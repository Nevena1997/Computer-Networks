package zad1;

final class Zad1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Zad1Main!");
    }
}

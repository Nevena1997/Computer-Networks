package zad1;

final class HTMLReaderThread extends Thread {
    
}

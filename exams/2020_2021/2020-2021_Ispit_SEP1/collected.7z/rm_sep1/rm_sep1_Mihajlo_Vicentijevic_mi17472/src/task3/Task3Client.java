package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (SocketChannel socket = SocketChannel.open(new InetSocketAddress("localhost", 12345));
             Scanner sc = new Scanner(System.in)) {
            ByteBuffer buff = ByteBuffer.allocate(256);

            for (int i = 0; i < 4; i++) {
                byte b = sc.nextByte();
                buff.put(b);
                buff.flip();
                socket.write(buff);
                buff.clear();
            }

            buff.clear();
            System.err.println("pre");
            socket.read(buff);
            buff.flip();

            int num = buff.getInt();
            System.out.println(num);
            System.err.println("posle");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Task3Server {

    private static int hiddenNum;

    public static void main(String[] args) {

        Random r = new Random();
        boolean run = true;

        hiddenNum = r.nextInt(500);
        for ( int i = 2; i < 500; i++) {
            if ( (hiddenNum + i) % i == 0) {
                break;
            }
        }


        try (ServerSocketChannel socket = ServerSocketChannel.open();
             Selector selector = Selector.open()){
            socket.bind(new InetSocketAddress(12345));
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_ACCEPT);


            while (true) {

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()) {
                        System.err.println("key.isAcceptable");
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                        clientKey.attach(ByteBuffer.allocate(256));

                    } else if (key.isReadable()) {
                        System.err.println("key.isReadable");
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();
                        client.read(buff);

                        System.err.println(buff.position());
                        if (buff.position() == 4) {
                            System.err.println("usao sam");
                            ByteBuffer numBytes = ByteBuffer.allocate(4);
                            for (int i = 0; i < 4; i++) {
                                buff.position(buff.position() - 1);
                                numBytes.put(buff.get());
                            }
                            numBytes.flip();
                            int num = numBytes.getInt();
                            int res = num ^ hiddenNum;

                            buff.clear();
                            buff.putInt(res);
                            buff.flip();
                            key.attach(buff);

                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                    } else if (key.isWritable()) {
                        System.err.println("key.isWritable()");
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();
                        client.write(buff);
                        if (!buff.hasRemaining()) {
                            key.attach(ByteBuffer.allocate(256));
                            key.interestOps(SelectionKey.OP_READ);
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

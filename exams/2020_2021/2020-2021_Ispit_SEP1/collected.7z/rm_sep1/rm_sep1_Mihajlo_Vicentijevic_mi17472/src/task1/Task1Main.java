package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.text.DateFormat;
import java.util.Scanner;
import java.util.regex.Matcher;

public class Task1Main {

    public static void main(String[] args) {
        String fileName;
        try (Scanner sc = new Scanner(System.in)) {
//            ileName = sc.next();
            fileName = "file.txt";
        }



        try (BufferedReader in = new BufferedReader(new FileReader(fileName, StandardCharsets.UTF_8));
             BufferedWriter out = new BufferedWriter(new FileWriter("timestamp.txt", StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    Date date;

                        String[] nums = word.split("-");
                        if(nums.length == 3) {
                            try {
                                date = Date.valueOf(nums[2] + "-" + nums[1] + "-" + nums[0]);
                            } catch (IllegalArgumentException e) {
                                continue;
                            }
                            out.write(date.toString());
                            out.newLine();
                            out.flush();
                        }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Task2Server {
    private static final Path inputDir = Paths.get("/home/ispit/Desktop/tests/aerodromi");
    private static final Map<String, List<Fly>> airports = new HashMap<>();


    public static void main(String[] args) {
        try (ServerSocket socket = new ServerSocket(12345)) {


            walk(inputDir);
//            printAirportsData();

            while (true) {
                Socket client = socket.accept();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
                     BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8))) {

                    out.write(getCities());
                    out.newLine();
                    out.flush();

                    String cityName = in.readLine();
                    out.write(getFlyList(cityName));
                    out.flush();

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void walk(Path path) throws IOException {
        try(var ds = Files.newDirectoryStream(path)) {
            for (Path p : ds) {
                if (Files.isDirectory(p)) {
                    walk(p);
                } else {
                    loadAirportsData(p);
                }
            }
        }
    }

    private static void loadAirportsData(Path p) throws IOException {
        String fileName = p.getFileName().toString();
        String cityName = fileName.substring(0, fileName.lastIndexOf("."));

        List<Fly> flyList = new ArrayList<>();
        BufferedReader fin = new BufferedReader(new FileReader(p.toFile(), StandardCharsets.UTF_8));
        String line;
        while ((line = fin.readLine()) != null) {
            String[] data = line.split("\\s+");
            flyList.add(new Fly(data[0], data[1], data[2], data[3]));
        }

        if (airports.containsKey(cityName)) {
            airports.get(cityName).addAll(flyList);
        } else {
            airports.put(cityName, flyList);
        }
    }

    private static void printAirportsData() {
        airports.forEach((key, value) -> {
            System.out.println("City: " + key);
            value.forEach(f -> {
                System.out.println("\t" + f.toString());
            });
        });
    }

    public static String getCities() {
        StringBuilder cities = new StringBuilder();
        airports.keySet().forEach(key -> {
            cities.append(key).append(" ");
        });

        return cities.toString();
    }

    public static String getFlyList(String cityName) {

        StringBuilder flyList = new StringBuilder();
        airports.get(cityName).forEach(el -> {
            flyList.append(el.toString()).append("\n");
        });
        return flyList.toString();
    }
}


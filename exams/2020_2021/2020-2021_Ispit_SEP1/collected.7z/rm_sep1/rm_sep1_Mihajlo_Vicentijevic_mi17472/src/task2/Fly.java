package task2;

public class Fly {

    private String code;
    private String city;
    private String startFly;
    private String endFly;


    public Fly(String code, String city, String startFly, String endFly) {
        this.code = code;
        this.city = city;
        this.startFly = startFly;
        this.endFly = endFly;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStartFly() {
        return startFly;
    }

    public void setStartFly(String startFly) {
        this.startFly = startFly;
    }

    public String getEndFly() {
        return endFly;
    }

    public void setEndFly(String endFly) {
        this.endFly = endFly;
    }

    @Override
    public String toString() {
        return code + " " + city + " " + startFly + " " + endFly;
    }
}

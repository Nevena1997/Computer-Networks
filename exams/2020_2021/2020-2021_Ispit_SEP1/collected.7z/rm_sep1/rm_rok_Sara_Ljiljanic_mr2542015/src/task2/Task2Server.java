package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class Task2Server {

    public static int PORT = 12345;

    public static void main(String[] args) {
/*
        try (ServerSocket server = new ServerSocket(PORT)) {

            String putanja = "/home/ispit/Desktop/tests/aerodromi";
            Path path = Paths.get(putanja);

            DirectoryStream<Path> ds = Files.newDirectoryStream(path);
            List<String> namesList = new ArrayList();
            for (Path p: ds) {
                namesList.add(p.getFileName().toString());
            }

            while (true) {
                Socket klijent = server.accept();
                Thread nit = new Thread(new Nit(klijent, namesList, putanja));
                nit.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
*/
    }
}

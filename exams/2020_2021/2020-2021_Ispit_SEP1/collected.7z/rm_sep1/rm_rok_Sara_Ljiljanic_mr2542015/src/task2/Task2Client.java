package task2;

import java.io.*;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
/*
        String putanja = "/home/ispit/Desktop/tests/aerodromi";
        Path path = Paths.get(putanja);

        try (Socket klijent = new Socket();
             BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()))) {


            //klijent od servera treba da primi listu imena gradova
            //server mu posalje broj gradova i klijent prima imena
            String brojElemenata = in.readLine();
            Integer broj = Integer.parseInt(brojElemenata);

            for (int i = 0; i < broj; i++) {
                String line = in.readLine();
                if (line == null || line.equalsIgnoreCase(""))
                    break;
                System.out.println(line);
            }

            System.out.println("Unesi ime grada: ");
            Scanner sc = new Scanner(System.in);
            String ime = sc.nextLine();

            out.write(ime);
            out.newLine();
            out.flush();

            while (true) {
                //cita informacije o gradu o kom je zeleo da zna
                String line = in.readLine();

                if (line == null)
                    break;


            }


        } catch (IOException e) {
            e.printStackTrace();
        }

        //klijent od servera prima listu imena gradova
*/
    }
}

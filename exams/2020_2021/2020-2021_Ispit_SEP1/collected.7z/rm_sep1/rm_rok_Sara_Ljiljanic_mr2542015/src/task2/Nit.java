package task2;

import java.io.*;
import java.net.Socket;
import java.util.List;

public class Nit implements Runnable {

    private Socket klijent;
    private List<String> namesList;
    private String putanja;
    private BufferedReader fromUser;
    private BufferedWriter toUser;
    private String name;


    public Nit(Socket klijent, List<String> namesList, String putanja) {
        this.klijent = klijent;
        this.namesList = namesList;
        this.putanja = putanja;
    }

    @Override
    public void run() {

        try {
            this.fromUser = new BufferedReader(new InputStreamReader(this.klijent.getInputStream()));
            this.toUser = new BufferedWriter(new OutputStreamWriter(this.klijent.getOutputStream()));

            //server klijentu salje listu imena gradova

            for (int i = 0; i < this.namesList.toArray().length; i++) {
                this.toUser.write(this.namesList.get(i));
                this.toUser.newLine();
                this.toUser.flush();
            }

            //klijent je serveru posalo ime grada od koga zeli informacije
            this.name = this.fromUser.readLine();

            //sada na osnovu imena grada server posalje sve informacije o letovima vezanim za taj grad
            BufferedReader grad = new BufferedReader(new InputStreamReader(new FileInputStream(this.name)));
            while (true) {
                String line = grad.readLine();

                if (line == null)
                    break;

                this.toUser.write(line);
                this.toUser.newLine();
                this.toUser.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

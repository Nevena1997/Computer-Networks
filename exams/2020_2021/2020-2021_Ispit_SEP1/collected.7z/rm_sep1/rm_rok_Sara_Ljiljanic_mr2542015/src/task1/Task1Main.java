package task1;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

/*
        //kopira sadrzaj textualnog fajla sa imenom koji se unosi sa standardnog ulaza
        //kopita u fajl timestamps.txt

        //Unesemo ime fajla iz kog kopiramo tekst
        System.out.println("Unesite ime fajla: ");
        Scanner sc = new Scanner(System.in);
        String imeFajla = sc.nextLine();

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(imeFajla)));
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt")))) {

            while (true) {

                String line = in.readLine();

                if (line == null)
                    break;

                if (jesteDatum(line)) {
                    out.write(line);
                    out.newLine();
                    out.flush();
                }

            }


        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

        private static boolean jesteDatum(String line) {

        String [] podaci = line.split("-");



        String danStr = podaci[0];
        Integer dan = Integer.parseInt(danStr);
        String mesecStr = podaci[1];
        Integer mesec = Integer.parseInt(mesecStr);
        String godinaStr = podaci[2];
        Integer godina = Integer.parseInt(godinaStr);

        if (dan < 1 || dan > 31)
            return false;

        if (mesec < 1 || mesec > 12)
            return false;

        if (mesec == 2 && dan > 29)
            return false;

        if (godina < 2000)
            return false;

        return true;


*/

    }


}


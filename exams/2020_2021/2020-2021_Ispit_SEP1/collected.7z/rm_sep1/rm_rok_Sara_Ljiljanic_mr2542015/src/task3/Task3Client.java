package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketOption;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;
import java.util.Set;

public class Task3Client {
    public static void main(String[] args) {
/*
        InetSocketAddress address = new InetSocketAddress(12345);

        try (SocketChannel klijent = SocketChannel.open(address);
             Scanner sc = new Scanner(System.in)) {

            //ucitava sa ulaza bajtove
            String s = sc.nextLine();
            byte[] bajtovi = s.getBytes();

            ByteBuffer buffer = ByteBuffer.allocate(4);
            buffer.put(bajtovi);
            buffer.flip();
            klijent.write(buffer);

            while (true) {
                buffer.clear();
                klijent.read(buffer);
                buffer.flip();

                int rezultat = buffer.getInt();
                System.out.println(rezultat);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

*/
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Task3Server {
    public static void main(String[] args) {
/*
        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if (!selector.isOpen() || !serverSocketChannel.isOpen()) {
                System.err.println("Greska");
                System.exit(1);
            }

            serverSocketChannel.bind(new InetSocketAddress(12345));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {

                    SelectionKey key = it.next();
                    it.remove();

                    try {

                        if (key.isAcceptable()) {

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel klijent = server.accept();

                            System.out.println("klijent je prihvacen");

                            klijent.configureBlocking(false);
                            SelectionKey selectionKey = klijent.register(selector, SelectionKey.OP_READ);
                            ByteBuffer buffer = ByteBuffer.allocate(4);
                            selectionKey.attach(buffer);


                        } else if (key.isReadable()) {

                            SocketChannel klijent = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            klijent.read(buffer);


                            if(!buffer.hasRemaining()) {
                                buffer.flip();
                                //
                            }

                        } else if (key.isWritable()) {
                            SocketChannel klijent = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            klijent.write(buffer);
                        }
                    }

                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }


 */
    }
}
package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {

        try (Socket client = new Socket(Task2Server.host, Task2Server.port)){

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            );

            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream()
                    )
            );

            String city;

            while (!(city = in.readLine()).equals("end")) {
                System.out.println(city);
            }

            Scanner sc = new Scanner(System.in);

            String c = sc.next();
            out.write(c);
            out.newLine();
            out.flush();

            while (!(city = in.readLine()).equals("end")) {
                System.out.println(city);
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class Task2Server {

    final static int port = 12345;
    final static String host = "localhost";


    public static void main(String[] args) throws IOException {

        LinkedList<String> files = walkDir(Paths.get("/home/ispit/Desktop/tests/aerodromi"));
        Map<String, LinkedList<String>> info = new HashMap<>();


        try(ServerSocket server = new ServerSocket(port)) {

            System.out.println("Server is waiting for clients...");

            while (true) {

                Socket client = server.accept();

                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(
                                client.getOutputStream()
                        )
                );


                for (String f : files) {
                    out.write(f);
                    out.newLine();
                    out.flush();
                }

                out.write("end");
                out.newLine();
                out.flush();

                BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
                );

                String city = in.readLine();

                LinkedList<String> list = getAirportInformation(city, info);


                for (String inf : list) {
                    out.write(inf);
                    out.newLine();
                    out.flush();

                }

                out.write("end");
                out.newLine();
                out.flush();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }




    }

    private static LinkedList<String> walkDir(Path path) throws IOException {

        LinkedList<String> files = new LinkedList<>();

        DirectoryStream ds = Files.newDirectoryStream(path);

        ds.forEach(f -> files.add(f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("."))));


        return files;

    }

    public static LinkedList<String> getAirportInformation(String city, Map<String, LinkedList<String>> info) {

        LinkedList<String> list = new LinkedList<>();


        if (info.containsKey(city)) {
            System.out.println("aaaa");
            return info.get(city);
        } else {
            Path path = Paths.get("/home/ispit/Desktop/tests/aerodromi/" + city + ".txt");

            File f = new File(path.toString());


            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(f)
                    )
            )) {

                String l;

                while ((l = in.readLine()) != null) {
                    list.add(l);
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }



        }

        info.put(city, list);

        return list;

    }

}



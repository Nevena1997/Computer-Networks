package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Task1Main {

    public static void main(String[] args) {

        Path path = Paths.get("timestamps.txt");


        try (   BufferedReader inC = new BufferedReader(
                new InputStreamReader(
                        System.in
                )
        );

                  BufferedWriter out = new BufferedWriter(
                          new OutputStreamWriter(
                          Files.newOutputStream(path)
                    )
            );

        ) {




            String p = inC.readLine();

            try (    BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            Files.newInputStream(Paths.get(p))
                    )
            );){

                String line;
                while ((line = in.readLine()) != null) {
                    if (isValid(line)) {
                        out.write(line);
                        out.newLine();
                        out.flush();
                    }
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    private static boolean isValid(String line) {

        if (Character.isDigit(line.charAt(0))
                && Character.isDigit(line.charAt(1))
                    && Character.isDigit(line.charAt(3))
                       && Character.isDigit(line.charAt(4))
                        && Character.isDigit(line.charAt(6))
                         && Character.isDigit(line.charAt(7))
                            && Character.isDigit(line.charAt(8))
                                && Character.isDigit(line.charAt(9))
                                    && line.substring(2, 3).equals("-")
                                        && line.substring(5, 6).equals("-")
                                            && (line.substring(3, 4).equals("0") || line.substring(3, 4).equals("1")  || line.substring(3, 4).equals("2")
                                               || (line.substring(3, 4).equals("3")  && (line.substring(4, 5).equals("0") || line.substring(4, 5).equals("1"))))
                                                && line.substring(6, 7).equals("2")
        ) {

            return true;

        }

        return false;

    }

}

package task3;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.PORT));
            Scanner sc = new Scanner(System.in)) {

            ByteBuffer buffer = ByteBuffer.allocate(4);

            for (int i = 0; i < 4; i++) {
                byte b = sc.nextByte();
                buffer.put(b);
            }

            buffer.flip();
            client.write(buffer);
            buffer.flip();




        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Random;

public class Task3Server {
    public static final int  PORT = 12345;

    public static void main(String[] args) {
        Random r = new Random();
        int secretNumber = r.nextInt();

        try (ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            ByteBuffer buffer = ByteBuffer.allocate(1000);


            while (true) {
                SocketChannel client = server.accept();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

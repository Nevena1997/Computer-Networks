package task1;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {
        String fileName;
        System.out.print("Unesite ime fajla: ");
        try (Scanner sc = new Scanner(System.in)) {
            fileName = sc.nextLine();
        }

        Path path = Paths.get(fileName);
        Path outPath = Paths.get("timestamps.txt");

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path.toString())));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outPath.toString())))) {
            String line;
            while ((line = in.readLine()) != null) {
                String[] reci = line.split(" ");
                for (String rec : reci) {
                    if (rec.contains("-")) {
                        String[] s = rec.split("-");
                        if (s.length != 3)
                            continue;
                        try {
                            if (Integer.parseInt(s[0]) > 0 && Integer.parseInt(s[0]) <= 31 && Integer.parseInt(s[1]) <= 12 && Integer.parseInt(s[1]) > 0 && Integer.parseInt(s[2].substring(0, 4)) > 2000) {
                                out.write(s[0] + "-" + s[1] + "-" + s[2].substring(0, 4));
                                out.newLine();
                                out.flush();
                            }
                        } catch (NumberFormatException e) {
                            continue;
                        }
                    }
                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("Fajl ne postoji!");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Finished!");
    }
}

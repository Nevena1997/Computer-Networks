package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", Task2Server.PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader((client.getInputStream())));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)) {
            System.err.println("Client connected!");
            //client.setSoTimeout(1000);

            String line;
            while (!(line = in.readLine()).equalsIgnoreCase("kraj")) {
                System.out.println(line);
            }

            System.out.print("Unesite naziv grada: ");
            String cityName = sc.next();

            out.write(cityName);
            out.newLine();
            out.flush();

            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Task2Server {
    public static final int PORT = 12345;

    public static void main(String[] args) throws IOException {
        Map<String, String> map = new HashMap<>();
        Path path = Paths.get("/home/ispit/Desktop/tests/aerodromi");

        for (Path p : Files.newDirectoryStream(path)) {
            String lines = "";
            String line;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))) {
                int i = 0;
                while ((line = in.readLine()) != null) {
                    lines += line + "\n";
                }
                String fileName = (String.valueOf(p.getFileName()).split("\\."))[0];
                map.put(fileName, lines);

            }
        }

        //System.out.println(map);

        try(ServerSocket server = new ServerSocket(PORT)) {
            System.err.println("Listening...");

            while (true) {
                Socket client = server.accept();

                try (BufferedReader in = new BufferedReader(new InputStreamReader((client.getInputStream())));
                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

                    var iterator = map.entrySet().iterator();
                    while (iterator.hasNext()) {
                        out.write(iterator.next().getKey());
                        out.newLine();
                        out.flush();
                    }

                    out.write("kraj");
                    out.newLine();
                    out.flush();

                    String cityName = in.readLine().trim();

                    iterator = map.entrySet().iterator();

                    while (iterator.hasNext()) {
                        if (iterator.next().getKey().equalsIgnoreCase(cityName)) {
                            out.write(iterator.next().getValue());
                            out.newLine();
                            out.flush();
                        }
                    }

                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {
    
    
    private Socket socket;

    public Task2Client(int port, String hostname) throws IOException {
        socket = new Socket(hostname,port);
        this.port = port;
        this.hostname = hostname;
        stdout = new PrintWriter(new OutputStreamWriter(System.out),true);
    }

    private int port;
    private String hostname;
    PrintWriter stdout;
    public static void main(String[] args) {
        try {
            Task2Client client = new Task2Client(12345,"localhost");
            client.executeClient();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    private void executeClient() throws IOException {
        try(Scanner userIn = new Scanner(System.in);
            BufferedReader networkIn  = new BufferedReader( new InputStreamReader(socket.getInputStream()));
            PrintWriter networkOut  = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()))){

            String line;

//            var lines = networkIn.lines().toString();
//            System.err.println(lines);
//            stdout.println(lines);
//            stdout.flush();



            while((line = networkIn.readLine())!=null){
                System.err.println(line);
               // stdout.println(line);
               // stdout.flush();
            }


            System.err.println("Dosao ovde?");
            stdout.println("Unesite trazeni grad");
            String trazeniGrad = userIn.nextLine();
            networkOut.println(trazeniGrad);
            networkOut.flush();

            while((line = networkIn.readLine())!=null){
                System.err.println(line);
                // stdout.println(line);
                // stdout.flush();
            }

            }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}

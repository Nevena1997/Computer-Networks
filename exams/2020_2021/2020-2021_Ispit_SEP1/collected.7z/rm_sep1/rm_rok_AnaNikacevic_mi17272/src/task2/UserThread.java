package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class UserThread implements Runnable {


    private Task2Server server;
    private Socket client;

    public UserThread(Task2Server serverIn, Socket clientIn) {
        server = serverIn;
        client = clientIn;
    }

    @Override
    public void run() {
        try(BufferedReader networkIn  = new BufferedReader( new InputStreamReader(client.getInputStream()));
            PrintWriter networkOut  = new PrintWriter(new OutputStreamWriter(client.getOutputStream()))) {

            StringBuffer gradovi = new StringBuffer("");


            System.err.println("Poceo klijent");
            for(var x : server.getMapa().keySet()) {
                networkOut.println(x.toString());
                networkOut.flush();
//                gradovi.append(x);
//                gradovi.append("\n");
            }
//            System.err.println(gradovi);
//            networkOut.println(gradovi.toString());
//            networkOut.flush();
            System.err.println("Dosao ovde na serever");

           String trazeniGrad = "Beograd";
          //  String trazeniGrad = networkIn.readLine();
        //    System.err.println(trazeniGrad);

            for(Task2Server.Let  x : server.getMapa().get(trazeniGrad)){
                networkOut.println(x);
                networkOut.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

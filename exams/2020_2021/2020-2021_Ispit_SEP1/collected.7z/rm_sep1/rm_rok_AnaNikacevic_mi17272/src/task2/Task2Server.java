package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Task2Server {
    private ServerSocket socket;
    private Map<String, List<Let>> mapa;

    public Map<String, List<Let>> getMapa() {
        return mapa;
    }

    public Task2Server(int port) throws IOException {
        socket = new ServerSocket(port);
        mapa = new HashMap<>();
        loadData();
        this.port = port;
    }
    public class Let{
        private String sifra;
        private String grad;
        private String polazak;
        private String dolazak;

        @Override
        public String toString() {
            return "\tLet{" +
                    "sifra='" + sifra + '\'' +
                    ", grad='" + grad + '\'' +
                    ", polazak='" + polazak + '\'' +
                    ", dolazak='" + dolazak + '\'' +
                    '}';
        }

        public Let(String sifra, String grad, String polazak, String dolazak) {
            this.sifra = sifra;
            this.grad = grad;
            this.polazak = polazak;
            this.dolazak = dolazak;
        }
    }

    private void loadData() throws IOException {

        for (Path p: Files.newDirectoryStream(Paths.get("../tests/aerodromi")) ){
            String filename = p.getFileName().toString();
            var file = Files.newBufferedReader(Paths.get("../tests/aerodromi/" + filename));
            var letovi = new ArrayList<Let>();
            int tacka = filename.indexOf('.');
            String grad = filename.substring(0,tacka);

            while (true){
                String line = file.readLine();
                if(line==null)
                    break;
                String[] reci = line.split(" ");
                var value = new Let(reci[0],reci[1],reci[2],reci[3]);
                letovi.add(value);
            }
            mapa.put(grad,letovi);
        }

    }
    private int port;
    private String hostname;

    public static void main(String[] args) {
        try {
            Task2Server server = new Task2Server(12345);
            System.err.println("Server ready");

            while(true) {
                Socket client = server.socket.accept();
                Thread t1 = new Thread(new UserThread(server, client));
                t1.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Hello world!");
    }

}

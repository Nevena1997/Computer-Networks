package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

        BufferedReader fajl=null;
        try( var result = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/task1/"+"timestamps.txt"), StandardCharsets.UTF_8)))
        {

            System.out.println("Unesite ime fajla");
            Scanner input = new Scanner(System.in);


            String line = input.nextLine();
            fajl = new BufferedReader(new InputStreamReader(new FileInputStream("src/task1/"+line), StandardCharsets.UTF_8));
            String linija;
            while((linija=fajl.readLine())!=null){
                //System.err.println(linija.length());
                if(linija.length()==10 && linija.contains("-")) {

                           String[] reci = linija.split("-");
                           if(reci.length==3) {
                               if (reci[0].length() == 2 && reci[1].length() == 2 && reci[2].length() == 4){
                                   int godine = Integer.parseInt(reci[2]);
                                   int mesec = Integer.parseInt(reci[1]);
                                   int dan = Integer.parseInt(reci[0]);
                                   if( godine>=2000 && dan >=1 && dan<=31 && mesec >=1 && mesec<=12 ) {
                                       result.write(linija);
                                       result.newLine();
                                       result.flush();
                                   }

                               }
                           }

                           }
                }


        }catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        catch(IOException e){
            e.printStackTrace();
        }
      finally {
            try {
                if(fajl!=null)
                        fajl.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

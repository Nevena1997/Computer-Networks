package task3;

import task2.Task2Client;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

public class Task3Server {
    private ServerSocketChannel server;
    private final int port = 12345;
    private void mainLoop() throws IOException {
        try{
            server = ServerSocketChannel.open();
            Selector selector = Selector.open();

            server.bind(new InetSocketAddress(port));
            server.configureBlocking(false);
            var it = selector.selectedKeys().iterator();

            while(it.hasNext()){
                var key = it.next();
                it.remove();

                if(key.isAcceptable()){
                    ServerSocketChannel channel = (ServerSocketChannel)key.channel();
                    SocketChannel client = channel.accept();
                    client.register(selector,SelectionKey.OP_ACCEPT);




                }
                else if(key.isReadable()){
                    SocketChannel client = (SocketChannel)key.channel();
                    ByteBuffer buffer =(ByteBuffer) key.attachment();
                    if(buffer==null) {
                        buffer = ByteBuffer.allocate(4);
                        key.attach(buffer);
                    }


                    key.interestOps(SelectionKey.OP_WRITE);
                }
                else if(key.isWritable()){
                    SocketChannel client = (SocketChannel)key.channel();
                    ByteBuffer buffer = (ByteBuffer)key.attachment();


                    key.interestOps(SelectionKey.OP_READ);
                }
            }

        }catch (IOException e){
            e.printStackTrace();
        }




    }

    public static void main(String[] args) throws IOException {

        Task3Server server = new Task3Server();
        server.mainLoop();


    }
}

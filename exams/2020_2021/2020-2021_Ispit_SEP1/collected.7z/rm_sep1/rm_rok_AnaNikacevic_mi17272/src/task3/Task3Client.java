package task3;

import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

public class Task3Client {
    private SocketChannel server;
    private final int port = 12345;
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

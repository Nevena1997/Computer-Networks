package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/*
    Klijent
        port 1234
        salje serveru 4 bayta jedan za drugim
        koji su ucitani sa stdin

    Server:
        server cuva skriveni ceo broj. Prilikom pbradjivanja klijenata
        server prihvata bajtove od visih ka nizim i kreira ceo broj. Npr:
        0xA0, 0xBO , 0xC0, 0xD0 on kreira 0xA0B0C0D0.
        Server nakon toga klijentu salje novi broj nastao primenom operacije xor na prihvacene brojeve
        i skrivenog broja

        Slucajno generise skriveni ceo broji i ispisuje ga stdou
        Mora biti veci od 999 i prost.

        Klijent  ispisuje primljeni broj na izlaz.




 */
public class Task3Server {
    public static int PORT = 1234;
    public static int count = 0;
    private static int skriven_broj;
    public static List<String> listaPoruka = new ArrayList<>();
    public static void main(String[] args) throws IOException {
        Random rand = new Random();
        int broj ;
        if((broj = rand.nextInt())>999){
            if(prost(broj)){
                skriven_broj = broj;
            }
        }
        ServerSocketChannel server = ServerSocketChannel.open();
        Selector selector = Selector.open();

        server.bind(new InetSocketAddress("localhost",PORT));
        server.configureBlocking(false);
        server.register(selector, SelectionKey.OP_ACCEPT);

        while(true){
            selector.select();
            Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
            while(iterator.hasNext()){
                SelectionKey key = iterator.next();
                iterator.remove();
                if(key.isAcceptable()){
                    ServerSocketChannel socket = (ServerSocketChannel) key.channel();
                    SocketChannel client = socket.accept();

                    client.configureBlocking(false);
                    SelectionKey clientKey = client.register(selector,SelectionKey.OP_READ);

                    ByteBuffer buffer = ByteBuffer.allocate(20);
                    clientKey.attach(buffer);
                    buffer.flip();



                }else if(key.isReadable()){
                    SocketChannel client = (SocketChannel) key.channel();
                    ByteBuffer buffer = (ByteBuffer) key.attachment();

                    client.read(buffer);
                    buffer.flip();
                    String fromClient = new String(buffer.array(),0,buffer.limit());
                    System.out.println("Procitan bajt "+ fromClient);
                    /*
                        dodajemo ga u niz stringova kojim obradjujemo bajtove

                     */
                    listaPoruka.add(fromClient);
                    if(count>=4){
                        System.out.println("Kraj unosa");
                        /*
                                iz liste poruka citamo elemente i obradjujemo
                         */
                        for (String byteInString : listaPoruka){
                        }
                        key.interestOps(SelectionKey.OP_WRITE);
                    }
                    buffer.flip();
                    key.interestOps(SelectionKey.OP_WRITE);





                }else if(key.isWritable()){
                    SocketChannel client = (SocketChannel) key.channel();
                    ByteBuffer buffer = (ByteBuffer) key.attachment();

                    client.close();
                }
            }

        }

    }

    private static boolean prost(int broj) {
        for(int i = 2 ;i<=Math.sqrt(broj);i++){
            if(broj % i !=0)
                return false;
        }
        return true;
    }
}

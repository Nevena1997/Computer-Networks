package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.PORT))) {
            //sada zelimo sa standardnog ulaza da ucitamo bajtove

            Scanner sc= new Scanner(System.in);

            ByteBuffer byteBuffer = ByteBuffer.allocate(210);
            for (int i = 0 ;i<4;i++){
                String number = sc.nextLine();
                byteBuffer.put(number.getBytes());
                byteBuffer.flip();
                client.write(byteBuffer);
                byteBuffer.clear();
            }

            //Sada iz bajtbafera citamo rezutat
            client.read(byteBuffer);
            byteBuffer.flip();
            System.out.println(new String(byteBuffer.array(),0,byteBuffer.limit()));

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

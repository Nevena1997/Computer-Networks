package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/*
    u direktorijumu aerodromi , unutar ests , nalaze se tekstualni fajlovi sa info o odlaznim letovima
    ime fajla - ime grada u kojem je aerodrom
    scaka linija oblika <Sifra> <grad sletanja> <vreme poletanja> <vreme sletanja>

    Server:
        port 12345
        svakom klijentu saljem o spisak gradova za cije aerodrome imamo info o letovima

     Klijent:
        klijent ceka spisak graodva i ispisuje ih na stdout
        klijent onda salje ime grada ,uneto sa sdin
        server vraca informacije o letovima iz tog grada odn aerodroma



 */
public class Task2Server {
    public  static int PORT = 12345;
    public static Map<String, String> nameToInfo = new HashMap<>();


    public static void main(String[] args) throws IOException {
        //prvo ucitavamo informacije u mapu
        Path dir = Paths.get("/home/ispit/Desktop/tests/aerodromi");

        DirectoryStream<Path> ds = Files.newDirectoryStream(dir);
        for (Path p : ds){
            String imeGrada = p.getFileName().toString().split("\\.")[0];
            StringBuilder data = new StringBuilder();
            Scanner sc = new Scanner(p);
            String line ;

            while((sc.hasNextLine())){
                data.append(sc.nextLine()+"\n");
            }
            nameToInfo.put(imeGrada,data.toString());
        }

        //prihvatamo klijenta i saljemo sve kljuceve mape
        ServerSocket server = new ServerSocket(PORT);
        Socket client = server.accept();
        System.out.println("Klijent prihvacen");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            StringBuilder sb = new StringBuilder();
            for (String grad : nameToInfo.keySet()) {
                out.write(grad);
                out.newLine();
                out.flush();
            }

            out.write("kraj");
            out.newLine();
            out.flush();


            //sada od klijenta ocekujemo ime grada
            String line=in.readLine();
            System.out.println(line);

            System.out.println("Data: " + nameToInfo.get(line));
            out.write(nameToInfo.get(line));
            out.newLine();
            out.flush();

            out.write("kraj");
            out.flush();
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            client.close();
        }


    }
}

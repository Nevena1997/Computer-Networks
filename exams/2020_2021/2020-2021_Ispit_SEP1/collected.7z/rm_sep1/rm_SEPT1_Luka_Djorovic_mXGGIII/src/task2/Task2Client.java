package task2;


/*
    u direktorijumu aerodromi , unutar ests , nalaze se tekstualni fajlovi sa info o odlaznim letovima
    ime fajla - ime grada u kojem je aerodrom
    scaka linija oblika <Sifra> <grad sletanja> <vreme poletanja> <vreme sletanja>

    Server:
        port 12345
        svakom klijentu saljem o spisak gradova za cije aerodrome imamo info o letovima

     Klijent:
        klijent ceka spisak graodva i ispisuje ih na stdout
        klijent onda salje ime grada ,uneto sa sdin
        server vraca informacije o letovima iz tog grada odn aerodroma



 */

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", Task2Server.PORT)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner sc = new Scanner(System.in);

            // klijent od servera prima spisak gradova

            String line ;
            while(!(line=in.readLine()).equalsIgnoreCase("kraj")) {
                System.out.println(line);
            }


            //biramo grad
            String choice = sc.nextLine();
            //ovde sada serveru saljemo ime izbranpg grad
            out.write(choice);
            out.newLine();
            out.flush();

            //sada cekamo da server posalje informacije o aerodromu
            String line1;
            while(!(line1=in.readLine()).equalsIgnoreCase("kraj")){
                System.out.println(line1);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/*
    ucitava se ime fajla se ulaza i kopira se sadrzaj u timestamps.txt.

    Prekopirati samo one niske koje predstavljaju niske u formatu DD-MM-YYYY.
    Svi meseci imaju najvise 31 dan i godina je veca od 02-12-2015.

    koristiti baferisaje ulaznog i izlaznog toka

    po jedna niska u svakoj linij

    kodne strane su UTF-8


 */
public class Task1Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);


        System.out.println("Uneste ime fajla iz kojeg vadite datume");

        String fileName = sc.nextLine();

        Path pathSource = Paths.get(fileName);
        Path pathDest = Paths.get("/home/ispit/Desktop/rm_SEPT1_Luka_Djorovic_mXGGIII/src/task1/timestamps.txt");


        BufferedReader in = Files.newBufferedReader(pathSource);
        BufferedWriter out = Files.newBufferedWriter(pathDest);

        String line;
        while((line=in.readLine())!=null){
            String[] tokens = line.split(" ");
            for( String word : tokens){
                if(dateFormat(word)){
                    out.write(word);
                    out.newLine();
                    out.flush();
                }
            }
        }

    }

    private static boolean dateFormat(String word) {
        String tokens[];
        if((tokens=word.split("-")).length==3){
            if(tokens[0].length()==2 && tokens[1].length()==2 && tokens[2].length()==4) {
                try {
                    int day = Integer.parseInt(tokens[0]);
                    int month = Integer.parseInt(tokens[1]);
                    int year = Integer.parseInt(tokens[2]);
                    if(year>=200 && day>=0 && day<=31 && month>=0 && month<=12)
                        return true;
                }catch(NumberFormatException e){
                    return false;
                }
            }
        }
        return false;
    }
}

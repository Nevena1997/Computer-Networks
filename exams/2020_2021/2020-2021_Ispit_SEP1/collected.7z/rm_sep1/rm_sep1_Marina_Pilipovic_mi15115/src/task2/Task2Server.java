package task2;

public class Task2Server {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

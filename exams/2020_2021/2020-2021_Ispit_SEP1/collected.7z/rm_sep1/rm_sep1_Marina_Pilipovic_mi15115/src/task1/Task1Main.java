package task1;

import javax.net.ssl.StandardConstants;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Napisite ime fajla:");
        String ime_fajla=sc.next();
        sc.close();

        try(InputStreamReader isr=
                    new InputStreamReader(
                            new BufferedInputStream(
                                    new FileInputStream(ime_fajla)), StandardCharsets.UTF_8);
            OutputStreamWriter osw=
                new OutputStreamWriter(
                        new BufferedOutputStream(
                                new FileOutputStream("timestamps.txt")), StandardCharsets.UTF_8
                )) {

            Scanner read=new Scanner(isr);
            while(read.hasNext()) {
                String datum = read.next();

                if (datum.length() == 10) {
                    if (Character.isDigit(datum.charAt(0)) &&
                            Character.isDigit(datum.charAt(1)) &&
                            Character.isDigit(datum.charAt(3)) &&
                            Character.isDigit(datum.charAt(4)) &&
                            Character.isDigit(datum.charAt(6)) &&
                            Character.isDigit(datum.charAt(7)) &&
                            Character.isDigit(datum.charAt(8)) &&
                            Character.isDigit(datum.charAt(9)) &&
                            datum.charAt(2) == '-' && datum.charAt(5) == '-') {
                        //System.out.println(datum.substring(0, 2));
                        int dan = Integer.parseInt(datum.substring(0, 2));
                        int mesec = Integer.parseInt(datum.substring(3, 5));
                        int godina = Integer.parseInt(datum.substring(6, 10));

                        if (dan >= 1 && dan <= 31 &&
                                mesec >= 1 && mesec <= 12 &&
                                godina > 2000) {
                            osw.write(datum + "\n");
                        }
                    }
                }
            }
            read.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

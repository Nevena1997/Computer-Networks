package task2;

import java.io.*;
import java.net.Socket;

public class Task2WorkerThread extends Thread {
    private Socket connection;
    Task2WorkerThread(Socket client){
        connection = client;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()))) {

            //Salje spisak gradova
            String gradovi = "Gradovi: " + Task2Server.listaLetova.keySet().toString();
            out.write(gradovi);
            out.newLine();
            out.flush();

            String grad = in.readLine().trim();

            if(Task2Server.listaLetova.containsKey(grad)){
                Task2Server.listaLetova.get(grad).stream().sequential().forEach(line -> {
                    try {
                        out.write(line);
                        out.newLine();
                    } catch (IOException e) {
                        System.err.println("Error while sending client \"" + line + "\"!");
                    }
                });
                out.write(Task2Server.OK_MESSAGE);
                out.newLine();
                out.flush();
            } else {
                out.write(Task2Server.ERROR_MESSAGE);
                out.newLine();
                out.flush();
            }


        } catch (IOException e) {
            System.err.println("Error while working with client!");
        } finally {
            try {
                connection.close();
            } catch (IOException e) {
                System.err.println("Error while ending connection with client!");
            }
        }
    }
}

package task2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Task2Server {
    public static Map<String, List<String>> listaLetova = null;
    public static final int PORT = 12345;
    public static final String OK_MESSAGE = "Gotovo!";
    public static final String ERROR_MESSAGE = "Izabrali ste nepostojeci grad!";

    static {
        try (Stream<Path> fajlovi = Files.walk(Paths.get("/home/ispit/Desktop/tests/aerodromi"))) {
            listaLetova = fajlovi.filter(Files::isRegularFile)
                    .collect(Collectors.toMap(
                            file -> {
                                String fileName = file.toFile().getName();
                                return fileName.substring(0, fileName.lastIndexOf('.')).trim();
                            },
                            file -> {
                                try (BufferedReader in = new BufferedReader(new FileReader(String.valueOf(file)))) {
                                    return in.lines().map(String::trim).collect(Collectors.toList());
                                } catch (IOException e) {
                                    return new LinkedList<>();
                                }
                            },
                            (a, b) -> b
                    ));
        } catch (IOException e) {
            System.exit(1);
        }
    }

    public static void main(String[] args){
        System.err.println("========UCITANI LETOVI============");
        listaLetova.forEach((key, value) -> {System.err.println(key + ":"); value.forEach(line -> System.err.println("\t" + line));});
        System.err.println("==================================");

        try (ServerSocket connection = new ServerSocket(PORT)) {
            while(true){
                Socket client = connection.accept();
                System.err.println("Accepted new client!");
                Task2WorkerThread thread = new Task2WorkerThread(client);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

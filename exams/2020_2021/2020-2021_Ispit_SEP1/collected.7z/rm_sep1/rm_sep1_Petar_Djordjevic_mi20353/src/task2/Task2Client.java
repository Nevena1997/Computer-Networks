package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try (Socket connection = new Socket("localhost", Task2Server.PORT);
             Scanner in = new Scanner(System.in);
             BufferedReader cIn = new BufferedReader(new InputStreamReader(connection.getInputStream()));
             BufferedWriter cOut = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()))) {

            System.out.println(cIn.readLine().trim());

            cOut.write(in.nextLine().trim());
            cOut.newLine();
            cOut.flush();

            String response;
            do{
                response = cIn.readLine();
                System.out.println(response);
            }   while (!response.equals(Task2Server.OK_MESSAGE) && !response.equals(Task2Server.ERROR_MESSAGE));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

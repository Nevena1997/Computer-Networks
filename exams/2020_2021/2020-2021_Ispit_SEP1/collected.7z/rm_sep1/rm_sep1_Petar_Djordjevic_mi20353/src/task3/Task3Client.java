package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args){
        ByteBuffer request = ByteBuffer.allocate(4);

        try (Scanner in = new Scanner(System.in)){
            for (int i = 0; i != 4; ++i) request.put(in.nextByte());
        }

        request.flip();

        try (SocketChannel connection = SocketChannel.open()){

            connection.connect(new InetSocketAddress("localhost", Task3Server.PORT));

            connection.write(request);

            ByteBuffer response = ByteBuffer.allocate(4);

            System.err.println(Arrays.toString(response.array()));

            connection.read(response);

            System.err.println(Arrays.toString(response.array()));

            response.flip();

            System.err.println(Arrays.toString(response.array()));

            System.out.println(Task3Server.makeInt(response.array()));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;

public class Task3Server {
    public static final int PORT = 12345;
    public static void main(String[] args) {
        final int secretNumber = generateSecretNumber();
        System.out.println("Secret number: " + secretNumber);

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){
            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);

            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                try {
                    selector.select();
                    Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                    while (iterator.hasNext()){
                        SelectionKey key = iterator.next();
                        iterator.remove();

                        if(key.isAcceptable()){
                            System.err.println("Client accepted!");
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);

                            client.register(selector, SelectionKey.OP_READ);
                        } else if(key.isReadable()){
                            System.err.println("Reading from client!");
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            if(buffer == null){
                                buffer = ByteBuffer.allocate(4);
                                key.attach(buffer);
                            }
                            if(buffer.hasRemaining()){
                                client.read(buffer);
                            }
                            if(!buffer.hasRemaining()){
                                buffer.flip();
                                int number = secretNumber ^ makeInt(buffer.array());
                                System.err.println(number);
                                buffer.clear();
                                buffer.putInt(number);
                                buffer.flip();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                        } else if (key.isWritable()){
                            System.err.println("Writing to client!");
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            if(buffer.hasRemaining()){
                                client.write(buffer);
                            }
                            if(!buffer.hasRemaining()){
                                client.close();
                                System.err.println("Done with client!");
                            }
                        }

                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static int makeInt(byte[] bytes){
        int result = 0;

        for(byte b : bytes){
            result *= 256;
            result += b>=0?b:(b+256);
        }

        return result;
    }

    private static int generateSecretNumber() {
        Random r = new Random();
        int generatedNumber;

        do {
            generatedNumber = r.nextInt() + 999;
        } while (generatedNumber < 999 || !isPrime(generatedNumber));

        return generatedNumber;
    }

    private static boolean isPrime(int number){
        if (number % 2 == 0) return false;
        for(int i = 3; i <= Math.sqrt(number); i += 2){
            if (number % i == 0) return false;
        }
        return true;
    }
}

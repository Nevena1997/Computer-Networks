package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

        System.out.println("Unesite putanju do fajla:");

        String putanjaDoFajla;
        try (Scanner in = new Scanner(System.in)) {
            putanjaDoFajla = in.nextLine().trim();
        }

        try (BufferedReader fileIn = new BufferedReader(new FileReader(putanjaDoFajla, StandardCharsets.UTF_8));
             BufferedWriter fileOut = new BufferedWriter(new FileWriter("timestamps.txt", StandardCharsets.UTF_8))) {

            fileIn.lines().sequential()
                    .filter(line -> line.matches("^((0[1-9])|([1-2][0-9])|(3[0-1]))-((0[1-9])|(1[0-2]))-(2[0-9]{3})$"))
            .forEach(timestamp -> {
                try {
                    fileOut.write(timestamp);
                    fileOut.newLine();
                } catch (IOException ignored) {}
            });
            fileOut.flush();

        } catch (FileNotFoundException e) {
            System.err.println("Uneli ste nepostojec fajl!");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

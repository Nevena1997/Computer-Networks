package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Task2Client {

    private Socket sock;


    Task2Client(){}


    private void print(BufferedReader br) throws IOException {
        while(true){
            String line = br.readLine();
            if(line.equalsIgnoreCase("kraj")){
                break;
            }
            else{
                System.out.println(line);
            }
        }
    }

    public void execute(){
        BufferedReader br = null;
        PrintWriter pw = null;
        try {
            sock = new Socket(InetAddress.getLocalHost().getHostAddress(), Task2Server.DEFAULT_PORT);
            br = new BufferedReader(new InputStreamReader(sock.getInputStream(), StandardCharsets.UTF_8));
            print(br);

            pw = new PrintWriter(sock.getOutputStream(), true);
            String city = null;
            try(Scanner sc = new Scanner(System.in)){
                System.out.println("Unesite naziv grada za koji zelite podatke");
                city = sc.nextLine();
            }
            pw.println(city);
            print(br);


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {

        Task2Client client = new Task2Client();
        client.execute();


    }
}

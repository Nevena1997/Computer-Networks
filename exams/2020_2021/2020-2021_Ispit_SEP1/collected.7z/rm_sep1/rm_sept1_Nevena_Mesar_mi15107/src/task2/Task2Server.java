package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Task2Server {

    public static final int DEFAULT_PORT = 12345;

    private ServerSocket serverSocket;
    // TODO: treba li ovde da ide lista klijenata?

    private class FlightInfo {
        String flightId;
        String destination;
        String departureTime;
        String landingTime;

        public FlightInfo(String line){
            String[] info = line.split(" ");
            flightId = info[0];
            destination = info[1];
            departureTime = info[2];
            landingTime = info[3];
        }

        @Override
        public String toString() {
            // todo efikasnije
            return flightId + " "+ destination + " "+ departureTime + " "+ landingTime;
        }
    }

    private static final String dirPath = "/home/ispit/Desktop/tests/aerodromi";

    private HashMap<String, ArrayList<FlightInfo>> flightInfos = new HashMap<>();

    public Task2Server(){
        loadFileInfo();
    }

    private void flushEnd(PrintWriter pw){
        pw.flush();
        // TODO: izdvojiti u neku static final prom
        pw.println("kraj");
        pw.flush();
    }

    private void exitWithMsg(String msg){
        System.err.println(msg);
        System.exit(1);// koji god da je
    }

    public void execute(){
        BufferedReader br = null;
        PrintWriter pw = null;
        try{
            serverSocket = new ServerSocket(DEFAULT_PORT);

            while(true){
                Socket client = serverSocket.accept();
                pw = new PrintWriter(client.getOutputStream());
                PrintWriter finalPw = pw;
                flightInfos.keySet().forEach(finalPw::println);
                flushEnd(pw);

                br = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String city = br.readLine();
                PrintWriter finalPw1 = pw;
                if(flightInfos.keySet().contains(city)){
                    flightInfos.get(city).forEach(info->{
                        finalPw1.println(info.toString());
                    });
                    flushEnd(pw);
                }
                else{
                    System.err.println("Klijent nije lepo uneo grad");
                    pw.println("Nije dobro unet grad! Pokusajte ponovo");
                    flushEnd(pw);
                }

                pw.close();
                br.close();
            }

        } catch(Exception e){
            System.err.println("Doslo je do greske: "+ e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try{
                if (pw != null) {
                    pw.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    // prva tacka
    private void loadFileInfo(){
        try{
            File f = new File(dirPath);
            if(!f.exists()){
                exitWithMsg("Proverite putanju do direktorijuma : '"+dirPath+"'");
            }
            if(!f.isDirectory()){
                exitWithMsg("Proslednjena putanja nije direktorijum, proverite putanju: '"+dirPath+"'");
            }
            Arrays.stream(f.listFiles()).forEach(airport->{
                if(airport.isFile()){
                    String airportName = airport.getName().substring(0, airport.getName().lastIndexOf('.'));

                    try(Scanner sc = new Scanner(airport)){
                        ArrayList<FlightInfo> info = new ArrayList<>();
                        while(sc.hasNextLine()){
                            info.add(new FlightInfo(sc.nextLine()));
                        }
                        flightInfos.put(airportName, info);
                    } catch (Exception e){
                        System.err.println("Doslo do greske prilikom citanja za aerodrom: "+airportName);
                    }
                }
            });
        } catch(Exception e){
            System.err.println("Doslo je do greske: "+e.getMessage());
        }
    }

    public static void main(String[] args) {
        Task2Server server = new Task2Server();
        server.execute();
    }
}

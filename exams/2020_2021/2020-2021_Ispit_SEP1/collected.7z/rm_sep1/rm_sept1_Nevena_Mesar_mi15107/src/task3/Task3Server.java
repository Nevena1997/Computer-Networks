package task3;

import java.util.Random;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class Task3Server {

    private Integer hiddenNumber;


    private void genHiddenNum(){
        Random r = new Random();
        r.setSeed(0);
        // maybe
        IntStream i = r.ints(9999, 100000);
        // vraca radnom ali je infinite, tako da mozda neko drugo resenje
//        i.forEach(num->{
//            for(int k = 2; k<num / 2; k++) {
//                if (num % k == 0) {
//                    return;
//                }
//            }
//            System.out.println(num);
//        });
//        IntStream simpleI = i.takeWhile(new IntPredicate() {
//            @Override
//            public boolean test(int value) {
//                for(int i = 2; i<value/2; i++){
//                    if(value % i == 0){
//                        return false;
//                    }
//                }
//                System.out.println(value);
//                return true;
//            }
//        });
    }

    public Task3Server(){
        genHiddenNum();
    }

    public static void main(String[] args) {
        Task3Server s = new Task3Server();
    }
}

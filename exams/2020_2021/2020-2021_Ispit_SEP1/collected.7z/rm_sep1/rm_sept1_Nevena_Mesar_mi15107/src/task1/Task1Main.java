package task1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Task1Main {

    private static final String fileNameOutput = "timestamps.txt";
    private static final int BUFF_SIZE = 256;

    // INFO: nije postavljen encoding za output

    public static void main(String[] args) {
        BufferedReader in = null;
        FileOutputStream out = null;
        String fileName = null; // "fileToCopy.txt"; // TEST
        System.out.println("Uneti fajl odakle se kopira");
        try(Scanner sc = new Scanner(System.in)){
            if(sc.hasNextLine()){
                fileName = sc.nextLine();
            }
        } catch(Exception e){
            System.err.println("Doslo je do greske prilikom ucitavanja naziva fajla: "+ e.getMessage());
            e.printStackTrace();
        }
        try{
            URL fileIn = new URL("file:"+fileName);
//            URL fileOutUri = new URL("file:"+fileNameOutput);
//            File fileOut = Paths.get(fileOutUri.toURI()).toFile();
            out = new FileOutputStream(fileNameOutput);
            in = new BufferedReader(new InputStreamReader(fileIn.openStream(), StandardCharsets.UTF_8));
//            out = new BufferedWriter(new OutputStreamWriter(connOut.getOutputStream(), StandardCharsets.UTF_8));
            char[] buffer = new char[BUFF_SIZE];

            while((in.read(buffer)) != -1){
                // TODO: mora da moze ovde da se uradi nesto pametije
                // TODO: resiti problem kada se uhvati datum "na pola puta"
                out.write(Arrays.stream(String.copyValueOf(buffer).split(" ")).filter(l->{
                    try{
                        // OLD ovo ce vratiti i slucajeve kad se stavi veci mesec, samo ce ispomerati datum da bude tacan tako da ipak ne..
//                        new SimpleDateFormat("dd-MM-yyyy").parse(l);
                        // ovo je iskljucivo ako se gleda da bas mora da ima leading nule
                        if(!l.matches("[0-9][0-9]-[0-9][0-9]-2[0-9][0-9][0-9]")){
                            return false;
                        }
                        String[] parts = l.split("-");
                        return Integer.parseInt(parts[0])<32 && Integer.parseInt(parts[0])>0
                                && Integer.parseInt(parts[1])<13 &&Integer.parseInt(parts[1])>0
                                && Integer.parseInt(parts[2])>=2000;
                    }catch(Exception e){
                        return false;
                    }
                }).collect(Collectors.joining("\n")).getBytes());
            }
        } catch(MalformedURLException e) {
            System.err.println("Nepoznat protokol." + e.getMessage());
        } catch(FileNotFoundException e) {
            System.err.println("Proverite putanju do fajla." + e.getMessage());
        } catch (IOException e){
            System.err.println("Greska prilikom obrade fajlova."+ e.getMessage());
        } catch (Exception e){
            System.err.println("Doslo je do greske: "+e.getMessage());
        } finally {
            try{
                in.close();
            } catch (Exception e){
                e.printStackTrace();
            }
            try{
                out.close();
            } catch (Exception e){
                e.printStackTrace();
            }
        }



    }
}
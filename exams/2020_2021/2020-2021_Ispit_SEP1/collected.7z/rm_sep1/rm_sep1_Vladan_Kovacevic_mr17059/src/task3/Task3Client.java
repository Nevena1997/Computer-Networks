package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {

        SocketAddress address = new InetSocketAddress("localhost", Task3Server.SERVER_PORT);

        try (SocketChannel clientChannel = SocketChannel.open(address)) {
            clientChannel.configureBlocking(true);

            System.out.println("Uneti 4 bajta jedan za drugim: ");
            Scanner sc = new Scanner(System.in);
            ByteBuffer bb = ByteBuffer.allocate(4);
            System.err.println("Sending bytes...");
            for(int i=0; i<4; i++) {
                byte b = sc.nextByte();
                bb.put(b);
                bb.flip();
                clientChannel.write(bb);
                bb.clear();
            }

            bb.clear();
            clientChannel.read(bb);
            bb.flip();

            System.out.println(bb.getInt());


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

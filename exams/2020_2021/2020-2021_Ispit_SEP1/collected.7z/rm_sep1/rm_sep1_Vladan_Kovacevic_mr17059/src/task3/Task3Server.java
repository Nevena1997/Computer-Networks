package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Task3Server {

    public static int BOUND = 10000000;
    public static int BACKUP_PRIME = 4003;
    public static int SERVER_PORT = 12345;
    public static int SECRET_NUM;


    public static void main(String[] args) {

        SECRET_NUM = generateSecretNum();
        System.out.println("Secret number: " + SECRET_NUM);

        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();) {

            if(!serverSocketChannel.isOpen() || !selector.isOpen()) {
                System.err.println("Can't open serverSocketChannel or selector!");
                System.exit(1);
            }

            System.err.println("Server is up!");

            serverSocketChannel.bind(new InetSocketAddress(SERVER_PORT));
            serverSocketChannel.configureBlocking(false);

            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {
                selector.select();
                Iterator<SelectionKey> keyIterator = selector.selectedKeys().iterator();

                while(keyIterator.hasNext()) {
                    SelectionKey key = keyIterator.next();
                    keyIterator.remove();

                    //KOMENTAR:
                    //Ovde bi dodali jos jedan try/catch za izuzetke koje moze da baci write/read,
                    //jer ako prekinemo sa jednim klijentom ne zelimo da prekinemo rad servera
                    //Nisam stigao da implementiram da klijent vise puta pise, pa onda ovo nije ni potrebno

                    if(key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        System.err.println("Connected to " + client.getRemoteAddress());

                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer byteBuffer = ByteBuffer.allocate(4);
                        clientKey.attach(byteBuffer);

                    }

                    else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer byteBuffer = (ByteBuffer) key.attachment();

                        System.err.println("Reading from " + ((SocketChannel) key.channel()).getRemoteAddress() + "...");

                        client.read(byteBuffer);


                        if(!byteBuffer.hasRemaining()) {
                            byteBuffer.flip();
                            //client.read(byteBuffer);
                            byte[] bytes = new byte[4];
                            for(int i=0; i<4; i++) {
                                bytes[i] = byteBuffer.get();
                                //System.out.println(bytes[i]);
                            }
                            //Spremamo za pisanje
                            byteBuffer.clear();
                            System.out.println("Number to send: " + xorWithSecretNum(bytes));
                            byteBuffer.putInt(xorWithSecretNum(bytes));
                            byteBuffer.flip();
                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                            //System.out.println(byteBuffer.position() + " " + byteBuffer.limit());
                    }


                    else if(key.isWritable()) {
                        System.err.println("Writing...");
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer byteBuffer = (ByteBuffer) key.attachment();
                        client.write(byteBuffer);
                        if(!byteBuffer.hasRemaining())
                            client.close();

                    }
                }
            }


    } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int xorWithSecretNum(byte[] bytes) {
        int x = 0;
        for(int i=0; i<4; i++) {
            x |= bytes[i];
            x <<= 8;
        }

        return SECRET_NUM^x;
    }

    public static int generateSecretNum() {
        Random random = new Random(System.currentTimeMillis());
        //probacemo sa 6k-1 ili 6k+1 da generisemo prost broj, ako nije prost, prelazimo na k+1
        // k se bira random iz datih granica (k>=200, pa garantuje da je broj > 999)
        int k = random.nextInt(BOUND-200) + 200;
        //ako ne uspemo u 100 iteracija, vracamo 4003
        for(int i=k; i<k+100; k++) {
            if(isPrime(6*k-1))
                return 6*k-1;
            else if(isPrime(6*k+1))
                return 6*k+1;
        }
        return BACKUP_PRIME;
    }

    public static boolean isPrime(int num) {
        for(int i=2; i<num/2 + 1; i++) {
            if(num % i == 0)
                return false;
        }
        return true;
    }

    public static int power(int n, int m) {
        int res = 1;
        for(int i=0; i<m; i++) {
            res *= n;
        }
        return res;
    }
}

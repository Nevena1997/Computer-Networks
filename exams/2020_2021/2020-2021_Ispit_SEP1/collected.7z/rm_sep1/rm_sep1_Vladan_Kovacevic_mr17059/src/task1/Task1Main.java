package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {

    public static String outFile = "timestamps.txt";

    public static void main(String[] args) {
        System.out.println("Uneti ime fajla: ");
        Scanner sc = new Scanner(System.in);
        String file = sc.nextLine();


        try(BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8));
            BufferedWriter bw = new BufferedWriter(new FileWriter(outFile, StandardCharsets.UTF_8));)
        {
            String line;

            while((line = br.readLine()) != null) {
                if(validDate(line)) {
                    bw.write(line);
                    bw.newLine();
                    bw.flush();
                }
            }





        } catch (FileNotFoundException e) {
            System.err.println("Neuspesno otvaranje fajle " + file);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("IOException");
            e.printStackTrace();
        }

    }

    public static boolean validDate(String date) {
        if(date.length() != 10) {
            //System.out.println("False length");
            return false;
        }

        if(date.charAt(2) != '-' && date.charAt(5) != '-') {
            //System.out.println("False dash");
            return false;
        }

        //U sustini ne mora ovo, zbog try/catch za parseInt
        if(date.chars().anyMatch(c-> !Character.isDigit(c) && c!='-')) {
            //System.out.println("False chars");
            return false;
        }

        Integer day;
        Integer month;
        Integer year;
        try {
             day = Integer.parseInt(date.substring(0, 2));
             month = Integer.parseInt(date.substring(3, 5));
             year = Integer.parseInt(date.substring(6, 10));
        } catch (NumberFormatException e) {
            return false;
        }
        //System.out.println(day + " " + month + " " + year);

        if(day < 1 || day > 31 || month < 1 || month > 12 || year < 2001)
            return false;

        return true;
    }
}

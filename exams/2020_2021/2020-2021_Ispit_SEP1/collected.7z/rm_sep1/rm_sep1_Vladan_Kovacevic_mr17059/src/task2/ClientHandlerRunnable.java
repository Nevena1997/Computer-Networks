package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Map;

public class ClientHandlerRunnable implements Runnable {

    private Socket client;
    private BufferedReader br;
    private PrintWriter pw;

    ClientHandlerRunnable(Socket client) {
        this.client = client;
        try {
            br = new BufferedReader(new InputStreamReader(client.getInputStream()));
            pw = new PrintWriter(client.getOutputStream(), true);

        } catch (IOException e) {
            System.err.println("Cant open buffers...");
            e.printStackTrace();
        }
    }


    @Override
    public void run() {
        System.err.println("Sending cities to " + client.getRemoteSocketAddress() + "...");
        sendCities();
        System.err.println("Waiting for request from " + client.getRemoteSocketAddress() + "...");
        String city = getRequest();
        System.err.println("Responding to " + client.getRemoteSocketAddress());
        respond(city);
    }

    public void sendCities() {

            StringBuilder sb = new StringBuilder("");
            for(String city: Task2Server.cities) {
                sb.append(city);
                sb.append(" ");
            }
            pw.println(new String(sb));
    }

    public String getRequest() {


        String city = null;
        try {
            city = br.readLine();
            //System.out.println(city);
        } catch (IOException e) {
            System.err.println("Cant get city :(");
            e.printStackTrace();
        }
            return city;

    }


    public void respond(String city) {
        if(!Task2Server.cities.contains(city)) {
            pw.println("None");
        }
        pw.println(Task2Server.flightSchedule.get(city));
    }
}

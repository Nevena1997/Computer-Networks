package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Task2Server {

    public static int SERVER_PORT = 12345;
    public static String directoryPath = "/home/ispit/Desktop/tests/aerodromi";
    public static List<String> cities = new ArrayList<>();
    //<ime grada, informacije o letu>
    public static Map<String, String> flightSchedule = new HashMap<>();

    public static void main(String[] args) {
        initializeFlightSchedule();

        /*for(String c : cities) {
            System.out.println(c);
        }
        for(String s : flightSchedule.values())
            System.out.println(s);
        */
        try (ServerSocket serverSocket = new ServerSocket(SERVER_PORT)) {
            System.err.println("Server is up!");
            while(true) {

                Socket client = serverSocket.accept();
                System.err.println("Accepted client: " + client.getRemoteSocketAddress());

                new Thread(new ClientHandlerRunnable(client)).start();

            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    public static void initializeFlightSchedule() {
        Path path = Paths.get(directoryPath);
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(path)) {
            for(Path cityPath : ds) {
                String cityName = cityPath.getFileName().toString();
                cityName = cityName.substring(0, cityName.indexOf('.'));
                //System.out.println(cityName);
                cities.add(cityName);

                readLines(cityPath, cityName);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void readLines(Path p, String cityName) {
        StringBuilder sb = new StringBuilder("");
        try (Scanner sc = new Scanner(p)) {
            String line;
            while(sc.hasNextLine()) {
                line = sc.nextLine();
                sb.append(line);
                sb.append(" | ");
                //System.out.println(line);
            }
            flightSchedule.put(cityName, new String(sb));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

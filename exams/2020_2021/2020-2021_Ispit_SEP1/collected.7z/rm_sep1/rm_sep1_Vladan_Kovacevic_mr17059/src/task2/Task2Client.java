package task2;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", Task2Server.SERVER_PORT);
             BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));
             PrintWriter pw = new PrintWriter(client.getOutputStream(), true);) {


            System.err.println("Getting cities from server...");
            String line = br.readLine();

            for(String city : line.split(" ")) {
                System.out.println(city);
            }


            Scanner sc = new Scanner(System.in);
            String city = sc.nextLine();
            System.err.println("Requesting schedule for city: " + city);
            pw.println(city);

            System.err.println("Getting requested schedule...");
            line = br.readLine();
            System.out.println(line);

            //formatiranje ispisa...




        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

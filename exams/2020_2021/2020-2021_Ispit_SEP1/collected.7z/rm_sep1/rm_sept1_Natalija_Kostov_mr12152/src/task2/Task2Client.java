package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) throws IOException {
        try(Socket client = new Socket("localhost",Task2Server.DEFAULT_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner sc = new Scanner(System.in)){

            String line;
            String[] cities = in.readLine().split(" ");
            System.out.println("Choose one city:");
            for(String city : cities){
                System.out.println(city);
            }

            out.write(sc.nextLine());
            out.newLine();
            out.flush();

            while((line = in.readLine())!=null){
                System.out.println(line);
            }



        }
    }
}

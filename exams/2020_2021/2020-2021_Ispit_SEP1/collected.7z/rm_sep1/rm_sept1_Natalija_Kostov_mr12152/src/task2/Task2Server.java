package task2;


import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Task2Server {

    public static final int DEFAULT_PORT = 12345;
    private static Map<String,StringBuffer> flights = new HashMap<>();

    public static void main(String[] args) throws IOException {
        String pathString;
        String filename;

        try(Scanner sc = new Scanner(System.in)){

            System.out.println("Enter the pathString of dir aerodromi");
            pathString = sc.nextLine();

        }
        pathString = "/home/ispit/Desktop/tests/aerodromi";
        Path path = Paths.get(pathString);
        try {
            DirectoryStream<Path> directoryStream = Files.newDirectoryStream(path);
            Iterator<Path> iterator = directoryStream.iterator();
            while(iterator.hasNext()){
                StringBuffer flightsBuffer = new StringBuffer();
                Path file = iterator.next();
                filename = file.getFileName().toString();
                filename = filename.substring(0,filename.lastIndexOf('.'));
                try(Scanner inFlights = new Scanner(new InputStreamReader(new FileInputStream(new File(file.toString()))))){

                    while(inFlights.hasNextLine()){
                        flightsBuffer.append(inFlights.nextLine());
                        flightsBuffer.append('\n');
                    }
                    flights.put(filename,flightsBuffer);
                }
            }
        } catch (IOException e) {
            System.err.println("The path for directory isn't correct");
        }

        String city;

        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){
            while(true){
                System.out.println("Listening...");
                Socket client = server.accept();
                try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
                    Set<String> cities = flights.keySet();
                    for(String c : cities){
                        out.write(c);
                        out.write(" ");
                    }
                    out.newLine();
                    out.flush();
                    city = in.readLine();
                    out.write(flights.get(city).toString());
                    out.flush();
                }
            }

        }
    }
}

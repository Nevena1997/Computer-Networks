package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Task1Main {

    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("DD-MM-YYYY");
        try(Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter filename: ");
            String filename = sc.nextLine();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(new File(filename)), StandardCharsets.UTF_8));
                 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("timestamps.txt")),StandardCharsets.UTF_8))) {
                String line;

                while((line = in.readLine()) != null){

                    try {
                        Date date = sdf.parse(line);

                        if((date.getYear() + 1900) < 2000){
                            continue;
                        }
                        out.write(line);
                        out.newLine();
                    } catch (ParseException e) {}
                }

            } catch (FileNotFoundException e) {
                System.out.println("This file doesn't exist");
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {


    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.SERVER_PORT));
             Scanner sc = new Scanner(System.in)) {

            ByteBuffer buffer = ByteBuffer.allocate(4);

            byte[] bajtovi = new byte[4];
            int i = 0;
            while (i < 4) {
                bajtovi[i] = sc.nextByte();
                buffer.flip();
                buffer.put(bajtovi[i]);
                i++;
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

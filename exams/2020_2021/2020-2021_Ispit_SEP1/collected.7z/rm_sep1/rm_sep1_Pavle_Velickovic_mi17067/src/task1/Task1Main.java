package task1;

import java.io.*;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

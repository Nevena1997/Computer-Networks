package task2;

import java.io.*;
import java.net.*;

public class Task2Client {
    public static void main(String[] args) {
        try {
            Socket sck = new Socket("localhost", 12345);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

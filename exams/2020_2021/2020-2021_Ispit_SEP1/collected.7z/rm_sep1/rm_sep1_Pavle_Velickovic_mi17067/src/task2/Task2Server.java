package task2;

import java.io.*;
import java.net.*;

public class Task2Server {
    public static void main(String[] args) {
        try {
            ServerSocket sck = new ServerSocket(12345);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

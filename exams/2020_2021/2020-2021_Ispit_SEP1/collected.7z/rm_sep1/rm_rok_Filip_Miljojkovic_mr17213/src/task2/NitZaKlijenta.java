package task2;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class NitZaKlijenta implements Runnable {

    Socket client;
    HashMap<String,ArrayList<String>> map;

    public NitZaKlijenta(Socket client, HashMap<String, ArrayList<String>> map) {
        this.client = client;
        this.map = map;
    }


    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream())))
        {

            StringBuilder sb = new StringBuilder("");
            for(Map.Entry<String,ArrayList<String>> e : map.entrySet())
            {
                sb.append(e.getKey()+ " ");
            }
            out.write(sb.toString());
            out.newLine();
            out.flush();

            System.out.println("Uspesno poslato");
            String grad = in.readLine();

            if(map.containsKey(grad))
            {
                for(String s : map.get(grad))
                {
                    out.write(s);
                    out.newLine();
                    out.flush();
                }
            }
            else{
                out.write("Grad nije u listi");
                out.newLine();
                out.flush();
                client.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

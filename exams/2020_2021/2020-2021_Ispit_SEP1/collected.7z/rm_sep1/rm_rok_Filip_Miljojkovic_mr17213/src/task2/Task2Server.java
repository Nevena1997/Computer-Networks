package task2;

import java.awt.image.AreaAveragingScaleFilter;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Task2Server {


    public static final int broj_porta = 12345;

    public static void main(String[] args)
    {

        String dir = "/home/ispit/Desktop/tests/aerodromi";
        HashMap<String,ArrayList<String>> map = new HashMap<>();


        try(DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get(dir)))
        {
            for(Path p : ds)
            {
                Scanner sc = new Scanner(p);
                String line;
                ArrayList<String> tmp = new ArrayList<>();
                while (sc.hasNextLine())
                {
                    line = sc.nextLine();
                    tmp.add(line.trim());
                }

                map.put((p.toString().substring(36,p.toString().length()-4)),tmp);

                //System.out.println(p);
            }


            try(ServerSocket server = new ServerSocket(broj_porta))
            {
                while (true)
                {
                    Socket client = server.accept();
                    new Thread(new NitZaKlijenta(client,map)).start();
                    // Zakomplikovao sam jer sam imao probleme malo sa citanjem od strane server, nepotrebno sam pravio
                    // dodatne niti na kraju, pri kraju sam razumeo ali nisam imao dovoljno vremena da ovde prekucam sve, ali kod je skoro isti
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }



}

package task3;

import javax.swing.text.html.HTMLDocument;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;

public class Task3Server {


    public static final int broj_porta = 12345;

    public static void main(String[] args) {

        try(ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open())
        {

            if(!selector.isOpen() || !serverSocketChannel.isOpen())
            {
                System.out.println("Greska pri otvaranju");
            }

            serverSocketChannel.bind(new InetSocketAddress(broj_porta));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true)
            {
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try{                    // Da ne bi pukao server zbog jednog klijenta
                    if (key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();

                        ByteBuffer buffer = ByteBuffer.allocate(4);

                        client.configureBlocking(false);
                        SelectionKey sKey = client.register(selector, SelectionKey.OP_READ);

                        sKey.attach(buffer);

                    } else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.read(buffer);
                        if (!buffer.hasRemaining()) {

                            int broj;
                            while(buffer.hasRemaining())
                            {
                                broj = buffer.getInt();
                                // Nisam siguran tacno kako logika za ovo treba da izgleda
                                // Pokusavao sam nesto ali nije mi bas imalo smisla
                            }
                        }

                        buffer.flip();
                        key.interestOps(SelectionKey.OP_WRITE);


                    } else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();


                        client.write(buffer);
                        if (!buffer.hasRemaining()) {
                            client.close();
                        }

                    }
                }catch (IOException e)
                    {
                        System.out.println("Prekid veze sa klijentom");
                        key.channel().close();
                    }

                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

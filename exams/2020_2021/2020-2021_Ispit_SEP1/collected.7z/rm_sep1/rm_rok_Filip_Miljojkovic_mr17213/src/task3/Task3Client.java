package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args)
    {

        SocketAddress address = new InetSocketAddress("localhost",Task3Server.broj_porta);
        try(SocketChannel client = SocketChannel.open(address);
            Scanner sc = new Scanner(System.in))
        {

            ByteBuffer buffer = ByteBuffer.allocate(4);
            System.out.println("Unesite 4 bajta:");
            for(int i=0;i<4;i++)
            {
                byte b = sc.nextByte();
                buffer.put(b);
            }

            // [a b c d]
            //        p,l

            buffer.rewind();
            client.write(buffer);

            buffer.flip();
            client.read(buffer);
            buffer.flip();

            int broj = buffer.getInt();
            System.out.println(broj);


            //p, l , c
            // flip, rewind, clear





        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

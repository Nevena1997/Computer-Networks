package task1;

import java.io.*;
import java.nio.Buffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Task1Main {



    public static void main(String[] args){

        System.out.println("Unesite dir:");
        Scanner sc = new Scanner(System.in);
        String dir = sc.nextLine();

        // ulaz = /home/ispit/Desktop/rm_rok_Filip_Miljojkovic_mr17213/src/test.txt


        //Scanner sc = new Scanner(Paths.get("/home/ispit/Desktop/rm_rok_Filip_Miljojkovic_mr17213/src/task1/test.txt"));

        try(BufferedReader in = new BufferedReader(new InputStreamReader(Files.newInputStream(Paths.get(dir))));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(Paths.get("timestamps.txt"))))) {
            // while(sc.hasNextLine())
            String linija;
            while ((linija = in.readLine()) != null) {
                //String linija = sc.nextLine();
                if (isValidDate(linija)) {
                    out.write(linija);
                    out.newLine();
                    out.flush();
                } else
                    continue;

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static boolean isValidDate(String linija) {

        String[] reci= linija.split("-");

        if (reci.length != 3)
        {
            return false;
        }

        if(Integer.parseInt(reci[0]) <= 0 || Integer.parseInt(reci[0])>31 ||Integer.parseInt(reci[1])<=0 ||Integer.parseInt(reci[1]) > 12 || Integer.parseInt(reci[2]) <2000)
            return false;

        return true;
    }
}

package task1;

import java.io.*;
import java.util.Scanner;

public class Task1Main {

    private final static String FAJL = "timestamps.txt";
    private final static int BUFF = 256;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fileName = sc.nextLine().trim();
        System.out.println(fileName);

        try(Scanner in = new Scanner(new FileInputStream(fileName));
            PrintWriter out = new PrintWriter(new FileOutputStream(FAJL))
        ) {

            while(in.hasNextLine()) {
                String datum1 = in.nextLine();
                String datum = in.findInLine("%d%d-%d%d-%d%d%d%d");
                String[] datumDelovi = datum.split("-");
                if ((0 < Integer.getInteger(datumDelovi[0])) && (Integer.getInteger(datumDelovi[0]) < 31)
                        && (0 < Integer.getInteger(datumDelovi[1])) && (Integer.getInteger(datumDelovi[1]) < 12)
                        && (Integer.getInteger(datumDelovi[2]) > 2000)) {
                    out.println(datum);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Greska kod otvaranja fajlova. "+e.getMessage());
            //e.printStackTrace();
        }
        sc.close();
    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.Files;

import java.nio.file.Paths;

public class Task2Server {

    public static final int PORT = 12345;

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(PORT)){

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

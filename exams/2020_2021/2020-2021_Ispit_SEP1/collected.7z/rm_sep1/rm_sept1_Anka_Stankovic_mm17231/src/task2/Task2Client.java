package task2;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Task2Client {


    public static void main(String[] args) {

        try(Socket klijent = new Socket("lockalhost", Task2Server.PORT)){

        } catch (UnknownHostException e) {
            System.out.println("Nepoznat host "+e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package DRUGI;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;

import static java.lang.String.*;

public class SERVER {
    public static int port = 12345;
    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(port)) {

            Letovi[] let;
            String line;
            BufferedInputStream in = new BufferedInputStream(new FileInputStream("aerodromi"));

            while(true){
                in.read();
                if (!(line = true)) break;

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

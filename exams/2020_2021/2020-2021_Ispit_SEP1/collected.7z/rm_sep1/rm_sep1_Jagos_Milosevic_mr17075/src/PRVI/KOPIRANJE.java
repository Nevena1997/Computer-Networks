package PRVI;

import java.io.*;
import java.nio.file.Paths;
import java.util.Scanner;

public class KOPIRANJE {
    public static void main(String[] args) {

        try (Scanner skener = new Scanner(System.in)) {

            System.out.println("Unesi ime fajla: ");
            String name = skener.nextLine();
            String line;

            BufferedInputStream inf = new BufferedInputStream(new FileInputStream(name));
            BufferedOutputStream outf = new BufferedOutputStream(new FileOutputStream("timestamps.txt"));

            while((line = inf.toString()) != null){

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

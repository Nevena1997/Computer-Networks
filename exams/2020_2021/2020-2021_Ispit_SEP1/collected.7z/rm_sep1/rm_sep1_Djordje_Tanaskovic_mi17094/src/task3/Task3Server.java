package task3;

public class Task3Server {
    public final static int PORT = 12345;



    public static void main(String[] args) {


    }

}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", Task2Server.PORT)){
            BufferedReader bIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter pw = new PrintWriter(socket.getOutputStream());

            String res = bIn.readLine();
            if(res == null) {
                System.err.println("Connection closed.");
                socket.close();
            }
            System.out.println(res);


            Scanner sc = new Scanner(System.in);
            String opt = sc.next();

            pw.println(opt);
            pw.flush();

            String resLines = bIn.readLine();
            System.out.println(resLines);
            // socket.close();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

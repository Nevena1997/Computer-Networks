package task2;

public class AirlineInfo {
    public String id;
    public String destination;
    public String startTime;
    public String endTime;

    public AirlineInfo(String id, String destination, String startTime, String endTime) {
        this.id = id;
        this.destination = destination;
        this.startTime = startTime;
        this.endTime = endTime;
    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ServerThread extends Thread {
    public static Set<String> cities;
    public static ConcurrentHashMap<String, String> airLines;


    private Socket socket;
    private BufferedReader bIn;
    private PrintWriter pw;

    public ServerThread(Socket socket) {
        this.socket = socket;
        try {
            this.bIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.pw = new PrintWriter(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        for(String c : cities)
            pw.print(c + ' ');
        pw.print("\r\n");
        pw.flush();

        try {
            String req = bIn.readLine().strip();

            if(req == null || !airLines.containsKey(req)) {
                System.err.println("Error");
                socket.close();
                return;
            }

            synchronized (airLines) {
                pw.print(airLines.get(req));
                pw.print("\r\n");
                pw.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

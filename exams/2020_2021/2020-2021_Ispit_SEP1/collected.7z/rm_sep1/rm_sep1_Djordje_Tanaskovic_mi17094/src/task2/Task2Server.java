package task2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class Task2Server {
    public final static String testDirPath = "tests/aerodromi";
    public final static int PORT = 12345;
    public static void main(String[] args) {
        File dir = new File(testDirPath);

        ServerThread.cities = Collections.synchronizedSet(new HashSet<String>());
        for (String file : dir.list()) {
            String city = file.split("\\.")[0].strip();
            ServerThread.cities.add(city);

            try (Scanner sc = new Scanner(new File(dir, file))){
                //Scanner sc = new Scanner(new File(dir, file));
                StringBuilder sb = new StringBuilder();
                ServerThread.airLines = new ConcurrentHashMap<String, String>();
                while (sc.hasNextLine()) {
                    sb.append(sc.nextLine() + ' ');
                }
                //System.out.println(sb.toString());
                ServerThread.airLines.put(city, sb.toString());
                System.out.println(city + "-" + ServerThread.airLines.get(city));
                // sc.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        while (true) {
            try (ServerSocket socket = new ServerSocket(PORT)) {
                //Socket client = socket.accept();
                ServerThread thread = new ServerThread(socket.accept());
                thread.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

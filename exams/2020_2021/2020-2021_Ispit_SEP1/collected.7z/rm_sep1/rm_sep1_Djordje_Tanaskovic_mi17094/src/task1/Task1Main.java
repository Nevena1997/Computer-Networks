package task1;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Task1Main {
    public final static String FILEPATH = "timestamps.txt";

    public static void main(String[] args) {
        BufferedReader bReader = null;
        BufferedWriter bf = null;

        String inFilep = new Scanner(System.in).next();

        try {
            bReader = Files.newBufferedReader(Paths.get(inFilep), StandardCharsets.UTF_8);
            //bReader = new BufferedReader(new InputStreamReader(new FileInputStream(inFilep)));
            bf = Files.newBufferedWriter(Paths.get(FILEPATH), StandardCharsets.UTF_8);
            // bf = new BufferedOutputStream(new FileOutputStream(FILEPATH));

            String line = bReader.readLine();
            while (line != null) {
                for(String date : line.split(" ")) {
                    if(date.strip().matches("[0-3][0-9]-[0-1][0-9]-2[0-9][0-9][0-9]")) {
                        bf.write(date + "\r\n");
                    }
                }
                line = bReader.readLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bReader.close();
                bf.close();
            } catch (IOException | NullPointerException e) {
                e.printStackTrace();
            }
        }


    }
}

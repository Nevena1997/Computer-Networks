package task1;

import java.io.*;
import java.sql.Date;
import java.text.DateFormat;

public class Task1Main {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt")))){

            while (true) {
                String line = reader.readLine();
                if (line == null) break;
                if (!line.matches("[0-3][0-9]-[0-1][0-9]-[2-9][0-9][0-9][0-9]")) continue;
                try {
                    //if (line.substring(0, line.indexOf("-"))) {

                    //}
                    //DateFormat dateFormat = DateFormat.getDateInstance(line.codePointCount(0, 8));
                    Date date = new Date(line.codePointCount(0, 9));
                    //writer.write(String.valueOf(dateFormat));
                    writer.write(line);
                    writer.newLine();
                    writer.flush();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Hello world!");
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Task3Server {
    public static void main(String[] args) {


        int[] combination = new int[4 * 4];
        //byte[] buffer = new byte[4 * 4];
        Random random = new Random();
        int num = 0;
        int i = 0;
        while (i < 1) {
            num = random.nextInt() + 1000;
            if (num < 999) {
                System.out.println("Nije manji od 999");
                continue;
            }
            for (int j = 1; j < 1000; j++) {
                if (num % j == 0) {
                    System.out.println("nije prost");
                    continue;
                }
            }

            combination[i] = num;
            i++;
        }
        //for (int num : combination) {
        System.out.println("Skriveni broj: " + num);
        //}






        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            server.bind(new InetSocketAddress(12345));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()) {
                        ServerSocketChannel s = (ServerSocketChannel) key.channel();
                        SocketChannel client = s.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buffer = ByteBuffer.allocate(4*4);
                        clientKey.attach(buffer);
                    } else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.write(buffer);
                        if (!buffer.hasRemaining()) {
                            client.close();
                            System.out.println("Zavrseno");
                        }
                    } else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.read(buffer);
                        if (!buffer.hasRemaining()) {
                            buffer.flip();
                            int num1 = buffer.getInt();
                            while (buffer.hasRemaining()) {
                                List<Integer> list = null;
                                list.add(num1);

                                buffer.clear();
                                buffer.putInt(num1);
                                buffer.clear();

                            }
                        }
                    }
                }
            }

        } catch (ClosedChannelException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

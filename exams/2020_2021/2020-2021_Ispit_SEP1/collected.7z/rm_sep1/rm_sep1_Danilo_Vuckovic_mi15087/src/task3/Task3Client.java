package task3;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (Socket client = new Socket(InetAddress.getLocalHost(), 12345);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)){

            System.out.println("Unesite 4 puta bajt duzine 4");
            while (true) {
                byte[] combination = new byte[4];
                byte[] buffer1 = new byte[4*4];
                ByteBuffer buffer = ByteBuffer.allocate(4*4);
                int i = 0;
                while (i < 4) {
                    byte num = sc.nextByte();
                    combination[i] = num;
                    i++;
                }
                for (byte num : combination) {
                    System.out.println("Num: " + num);
                }


            }
            //byte[] buffer = new byte[4*4];
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

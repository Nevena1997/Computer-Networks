package task2;

import java.io.*;
import java.net.Socket;
import java.util.List;

public class ServerThread implements Runnable {
    private Socket client;
    private File dir;
    private String fajl;

    private List<String> sifre = ServerTest.getSifra();
    private List<String> gradovi = ServerTest.getGrad();
    private List<String> poletanja = ServerTest.getVreme_poletanja();
    private List<String> sletanje = ServerTest.getVreme_sletanja();

    public ServerThread(Socket client, File dir, String fajl) {
        this.client = client;
        this.dir = dir;
        this.fajl = fajl;
        this.sletanje = ServerTest.getVreme_sletanja();
        this.sifre = ServerTest.getSifra();
        this.gradovi = ServerTest.getGrad();
        this.poletanja = ServerTest.getVreme_poletanja();
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));){
            try (BufferedReader reader1 = new BufferedReader(new InputStreamReader(new FileInputStream(this.dir.toString() + "/" + this.fajl)))){

                fja(reader, writer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void fja(BufferedReader reader, BufferedWriter writer) {
        this.gradovi.forEach(grad->{
            try {
                writer.write(grad);
                writer.newLine();
                writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}

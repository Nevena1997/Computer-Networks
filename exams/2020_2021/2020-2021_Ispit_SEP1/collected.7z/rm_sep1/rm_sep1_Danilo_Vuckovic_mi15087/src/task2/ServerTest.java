package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class ServerTest {
    private final static List<String> sifra = new LinkedList<>();
    private final static List<String> grad = new LinkedList<>();
    private final static List<String> vreme_poletanja = new LinkedList<>();
    private final static List<String> vreme_sletanja = new LinkedList<>();

    private final static List<Socket> listClients = Collections.synchronizedList(new LinkedList<>());
    private final static List<String> nameClients = new LinkedList<>();

    public static List<String> getSifra() {
        return sifra;
    }

    public static List<String> getGrad() {
        return grad;
    }

    public static List<String> getVreme_poletanja() {
        return vreme_poletanja;
    }

    public static List<String> getVreme_sletanja() {
        return vreme_sletanja;
    }

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(12345);){
            readFile();
            while (true) {

                Socket client = server.accept();
                getData(client);
                File dir = new File("/home/ispit/Desktop/tests/aerodromi/");
                String[] fajlovi = dir.list();

                for (String f: fajlovi)
                    new Thread(new ServerThread(client, dir, f)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void getData(Socket client) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()))){
            String line = reader.readLine();
            nameClients.add(line);
        }
    }

    private static void readFile() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/aerodromi/Amsterdam.txt")))){
            String line;

            while ((line = reader.readLine()) != null) {
                String[] nesto = line.split(" ");
                String sifra2 = nesto[0];
                String grad2 = nesto[1];
                String poletanje2 = nesto[2];
                String sletanje2 = nesto[3];
                insertInList(sifra2, grad2, poletanje2, sletanje2);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void insertInList(String sifra1, String grad1, String poletanje, String sletanje) {
        sifra.add(sifra1);
        grad.add(grad1);
        vreme_poletanja.add(poletanje);
        vreme_sletanja.add(sletanje);
    }
}

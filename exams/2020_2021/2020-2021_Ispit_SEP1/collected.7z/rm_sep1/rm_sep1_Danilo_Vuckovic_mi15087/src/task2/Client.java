package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

public class Client {


    public static void main(String[] args) {
        try (Socket client = new Socket(InetAddress.getLocalHost(), 12345);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)){

            System.out.println("napravljen soket");
            while (true) {
                System.out.println("unesite grad koji zelite");
                String ime_grada = sc.nextLine();

                for (String l: ServerTest.getGrad()) {
                    System.out.println("gradovi: " + l);
                }
                writer.write(ime_grada);
                writer.newLine();
                writer.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

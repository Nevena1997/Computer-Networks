package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    private static final String host = "localhost";
    private static final int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner sc = new Scanner(System.in);

        try (Socket socket = new Socket(host, PORT)) {

            Scanner in = new Scanner(
                    new BufferedReader(
                            new InputStreamReader(socket.getInputStream())
                    )
            );

            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            socket.getOutputStream()
                    )
            );

            String citiesAll = in.nextLine();
            System.out.println("Ponudjeni gradovi su: " + citiesAll);
            System.out.println("A koji ti zelis? ");

            String interestingCIty = sc.next();
            out.write(interestingCIty);
            out.newLine();
            out.flush();

            while (in.hasNextLine()) {
                System.out.println(in.nextLine());
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

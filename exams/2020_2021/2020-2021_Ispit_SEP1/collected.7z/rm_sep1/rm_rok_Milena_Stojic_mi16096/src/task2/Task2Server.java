package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

import static java.nio.file.Files.list;

public class Task2Server {
    private static final String BASE_PATH = "/home/ispit/Desktop/tests/aerodromi";

    private static class Flight {
        private String id;
        private String destination;
        private String timeOfArrival;
        private String timeOfLanding;

        public Flight(String id_, String destination_, String timeOfArrival_, String timeOfLanding_) {
            this.id = id_;
            this.destination = destination_;
            this.timeOfArrival = timeOfArrival_;
            this.timeOfLanding = timeOfLanding_;
        }

        public String getId() {
            return id;
        }

        public String getDestination() {
            return destination;
        }

        public String getTimeOfArrival() {
            return timeOfArrival;
        }

        public String getTimeOfLanding() {
            return timeOfLanding;
        }
    }

    public static final int PORT = 12345;
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Map<String, List<Flight>> airportData = new TreeMap<>();
        try {
            cacheAirportData(airportData);
            Set<String> cities = airportData.keySet();
/*
            for (Iterator<String> it = cities.iterator(); it.hasNext(); ) {
                System.out.println(it.next());
            }*/

            try (ServerSocket server = new ServerSocket(PORT)) {
                while(true) {

                    try {
                        Socket client = server.accept();

                        Scanner in = new Scanner(
                                new BufferedReader(
                                        new InputStreamReader(
                                                client.getInputStream()
                                        )
                                )
                        );

                        BufferedWriter out = new BufferedWriter(
                                new OutputStreamWriter(
                                        client.getOutputStream()
                                )
                        );
                        String citiesAll = "";

                        for (Iterator<String> it = cities.iterator(); it.hasNext(); ) {
                            citiesAll = citiesAll + " " + it.next();
                        }
                        System.out.println(citiesAll);

                        out.write(citiesAll);
                        out.newLine();
                        out.flush();
                        String interestingCity = in.next();
                        //System.out.println(interestingCity);

                        List<Flight> flights = airportData.get(interestingCity);


                        for (Iterator<Flight> it = flights.iterator(); it.hasNext();) {
                            Flight fly = it.next();
                            String flightLine = fly.getId() + " " + fly.getDestination() + " " + fly.getTimeOfArrival() + " " + fly.getTimeOfLanding();

                            out.write(flightLine);
                            out.newLine();
                            out.flush();
                        }

                        out.write("Have a nice trip! :)");
                        out.newLine();
                        out.flush();

                    } catch (Exception e) {
                        System.err.println("Neuspela konekcija");
                    }



                }



            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void cacheAirportData(Map<String, List<Flight>> airportData) throws IOException {
        Path dir = Paths.get("/home/ispit/Desktop/tests/aerodromi");
        Stream<Path> files = Files.list(dir);
/*
        files
                .map(p -> p.getFileName().toString())
                .map(s -> s.substring(0, s.lastIndexOf('.')))
                .forEach(System.out::println);*/

         files
                 .forEach(p -> readData(airportData, p));
    }

    private static void readData(Map<String, List<Flight>> airportData, Path p)  {
        try (Scanner sc = new Scanner(p)) {

            String fileName = p.getFileName().toString();
            String cityName = fileName.substring(0, fileName.lastIndexOf('.'));
            List<Flight> flights = new ArrayList<>();
            //System.out.println(cityName + ":");

            while (sc.hasNextLine()) {
                String line = sc.nextLine();

                String id = line.substring(0, line.indexOf(' '));
                line = line.substring(line.indexOf(' ') + 1);

                String destination = line.substring(0, line.indexOf(' '));
                line = line.substring(line.indexOf(' ') + 1);

                String timeOfArrival = line.substring(0, line.indexOf(' '));
                line = line.substring(line.indexOf(' ') + 1);

                String timeOfLanding = line;

                //System.out.println("     " + id + "*" + destination + "*" + timeOfArrival + "*" + timeOfLanding);

                flights.add(new Flight(id, destination, timeOfArrival, timeOfLanding));
            }

            airportData.put(cityName, flights);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

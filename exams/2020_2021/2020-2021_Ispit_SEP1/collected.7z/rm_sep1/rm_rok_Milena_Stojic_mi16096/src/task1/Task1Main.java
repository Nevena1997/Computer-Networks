package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        try (Scanner in =
                new Scanner(
                     new BufferedReader(
                             new InputStreamReader(System.in, StandardCharsets.UTF_8)
                     ));
             BufferedWriter out =
                     new BufferedWriter(
                             new OutputStreamWriter(
                                     new FileOutputStream("timestamps.txt"), StandardCharsets.UTF_8
                             )
                     )) {

            while (in.hasNext()) {
                String newDate = in.next();

                if (isValidDate(newDate)) {
                    out.write(newDate);
                    out.newLine();
                    out.flush();
                }
                /*else {
                    System.err.println("Incorrect");
                }*/
            }


        } catch (FileNotFoundException e) {
            System.err.println("Fajl ne postoji na datoj putanji!");
            System.err.println(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Greska pri I/O operacijama!");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }


    }

    private static boolean isValidDate(String newDate) {
        if (newDate.length() != 10)
            return false;

        try {
            if (newDate.charAt(2) != '-' || newDate.charAt(5) != '-')
                return false;

            int day = Integer.parseInt(newDate.substring(0, 2));

            if (day < 1 || day > 31)
                return false;

            int month = Integer.parseInt(newDate.substring(3, 5));

            if (month < 1 || month > 12)
                return false;

            int year = Integer.parseInt(newDate.substring(6));

            return year > 2000;
        } catch(NumberFormatException  e) {
            return false;
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Task3Server {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        try {
            ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.bind(new InetSocketAddress(12345));
            serverSocketChannel.configureBlocking(false);

            Random rd = new Random();
            int[] skriveniBrojevi = {1031, 1013, 1021};

            Selector selector = Selector.open();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();

                for (Iterator<SelectionKey> it = keys.iterator(); it.hasNext(); ) {
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()) // znaci server treba da prihvati
                    {
                        SocketChannel client = serverSocketChannel.accept();

                        client.configureBlocking(false);
                        SelectionKey cKey = client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buff = ByteBuffer.allocate(4);

                        cKey.attach(buff);
                    } else if (key.isReadable()) {
                        try {
                        ByteBuffer buff = (ByteBuffer) key.attachment();


                        SocketChannel client = (SocketChannel) key.channel();

                        buff.clear();
                        client.read(buff);

                        int ind = rd.nextInt(3);
                        int hiddenNumber = skriveniBrojevi[ind];
                        byte[] bytes = buff.array();
                            System.out.println(Arrays.toString(bytes));
                        int bytesFromBuf = ((int) bytes[3]) | ((int)bytes[2] << 8) | ((int)bytes[1] << 16) | ((int)bytes[0] << 24);

                        System.out.println(bytesFromBuf);

                        System.out.println("Skriveni broj je " + hiddenNumber);

                        int forWrite = bytesFromBuf ^ hiddenNumber;
                        System.out.println("A saljemo " + Arrays.toString(ByteBuffer.allocate(4).putInt(forWrite).array()));
                            System.out.println(forWrite);

                        buff.clear();
                        buff.putInt(forWrite);
                        buff.flip();

                        client.write(buff);
                    }
                        catch (Exception e) {
                            e.printStackTrace();
                            key.cancel();
                        }

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        try {
            Scanner sc = new Scanner(System.in);
            SocketChannel channel = SocketChannel.open(new InetSocketAddress("localhost", 12345));
            // channel.configureBlocking(false);  BLOKIRAMO

            ByteBuffer buff = ByteBuffer.allocate(4);

            while (true) {
                int bajtovi = sc.nextInt();


                buff.clear();
                buff.putInt(bajtovi);
                buff.flip();
                buff.clear();

                channel.write(buff);
                buff.clear();
                channel.read(buff);
                buff.flip();

                byte[] readBytes = buff.array();
                System.out.println(Arrays.toString(readBytes));
                int readBytesInt = ((int) readBytes[3]) | ((int)readBytes[2] << 8) | ((int)readBytes[1] << 16) | ((int)readBytes[0] << 24);

                System.out.println("Dobili smo od servera " + readBytesInt + "\nHocemo li dalje?");
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

public class Task3Client {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}

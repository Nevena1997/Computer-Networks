package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");

        try (
                Scanner sc = new Scanner(System.in);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), StandardCharsets.UTF_8));
        ){

            System.out.println("Unesite naziv fajla: ");
            String fajl = sc.nextLine();
            String linija = "";

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fajl), StandardCharsets.UTF_8))){

                while((linija = reader.readLine()) != null) {

                    if(validna(linija)) {

                        writer.write(linija, 0, linija.length());
                        writer.newLine();
                        writer.flush();
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean validna(String linija) {

        String[] podaci = linija.split("-");
        if(podaci.length != 3)
            return false;

        if((podaci[0].length() != 2) || (podaci[1].length() != 2) || (podaci[2].length() != 4))
            return false;

        int dan = Integer.parseInt(podaci[0]);
        int mesec = Integer.parseInt(podaci[1]);
        int godina = Integer.parseInt(podaci[2]);

        if(dan < 1 || dan > 31)
            return false;

        if(mesec < 1 || mesec > 12)
            return false;

        if(godina < 2000)
            return false;

        return true;
    }
}

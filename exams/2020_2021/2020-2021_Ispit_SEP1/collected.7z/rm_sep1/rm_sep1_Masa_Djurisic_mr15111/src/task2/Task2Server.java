package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Task2Server {

    public static final int port = 12345;
    public static Map<String, String> mapa = new HashMap<>();


    public static void main(String[] args) throws IOException {
        DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/aerodromi"));

        for(Path p : ds) {
            String ime = p.getFileName().toString().substring(0, p.getFileName().toString().indexOf('.'));

            try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))) {
                StringBuffer sadrzaj = new StringBuffer();
                String linija;

                while((linija = in.readLine()) != null) {
                    sadrzaj.append(linija + "\r\n");
                }
                mapa.put(ime, sadrzaj.toString());
            }

        }

        try (ServerSocket server = new ServerSocket(port)) {

            Socket client = server.accept();

            try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

                for(String key : mapa.keySet()) {
                    out.write(key);
                    out.newLine();
                    out.flush();
                }

                out.write("kraj");
                out.newLine();
                out.flush();

                String grad = in.readLine();

                boolean postoji = mapa.containsKey(grad);

                if(postoji) {
                    out.write(mapa.get(grad));
                    out.write("kraj");
                    out.newLine();
                    out.flush();
                } else {
                    out.write("Nemamo informacije o gradu koji ste nam poslali!");
                    out.newLine();
                    out.flush();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", Task2Server.port);
             Scanner sc = new Scanner(System.in);
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){

            String line;
            while(!(line = in.readLine()).equalsIgnoreCase("kraj")) {
                System.out.println(line);
            }

            System.out.println("Unesite ime grada koje zelite da posaljete serveru: ");
            String grad = sc.next();

            //client salje serveru ime grada i ceka povratne informacije koje zatim ispisuje
            out.write(grad);
            out.newLine();
            out.flush();

            while(!(line = in.readLine()).equalsIgnoreCase("kraj")) {
                System.out.println(line);
            }


        } catch (IOException  e) {
            e.printStackTrace();
        }
    }
}

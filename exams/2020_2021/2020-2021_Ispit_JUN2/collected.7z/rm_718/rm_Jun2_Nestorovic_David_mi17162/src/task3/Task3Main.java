package task3;

public class Task3Main {

    public static void main(String[] args) {
        System.out.println("Hello from Task3Main");
    }

}

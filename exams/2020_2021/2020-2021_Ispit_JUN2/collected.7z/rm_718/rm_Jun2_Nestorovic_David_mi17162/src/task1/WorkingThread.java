package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class WorkingThread implements Runnable {

    private ArrayBlockingQueue<Path> jobs;


    WorkingThread(ArrayBlockingQueue<Path> jobs){
        this.jobs = jobs;
    }


    @Override
    public void run() {

            try {

                boolean done = false;
                while (!done) {

                    Path p = jobs.take();
                    if(p == Task1Main.END_OF_WORK){
                        done = true;
                        jobs.put(p);
                    }
                    else
                        work(p);


                }


                } catch (InterruptedException e) {
                e.printStackTrace();
            }

    }

    private static void work(Path p){


        try(Scanner sc = new Scanner(p)) {

            while (sc.hasNextLine()) {

                String line = sc.nextLine();

                Scanner lineScanner = new Scanner(line);
                int n = Integer.parseInt(lineScanner.next());
                String url = lineScanner.next();

                URL u = new URL(url);


                synchronized (System.out) {

                    if (!u.getHost().contains("www")) {
                        draw_matrix(n);
                        System.out.print(ipType(u));
                    }
                    System.out.println(u.getPath() + " " + u.getProtocol());
                }

            }


        } catch (MalformedURLException e) {

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void draw_matrix(int n){

        int i, j, k = 0;
        for(i = 0; i < n; i++){
            for(j = 0; j < n; j++){
                if (j == k){
                    System.out.print(">");
                }
                else
                    System.out.print("=");
            }
            System.out.println();
            k++;
        }

    }

    private static String ipType(URL u){

        try {
            InetAddress address = InetAddress.getByName(u.getHost());

            if (address.getAddress().length == 4)
                return "(v4)";
            else if(address.getAddress().length == 16)
                return "(v6)";
            else
                return "";

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        return "";

    }


}

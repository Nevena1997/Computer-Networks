package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    public static final Path END_OF_WORK = Paths.get("");
    private static ArrayBlockingQueue<Path> jobs = new ArrayBlockingQueue<Path>(10);


    public static void main(String[] args) {

        Path homeDir = Paths.get("./../tests/urls");

        fill_jobs_queue(homeDir);



        for(int i = 0; i < jobs.size(); i++){
            new Thread(new WorkingThread(jobs)).start();
        }

    }

    private static void walk(Path dir){

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {

            for(Path p : ds){
                if(Files.isDirectory(p)){
                    walk(p);
                }
                else
                  jobs.put(p);
            }


        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }


    private static void fill_jobs_queue(Path homeDir){

        walk(homeDir);
        jobs.add(END_OF_WORK);

    }


}

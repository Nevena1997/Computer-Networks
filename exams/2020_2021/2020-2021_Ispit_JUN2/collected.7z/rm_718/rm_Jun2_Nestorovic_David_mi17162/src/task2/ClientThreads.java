package task2;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeoutException;

public class ClientThreads implements Runnable {

    private Socket socket;
    private ArrayBlockingQueue<Path> questionFiles;
    private BufferedReader in;
    private PrintWriter out;
    private String username;
    public int rezultat = 0;

    ClientThreads(Socket socket, ArrayBlockingQueue<Path> questionFiles){
        this.socket = socket;
        this.questionFiles = questionFiles;

        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter( new OutputStreamWriter(socket.getOutputStream()), true);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    @Override
    public void run() {

        try {

            this.username = in.readLine();
            send_question_types();

            read_question_type();


        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    private void send_question_types(){


        StringBuilder sb =new StringBuilder();
        for(Path p : questionFiles){
            sb.append(p.getFileName().toString());
            sb.append("/");
        }
        sb.deleteCharAt(sb.length() - 1);


        out.println(sb.toString());
        out.flush();


    }

    private void read_question_type(){

        try {

            String category = in.readLine();

            Scanner questionGetter = new Scanner(Paths.get(Task2Server.homePath + "/" + category));
            while (questionGetter.hasNextLine()){

                String[] line = questionGetter.nextLine().split("[?]");
                String question = line[0];
                System.out.println("Sending: " + question);

                out.println(question);


                socket.setSoTimeout(5000);

                try {

                    try {
                        String response = in.readLine();

                        String correct = line[1].split(" ")[1];
                        System.out.println(correct);
                        if(response.equalsIgnoreCase("Ne znam")){
                            System.out.println("Niste znali tacan odgovor");
                        }else if(!correct.equalsIgnoreCase(response)){
                            rezultat -= 1;
                            System.out.println("Niste odgovorili tacno. Gubite 1 poen");
                        }
                        else {
                            rezultat += Integer.parseInt(line[1].split(" ")[2]);
                            System.out.println("Tacan odgovor");
                        }

                    }catch (SocketTimeoutException ex){
                        System.out.println("Niste stigli da odgovorite");
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }


            }



        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}

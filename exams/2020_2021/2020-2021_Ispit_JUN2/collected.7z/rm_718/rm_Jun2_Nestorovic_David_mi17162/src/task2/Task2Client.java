package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {

        try(Socket client = new Socket("localhost", Task2Server.PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(client.getOutputStream());
            Scanner userInput = new Scanner(System.in);
        ) {

            String username = userInput.next();
            out.println(username);
            out.flush();

            String[] questionTypes = in.readLine().split("/");

            for(String type : questionTypes)
                System.out.println(type);

            System.out.println("Chose type by number: ");
            int index = userInput.nextInt();

            out.println(questionTypes[index]);
            out.flush();

            boolean allQuestionsAsked = false;
            while (!allQuestionsAsked){

                String question = in.readLine();
                if (question.equalsIgnoreCase("end"))
                    allQuestionsAsked =true;
                else{
                    System.out.println(question);

                    client.setSoTimeout(5000);

                    String odgovor = userInput.next();
                    out.println(odgovor);
                }


            }



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

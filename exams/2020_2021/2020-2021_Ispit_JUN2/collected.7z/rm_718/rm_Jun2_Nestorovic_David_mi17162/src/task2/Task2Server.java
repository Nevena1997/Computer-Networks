package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ArrayBlockingQueue;

public class Task2Server {

    public static final int PORT = 12321;
    private static ArrayBlockingQueue<Path> questionFiles = new ArrayBlockingQueue<Path>(100);
    public static String homePath;


    public static void main(String[] args) {




        try(ServerSocket server = new ServerSocket(PORT);
            Scanner sc = new Scanner(System.in);
        ) {


            String path = sc.nextLine();
            homePath = path;
            fill_queue(Paths.get(path));

            while (true){

                System.out.println("Waiting for new client...");
                Socket client = server.accept();
                new Thread(new ClientThreads(client, questionFiles)).start();

            }




        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void walk(Path dir){

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {

            for(Path p : ds){
                if(Files.isDirectory(p)){
                    walk(p);
                }
                else
                    questionFiles.put(p);
            }


        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }


    private static void fill_queue(Path homeDir){
        walk(homeDir);
    }

}

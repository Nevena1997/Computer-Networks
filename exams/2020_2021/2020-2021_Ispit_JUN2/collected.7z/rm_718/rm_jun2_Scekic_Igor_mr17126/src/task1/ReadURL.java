package task1;

import java.net.MalformedURLException;
import java.net.URL;

public class ReadURL extends Thread {
    private String line;

    public ReadURL(String line) {
        this.line = line;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    @Override
    public void run() {
        //super.run();

            System.out.println(line);
        }

    }


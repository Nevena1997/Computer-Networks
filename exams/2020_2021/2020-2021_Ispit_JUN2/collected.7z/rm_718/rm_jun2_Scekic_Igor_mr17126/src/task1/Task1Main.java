package task1;

import java.io.*;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) {
        Path path = Paths.get("/home/ispit/Desktop/tests/urls/1.txt");
       try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path.toString())))) {

            String line = reader.readLine();
            ReadURL readURL;
            new ReadURL(line).start();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        }

    }

package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {
        System.out.println("Hello from Task2Client");

        String hostname="localhost";
        try (Socket client = new Socket(hostname, Task2Server.DEFAULT_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)){


            String username = sc.nextLine();


            out.write(username);
            out.newLine();
            out.flush();


            ArrayList<String> response=new ArrayList<>();
            String s;
            while((s=in.readLine())!=null) {
                response.add(s);
            }
            System.out.println(response);
            String select = sc.nextLine();

            out.write(select);
            out.newLine();
            out.flush();



        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.*;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

final class Task2Server {
    public static final int DEFAULT_PORT=12321;
    public static final int MAX=100;
    public static void main(String[] args) {
        System.out.println("Hello from Task2Server");
        try (ServerSocket server = new ServerSocket(DEFAULT_PORT);
             Scanner sc = new Scanner(System.in)) {
            System.err.println("Started server @ "+DEFAULT_PORT);

            Path path= Path.of(sc.nextLine());
            File file = new File(String.valueOf(path.toFile()));
            File[] niz2 = file.listFiles();
            ArrayList<String> oblast = new ArrayList<>();
/*
            for (int i=0;i<niz2.length;i++) {
                System.out.println(niz2[i].getName().split(".txt")[0]);
            }

 */
            for (int i=0;i<niz2.length;i++) {
                oblast.add(i,niz2[i].getName().split(".txt")[0]);
            }/*
            for (int i=0;i<niz2.length;i++) {
                System.out.println(oblast.get(i));
            }
*/

            while(true){

                Socket client = server.accept();
                System.err.println("Client accepted! Disposing Thread");
                new Thread(new Task2ClientRunnable(client,oblast)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.err.println("Client Disconnected");
    }

}
final class Task2ClientRunnable implements Runnable{
    private Socket client;
    private ArrayList<String> oblast;
    Task2ClientRunnable(Socket client,ArrayList oblast){
        this.client=client;
        this.oblast=oblast;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))) {
            System.out.println(oblast);
            String user = in.readLine();
            System.out.println(user);

            for(int i=0;i<oblast.size();i++) {
                out.write(oblast.get(i));
                out.newLine();
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) {

      String putanja = "/home/ispit/Desktop/tests/urls";

        Path path = Paths.get(putanja);



    }
}

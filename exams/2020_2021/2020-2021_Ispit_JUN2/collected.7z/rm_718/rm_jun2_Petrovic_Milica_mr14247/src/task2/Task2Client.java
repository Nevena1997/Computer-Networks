package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {

        System.out.println("Hello from Task2Client");

        try (Socket client = new Socket("localhost", Task2Server.PORT);
             Scanner sc = new Scanner(System.in)) {

            String ime = sc.nextLine();

            try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

                out.write(ime);
                out.newLine();
                out.flush();



            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

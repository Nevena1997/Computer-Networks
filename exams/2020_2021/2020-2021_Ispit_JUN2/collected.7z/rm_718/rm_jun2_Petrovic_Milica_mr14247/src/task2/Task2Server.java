package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task2Server {

    public static int PORT = 12321;

    public static void main(String[] args) {

        System.out.println("Hello from Task2Server");

        try (ServerSocket server = new ServerSocket(PORT);
             Scanner sc = new Scanner(System.in)) {

            String putanjaStr = sc.nextLine();
            Path putanja = Paths.get(putanjaStr);



            while(true){

                Socket client = server.accept();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

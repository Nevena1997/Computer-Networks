package task2;

import javax.naming.spi.DirectoryManager;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.util.Arrays;

public class Task2Server {

    static int PORTNUM = 12327;
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(PORTNUM)) {
            Socket client = server.accept();
            BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            System.out.println(br.readLine());

            bw.write("Geo");
            bw.newLine();
            bw.flush();
            bw.write("mata");
            bw.newLine();
            bw.flush();
            bw.write("trte");
            bw.newLine();
            bw.flush();
            bw.write("mrte");
            bw.newLine();
            bw.flush();
            bw.write("end");
            bw.newLine();
            bw.flush();

            String oblast = br.readLine();
//            Files.getFileStore(File)
            BufferedReader citacPitanja = new BufferedReader(new FileReader(new File("/home/ispit/Desktop/kviz/"+oblast+".txt")));
            System.out.println(citacPitanja.readLine());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

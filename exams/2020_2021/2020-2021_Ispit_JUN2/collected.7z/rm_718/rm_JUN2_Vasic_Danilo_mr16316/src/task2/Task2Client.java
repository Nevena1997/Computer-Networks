package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {
        try(Socket socket = new Socket("localhost",Task2Server.PORTNUM);
        Scanner sc = new Scanner(System.in)){
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String ime = sc.next();
            bw.write(ime);
            bw.newLine();
            bw.flush();
            String oblast;
            while(!(oblast = br.readLine()).equalsIgnoreCase("end")){
                System.out.println(oblast);
            }
            bw.write(sc.next());
            bw.newLine();
            bw.flush();
//            PITANJE 1
            System.out.println(br.readLine());
            bw.write(sc.next());
            bw.newLine();
            bw.flush();
            System.out.println(br.readLine());
            //            PITANJE 2
            System.out.println(br.readLine());
            bw.write(sc.next());
            bw.newLine();
            bw.flush();
            System.out.println(br.readLine());
//            PITANJE 3
            System.out.println(br.readLine());
            bw.write(sc.next());
            bw.newLine();
            bw.flush();
            System.out.println(br.readLine());
//            PITANJE 4
            System.out.println(br.readLine());
            bw.write(sc.next());
            bw.newLine();
            bw.flush();
            System.out.println(br.readLine());

            System.out.println(br.readLine());





        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

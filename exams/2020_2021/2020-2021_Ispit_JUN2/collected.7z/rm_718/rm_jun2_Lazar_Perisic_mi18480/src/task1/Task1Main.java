package task1;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");
    }
}

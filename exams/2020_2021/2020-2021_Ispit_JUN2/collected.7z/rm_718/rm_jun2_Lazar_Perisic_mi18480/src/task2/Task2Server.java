package task2;

import org.w3c.dom.ls.LSOutput;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Task2Server {

//    private List<String> oblasti;
//
//    public void setOblasti(List<String> oblasti){
//        this.oblasti=oblasti;
//    }

    public static void main(String[] args) {

        int port=12321;
        List<String> oblasti=new LinkedList<>();


        try (ServerSocket server = new ServerSocket(port)) {

            System.err.println("server started");

            Scanner sc = new Scanner(System.in);
            String path=sc.nextLine();

//            System.out.println(Path.of("kviz"));
            var dir=Files.newDirectoryStream(Paths.get(path));
            var it=dir.iterator();

            while(it.hasNext()){
//                System.out.println(it.next());

                oblasti.add(it.next().toString().split("/")[1]);

            }

            System.err.println(oblasti);



//            BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(path)));
//
//
////            BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(path)));
//
//            List<String> collect = br.lines().collect(Collectors.toList());
//
//            System.err.println(collect);

//            Date time=new Date();
//            System.out.println(time.getTime());


            while(true){


                Socket client=server.accept();

                new Thread(new ClientThread(client,oblasti.toString(),path)).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

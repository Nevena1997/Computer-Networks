package task2;

import java.io.*;
import java.net.Socket;
import java.sql.Time;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;


public class ClientThread implements Runnable {

    private Socket client;
    private String name;
//    private Task2Server server;
    private String oblasti;
    private String path;
    private int poeni;

    ClientThread(Socket client,String oblasti,String path) {

        this.client = client;
//        this.name = name;
//        this.server=server;
        this.oblasti=oblasti;
        this.path=path;
        this.poeni=0;

    }

    public void setUsername(String name){
        this.name=name;
    }

    @Override
    public void run() {

        try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             PrintWriter out = new PrintWriter(client.getOutputStream());
             Scanner sc = new Scanner(System.in);) {

            String name=in.readLine();

            if(name!=null){
                setUsername(name);
            }

            out.println(oblasti);
            out.flush();


            StringBuilder pathNew=new StringBuilder(path);

            String oblastIzabrana=in.readLine();

            pathNew.append("/");
            pathNew.append(oblastIzabrana).append(".txt");
            System.out.println(pathNew);



            BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(pathNew.toString())));

            List<String> collect = br.lines().collect(Collectors.toList());

            System.err.println(collect);

            for(String p:collect){

//                out.println(p);
                List<String> sve = Arrays.asList(p.split("[?]"));


                String odgovor=sve.get(1).split(" ")[1];
                String poeni=sve.get(1).split(" ")[2];
                out.println(sve.get(0));
                out.flush();

//                System.out.println(sve.get(1));


                Date start=new Date();
//                System.out.println(start);

//                System.out.println(start);




                String odg=in.readLine();

                Date end=new Date();
//                System.out.println(end);

                if(end.getTime()-start.getTime()>5000){
                    out.println("niste stigli da odgovorite na vreme");
                    out.flush();
                } else {
                    if(odg.equalsIgnoreCase("Ne znam")){
                        out.println("niste znali tacan odgovor");
                        out.flush();
                    }
                    else if(odg.equalsIgnoreCase(odgovor)){
                        this.poeni=this.poeni+Integer.parseInt(poeni);
                        out.println("tacan odgovor, osvojili ste "+poeni+" poena");
                        out.flush();
                    }else{
                        this.poeni=this.poeni-1;
                        out.println("netacan odgovor, gubite 1 poen");
                        out.flush();
                    }
                }

            }





            StringBuilder pathNew1=new StringBuilder();
            pathNew1.append(oblastIzabrana).append("R").append(".txt");
//            System.out.println(pathNew1);
            BufferedReader br1=new BufferedReader(new InputStreamReader(new FileInputStream(pathNew1.toString())));
            List<String> rez = br1.lines().collect(Collectors.toList());

            boolean notified=false;


            for(String r:rez){
                if(Integer.parseInt(r.split(" ")[1])>poeni){
                    notified=true;
                    out.println("Kviz je zavrsen. Trenutno ste u najbolja tri u oblasti, imate "+ poeni+ " poena");
                    out.flush();
                    System.err.println(this.name + " " +poeni);
                    break;
                }


                System.err.println(r);
            }

            if(!notified) {
                out.println("Kviz je zavrsen");
                out.flush();
            }

            System.err.println("client finished");












        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

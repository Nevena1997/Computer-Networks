package task3;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Task3Main {

    public static void main(String[] args) {


        List<String> oblasti=new LinkedList<>();
        boolean postoji=false;

        DirectoryStream<Path> dir= null;
        try {
            dir = Files.newDirectoryStream(Paths.get("kviz"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        var it=dir.iterator();

        while(it.hasNext()){
//                System.out.println(it.next());

            oblasti.add(it.next().toString().split("/")[1]);

        }

        System.err.println(oblasti);


        Scanner sc = new Scanner(System.in);

        String url = sc.nextLine();

        String urlAfter=url.split("://")[1];

        String host = urlAfter.split(":")[0];
        int port=12321;

//        System.out.println(host);
//        System.out.println("ovde");

        if(urlAfter.split(":").length<2){
            System.err.println("Nije unet port");
        }else{
            port=Integer.parseInt(urlAfter.split(":")[1]);
        }

        if(urlAfter.split("[?]").length<2){
            System.out.println(urlAfter);
            System.out.println(urlAfter.split("[?]")[0]);
            System.out.println(urlAfter.split("[?]"));
            System.err.println("Nije uneta oblast");
        }
        else{
            String oblast=urlAfter.split("[?]")[1];
//            System.out.println("ovde");
//            System.out.println(oblast);

            for (String e:oblasti){
                if(e.split("[.]")[0].equalsIgnoreCase(oblast)){
                    //salji pitanje
                    postoji=true;
                    break;

                }
            }
            if(!postoji){
                System.err.println("Nepostojeca oblast");
            }else{
                StringBuilder pathNew=new StringBuilder("kviz");

                pathNew.append("/");
                pathNew.append(oblast).append(".txt");
                System.out.println(pathNew);


                BufferedReader br= null;
                try {
                    br = new BufferedReader(new InputStreamReader(new FileInputStream(pathNew.toString())));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                List<String> collect = br.lines().collect(Collectors.toList());

                System.err.println(collect);

                for(String p:collect) {
                    List<String> sve = Arrays.asList(p.split("[?]"));

                    System.out.println(sve.get(0));
                    break;
                }
            }
        }


//        System.out.println(urlAfter.split(":").length);
//        String portString=urlAfter.split(":")[1];




        try (Socket client = new Socket(host, port)) {

            System.err.println("connected to server");
        } catch (UnknownHostException e) {
            System.err.println("Neuspela konekcija");
//            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class Task2Client {



}

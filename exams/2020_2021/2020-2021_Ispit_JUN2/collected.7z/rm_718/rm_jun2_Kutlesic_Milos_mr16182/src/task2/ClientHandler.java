package task2;

import java.io.*;
import java.net.Socket;
import java.nio.Buffer;
import java.util.Scanner;

public class ClientHandler  implements Runnable{
    private Socket client;
    private String[] oblasti;
    private String path;

    ClientHandler(Socket client,String []oblasti,String path){
        this.client = client;
        this.oblasti = oblasti;
        this.path = path;

    }
    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))) {
                    String ime = in.readLine();

                    for(int i =0 ; i < this.oblasti.length; i++) {
                        out.write(oblasti[i]);
                        out.newLine();
                        out.flush();
                    }


                    String odg = in.readLine();
                    String novaPutanja = this.path +  odg + ".txt";



            try (Scanner f = new Scanner(new FileInputStream(novaPutanja))) {
                while(f.hasNextLine()){
                    out.write(f.nextLine());
                    out.newLine();
                    out.flush();
                    client.setSoTimeout(5000);

                }




            }





        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Task2Server {
    public static int PORT = 12321;

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(PORT);
            Scanner sc = new Scanner(System.in)) {
            System.err.println("Osluskivanje na portu " + PORT);
            System.err.println("Ucitajte putanju ka fajlovima");
            String putanja = "/";


            if(sc.hasNext()){
                putanja = sc.next();
            }
            File f = new File(putanja);
            String[] a = f.list();
            for(int i =0 ; i< a.length;i++) {
                System.err.println(a[i]);
                a[i] = a[i].substring(0, a[i].length() - 4);
                //System.err.println(a[i]);
            }
            System.err.println("Upsesno ucitana putanja");




            while(true){
                Socket client =  server.accept();
                System.err.println("Prihvacen novi klijent saljem ga niti ");

                new Thread(new ClientHandler(client,a,putanja)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

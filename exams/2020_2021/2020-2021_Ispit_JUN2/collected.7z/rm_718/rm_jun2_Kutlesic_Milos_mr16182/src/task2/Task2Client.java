package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", Task2Server.PORT);
            Scanner sc = new Scanner(System.in);
             BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()))){
                System.err.println("Unesite vase ime : ");
                String ime = null;
                if(sc.hasNext()) {
                    ime = sc.nextLine();
                }
                System.err.println(ime);
                bw.write(ime);
                bw.newLine();
                bw.flush();

                String s;
                System.err.println("Izaberite oblasti iz kojih hocete da odgovarate?");
                int i=1;
               while((s = br.readLine()) != null){
                   System.err.println(s);
               }

                System.err.println("Izasao sam");
                String odg = null;
                if(sc.hasNext()) {
                    odg = sc.nextLine();
                }
                System.err.println(odg);


                bw.write(odg);
                bw.newLine();
                bw.flush();








        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Scanner;

public class Task2Server {
    public static final int PORT = 12321;

    public static void main(String[] args) {

        try ( var server = new ServerSocket(PORT) ) {

            System.err.println("Server started on port: " + PORT);
            var dir = getQuizDir();

            while (true) {
                System.err.println("Waiting for client connections...");

                var client = server.accept();
                System.err.println("Accepted connection from: [" + client + "]");

                new ClientHandler(client, server, dir).run();
            } // server lifecycle

        } catch (IOException e) {
            e.printStackTrace();
        }

    } // main

    private static String getQuizDir() {
        String dir = "";

        System.out.println("Getting directory for Quiz");

        try ( var systemIn = new Scanner(System.in) ) {

            System.out.print("Directory path: ");
            dir = systemIn.nextLine();

            System.out.println("Quiz directory: [" + dir + "]");
        }

        return dir;
    }

}// class

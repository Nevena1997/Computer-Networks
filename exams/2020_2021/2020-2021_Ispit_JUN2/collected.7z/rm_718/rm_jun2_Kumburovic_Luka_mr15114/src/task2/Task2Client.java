package task2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Task2Client {
    private static final String host = "localhost";

    public static void main(String[] args) {

        ArrayList<String> quizAreas = new ArrayList<>();

        try (
             var client = new Socket(host, Task2Server.PORT);
             var clientIn = new BufferedReader( new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
             var clientOut = new BufferedWriter( new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8) )
        ) {

            System.err.println("Connected to the server on the port: " + Task2Server.PORT);

            var clientName = getName();

            System.out.println("Sending client name to server.");
            clientOut.write(clientName);
            clientOut.newLine();
            clientOut.flush();
            System.out.println("Name successfully sent to server.");

            System.out.println("Expecting to receive areas...");
            String area;
            while ( ( area = clientIn.readLine() ) != null ) {
                if (area.equals("End")){
                    break;
                }
                System.out.println("Received area [" + area + "]");
                quizAreas.add(area);
            }
            System.out.println("Received list of areas.");

            var chosenArea = chooseArea(quizAreas);
            System.out.println("Sending chosen area to the server.");
            clientOut.write(chosenArea);
            clientOut.newLine();
            clientOut.flush();
            System.out.println("Area successfully sent to server.");

            String question;
            while ( ( question = clientIn.readLine() ) != null ) {
                if (question.equals("Kviz je zavrsen!")){
                    break;
                }

                System.err.println(question);
                var answer = generateAnswer(question);

                System.out.println("Answer is [" + answer + "]");
                clientOut.write(answer);
                clientOut.newLine();
                clientOut.flush();
                System.out.println("Answer successfully sent");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    } // main

    private static String getName() {
        String name = "";

        try ( var systemIn = new Scanner(System.in)) {

            System.out.print("Name: ");
            name = systemIn.nextLine();

            System.out.println("Client name is: [" + name + "]");
        }

        return name;
    }

    private static String chooseArea(ArrayList<String> quizAreas) {
        var random = new Random().nextInt(quizAreas.size());

        return quizAreas.get(random);
    }

    // System.in se ne ponasa lepo, mockujem samo da bi radilo
    private static String generateAnswer(String question) {
        String answer = "";

        if ( question.startsWith("1.Ko je glavni") ) {
            answer = "Raskoljnikov";
        } else if ( question.startsWith("1.Koliko igraca") ) {
            answer = "7";
        } else if ( question.startsWith("1.U kom mestu") ) {
            answer = "Orasac";
        } else if ( question.startsWith("1.Koji je glavni") ) {
            answer = "Amsterdam";
        } else {
            answer = "Sekspir";
        }

        return answer;
    }

} // class

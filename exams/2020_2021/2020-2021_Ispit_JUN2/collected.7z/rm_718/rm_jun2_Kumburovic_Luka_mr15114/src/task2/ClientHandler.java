package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ClientHandler implements Runnable {

    private Socket client;
    private ServerSocket server;

    private BufferedReader serverIn;
    private BufferedWriter serverOut;

    private String name;
    private String quizDir;

    private int points;

    private ArrayList<String> quizAreas = new ArrayList<>();

    public ClientHandler(Socket client, ServerSocket server, String quizDir) {
        this.client = client;
        this.server = server;
        this.quizDir = quizDir;

        this.quizAreas = getQuizAreas();
        this.points = 0;

        try {
            this.serverIn = new BufferedReader( new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8) );
            this.serverOut = new BufferedWriter( new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8) );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println("Thread for client [" + this.client + "] started");

        try {
            this.name = serverIn.readLine();
            System.out.println("Client name is [" + this.name + "]");

            System.out.println("Sending available areas to [" + this.name + "]");
            for (String area: this.quizAreas) {
                serverOut.write(area);
                serverOut.newLine();
                serverOut.flush();
            }
            serverOut.write("End");
            serverOut.newLine();
            serverOut.flush();
            System.out.println("Areas successfully sent to [" + this.name + "]");

            System.out.println("Expecting chosen area back from client...");
            var chosenArea = serverIn.readLine();
            System.out.println("Chosen area is: [" + chosenArea + "]");

            var questions = getQuestions(chosenArea);

            for (String questionAnswer: questions) {
                var question = questionAnswer.substring(0, questionAnswer.lastIndexOf('?')).trim();
                var correctAnswer = questionAnswer.substring(questionAnswer.lastIndexOf('?') + 1, questionAnswer.lastIndexOf(' ')).trim();
                var points = questionAnswer.substring(questionAnswer.lastIndexOf(' ')).trim();

                System.out.println("Question: [" + question + "]");
                System.out.println("Answer: [" + correctAnswer + "]");
                System.out.println("Points: [" + points + "]");

                serverOut.write(question);
                serverOut.newLine();
                serverOut.flush();
                System.out.println("Successfully sent question to [" + this.name + "]");

                System.out.println("Expecting answer from [" + this.name + "]");
                var answer = serverIn.readLine();
                System.out.println("[" + this.name + "] answer is: [" + answer + "]");

                if ( correctAnswer.equalsIgnoreCase(answer) ){
                    serverOut.write("Tacan odgovor. Osvojili ste " + points + " poena");
                    serverOut.newLine();
                    serverOut.flush();
                    this.points += Integer.parseInt(points);
                } else if ( answer.equalsIgnoreCase("ne znam") ) {
                    serverOut.write("Niste znali tacan odgovor");
                    serverOut.newLine();
                    serverOut.flush();
                } else {
                    serverOut.write("Netacan odgovor. Izgubili ste 1 poen");
                    serverOut.newLine();
                    serverOut.flush();
                    this.points--;
                }
            }
            System.out.println("[" + this.name + "] finished with the quiz with: " + this.points + " points.");
            serverOut.write("Kviz je zavrsen!");
            serverOut.newLine();
            serverOut.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ArrayList<String> getQuizAreas() {
        var tempAreas = new ArrayList<String>();
        tempAreas.add("Geografija");
        tempAreas.add("Istorija");
        tempAreas.add("Knjizevnost");
        tempAreas.add("Sport");

        return tempAreas;
    }

    private ArrayList<String> getQuestions(String chosenArea) {
        ArrayList<String> questions = new ArrayList<>();

        var path = quizDir.endsWith("/") ? quizDir : quizDir + "/";
        path += chosenArea + ".txt";
        System.out.println("Looking for: [" + path + "]");

        try ( var fileIn = Files.newBufferedReader(Paths.get(path)) ){
            String line;
            while ( (line = fileIn.readLine()) != null ) {
                System.out.println("Question: [" + line + "]");
                questions.add(line);
            }
            System.out.println("Successfully read all questions.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return questions;
    }
}

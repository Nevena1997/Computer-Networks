package task1;

public class Nit implements Runnable {


    @Override
    public void run() {

    }
}

package task1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    public static final int BR = 10;
    public static final int BR_NITI = 5;


    public static void main(String[] args) {

        Path putanja = Paths.get("/home/ispit/Desktop/tests/urls");

        BlockingQueue<Path> red = new ArrayBlockingQueue<>(BR);

        Thread glavna = new ObilazakDirektorijuma(putanja, red);
        glavna.start();

        int i;
        for(i=0; i<BR_NITI; i++) {
            Thread nit = new ObradaFajla(red);
            nit.start();
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
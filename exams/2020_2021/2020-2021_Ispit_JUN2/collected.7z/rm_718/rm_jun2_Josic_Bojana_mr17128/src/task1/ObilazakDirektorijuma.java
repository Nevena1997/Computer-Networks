package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class ObilazakDirektorijuma extends Thread{

    public static final String KRAJ_OBILASKA = "";

    private BlockingQueue<Path> red;
    private Path putanja;

    public ObilazakDirektorijuma(Path putanja, BlockingQueue<Path> red) {
        this.red = red;
        this.putanja = putanja;
    }

    @Override
    public void run() {
        try {
            DirectoryStream<Path> putanje = Files.newDirectoryStream(putanja);
            for(Path p: putanje) {
                if(Files.isRegularFile(p)) {
                    red.put(p);
                }
            }
            red.put(Paths.get(KRAJ_OBILASKA));

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ObradaFajla extends Thread{

    private BlockingQueue<Path> red;
    private Lock lock = new ReentrantLock();

    public ObradaFajla(BlockingQueue<Path> red) {

        this.red = red;
    }



    @Override
    public void run() {

        while (true) {

            try {
                Path putanja = red.take();
                if(putanja.equals(Paths.get(ObilazakDirektorijuma.KRAJ_OBILASKA))) {
                    red.put(putanja);
                    break;
                }

                pretraziUrl(putanja);

            } catch (InterruptedException | IOException e) {
                e.printStackTrace();
            }

        }

    }

    void pretraziUrl(Path putanja) throws IOException {
        Scanner sc = new Scanner(putanja);


        String linija = "";

        String num;

        while(sc.hasNext()) {
            lock.lock();
            linija = sc.nextLine();
            lock.unlock();
            String l = linija.substring(2);
            num = linija.substring(0,1);
            int n = Integer.parseInt(num);

            try {
                URL url = new URL(l);
                System.out.println(url.getPath() + "   " + url.getProtocol() );

            }catch (MalformedURLException e) {
                continue;
            }
        }

    }



}
package task2;

import java.io.InputStream;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {

    public static final int BUFER_LEN = 555;

    public static void main(String[] args) {

        try(Socket klijent = new Socket("localhost", Task2Server.PORT); Scanner sc = new Scanner(System.in)) {
            String ime = sc.nextLine();

            klijent.getOutputStream().write(ime.getBytes());
            InputStream in = klijent.getInputStream();

            byte[] b = new byte[BUFER_LEN];
            int n = in.read(b);
            if(n > 0) {
                System.out.println(new String(b, 0, n));
            }

            String odgovor = sc.nextLine();
            klijent.getOutputStream().write(odgovor.getBytes());

            while(true) {
                n = in.read(b);
                if(n > 0) {
                    System.out.println(new String(b, 0, n)); // ispis pitanja
                }
                String odgovor_na_pitanje = sc.nextLine();
                klijent.getOutputStream().write(odgovor_na_pitanje.getBytes());

            }


        }
        catch (Exception e) {
            e.printStackTrace();
        }


    }

}

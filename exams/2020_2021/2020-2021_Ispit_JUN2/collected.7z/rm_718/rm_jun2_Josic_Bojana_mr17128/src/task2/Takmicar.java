package task2;

public class Takmicar {
    private String ime;
    private String oblast;
    int bodovi;


    public Takmicar(String ime, String oblast, int bodovi) {
        this.ime = ime;
        this.oblast = oblast;
        this.bodovi = bodovi;
    }

    public String getIme() {
        return ime;
    }
    public int getBodovi() {
        return bodovi;
    }

    public void tacanOdgovor(int br_bodova) {
        this.bodovi = this.bodovi + br_bodova;
    }

    public void pogresanOdgovor() {
        this.bodovi = this.bodovi - 1;
    }


}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task2Server {

    public static final int PORT = 12321;


    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(PORT); Scanner sc = new Scanner(System.in)) {

            String putanja = sc.nextLine(); //  /home/ispit/Dekstop/kviz
            List<Takmicar> takmicari = new ArrayList<>();

            while (true) {

                Socket klijent = server.accept();

                System.out.println("Klijent povezan.");

                Thread t = new ObradaTakmicara(klijent, putanja, takmicari);
                t.start();


            }


        } catch (IOException e) {
            e.printStackTrace();

        }

    }
}

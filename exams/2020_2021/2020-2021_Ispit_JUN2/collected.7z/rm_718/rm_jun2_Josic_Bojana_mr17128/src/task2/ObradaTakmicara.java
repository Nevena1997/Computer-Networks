package task2;

import java.io.IOException;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ObradaTakmicara extends Thread {

    private Socket klijent;
    private String putanja;
    private List<Takmicar> takmicari;

    public ObradaTakmicara(Socket klijent, String putanja, List<Takmicar> takmicari) {
        this.klijent = klijent;
        this.putanja = putanja;
        this.takmicari = takmicari;
    }


    @Override
    public void run() {
        String ime = ucitajIme();
        posaljiOblasti();
        String oblast = ucitajOblast();
        int bodovi = 0;
        Takmicar takmicar = new Takmicar(ime, oblast, bodovi);
        Takmicar t = takmicenje(oblast, takmicar);
        takmicari.add(t);
    }

    public String ucitajIme() {
        try {
            byte[] b = new byte[Task2Client.BUFER_LEN];
            int n = klijent.getInputStream().read(b);
            if(n > 0) {
                return new String(b, 0, n);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public String ucitajOblast() {
        try {
            byte[] b = new byte[Task2Client.BUFER_LEN];
            int n = klijent.getInputStream().read(b);
            if(n > 0) {
                return new String(b, 0, n);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public void posaljiOblasti() {
        try {
            klijent.getOutputStream().write("Izaberite oblast: Geografija, Istorija, Knjizevnost, Sport".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public Takmicar takmicenje(String oblast, Takmicar takmicar) {
        putanja = putanja + "/" + oblast + ".txt";
        Path p = Paths.get(putanja);
        try(Scanner sc = new Scanner(p)) {
            while(sc.hasNext()) {
                String pitanje = sc.nextLine();

                int i = pitanje.indexOf("?");
                String ostatak = pitanje.substring(i, pitanje.length() - 1);
                pitanje = pitanje.substring(0,i);
                pitanje = pitanje + "?";

                klijent.getOutputStream().write(pitanje.getBytes());

                String odgovor = "";
                try {
                    byte[] b = new byte[Task2Client.BUFER_LEN];
                    int n = klijent.getInputStream().read(b);
                    if(n > 0) {
                         odgovor = new String(b, 0, n);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                String[] od_bodovi = ostatak.split(" ");
                String tacan_odgovor = od_bodovi[0];
                String bd = od_bodovi[1];
                int bodovi = Integer.parseInt(bd);
                if(odgovor.equalsIgnoreCase(tacan_odgovor)) {
                    takmicar.tacanOdgovor(bodovi);
                }
                else if(odgovor.equalsIgnoreCase("ne znam")) {
                    continue;
                }
                else {
                    takmicar.pogresanOdgovor();
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Takmicar: " + takmicar.getIme() + " bodovi: " + takmicar.getBodovi());

        return takmicar;

    }


}

package task3;

import task2.Task2Client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class QuizStream extends URLConnection {

    private Socket conn;

    public QuizStream(URL u) {
        super(u);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected)
            this.connect();

        return this.conn.getInputStream();
    }

    @Override
    public void connect() throws IOException {

        if(!this.connected) {
            this.conn = new Socket(url.getHost(), url.getPort()); //ovde smo se povezali na server
            InputStream in = conn.getInputStream();
            OutputStream out = conn.getOutputStream();

            Scanner sc = new Scanner(System.in);
            String ime = sc.nextLine();
            String serverSalje = "";

            out.write(ime.getBytes());

            try {
                byte[] b = new byte[Task2Client.BUFER_LEN];
                int n = in.read(b);
                if(n > 0) {
                    serverSalje = new String(b, 0, n);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }


            String s = url.getQuery();
            String oblast = s.substring(7, s.length()-1); // Geografija
            out.write(oblast.getBytes());
        }


    }
}

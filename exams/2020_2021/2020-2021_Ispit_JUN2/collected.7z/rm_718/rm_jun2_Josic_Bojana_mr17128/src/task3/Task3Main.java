package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public class Task3Main {

    public static void main(String[] args) throws IOException {

        URL url = new URL(null, "quiz://localhost", new Handler());
        URLConnection con = url.openConnection(); //ovo je ustvari QuizStream
        BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));


        System.out.println(reader.readLine());

    }

}

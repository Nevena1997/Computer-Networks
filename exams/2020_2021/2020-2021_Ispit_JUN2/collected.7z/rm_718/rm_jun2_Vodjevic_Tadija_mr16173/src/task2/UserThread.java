package task2;

import java.io.*;
import java.net.Socket;

public class UserThread extends Thread {
    private String name;
    private BufferedReader in;
    private PrintWriter out;
    private Task2Server server;


    public UserThread(Socket client, Task2Server server) {
        this.server = server;
        try {
            this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            this.out = new PrintWriter(client.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            name = in.readLine();
            out.println("Geografija Istorija Knjizevnost Sport");
            String oblast = in.readLine();
            int poeni = 0;

            BufferedReader filein = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/kviz/"+oblast+".txt")));
            while(true){
                String pitanje = filein.readLine();
                if(pitanje == null)
                    break;
                out.println(pitanje.substring(0, pitanje.indexOf("?")+1));
                String odgovor = in.readLine();
                if(odgovor.equalsIgnoreCase(pitanje.substring(pitanje.indexOf("?")+2).split(" ")[0])) {
                    int p = Integer.parseInt(pitanje.substring(pitanje.indexOf("?") + 2).split(" ")[1]);
                    poeni += p;
                    out.println("Tacan odgovor! Osvojili ste "+p+" poena");
                }
                else if(odgovor.equalsIgnoreCase("ne znam")){
                    out.println("Niste znali tacan odgovor");
                } else{
                    poeni-=1;
                    out.println("Netacan odgovor. Izgubili ste 1 poen");
                }
            }
            out.println("Kviz je zavrsen");
            if(server.checkTop3(name, poeni, oblast)){
                out.println("Medju najbolja 3 ste rezultata iz ove oblasti od sada");
            }else{
                out.println("Niste pobedili tri najbolja rezultata iz ove oblasti");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

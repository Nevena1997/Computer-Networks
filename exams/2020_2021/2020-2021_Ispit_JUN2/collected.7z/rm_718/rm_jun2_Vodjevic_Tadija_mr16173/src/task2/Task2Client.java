package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {
    private String hostname;
    private int port;

    public Task2Client(String hostname, int port) {
        this.hostname = hostname;
        this.port = port;
    }

    public static void main(String[] args) {
        Task2Client client = new Task2Client("localhost", Task2Server.SERVER_PORT);
        client.execute();
    }

    private void execute() {
        Scanner sc = new Scanner(System.in);
        try(Socket socket = new Socket(hostname, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true)){

            System.out.println("Unesi username\n");
            String name = sc.nextLine();
            out.println(name);
            String[] oblasti = in.readLine().split(" ");
            System.out.println("Ponudjene oblasti: ");
            for(int i = 0; i<oblasti.length; i++){
                System.out.println(oblasti[i]);
            }
            System.out.println("Unesite zeljenu oblast");
            String oblast = sc.nextLine();
            out.println(oblast);
            while(true){
                String recieved = in.readLine();
                System.out.println(recieved);
                if(recieved.equalsIgnoreCase("kviz je zavrsen"))
                    break;
                out.println(sc.nextLine());
                System.out.println(in.readLine());
            }
            System.out.println(in.readLine());
        }catch(IOException e){
            e.printStackTrace();
        }
    }

}

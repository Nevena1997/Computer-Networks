package task3;

import task2.UserThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Task3Server {
    static final int SERVER_PORT = 12321;

    private int port;

    private int[][] toplists = new int[4][3];

    Set<UserThread3> users = new HashSet<>();

    public static void main(String[] args) {
        Task3Server server = new Task3Server(SERVER_PORT);
        server.execute();
    }

    private void intializeTopLists() {
        for(int i=0; i<4; i++)
            for(int j=0;j<3;j++)
                this.toplists[i][j]=0;
    }

    public Task3Server(int port) {
        this.port = port;
        this.intializeTopLists();
    }

    private void execute(){
        Scanner sc = new Scanner(System.in);
        try(ServerSocket server = new ServerSocket(port)){
//            System.out.println("Unesi putanju do fajla\n");
//            String filepath = sc.nextLine();
//            BufferedReader filereader = new BufferedReader(new InputStreamReader(new FileInputStream(filepath)));
//            String s;
//            while((s=filereader.readLine())!=null){
//                System.out.println(s);
//            }
            while(true){
                Socket client = server.accept();
                System.out.println(client);
                UserThread3 user = new UserThread3(client, this);
                users.add(user);
                user.start();
            }

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public boolean checkTop3(int poeni, String oblast) {
        int i;
        if(oblast.equalsIgnoreCase("Geografija"))
            i=0;
        else if(oblast.equalsIgnoreCase("Istorija"))
            i=1;
        else if(oblast.equalsIgnoreCase("Knjizevnost"))
            i=2;
        else
            i=3;
        for(int j=0; j<3; j++)
            if(toplists[i][j]<poeni){
                toplists[i][j] = poeni;
                return true;
            }
        return false;
    }
}

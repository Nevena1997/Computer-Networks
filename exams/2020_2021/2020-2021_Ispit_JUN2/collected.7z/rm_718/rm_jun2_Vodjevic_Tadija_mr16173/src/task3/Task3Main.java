package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Task3Main {

    public static void main(String[] args) {
        System.out.println("URL: ");
        Scanner sc = new Scanner(System.in);
        String urladdress = sc.nextLine();


        try {
            URL url = new URL(null, urladdress, new Handler());
            var conn = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            System.out.println(in.readLine());


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

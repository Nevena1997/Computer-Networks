package task3;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public class QuizURLConnection extends URLConnection {
    static final int DEFAULT_PORT = 12321;

    private Socket connection;

    public QuizURLConnection(URL url) {
        super(url);
    }

    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if(!this.connected)
            this.connect();
        return this.connection.getInputStream();
    }


    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port = url.getPort();
            if(port < 1 || port > 65335)
                port = DEFAULT_PORT;
            connection = new Socket(url.getHost(), port);
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            PrintWriter out = new PrintWriter(connection.getOutputStream(), true);
            String query = url.getQuery();
            String oblast = query.substring(query.indexOf("=")+1);
            System.out.println(oblast);
            out.println("Tadija");
            String oblasti = in.readLine();
            System.out.println(oblasti);
            out.println(oblast);
        }
    }
}

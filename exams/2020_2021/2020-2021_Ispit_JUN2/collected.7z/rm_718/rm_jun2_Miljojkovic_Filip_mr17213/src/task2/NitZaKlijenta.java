package task2;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class NitZaKlijenta implements Runnable {

    private Socket client;
    private ArrayList<String> lista;

    public NitZaKlijenta(Socket client, ArrayList<String> lista) {

        this.client = client;
        this.lista = lista;

    }

    @Override
    public void run() {

        try(BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            Scanner sc = new Scanner(System.in))
        {
            String ime_klijenta = in.readLine();

            System.out.println("Odaberite oblast: ");

            for(String tmp:lista)
            {
                out.write(tmp);
                out.newLine();
                out.flush();
            }


            String odabrana_oblast = sc.nextLine();




        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

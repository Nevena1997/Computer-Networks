package task2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Task2Server {


    public static final int broj_porta = 12321;


    public static void main(String[] args) {


        System.out.println("Unesite putanju: ");
        Scanner sc = new Scanner(System.in);

        String putanja = sc.nextLine();
        Path path = Paths.get(putanja);

        ArrayList<String> lista = new ArrayList<String>();

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(path))
        {

            for(Path p :ds)
            {
                String tmp = p.getFileName().toString();
                lista.add(tmp.substring(0,tmp.length()-4));
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


        try(ServerSocket server = new ServerSocket(broj_porta);)
        {
            while (true)
            {
                Socket client = server.accept();
                new Thread(new NitZaKlijenta(client,lista));
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

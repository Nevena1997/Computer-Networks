package task1;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class NitZaObradu implements Runnable {

    static Path kraj = Paths.get("kraj");


    private BlockingQueue<Path> bq;

    public NitZaObradu(BlockingQueue<Path> bq) {
        this.bq = bq;
    }


    @Override
    public void run() {

       while(true)
       {
           try {
               Path p = bq.take();
               radi(p);



           } catch (InterruptedException e) {
               e.printStackTrace();
           }
       }

    }

    private void radi(Path p) {
    }
}

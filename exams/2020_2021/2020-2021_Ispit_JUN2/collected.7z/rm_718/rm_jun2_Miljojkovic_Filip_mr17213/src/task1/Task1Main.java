package task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    public static final int velicina = 5;


    public static void main(String[] args) {


        String putanja = "/home/ispit/Desktop/tests/urls";

        Path path = Paths.get(putanja);

        BlockingQueue<Path> bq = new ArrayBlockingQueue<>(velicina);

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(path))
        {
            for (Path p:ds)
            {
                bq.put(p);
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        for(int i=0;i<5;i++)
        {
            new Thread(new NitZaObradu(bq)).start();
        }


    }

}

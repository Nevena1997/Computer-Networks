package task2;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientRead extends Thread {
    private Map<String, Integer> data;
    private Map<String, File> questionMap;
    private Socket socket;

    public ClientRead(Socket socket, Map<String, Integer> data, Map<String, File> questionMap) {
        this.socket = socket;
        this.data = data;
        this.questionMap = questionMap;
    }

    public void sendQuestions(BufferedReader in, BufferedWriter out, File current, String userName) throws IOException{
        Scanner input = new Scanner(current);
        while(input.hasNextLine()) {

            String line = input.nextLine();
//            Pattern pointPattern = Pattern.compile("\\d");
//            Pattern answerPattern = Pattern.compile("[a-zA-z]+");
//            Matcher matcher = pointPattern.matcher(line);
//            int points = Integer.parseInt(matcher.group(0));
            String question = line.split("\\?")[0];
//            String answerWithPoints = line.split("\\?")[1];
//            matcher = answerPattern.matcher(answerWithPoints);
//            String answer = matcher.group(0);

            out.write(question + "?");
            out.newLine();
            out.flush();

            this.socket.setSoTimeout(5000);
            try {
                String response = in.readLine();
                String serverResponse = "";
                if(response.contains("Ne znam\n")){
                    serverResponse = "Niste znali tacan odgovor";
                }

                if(line.contains(response)) {
                    serverResponse = "Tacan odgovor ostovjili ste " + 5;
                    data.put(userName, data.get(userName) + 5);
                } else {
                    serverResponse = "Netacan odgovor izgubili ste jedan poen";
                    data.put(userName, data.get(userName) - 1);
                }
                System.out.println(response);
                out.write(serverResponse);
                out.newLine();
                out.flush();
            } catch (SocketTimeoutException e)
            {
                out.write("Niste stigli da odgovorite na vreme.");
                out.newLine();
                out.flush();
            }
        }

        out.write("end");
        out.newLine();
        out.flush();

        input.close();
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

            String userName = in.readLine();
            this.data.put(userName, 0);
            out.write("Oblasti iz kojih " + userName +" moze da se takmici: ");
            for(String area : this.questionMap.keySet()) {
                out.write(area + " ");
            }

            out.newLine();
            out.flush();

            String receivedArea = in.readLine();
            System.out.println(userName + " je izabrao/la oblast " + receivedArea);

            System.err.println("K V I Z P O C I N J E");
            sendQuestions(in, out, questionMap.get(receivedArea), userName);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

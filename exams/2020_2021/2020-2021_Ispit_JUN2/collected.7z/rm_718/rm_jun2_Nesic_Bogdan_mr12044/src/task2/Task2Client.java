package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;


public class Task2Client {

    public static void main(String[] args) {
        System.out.println("Hello from Task2Client");

        try (Socket client = new Socket("localhost", Task2Server.PORT);
             BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

            System.out.println("Input your user name");
            String userName = userIn.readLine();

            out.write(userName);
            out.newLine();
            out.flush();

            String line = in.readLine();
            System.out.println(line);


            System.out.println("Unesi oblast iz koje zelis da se takmicis");
            String oblast = userIn.readLine();


            out.write(oblast);
            out.newLine();
            out.flush();

            String question = "";
            while((question = in.readLine()) != null) {
                if(question.equals("end\n")) {
                    break;
                }
                System.out.println(question);
                String odgovor = userIn.readLine();
                out.write(odgovor);
                out.newLine();
                out.flush();
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

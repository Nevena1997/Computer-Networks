package task2;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Logger;


public class Task2Server {
    public static int PORT = 12321;
    public static Logger audit = Logger.getLogger("info");


    public static void main(String[] args) {
        System.out.println("Hello from Task2Server");

        Map<String, Integer> data = new HashMap<>();
        Map<String, File> questionMap = new HashMap<>();

        try (ServerSocket server = new ServerSocket(PORT);
             Scanner input = new Scanner(System.in)) {
//            String path = input.nextLine();
            // Zakucano radi lakseg pokretanja
            String path = "/home/ispit/Desktop/kviz";

            File[] files = new File(path).listFiles();
            assert files != null;

            for(File f : files) {
                String fileName = f.getName().split("\\.")[0];
                questionMap.put(fileName, f);
            }

            while(true) {
                Socket client = server.accept();
                audit.info("New client connected!");

                new ClientRead(client, data, questionMap).start();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

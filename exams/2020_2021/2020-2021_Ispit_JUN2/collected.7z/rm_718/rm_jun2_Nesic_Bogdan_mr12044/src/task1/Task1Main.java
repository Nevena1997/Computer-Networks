package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Task1Main {

    public static class MyThread extends Thread {
        public MyThread(File file) {
            this.file = file;
        }

        public void ProcessFile(File file) {
            try(Scanner input = new Scanner(file)) {
                while(input.hasNextLine()) {
                    int n = input.nextInt();
                    String potentialURL = input.nextLine();
                    URL u = new URL(potentialURL);
                    String version = hasIP(potentialURL);
                    if(!version.equals("")) {
                        System.out.print(GenerateMatrix(n));
                    }
                    System.out.println(u.getPath() + " " + u.getProtocol() + "\t");
                }

            } catch (FileNotFoundException | MalformedURLException e) {
                System.err.println("Los url " + e.getMessage());
            }
        }

        public String GenerateMatrix(int n) {
            StringBuilder result = new StringBuilder();
            for(int i = 0; i < n; ++i) {
                for(int j = 0; j < n; ++j) {
                    if(i == j){
                        result.append('>');
                    } else result.append('=');
                }
                result.append('\n');
            }
            return result.toString();
        }

        public String hasIP(String u) {
            Pattern pattern = Pattern.compile(".*(\\d+\\.)+(\\d+:)");
            Matcher matcher = pattern.matcher(u);
            if(matcher.find()) {
                return "(v4)";
            }

            return "";
        }

        @Override
        public void run() {
            ProcessFile(this.file);
        }

        private File file;
    }

    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");
        // TODO: why does sftp throw malformed if its a legit protocol?

        File[] files = new File("/home/ispit/Desktop/tests/urls").listFiles();
        assert files != null;

        for(File f : files) {
            MyThread t = new MyThread(f);
            t.start();
            while(t.isAlive())
            { /* (: */ }

        }
    }
}

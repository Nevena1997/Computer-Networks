package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class MyThread extends Thread {
    public String threadarg;

    public MyThread(String arg){
        super(new Thread());
        this.threadarg = arg;
    }

    @Override
    public void run(){
        File f = new File(threadarg);
        String line;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);



        try {
            isr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

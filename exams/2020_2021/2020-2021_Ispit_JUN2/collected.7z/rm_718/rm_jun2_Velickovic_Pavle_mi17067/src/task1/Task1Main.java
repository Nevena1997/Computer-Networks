package task1;

import java.io.*;

public class Task1Main {
    public static void main(String[] args) {
        File f = new File("/home/ispit/Desktop/tests/urls");
        String[] s = f.list();
        for(int i = 0; i<s.length ; i++){
            MyThread tr = new MyThread(s[i]);
        }
    }
}

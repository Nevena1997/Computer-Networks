package task2;

import java.net.*;
import java.io.*;

public class Task2Server {

    public static void main(String[] args) throws IOException {
        ServerSocket sck = new ServerSocket(12321);

        String dirpath = "/home/ispit/Desktop/Kviz";

        Socket sck2 = sck.accept();
    }

}

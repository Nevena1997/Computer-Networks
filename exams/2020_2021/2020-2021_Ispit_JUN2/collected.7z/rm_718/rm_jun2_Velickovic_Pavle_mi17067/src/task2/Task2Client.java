package task2;

import java.net.*;
import java.io.*;

public class Task2Client {

    public static void main(String[] args) throws IOException {
        Socket sck = new Socket("http://localhost", 12321);


    }

}

package task1;

import java.io.IOException;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task1Main extends Thread{
    private Task1Main mainThread;
    private Path filename;

    public Task1Main(Task1Main mainThread, Path filename) {
        if(mainThread != null) {
            this.mainThread = mainThread;
            this.filename = filename;
        }
    }

    public static void main(String[] args) {
        var mainThread = new Task1Main(null, null);
        mainThread.execute();
    }

    private void execute() {
        Path p = Paths.get("/home/ispit/Desktop/tests/urls");
        List<Task1Main> threads = new ArrayList<>();
        try {
            var dirStream = Files.newDirectoryStream(p);
            for(Path file: dirStream) {
                var newThread = new Task1Main(this, file);
                threads.add(newThread);
                newThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        for(var thrd : threads) {
            try {
                thrd.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void run() {
        //TODO
        try {
            var reader = Files.newBufferedReader(filename);
            String line;
            while((line=reader.readLine()) != null) {
                try (Scanner sc = new Scanner(line)) {
                    if(sc.hasNextInt()) {
                        var number = sc.nextInt();
                        if(sc.hasNext()) {
                            var nextLine = sc.nextLine();
                            String result = "";
                            try {
                                URL u = new URL(nextLine);
                                try {
                                    InetAddress address = InetAddress.getByName(u.getHost());
                                    if(!address.getHostAddress().equals(u.getHost())) {
                                        throw new UnknownHostException();
                                    }
                                    for (int i = 0; i < number; i++) {
                                        for (int j = 0; j < number; j++) {
                                            if (j == i) {
                                                result += ">";
                                            } else {
                                                result += "=";
                                            }
                                        }
                                        if(i!=number-1) result += "\n";
                                    }

                                    if (address instanceof Inet4Address)
                                        result += "\n(v4) ";
                                    if (address instanceof Inet6Address)
                                        result += "\n(v6) ";
                                } catch (UnknownHostException ignored) {}

                                result += u.getProtocol() + " " + u.getPath();
                                mainThread.printResult(this, result);
                            } catch (MalformedURLException ignored) {}

                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    synchronized private void printResult(Task1Main thread, String result) {
        System.out.println(result);
    }
}

/*

  5 http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt
  8 http://123.123.123.123:80/dir1/dir2/test.txt
  2 sftp://2001:0db8:85a3:::8a2e:0370:7334/dir1/dir2/test.txt
  14 neispravna linija

*/

package task2;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;

public class Task2ServerThread extends Thread {
    private Task2Server mainServer;
    private Socket client;
    private String username;

    Task2ServerThread(Task2Server mainServer, Socket client) {
        this.mainServer = mainServer;
        this.client = client;
    }

    @Override
    public void run() {
        BufferedReader reader = null;
        PrintWriter writer = null;
        try {
            reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            username = reader.readLine();
            writer = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
            for(Path path: mainServer.quizFiles) {
                writer.println(path.getFileName());
            }
            writer.println("end");
            writer.flush();

            // ucitavanje izbora
            String choice = reader.readLine();
            BufferedReader fileReader = null;
            for(Path p: mainServer.quizFiles) {
                if(p.getFileName().toString().equals(choice)) {
                    fileReader = Files.newBufferedReader(p);
                    break;
                }
            }

            client.setSoTimeout(5000);
            int totalPoints = 0;
            try(Scanner fileScanner = new Scanner(fileReader)) {
                while(fileScanner.hasNextLine()) {
                    String question = fileScanner.nextLine();
                    //TODO fix answer parsing
                    String response = new String(question.substring(0, question.indexOf("?")+1));
                    String correctAnswer = new String(question.substring(question.indexOf("?")+2, question.length()));
                    //pretpostavka da su odgovori jedna rec, nemam vremena da parsiram
                    String answer = new String(correctAnswer.substring(0, correctAnswer.indexOf(" ")));
                    String points = new String(correctAnswer.substring(correctAnswer.indexOf(" ")+1, correctAnswer.length()));

                    writer.println(response);
                    writer.flush();


                    try {
                        String clientAnswer = reader.readLine();
                        if(clientAnswer.equals(answer)) {
                            writer.println("Tacan odgovor. Osvojili ste " + points);
                            totalPoints += Integer.getInteger(points);
                        } else if(clientAnswer.equals("Ne znam")) {
                            writer.println("Niste znali odgovor.");
                        } else {
                            writer.println("Netacan odgovor. Izgubili ste 1 poen.");
                            totalPoints -= 1;
                        }

                    } catch (SocketTimeoutException t) { // ne mogu da se setim kako se zove timeout exception, mozda je ovo?
                        writer.println("Niste stigli da odgovorite na vreme.");
                    }

                }

                writer.println("Kviz je zavrsen!");
                writer.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(reader != null)
                    reader.close();
                if(writer != null)
                  writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task2Server {
    final static int port = 12321;
    public List<Path> quizFiles = new ArrayList<>();
    public List<Task2ServerThread> allThreads = new ArrayList<>();
    public ServerSocket server;

    public static void main(String[] args) {
        Task2Server mainServer = new Task2Server();
        mainServer.execute();
    }


    private void execute() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite putanju do pitanja za kviz: ");
        String path = sc.nextLine();
        try {
            var dirStream = Files.newDirectoryStream(Path.of(path));
            for(Path p: dirStream) {
                quizFiles.add(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try(ServerSocket server = new ServerSocket(port)) {
            while(true) {
                Socket client = server.accept();
                Task2ServerThread clientThread = new Task2ServerThread(this, client);
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        for(var thread: allThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}

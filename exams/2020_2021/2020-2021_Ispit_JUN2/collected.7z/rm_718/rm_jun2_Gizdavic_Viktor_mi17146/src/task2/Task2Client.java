package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Task2Client {
    private String username;

    public static void main(String[] args) {
        Task2Client client = new Task2Client();
        client.execute();
    }

    private void execute() {
        System.out.println("Unesite ime: ");
        Scanner sc = new Scanner(System.in);
        username = sc.nextLine();

        try(Socket client = new Socket(InetAddress.getLocalHost(), Task2Server.port)){
            try(PrintWriter clientWriter = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                BufferedReader clientReader = new BufferedReader(
                        new InputStreamReader(client.getInputStream())))
            {
                clientWriter.println(username);
                clientWriter.flush();

                System.out.println("Izaberite oblast kviza: (puno ime sa .txt)");
                String areaLine;
                while((areaLine = clientReader.readLine()) != null) {
                    if(areaLine.equals("end")) break;
                    System.out.println(areaLine);
                }


                clientWriter.println(sc.nextLine());
                clientWriter.flush();


                while((areaLine = clientReader.readLine()) != null) {
                    // TODO fix flush issue, press enter again after sending answer for next question
                    if(areaLine.equals("Kviz je zavrsen!")) {
                        System.out.println(areaLine);
                        break;
                    }
                    // ispis pitanja
                    System.out.println(areaLine);

                    // ucitavanje odgovora

                    clientWriter.println(sc.nextLine());
                    clientWriter.flush();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        sc.close();
    }
}

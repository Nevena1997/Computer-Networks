package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class URLStream extends URLConnection {
    @Override
    public void connect() throws IOException {
        try (Socket s = new Socket(InetAddress.getLocalHost(), 12321);
             Scanner sc = new Scanner(System.in);
             BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()))){
            String line = sc.nextLine();
            URL url = new URL(line);
            url.getDefaultPort();
            Boolean da = true;
            URLConnection urlConnection = url.openConnection();
            urlConnection.getInputStream();
            String urlL = url.getHost();
            String fileN = url.getFile();

            boolean connected = this.connected;
            if (connected) {

            }

            }


    }



    public URLStream(URL u) {
        super(u);
    }
}

package task3;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Task3Main {

    public static void main(String[] args) {
        try /*(Socket s = new Socket(InetAddress.getLocalHost(), 12345);
             Scanner sc = new Scanner(System.in);
             BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));)*/{
            Scanner sc = new Scanner(System.in);
            System.out.println("unestie url");
            String ulaz = sc.nextLine();
            URL url = new URL(null, ulaz, new Handler());
            URLConnection urlConnection = url.openConnection();
            urlConnection.connect();
            String file = url.getFile();
            String host = url.getHost();
            String path = url.getPath();
            int port = url.getPort();
            File f = new File("/home/ispit/Desktop/kviz");
            System.out.println(f.list());


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Hello from Task3Main");
    }

}

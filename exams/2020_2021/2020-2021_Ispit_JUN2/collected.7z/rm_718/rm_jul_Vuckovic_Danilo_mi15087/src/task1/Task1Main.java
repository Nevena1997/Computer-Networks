package task1;

import java.io.*;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.spi.AbstractResourceBundleProvider;

public class Task1Main implements Runnable{
    private String file;
    private File dir;

    public Task1Main(String file, File dir) {
        this.file = file;
        this.dir = dir;
    }

    public static void main(String[] args) {
        File f = new File("/home/ispit/Desktop/tests/urls/");
        String[] fajlvoi = f.list();




        for (String fajl: fajlvoi) {
       new Thread(new Task1Main(fajl, f)).start();
        }

        System.out.println("Hello from Task1Main");
    }

    @Override
    public void run() {
       try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(this.dir.toString() + "/" + this.file)))){
//        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls/1.txt")))){
            //while (true) {
                //File f = new File("/home/ispit/Desktop/tests/urls/2.txt");
                //System.out.println(f.list());
             String line = reader.readLine();
            //System.out.println("line:  " + line);
            String[] niske = line.split(" ");
            int i = Integer.parseInt(niske[0]);
           //System.out.println(i);
           //for (int j = 0; j < i; j++) {
           //    Character[] jednak =
           //    System.out.println();
           //}
           //String urllll = niske[1];
           //String http = "http";
           //System.out.println(niske[1]);
           //URL url = new URL(niske[1]);
           if (niske[1].startsWith("http") || niske[1].startsWith("https") || niske[1].startsWith("sftp") || niske[1].startsWith("ftp"))
           {
               //System.out.println(i);
               URL url = new URL(niske[1]);
               //System.out.println(url);
               String filename = url.getFile();
               String filename1 = url.getHost();
               String filename2 = url.getPath();
               //System.out.println(filename);
               //System.out.println(filename1);
               //System.out.println(filename2);
               String filename3 = url.getProtocol();
               InetAddress address = InetAddress.getByName(filename1);
               for (int j = 0; j < i; j++) {
                   //System.out.print(">");
                   for (int k = 0; k < i; k++) {
                       if (j == k) {
                           System.out.print(">");
                       } else
                           System.out.print("=");
                   }

                   System.out.println();


               }
               System.out.println("(v" + getVersion(address) + ")" + filename + " " + filename3);

               //System.out.println(filename);
           }




        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static int getVersion(InetAddress adrr) {
        byte[] adres = adrr.getAddress();
        switch (adres.length) {
            case 4: return 4;
            case 16: return 6;
            default: return -1;
        }
    }


}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Task2Server implements Runnable{
    private static Socket s;


    public Task2Server(Socket s) {
        this.s = s;
    }

    public static void main(String[] args) {

        try (ServerSocket serverSocket = new ServerSocket(12321)){
            Socket client = serverSocket.accept();
            new Thread(new Task2Server(client)).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Hello from Task2Server");
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
             Scanner sc = new Scanner(System.in)
             ){

            while (true) {
                System.out.println("ucitajte naziv fajla");
                String naziv_fajla = reader.readLine();
                String naziv = sc.nextLine();
                //BufferedReader reader1 = new BufferedReader(new InputStreamReader(new FileInputStream(naziv)));
                if (naziv_fajla == null) {
                    writer.write(naziv_fajla);
                    writer.newLine();
                    writer.flush();
                    break;
                }
                File f = new File(naziv_fajla);
                if (f == null)
                    break;

                String[] fajlovi = f.list();
                for (String fajl: fajlovi) {
                    System.out.println(fajl);
                }
                //BufferedReader reader1 = new BufferedReader(new InputStreamReader(new FileInputStream(naziv_fajla)));
                //System.out.println(f.list());/home/ispit/Desktop/kviz/Geogradija.txt

                writer.write(naziv_fajla);
                writer.newLine();
                writer.flush();

                wait(5000);
            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

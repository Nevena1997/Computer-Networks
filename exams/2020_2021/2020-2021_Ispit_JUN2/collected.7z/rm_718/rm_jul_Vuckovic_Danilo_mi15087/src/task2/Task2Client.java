package task2;

import task3.Task3Main;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {
        try (Socket client = new Socket(InetAddress.getLocalHost(), 12321);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)){

            while (true) {
                System.out.println("unesite ime klijenta");
                String line = sc.nextLine();
                writer.write(line);
                writer.newLine();
                writer.flush();

                String res = reader.readLine();
                System.out.println(res);

                String odgvor = sc.nextLine();

            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Hello from Task2Client");
    }

}

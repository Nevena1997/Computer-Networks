package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) {

        Path dir_path = Paths.get("..//tests//urls");

        try (DirectoryStream<Path> ds =Files.newDirectoryStream(dir_path)) {
            for (Path p : ds) {
                Thread t = new Thread(new FileWalkerRunnable(p));
                t.start();
                try {
                    t.join();
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

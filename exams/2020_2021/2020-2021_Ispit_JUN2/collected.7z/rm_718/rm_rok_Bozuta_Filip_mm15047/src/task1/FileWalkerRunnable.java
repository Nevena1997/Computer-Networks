package task1;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;

public class FileWalkerRunnable implements Runnable{

    private Path path;

    public FileWalkerRunnable(Path p) {
        this.path = p;;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(path)) {
            while (sc.hasNextLine()) {
                try {
                    String line = sc.nextLine();
                    String[] num_url = line.split(" ");
                    URL url;

                    if (num_url.length > 1) {
                        url = new URL(num_url[1]);
                    } else {
                        continue;
                    }

                    int num = Integer.parseInt(num_url[0]);

                    if (url.getHost() != null) {

                        for (int i = 0; i < num; i++) {
                            for (int j = 0; j < num; j++) {
                                if (i == j) {
                                    System.out.print(">");
                                } else {
                                    System.out.print("=");
                                }
                            }
                            System.out.println();
                        }
                    }

                    System.out.println(path + " " + url.getProtocol());

                } catch (MalformedURLException mue) {
                    continue;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

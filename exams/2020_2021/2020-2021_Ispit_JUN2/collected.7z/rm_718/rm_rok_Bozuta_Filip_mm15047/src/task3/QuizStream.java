package task3;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public class QuizStream extends URLConnection {

    public QuizStream(URL u) {
        super(u);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return super.getInputStream();
    }

    @Override
    public void connect() throws IOException {

        try (Socket socket = new Socket(getURL().getHost(), getURL().getPort());
             BufferedReader sockIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter sockOut = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));) {

            String ime = "moje_ime";

            String oblast = getURL().toString().split("oblast=")[1];

            sockOut.write(ime);
            sockOut.flush();

            sockOut.write(oblast);
            sockOut.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

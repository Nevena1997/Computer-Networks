package task3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class Task3Main {

    public static void main(String[] args) throws MalformedURLException {

        URL url = new URL(null, "quiz::/", new Handler());

        URLConnection urlConnection;
        
        try {
            urlConnection = url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

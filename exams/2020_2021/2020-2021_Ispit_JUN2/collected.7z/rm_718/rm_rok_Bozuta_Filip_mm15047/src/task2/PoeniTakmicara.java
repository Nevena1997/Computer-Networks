package task2;

import java.util.HashMap;
import java.util.Map;

public class PoeniTakmicara {

    private Map<String, Integer> poeni;

    private String prvi_najbolji = null;
    private String drugi_najbolji = null;
    private String treci_najbolji = null;

    public PoeniTakmicara() {
        poeni = new HashMap<String, Integer>();
    }

    public synchronized void dodaj_bodove_za_takmicara(String ime, int bodovi) {

        if (poeni.containsKey(ime)) {
            poeni.put(ime, poeni.get(ime) + bodovi);
        } else {
            poeni.put(ime, bodovi);
        }

        azuriraj_najbolja_tri();
    }

    public synchronized void oduzmi_bod_za_takmicara(String ime) {

        if (poeni.containsKey(ime)) {
            int novi_bodovi = poeni.get(ime) - 1;
            // Pretpostavio sam da broj bodova ne moze biti negativan
            // (Nije ovo slagalica :D)
            if (novi_bodovi < 0) {
                novi_bodovi = 0;
            }
            poeni.put(ime, novi_bodovi);
        } else {
            poeni.put(ime, 0);
        }

        azuriraj_najbolja_tri();
    }

    public synchronized  void izbaci_takmicara(String ime) {
        poeni.remove(ime);
        azuriraj_najbolja_tri();
    }

    private void azuriraj_najbolja_tri() {
        int max_bodova_1 = 0;
        int max_bodova_2 = 0;
        int max_bodova_3 = 0;

        for (Map.Entry<String, Integer> me : poeni.entrySet()) {
            // Ukoliko svi takmicari imaju 0 bodova niko nije najbolji
            if (me.getValue() > 0) {

                if (me.getValue() > max_bodova_1) {
                    max_bodova_1 = me.getValue();
                    prvi_najbolji = me.getKey();
                } else if (me.getValue() > max_bodova_2) {
                    max_bodova_2 = me.getValue();
                    drugi_najbolji = me.getKey();
                } else if (me.getValue() > max_bodova_3) {
                    max_bodova_3 = me.getValue();
                    treci_najbolji = me.getKey();
                }
            }
        }
    }

    public boolean medju_tri_najbolja(String ime) {

        for (Map.Entry<String, Integer> me : poeni.entrySet()) {
            // Ne moze se smatrati da je takmicar medju tri najbolja ako
            // svi takmicari imaju 0 boda
            if (me.getKey().equals(prvi_najbolji) || me.getKey().equals(drugi_najbolji) ||
                    me.getKey().equals(prvi_najbolji)) {
                return true;
            }
        }

        return false;
    }

}

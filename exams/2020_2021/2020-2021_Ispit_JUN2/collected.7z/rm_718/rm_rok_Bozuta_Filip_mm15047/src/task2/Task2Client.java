package task2;

import java.io.*;
import java.net.Socket;
import java.nio.Buffer;
import java.util.SortedMap;

public class Task2Client {

    public static final String HOST = "localhost";
    public static void main(String[] args) {

        try (Socket client = new Socket(HOST, Task2Server.PORT);
             BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));) {

            client.setSoTimeout(5000);
            String ime_klijenta;
            ime_klijenta = userIn.readLine();

            networkOut.write(ime_klijenta);
            networkOut.flush();

            String[] oblasti = networkIn.readLine().split(" ");

            System.out.println("Izaberite jednu od sledecih oblasti:");

            for (String oblast : oblasti) {
                System.out.println(oblast);
            }

            String izabrana_oblast = userIn.readLine();

            networkOut.write(izabrana_oblast);
            networkOut.flush();

            String pitanje = networkIn.readLine();

            while (pitanje != null) {
                System.out.println(pitanje);

                String odgovor = userIn.readLine();

                networkOut.write(odgovor);
                networkOut.flush();

                pitanje = networkIn.readLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

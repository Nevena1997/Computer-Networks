package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task2Server {

    public static final int PORT = 12321;

    public static void main(String[] args) {

        Path dir_path;
        Scanner sc = new Scanner(System.in);

        dir_path = Paths.get(sc.next());

        sc.close();

        PoeniTakmicara poeni = new PoeniTakmicara();

        try (ServerSocket server = new ServerSocket(PORT)){

            while (true) {
                Socket client = server.accept();

                new Thread(new ClientRunnable(client, dir_path, poeni)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

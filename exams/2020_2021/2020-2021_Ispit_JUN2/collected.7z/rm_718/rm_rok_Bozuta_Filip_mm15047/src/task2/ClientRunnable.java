package task2;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;

public class ClientRunnable implements Runnable{

    private Socket client;
    private Path dir_path;

    private PoeniTakmicara poeni;

    public ClientRunnable(Socket c, Path dp, PoeniTakmicara p) {
        this.client = c;
        this.dir_path = dp;
        this.poeni = p;
    }

    @Override
    public void run() {

        try (BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));) {

            String ime_klijenta = networkIn.readLine();

            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir_path)) {

                ArrayList<String> oblasti = new ArrayList<String>();

                for (Path p : ds) {
                    if (p.endsWith(".txt")) {
                        oblasti.add((p.toString().split("."))[0]);
                    }
                }

                String oblasti_str = "";

                for (String oblast : oblasti) {
                    oblasti_str += oblast + " ";
                }

                networkOut.write(oblasti_str);
                networkOut.flush();

                String izabrana_oblast = networkIn.readLine();

                Scanner sc = null;

                for (Path p : ds) {
                    if (p.toString().contains(izabrana_oblast)) {
                        sc = new Scanner(p);
                    }
                }

                if (sc != null) {
                    while (sc.hasNextLine()) {
                        String line = sc.nextLine();
                        String[] pitanje_odgovor = line.split("/? ");
                        String pitanje = pitanje_odgovor[0];

                        networkOut.write(pitanje);
                        networkOut.flush();

                        try {
                            wait(5000);
                        } catch (InterruptedException ine) {
                            ine.printStackTrace();
                        }

                        boolean odustao = false;
                        try {
                            String odgovor = networkIn.readLine();
                            String[] pravi_odgovor_bodovi = pitanje_odgovor[1].split(" ");
                            String pravi_odgovor = pravi_odgovor_bodovi[0];
                            int bodovi = Integer.parseInt(pravi_odgovor_bodovi[1]);

                            if (odgovor.equals("Ne znam")) {
                                networkOut.write("Niste znali tacan odgovor.");
                            } else if (odgovor.equals(pravi_odgovor)) {
                                networkOut.write("Tacan odgovor. Osvojili ste " + bodovi + " poena.");
                                poeni.dodaj_bodove_za_takmicara(ime_klijenta, bodovi);
                            } else {
                                networkOut.write("Netacan odgovor. Izgubili ste 1 poen");
                                poeni.oduzmi_bod_za_takmicara(ime_klijenta);
                            }

                        } catch (SocketTimeoutException ste) {
                            networkOut.write("Niste stigli da odgovorite na vreme.");
                            odustao = true;
                            poeni.izbaci_takmicara(ime_klijenta);
                        }

                        networkOut.flush();
                        networkOut.write("Kviz je zavrsen!");

                        if (!odustao) {
                            if (poeni.medju_tri_najbolja(ime_klijenta)) {
                                networkOut.flush();
                                networkOut.write("Medju najbolja tri ste rezultat iz ove oblasti do sada!");
                            }
                        }
                    }
                    sc.close();
                }

            } catch (IOException ie) {
                ie.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;


import java.io.*;
import java.nio.file.Path;
import java.util.Scanner;


class SongParser implements Runnable{

    private Path path;
    private String keyword;
    private PrintWriter pw;
    SongParser(Path path, String keyword, PrintWriter pw) {
        this.path = path;
        this.keyword = keyword;
        this.pw = pw;
    }

    @Override
    public void run() {

        StringBuilder sb = new StringBuilder("");
        //1. poem title
        String s = path.getFileName().toString();
        int idx_backslash = s.lastIndexOf('\\') + 1;
        int idx_dot = s.lastIndexOf('.');
        String title = s.substring(idx_backslash, idx_dot);
        sb.append(title + "\n");
        //find longest line/count keyword
        int maxLineLen = 0;
        String maxLine = "";
        int keywordCounter = 0;
        try {
            Scanner sc = new Scanner(path);
            while(sc.hasNext()) {
                String line = sc.nextLine();
                if(line.length() > maxLineLen) {
                    maxLineLen = line.length();
                    maxLine = line;
                }
                String[] words = line.split(" ");
                for(String word : words) {
                    if(word.equalsIgnoreCase(keyword))
                        keywordCounter++;
                }
            }
            sb.append(maxLine + "\n");
            sb.append(keywordCounter + "\n");
        } catch (IOException e) {
            System.err.println("Couldn't read file");
            e.printStackTrace();
        }

        synchronized (this.pw) {
            pw.println(sb.toString());
        }
    }
}

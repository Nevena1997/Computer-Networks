package task1;


import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Task1Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String keyword = sc.nextLine();

        try(DirectoryStream<Path> directoryStream =
                    Files.newDirectoryStream(
                            Paths.get("/home/ispit/Desktop/tests/pesme"));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(System.out))
        ) {
            List<Thread> threads = new ArrayList<>();

            for(Path p : directoryStream) {
                Thread t = new Thread(new SongParser(p, keyword, pw));
                threads.add(t);
            }

            for(Thread t : threads)
                t.start();

            for (Thread t: threads)
                t.join();

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

}

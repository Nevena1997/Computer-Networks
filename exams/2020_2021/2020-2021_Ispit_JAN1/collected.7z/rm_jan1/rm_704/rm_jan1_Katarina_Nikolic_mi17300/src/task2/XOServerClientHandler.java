package task2;

import java.net.Socket;

class XOServerClientHandler {
    private Socket socket;

    XOServerClientHandler(Socket socket) {
        this.socket = socket;
    }


    
}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class XOServer {

    private static final int PORT = 12345;
    private static final String HOST = "localhost";

    int port;
    String host;
    private ServerSocket socket;
    int n_clients;
    Socket cl1, cl2;
    char turn;
    Character[] table;

    XOServer(int port, String host) throws IOException {
        this.port = port;
        this.host = host;
        this.socket = new ServerSocket(port);
        this.n_clients = 0;
        this.turn = 'x';
        //init board
        table = new Character[9];
        for(int i = 0; i < 9; i++)
            table[i] = '/';
    }

    void mainLoop() {
        try {
            while(n_clients < 2) {
                if(n_clients == 0) {
                    cl1 = this.socket.accept();
                    System.err.println("prvi klijent povezan");
                    n_clients++;

                }
                else {
                    cl2 = this.socket.accept();
                    n_clients++;
                }
            }
            System.err.println("Imamo dva klijenta! Pocinje igra...");
            //x player: cl1
            //o player: cl2
            while(true) {
                if(!gameOver())
                {if(turn == 'x') {
                   // byte[] msgBuf = (table.toString()).getBytes();
                    //cl1.getOutputStream().write(msgBuf);
                    OutputStreamWriter osw = new OutputStreamWriter(cl1.getOutputStream());
                    osw.write("your turn\n" + boardString());
                    osw.flush();
                    //read move from client
                    InputStreamReader isr = new InputStreamReader(cl1.getInputStream());
                    BufferedReader br = new BufferedReader(isr);
                    String move = br.readLine();
                    //TODO: slucajevi za nevalidne poteze...
                    Integer potez = Integer.parseInt(move.trim());
                    table[potez] = 'X';
                    turn = 'o';
                }
                else {
                    OutputStreamWriter osw = new OutputStreamWriter(cl2.getOutputStream());
                    osw.write("your turn\n" + boardString());
                    osw.flush();

                    InputStreamReader isr = new InputStreamReader(cl2.getInputStream());
                    BufferedReader br = new BufferedReader(isr);
                    String move = br.readLine();
                    //TODO: slucajevi za nevalidne poteze...
                    Integer potez = Integer.parseInt(move.trim());
                    table[potez] = '0';
                    turn = 'x';
                }}

            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    String boardString() {
        StringBuilder sb = new StringBuilder("");
        for(int i = 0; i < 9; i++) {
            sb.append(table[i] + " ");
            if((i+1)%3 == 0)
                sb.append("\n");
        }
        //System.out.println(sb.toString());
        return sb.toString();
    }

    boolean gameOver() {
        boolean noFreeSpaces = true;
        for(int i = 0; i<9; i++) {
            if(table[i] == '/')
                noFreeSpaces = false;
        }

        boolean horizontalMatch = false;
        if((table[0] == table[1] && table[1] == table[2]) || (table[3] == table[4] && table[5] == table[4]) || (table[6] == table[7] && table[7] == table[8]))
            horizontalMatch = true;

        //TODO: vertical match, diagonal match

        return noFreeSpaces || horizontalMatch;

    }

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());
        try {
            XOServer server = new XOServer(PORT, HOST);
            server.mainLoop();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

class UDPClient {
    private static final int PORT = 31415;
    private static final String HOST = "localhost";

    private DatagramSocket clientSocket;
    private int port;
    private String host;
    UDPClient(int port, String host) throws SocketException {
        this.port = port;
        this.host = host;
        this.clientSocket = new DatagramSocket();
    }

    void start() {
        try(Scanner sc = new Scanner(System.in);) {
            Double r = sc.nextDouble();
            byte[] toServer = r.toString().getBytes();
            DatagramPacket req = new DatagramPacket(toServer, toServer.length, InetAddress.getByName(this.host), this.port);
            this.clientSocket.send(req);

            byte[] resBytes = new byte[512];
            DatagramPacket res = new DatagramPacket(resBytes, resBytes.length);
            this.clientSocket.receive(res);
            String msg = new String(resBytes,0, res.getLength());
            System.out.println(msg);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            this.clientSocket.close();
        }
    }

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPClient.class.getName());
        try {
            UDPClient client = new UDPClient(PORT, HOST);
            client.start();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    private static final int PORT = 31415;
    private static final String HOST = "localhost";

    private DatagramSocket serverSocket;

    UDPServer(int port, String host) throws SocketException {
        this.serverSocket = new DatagramSocket(port);
    }

    void mainLoop() {
        try {
            while(true)
                {
                    byte[] buf = new byte[512];
                    DatagramPacket req = new DatagramPacket(buf, buf.length);
                    this.serverSocket.receive(req);
                    String msg;
                    try{
                        double r = Double.parseDouble(new String(buf,0, req.getLength()));

                        if(r < 0)
                            msg = "Neispravan poluprecnik";
                        else
                        {
                            Double area = r*r*3.14;
                            msg = area.toString();
                        }

                    }
                    catch (NumberFormatException e) {
                        msg = "Neispravan format broja";
                    }

                    byte[] resBuf = msg.getBytes();
                    DatagramPacket res = new DatagramPacket(resBuf, resBuf.length, req.getAddress(), req.getPort());
                    this.serverSocket.send(res);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            this.serverSocket.close();
        }
    }

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());
        try {
            UDPServer server = new UDPServer(PORT, HOST);
            server.mainLoop();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

}

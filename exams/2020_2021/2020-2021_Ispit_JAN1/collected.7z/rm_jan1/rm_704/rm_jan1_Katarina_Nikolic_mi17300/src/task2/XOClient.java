package task2;

class XOClient {

    private static final int PORT = 12345;
    private static final String HOST = "localhost";

    int port;
    String host;

    XOClient(int port, String host) {
        this.port = port;
        this.host = host;
    }

    void game() {

    }
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + XOClient.class.getName());


    }

}

package task3;

class UDPClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPClient.class.getName());
    }

}

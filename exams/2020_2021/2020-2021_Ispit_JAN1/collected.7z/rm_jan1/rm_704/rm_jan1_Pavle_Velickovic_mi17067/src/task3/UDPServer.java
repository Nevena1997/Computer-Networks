package task3;

class UDPServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());
    }

}

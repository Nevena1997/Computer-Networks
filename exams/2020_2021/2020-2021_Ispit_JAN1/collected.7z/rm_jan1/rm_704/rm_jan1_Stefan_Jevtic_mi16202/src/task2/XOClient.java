package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {
        //System.out.println("Hello from: " + XOClient.class.getName());


        try(Socket connection = new Socket("localhost", 11345);
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
        ) {


            Scanner sc = new Scanner(System.in);
            while (connection.isConnected()) {
                String playerMove = sc.nextLine();
                bw.write(playerMove);
                bw.flush();

                String serverResponse = br.readLine();
            }


        }
        catch (IOException e) {
            System.err.println("Client failed to connect to server!");
            e.printStackTrace();
        }
    }

}

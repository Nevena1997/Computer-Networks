package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        final int port = 31415;

        try(DatagramSocket datagramSocket = new DatagramSocket()) {

            Scanner sc = new Scanner(System.in);
            double r = sc.nextDouble();

            byte[] requestBuff = ByteBuffer.allocate(8).putDouble(r).array();
            DatagramPacket request = new DatagramPacket(requestBuff, requestBuff.length, InetAddress.getLocalHost(), port);
            datagramSocket.send(request);

            byte[] responseBuffer = new byte[64];
            DatagramPacket response = new DatagramPacket(responseBuffer, responseBuffer.length);
            datagramSocket.receive(response);


            System.out.println(new String(responseBuffer, StandardCharsets.US_ASCII));
        }
        catch (IOException e) {
            System.err.println("Failed to connect to server");
            e.printStackTrace();
        }

    }

}

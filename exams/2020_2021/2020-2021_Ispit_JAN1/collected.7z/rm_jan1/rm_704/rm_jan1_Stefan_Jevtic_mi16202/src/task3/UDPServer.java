package task3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

class UDPServer {
    static final int port = 31415;

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());


        try(DatagramSocket datagramSocket = new DatagramSocket(port)) {

            while (true) {
                DatagramPacket request = new DatagramPacket(new byte[8], 8);
                datagramSocket.receive(request);

                double recivedNumber = ByteBuffer.wrap(request.getData()).getDouble();

                System.out.println(recivedNumber);


                byte[] responseBuff;
                if(recivedNumber < 0)
                    responseBuff = ("Neispravan poluprecnik").getBytes(StandardCharsets.US_ASCII);
                else {
                    double p = recivedNumber * recivedNumber * Math.PI;
                    System.out.println(p);

                    responseBuff = Double.toString(p).getBytes();
                }

                DatagramPacket response = new DatagramPacket(responseBuff, responseBuff.length, request.getAddress(), request.getPort());
                datagramSocket.send(response);

                System.out.println(new String(responseBuff));

            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }



    }



}

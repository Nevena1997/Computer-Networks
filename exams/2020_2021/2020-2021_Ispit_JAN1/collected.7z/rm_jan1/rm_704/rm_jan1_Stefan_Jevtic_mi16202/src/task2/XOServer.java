package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class XOServer {


    static public int[] gameBoard = new int[10];
    private static boolean isGameFinished = false;

    public static void main(String[] args) {
        //System.out.println("Hello from: " + XOServer.class.getName());

        try(ServerSocket server = new ServerSocket(11345);) {

            LinkedList<Socket> players = new LinkedList<>();
            while (true) {

                try {
                    Socket player = server.accept();
                    players.add(player);

                    if(players.size() == 2) {
                        BufferedInputStream playerOneInput = new BufferedInputStream(players.getFirst().getInputStream());
                        BufferedInputStream playerTwoInput = new BufferedInputStream(players.getLast().getInputStream());

                        System.out.println("A game has started");
                        printBoardState();
                        while (!isGameFinished) {

                            int move = readMove(playerOneInput);
                            System.out.println(move);
                            if(isValidMove(move)) {
                                playMove(move, 1);
                                printBoardState();
                                System.out.println("Player one played: " + move);
                            }

                            move = readMove(playerTwoInput);
                            if(isValidMove(move)) {
                                playMove(move, 2);
                                printBoardState();
                                System.out.println("Player two played: " + move);
                            }

                        }






                    }




                }
                catch (IOException e) {

                    //TODO errors, kick players and reset board state

                    System.err.println("Error with one of the players");
                    e.printStackTrace();
                }


            }


        }
        catch (IOException e) {
            System.err.println("Failed to start server");
            e.printStackTrace();
        }
    }

    private static void playMove(int move, int player) {
        System.out.println("MOVE: " + move);
        for (int i = 0; i < gameBoard.length; i++) {
            System.out.println(gameBoard[i]);
        }
        gameBoard[move] = player;
    }

    private static void printBoardState() {
        for (int i = 1; i < gameBoard.length; i++) {
            if(gameBoard[i] == 0) System.out.print("_ ");
            if(gameBoard[i] == 1) System.out.print("X ");
            if(gameBoard[i] == 2) System.out.print("O ");

            if(i % 3 == 0) System.out.println("");
        }
    }

    private static boolean isValidMove(int move) {
        return true;
    }


    static private int readMove(BufferedInputStream inputStream) throws IOException
    {
        byte[] intBuff = new byte[4];

     //   inputStream.read(intBuff, 0, 4);
        return ByteBuffer.wrap(intBuff).getInt();
    }



}

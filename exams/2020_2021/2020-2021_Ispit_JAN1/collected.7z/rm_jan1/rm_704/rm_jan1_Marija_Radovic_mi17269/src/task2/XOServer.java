package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    public static char[][] board;
    private static int playersOnline;
    private static int turn;

    XOServer(){
        this.board = new char[3][3];
        for(int i = 0; i<3;i++){
            for(int j = 0; j<3; j++){
                this.board[i][j] = '-';
            }
        }

        this.playersOnline = 0;
        this.turn = -1;
    }

    static String boardToString(){
        StringBuilder retVal = new StringBuilder();
        for(int i = 0; i<3;i++){
            for(int j = 0; j<3; j++){
                retVal.append(XOServer.board[i][j]);
                retVal.append(" ");
            }
            retVal.append("\n");
        }
        return retVal.toString();
    }

    static void changeState(int nextMove, int player){
        char character = player == 1 ? 'X' : 'O';
        switch (nextMove){
            case 1: XOServer.board[2][0] = character;
                    break;

            case 2: XOServer.board[2][1] = character;
                break;

            case 3: XOServer.board[2][2] = character;
                break;

            case 4: XOServer.board[1][0] = character;
                break;

            case 5: XOServer.board[1][1] = character;
                break;

            case 6: XOServer.board[1][2] = character;
                break;

            case 7: XOServer.board[0][0] = character;
                break;

            case 8: XOServer.board[0][1] = character;
                break;

            case 9: XOServer.board[0][2] = character;
                break;

        }
    }

    static boolean gameEnded(){
        if(XOServer.board[0][0] != '-'){
            char current = XOServer.board[0][0];
            if(XOServer.board[1][1] == current && XOServer.board[2][2] == current)
                return true;
            if(XOServer.board[0][1] == current && XOServer.board[0][2] == current)
                return true;
            if(XOServer.board[1][0] == current && XOServer.board[2][0] == current)
                return true;
        }

        if(XOServer.board[0][1] != '-'){
            char current = XOServer.board[0][1];
            if(XOServer.board[1][1] == current && XOServer.board[2][1] == current)
                return true;

        }

        if(XOServer.board[0][2] != '-'){
            char current = XOServer.board[0][2];
            if(XOServer.board[1][2] == current && XOServer.board[2][2] == current)
                return true;
            if(XOServer.board[1][1] == current && XOServer.board[2][0] == current)
                return true;
        }

        if(XOServer.board[1][0] != '-'){
            char current = XOServer.board[1][0];
            if(XOServer.board[1][1] == current && XOServer.board[1][2] == current)
                return true;
        }

        if(XOServer.board[2][0] != '-'){
            char current = XOServer.board[0][1];
            if(XOServer.board[2][1] == current && XOServer.board[2][2] == current)
                return true;
        }

        return false;
    }

    public static void main(String[] args) {
        try {

            ServerSocket server = new ServerSocket(12345);

            //main server loop

            while(true) {
                XOServer xoServer = new XOServer();

                System.out.println("Waiting for players...");
                Socket player1 = server.accept();
                System.out.println("One more player needed");
                Socket player2 = server.accept();

                BufferedReader fromPlayer1 = new BufferedReader(new InputStreamReader(player1.getInputStream()));
                BufferedReader fromPlayer2 = new BufferedReader(new InputStreamReader(player2.getInputStream()));

                BufferedWriter toPlayer1 = new BufferedWriter(new OutputStreamWriter(player1.getOutputStream()));
                BufferedWriter toPlayer2 = new BufferedWriter(new OutputStreamWriter(player2.getOutputStream()));

                //player1's turn initially
                XOServer.turn = 1;
                XOServer.playersOnline = 2;

                int nextMove;
                String input;

                //main game loop

                while (true) {

                    if (XOServer.gameEnded()) {
                        toPlayer1.write("end");
                        toPlayer1.newLine();
                        toPlayer1.flush();
                        toPlayer2.write("end");
                        toPlayer2.newLine();
                        toPlayer2.flush();

                        fromPlayer1.close();
                        toPlayer1.close();
                        fromPlayer2.close();
                        toPlayer2.close();

                        player1.close();
                        player2.close();
                        playersOnline = 0;
                        break;
                    }

                    //notify players of their turn

                    if(XOServer.turn == 1){
                        toPlayer1.write("yes");
                        toPlayer1.newLine();
                        toPlayer1.flush();
                        toPlayer2.write("no");
                        toPlayer2.newLine();
                        toPlayer2.flush();

                    }
                    else{
                        toPlayer1.write("no");
                        toPlayer1.newLine();
                        toPlayer1.flush();
                        toPlayer2.write("yes");
                        toPlayer2.newLine();
                        toPlayer2.flush();
                    }

                    //send current state
                    String boardString = XOServer.boardToString();
                    System.out.println(boardString);

                    toPlayer1.write(boardString);
                    //toPlayer1.newLine();
                    toPlayer1.flush();

                    toPlayer2.write(boardString);
                    //toPlayer2.newLine();
                    toPlayer2.flush();


                    //read next move and change state
                    if (XOServer.turn == 1) {
                        input = fromPlayer1.readLine();
                        nextMove = Integer.parseInt(input);
                        XOServer.turn = 2;
                        XOServer.changeState(nextMove, 1);
                    } else {
                        input = fromPlayer2.readLine();
                        nextMove = Integer.parseInt(input);
                        XOServer.turn = 1;
                        XOServer.changeState(nextMove, 2);
                    }



                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

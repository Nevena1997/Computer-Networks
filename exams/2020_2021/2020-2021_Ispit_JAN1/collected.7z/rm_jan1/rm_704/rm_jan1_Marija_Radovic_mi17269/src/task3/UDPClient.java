package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

class UDPClient {
    
    public static void main(String[] args) {



        BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in));
        String inputFromUser;
        String inputFromServer;

        try {

            DatagramSocket client = new DatagramSocket();

            //main Client Loop
            while (true) {

                System.out.println("Insert radius of a circle");
                inputFromUser = fromUser.readLine();

                byte[] bufferOut = new byte[16];
                bufferOut = inputFromUser.getBytes(StandardCharsets.UTF_8);
                DatagramPacket forSending = new DatagramPacket(bufferOut, 0, bufferOut.length, InetAddress.getByName("localhost"), 31415);

                client.send(forSending);

                byte[] bufferIn = new byte[16];
                DatagramPacket forReceiving = new DatagramPacket(bufferIn,bufferIn.length);
                client.receive(forReceiving);
                inputFromServer = new String(forReceiving.getData(),0,forReceiving.getLength(),StandardCharsets.UTF_8);

                System.out.println("Area of a circle is: " + inputFromServer);

            }
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;



class XOClient {

    static void readBoard(BufferedReader fromServer) throws IOException {
        StringBuilder acc = new StringBuilder();
        for(int i = 0;i<3;i++){
            acc.append(fromServer.readLine()).append("\n");
        }
        System.out.println(acc.toString());
    }
    
    public static void main(String[] args) {

        try {
            Socket client = new Socket(InetAddress.getByName("localhost"),12345);

            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            String inputFromUser;

            //main game loop
            while (true){

                String shouldPlay = fromServer.readLine();



                if(shouldPlay.equals("end")){
                    fromServer.close();
                    fromUser.close();
                    toServer.close();
                    System.out.println("Game ended");
                    break;
                }

                else if(shouldPlay.equals("yes")){
                    XOClient.readBoard(fromServer);
                    System.out.println("input a move");
                    inputFromUser = fromUser.readLine();
                    toServer.write(inputFromUser);
                    toServer.newLine();
                    toServer.flush();
                }
                else if(shouldPlay.equals("no")){
                    XOClient.readBoard(fromServer);
                    System.out.println("Other player is playing");
                }


            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

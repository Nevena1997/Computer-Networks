package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {

        String inputFromClient;
        String outputForClient;
        double in;
        double out;

        try {
            DatagramSocket server = new DatagramSocket(31415);

            //main server loop
            while(true) {

                byte[] bufferIn = new byte[16];
                DatagramPacket forReceiving = new DatagramPacket(bufferIn, bufferIn.length);
                server.receive(forReceiving);

                inputFromClient = new String(forReceiving.getData(), 0, forReceiving.getLength(), StandardCharsets.UTF_8);
                in = Double.parseDouble(inputFromClient);

                if(in < 0){
                    outputForClient = "Invalid radius";
                }
                else {
                    out = Math.PI * in * in;
                    outputForClient = String.valueOf(out);
                }

                byte[] bufferOut = new byte[16];
                bufferOut = outputForClient.getBytes(StandardCharsets.UTF_8);
                DatagramPacket forSending = new DatagramPacket(bufferOut, 0, bufferOut.length, forReceiving.getAddress(), forReceiving.getPort());
                server.send(forSending);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

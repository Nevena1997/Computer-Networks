package task2;

class XOClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + XOClient.class.getName());
    }

}

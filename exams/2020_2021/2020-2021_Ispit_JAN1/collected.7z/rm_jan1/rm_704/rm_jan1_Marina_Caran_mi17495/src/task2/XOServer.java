package task2;

class XOServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());
    }

}

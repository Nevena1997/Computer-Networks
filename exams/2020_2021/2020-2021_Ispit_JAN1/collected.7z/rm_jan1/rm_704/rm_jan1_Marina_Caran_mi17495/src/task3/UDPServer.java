package task3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {
//        System.out.println("Hello from: " + UDPServer.class.getName());

        try(DatagramSocket server=new DatagramSocket(31415)){
            //prima broj od klijenta i salje mu povrsinu kruga

            while(true){

                byte[] buf=new byte[1024];
                DatagramPacket received=new DatagramPacket(buf,buf.length);
                server.receive(received);

                String num=new String(received.getData(),0,received.getLength(),StandardCharsets.UTF_8);
                Float r=Float.parseFloat(num);

                String pov;
                if(r<0){
                     pov="Neispravan poluprecnik";
                }
                else {

                    Double p = r * r * Math.PI;

                     pov = p.toString();

                }
                byte[] buf2=new byte[1024];
                buf2=pov.getBytes(StandardCharsets.UTF_8);
                DatagramPacket sendP=new DatagramPacket(buf2,buf2.length,received.getAddress(),received.getPort());
                server.send(sendP);



            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

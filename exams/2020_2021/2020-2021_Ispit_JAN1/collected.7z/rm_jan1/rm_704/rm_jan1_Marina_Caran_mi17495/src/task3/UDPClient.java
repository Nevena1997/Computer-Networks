package task3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    //Klijent salje datagram serveru na portu 31415 u kome se nalazi jedan realan broj ucitan sa ulaza
    //salje to serveru i server mu vraca povrsinu kruga

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try(DatagramSocket client=new DatagramSocket()){

            // byte[] buf;
            String line = sc.nextLine();
          //  System.out.println(line);
            byte[] buf = new byte[1024];
            buf = line.getBytes(StandardCharsets.UTF_8);


            InetAddress addr = InetAddress.getByName("localhost");

            DatagramPacket sendNum = new DatagramPacket(buf, buf.length, addr, 31415);
            client.send(sendNum);

            //zatim primimo odgovor

            byte[] buf2 = new byte[1024];
            DatagramPacket received = new DatagramPacket(buf2, buf2.length);
            client.receive(received);

            System.out.println(new String(received.getData(), 0, received.getLength(), StandardCharsets.US_ASCII));


        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Hello from: " + UDPClient.class.getName());
    }

}

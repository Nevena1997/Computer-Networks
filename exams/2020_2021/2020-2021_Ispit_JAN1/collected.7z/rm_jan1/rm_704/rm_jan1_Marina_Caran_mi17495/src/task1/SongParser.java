package task1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;


class SongParser implements Runnable{
    //public static Path end_of_file=Paths.get("");

    private Path end= Paths.get("");
    private BlockingQueue<Path> fileQueue;
    private String word;

    public SongParser(BlockingQueue<Path> fileQueue, String word) {
        this.fileQueue=fileQueue;
        this.word=word;

    }

    @Override
    public synchronized void run(){

            boolean done=false;
            while(done!=true) {
                try {
                    Path p = this.fileQueue.take();

                    if (p == Task1Main.end_of_file) {
                        done = true;
                        this.fileQueue.put(p);
                    } else {
                        this.analyze(p);
                    }

                } catch (InterruptedException | FileNotFoundException e) {
                    e.printStackTrace();
                }
            }

    }

    public synchronized void analyze(Path p) throws FileNotFoundException {
        String p_to_string=p.getFileName().toString();
    //    System.out.println(p_to_string);

       // String name=p_to_string.substring(0,p_to_string.lastIndexOf("."));
      String name=p_to_string.substring(0,p_to_string.indexOf('.'));
        int counter = 0;
        int max_length = 0;
        String max_line = null;
        Scanner sc = new Scanner(new FileInputStream(p.toFile()));

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            int line_length = line.length();
            if (line_length >= max_length) {
                max_length = line_length;
                max_line = line;
            }

            String line_check=line.toLowerCase();
            if (line_check.contains(word.toLowerCase())){
                counter++;
            }

        }
        synchronized (System.out) {
            System.out.println(name);
        System.out.println(max_line);
        System.out.println(counter);
    }
    }

//    boolean ifLineContains(String line, String word){
//        String[] words=line.split(" ");
//        for(int i=0;i<words.length;i++){
//            if(words[i].equalsIgnoreCase(word) || words[i].toLowerCase().contains()) {
//                return true;
//            }
//
//        }
//
//        return false;
//
//
//    }
}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Task1Main {

    public static Path end_of_file=Paths.get("");
    public static void main(String[] args) throws InterruptedException {

        int file_size=10;



        //System.out.println("Hello from: " + Task1Main.class.getName());
        String word;

        Scanner sc=new Scanner(System.in);

        word=sc.next();

        BlockingQueue<Path> fileQueue=new ArrayBlockingQueue<>(10);
        String path_string="/home/ispit/Desktop/tests/pesme";

        Path dir_path= Paths.get(path_string);


        try(DirectoryStream<Path> ds= Files.newDirectoryStream(dir_path)){
            for(Path p:ds){

                fileQueue.put(p);
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        fileQueue.put(end_of_file);

        for(int i=0;i<fileQueue.size();i++){
            new Thread(new SongParser(fileQueue,word)).start();
            try {
                Thread.sleep(1000/fileQueue.size());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


    }

}

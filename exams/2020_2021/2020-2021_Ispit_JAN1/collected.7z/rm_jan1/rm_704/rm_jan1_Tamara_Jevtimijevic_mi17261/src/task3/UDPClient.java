package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket datagramSocket = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){

            datagramSocket.setSoTimeout(5000);
            InetSocketAddress address = new InetSocketAddress(31415);

            while (true) {

                Double poluprecnik = sc.nextDouble();

                String niskaPoluprecnik = String.valueOf(poluprecnik);

                byte[] nizZaSlanje = niskaPoluprecnik.getBytes();

                DatagramPacket saljemPoluprecnik = new DatagramPacket(nizZaSlanje, nizZaSlanje.length, address);
                datagramSocket.send(saljemPoluprecnik);

                DatagramPacket primamOdgovor = new DatagramPacket(new byte[1024], 1024);
                datagramSocket.receive(primamOdgovor);

                String odgovor = new String(primamOdgovor.getData(), 0, primamOdgovor.getLength(), StandardCharsets.UTF_8);
                System.out.println(odgovor);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

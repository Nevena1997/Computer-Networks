package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

class XOServer {

    static final int defaultPort = 12345;
    private Set<Thread> users = Collections.synchronizedSet(new HashSet<>());
    private static String hostName;
    private int port;
    private int i = 0;

    public XOServer(int defaultPort) {
        this.port = defaultPort;
    }

    public static void main(String[] args) {
        XOServer server = new XOServer(defaultPort);
        server.execute();
    }

    private void execute() {

        try(ServerSocket serverSocket = new ServerSocket(this.port)){

            System.out.println("Osluskujem klijente:");

            while(true){
                Socket client = serverSocket.accept();
                Thread user = new XOServerClientHandler(client, this);
                user.start();
                users.add(user);

                i++;
                System.out.println("Nasao sam klijenta #:" + i);

                if(i == 2){
                    System.out.println("Sad pokrecem igru...");
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

class Task1Main {
    
    public static void main(String[] args) {

    }
}

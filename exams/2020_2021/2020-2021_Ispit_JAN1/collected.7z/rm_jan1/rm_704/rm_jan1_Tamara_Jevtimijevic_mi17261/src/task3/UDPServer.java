package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {
        try(DatagramSocket datagramSocket = new DatagramSocket(31415)){

            String niskaZaSlanje = "";

            while(true) {
                DatagramPacket prijemnaPoruka = new DatagramPacket(new byte[1024], 1024);
                datagramSocket.receive(prijemnaPoruka);

                String niskaPoluprecnik = new String(prijemnaPoruka.getData(), 0, prijemnaPoruka.getLength(), StandardCharsets.UTF_8);
                Double poluprecnik = Double.valueOf(niskaPoluprecnik);

                if(poluprecnik < 0){
                    niskaZaSlanje = "Neispavan polupecnik";
                } else{
                    double poluprecnikZaSlanje = poluprecnik*poluprecnik*Math.PI;
                    niskaZaSlanje = (String.valueOf(poluprecnikZaSlanje));
                }

                byte[] ovoSeSalje = niskaZaSlanje.getBytes();

                DatagramPacket porukaZaSlanje = new DatagramPacket(ovoSeSalje, ovoSeSalje.length, prijemnaPoruka.getSocketAddress());
                datagramSocket.send(porukaZaSlanje);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

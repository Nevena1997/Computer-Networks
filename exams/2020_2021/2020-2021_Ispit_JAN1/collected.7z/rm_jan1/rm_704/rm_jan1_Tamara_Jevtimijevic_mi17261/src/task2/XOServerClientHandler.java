package task2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.net.Socket;

class XOServerClientHandler extends Thread {
    private Socket socket;
    private XOServer server;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;

    public XOServerClientHandler(Socket client, XOServer xoServer) {
        this.socket = client;
        this.server = xoServer;
    }

    @Override
    public void run() {
        //TODO
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class XOClient {
    private static InetSocketAddress inetSocketAddress = new InetSocketAddress(12345);
    public static final String adrress = inetSocketAddress.getHostName();
    private int port;
    private String hostName;

    public XOClient(String adrress, int port) {
        this.port = port;
        this.hostName = adrress;
    }

    public static void main(String[] args) {
        XOClient client = new XOClient(adrress, 12345);
        client.execute();
    }

    private void execute() {

        try (Socket socket = new Socket();
             Scanner sc = new Scanner(System.in)) {

            System.out.println("Unesi broj:");
            int broj = sc.nextInt();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

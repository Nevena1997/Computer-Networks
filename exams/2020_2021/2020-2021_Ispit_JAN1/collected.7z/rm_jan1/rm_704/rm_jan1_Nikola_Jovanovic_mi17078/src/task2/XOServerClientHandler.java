package task2;

class XOServerClientHandler {

    public static void main(String[] args) throws InterruptedException {

        XOServer server = new XOServer();
        server.start();

        while (true){

            if(XOServer.endGame) {
                XOServer.endGame = false;

                server.resetTable();
                XOClient player1 = new XOClient("X");

                player1.start();

                XOClient player2 = new XOClient("O");

                player2.start();
            }
        }
    }

}

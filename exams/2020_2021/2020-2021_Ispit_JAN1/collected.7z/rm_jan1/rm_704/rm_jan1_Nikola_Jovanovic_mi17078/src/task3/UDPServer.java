package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

class UDPServer {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPServer.class.getName());

        try(DatagramSocket socket = new DatagramSocket(31415)){

            while (true) {

                byte[] buf1 = new byte[128];
                DatagramPacket dp1 = new DatagramPacket(buf1, buf1.length);
                socket.receive(dp1);

                String input = new String(dp1.getData(), 0, dp1.getLength());
                Double r = Double.valueOf(input);
                Double result = r * r * 3.14;

                byte[] buf2;
                if(r >= 0)
                    buf2 = Double.toString(result).getBytes();
                else
                    buf2 = "Neispravan poluprecnik".getBytes();
                DatagramPacket dp2 = new DatagramPacket(buf2, 0, buf2.length, dp1.getAddress(), dp1.getPort());
                socket.send(dp2);
            }

        }catch (IOException e){
            e.printStackTrace();
        }
    }

}

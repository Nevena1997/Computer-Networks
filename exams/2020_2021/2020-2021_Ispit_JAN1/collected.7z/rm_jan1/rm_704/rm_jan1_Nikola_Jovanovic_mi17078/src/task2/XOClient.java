package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

class XOClient extends Thread{

    public String label;
    public String[] table;
    public String board;

    public XOClient(String label){
        this.label = label;
        this.table = new String[9];
        for(int i = 0; i < 9; i++)
            this.table[i] = "-";
    }

    public void printTable(){
        System.out.println(table[6] + " " + table[7] + " " + table[8]);
        System.out.println(table[3] + " " + table[4] + " " + table[5]);
        System.out.println(table[0] + " " + table[1] + " " + table[2]);
    }

    @Override
    public void run() {
        System.out.println("Hello from: " + XOClient.class.getName() + " IGRAC " + label);

        this.board = "- - -" + "\n" + "- - -" + "\n" + "- - -";

        try(Socket client = new Socket(InetAddress.getLocalHost(), 12345);
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            while (true) {

                if (XOServer.turn.equals(this.label)) {

                    System.out.println(this.board);

                    String input = stdin.readLine();

                    out.write(input);
                    out.newLine();
                    out.flush();

                    String currTable = in.readLine();

                }

            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

    }
}

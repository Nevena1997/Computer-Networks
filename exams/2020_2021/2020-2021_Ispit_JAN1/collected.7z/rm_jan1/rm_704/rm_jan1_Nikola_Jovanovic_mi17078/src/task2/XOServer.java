package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer extends Thread{

    public static String[] table = new String[9];
    public static boolean endGame;
    public static int numOfPlayers = 0;
    public static String turn = "X";

    public XOServer(){
        for(int i = 0; i < 9; i++)
            XOServer.table[i] = "-";
        XOServer.endGame = true;
    }

    public static void resetTable(){
        for(int i = 0; i < 9; i++)
            XOServer.table[i] = "-";
    }

    public static String tableToString(){
        String ret = "";

        ret += XOServer.table[6] + " " + XOServer.table[7] + " " + XOServer.table[8] + '\n';
        ret += XOServer.table[3] + " " + XOServer.table[4] + " " + XOServer.table[5] + '\n';
        ret += XOServer.table[0] + " " + XOServer.table[1] + " " + XOServer.table[2];

        return ret;
    }

    @Override
    public void run() {
        System.out.println("Hello from: " + XOServer.class.getName());

        resetTable();

        try(ServerSocket server = new ServerSocket(12345)){

            while (true){

                Socket client1 = server.accept();
                Socket client2 = server.accept();


                try(BufferedReader in1 = new BufferedReader(new InputStreamReader(client1.getInputStream()));
                    BufferedReader in2 = new BufferedReader(new InputStreamReader(client2.getInputStream()));
                    BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(client1.getOutputStream()));
                    BufferedWriter out2 = new BufferedWriter(new OutputStreamWriter(client2.getOutputStream()))){

                    while(true){

                        int pos = Integer.parseInt(in1.readLine());

                        System.out.println("Server procitao: " + pos);
                        XOServer.table[pos-1] = "X";

                        out1.write(XOServer.tableToString());
                        out1.newLine();
                        out1.flush();
                        XOServer.turn = "O";

                        //check endgame

                        pos = Integer.parseInt(in2.readLine());

                        XOServer.table[pos-1] = "O";

                        out2.write(XOServer.tableToString());
                        out2.newLine();
                        out2.flush();

                        //check endgame

                    }

                }catch (IOException e){
                    e.printStackTrace();
                }

            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {


    }

}

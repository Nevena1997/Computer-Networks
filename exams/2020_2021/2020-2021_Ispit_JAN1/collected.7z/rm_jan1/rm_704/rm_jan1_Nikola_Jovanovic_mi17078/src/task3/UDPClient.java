package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try(DatagramSocket socket = new DatagramSocket();
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in))){


            while (true) {
                byte[] buf1;
                buf1 = stdin.readLine().getBytes();
                DatagramPacket dp1 = new DatagramPacket(buf1, 0, buf1.length, new InetSocketAddress("localhost", 31415));
                socket.send(dp1);

                byte[] buf2 = new byte[128];
                DatagramPacket dp2 = new DatagramPacket(buf2, buf2.length);
                socket.receive(dp2);

                String res = new String(dp2.getData(), 0, dp2.getLength());
                System.out.println(res);
            }

        }catch (IOException e){
            e.printStackTrace();
        }
    }

}

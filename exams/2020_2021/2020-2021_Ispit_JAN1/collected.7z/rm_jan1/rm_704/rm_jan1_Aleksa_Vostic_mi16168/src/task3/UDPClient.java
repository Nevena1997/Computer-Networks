package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket dsClient = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            System.out.print("Unesite poluprecnik (r):\t");
            String poluprecnik = sc.next();
            byte[] data = poluprecnik.trim().getBytes();

            DatagramPacket toServer = new DatagramPacket(data,
                                                         data.length,
                                                         InetAddress.getByName("localhost"),
                                                         UDPServer.PORT);
            DatagramPacket fromServer = new DatagramPacket(new byte[1024], 1024);
            dsClient.send(toServer);
            dsClient.receive(fromServer);

            String result = new String(fromServer.getData(), 0, fromServer.getLength(), StandardCharsets.UTF_8);
            if (result.contains("Neispravan"))
            {
                System.err.println(result);
            }
            else
            {
                System.out.println("Povrsina kruga je:\t" + result);
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

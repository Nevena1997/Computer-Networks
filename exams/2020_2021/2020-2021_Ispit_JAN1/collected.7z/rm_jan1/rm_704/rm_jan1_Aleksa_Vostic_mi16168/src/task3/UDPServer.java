package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    public static final int PORT = 31415;
    
    public static void main(String[] args) {
        try(DatagramSocket dsServer = new DatagramSocket(PORT)) {

            while (true) {
                DatagramPacket fromClient = new DatagramPacket(new byte[1024], 1024);
                dsServer.receive(fromClient);

                String poluprecnik = new String(fromClient.getData(), 0,
                        fromClient.getLength(), StandardCharsets.UTF_8);

                String povrsina = PovrsinaKruga(poluprecnik);
                byte[] data = povrsina.getBytes();

                DatagramPacket toServer = new DatagramPacket(data,
                        data.length,
                        fromClient.getAddress(),
                        fromClient.getPort());
                dsServer.send(toServer);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String PovrsinaKruga(String poluprecnik) {
        double pp = Double.parseDouble(poluprecnik);
        if (pp < 0)
            return "Neispravan poluprecnik";
        return Double.toString(pp*pp*Math.PI);
    }

}

package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {
        boolean gameOver = false;
        try(Socket client = new Socket("localhost", 12345);
            Scanner sc = new Scanner(System.in);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {
            while (!gameOver)
            {
                String serverKaze = fromServer.readLine();
                //System.out.println(serverKaze); debugger
                if (serverKaze == null)
                    continue;
                if (serverKaze.equals("over"))
                {
                    gameOver = true;
                }
                else if (serverKaze.equals("you"))
                {
                    String kazeServer1 = fromServer.readLine();
                    String kazeServer2 = fromServer.readLine();
                    String kazeServer3 = fromServer.readLine();
                    System.out.println(kazeServer1 + "\n" + kazeServer2 + "\n" + kazeServer3);
                    System.out.print("> ");
                    String potez = sc.next();
                    toServer.write(potez);
                    toServer.newLine();
                    toServer.flush();
                }
                else if (serverKaze.equals("win"))
                {
                    String kazeServer1 = fromServer.readLine();
                    String kazeServer2 = fromServer.readLine();
                    String kazeServer3 = fromServer.readLine();
                    System.out.println(kazeServer1 + "\n" + kazeServer2 + "\n" + kazeServer3);
                    System.out.println("Pobedio sam!");
                }
                else if (serverKaze.equals("lose"))
                {
                    String kazeServer1 = fromServer.readLine();
                    String kazeServer2 = fromServer.readLine();
                    String kazeServer3 = fromServer.readLine();
                    System.out.println(kazeServer1 + "\n" + kazeServer2 + "\n" + kazeServer3);
                    System.out.println("Izgubio sam:(");
                }
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

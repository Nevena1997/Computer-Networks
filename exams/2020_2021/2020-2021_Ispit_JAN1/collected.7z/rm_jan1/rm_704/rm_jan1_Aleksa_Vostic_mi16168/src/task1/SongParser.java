package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Scanner;

class SongParser implements Runnable{

    private final Path path;
    private final String keyword;

    public SongParser(Path path, String keyword) {
        this.path = path;
        this.keyword = keyword;
    }

    @Override
    public void run() {
        try {
            // mozda bih mogao preko synchronized ili lockova da zastitim ispis, odnosno zakljucam dok neka nit pise
            // medjutim ovako mi je dosta brze da napravim jedan veliki string i to ispisujem na ekran i samim tim
            // se niti ne preplicu
            String ispis = "\t" + nazivPesme(this.path.toString());
            String[] najBroj = najduziStihBrojac(this.path, this.keyword);
            ispis += "\n\t" + najBroj[0] + "\n\t" + najBroj[1];
            System.out.println(ispis);
        } catch (FileNotFoundException e) {
            System.err.println("Datoteka ne postoji na putanji " + this.path.toString());
            e.printStackTrace();
        }
    }

    private static String nazivPesme(String s) {
        int kosa = s.lastIndexOf('/') + 1;
        int tacka = s.lastIndexOf('.');
        return s.substring(kosa, tacka);
    }

    private static String[] najduziStihBrojac(Path path, String keyword) throws FileNotFoundException {
        Scanner fileR = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(path.toFile()))));
        int duzinaLinije = 0;
        int i = 0;
        keyword = keyword.toLowerCase();
        String najduzaLinija = "";
        while (fileR.hasNextLine())
        {
            String line = fileR.nextLine();
            if (line.toLowerCase().contains(keyword))
            {
                i++;
            }
            if(line.length() > duzinaLinije)
            {
                duzinaLinije = line.length();
                najduzaLinija = line;
            }
        }

        String[] result = new String[2];
        result[0] = najduzaLinija;
        result[1] = Integer.toString(i);

        return result;
    }
}

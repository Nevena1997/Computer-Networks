package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class XOServer {
    public static void main(String[] args) {
        List<Socket> players = Collections.synchronizedList(new LinkedList<>());
        try(ServerSocket server = new ServerSocket(12345)) {
            do {
                Socket accept = server.accept();
                players.add(accept);
            } while (players.size() != 2);

            System.out.println("Usla su dva igraca! Inicijalizujem igru");
            sendToClient(players.get(0), "Igra pocinje!");
            sendToClient(players.get(1), "Igra pocinje!");
            int igrac = 0;
            boolean gameOver = false;
            String test = "---\n---\n---";
            char[] playground = test.toCharArray();
            while (!gameOver) {
                if (igrac == 0)
                {
                    sendToClient(players.get(0), "you");
                    sendToClient(players.get(0), Arrays.toString(playground));
                    String move = readFromClient(players.get(0));
                    System.out.println("Igrao je igrac 0");
                    odigrajPotez(playground, igrac, move);
                    boolean win = pobednikJe(playground);
                    if (win) {
                        sendToClient(players.get(0), "win");
                        sendToClient(players.get(0), Arrays.toString(playground));
                        sendToClient(players.get(1), "lose");
                        sendToClient(players.get(1), Arrays.toString(playground));
                        gameOver = true;
                    }
                    // nakon odigranog poteza, trebao bi da testiram playground da li ima pobednika
                    // i ukoliko ima poslati igracima poruku da je kraj, ne mogu da stignem da implementiram
                    igrac = 1;
                }
                else
                {
                    sendToClient(players.get(1), "you");
                    sendToClient(players.get(1), Arrays.toString(playground));
                    String move = readFromClient(players.get(1));
                    System.out.println("Igrao je igrac 1");
                    if (!odigrajPotez(playground, igrac, move))
                        continue;

                    boolean win = pobednikJe(playground);
                    if (win) {
                        sendToClient(players.get(1), "win");
                        sendToClient(players.get(1), Arrays.toString(playground));
                        sendToClient(players.get(0), "lose");
                        sendToClient(players.get(0), Arrays.toString(playground));
                        gameOver = true;
                    }
                    // nakon odigranog poteza, trebao bi da testiram playground da li ima pobednika
                    // i ukoliko ima poslati igracima poruku da je kraj, ne mogu da stignem da implementiram
                    igrac = 0;
                }
            }
            sendToClient(players.get(1), "over");
            sendToClient(players.get(0), "over");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean pobednikJe(char[] playground) {
        // iskreno mrzi me
        if (playground[0] == playground[1] && playground[0] == playground[2] && playground[0] != '-')
            return true;
        if (playground[4] == playground[5] && playground[4] == playground[6] && playground[4] != '-')
            return true;
        if (playground[8] == playground[9] && playground[8] == playground[10] && playground[10] != '-')
            return true;
        if (playground[0] == playground[4] && playground[0] == playground[8] && playground[8] != '-')
            return true;
        if (playground[1] == playground[5] && playground[1] == playground[9] && playground[9] != '-')
            return true;
        if (playground[2] == playground[6] && playground[2] == playground[10] && playground[6] != '-')
            return true;
        if (playground[0] == playground[5] && playground[0] == playground[8] && playground[5] != '-')
            return true;
        if (playground[2] == playground[4] && playground[2] == playground[9] && playground[2] != '-')
            return true;

        return false;
    }

    private static boolean odigrajPotez(char[] playground, int igrac, String potez) {
        // Ovde bi sad trebao da proveravam ukoliko je vec X/O na toj poziciji, reci mu da igra ponovo
        // ako stignem implementiracu
        switch (potez.trim())
        {
            case "1":
                if (igrac == 0)
                    playground[0] = 'X';
                else
                    playground[0] = 'O';
                break;
            case "2":
                if (igrac == 0)
                    playground[1] = 'X';
                else
                    playground[1] = 'O';
                break;
            case "3":
                if (igrac == 0)
                    playground[2] = 'X';
                else
                    playground[2] = 'O';
                break;
            case "4":
                if (igrac == 0)
                    playground[4] = 'X';
                else
                    playground[4] = 'O';
                break;
            case "5":
                if (igrac == 0)
                    playground[5] = 'X';
                else
                    playground[5] = 'O';
                break;
            case "6":
                if (igrac == 0)
                    playground[6] = 'X';
                else
                    playground[6] = 'O';
                break;
            case "7":
                if (igrac == 0)
                    playground[8] = 'X';
                else
                    playground[8] = 'O';
                break;
            case "8":
                if (igrac == 0)
                    playground[9] = 'X';
                else
                    playground[9] = 'O';
                break;
            case "9":
                if (igrac == 0)
                    playground[10] = 'X';
                else
                    playground[10] = 'O';
                break;
            default:
                return false;
        }
        return true;
    }

    private static String readFromClient(Socket socket) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            return reader.readLine();
        }
        catch (IOException e) {
            e.printStackTrace();
            return "IOBugged";
        }
    }

    private static void sendToClient(Socket socket, String s) {
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.write(s);
            writer.newLine();
            writer.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

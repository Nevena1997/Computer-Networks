package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Array;
import java.util.Scanner;

class Task1Main {

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
             DirectoryStream<Path> paths = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"));) {
            System.out.print("Ulaz:\t");
            String keyword = sc.next();

            System.out.println("Izlaz:");
            for (Path p : paths) {
                new Thread(new SongParser(p, keyword)).start();
            }
        } catch (IOException e) {
            //Posto sam ubacio u () zagrade try, oni ce se zatvoriti ako dodje do problema
            System.out.println("Problem sa ulazom/izlazom");
            e.printStackTrace();
        }
    }
}
package task2;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    public static String host = "localhost";
    public static int port = 12345;

    private int potez;
    char[]  stanjeIgre;

    public synchronized void prepustiPotez(int zavrsio){
        if(zavrsio == 1)
            this.potez = 2;
        if(zavrsio == 2)
            this.potez = 1;
    }

    public synchronized char[] stanjeIgre(){
        return stanjeIgre;
    }

    public synchronized void odigrajPotez(Integer polje, char znak){
        stanjeIgre[polje] = znak;
    }

    public int getPotez() {
        return potez;
    }

    public void startServer(){

        try(ServerSocket server = new ServerSocket(XOServer.port)) {

            System.out.println("Server started!");

            while (true){

                Socket client1 = server.accept();
                Socket client2 = server.accept();

                Thread c1 = new XOServerClientHandler(client1, "X", this);
                Thread c2 = new XOServerClientHandler(client2, "O", this);

                //inicijalizujemo stanje
                this.potez = 1;
                this.stanjeIgre = new char[9];
                for (int i = 0; i < 9; i++) {
                    this.stanjeIgre[i] = '-';
                }

                c1.start();
                c2.start();

                try {
                    c1.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try {
                    c2.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public static void main(String[] args) {

        System.out.println("Hello from: " + XOServer.class.getName());
        XOServer server = new XOServer();
        server.startServer();

    }

}

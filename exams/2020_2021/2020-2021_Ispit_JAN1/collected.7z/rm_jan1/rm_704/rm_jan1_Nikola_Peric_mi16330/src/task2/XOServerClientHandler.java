package task2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

class XOServerClientHandler extends Thread {

    private Socket client;
    private XOServer server;
    private int brojIgraca;
    private char znak;
    private StringBuilder stanjeIgre;

    public XOServerClientHandler(Socket s, String znak, XOServer server){
        this.client = s;
        if(znak.equalsIgnoreCase("X")) {
            this.brojIgraca = 1;
            this.znak = 'X';
        }
        if(znak.equalsIgnoreCase("O")) {
            this.brojIgraca = 2;
            this.znak = 'O';
        }
        this.server = server;
    }

    @Override
    public void run() {

        try {
            BufferedReader fromCLient = new BufferedReader(
                    new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));

            BufferedWriter toClient = new BufferedWriter(
                    new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));

            //slanje inicijalnog stanj igra igracima
            String inicijalnoStanje = stanje();
            toClient.write(inicijalnoStanje);
            toClient.flush();

            //TODO petlja ce ici dok se igra ne zavrsi
            while (true){

                if(brojIgraca == server.getPotez()){

                    String stanje = stanje();
                    toClient.write(inicijalnoStanje);
                    toClient.newLine();
                    toClient.flush();

                    String odigranPotez = fromCLient.readLine().strip();

                    Integer polje = Integer.parseInt(odigranPotez);

                    server.odigrajPotez(polje, znak);

                    server.prepustiPotez(this.brojIgraca);

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }//run


    private String stanje(){

        char[] si = server.stanjeIgre();
        this.stanjeIgre = new StringBuilder();

        for (int i = 0; i < si.length; i++) {
            this.stanjeIgre.append(si[i]);
        }
        return this.stanjeIgre.toString();
    }
}

package task1;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Task1Main {

    public void stampajInformacije(String naziv, String najduziStih, int brojPojavljvanja){
        synchronized (System.out){
            System.out.println(naziv);
            System.out.println(najduziStih);
            System.out.println(brojPojavljvanja);
        }
    }


    public static void main(String[] args) {

        System.out.println("Hello from: " + Task1Main.class.getName());

        try {
            File dir = new File("/home/ispit/Desktop/tests/pesme");

            String[] pesme = dir.list();


            Scanner sc = new Scanner(System.in);
            System.out.print("Ulaz: ");
            String rec = sc.next();

            Task1Main obj = new Task1Main();

            Thread[] niti = new Thread[pesme.length];
            for (int i = 0; i < pesme.length; i++) {
                Thread t = new SongParser(rec, pesme[i], obj);
                niti[i] = t;
                niti[i].start();
            }

            for (int i = 0; i < pesme.length; i++) {
                try {
                    niti[i].join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }



        }catch (NullPointerException e){
            System.out.println("Not a directory!");
        }




    }

}

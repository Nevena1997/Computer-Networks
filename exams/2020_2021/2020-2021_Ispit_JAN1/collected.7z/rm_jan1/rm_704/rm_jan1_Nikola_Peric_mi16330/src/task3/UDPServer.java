package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

class UDPServer {

    public static String host = "localhost";
    public static int port = 31415;

    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPServer.class.getName());


        try (DatagramSocket server = new DatagramSocket(new InetSocketAddress(UDPServer.host, UDPServer.port))) {

            byte[] req = new byte[512];

            DatagramPacket request = new DatagramPacket(req, req.length);

            try {

                server.receive(request);

                String brojStr = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);


                String rezultat;

                Double poluprecnik = Double.parseDouble(brojStr);

                //System.out.println("Primljen je broj: " + poluprecnik);

                if(poluprecnik < 0){
                    rezultat = "Neispravan poluprecnik";
                }else {
                    Double povrsina = Math.PI * Math.pow(poluprecnik, 2);
                    rezultat = povrsina.toString();
                }

                DatagramPacket response = new DatagramPacket(rezultat.getBytes(), rezultat.length(),
                        request.getAddress(), request.getPort());

                //System.out.println("Salje se: " + rezultat);

                server.send(response);

            } catch (IOException e) {
                e.printStackTrace();
                server.close();
            }


        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

}

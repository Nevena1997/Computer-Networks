package task2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());

        try (Socket client = new Socket("localhost", 12345);){

            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));

            String res;
            while ((res = fromServer.readLine()) != null){

                char[] dobijenoStanje = res.toCharArray();
                for (int i = 0; i < dobijenoStanje.length; i++) {
                    System.out.print(dobijenoStanje[i] + " ");
                    if(i == 2 || i == 5 || i == 8)
                        System.out.print("\n");
                }

                Scanner sc = new Scanner(System.in);
                Integer potez = sc.nextInt();

                toServer.write(potez.toString());
                toServer.newLine();
                toServer.flush();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

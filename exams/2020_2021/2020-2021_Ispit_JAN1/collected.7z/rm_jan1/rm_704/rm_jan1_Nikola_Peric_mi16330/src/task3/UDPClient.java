package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.zip.CheckedOutputStream;

class UDPClient {

    public static String host = "localhost";
    public static int port = 31415;
    public static int MAX_RES_SIZE = 512;

    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try (DatagramSocket client = new DatagramSocket()) {

            Scanner sc = new Scanner(System.in);
            System.out.print("Uneti realan broj: ");
            float broj;
            broj = sc.nextFloat();
            Float Broj = broj;
            String BrojStr = Broj.toString();



            try {

                InetAddress add = InetAddress.getByName(UDPClient.host);

                byte[] podaci = BrojStr.getBytes();

                DatagramPacket request = new DatagramPacket(podaci, podaci.length, add, UDPClient.port);

                try {

                    client.send(request);

                    byte[] res = new byte[MAX_RES_SIZE];
                    DatagramPacket response = new DatagramPacket(res, res.length);

                    client.receive(response);

                    String odgovor = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);

                    System.out.println("Odgovor od servera: " + odgovor);


                } catch (IOException e) {
                    e.printStackTrace();
                    client.close();
                }


            } catch (UnknownHostException e) {
                e.printStackTrace();
                client.close();
            }


        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

}

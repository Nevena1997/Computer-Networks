package task1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

class SongParser extends Thread{

    private String nazivPesme;
    private String rec;
    private Task1Main o;

    public SongParser(String rec, String nazivPesme, Task1Main o){
        this.rec = rec;
        this.nazivPesme = nazivPesme;
        this.o = o;
    }

    @Override
    public void run() {

        String nazivBezEkst = nazivPesme.substring(0, nazivPesme.indexOf("."));

        try {

            String bazaPutanje = "/home/ispit/Desktop/tests/pesme/";
            FileInputStream file = new FileInputStream(bazaPutanje + nazivPesme);

            Scanner sc = new Scanner(file);

            String najduziStih = "";
            int brojPojavljivanja = 0;


            while (sc.hasNextLine()){

                String linija = sc.nextLine();

                if(linija.length() > najduziStih.length())
                    najduziStih = linija;

                String[] reciLinije = linija.split(" ");
                for (int i = 0; i < reciLinije.length; i++) {
                    if(reciLinije[i].strip().equalsIgnoreCase(rec))
                        brojPojavljivanja++;
                }
            }

            o.stampajInformacije(nazivBezEkst, najduziStih, brojPojavljivanja);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}

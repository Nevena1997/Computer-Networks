package task3;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

class UDPServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());

         try(DatagramSocket sc = new DatagramSocket(31415)) {

             while(true) {

                 byte[] broj = new byte[256];
                 DatagramPacket packet = new DatagramPacket(broj, broj.length);
                 sc.receive(packet);

                 String s = new String(packet.getData(), 0, packet.getLength());


                 double r = Double.parseDouble(s);
                 double p = r * r * 3.14;

                 String pov = Double.toString(p);
                 byte[] povrsina = pov.getBytes();
                 DatagramPacket packet1 = new DatagramPacket(povrsina,povrsina.length, packet.getAddress(),packet.getPort());

                 sc.send(packet1);
             }

           } catch (SocketException e) {
             e.printStackTrace();
         } catch (IOException e) {
             e.printStackTrace();
         }


    }

}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.Set;

class XOServerClientHandler {

    Socket igrac1;
    Socket igrac2;
    ServerSocket server;
    XOServer s;


    public XOServerClientHandler(Set<Socket> igraci, ServerSocket sc, XOServer s) {
        Iterator<Socket> it = igraci.iterator();
        this.igrac1 = it.next();
        this.igrac2 = it.next();
        this.server = sc;
        this.s = s;
    }


    public void startGame() {

        try (BufferedReader in1 = new BufferedReader(new InputStreamReader(this.igrac1.getInputStream()));
             BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(this.igrac1.getOutputStream()));
             BufferedReader in2 = new BufferedReader(new InputStreamReader(this.igrac2.getInputStream()));
             BufferedWriter out2 = new BufferedWriter(new OutputStreamWriter(this.igrac2.getOutputStream()))){



            String stanje = "---------";

            while(stanje.indexOf("-") != -1) {

                //ispisi oboma stanje
                out1.write(stanje);
                out1.newLine();
                out1.flush();
                out2.write(stanje);
                out2.newLine();
                out2.flush();

                //uzmi potez prvog igraca
                while (true) {
                    int pozicija1 = Integer.parseInt(in1.readLine()) - 1;
                    System.out.println(pozicija1);
                    if (pozicija1 < 0 || pozicija1 > 8) {
                        //posalji mu poruku o gresci i trazi da upise nov
                        out1.write("Nevalidan potez");
                        out1.newLine();
                        out1.flush();
                    } else {
                        String novo = stanje.substring(0, pozicija1) + "x" + stanje.substring(pozicija1 + 1, stanje.length());
                        stanje = novo;
                        break;
                    }

                }

                 if(stanje.indexOf("-") != -1){
                //uzmi potez drugog igraca
                while (true) {
                    int pozicija2 = Integer.parseInt(in2.readLine()) - 1;
                    System.out.println(pozicija2);
                    if (pozicija2 < 0 || pozicija2 > 8) {
                        //posalji mu poruku o gresci i trazi da upise nov
                        out1.write("Nevalidan potez");
                        out1.newLine();
                        out1.flush();
                    } else {
                        String novo = stanje.substring(0, pozicija2) + "o" + stanje.substring(pozicija2 + 1, stanje.length());
                        stanje = novo;
                        break;
                    }

                }

            }
            }

           s.start = false;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

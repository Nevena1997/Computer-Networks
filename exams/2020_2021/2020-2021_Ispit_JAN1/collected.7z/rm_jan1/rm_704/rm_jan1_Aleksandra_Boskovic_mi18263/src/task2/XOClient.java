package task2;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());

        try(Socket sc = new Socket("localhost",12345);
            Scanner scanner = new Scanner(System.in);
            BufferedReader in = new BufferedReader(new InputStreamReader(sc.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sc.getOutputStream()))) {


            while(true) {
                //ucitavamo tablu
                String stanje = in.readLine();

                System.out.println(stanje.substring(0, 3));
                System.out.println(stanje.substring(3, 6));
                System.out.println(stanje.substring(6, 9));

                String pozicija = scanner.next();

                out.write(pozicija);
                out.newLine();
                out.flush();

            }




        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

package task1;

import java.io.*;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.SplittableRandom;

class SongParser extends Thread{

    Path file;
    String naziv;
    int najduzaLinija;
    int brPojavljivanja;
    String najduziStih;
    String rec;

    public SongParser(Path file,String rec) {
        this.file = file;
        String string_file =  file.toString();
        this.naziv = string_file.substring(6,string_file.length()-4);
        this.najduzaLinija = 0;
        this.brPojavljivanja = 0;
        this.rec = rec;
        this.najduziStih = "";
    }


    @Override
    public void run() {

      try (Scanner in = new Scanner(new FileInputStream("pesme/"+this.naziv+".txt"))){
          String linija;
          while(in.hasNextLine()){
              linija = in.nextLine();
              if(this.najduzaLinija < linija.length()){
                  this.najduzaLinija = linija.length();
                  this.najduziStih = linija;
              }
             String[] reci = linija.split(" ");
             // System.out.println(reci.length);
              if(reci.length > 0){
                  for (int i = 0 ; i < reci.length ; i++){
                     // System.out.println(reci[i]);
                      if(reci[i].trim().toLowerCase().startsWith(this.rec)){
                          this.brPojavljivanja++;
                      }
                  }
              }
          }

      } catch (FileNotFoundException e) {
          e.printStackTrace();
      } catch (IOException e) {
          e.printStackTrace();
      }
        System.out.println(this.naziv);
        System.out.println(this.najduziStih);
        System.out.println(this.brPojavljivanja);
    }
}

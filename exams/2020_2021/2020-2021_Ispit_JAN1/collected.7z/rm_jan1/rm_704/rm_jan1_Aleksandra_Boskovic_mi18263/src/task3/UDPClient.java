package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.channels.DatagramChannel;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try(DatagramSocket sc = new DatagramSocket();
            Scanner scanner = new Scanner(System.in)){

            String r = scanner.next();

            byte[] bf = r.getBytes();

            DatagramPacket packet = new DatagramPacket(bf,bf.length, InetAddress.getByName("localhost"),31415);

            sc.send(packet);

            byte[] bf2 = new byte[8];
            DatagramPacket packet1 = new DatagramPacket(bf2,bf2.length);

            sc.receive(packet1);

            String povrsina = new String(packet1.getData(),0,packet1.getLength());

            System.out.println(povrsina);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

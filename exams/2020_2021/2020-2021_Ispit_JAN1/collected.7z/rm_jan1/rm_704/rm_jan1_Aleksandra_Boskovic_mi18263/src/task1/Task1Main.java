package task1;

import java.io.File;
import java.io.IOError;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.Set;

class Task1Main {
    
    public static void main(String[] args)  {


        try {


            System.out.println("Hello from: " + Task1Main.class.getName());

            Scanner sc = new Scanner(System.in);

            String rec = sc.next();

            DirectoryStream<Path> pesme = Files.newDirectoryStream(Paths.get("pesme"));

            for(Path file : pesme){

              SongParser nit = new SongParser(file,rec);
                      nit.start();
                      nit.join();


            }

            sc.close();

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }




    }
}

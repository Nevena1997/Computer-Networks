package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;

class XOServer {

    boolean start ;

    XOServer(){
        this.start = false;
    }
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOServer.class.getName());

        XOServer s = new XOServer();

        try(ServerSocket sc = new ServerSocket(12345)){

          Set<Socket> igraci = new HashSet<>();

          //boolean start = false;

            while(true){

                if(!s.start) {
                    if (igraci.size() == 2) {
                       XOServerClientHandler xo = new XOServerClientHandler(igraci,sc,s);
                       xo.startGame();
                        s.start = true;
                    }

                    Socket client = sc.accept();
                    igraci.add(client);
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

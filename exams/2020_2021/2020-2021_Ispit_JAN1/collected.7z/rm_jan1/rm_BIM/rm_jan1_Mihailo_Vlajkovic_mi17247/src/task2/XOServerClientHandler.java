package task2;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;

class XOServerClientHandler implements Runnable{
    private Socket s1;
    private Socket s2;
    private char[] table;
    XOServerClientHandler(Socket s1, Socket s2) {
        this.s1 = s1;
        this.s2 = s2;
        char[] table = new char[10];
        Arrays.fill(table, '-');
        this.table = table;
    }

    @Override
    public void run() {
        try(BufferedReader reader1 = new BufferedReader(new InputStreamReader(s1.getInputStream()));
            BufferedWriter writer1 = new BufferedWriter(new OutputStreamWriter(s1.getOutputStream()));
            BufferedReader reader2 = new BufferedReader(new InputStreamReader(s2.getInputStream()));
            BufferedWriter writer2 = new BufferedWriter(new OutputStreamWriter(s2.getOutputStream()))){

            int flag = 0;
            for(int i = 1;i<=9;++i){
                if(flag==1)
                    break;
                System.out.println("Potez broj: " + i);
                if(i%2 == 1){ //prvi igrac
                    System.out.println("Na potezu igrac 1");
                    while(true) {
                        if(checkIfSomeoneWon()){
                            flag = 1;
                            writer1.write("YOU LOSE");
                            writer1.newLine();
                            writer1.flush();
                            writer2.write("YOU WON");
                            writer2.newLine();
                            writer2.flush();
                            s1.close();
                            s2.close();
                        }
                        System.out.println("Ucitavam");
                        String line = reader1.readLine();
                        System.out.println("linija1: " + line);
                        if (line.equals("ispis")) {
                            ispisiTablu(writer1);
                        }
                        else if (line.charAt(0) == '>') {
                            unesiChar('X', line.charAt(1),writer1);
                            break;
                        }
                        else{
                            writer1.write("Nevalidan potez");
                            writer1.newLine();
                            writer1.flush();
                        }
                    }
                }
                else{ //drugi igrac
                    System.out.println("Na potezu igrac 2");
                    while(true) {
                        if(checkIfSomeoneWon()){
                            flag = 1;
                            writer1.write("YOU WON");
                            writer1.newLine();
                            writer1.flush();
                            writer2.write("YOU LOSE");
                            writer2.newLine();
                            writer2.flush();
                            s1.close();
                            s2.close();
                        }
                        System.out.println("Ucitavam");
                        String line = reader2.readLine();
                        System.out.println("linija2: " + line);
                        if (line.equals("ispis")) {
                            ispisiTablu(writer2);
                        }
                        else if (line.charAt(0) == '>') {
                            unesiChar('O', line.charAt(1),writer2);
                            break;
                        }
                        else{
                            writer1.write("Nevalidan potez");
                            writer1.newLine();
                            writer1.flush();
                        }
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean checkIfSomeoneWon() {
        if(table[1] == table[2] && table[1] == table[3] && table[1]!='-')
            return true;
        else if(table[4] == table[5] && table[4] == table[6] && table[4]!='-')
            return true;
        else if(table[7] == table[8] && table[7] == table[9] && table[7]!='-')
            return true;
        else if(table[1] == table[4] && table[1] == table[7] && table[1]!='-')
            return true;
        else if(table[2] == table[5] && table[2] == table[8] && table[2]!='-')
            return true;
        else if(table[3] == table[6] && table[3] == table[9] && table[3]!='-')
            return true;
        else if(table[1] == table[5] && table[1] == table[9] && table[1]!='-')
            return true;
        else if(table[3] == table[5] && table[3] == table[7] && table[3]!='-')
            return true;
        else
            return false;
    }

    private void unesiChar(char o, char charAt,BufferedWriter writer1) throws IOException {
        System.out.println((int)charAt);
        if(table[(int)charAt-48] == '-') {
            table[(int) charAt - 48] = o;
            writer1.write("Uspesan potez");
            writer1.newLine();
            writer1.flush();
        }
        else{
            writer1.write("NEUSPESAN POTEZ, SLOMILI STE IGRU, SAD VAM NEMA SPASA HUEHUEHUE");
            writer1.newLine();
            writer1.flush();
        }
    }

    private void ispisiTablu(BufferedWriter writer) throws IOException {
        for(int j = 1;j<=9;j++){
            System.out.print(table[j]);
            writer.write(table[j]);
            if(j%3==0){
                System.out.println();
                writer.write(' ');
            }
        }
        writer.newLine();
        writer.flush();
    }
}

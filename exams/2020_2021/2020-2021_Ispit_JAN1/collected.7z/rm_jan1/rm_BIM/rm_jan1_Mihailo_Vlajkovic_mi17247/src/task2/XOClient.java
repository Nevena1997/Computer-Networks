package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {
        try(Socket s = new Socket(InetAddress.getLocalHost(),12345);
            BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
            Scanner sc = new Scanner(System.in)
        ) {
            while(true){
                String line = sc.nextLine();
                writer.write(line);
                writer.newLine();
                writer.flush();
                String ic = reader.readLine();
                System.out.println(ic);
                if(ic.equals("YOU WON") || ic.equals("YOU LOSE")){
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

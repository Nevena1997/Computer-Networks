package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket server = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ) {
            byte[] buf = new byte[256];
            String line = sc.nextLine();
            DatagramPacket send = new DatagramPacket(line.getBytes(),0,line.length(), InetAddress.getLocalHost(),31415);
            server.send(send);
            DatagramPacket receive = new DatagramPacket(buf,buf.length);
            server.receive(receive);
            String response = new String(receive.getData(),0,receive.getLength(), StandardCharsets.UTF_8);
            System.out.println(response);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

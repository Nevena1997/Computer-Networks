package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {
        try(DatagramSocket client = new DatagramSocket(31415)) {
            while(true) {
                byte[] buf = new byte[256];
                DatagramPacket receive = new DatagramPacket(buf, buf.length);
                client.receive(receive);
                String numStr = new String(receive.getData(),0,receive.getLength(), StandardCharsets.UTF_8);
                if(numStr.charAt(0) == '-'){
                    String resp = "Neispravan poluprecnik";
                    DatagramPacket send = new DatagramPacket(resp.getBytes(),0,resp.length(),receive.getAddress(),receive.getPort());
                    client.send(send);
                    continue;
                }
                float num = Float.parseFloat(numStr);
                float area = (float) (num*num*Math.PI);
                System.out.println(numStr);
                String areaStr = Float.toString(area);
                DatagramPacket send = new DatagramPacket(areaStr.getBytes(),0,areaStr.length(),receive.getAddress(),receive.getPort());
                client.send(send);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

}

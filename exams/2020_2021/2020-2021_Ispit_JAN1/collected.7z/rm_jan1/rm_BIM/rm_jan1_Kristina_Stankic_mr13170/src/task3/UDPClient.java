package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        //System.out.println("Hello from: " + UDPClient.class.getName());
        try(DatagramSocket klijent=new DatagramSocket();
            Scanner sc=new Scanner(System.in)){

            System.out.println("Uneti realan broj: ");
            double r=sc.nextDouble();


            String real = Double.toString(r);
            DatagramPacket paket_za_slanje = new DatagramPacket(real.getBytes(), real.length(), InetAddress.getLocalHost(), UDPServer.PORT);
            klijent.send(paket_za_slanje);


            byte[] niz=new byte[1024];
            DatagramPacket paket_za_prijem=new DatagramPacket(niz,niz.length);
            klijent.receive(paket_za_prijem);

            String odgovor=new String(niz,0,paket_za_prijem.getLength());
            System.out.println(odgovor);

        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    public static final int PORT=12345;

    public static void main(String[] args) {
        //System.out.println("Hello from: " + XOServer.class.getName());

        //server osluskuje ne portu
        try(ServerSocket server=new ServerSocket(PORT)){

            //prihvatamo klijente u petlji
            while(true){

               Socket klijent=server.accept();

               //kreiramo nit za svakog klijenta
               new Thread(new XOServerClientHandler(klijent)).start();
            }

        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

}

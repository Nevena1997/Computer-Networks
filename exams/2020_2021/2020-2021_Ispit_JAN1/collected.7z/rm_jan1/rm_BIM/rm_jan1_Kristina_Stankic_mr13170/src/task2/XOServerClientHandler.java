package task2;

import javax.management.OperationsException;
import java.io.*;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.Arrays;

class XOServerClientHandler implements Runnable{

    private Socket klijent;
    public  XOServerClientHandler(Socket klijent){
        this.klijent=klijent;
    }

    @Override
    public void run() {

        try(BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(this.klijent.getOutputStream()));
            BufferedReader br=new BufferedReader(new InputStreamReader(this.klijent.getInputStream()))){

            //server vrsi azuriranje na osnovu instrukcije koje je dobio
            String s;
            int i=0;
            while((s=br.readLine())!=null){

                //rasclanjujemo instrukciju koju smo dobili
                //na String potez i int poziciju
                String[] split=s.split(" ");
                System.out.println(Arrays.toString(split));
                //za proveru
                //bw.write(s);
                //bw.newLine();
                //bw.flush();;
                String potez=split[0];
                int pozicija= Integer.parseInt(split[1]);



                //unosimo potez na zeljenu poziciju
                //odnosno popunjavamo matricu

                i++;
                //brojac koji nam govori koliko poteza smo povukli
            }
        }

        catch(IOException e){
            e.printStackTrace();
        }
    }
}

package task2;

//import jdk.swing.interop.SwingInterOpUtils;

import java.io.*;
import java.lang.reflect.Array;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

class XOClient {

    public static void main(String[] args) {
        //System.out.println("Hello from: " + XOClient.class.getName());

        try(Socket klijent=new Socket("localhost",XOServer.PORT);
            BufferedReader br=new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
            Scanner sc=new Scanner(System.in)) {

            //imacemo matricu
            char[][] matrica = new char[3][3];
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    matrica[i][j] = '-';
                }
            }
            System.out.println("Pocetno stanje: ");
            for (int i = 0; i < 3; i++) {
                System.out.println(Arrays.toString(matrica[i]));
            }

            while (true) {
                System.out.println("Unesite potez: X-iks/O-oks");
                String potez = sc.next();
                System.out.println("Ako zamislimo da su pozicije predstavljene brojevima");
                System.out.println("od 1-9 na sledeci nacin");
                System.out.println("Unesite sad poziciju na koju zelite da povucete potez");
                int[][] matrica_pozicija = new int[3][3];
                int k = 1;
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        matrica_pozicija[i][j] = k;
                        k++;
                    }
                }
                System.out.println("Pocetno stanje: ");
                for (int i = 0; i < 3; i++) {
                    System.out.println(Arrays.toString(matrica_pozicija[i]));
                }
                int pozicija = sc.nextInt();
                //Serveru prosledjujemo poziciju i

                //instrukciju dobijamo tako sto smo nadovezali na potez broj pozicije
                //primer instrukcije : X 1
                // X - -
                // - - -
                // - - -
                //instrukcija : O 3
                // X - O
                // - - -
                // - - -
                String instrukcija=potez+" "+String.valueOf(pozicija);
                bw.write(instrukcija);
                bw.newLine();
                bw.flush();

                //System.out.println(br.readLine());
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

}

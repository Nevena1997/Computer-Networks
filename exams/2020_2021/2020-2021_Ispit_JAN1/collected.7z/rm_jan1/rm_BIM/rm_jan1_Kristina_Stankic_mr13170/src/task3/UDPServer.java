package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

class UDPServer {

    public static final int PORT=31415;

    public static void main(String[] args) {

        try(DatagramSocket server=new DatagramSocket(PORT)){

            while(true) {
                byte[] niz = new byte[1024];
                DatagramPacket paket_za_prijem = new DatagramPacket(niz, niz.length);
                server.receive(paket_za_prijem);

                String broj = new String(niz, 0, paket_za_prijem.getLength());
                System.out.println(broj);


                double poluprecnik=Double.parseDouble(broj);

                if(poluprecnik<0.0){
                    String poruka="Neispravan poluprecnik";
                    DatagramPacket paket_za_slanje=new DatagramPacket(poruka.getBytes(),poruka.length(),paket_za_prijem.getAddress(),paket_za_prijem.getPort());
                    server.send(paket_za_slanje);

                }
                else {
                    double povrsina = poluprecnik * poluprecnik * Math.PI;
                    String povrsina_string = new String(Double.toString(povrsina));

                    DatagramPacket paket_za_slanje = new DatagramPacket(povrsina_string.getBytes(), povrsina_string.length(), paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                    server.send(paket_za_slanje);

                }

            }
        }

        catch(IOException e){
            e.printStackTrace();
        }

        //System.olic static final int PORT=31415;ut.println("Hello from: " + UDPServer.class.getName());
    }

}

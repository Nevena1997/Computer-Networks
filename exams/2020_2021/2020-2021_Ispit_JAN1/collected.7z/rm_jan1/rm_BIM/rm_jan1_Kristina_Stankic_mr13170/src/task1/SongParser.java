package task1;

import java.io.*;
import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

class SongParser extends Thread{

    String pathname;
    File f;
    String rec;
    public  SongParser(File f, String pathname,String rec){
        this.pathname=pathname;
        this.f=f;
        this.rec=rec;
    }

    @Override
    public void run() {
        ThreadLocalRandom r=ThreadLocalRandom.current();

        String putanja=f.toString()+"/"+pathname;

        //System.out.println(putanja);

        try(Scanner sc=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja))));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(System.out));
            Scanner sc1=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja))))){

            String linija;

            int broj_pojavljivanja_reci=0;
            int duzina=0; //lazno postavljamo da je najduzi stih duzine 0
           //tu cemo drzati najduzi stih
            String pamtimo_liniju = "";
            //sc-koristimo za citanje linija i uporedjivanje duzina
            while(sc.hasNextLine()){


                linija=sc.nextLine();
                //System.out.println(linija);

                //ideja: da za svaki stih cuvamo duzinu u HashMap-i?

                //trazimo duzinu najduzeg stiha
                if(duzina<linija.length()){
                    //azuriramo duzinu najduzeg stiha i cuvamo tu liniju
                    pamtimo_liniju=linija;
                    duzina=linija.length();
                }

            }
            int br=0;
            //sc1-koristimo da iscitamo reci i vidimo da li je uneta rec sadrzana u nekoj iz teksta pesme
            while(sc1.hasNext()){
                String ime;
                ime=sc1.next();
                if(ime.contains(rec)){
                    br++;
                }
            }

                System.out.println(pamtimo_liniju);
                System.out.println(duzina);
                System.out.printf("\nBroj pojavljivanja reci je %d\n", br);
        }
        catch (IOException e){
            e.printStackTrace();
        }

        try {
            Thread.sleep(r.nextLong(2));
        }
        catch (InterruptedException e){
            e.fillInStackTrace();
        }

    }
}

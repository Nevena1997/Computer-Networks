package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLOutput;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        //System.out.println("Hello from: " + Task1Main.class.getName());

        Scanner sc=new Scanner(System.in);
        System.out.println("Uneti rec: ");
        String rec=sc.nextLine();

        String[] pathnames;
        File file=new File("/home/ispit/Desktop/tests/pesme");
        //pravimo listu datoteka u okv
        pathnames= file.list();

        //izlistavamo sve datoteke u okviru direktorijuma pesme
        for(String pathname:pathnames){
            //System.out.println(pathname);
            //za svaku datoteku pokrecemo nit koja ce voditi evidenciju
            //saljemo fajl, ime datoteke i rec
            new SongParser(file,pathname,rec).start();
            try{
                Thread.sleep(2);
            }
            catch(InterruptedException e){
                e.fillInStackTrace();
            }
        }

    }

}

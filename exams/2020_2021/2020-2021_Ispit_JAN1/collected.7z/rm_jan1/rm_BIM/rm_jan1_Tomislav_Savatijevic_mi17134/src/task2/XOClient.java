package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

class XOClient {


    public boolean cekamPrvoStanje = true;
    public boolean cekamDrugoStanje = false;
    public boolean cekamPotez = false;
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());

        XOClient client = new XOClient();
        client.execute();
    }

    private void execute() {

        try  {
            Socket socket = new Socket("localhost", 12345);
            BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            // ne zatvaram ih jer to ce da sjebe ostale cliente, dok socket cu zatv u threadu

            String line;
            while((line = in.readLine()) != null){
                if(line.contains("Pobedio je")){
                    //pobednik
                    System.out.println(in.readLine());
                } else if(cekamPrvoStanje){
                    //stanje igre
                    System.out.println(in.readLine());
                    cekamPotez = true;
                    cekamPrvoStanje = false;
                } else if(cekamPotez){
                    // potez
                    String potez = stdin.readLine();
                    out.println(potez);
                    cekamPotez = false;
                    cekamDrugoStanje = true;
                } else  if(cekamDrugoStanje){
                    // stanje igre 2
                    System.out.println(in.readLine());
                    cekamDrugoStanje = false;
                    cekamPrvoStanje = true;
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

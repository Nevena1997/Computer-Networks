package task3;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try(DatagramSocket client = new DatagramSocket();
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in))){

            InetAddress host = InetAddress.getLocalHost();
            System.out.println("unesite jedan realan broj(ne negativan :))");

            String brojString = in.readLine();
            byte[] dataToSend = brojString.getBytes();
            DatagramPacket request = new DatagramPacket(dataToSend, dataToSend.length, host,31415);
            client.send(request);

            byte[] dataToGet = new byte[512];
            DatagramPacket response = new DatagramPacket(dataToGet,dataToGet.length);
            client.receive(response);

            String rezultat = new String(response.getData(), 0, response.getLength());
            System.out.println("Povrsina je " + rezultat);
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.Arrays;

class XOServerClientHandler extends Thread{

    private boolean first;
    private Socket client;
    private BufferedReader stdin;
    private BufferedReader in;
    private PrintWriter out;
    private XOServer server;

    XOServerClientHandler(boolean first, Socket client, XOServer server) throws IOException {
        this.server = server;
        this.first = first;
        this.client = client;
        this.stdin = new BufferedReader(new InputStreamReader(System.in));
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true);
    }

    @Override
    public void run() {

        // ispijuemo pocetno stanje igre
        while(!server.gameStarted){
            // cekamo da udju oba igraca
        }
        while(server.gameStarted){
            stanjeIgre();
            //uvek pocinjemo game sa X
            while(!naPotezu()){
                // wait
            }
            while(!ucitajDobarPotez()){
                out.println("Nevalidan potez");
            }
            stanjeIgre();

            if(pobedio()){
                server.gameStarted = false;
                if(first){
                    server.pobednik = "Pobedio je igrac 1";
                } else{
                    server.pobednik = "Pobedio je igrac 2";
                }
                // posemo svima ko je pobedio
                server.imamoPobednika = true;
                out.println(server.pobednik);
                server.gameFinished = true;
            }
        }

    }

    private boolean naPotezu() {
        if(first == server.prviJeNaPotezu){
            return true;
        }
        return  false;
    }

    private boolean pobedio() {
        String znak;
        if(first){
            znak = "x";
        } else {
            znak = "o";
        }
        // ne mogu razmisljam ovo je haos hahahaha a radi(vlajda)
        if(server.board.get(0).equalsIgnoreCase(znak) && server.board.get(3).equalsIgnoreCase(znak) && server.board.get(6).equalsIgnoreCase(znak)){
            return true;
        } else if(server.board.get(1).equalsIgnoreCase(znak) && server.board.get(4).equalsIgnoreCase(znak) && server.board.get(7).equalsIgnoreCase(znak)){
            return true;
        } else if(server.board.get(2).equalsIgnoreCase(znak) && server.board.get(5).equalsIgnoreCase(znak) && server.board.get(8).equalsIgnoreCase(znak)) {
            return true;
        } else if(server.board.get(0).equalsIgnoreCase(znak) && server.board.get(4).equalsIgnoreCase(znak) && server.board.get(8).equalsIgnoreCase(znak)){
            return true;
        } else if(server.board.get(3).equalsIgnoreCase(znak) && server.board.get(4).equalsIgnoreCase(znak) && server.board.get(6).equalsIgnoreCase(znak)){
            return true;
        } else {
            return true;
        }
    }

    private boolean ucitajDobarPotez(){
        try {
            String potez = in.readLine();
            int pozicija = Integer.parseInt(potez) - 1;
            if(server.board.get(pozicija).equalsIgnoreCase("-")){
                server.board.add(pozicija,first ? "x" : "o");
                return true;
            } else {
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void stanjeIgre(){
        // TODO malo lepse
        out.println(server.board.toArray().toString());
    }
}

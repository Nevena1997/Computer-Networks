package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {
    
    public static void main(String[] args)
    {
        System.out.println("Hello from: " + UDPServer.class.getName());

        try(DatagramSocket server = new DatagramSocket(31415)){

            while(true){
                try{
                    byte[] dataToGet = new byte[512];
                    DatagramPacket reqest = new DatagramPacket(dataToGet,dataToGet.length);
                    server.receive(reqest);
                    String r = new String(reqest.getData(), 0, reqest.getLength());
                    String povrsinuPoslati;
                    if(r.contains("-")){
                        povrsinuPoslati = "-1";
                    } else {
                        Double poluprecnik = Double.parseDouble(r);
                        Double povrsina = poluprecnik * poluprecnik * Math.PI;

                        povrsinuPoslati = povrsina.toString();
                    }
                    byte[] dataToSend = povrsinuPoslati.getBytes();
                    DatagramPacket response = new DatagramPacket(dataToSend, dataToSend.length,reqest.getAddress(),reqest.getPort());
                    server.send(response);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

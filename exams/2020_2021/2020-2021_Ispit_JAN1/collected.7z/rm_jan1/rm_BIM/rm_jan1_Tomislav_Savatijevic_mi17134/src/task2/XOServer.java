package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

class XOServer {
    public  boolean imamoPobednika = false;
    public  int numUsers = 0;
    public  boolean gameStarted = false;
    public  boolean gameFinished = false;
    public  String X = "X";
    public  String O = "O";
    public  boolean foundFirst = false;
    public boolean prviJeNaPotezu = false;
    public List<String> board = List.of("-","-","-","-","-","-","-","-","-");
    public String pobednik;
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOServer.class.getName());
        XOServer server = new XOServer();
        server.execute();
    }

    private void execute() {

        System.err.println("Starting server...");
        try(ServerSocket server = new ServerSocket(12345)) {

            while(true){
                while(gameStarted){
                    //wait here
                }
                if(!gameStarted && !gameFinished){
                    System.err.println("Waiting for players...");
                    try{
                        Socket client = server.accept();
                        if(!foundFirst){
                            new XOServerClientHandler(true, client, this).start();
                            foundFirst = true;
                            numUsers++;
                        } else {
                            System.err.println("Found game");
                            new XOServerClientHandler(false, client, this).start();
                            numUsers++;
                        }
                        if(numUsers == 2){
                            gameStarted = true;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void resetIgru(){
        this.board.clear();
        this.foundFirst = false;
        this.numUsers = 0;
        this.gameStarted = false;
        this.prviJeNaPotezu = false;
        this.imamoPobednika = false;
    }
//                if(numUsers == 2){
//                    gameStarted = true;
//                    prviJeNaPotezu = true;
//                } else {
//                    System.err.println("Waiting for players...");
//                    try{
//                        Socket client = server.accept();
//                        if(!foundFirst){
//                            new XOServerClientHandler(true, client, this).start();
//                            foundFirst = true;
//                        } else {
//                            System.err.println("Found game");
//                            new XOServerClientHandler(false, client, this).start();
//                        }
//                        numUsers++;
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                if(gameFinished){
//                    wait(10000);
//                    resetIgru();
//                }
}

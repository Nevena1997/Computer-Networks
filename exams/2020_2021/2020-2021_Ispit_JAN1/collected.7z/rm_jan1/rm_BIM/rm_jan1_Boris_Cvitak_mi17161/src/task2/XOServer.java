package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;

class XOServer {
    //promenio sam port jer nisam lepo iskljucio server u jednom trenutku i vise nije htelo da mi se poveze na isti port
    public static final int PORT = 11111;

    public static  String waitMsg = "Cekajte da protivnik odigra potez";
    public static  String yourTurnMsg = "Vas potez";


    public static List<String> table = new LinkedList<>();
    public static int playerOnTurn = 0;

    public static void main(String[] args) {
        List<Socket> list = new LinkedList<>();

        try (ServerSocket server = new ServerSocket(PORT)){
            System.out.println("Server je zapoceo sa radom na portu: " + PORT);
            while (true) {
                System.out.println("Server ceka igraca");
                Socket client = server.accept();

                list.add(client);
                if (list.size() == 2) {
                    prepareTable();
                    Thread client1 = new Thread(new XOServerClientHandler(list.get(0), 0));
                    Thread client2 = new Thread(new XOServerClientHandler(list.get(1), 1));

                    client1.start();
                    client2.start();

                    client1.join();
                    client2.join();

                    list.clear();
                    removeTable();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void removeTable() {
        table.clear();
    }

    private static void prepareTable() {
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
       table.add("-");
    }

    public static String getTable() {
        return table.get(0) + " " + table.get(1) +  " " + table.get(2) + " "  + table.get(3) + " " + table.get(4) + " " + table.get(5) + " " + table.get(6) + " " + table.get(7) + " " + table.get(8) + " ";
    }

}

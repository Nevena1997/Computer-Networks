package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable{
    private Socket socket;
    private int id;
    private String label;

    public XOServerClientHandler(Socket socket, int id) {
        this.socket = socket;
        this.id = id;
        if (id == 0)
            this.label = "X";
        else
            this.label = "0";

    }

    @Override
    public void run() {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))
        ) {

            while (true) {
                printTable(writer);

                if (XOServer.playerOnTurn != id) {
                    printMsg(XOServer.waitMsg, writer);
                    this.socket.wait();
                }

                printMsg(XOServer.yourTurnMsg, writer);
                readMove(reader, writer);
                XOServer.playerOnTurn = Math.abs(XOServer.playerOnTurn - id);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    private void printMsg(String msg, BufferedWriter writer) throws IOException {
        writer.write(msg);
        writer.newLine();
        writer.flush();

    }

    private void printTable(BufferedWriter writer) throws IOException {
        writer.write(XOServer.getTable());
        writer.newLine();
        writer.flush();
    }

    private void readMove(BufferedReader reader, BufferedWriter writer) throws IOException {
        String line;
        while ((line = reader.readLine()) == null);
        int num = Integer.parseInt(line);
        if (validNumber(num))
            XOServer.table.set(num-1, this.label);
        else
            printMsg("Nevalidan potez", writer);
    }

    private Boolean validNumber(int num) {
        if ((num < 1) || (num >9))
            return false;
        return true;
    }


}

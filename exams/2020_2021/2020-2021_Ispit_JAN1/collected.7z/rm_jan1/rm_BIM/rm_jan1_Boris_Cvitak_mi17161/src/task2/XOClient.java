package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {

    public static void main(String[] args) {

        try (Socket client = new Socket(InetAddress.getLocalHost(), XOServer.PORT);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in);
        ){
            Boolean gameRun = true;
            while (gameRun) {
                printTable(reader);
                createMove(reader, writer, sc);
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void createMove(BufferedReader reader, BufferedWriter writer, Scanner sc) throws IOException {
            System.out.println(reader.readLine());
            String line = sc.nextLine();
            writer.write(line);
            writer.newLine();
            writer.flush();
    }

    private static void printTable(BufferedReader reader) throws IOException {
        String table = reader.readLine();
        System.out.println(table);
    }

}

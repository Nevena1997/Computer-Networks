package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import static java.nio.charset.StandardCharsets.UTF_8;

class UDPClient {
    
    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in);
        ){
            Double num;
            while (true) {
                System.out.println("Ucitajte poluprecnik (realan broj):");
                String line = sc.nextLine();
                try {
                    num = Double.parseDouble(line);
                    break;
                } catch (NumberFormatException e) {
                    continue;
                }
            }

            byte[] buff = (Double.toString(num)).getBytes(UTF_8);
            DatagramPacket packet = new DatagramPacket(buff, buff.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(packet);

            byte[] bytes = new byte[256];
            DatagramPacket response = new DatagramPacket(bytes, bytes.length);
            client.receive(response);

            String p = new String(response.getData(), 0, response.getLength(), UTF_8);
            System.out.println("Povrsina je : " + p);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

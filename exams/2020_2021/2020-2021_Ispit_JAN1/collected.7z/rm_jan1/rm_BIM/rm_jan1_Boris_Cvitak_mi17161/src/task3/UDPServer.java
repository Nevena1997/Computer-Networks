package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    public static final int PORT = 31415;

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(PORT)){
            System.out.println("Server je startova sa radom na portu: " + PORT);
            while (true) {
                byte[] buff = new byte[256];
                DatagramPacket packet = new DatagramPacket(buff, buff.length);
                server.receive(packet);

                String strNum = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                Double num = Double.parseDouble(strNum);
                String p;
                if (num < 0) {
                    p = "Neispravan poluprecnik";
                } else {
                    p = Double.toString(num * num * Math.PI);
                }
                byte[] res = p.getBytes(StandardCharsets.UTF_8);
                DatagramPacket response = new DatagramPacket(res, res.length, packet.getAddress(), packet.getPort());
                server.send(response);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

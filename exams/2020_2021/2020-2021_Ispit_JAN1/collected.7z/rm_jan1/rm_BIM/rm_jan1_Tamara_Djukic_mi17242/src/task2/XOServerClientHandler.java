package task2;

import java.net.Socket;

class XOServerClientHandler extends Thread{
    private Socket socket;

    XOServerClientHandler(Socket sock){
        this.socket=sock;
    }

    @Override
    public void run() {


    }

    //this.socket.close();
}

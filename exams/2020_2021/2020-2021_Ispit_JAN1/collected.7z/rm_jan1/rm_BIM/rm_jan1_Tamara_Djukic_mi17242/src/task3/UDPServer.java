package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

class UDPServer {
    
    public static void main(String[] args){
        try (DatagramSocket server=new DatagramSocket(31415)) {
            byte[] buf=new byte[256];
            DatagramPacket request=new DatagramPacket(buf, buf.length);
            server.receive(request);

            byte[] res=request.getData();
            if (res[0]<0){
                byte[] poruka="Neispravan poluprecnik".getBytes();
                DatagramPacket response=new DatagramPacket(poruka, poruka.length, request.getAddress(), request.getPort());
                server.send(response);
            }
            else{
                double povrsina=4*res[0]*res[0]*Math.PI;
                buf[0]=(byte)povrsina;

                DatagramPacket response=new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                server.send(response);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

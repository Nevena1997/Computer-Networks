package task1;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class SongParser extends Thread {
    private final Path p;
    private final String wordToFind;
    private Lock lock;
    private Condition conditionForLock;

    SongParser(Path p, String wordToFind) {
        this.p = p;
        this.wordToFind = wordToFind;
        this.lock = new ReentrantLock();
        this.conditionForLock = lock.newCondition();
    }

    @Override
    public void run() {
        this.lock.lock();
        System.out.println(this.p.getFileName().toString().substring(0, this.p.getFileName().toString().length() - 4));

        int max = 0;
        String maxLine = null;
        int count = 0;
        try {
            try (Scanner scFile = new Scanner(this.p)) {
                while (scFile.hasNextLine()) {
                    String line = scFile.nextLine();
                    int lineLen = line.length();
                    if (lineLen > max) {
                        max = lineLen;
                        maxLine = line;
                    }

                    if (line.contains(this.wordToFind))
                        count++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            System.out.println(maxLine);
            System.out.println(count);

            this.conditionForLock.signalAll();
        } finally {
            this.lock.unlock();
        }
    }
}

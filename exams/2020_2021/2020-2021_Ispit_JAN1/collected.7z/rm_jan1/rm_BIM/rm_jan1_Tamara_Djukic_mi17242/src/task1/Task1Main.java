package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        String wordToFind;
        try(Scanner sc=new Scanner(System.in)){
            wordToFind=sc.nextLine();
        }

        try {
            for(Path p: Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"))){
                if(Files.isRegularFile(p)){
                    new Thread(new SongParser(p, wordToFind)).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

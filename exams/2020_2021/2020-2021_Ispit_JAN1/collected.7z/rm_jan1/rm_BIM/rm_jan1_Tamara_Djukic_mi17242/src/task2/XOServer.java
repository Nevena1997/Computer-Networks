package task2;

import java.io.IOException;
import java.net.ServerSocket;

class XOServer {
    
    public static void main(String[] args) {
        try (ServerSocket server=new ServerSocket(12345)) {
            while (true){

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

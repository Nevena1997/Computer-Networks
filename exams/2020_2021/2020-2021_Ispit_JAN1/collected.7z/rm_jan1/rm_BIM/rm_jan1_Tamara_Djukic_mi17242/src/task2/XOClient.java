package task2;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

class XOClient {
    
    public static void main(String[] args) {
        try (Socket sock=new Socket("localhost", 12345)) {
            var clientThread=new XOServerClientHandler(sock);
            clientThread.start();

            clientThread.join();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

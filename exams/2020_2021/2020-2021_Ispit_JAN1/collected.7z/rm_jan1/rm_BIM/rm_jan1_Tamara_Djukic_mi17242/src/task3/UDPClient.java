package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        String host="localhost";
        int port=31415;

        byte poluprecnik;
        try (Scanner sc=new Scanner(System.in)) {
            poluprecnik=(byte) sc.nextDouble();
        }

        try (DatagramSocket sock=new DatagramSocket()) {
            byte[] buf=new byte[]{poluprecnik};

            DatagramPacket request= new DatagramPacket(buf, buf.length, InetAddress.getByName(host), port);
            sock.send(request);

            DatagramPacket response=new DatagramPacket(buf, buf.length);
            sock.receive(response);


            //TODO
            String res=new String(response.getData(), 0, response.getLength());
            System.out.println(res);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

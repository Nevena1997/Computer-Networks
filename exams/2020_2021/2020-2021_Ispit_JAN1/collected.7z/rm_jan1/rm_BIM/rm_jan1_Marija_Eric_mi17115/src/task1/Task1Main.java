package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String pesma = sc.nextLine();
        ArrayList<SongParser> th = new ArrayList<>();
        try(DirectoryStream<Path> dirs = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"))){

        for (Path p: dirs){
            if (Files.isRegularFile(p)) {
                SongParser t = new SongParser(p, pesma);
                th.add(t);
                t.start();
            }
        }
        for (SongParser t:th)
            t.join();

        }catch (IOException | InterruptedException e){
            e.printStackTrace();
        }

    }

}

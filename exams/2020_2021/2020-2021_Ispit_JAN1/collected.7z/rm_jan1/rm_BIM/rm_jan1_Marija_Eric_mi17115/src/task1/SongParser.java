package task1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class SongParser extends Thread{
    private Path path;
    int num;
    int maxLine;
    String longestLine;
    String rec;

    SongParser(Path path, String rec) {
        this.path = path;
        this.rec = rec;
        this.num = 0;
        this.maxLine = 0;
        this.longestLine ="";
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(new FileInputStream(path.toString())))
        {
            while(sc.hasNextLine()) {
                String line = sc.nextLine();
                if (line.length() > maxLine){
                    maxLine = line.length();
                    longestLine = line;
                }
                int index;
                String[] s = line.split(" ");
                num += Arrays.stream(s).filter(x->x.trim().contains(rec)).count();
            }
            String name = path.getFileName().toString();
            synchronized (System.in){

                System.out.println(name.substring(0, name.length()-4));
                System.out.println(longestLine);
                System.out.println(num);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

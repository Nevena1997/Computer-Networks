package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;


class XOServer {
    static final int PORT = 12345;
    static final String HOST = "localhost";
    static ArrayList<Character> table = new ArrayList<>();
    private static Socket client1 = null;
    private static Socket client2 = null;


    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(PORT)) {
            while (true) {
                if (client1 == null) {
                    client1 = server.accept();
                } else if (client2 == null)
                    client2 = server.accept();

                table.clear();
                for (int i = 0; i < 9; i++) {
                    table.add(i, '-');
                }

                while (client1 != null && client2 != null) {

                    while (!isOver()) {

                        writeMove(client1);
                        readMove(client1);
                        writeMove(client2);
                        readMove(client2);
                    }
                    try(PrintWriter out1 = new PrintWriter(new BufferedOutputStream(client1.getOutputStream()));
                    PrintWriter out2 = new PrintWriter(new BufferedOutputStream(client2.getOutputStream()));) {
                        out1.println("Game over");
                        out2.println("Game over");
                        client1 = null;
                        client2 = null;
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private static boolean isOver(){
        for (int i = 0; i < table.size() ; i++) {
            if (table.get(i).equals('-'))
                return false;
        }
        return true;
    }
    private static Boolean isValidMove(String move) {
        int p = Integer.parseInt(move);
        return p>=0 && p<9 && table.get(p).equals('-');

    }
    private static void writeMove(Socket client) throws IOException {
        PrintWriter out1 = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
        //System.err.println();
        out1.println(Arrays.toString(table.toArray()));
        out1.flush();
    }
    private static void readMove(Socket client) throws IOException {

        String move;
        while(true){
            BufferedReader in1 = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out1 = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));


            if (isOver()){
                out1.println("Game over");
                out1.flush();
                return;
            }
            move = in1.readLine();
            if (isValidMove(move)) {
                if (client.equals(client1))
                    table.set(Integer.parseInt(move), 'x');
                else
                    table.set(Integer.parseInt(move), 'O');

                if (isOver()){
                    out1.println("Game over");
                    out1.flush();
                    return;
                }
                break;
            }
            else{
                out1.println("Nevalidan potez");
                out1.flush();

            }
        }

    }
}


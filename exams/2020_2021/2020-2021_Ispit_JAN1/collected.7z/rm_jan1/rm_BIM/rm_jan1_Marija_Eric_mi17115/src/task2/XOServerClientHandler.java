package task2;

// Nije koriscen fajl sva logika je implementirana u okviru XOServer i XOClient

class XOServerClientHandler {
    
}

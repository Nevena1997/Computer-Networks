package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            double r = sc.nextDouble();
            String msg = String.valueOf(r);

            DatagramPacket toSend = new DatagramPacket(msg.getBytes(), msg.getBytes().length,
                                    InetAddress.getByName(UDPServer.HOST), UDPServer.PORT);

            client.send(toSend);

            DatagramPacket toRecieve = new DatagramPacket(new byte[64], 64);
            client.receive(toRecieve);

            System.out.println(new String(toRecieve.getData(), 0, toRecieve.getLength()));
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

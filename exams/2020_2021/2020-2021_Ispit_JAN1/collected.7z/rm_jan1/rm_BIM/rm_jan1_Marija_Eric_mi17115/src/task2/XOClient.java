package task2;

import java.io.*;
import java.net.Socket;

import java.util.Scanner;

class XOClient {
    public static void main(String[] args) {

        try(Socket client = new Socket(XOServer.HOST, XOServer.PORT);
            PrintWriter out = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream())))
        {

            String response;
            while(true) {
                response = in.readLine();

                if (response.equalsIgnoreCase("Nevalidan potez")) {
                    System.out.println(response);

                } else if (response.equals("Game over")){
                    System.out.println("Game over");
                    break;
                }else
                    printTable(response);
                Scanner sc = new Scanner(System.in);
                int p = sc.nextInt();
                out.println(p);
                out.println();
                out.flush();

            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void printTable(String s){
        System.out.println(s);;
    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {
    public static final int PORT = 31415;
    public static final String HOST = "localhost";
    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT)){

            while (true) {
                try {
                    DatagramPacket toRecieve = new DatagramPacket(new byte[64], 64);
                    server.receive(toRecieve);
                    double msg = Double.parseDouble(new String(toRecieve.getData(), 0, toRecieve.getLength()));
                    double value = circleP(msg);
                    String msgToSend;
                    if (value == -1) {
                        msgToSend = "Neispravan poluprecnik";
                    } else
                        msgToSend = String.valueOf(value);

                    DatagramPacket toSend = new DatagramPacket(msgToSend.getBytes(), msgToSend.getBytes().length,
                            toRecieve.getAddress(), toRecieve.getPort());
                    server.send(toSend);
                }catch (IOException e){

                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

    private static double circleP(double r){
        if (r<0)
            return -1;
        return Math.PI*r*r;
    }

}

package task3;

import java.io.IOError;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket()) {
            Scanner sc = new Scanner(System.in);
            var r = sc.nextLine().getBytes();
            var req = new DatagramPacket(r, r.length, InetAddress.getByName("localhost"), 31415 );

            client.send(req);

            var res = new DatagramPacket(new byte[32], 32);
            client.receive(res);

            var data = new String(res.getData(), 0, res.getLength());
            System.out.println("Server response: " + data);

        } catch (IOError | IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

class XOServer {

    private static ArrayList<String> board = new ArrayList<>(Arrays.asList("-", "-", "-", "-", "-", "-", "-", "-", "-"));

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(12345)) {
            while (true) {
                try {

                    var client1 = server.accept();
                    System.out.println("client 1 connected");
                    var client2 = server.accept();
                    System.out.println("client 2 connected");

                    try (var in1 = new BufferedReader(new InputStreamReader(client1.getInputStream()));
                         var in2 = new BufferedReader(new InputStreamReader(client2.getInputStream()));
                         var out1 = new BufferedWriter(new OutputStreamWriter(client1.getOutputStream()));
                         var out2 = new BufferedWriter(new OutputStreamWriter(client2.getOutputStream()))
                    ) {
                        while (!gameFinished()) {
                            handleMove(in1, out1, out2, "X");
                            handleMove(in2, out2, out1, "O");
                        }
                        System.out.println("Game finished");

                        out1.write("Game finished");
                        out1.newLine();
                        out1.flush();

                        out2.write("Game finished");
                        out2.newLine();
                        out2.flush();

                        client1.close();
                        client2.close();

                        // reset board
                        board = new ArrayList<>(Arrays.asList("-", "-", "-", "-", "-", "-", "-", "-", "-"));

                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } catch (IOException exe) {
                    exe.printStackTrace();
                }
            }
            } catch(IOException e){
                e.printStackTrace();
            }
        }

    private static void handleMove(BufferedReader inPlayer, BufferedWriter outPlayer, BufferedWriter outOther, String playerSymbol) throws IOException {
        boolean validInput = false;
        while(!validInput && !gameFinished()) {
            var playerInput = inPlayer.readLine();
            try {
                Integer move = Integer.parseInt(playerInput);
                if(move < 1 || move > 9) {
                    throw new NumberFormatException();
                }

                System.out.println("Received move: " + move.toString());

                if (!board.get(move - 1).equals("-")) {
                    throw new NumberFormatException();
                }

                board.set(move - 1, playerSymbol);

                var line1 = "";
                for(Integer i = 0; i < 3; i++) {
                    line1 += board.get(i);
                }

                var line2 = "";
                for(Integer i = 3; i < 6; i++) {
                    line2 += board.get(i);
                }

                var line3 = "";
                for(Integer i = 6; i < 9; i++) {
                    line3 += board.get(i);
                }

                outPlayer.write(line1);
                outPlayer.newLine();
                outPlayer.write(line2);
                outPlayer.newLine();
                outPlayer.write(line3);
                outPlayer.newLine();
                outPlayer.flush();

                outOther.write(line1);
                outOther.newLine();
                outOther.write(line2);
                outOther.newLine();
                outOther.write(line3);
                outOther.newLine();
                outOther.flush();

                validInput = true;


            } catch (NumberFormatException e) {
                outPlayer.write("Nevalidan potez");
                outPlayer.newLine();
                outPlayer.flush();

            }

        }

    }

    private static boolean gameFinished() {

        Integer emptyFields = 0;
        for (var e : board) {
            if(e.equals("-")) {
                emptyFields++;
            }
        }

        if(emptyFields == 0) {
            return true;
        }


        if(board.get(0).equals(board.get(3)) && board.get(3).equals(board.get(6)) && !board.get(0).equals("-")) {
            return true;
        }


        if(board.get(1).equals(board.get(4)) && board.get(4).equals(board.get(7)) && !board.get(1).equals("-")) {
            return true;
        }

        if(board.get(2).equals(board.get(5)) && board.get(5).equals(board.get(8)) && !board.get(2).equals("-")) {
            return true;
        }

        if(board.get(0).equals(board.get(1)) && board.get(1).equals(board.get(2)) && !board.get(0).equals("-")) {
            return true;
        }

        if(board.get(3).equals(board.get(4)) && board.get(4).equals(board.get(5)) && !board.get(3).equals("-")) {
            return true;
        }
        if(board.get(6).equals(board.get(7)) && board.get(7).equals(board.get(8)) && !board.get(6).equals("-")) {
            return true;
        }

        if(board.get(0).equals(board.get(4)) && board.get(4).equals(board.get(8)) && !board.get(0).equals("-")) {
            return true;
        }

        if(board.get(2).equals(board.get(4)) && board.get(4).equals(board.get(6)) && !board.get(2).equals("-")) {
            return true;
        }

        return false;
    }

}

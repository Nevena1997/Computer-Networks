package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

class UDPServer {
    
    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(31415)) {
            while(true) {
                var req = new DatagramPacket(new byte[32], 32);
                server.receive(req);

                var data = new String(req.getData(), 0, req.getLength());
                var forSend = "";
                try {
                    var r = Integer.parseInt(data);
                    if(r < 0) {
                        throw new NumberFormatException();
                    }

                    Double p = r*r*3.1415;
                    forSend = p.toString();
                } catch (NumberFormatException e) {
                    forSend = "Neispravan poluprecnik";
                }

                var binData = forSend.getBytes();
                var res = new DatagramPacket(binData, binData.length, req.getAddress(), req.getPort());
                server.send(res);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

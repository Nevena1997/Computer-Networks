package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandlerWriter implements Runnable {

    Socket client;

    public XOServerClientHandlerWriter(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try(BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        ) {
            while(true) {
                var input = stdin.readLine();
                out.write(input);
                out.newLine();
                out.flush();
                }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class XOServerClientHandlerReader implements Runnable {

    Socket client;

    public XOServerClientHandlerReader(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {
            String line;
            while((line = in.readLine()) != null) {
                System.out.println(line);
                if (line.equals("Game finished")) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

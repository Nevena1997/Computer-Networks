package task2;

import java.io.IOException;
import java.net.Socket;

class XOClient {

    public static void main(String[] args) {

        try(Socket client = new Socket("localhost", 12345)) {
            // Validni unosi su brojevi od 1 do 9

            var writer = new Thread(new XOServerClientHandlerWriter(client));
            writer.start();

            var reader = new Thread(new XOServerClientHandlerReader(client));
            reader.start();

            writer.join();
            reader.join();


        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            // Bacice izuzetak i kada server eksplictno zatvori sockete, ali ne znam kako da resim to
            // uzimajuci u obzir kako sam implementirao klijenta :/

            // Server uredno nastavlja da radi i ceka na konekciju druga 2 igraca, tako da u sustini samo se dobije ruzan
            // ispis stack trace-a, sve ostalo radi.
        }
    }

}

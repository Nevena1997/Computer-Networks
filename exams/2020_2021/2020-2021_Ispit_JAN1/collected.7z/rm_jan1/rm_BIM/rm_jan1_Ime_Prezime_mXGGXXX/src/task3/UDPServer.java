package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

class UDPServer {

    public static void main(String[] args) {

        try (DatagramSocket socket = new DatagramSocket(31415)){

            while (true){
                byte[] buf = new byte[256];

                DatagramPacket req = new DatagramPacket(buf, buf.length);
                socket.receive(req);

                String line = new String(req.getData(), 0, req.getLength());

                double num = Double.parseDouble(line);
                double r = Math.PI * num * num;

                if ( num >= 0) {
                    line = Double.toString(r);
                } else {
                    line = "Neispravan poluprecnik";
                }

                buf = line.getBytes(StandardCharsets.UTF_8);

                DatagramPacket res = new DatagramPacket(buf, buf.length, req.getAddress(), req.getPort());
                socket.send(res);
            }

        } catch (IOException e){
            e.printStackTrace();
        }

    }

}

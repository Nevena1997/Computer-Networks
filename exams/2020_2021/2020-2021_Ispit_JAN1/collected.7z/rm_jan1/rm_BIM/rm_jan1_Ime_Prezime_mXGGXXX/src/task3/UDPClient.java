package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient{

    public static void main(String[] args){
        InetSocketAddress addr = new InetSocketAddress("localhost", 31415);

        try (DatagramSocket socket = new DatagramSocket()){
            Scanner sc = new Scanner(System.in);

            String num = sc.next();

            byte[] buf = num.getBytes(StandardCharsets.UTF_8);

            DatagramPacket req = new DatagramPacket(buf, buf.length, addr.getAddress(), addr.getPort());
            socket.send(req);

            buf = new byte[256];

            DatagramPacket res = new DatagramPacket(buf, buf.length);
            socket.receive(res);

            System.out.println( new String(res.getData(), 0, res.getLength()));

        }catch(IOException e){
            e.printStackTrace();
        }

    }
}

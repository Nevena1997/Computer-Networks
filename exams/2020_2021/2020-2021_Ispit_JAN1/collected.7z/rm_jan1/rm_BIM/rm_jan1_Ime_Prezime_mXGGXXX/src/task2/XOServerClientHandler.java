package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable {
    private final Socket klijent1;
    private final Socket klijent2;
    private String stanje = "---------";
    private Boolean prviNaPotezu = true;

    public XOServerClientHandler(Socket klijent1, Socket klijent2) {
        this.klijent1 = klijent1;
        this.klijent2 = klijent2;
    }

    public boolean isValid(int potez){
        if (potez < 0 || potez > 8)
            return false;

        if (this.stanje.charAt(potez) != '-')
            return false;

        return true;
    }

    public int freeFields() {
        int num = 0;

        for (int i = 0; i < 9; i++){
            if(this.stanje.charAt(i) == '-')
                num++;
        }

        return num;
    };


    @Override
    public void run() {
        try (
                BufferedReader in1 = new BufferedReader(new InputStreamReader(this.klijent1.getInputStream()));
                BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(this.klijent1.getOutputStream()));
                BufferedReader in2 = new BufferedReader(new InputStreamReader(this.klijent2.getInputStream()));
                BufferedWriter out2 = new BufferedWriter(new OutputStreamWriter(this.klijent2.getOutputStream()));
        ) {

            while (true) {

                if (freeFields() == 0){
                    out1.write("kraj");
                    out1.newLine();
                    out1.flush();

                    out2.write("kraj");
                    out2.newLine();
                    out2.flush();
                    break;
                }

                if (prviNaPotezu) {
                    out1.write(stanje);
                    out1.newLine();
                    out1.flush();
                }
                else {
                    out2.write(stanje);
                    out2.newLine();
                    out2.flush();
                }

                while (prviNaPotezu) {
                    String potez1 = in1.readLine();
                    int p1 = Integer.parseInt(potez1);

                    if (isValid(p1)) {
                        StringBuilder novo = new StringBuilder(this.stanje);
                        novo.deleteCharAt(p1);
                        novo.insert(p1, 'X');
                        this.stanje = novo.toString();

                        out1.write("Validan potez");
                        out1.newLine();
                        out1.flush();

                        break;
                    } else {
                        out1.write("Nevalidan potez");
                        out1.newLine();
                        out1.flush();
                    }

                }

                while (!prviNaPotezu) {
                    String potez2 = in2.readLine();
                    int p2 = Integer.parseInt(potez2);

                    if (isValid(p2)) {// Is valid
                        StringBuilder novo = new StringBuilder(this.stanje);
                        novo.deleteCharAt(p2);
                        novo.insert(p2, 'O');
                        this.stanje = novo.toString();

                        out2.write("Validan potez");
                        out2.newLine();
                        out2.flush();

                        break;
                    } else {
                        out2.write("Nevalidan potez");
                        out2.newLine();
                        out2.flush();
                    }
                }

                System.out.println(this.stanje);

                prviNaPotezu = !prviNaPotezu;
            }


        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.klijent2.close();
                this.klijent1.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

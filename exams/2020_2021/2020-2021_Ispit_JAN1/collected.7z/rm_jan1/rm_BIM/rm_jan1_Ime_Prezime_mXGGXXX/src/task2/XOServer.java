package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {
    
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(12345)){

            while (true) {
                Socket klijent1 = server.accept();
                Socket klijent2 = server.accept();

                new Thread(new XOServerClientHandler(klijent1, klijent2)).start();
            }

        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

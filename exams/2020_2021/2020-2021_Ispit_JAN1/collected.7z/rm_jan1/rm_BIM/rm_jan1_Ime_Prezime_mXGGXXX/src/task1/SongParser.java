package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;

class SongParser implements Runnable{
    private BufferedReader stream;
    private String najduza = "";
    private String rec;
    private int brojac = 0;

    public SongParser(BufferedReader stream, String rec) {
        this.stream = stream;
        this.rec = rec;
    }

    public String podaci(){
        return najduza + '\n' + brojac;
    }


    @Override
    public void run() {
        try {
            String line;
            while ((line = this.stream.readLine()) != null) {
                if (this.najduza.length() < line.length()){
                    this.najduza = line;
                }

                if (line.contains(this.rec))
                    brojac ++;

            }

        } catch ( IOException e) {
            e.printStackTrace();
        }
    }
}

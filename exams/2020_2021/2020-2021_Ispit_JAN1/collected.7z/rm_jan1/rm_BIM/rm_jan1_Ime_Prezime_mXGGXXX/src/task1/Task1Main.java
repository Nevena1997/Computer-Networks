package task1;

import java.io.*;
import java.util.Scanner;

class Task1Main {

    // Ne mogu da se setim prolazka kroz fajl sistem pa cu hardkodovati taj deo nazivima fajlova
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Unseite rec:");
        String rec = sc.next();

        try {
            BufferedReader file1 = new BufferedReader(
                        new FileReader("/home/ispit/Desktop/tests/pesme/Dolap.txt")
                    );
            BufferedReader file2 = new BufferedReader(
                    new FileReader("/home/ispit/Desktop/tests/pesme/LjubavnaPesma.txt")
            );

            SongParser sp1 = new SongParser(file1, rec);
            Thread t1 = new Thread(sp1);
            t1.start();

            SongParser sp2 = new SongParser(file2, rec);
            Thread t2 = new Thread(sp2);
            t2.start();

            t1.join();
            t2.join();

            System.out.println("Dolap\n" + sp1.podaci());
            System.out.println("LjubavnaPesma\n" + sp2.podaci());

            file1.close();
            file2.close();
        } catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
    }

}

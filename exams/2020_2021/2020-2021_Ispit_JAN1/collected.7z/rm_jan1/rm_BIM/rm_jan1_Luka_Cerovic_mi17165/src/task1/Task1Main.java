package task1;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        Path path = Paths.get("../tests/pesme");

        String word;
        try (Scanner sc = new Scanner(System.in)){
            word = sc.nextLine();
            SongParser sp = new SongParser(path, word);
            sp.execute();
        } catch (IOException e){
            e.printStackTrace();
        }

    }

}

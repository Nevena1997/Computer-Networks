package task1;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

public class FileReadThread extends Thread {

    private final Path path;
    private final SongParser sp;
    private final String word;
    private String longestLine = "";
    private int wordOccurance = 0;

    FileReadThread(SongParser sp, Path path, String word){
        this.path = path;
        this.sp = sp;
        this.word = word;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(path)){
            while (sc.hasNextLine()){
                String line = sc.nextLine();
                if(line.length() > longestLine.length())
                    longestLine = line;

                if(line.contains(word))
                    wordOccurance++;
            }

            String filename = path.getFileName().toString();
            int index = filename.lastIndexOf('.');
            String songName = filename.substring(0, index);

            String stringToPrint = songName + "\n"
                    + longestLine + "\n"
                    + wordOccurance;

            sp.printContent(stringToPrint);

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

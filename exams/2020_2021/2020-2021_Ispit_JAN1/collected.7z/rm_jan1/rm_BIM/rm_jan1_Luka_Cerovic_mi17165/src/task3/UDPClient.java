package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

class UDPClient {

    private static int port = 31415;

    public static void main(String[] args) {
        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in))
        {
            InetAddress addr = InetAddress.getByName("localhost");

            double r = sc.nextDouble();

            ByteBuffer buffer = ByteBuffer.allocate(8);
            buffer.putDouble(r);
            buffer.flip();

            byte[] data = buffer.array();

            DatagramPacket request = new DatagramPacket(data, data.length, addr, port);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[128], 128);
            client.receive(response);

            ByteBuffer buff = ByteBuffer.allocate(128);
            buff.put(response.getData());
            buff.flip();

            if(response.getLength() > 8){
                String responseString = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);
                System.out.println(responseString);
            }else {
                System.out.println(buff.getDouble());
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

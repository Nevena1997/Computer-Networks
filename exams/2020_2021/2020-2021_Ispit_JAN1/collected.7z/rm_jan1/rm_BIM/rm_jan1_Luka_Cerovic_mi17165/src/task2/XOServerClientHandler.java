package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class XOServerClientHandler {

    private Socket client;
    private final PrintWriter toClient;
    private final BufferedReader fromClient;
    private final char piece;

    XOServerClientHandler(Socket client, char myPiece) throws IOException {
        this.toClient = new PrintWriter(client.getOutputStream(), true);
        this.fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.piece = myPiece;
    }

    public void sendMsg(String msg) throws IOException{
        this.toClient.println(msg);
    }

    public String getMsg() throws IOException{
        return this.fromClient.readLine();
    }

    public char getPiece() {
        return piece;
    }
}

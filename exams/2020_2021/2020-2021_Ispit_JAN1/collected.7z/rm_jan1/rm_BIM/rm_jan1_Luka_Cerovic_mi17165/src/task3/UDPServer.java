package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

class UDPServer {

    private static int port = 31415;

    public static void main(String[] args) {
    try (DatagramSocket server = new DatagramSocket(port)){

        while (true) {
            try {
                DatagramPacket request = new DatagramPacket(new byte[8], 8);
                server.receive(request);

                ByteBuffer buffer = ByteBuffer.allocate(8);
                buffer.put(request.getData());
                buffer.flip();

                double r = buffer.getDouble();
                byte[] data;

                if (r < 0) {
                    data = "Neispravan poluprecnik".getBytes(StandardCharsets.UTF_8);
                } else {
                    double p = r * r * Math.PI;
                    ByteBuffer buff = ByteBuffer.allocate(8);
                    buff.putDouble(p);
                    buff.flip();

                    data = buff.array();
                }

                DatagramPacket response = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());
                server.send(response);
            } catch (IOException e){
                e.printStackTrace();
            }
        }

    } catch (IOException e){
        e.printStackTrace();
    }
    }

}

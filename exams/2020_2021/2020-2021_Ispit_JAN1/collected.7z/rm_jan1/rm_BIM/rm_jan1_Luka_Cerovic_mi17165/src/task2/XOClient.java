package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {

    private static int port = 12345;
    private static PrintWriter toServer;
    private static BufferedReader fromServer;
    private static char[][] board;
    private static boolean gameOver = false;

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", port)){

            toServer = new PrintWriter(socket.getOutputStream(), true);
            fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            board = new char[3][3];

            for(int i=0; i<3; i++)
                for(int j=0; j<3; j++)
                    board[i][j] = '-';

            System.out.println("Waiting for other player...");
            String gameStart = fromServer.readLine();
            System.out.println("Game starts!");

            try (Scanner sc = new Scanner(System.in)){
                while (true){
                    if(gameOver)
                        break;

                    String maybeMyTurn = fromServer.readLine();
                    if(maybeMyTurn.equalsIgnoreCase("end")){
                        System.out.println("Game over. You lost");
                        break;
                    } else if(maybeMyTurn.startsWith("board=")){
                        String boardString = maybeMyTurn.substring(6);
                        stringToBoard(boardString);
                        printBoard();
                        continue;
                    }

                    printBoard();
                    System.out.println("Your turn!");
                    System.out.flush();

                    while (true) {
                        String moveToSend = readMove(sc);

                        toServer.println(moveToSend);

                        String response = fromServer.readLine();
                        if(response.equalsIgnoreCase("no")) {
                            System.out.println("That move is invalid");
                            continue;
                        } else if(response.equalsIgnoreCase("end")){
                            System.out.println("Game over. You won!");
                            gameOver = true;
                            break;
                        }

                    }
                }
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printBoard(){
        for(int i=0; i<3; i++) {
            for (int j = 0; j < 3; j++)
                System.out.print(board[i][j] + " ");
            System.out.println();
        }
    }

    private static String readMove(Scanner sc){
        int x = sc.nextInt();
        int y = sc.nextInt();

        return x + ":" + y;
    }

    private static void stringToBoard(String boardString){
        String[] array = boardString.split(":");
        board[0][0] = array[0].charAt(0);
        board[0][1] = array[1].charAt(0);
        board[0][2] = array[2].charAt(0);
        board[1][0] = array[3].charAt(0);
        board[1][1] = array[4].charAt(0);
        board[1][2] = array[5].charAt(0);
        board[2][0] = array[6].charAt(0);
        board[2][1] = array[7].charAt(0);
        board[2][2] = array[8].charAt(0);
    }
}

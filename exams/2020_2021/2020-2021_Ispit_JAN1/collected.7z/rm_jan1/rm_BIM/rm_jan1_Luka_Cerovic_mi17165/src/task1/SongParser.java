package task1;

import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class SongParser {

    private final Path path;
    private final String word;

    SongParser(Path path, String word){
        this.path = path;
        this.word = word;
    }

    public void execute() throws IOException {

        try (DirectoryStream<Path> ds = Files.newDirectoryStream(this.path)){
            List<FileReadThread> threads = new ArrayList<>();

            for(Path p : ds){
                FileReadThread t = new FileReadThread(this, p, word);
                threads.add(t);
                t.start();
            }

            for(FileReadThread t : threads) {
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }


    }

    synchronized public void printContent(String content){
        System.out.println(content);
        System.out.flush();
    }
    
}

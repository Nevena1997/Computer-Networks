package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    private int port;
    private XOServerClientHandler currentPlayer;
    private XOServerClientHandler player1;
    private XOServerClientHandler player2;
    private boolean gameOver = false;

    private char[][] board;

    XOServer(int port){
        this.port = port;
        this.board = new char[3][3];
    }

    public static void main(String[] args) {
        XOServer server = new XOServer(12345);
        server.execute();

    }

    private void execute() {
        try (ServerSocket server = new ServerSocket(this.port)){
            System.err.println("Server listening @" + this.port);

            while (true){
                try {

                    Socket p1 = server.accept();
                    System.err.println("Player1 connected");
                    this.player1 = new XOServerClientHandler(p1, 'x');
                    this.currentPlayer = this.player1;

                    Socket p2 = server.accept();
                    System.err.println("Player2 connected");
                    this.player2 = new XOServerClientHandler(p2, 'o');

                    for(int i=0; i<3; i++)
                        for(int j=0; j<3; j++)
                            board[i][j] = '-';

                    System.err.println("Starting game...");

                    player1.sendMsg("start");
                    player2.sendMsg("start");

                    while (true){
                        if(gameOver)
                            break;

                        currentPlayer.sendMsg("go");

                        while (true) {
                            String playerMove = currentPlayer.getMsg();
                            if(playerMove == null) {
                                gameOver = true;
                                break;
                            }

                            String[] coords = playerMove.split(":");
                            int x = Integer.parseInt(coords[0]);
                            int y = Integer.parseInt(coords[1]);

                            if(!isValidMove(x, y)) {
                                currentPlayer.sendMsg("no");
                                continue;
                            }

                            board[x][y] = currentPlayer.getPiece();
                            if(isOver()){
                                String endString = "end";
                                player1.sendMsg(endString);
                                player2.sendMsg(endString);
                                gameOver = true;
                                break;
                            }

                            currentPlayer.sendMsg("yes");

                            if(currentPlayer == player1)
                                currentPlayer = player2;
                            else
                                currentPlayer = player1;

                            player1.sendMsg("board=" + this.boardToString());
                            player2.sendMsg("board=" + this.boardToString());
                        }

                    }
                } catch (IOException e){
                    e.printStackTrace();
                }

            }
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    private String boardToString(){
        StringBuilder sb = new StringBuilder();

        for(int i=0; i<3; i++)
            for(int j=0; j<3; j++){
                sb.append(board[i][j]);
                if(i != 2 || j != 2)
                    sb.append(":");
            }

        System.err.println(sb.toString());
            return sb.toString();
    }

    private boolean isValidMove(int x, int y){
        if(x < 0 || x > 2 || y < 0 || y > 2)
            return false;

        if(board[x][y] == '-')
            return true;
        else
            return false;

    }

    //   0  1  2
    // 0
    // 1
    // 2


    private boolean isOver(){
        if((board[0][0] == board[0][1] && board[0][0] == board[0][2] && board[0][0] != '-')
        || (board[1][0] == board[1][1] && board[1][0] == board[1][2] && board[1][0] != '-')
        || (board[2][0] == board[2][1] && board[2][0] == board[2][2] && board[2][0] != '-')
        || (board[0][0] == board[1][0] && board[0][0] == board[2][0] && board[0][0] != '-')
        || (board[0][1] == board[1][1] && board[0][1] == board[2][1] && board[0][1] != '-')
        || (board[0][2] == board[1][2] && board[0][2] == board[2][2] && board[0][2] != '-')
        || (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] != '-')
        || (board[2][0] == board[1][1] && board[2][0] == board[0][2] && board[2][0] != '-'))
            return true;

        else
            return false;

    }

}

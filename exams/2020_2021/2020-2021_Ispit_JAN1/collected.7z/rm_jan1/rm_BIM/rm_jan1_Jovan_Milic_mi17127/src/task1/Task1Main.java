package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());

        try (Scanner sc = new Scanner(System.in)) {
            String word = sc.nextLine();

            File mainDir = new File("/home/ispit/Desktop/tests/pesme");
            for (File poem : mainDir.listFiles()){
                new Thread(new SongParser(poem.getAbsolutePath(), word)).start();
            }
        }
    }

}

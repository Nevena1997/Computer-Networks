package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

class UDPServer {


    public static final int DEFAULT_PORT = 31415 ;

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());

        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)) {

            System.err.println("Server listening on port: " + DEFAULT_PORT);

           while (true) {
               DatagramPacket request = new DatagramPacket(new byte[16], 16);
               server.receive(request);

               String readData = new String(request.getData(), 0 ,request.getLength());
               double r = Double.parseDouble(readData);

               byte[] bufResponse;
               if (r < 0) {
                   String responseString = "Neispravan poluprecnik";
                   bufResponse = responseString.getBytes();
               } else {
                   Double area = r * r * Math.PI;
                   String areaString = area.toString();
                   bufResponse = areaString.getBytes();
               }

               DatagramPacket response = new DatagramPacket(bufResponse, bufResponse.length, request.getAddress(),
                       request.getPort());
               server.send(response);
           }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

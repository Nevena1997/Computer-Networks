package task2;

import java.io.IOException;
import java.net.Socket;

class XOServerClientHandler implements Runnable{

    Socket client;

    public XOServerClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try {
            byte moveBuf[] = new byte[XOServer.MOVE_SIZE];
            client.getInputStream().read(moveBuf);
            
        } catch (IOException e) {
            try {
                client.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }
    }   
}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

class XOClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());

        try (Socket sock = new Socket("localhost", XOServer.DEFAULT_PORT);
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(System.in)
                )) {

            int[] initialGameState = new int[10];
            Arrays.fill(initialGameState,0);
            printGameState(initialGameState);

            System.out.println("Unesite broj polja na koje zelite da odigrate [0-8]");
            String move = reader.readLine();

            byte[] moveBuf = move.getBytes();

            sock.getOutputStream().write(moveBuf);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printGameState(int[] gameState) {
        for (int i=1; i<=9; i++){
            if (gameState[i] == 0)
                System.out.printf(" _ ");
            else if (gameState[i] == 1)
                System.out.printf(" X ");
            else if (gameState[i] == 2)
                System.out.printf(" O ");

            if (i % 3 == 0)
                System.out.printf("\n");
        }
    }

}

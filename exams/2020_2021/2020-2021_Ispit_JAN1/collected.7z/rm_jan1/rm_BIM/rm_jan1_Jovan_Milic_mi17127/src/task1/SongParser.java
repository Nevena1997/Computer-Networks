package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

class SongParser implements Runnable {

    String songPath;
    String searchedWord;
    LinkedBlockingQueue<String> linesQueue;


    public SongParser(String songPath, String searchedWord) {
        this.songPath = songPath;
        this.searchedWord = searchedWord;
    }

    @Override
    public void run() {

        System.out.println(extractSongName(songPath));
        try {
            List<String> lines = Files.readAllLines(Paths.get(songPath));
            int maxLen = 0;
            String maxLine = "";
            int wordCount = 0;
            for (String line : lines) {
                if (line.length() > maxLen) {
                    maxLen = line.length();
                    maxLine = line;
                }
                wordCount += countWordInLine(line);
            }
            System.out.println(maxLine);
            System.out.println(wordCount);
        } catch (FileNotFoundException ex) {
            System.err.println("No such file!");
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


     private String extractSongName(String songPath) {
        int startIndex = songPath.lastIndexOf("/");
        int endIndex = songPath.lastIndexOf(".");

        String songNameWithoutSpaces = songPath.substring(startIndex+1, endIndex);
        StringBuilder sb = new StringBuilder();

        for (char c : songNameWithoutSpaces.toCharArray()){
            if (songNameWithoutSpaces.indexOf(c) == 0)
                sb.append(c);
            else if (Character.isUpperCase(c)) {
                sb.append(' ');
                sb.append(c);
            } else
                sb.append(c);
        }

        return sb.toString();

    }

     private int countWordInLine(String line) {
        int count = 0;
        int index = line.indexOf(this.searchedWord);
        while (index != -1){
            line = line.substring(index + 1);
            count++;
            index = line.indexOf(this.searchedWord);
        }

        return count;
    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {


    public static final int DEFAULT_PORT = 12345;
    public static final int MOVE_SIZE = 1;
    public static int numOfClients = 0;

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)) {
            System.err.println("Listening on port : " + DEFAULT_PORT);

            while (true) {
                while (numOfClients < 2) {
                    Socket client = server.accept();
                    numOfClients++;
                    new Thread(new XOServerClientHandler(client)).start();
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try (DatagramSocket client = new DatagramSocket();
             BufferedReader reader = new BufferedReader(
                                     new InputStreamReader(System.in))
             ) {


            String readData = reader.readLine();
            byte[] buf = readData.getBytes();

            DatagramPacket request = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), UDPServer.DEFAULT_PORT);
            client.send(request);
            System.err.println("Request sent...");

            DatagramPacket response = new DatagramPacket(new byte[32], 32);
            client.receive(response);
            System.err.println("Response received...");

            double r = Double.parseDouble(readData);
            String received = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);
            System.out.println(received );

        } catch (IOException e) {
            e.printStackTrace();
        }{





        }
    }


}

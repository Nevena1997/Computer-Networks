package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {

    public static int PORT = 31415;
    
    public static void main(String[] args) {

            try(DatagramSocket server = new DatagramSocket(PORT)){

                System.out.println("Server slusa na portu: " + PORT);

                while(true){
                    byte[] buf = new byte[128];
                    DatagramPacket request = new DatagramPacket(buf, buf.length);
                    server.receive(request);

                    String req = new String(request.getData(), 0, request.getLength());
                    double r = Double.parseDouble(req);

                    String value;

                    if(r <= 0)
                        value = "Neispravan poluprecnik!";
                    else {
                        double P = r * r * 3.14;
                        value = "" + P;
                    }

                    buf = value.getBytes(StandardCharsets.UTF_8);

                    DatagramPacket response = new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                    server.send(response);
                }

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    public static int PORT = 12345;


    public static void main(String[] args) throws IOException {
        XOServer server = new XOServer(PORT);
        System.out.println("Server slusa na portu: " + PORT);
        server.execute();
    }

    private char[] table;
    private ServerSocket server;
    public int turn;

    XOServer(int port) throws IOException {
        this.server = new ServerSocket(port);
        this.table = new char[9];
        for(int i=0; i<9; i++)
            this.table[i] = '-';
        this.turn = 1;
    }

    private void execute() {

        try{

            while(true)
                startGame();

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }

    private void startGame() throws IOException, InterruptedException {

        Socket client1 = server.accept();
        XOServerClientHandler player1 = new XOServerClientHandler(this, client1, 1);

        Socket client2 = server.accept();
        XOServerClientHandler player2 = new XOServerClientHandler(this, client2, 2);

        player1.start();
        player2.start();

        player1.join();
        player2.join();
    }

    public String getTable(){

        StringBuilder sb = new StringBuilder();
        for(int i=0; i<9; i++){

                if(i%3 == 0)
                    sb.append("\n");

                sb.append(this.table[i]);
            }
        return sb.toString();
    }

    public void playMove(int move, char c) {

        this.table[move-1] = c;
    }
}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class XOServerClientHandler extends Thread{

    private XOServer server;
    private Socket socket;
    private int index;
    private BufferedReader fromUser;
    private PrintWriter toUser;

    XOServerClientHandler(XOServer server, Socket socket, int index){
        this.server = server;
        this.socket = socket;
        this.index = index;
        try {
            fromUser = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            toUser = new PrintWriter(this.socket.getOutputStream(),true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int getTurn(){
        return this.server.turn;
    }

    @Override
    public void run() {

        char c;
        if(index == 1)
            c = 'X';
        else
            c = 'O';

        while(true){

            if(getTurn() == this.index){

                toUser.println(this.server.getTable());

                server.playMove(takeMove(), c);

                if(index == 1)
                    server.turn = 2;
                else
                    server.turn = 1;
            }
        }
    }

    private int takeMove() {
        int move = -1;

        try {
                while (true) {
                String line = fromUser.readLine();
                move = Integer.parseInt(line);

                if (move < 1 || move > 9)
                    toUser.write("Nevalidan potez!");
                else
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.toUser.write("Ok");
        return move;
    }
}

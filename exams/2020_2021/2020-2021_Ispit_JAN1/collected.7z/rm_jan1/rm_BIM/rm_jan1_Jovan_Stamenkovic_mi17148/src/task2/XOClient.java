package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {
        XOClient client = new XOClient();
        System.out.println("Client povezan sa serverom");
        client.execute();
    }

    private BufferedReader fromServer;
    private BufferedWriter toServer;
    private Socket client;

    XOClient(){
        try {
            this.client = new Socket("localhost", XOServer.PORT);
            this.fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void execute() {

        try(Scanner in = new Scanner(System.in)) {
         
            while (true) {
                try {
                    String table = fromServer.readLine();
                    System.out.println(table);

                    String response;

                    do {
                        int move = in.nextInt();
                        String toSend = "" + move;
                        toServer.write(toSend);

                        response = fromServer.readLine();

                    } while (!response.equalsIgnoreCase("Ok"));


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }


}

package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(Scanner in = new Scanner(System.in);
            DatagramSocket client = new DatagramSocket()){

            System.out.println("Unesite poluprecnik: ");
            String r = in.next();
            byte[] bufRequest = new byte[128];
            bufRequest = r.getBytes(StandardCharsets.UTF_8);
            InetAddress address = InetAddress.getLocalHost();
            DatagramPacket request = new DatagramPacket(bufRequest, bufRequest.length, address, UDPServer.PORT);
            client.send(request);

            byte[] bufResponse = new byte[128];
            DatagramPacket response = new DatagramPacket(bufResponse, bufResponse.length);
            client.receive(response);

            String value = new String(response.getData(), 0, response.getLength());

            if(value.equalsIgnoreCase("Neispravan poluprecnik!"))
                System.out.println(value);
            else
                System.out.println("Povrsina kruga je : " + value);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {

    public static int PORT = 31415;
    public static String HOST = "localhost";


    public static void main(String[] args) {

        String errMessage = "Neipravan poluprecnik";
        double PI = 3.14;

       try(DatagramSocket server = new DatagramSocket(PORT)){

           while(true){
               DatagramPacket recieve = new DatagramPacket(new byte[23], 23);
               server.receive(recieve);

               Double r = Double.parseDouble(new String(recieve.getData()));
               DatagramPacket send;

               if(r < 0){
                    send = new DatagramPacket(errMessage.getBytes(StandardCharsets.UTF_8), errMessage.length(),
                            recieve.getAddress(), recieve.getPort());
               }else{
                   double p = r*r*PI;
                   String message = p + "";
                   send = new DatagramPacket(message.getBytes(StandardCharsets.UTF_8), message.length(),
                           recieve.getAddress(), recieve.getPort());
               }

                server.send(send);
           }




       } catch (SocketException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       }
    }

}

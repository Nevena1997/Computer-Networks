package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;

class SongParser implements Runnable {
    File file;
    int broj_ponavljanja;
    Lock lock;
    String rec;

    private void broj_ponavljanje(String line){

        for(String rec : line.split(" ")){
            if(rec.toLowerCase().contains(this.rec))
                this.broj_ponavljanja++;
        }

    }

    public SongParser(File file, Lock lock, String rec) {
        this.file = file;
        this.lock = lock;
        this.rec = rec;
        this.broj_ponavljanja = 0;
    }

    @Override
    public void run() {
        String line = "";
        String max_line = "";

        try(Scanner read = new Scanner(this.file)){

            while(read.hasNext()){

                line = read.nextLine().trim();
                if(line.length() > max_line.length()){
                    max_line = line;
                }

                broj_ponavljanje(line);

            }

            this.lock.lock();
                System.out.println(this.file.getName().split(".txt")[0]);
                System.out.println(max_line);
                System.out.println(this.broj_ponavljanja);
            this.lock.unlock();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}

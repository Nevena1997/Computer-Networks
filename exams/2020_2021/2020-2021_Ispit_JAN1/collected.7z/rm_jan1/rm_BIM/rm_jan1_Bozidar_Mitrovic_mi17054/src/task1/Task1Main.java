package task1;

import java.io.File;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Task1Main {
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Lock lock = new ReentrantLock();

        File pesme = new File("/home/ispit/Desktop/tests/pesme");

        try {
            for (File f : pesme.listFiles()) {
                System.out.println(f.getAbsolutePath());
            }

            String rec = sc.nextLine().trim();

            for (File f : pesme.listFiles()) {
                new Thread(new SongParser(f, lock, rec.toLowerCase())).start();
            }
        }catch(NullPointerException e){
            e.printStackTrace();
        }

    }

}

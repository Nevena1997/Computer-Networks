package task2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class XOServer {
    private static ArrayList<Socket> igraci = new ArrayList<>();
    public static int PORT = 12345;
    public static String host = "localhost";
    public static String[] tabla = {"_", "_", "_","_", "_", "_","_", "_", "_"};
    public static String[] simbol = {"X", "O"};

    public static void pisi_klijentima(int id) throws IOException {

        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(igraci.get(id).getOutputStream()));

        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < tabla.length; i++)
            sb.append(tabla[i]).append(",");

        out.write(sb.toString());
        out.newLine();
        out.flush();
    }

    public static boolean proveri_ima_li_pobednika(){

        if(tabla[0].equals(tabla[3]) && tabla[3].equals(tabla[6]) && !tabla[0].equals("_"))
            return true;

        if(tabla[1].equals(tabla[4]) && tabla[4].equals(tabla[7]) && !tabla[1].equals("_"))
            return true;

        if(tabla[2].equals(tabla[5]) && tabla[5].equals(tabla[8]) && !tabla[2].equals("_"))
            return true;

        if(tabla[0].equals(tabla[1]) && tabla[1].equals(tabla[2]) && !tabla[0].equals("_"))
            return true;

        if(tabla[3].equals(tabla[4]) && tabla[4].equals(tabla[5]) && !tabla[3].equals("_"))
            return true;

        if(tabla[6].equals(tabla[7]) && tabla[7].equals(tabla[8]) && !tabla[6].equals("_"))
            return true;

        if(tabla[0].equals(tabla[4]) && tabla[4].equals(tabla[8]) && !tabla[0].equals("_"))
            return true;

        if(tabla[2].equals(tabla[4]) && tabla[4].equals(tabla[6]) && !tabla[2].equals("_"))
            return true;

        return false;
    }

    public static void ugasi_igraca(int index) throws IOException {
        igraci.get(index).close();
    }

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(PORT)){
                while(igraci.size() != 2){
                    Socket socket = server.accept();
                    System.err.println("Klijent prihvacen!");
                    igraci.add(socket);
                }

                for(int i = 0; i < igraci.size(); i++){
                    new Thread(new XOServerClientHandler(i, igraci.get(i), simbol[i])).start();
                }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable {
    int i;
    Socket socket;
    String simbol;

    public XOServerClientHandler(int i, Socket socket, String simbol) {
        this.i = i;
        this.socket = socket;
        this.simbol = simbol;
    }

    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()))) {

            String line;

            System.out.println(this.i);

            while(true){

                int id = (this.i == 0 ? 1 : 0);
                XOServer.pisi_klijentima(id);

                if(socket.isClosed())
                    return;

                line = in.readLine();
                int index = Integer.parseInt(line);
                XOServer.tabla[index] = this.simbol;

                if(XOServer.proveri_ima_li_pobednika()){
                    XOServer.ugasi_igraca(this.i);
                    break;
                }

                //System.out.println("Pisem iz niti: " + this.i + " " + XOServer.proveri_ima_li_pobednika());

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

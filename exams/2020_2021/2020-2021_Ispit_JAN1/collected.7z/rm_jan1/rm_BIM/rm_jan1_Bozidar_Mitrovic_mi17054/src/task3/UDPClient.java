package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){

            client.connect(new InetSocketAddress(UDPServer.PORT));
            String line;

            while(true){

                line = sc.nextLine().trim();
                DatagramPacket send = new DatagramPacket(line.getBytes(StandardCharsets.UTF_8), line.length());
                client.send(send);

                DatagramPacket recieve = new DatagramPacket(new byte[23], 23);
                client.receive(recieve);
                System.out.println(new String(recieve.getData(), 0, recieve.getLength()));
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

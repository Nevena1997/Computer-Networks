package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    public static final int PORT = 31415;

    public static void main(String[] args) {
        while (true) {
            try (DatagramSocket server = new DatagramSocket(PORT)) {
                byte[] buf = new byte[64];
                DatagramPacket fromClient = new DatagramPacket(buf, buf.length);
                server.receive(fromClient);

                String num = new String(buf);
                double clientNum = Double.parseDouble(num.trim());

                String response = "";
                if (clientNum < 0.0) {
                    response = "Neispravan poluprecnik";
                } else {
                    double area = clientNum*clientNum*Math.PI;
                    response = String.valueOf(area);
                }

                buf = response.getBytes();
                DatagramPacket toClient = new DatagramPacket(buf, buf.length, fromClient.getAddress(), fromClient.getPort());
                server.send(toClient);

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}

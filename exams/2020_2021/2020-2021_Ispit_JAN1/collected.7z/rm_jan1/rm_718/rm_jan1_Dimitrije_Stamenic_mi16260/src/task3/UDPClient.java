package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
            Scanner userIn = new Scanner(System.in);
        ) {
            double num = userIn.nextDouble();
            String toServer = String.valueOf(num);
            byte[] buf = toServer.getBytes();
            DatagramPacket toServerDP = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), UDPServer.PORT);
            client.send(toServerDP);


            byte[] responseBuf = new byte[64];
            DatagramPacket responseDP = new DatagramPacket(responseBuf, responseBuf.length);
            client.receive(responseDP);
            String response = new String(responseBuf);
            System.out.println(response.trim());


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

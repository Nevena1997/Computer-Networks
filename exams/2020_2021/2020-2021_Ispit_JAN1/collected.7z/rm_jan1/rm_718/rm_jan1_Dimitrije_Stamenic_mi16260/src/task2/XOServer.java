package task2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

class XOServer {

    public static int DEFAULT_PORT = 12345;
    public int numOfPlayers = 0;
    public Vector<Vector<Integer>> tabela = new Vector<>();

    private final int port;
    private Vector<XOServerClientHandler> players = new Vector<>();

    XOServer(int port) {
        this.port = port;
    }
    
    public static void main(String[] args) {
        XOServer s = new XOServer(DEFAULT_PORT);
        s.execute();
    }

    private void execute() {
        try (ServerSocket server = new ServerSocket(this.port)) {
            while (true) {
                while (numOfPlayers < 2) {
                    // Cekamo 2 igraca da se pridruze
                    Socket player = server.accept();
                    XOServerClientHandler csHandler = new XOServerClientHandler(this, player);
                    players.add(csHandler);
                    numOfPlayers++;
                    // Ovde cemo da povecavamo broj igraca,
                    // a igrac kad se diskonektuje, onda ce sam da smanji broj igraca
                }

                // Pokrecemo igru za 2 igraca
//                System.out.println("Stigla 2 igraca");
//                System.out.println(players);
                initGame();
                startTheGame();


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startTheGame() {
        System.out.println("igra krece");
        boolean gameInProgress = true;
        int igracNaPotezu = 0;

        while (gameInProgress) {
//            posaljiStanje(igracNaPotezu);

            this.players.get(igracNaPotezu).writeToPlayer("ZDRAVO");

            String potez = null;
            if ((potez = primiPotez(igracNaPotezu)) != null) {
                System.out.println(potez);
            }

            // azuriranje tabele

            if(win()) {
                gameInProgress = false;
                this.players.get(0).endGame();
                this.players.get(1).endGame();
            }
        }

        // Zavrsili smo igru i raskidamo vezu sa igracima
    }

    private boolean win() {
        return false;
    }

    private String primiPotez(int igracNaPotezu) {
        String potez = null;
        potez = this.players.get(igracNaPotezu).receiveFromPlayer();
        return potez;
    }

    private void initGame() {
        Vector<Integer> tmp = new Vector<>();

        for (int i=0; i<3; i++) {
            for (int j=0; j<3; j++) {
                tmp.add(-1);
            }
            tabela.add(i, tmp);
        }
    }

    private void posaljiStanje(int igracNaPotezu) {
        String tabla = "";

        for (int i=0; i<3; i++) {
            for (int j=0; j<3; j++) {
                if (tabela.get(i).get(j) == -1){
                    tabla += "- ";
                } else if (tabela.get(i).get(j) == 0) {
                    tabla += "X ";
                } else if (tabela.get(i).get(j) == 1) {
                    tabla += "O ";
                }
            }
            tabla += "\n";
        }

        this.players.get(igracNaPotezu).writeToPlayer(tabla);
    }

}

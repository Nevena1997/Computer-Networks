package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

class XOServerClientHandler {
    private XOServer server;
    private PrintWriter toClient;
    private BufferedReader fromClient;
    private Socket clientSock;

    XOServerClientHandler(XOServer s, Socket clientSocket) {
        this.server = s;
        try {
            this.toClient = new PrintWriter(clientSocket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            this.fromClient= new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.clientSock = clientSocket;
    }

    public void writeToPlayer(String msg) {
        this.toClient.println(msg);
    }

    public String receiveFromPlayer() {
        String potez = null;
        try {
            potez = this.fromClient.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return potez;
    }

    public void endGame() {
        try {
            this.clientSock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", XOServer.DEFAULT_PORT);
             PrintWriter toServer = new PrintWriter(
                     new OutputStreamWriter(client.getOutputStream())
             );
             BufferedReader fromServer = new BufferedReader(
                     new InputStreamReader(client.getInputStream())
             );
             Scanner userIn = new Scanner(System.in);
        ) {

            String userPotez = null;
            String fromServerString;
            while (true) {
                // (1) ispis trenutnog stanja igre
                System.out.println(fromServer.readLine());

                // (2) ucitavanje poteza igraca
                int i = userIn.nextInt();
                int j = userIn.nextInt();
                userPotez = i + ";" + j;

                // (3) slanje poteza serveru
                toServer.println(userPotez);

            }




        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

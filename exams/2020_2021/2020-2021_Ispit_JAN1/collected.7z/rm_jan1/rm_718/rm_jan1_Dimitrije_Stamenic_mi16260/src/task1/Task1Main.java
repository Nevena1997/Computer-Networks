package task1;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        Scanner userIn = new Scanner(System.in);
        String rec = userIn.nextLine();
        try {
            File dat = new File("/home/ispit/Desktop/tests/pesme/");
            File[] txtPesme = dat.listFiles();

            for (File f: txtPesme) {
                SongParser song = new SongParser(f, rec);
                song.run();
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            System.err.println("Nema datoteke na navedenoj putanji");
        }

    }

}

package task1;

import java.io.*;

class SongParser extends Thread{
    private File f;
    private String songName;
    private String word;

    SongParser(File f, String w) {
        this.f = f;
        this.word = w;
    }

    public void run() {
        setSongName();
        System.out.println(songName);

        printLongestVerseAndWordCount(this.word);

    }

    private void printWordCount(String word) {

    }

    private void printLongestVerseAndWordCount(String w) {
        try (BufferedReader fromFile = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(this.f)
                )
        )) {

            String line;
            int longestLineLen = 0;
            String longestLine = "";

            int wCount = 0;

            while ((line = fromFile.readLine()) != null) {
                if (line.length() > longestLineLen) {
                    longestLine = line;
                    longestLineLen = line.length();
                }

                String[] lineWords = line.split(" ");
                for (String s : lineWords) {
                    if (s.equalsIgnoreCase(w)) wCount++;
                }


            }
            System.out.println(longestLine);
            System.out.println(wCount);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void setSongName() {
        this.songName = this.f.getName();
        int songNameLen = this.songName.length();
        this.songName = this.songName.substring(0, songNameLen-4);
    }

}

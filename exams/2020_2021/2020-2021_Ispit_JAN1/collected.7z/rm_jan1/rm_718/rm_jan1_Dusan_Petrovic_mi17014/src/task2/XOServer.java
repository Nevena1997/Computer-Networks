package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class XOServer {

    ArrayList<String> tabla;
    ArrayList<Igrac> igraci;

    @Override
    public String toString() {
        String str = "";
        for (int i=0; i<3; i++){
            str += tabla.get(3*i);
            str += tabla.get(3*i+1);
            str += tabla.get(3*i+2);
            str += "\n";
        }
        return str;
    }

    XOServer(){
        this.tabla = new ArrayList<>();
        for(int i=0; i<9; i++){
            tabla.add("-");
        }
        this.igraci = new ArrayList<Igrac>();
    }

    boolean kraj(){
        if(tabla.get(0).equals(tabla.get(1)) && tabla.get(0).equals(tabla.get(2)) && !tabla.get(0).equals("-"))
            return true;
        if(tabla.get(3).equals(tabla.get(4)) && tabla.get(3).equals(tabla.get(5)) && !tabla.get(3).equals("-"))
            return true;
        if(tabla.get(6).equals(tabla.get(7)) && tabla.get(6).equals(tabla.get(8)) && !tabla.get(6).equals("-"))
            return true;
        if(tabla.get(0).equals(tabla.get(3)) && tabla.get(0).equals(tabla.get(6)) && !tabla.get(0).equals("-"))
            return true;
        if(tabla.get(1).equals(tabla.get(4)) && tabla.get(1).equals(tabla.get(7)) && !tabla.get(1).equals("-"))
            return true;
        if(tabla.get(2).equals(tabla.get(5)) && tabla.get(2).equals(tabla.get(8)) && !tabla.get(2).equals("-"))
            return true;
        if(tabla.get(0).equals(tabla.get(4)) && tabla.get(0).equals(tabla.get(8)) && !tabla.get(0).equals("-"))
            return true;
        if(tabla.get(6).equals(tabla.get(4)) && tabla.get(6).equals(tabla.get(2)) && !tabla.get(6).equals("-"))
            return true;
        return false;
    }

    static class Igrac extends Thread {
        XOServer xo;
        Socket client;
        int br = 0;
        String znak;
        BufferedReader in;
        BufferedWriter out;

        Igrac(XOServer xo, Socket client, int br) throws IOException {
            this.xo = xo;
            this.client = client;
            this.br = br;
            if (br == 0) {
                this.znak = "X";
            } else {
                this.znak = "O";
            }
            this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

        }

        @Override
        public void interrupt() {
            super.interrupt();
        }

        @Override
        public void run() {
            System.out.println(znak);
            try {
                if (znak.equals("X")) {
                    out.write(xo.toString());
                    out.newLine();
                    out.flush();
                }

                while (true) {
                    String p = in.readLine();
                    int polje = Integer.parseInt(p) - 1;

                    if(polje < 0 || polje > 8 || !xo.tabla.get(polje).equals("-")){
                        out.write("Nevalidan potez");
                        out.newLine();
                        out.flush();
                        continue;
                    }
                    else {
                        xo.tabla.set(polje, znak);

                        if (xo.kraj()){
                            out.write("kraj");
                            out.newLine();
                            out.flush();

                            out.write(xo.toString());
                            out.newLine();
                            out.flush();

                            if (br == 0) {
                                var o = xo.igraci.get(1).out;

                                o.write("kraj");
                                o.newLine();
                                o.flush();

                                o.write(xo.toString());
                                o.newLine();
                                o.flush();

                                xo.igraci.get(1).stop();
                            } else {
                                var o = xo.igraci.get(0).out;

                                o.write("kraj");
                                o.newLine();
                                o.flush();

                                o.write(xo.toString());
                                o.newLine();
                                o.flush();

                                xo.igraci.get(0).suspend();
                            }

                            break;
                        }

                        out.write("ok");
                        out.newLine();
                        out.flush();
                    }

                    if (br == 0) {
                        var o = xo.igraci.get(1).out;
                        o.write(xo.toString());
                        o.newLine();
                        o.flush();
                    } else {
                        var o = xo.igraci.get(0).out;
                        o.write(xo.toString());
                        o.newLine();
                        o.flush();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOServer.class.getName());
        XOServer xo = new XOServer();
        int br = 0;
        try(ServerSocket server = new ServerSocket(12345)){

            while (true){

                var client = server.accept();
                Igrac i = new Igrac(xo, client, br);
                xo.igraci.add(i);
                br += 1;

                if (br == 2){
                    for (var ig : xo.igraci){
                        ig.start();
                    }
                    for (var ig : xo.igraci){
                        ig.join();
                    }

                    br = 0;
                }

            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

}

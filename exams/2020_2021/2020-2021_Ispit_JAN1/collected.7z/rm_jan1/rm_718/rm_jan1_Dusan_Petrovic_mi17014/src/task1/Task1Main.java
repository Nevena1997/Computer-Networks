package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

class Task1Main {

    static class Nit extends Thread{
        File f;
        String rec;
        int i;
        Nit(File f, String rec, int i){
            this.f = f;
            this.rec = rec;
            this.i = i;
        }

        @Override
        public void run() {
            Scanner r = null;
            try {
                r = new Scanner(f);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            String max = "";
            int c = 0;
            while (r.hasNext()){
                String line = r.nextLine();
                if (line.length() > max.length())
                    max = line;
                Scanner r1 = new Scanner(line);
                if (line.contains(rec))
                    c += 1;
            }
            try {
                sleep(i*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(f.getName().substring(0, f.getName().length()-4));
            System.out.println(max);
            System.out.println(c);
        }
    }
    
    public static void main(String[] args) throws FileNotFoundException {

        System.out.println("Hello from: " + Task1Main.class.getName());

        Scanner sc = new Scanner(System.in);
        String rec = sc.nextLine();
        ArrayList<File> files = new ArrayList<>();

        files.add(new File("../tests/pesme/AlSuToGrdneMuke.txt"));
        files.add(new File("../tests/pesme/Dolap.txt"));
        files.add(new File("../tests/pesme/DomovinaSeBraniLepotom.txt"));
        files.add(new File("../tests/pesme/LjubavnaPesma.txt"));
        files.add(new File("../tests/pesme/MozdaSpava.txt"));
        files.add(new File("../tests/pesme/PoslednjaPesma.txt"));

        int i = 1;
        for (var f : files){
            Nit n = new Nit(f, rec, i);
            n.start();
            i+=1;
        }


    }

}

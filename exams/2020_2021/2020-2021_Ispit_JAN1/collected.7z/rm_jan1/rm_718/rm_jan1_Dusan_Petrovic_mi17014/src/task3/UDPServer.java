package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPServer {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPServer.class.getName());
        while (true) {
            try (DatagramSocket socket = new DatagramSocket(31415)) {

                byte[] data = new byte[8];
                DatagramPacket response = new DatagramPacket(data, 8);
                socket.receive(response);
                double r = ByteBuffer.wrap(response.getData()).getDouble();
                System.out.println(ByteBuffer.wrap(response.getData()).getDouble());

                if (r < 0)
                    r = -1;
                else
                    r = r * r * 3.1416;

                byte[] buf = ByteBuffer.allocate(8).putDouble(r).array();
                DatagramPacket request = new DatagramPacket(buf, buf.length, response.getAddress(), response.getPort());
                socket.send(request);


            } catch (SocketException | UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());
        try(Socket socket = new Socket("localhost", 12345)){

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            Scanner sc = new Scanner(System.in);
            boolean b = false;

            String kontrola = "";
            while (true){
                for(int i =0; i<4; i++){
                    String line = in.readLine();
                    if(line.equals("kraj")){
                        for(int j =0; j<4; i++) {
                            String line1 = in.readLine();
                            System.out.println(line1);
                        }
                        b = true;
                    }
                    System.out.println(line);
                }
                if (b){
                    break;
                }
                do {
                    String p = sc.nextLine();
                    out.write(p);
                    out.newLine();
                    out.flush();
                    kontrola = in.readLine();
                    if (kontrola.equals("Nevalidan potez")){
                        System.out.println(kontrola);
                    }
                } while (kontrola.equals("Nevalidan potez"));

                if(kontrola.equals("kraj")){
                    for(int i =0; i<4; i++){
                        System.out.println(in.readLine());
                    }
                    break;
                }
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

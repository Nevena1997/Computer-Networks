package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());
        System.out.println("Hello from: " + UDPServer.class.getName());
        try(DatagramSocket socket = new DatagramSocket()) {

            Scanner sc = new Scanner(System.in);
            double b = sc.nextDouble();
            byte[] buf = ByteBuffer.allocate(8).putDouble(b).array();
            InetAddress address = InetAddress.getLocalHost();
            DatagramPacket request = new DatagramPacket(buf, buf.length, address, 31415);
            socket.send(request);

            byte[] data = new byte[8];
            DatagramPacket response = new DatagramPacket(data, 8);
            socket.receive(response);
            double r = ByteBuffer.wrap(response.getData()).getDouble();
            if (r == -1)
                System.out.println("Neispravan polupecnik");
            else
                System.out.println(r);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

class XOClient {
    private Socket socket;

    public XOClient(String host, int port) throws IOException {
        this.socket=new Socket(host,port);
    }

    public void startGame(){
        try {
            new Thread(()->{
                while(true){
                    byte[] table=new byte[15];
                    try {
                        int read=socket.getInputStream().read(table);
                        if(read<=0) return;
                        System.out.println(new String(table).trim());
                    } catch (IOException e) {
                        try {
                            socket.close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        System.exit(0);
                    }
                }
            }).start();
            Scanner sc=new Scanner(System.in);
            DataOutputStream ds=new DataOutputStream(socket.getOutputStream());
            while(true){
                int position=sc.nextInt();
                ds.writeInt(position);
                ds.flush();
            }
        } catch (IOException e) {
            System.out.println("Zavrsena igra.");
            System.exit(0);
        }
    }
    public static void main(String[] args) {
        System.out.println("Hello from: " + XOClient.class.getName());
        try {
            XOClient client=new XOClient("localhost",12345);
            client.startGame();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

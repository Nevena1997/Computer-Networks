package task2;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

class XOServerClientHandler {
    private Socket player1;
    private Socket player2;
    private char[] table=new char[9];
    private int onMove=1;

    public XOServerClientHandler(){
        Arrays.fill(table,'-');
    }

    public boolean player1Move(int number){
        if(number>8) return false;
        if(table[number-1]=='X'||table[number-1]=='O'){
            return false;
        }else{
            table[number-1]='X';
            return true;
        }
    }

    public boolean player2Move(int number){
        if(number>8) return false;
        if(table[number-1]=='X'||table[number-1]=='O'){
            return false;
        }else{
            table[number-1]='O';
            return true;
        }
    }

    public Socket getPlayer1() {
        return player1;
    }

    public void setPlayer1(Socket player1) {
        this.player1 = player1;
    }

    public Socket getPlayer2() {
        return player2;
    }

    public void setPlayer2(Socket player2) {
        this.player2 = player2;
    }

    public String getTable(){
        StringBuilder sb=new StringBuilder();
        sb.append(String.format("%c%c%c\n",table[0],table[1],table[2]));
        sb.append(String.format("%c%c%c\n",table[3],table[4],table[5]));
        sb.append(String.format("%c%c%c\n",table[6],table[7],table[8]));
        return sb.toString();
    }

    public void writeTable(Socket player) throws IOException {
        player.getOutputStream().write(getTable().getBytes(StandardCharsets.UTF_8));
        player.getOutputStream().flush();
    }

    public void start() {
        try{
            writeTable(player1);
            writeTable(player2);
            while(!gameEnds()){
                if(onMove==1){
                    boolean success=player1Move(readFromPlayer1());
                    if(success) {
                        onMove = 2;
                        writeTable(player1);
                        writeTable(player2);
                    }else{
                        writeMessageToPlayer("Nevalidan potez",player1);
                        onMove = 1;
                    }
                }else{
                    boolean success=player2Move(readFromPlayer2());
                    if(success) {
                        onMove = 1;
                        writeTable(player1);
                        writeTable(player2);
                    }else{
                        writeMessageToPlayer("Nevalidan potez",player2);
                        onMove = 2;
                    }
                }
            }
            writeMessageToPlayer("Gotova igra.",player1);
            writeMessageToPlayer("Gotova igra.",player2);
            player1.close();
            player2.close();
        }catch (IOException e){
            System.out.println("Game interrupted. One client disconnected.");
            try {
                player1.close();
                player2.close();
            } catch (IOException ex) {

            }
        }
    }

    private boolean gameEnds() {
        if(table[0]=='X'&&table[1]=='X'&&table[2]=='X') return true;
        if(table[0]=='O'&&table[1]=='O'&&table[2]=='O') return true;
        if(table[3]=='X'&&table[4]=='X'&&table[5]=='X') return true;
        if(table[3]=='O'&&table[4]=='O'&&table[5]=='O') return true;
        if(table[6]=='X'&&table[7]=='X'&&table[8]=='X') return true;
        if(table[6]=='O'&&table[7]=='O'&&table[8]=='O') return true;

        if(table[0]=='X'&&table[3]=='X'&&table[6]=='X') return true;
        if(table[0]=='O'&&table[3]=='O'&&table[6]=='O') return true;
        if(table[1]=='X'&&table[4]=='X'&&table[7]=='X') return true;
        if(table[1]=='O'&&table[4]=='O'&&table[7]=='O') return true;
        if(table[2]=='X'&&table[5]=='X'&&table[8]=='X') return true;
        if(table[2]=='O'&&table[5]=='O'&&table[8]=='O') return true;

        if(table[0]=='X'&&table[4]=='X'&&table[8]=='X') return true;
        if(table[0]=='O'&&table[4]=='O'&&table[8]=='O') return true;

        if(table[2]=='X'&&table[4]=='X'&&table[6]=='X') return true;
        if(table[2]=='O'&&table[4]=='O'&&table[6]=='O') return true;

        return false;
    }

    public int readFromPlayer1() throws IOException {
        int position;
        DataInputStream ds=new DataInputStream(player1.getInputStream());
        position=ds.readInt();
        return position;
    }

    public int readFromPlayer2() throws IOException {
        int position;
        DataInputStream ds=new DataInputStream(player2.getInputStream());
        position=ds.readInt();
        return position;
    }

    public void writeMessageToPlayer(String msg, Socket player) throws IOException {
        player.getOutputStream().write(msg.getBytes(StandardCharsets.UTF_8));
        player.getOutputStream().flush();
    }
}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {

    private DatagramSocket serverSocket;

    public UDPServer() throws SocketException {
        serverSocket=new DatagramSocket(new InetSocketAddress(31415));
    }

    public void start(){
        try{
            while(true){
                byte[] buff=new byte[1024];
                DatagramPacket received=new DatagramPacket(buff,buff.length);
                serverSocket.receive(received);
                double r=Double.parseDouble(new String(buff, StandardCharsets.UTF_8).trim());
                double p=r*r*Math.PI;
                if(r>=0) {
                    String pS = p + "";
                    DatagramPacket toSend = new DatagramPacket(pS.getBytes(StandardCharsets.UTF_8), pS.getBytes(StandardCharsets.UTF_8).length, received.getAddress(), received.getPort());
                    serverSocket.send(toSend);
                }else{
                    DatagramPacket toSend = new DatagramPacket("Neispravan poluprecnik.".getBytes(StandardCharsets.UTF_8), 23, received.getAddress(), received.getPort());
                    serverSocket.send(toSend);
                }
            }
        } catch (IOException e) {
            System.err.println("Error. Problem communicating with client, or other server error");
            return;
        }finally {
            serverSocket.close();
        }
    }
    
    public static void main(String[] args) throws SocketException {
        System.out.println("Hello from: " + UDPServer.class.getName());
        UDPServer server=new UDPServer();
        server.start();
    }

}

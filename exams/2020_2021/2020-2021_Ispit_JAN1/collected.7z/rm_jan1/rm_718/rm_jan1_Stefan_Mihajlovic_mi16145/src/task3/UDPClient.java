package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {

    private DatagramSocket socket;

    public UDPClient(String host, int port) throws SocketException {
        socket=new DatagramSocket();
        socket.connect(new InetSocketAddress(host,port));
    }

    public void start(){
        try{
            Scanner sc=new Scanner(System.in);
            double r=sc.nextDouble();
            String rS=r+"";
            DatagramPacket toSend=new DatagramPacket(rS.getBytes(StandardCharsets.UTF_8),rS.getBytes(StandardCharsets.UTF_8).length);
            try {
                socket.send(toSend);
            } catch (IOException e) {
                e.printStackTrace();
            }
            byte[] buff=new byte[1024];
            DatagramPacket received=new DatagramPacket(buff,buff.length);
            try {
                socket.receive(received);
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Primljeno: "+new String(buff).trim());
            sc.close();
            socket.close();
        }catch (Exception e){
            System.err.println("Failed to read value, or problem with sending.");
        }
    }
    
    public static void main(String[] args) throws SocketException {
        System.out.println("Hello from: " + UDPClient.class.getName());
        UDPClient client=new UDPClient("localhost",31415);
        client.start();
    }

}

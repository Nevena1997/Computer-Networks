package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {
    private static int PORT=12345;
    private ServerSocket serverSocket;
    private XOServerClientHandler game;


    public XOServer() throws IOException {
        this.serverSocket = new ServerSocket(PORT);
        this.game=new XOServerClientHandler();
    }

    public void start(){
        System.err.println("Waiting for players...");
        while(true){
            try {
                Socket client=serverSocket.accept();
                System.err.println("Player accepted.");
                if(game.getPlayer1()!=null){
                    game.setPlayer2(client);
                }else{
                    game.setPlayer1(client);
                }
                if(game.getPlayer1()!=null&&game.getPlayer2()!=null){
                    Thread gameThread=new Thread(()->{
                        synchronized (game){
                            game.start();
                        }
                    });
                    gameThread.start();
                    System.out.println("Game started.");
                    gameThread.join();
                    game=new XOServerClientHandler();
                }
            } catch (IOException | InterruptedException e) {
                System.err.println("Server error.");
                try {
                    serverSocket.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());
        try {
            XOServer server=new XOServer();
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable {

    public Socket client;
    public String marker;
    public String[] game;
    public boolean flag;
    public XOServerClientHandler opponent;
    public boolean first;

    XOServerClientHandler(Socket client, String[] game, int num, boolean flag) {
        if (num % 2 == 1) {
            this.marker = "x";
        } else {
            this.marker = "o";
        }
        this.flag = flag;
        this.game = game;
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))
        ) {
            while (true) {
                String move;
                if (this.flag) {
                    if (this.first) {
                        String answer = makeGameAnswer();
                        out.write(answer);
                        out.newLine();
                        out.flush();
                        this.first = false;
                        if(marker.equals("x") && XOServer.flagic) {
                            opponent.first = true;
                            opponent.flag = true;
                            System.out.println("Usao");
                            XOServer.flagic = false;
                        }
                    } else {
                        move = in.readLine();
                        if (move == null)
                            continue;
                        String[] curMove = move.split(" ");
                        Integer pos = Integer.parseInt(curMove[1]);
                        System.out.println(pos);
                        String answer = makePotez(pos);
                        out.write(answer);
                        out.newLine();
                        out.flush();
                        if (answer.equals("kraj"))
                            break;
                        opponent.flag = true;
                        this.flag = false;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        XOServer.numOfPlayers = 3;
    }

    private String makePotez(Integer pos) {
        if (pos > 9 || pos < 0)
            return "Nevalidan potez";
        else {
            this.game[pos - 1] = marker;
            if (isWinner()) {
                return "kraj";
            }
            return makeGameAnswer();
        }

    }

    private boolean isWinner() {
        if (this.game[0].equals(marker) && this.game[1].equals(marker) && this.game[2].equals(marker))
            return true;
        else if (this.game[3].equals(marker) && this.game[4].equals(marker) && this.game[5].equals(marker))
            return true;
        else if (this.game[6].equals(marker) && this.game[7].equals(marker) && this.game[8].equals(marker))
            return true;
        else if (this.game[0].equals(marker) && this.game[5].equals(marker) && this.game[8].equals(marker))
            return true;
        else if (this.game[2].equals(marker) && this.game[5].equals(marker) && this.game[6].equals(marker))
            return true;
        else
            return false;
    }

    private String makeGameAnswer() {
        StringBuilder answer = new StringBuilder();
        for (int i = 0; i < this.game.length; i++) {
            answer.append(this.game[i]);
            answer.append(" ");
        }
        return answer.toString();
    }

    public void closeMe() {
        try {
            this.client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

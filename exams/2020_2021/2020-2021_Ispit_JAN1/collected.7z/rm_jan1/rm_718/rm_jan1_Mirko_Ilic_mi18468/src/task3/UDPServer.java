package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;

class UDPServer {
    public static final int PORT = 31415;
    public DatagramSocket server;

    UDPServer(){
        try {
            this.server = new DatagramSocket(PORT, InetAddress.getByName("localhost"));
        } catch (SocketException e) {
            System.err.println("Greska u otvaranju soketa");
            e.printStackTrace();
        } catch (UnknownHostException e) {
            System.err.println("Nepostojeci host");
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        UDPServer ser = new UDPServer();
        System.err.println("Server pokrenut");
        ser.execute();
    }

    private void execute() {
        while (true){
            try {
                byte[] niz = new byte[64];
                DatagramPacket request = new DatagramPacket(niz, niz.length);
                this.server.receive(request);
                System.err.println("Primio paket");
                byte[] nizReq = request.getData();
                String data = new String(nizReq, 0, nizReq.length, StandardCharsets.UTF_8);
                Double number = Double.parseDouble(data);
                if(number >= 0){
                    System.err.println("Saljem odgovor");
                    Double answer = number*number*Math.PI;
                    byte[] answByte = answer.toString().getBytes();
                    DatagramPacket answerPaket = new DatagramPacket(answByte, answByte.length, request.getAddress(), request.getPort());
                    this.server.send(answerPaket);
                }else{
                    System.err.println("Saljem odgovor");
                    String response = "Neispravan poluprecnik";
                    byte[] answByte = response.getBytes();
                    DatagramPacket answer = new DatagramPacket(answByte, answByte.length, request.getAddress(), request.getPort());
                    this.server.send(answer);
                }
            } catch (IOException e) {
                System.err.println("Greska u primanju");
                e.printStackTrace();
            }
        }
    }
}

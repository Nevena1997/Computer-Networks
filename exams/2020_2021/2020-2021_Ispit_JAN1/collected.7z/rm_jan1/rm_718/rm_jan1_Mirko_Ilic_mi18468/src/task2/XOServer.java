package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;

class XOServer {
    public static final int PORT = 12345;
    public static int numOfPlayers = 0;
    public ServerSocket server;

    public XOServerClientHandler takX;
    public XOServerClientHandler takO;
    public static boolean flagic = true;

    public static boolean playX = true;

    String[] game;

    XOServer(){
        this.game = new String[9];

        for (int i =0; i<this.game.length; i++)
            this.game[i] = "-";

        try {
            this.server = new ServerSocket (PORT);
        } catch (IOException e) {
            System.err.println("Greska u otvaranju servera");
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        XOServer serr = new XOServer();
        System.err.println("Server je pokrenut");
        serr.execute();
    }

    private void execute() {
        System.err.println("Cekam igrace");
        while (true){
            try {
                if(numOfPlayers == 2){
                    takX.flag = true;
                    takO.flag = true;

                    takX.first = true;
                    takO.first = false;

                    takO.opponent = takX;
                    takX.opponent = takO;

                    takX.flag = true;
                    takO.flag = false;

                    new Thread(takX).start();
                    new Thread(takO).start();
                    numOfPlayers = 9;

                }else if(numOfPlayers == 0 || numOfPlayers == 1){
                    Socket client = this.server.accept();
                    numOfPlayers += 1;
                    System.err.println("Prihvatio " + numOfPlayers);

                    XOServerClientHandler clientHandler = new XOServerClientHandler(client,this.game ,numOfPlayers, true);

                    if (numOfPlayers % 2 == 1)
                        this.takX = clientHandler;
                    else
                        this.takO = clientHandler;
                }else if(numOfPlayers == 3){
                    takO.closeMe();
                    takX.closeMe();
                    numOfPlayers = 0;
                }
                else{
                    continue;
                }
            } catch (IOException e) {
                System.err.println("Ne mogu da otvorim klijenta");
                e.printStackTrace();
            }
        }
    }
}

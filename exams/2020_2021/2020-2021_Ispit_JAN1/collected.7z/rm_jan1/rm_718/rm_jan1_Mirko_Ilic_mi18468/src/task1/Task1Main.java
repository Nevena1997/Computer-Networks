package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {

    public static void main(String[] args) {
        System.out.println("Unesite rec: ");
        Scanner in = new Scanner(System.in);
        String rec = in.nextLine().trim();
        in.close();
        Path putanjaPesme = Paths.get("/home/ispit/Desktop/tests/pesme");
        traversePesme(putanjaPesme, rec);
    }

    private static void traversePesme(Path putanjaPesme, String rec) {
        try {
            DirectoryStream<Path> dir = Files.newDirectoryStream(putanjaPesme);
            for(Path p : dir){
                if(Files.isRegularFile(p)) {
                    SongParser parser = new SongParser(p, rec);
                    new Thread(parser).start();
                }
            }
        } catch (IOException e) {
            System.err.println("Ne mogu da dobijem direktorijum pesme");
            e.printStackTrace();
        }
    }

    public static int countNumberAppearence(String line, String rec) {
        String[] reci = line.split(" ");
        int numOfAppearence = 0;
        for(String curr : reci){
            if(curr.contains(rec))
                numOfAppearence++;
        }
        return numOfAppearence;
    }
}

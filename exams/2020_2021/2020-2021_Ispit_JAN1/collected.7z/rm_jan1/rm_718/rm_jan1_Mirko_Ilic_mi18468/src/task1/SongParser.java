package task1;

import java.io.*;
import java.nio.file.Path;

class SongParser implements Runnable {
    public Path filePath;
    String rec;

    SongParser(Path filePath, String rec) {
        this.filePath = filePath;
        this.rec = rec;
    }

    @Override
    public void run() {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(this.filePath))));) {
            String songName = filePath.getFileName().toString();
            String line;
            String longestStih = "";
            int numLogestStih = 0;
            int numOfAppearence = 0;
            while ((line = reader.readLine()) != null) {
                if (line.length() > numLogestStih) {
                    longestStih = line;
                    numLogestStih = line.length();
                }
                int apearence = Task1Main.countNumberAppearence(line, this.rec);
                numOfAppearence += apearence;
            }

            synchronized (System.in){
                System.out.println(songName);
                System.out.println(longestStih);
                System.out.println(numOfAppearence);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

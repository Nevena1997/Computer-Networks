package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    public DatagramSocket socket;

    UDPClient(){
        try {
            this.socket = new DatagramSocket();
        } catch (SocketException e) {
            System.err.println("Greska pri otvraanju soketa");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        UDPClient client = new UDPClient();
        System.err.println("Server pokrenut");
        client.execute();
    }

    private void execute() {
        Scanner in  = new Scanner(System.in);
        System.out.println("Unesti jedan realan broj");
        String number = in.nextLine().trim();
        if(isNumeric(number)){
            byte[] req = number.getBytes(StandardCharsets.UTF_8);
            try {
                DatagramPacket paket = new DatagramPacket(req, req.length, InetAddress.getByName("localhost") ,UDPServer.PORT);
                System.err.println("Saljem poruku");
                socket.send(paket);
                byte[] res = new byte[64];
                DatagramPacket response = new DatagramPacket(res, res.length);
                socket.receive(response);
                byte[] bRes = response.getData();
                String answer = new String(bRes, 0, bRes.length, StandardCharsets.UTF_8);
                Double answerNum = Double.parseDouble(answer);
                System.out.println("Odgovor: " + answerNum.toString());
            } catch (UnknownHostException e) {
                System.err.println("greska u formiranju poruke");
                e.printStackTrace();
            } catch (IOException e) {
                System.err.println("greska u slanju");
                e.printStackTrace();
            }
        }
        System.err.println("Zatvaram soket kraj...");
        this.socket.close();
    }

    private boolean isNumeric(String number) {
        try{
            Double num = Double.parseDouble(number);
            return true;
        }catch (NumberFormatException e){
            System.err.println("Niste uneli broj");
            e.printStackTrace();
            return false;
        }
    }

}

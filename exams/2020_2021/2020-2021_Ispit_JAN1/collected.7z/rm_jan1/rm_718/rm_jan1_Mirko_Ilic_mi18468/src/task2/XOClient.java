package task2;

import java.io.*;
import java.net.Socket;

class XOClient {
    public Socket client;

    XOClient(){
        try {
            this.client = new Socket("localhost", XOServer.PORT);
        } catch (IOException e) {
            System.err.println("Nisam uspeo da otvorim soket");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        XOClient client = new XOClient();
        client.execute();
    }

    private void execute() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
            BufferedReader sisIn = new BufferedReader(new InputStreamReader(System.in))
        ){
            String response;
            while (true){
                if((response = in.readLine()) != null) {
                    if(response.trim().equals("kraj")){
                        break;
                    }
                    System.out.println(response);
                    System.out.println("Uensite potez");
                    String potez = sisIn.readLine();
                    out.write(potez);
                    out.newLine();
                    out.flush();
                }
            }
        }   catch (IOException e){
            System.err.println("Greska u otvaranju reidera ili writera");
            e.printStackTrace();
        }
        try {
            this.client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.*;

class XOServerClientHandler extends  Thread{

    private final String symbol;
    private final Socket player;
    private BufferedReader in;
    private BufferedWriter out;
    private static String currPlayer = "X";
    private final Map<Integer, String> gameState= Collections.synchronizedMap(new HashMap<>());

    public XOServerClientHandler(String symbol, Socket player){
        this.symbol = symbol;
        this.player = player;

        for(int i = 0; i < 9; i++){
            gameState.put(i, "-");
        }
        try{
            this.in = new BufferedReader(new InputStreamReader(player.getInputStream()));
            this.out = new BufferedWriter(new OutputStreamWriter(player.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private synchronized void endTurn(){
        if(currPlayer.equalsIgnoreCase("X")){
            currPlayer = "O";
            System.err.println(currPlayer);
        }
        else{
            currPlayer = "X";
        }

    }
    private String getCurrentStateOfGame(){
        StringBuilder sb = new StringBuilder("");

        for (int i = 1 ; i <= 9; i++){
            synchronized (this.gameState){
                sb.append(gameState.get(i - 1));
                if(i  % 3 == 0){
                    sb.append("\n");
                }
            }

        }
        sb.append("\n");
        return sb.toString();
    }

    @Override
    public void run() {

        try{

            if(!currPlayer.equalsIgnoreCase(this.symbol)){
                synchronized (this) {
                    this.wait();
                }
            }
            else{

                String currState = getCurrentStateOfGame();
                System.err.println( currState);

                //ispis trenutnog stanja igre
                out.write(currState);
                out.newLine();
                out.flush();

                int currMove = Integer.parseInt(in.readLine().trim());
                System.err.println("Curr player: " + symbol + " curr move: " + currMove);

                synchronized (this.gameState){
                    gameState.replace(currMove, this.symbol);
                    endTurn();
                    System.err.println(currPlayer);
                }

                synchronized (this) {
                    this.notifyAll();
                }
            }


        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        } finally {
            try {

                player.close();
                XOServer.players.clear();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

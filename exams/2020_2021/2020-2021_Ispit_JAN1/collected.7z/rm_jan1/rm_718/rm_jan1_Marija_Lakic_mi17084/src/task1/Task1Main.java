package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in);
            DirectoryStream ds = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"))){

            String word = sc.nextLine().trim();
            for(Object p: ds){
                Thread t = new SongParser(word, p.toString());
                t.start();

                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

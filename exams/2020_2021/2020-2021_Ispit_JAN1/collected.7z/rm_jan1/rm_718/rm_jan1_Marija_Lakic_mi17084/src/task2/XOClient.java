package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        new XOClient().execute();
    }

    private void execute(){

        try(Socket client = new Socket("localhost",  XOServer.DEFAULT_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner moveIn = new Scanner(System.in)){

            while(true) {
                StringBuilder curr_state = new StringBuilder("");
                for (int i = 0; i < 3; i++) {
                    String input = in.readLine();
                    if(input.equalsIgnoreCase("kraj")){
                        break;
                    }
                    curr_state.append(input);
                    curr_state.append("\n");
                }
                System.out.println(curr_state.toString());
//                numeracija polja:
//                012
//                345
//                678
                System.out.println("Unesite broj polja: ");

                int field = moveIn.nextInt();

                out.write(String.valueOf(field));
                out.newLine();
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

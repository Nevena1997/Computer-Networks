package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {


    public static final int DEFAULT_PORT = 31415;
    public static void main(String[] args) {

        new UDPServer().execute();

    }

    public void execute(){

        try(DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){

            while(true) {
                byte[] buf = new byte[512];
                DatagramPacket request = new DatagramPacket(buf, buf.length);

                server.receive(request);
                System.err.println("Client datagram received");
                double radius = Double.parseDouble(new String(request.getData()));
                String res = "";
                if (radius < 0) {
                    res = "Neispravan poluprecnik";
                }
                else {
                    double s = radius * radius * Math.PI;
                    res = String.valueOf(s);
                }
                DatagramPacket response = new DatagramPacket(res.getBytes(), res.length(), request.getAddress(), request.getPort());
                System.err.println(res);
                server.send(response);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

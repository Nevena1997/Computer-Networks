package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        new UDPClient().execute();
    }

    private void execute(){


        try(DatagramSocket client = new DatagramSocket();
            Scanner in = new Scanner(System.in)){

            double radius = in.nextDouble();
            String req = String.valueOf(radius);
            System.err.println(req);
            DatagramPacket request = new DatagramPacket(req.getBytes(), req.length(), InetAddress.getByName("localhost"), UDPServer.DEFAULT_PORT);
            client.send(request);


            byte[] resp = new byte[512];
            DatagramPacket response = new DatagramPacket(resp, resp.length);
            client.receive(response);

            if(radius >= 0) {
                System.out.println(Double.parseDouble(new String(response.getData())));
            }
            else{
                System.out.println(new String(response.getData(), 0, response.getLength()));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

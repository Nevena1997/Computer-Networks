package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

class XOServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {

        new XOServer().execute();
    }
    public XOServer(){
        for(int i = 0; i < 9; i++){
            gameState.put(i, "-");
        }
    }
    private static String currPlayer = "X";
    private synchronized void endTurn(){
        if(currPlayer.equalsIgnoreCase("X")){
            currPlayer = "O";
            System.err.println(currPlayer);
        }
        else{
            currPlayer = "X";
        }

    }
    private String getCurrentStateOfGame(){
        StringBuilder sb = new StringBuilder("");

        for (int i = 1 ; i <= 9; i++){
            synchronized (this.gameState){
                sb.append(gameState.get(i - 1));
                if(i  % 3 == 0){
                    sb.append("\n");
                }
            }

        }
        sb.append("\n");
        return sb.toString();
    }
    private final Map<Integer, String> gameState= Collections.synchronizedMap(new HashMap<>());

    public static HashMap<String, Socket> players = new HashMap<>();

    private void execute(){

        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){

            while(true){
                Socket client = server.accept();
                System.err.println("Accept player");


                if(players.keySet().size() == 0){
                    System.err.println("Accept player 1");
                    players.put("X", client);
                    Thread t = new XOServerClientHandler("X", players.get("X"));
                    t.start();


                }
                else if(players.keySet().size() == 1){
                    players.put("O", client);
                    System.err.println("Accept player 2");
                    System.err.println(players.keySet().size());
                    Thread t = new XOServerClientHandler("O", players.get("O"));
                    t.start();
                }
                else if (players.keySet().size() == 2) {
                    System.err.println("Game begins");

//                    try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
//                        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {
//
//                        if (currPlayer.equalsIgnoreCase()) {
//
//                            String currState = getCurrentStateOfGame();
//                            System.err.println(currState);
//
//                            //ispis trenutnog stanja igre
//                            out.write(currState);
//                            out.newLine();
//                            out.flush();
//
//                            int currMove = Integer.parseInt(in.readLine().trim());
//                            System.err.println("Curr player: " + symbol + " curr move: " + currMove);
//
//                            synchronized (this.gameState) {
//                                gameState.replace(currMove, this.symbol);
//                                endTurn();
//                                System.err.println(currPlayer);
//                            }
//
//
//                        }
//                    }
                }




            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

package task1;

import java.io.*;
import java.util.Arrays;

class SongParser extends Thread{

    private String word, fPath;
    private BufferedReader in;
    private String longestLine = "";
    private String songName = "";
    private int counter = 0;
    public SongParser(String word, String path){
        this.word = word;
        this.fPath = path;
        try{
            in = new BufferedReader(new FileReader(fPath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        String line ;
        try {

            while ((line = in.readLine()) != null){

                var words = line.split(" ");

                for(String w: words){

//                    String currWord = w;
//                    if(w.endsWith(".") ||  w.endsWith(",") || w.endsWith("!") || w.endsWith("?")){
//                        currWord = currWord.substring(0, currWord.length() - 1);
//                        System.err.println(currWord);
//                    }
                    if(w.trim().contains(word)){
                        counter++;
                    }
                }
                if(line.length() > longestLine.length()){
                    longestLine = line;
                }
            }
            synchronized (this) {
                this.songName = (new File(fPath)).getName();
                this.songName = songName.substring(0, songName.length() - 4);
                System.out.println(songName);
                System.out.println(longestLine);
                System.out.println(counter);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

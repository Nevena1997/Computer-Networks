package task2;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {

    private static final String hostname = "localhost";
    private static final int port = 12345;

    private static String playOneMove(Scanner userIn,
                                    BufferedReader networkIn,
                                    PrintWriter networkOut) throws IOException {
        System.out.println("Potez (1-9): ");
        String x = userIn.nextLine();

        int field = -1;
        try{
            field = Integer.parseInt(x);
            if (field < 1 || field > 9){
                return null;
            }
        }catch (Exception e){
            return null;
        }

        networkOut.println(x);
        StringBuilder sbResponse = new StringBuilder();
        String response;
        while ((response = networkIn.readLine()) != null){
            sbResponse.append(response.replace("END", ""));
            if (response.contains("END")){
                break;
            }
            sbResponse.append("\r\n");
        }

        String serverResponse = sbResponse.toString();
        if (serverResponse.equalsIgnoreCase("invalid"))
            return null;
        return serverResponse;

    }

    private static String waitForBoard(BufferedReader networkIn,
                                     PrintWriter networkOut) throws IOException{
        String partialBoardString;
        StringBuilder boardSb = new StringBuilder();
        while ((partialBoardString = networkIn.readLine()) != null){
            boardSb.append(partialBoardString.replace("END", ""));
            if (partialBoardString.contains("END")){
                break;
            }
            boardSb.append("\r\n");
        }

        return boardSb.toString();
    }




    public static void main(String[] args) {

        System.out.println("Hello from: " + XOClient.class.getName());
        try(Socket socket = new Socket(hostname, port);
            BufferedReader networkIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter networkOut = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            Scanner userIn = new Scanner(System.in)){

            String myTurnString = networkIn.readLine();
            boolean myTurn = myTurnString.equals("yes");
            while (true){
                if (myTurn){

                    String resp;
                    while ((resp = playOneMove(userIn, networkIn, networkOut)) == null){
                        System.out.println("Potez nije validan.");
                    }
                    // A valid move has been played and response is now the board
                    System.out.println(resp);
                    myTurn = false;
                }else{
                    System.out.println("Not my turn, waiting for something...");
                    String board = waitForBoard(networkIn, networkOut);
                    System.out.println("\tGot something!");
                    if (board.equalsIgnoreCase("win")){
                        System.out.println("Pobedili ste!");
                        break;
                    }else if (board.equalsIgnoreCase("lose")) {
                        System.out.println("Izgubili ste!");
                        break;
                    }else if (board.equalsIgnoreCase("draw")){
                        System.out.println("Nereseno!");
                        break;
                    }else{
                        System.out.println(board);
                        myTurn = true;
                    }
                }
            }


        } catch (IOException e) {
            System.err.println("Greska pri povezivanju na server: " + e.getMessage());
            e.printStackTrace();
        }

    }

}

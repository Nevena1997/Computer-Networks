package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        int port = 31415;
        try(DatagramSocket socket = new DatagramSocket();
            Scanner userIn = new Scanner(System.in)){

            System.out.println("Broj: ");
            double number = userIn.nextDouble();

            byte[] buffOut = ByteBuffer.allocate(8).putDouble(number).clear().array();
            DatagramPacket packetOut = new DatagramPacket(buffOut, 0, buffOut.length, new InetSocketAddress(port));
            socket.send(packetOut);

            byte [] buffIn = new byte[128];
            DatagramPacket packetIn = new DatagramPacket(buffIn, 0, buffIn.length, new InetSocketAddress(port));
            socket.receive(packetIn);

            String response = new String(buffIn, 0, buffIn.length);
            response = response.substring(0, response.lastIndexOf("END"));
            System.out.println(response);
        } catch (IOException e) {
            System.err.println("Greska: " + e.getMessage());
        }
    }

}

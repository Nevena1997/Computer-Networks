package task1;

import java.io.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Scanner;

class SongParser extends Thread {
    private File file;
    private String word;

    public SongParser(File file, String word) {
        this.file = file;
        this.word = word;
    }

    @Override
    public void run() {

        try (Scanner fileScanner = new Scanner(new FileInputStream(file))){

            StringBuilder sb = new StringBuilder();

            String title = file.getName().replace(".txt", "");

            long wordCount = 0;

            String longestLine = null;
            while (fileScanner.hasNextLine()){
                String line = fileScanner.nextLine();
                if (longestLine == null || line.length() > longestLine.length()){
                    longestLine = line;
                }
                wordCount += Arrays.stream(line.split(" "))
                        .map(String::toLowerCase)
                        .map(String::strip)
                        .map(s -> s.replace(".", ""))
                        .filter(w -> w.equalsIgnoreCase(word))
                        .count();

            }
            String myOutput = title + "\r\n" + longestLine + "\r\n" + wordCount + "\r\n";
            Task1Main.printResults(myOutput);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        super.run();
    }
}

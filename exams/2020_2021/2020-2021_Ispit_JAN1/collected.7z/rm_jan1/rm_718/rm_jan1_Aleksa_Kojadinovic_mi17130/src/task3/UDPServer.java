package task3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;

class UDPServer {


    public static void main(String[] args) throws SocketException {
        int port = 31415;
        try (DatagramSocket socket = new DatagramSocket(port)){
            while (true){
                byte [] buffIn = new byte[8];
                DatagramPacket packetIn = new DatagramPacket(buffIn, 0, buffIn.length);
                socket.receive(packetIn);

                double num = ByteBuffer.wrap(buffIn).asDoubleBuffer().get();
                String resp = "";
                if (num < 0){
                    resp = "Neispravan poluprecnik.END";
                }else{
                    resp = (Math.PI*num*num) + "END";
                }

                ByteBuffer bbOut = ByteBuffer.allocate(128).put(resp.getBytes());
                byte [] buffOut = bbOut.clear().array();
                DatagramPacket packetOut = new DatagramPacket(buffOut, 0, buffOut.length, packetIn.getAddress(), packetIn.getPort());
                socket.send(packetOut);

            }


        } catch (IOException e) {
            System.err.println("Greska: " + e.getMessage());
            e.printStackTrace();
        }

    }

}

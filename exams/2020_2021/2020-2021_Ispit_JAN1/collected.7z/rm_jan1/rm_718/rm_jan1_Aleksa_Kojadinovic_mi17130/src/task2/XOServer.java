package task2;

import javax.imageio.plugins.tiff.TIFFImageReadParam;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.ServerError;
import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class XOServer {

    private static final int port = 12345;

    public static ArrayList<ArrayList<Integer>> XOMatrix = new ArrayList<>();

    public static synchronized String getBoardString(){
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++){
                if (XOMatrix.get(i).get(j) == -1)
                    sb.append("-");
                else if (XOMatrix.get(i).get(j) == 0)
                    sb.append("O");
                else if (XOMatrix.get(i).get(j) == 1)
                    sb.append("X");
            }
            sb.append("\r\n");
        }

        return sb.toString();
    }
    public static synchronized String getBoardNormalString(){
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++){
                sb.append(XOMatrix.get(i).get(j));
            }
            sb.append("\r\n");
        }

        return sb.toString();
    }

    public static synchronized int getGameResult(){


        int a = XOMatrix.get(0).get(0);
        int b = XOMatrix.get(0).get(1);
        int c = XOMatrix.get(0).get(2);
        int d = XOMatrix.get(1).get(0);
        int e = XOMatrix.get(1).get(1);
        int f = XOMatrix.get(1).get(2);
        int g = XOMatrix.get(2).get(0);
        int h = XOMatrix.get(2).get(1);
        int i = XOMatrix.get(2).get(2);



        // a b c
        // d e f
        // g h i

        if (a != -1 && a == b && b == c){
            System.out.println("row1");
            return a;
        }
        if (d != -1 && d == e && e == f){
            System.out.println("row2");
            return d;
        }
        if (g != -1 && g == h && h == i){
            System.out.println("row3");
            return g;
        }


        if (a != -1 && a == d && d == g){
            System.out.println("col1");
            return a;
        }

        if (b != -1 && b == e && e == h){
            System.out.println("col2");
            return b;
        }

        if (c != -1 && c == f && f == i){
            System.out.println("col3");
            return c;
        }



        if (a != -1 && a == e && e == i){
            System.out.println("diag1");
            return a;
        }

        if (g != -1 && g == c && c == e){
            System.out.println("diag2");
            return e;
        }

        boolean allTaken = true;
        for (var row: XOMatrix){
            for (var val: row){
                if (val != -1){
                    allTaken = false;
                    break;
                }
            }
            if (!allTaken)
                break;
        }

        if (allTaken)
            return 2;

        return -1; //nothing



    }

    public static synchronized boolean playMove(int field, int move){
        System.out.println("Got move: " + field);
        if (field < 1 || field > 9){
            System.out.println("\tRejected because out of bounds.");
            return false;
        }

        int i = 0, j = 0;
        if (field == 1){
            i = 0;
            j = 0;
        }else if (field == 2){
            i = 0;
            j = 1;
        }else if (field == 3){
            i = 0;
            j = 2;
        }else if (field == 4){
            i = 1;
            j = 0;
        }else if (field == 5){
            i = 1;
            j = 1;
        }else if (field == 6){
            i = 1;
            j = 2;
        }else if (field == 7){
            i = 2;
            j = 0;
        }else if (field == 8){
            i = 2;
            j = 1;
        }else {
            i = 2;
            j = 2;
        }

        if (XOMatrix.get(i).get(j) != -1){
            System.out.println("\tInvalid because taken.");
            return false;
        }

        XOMatrix.get(i).set(j, move);

        return true;
    }

    public static int TURN_MARKER = 1;

    public static synchronized int getTurnMarker(){
        return TURN_MARKER;
    }

    public static synchronized void setTurnMarker(int v){
        TURN_MARKER = v;
    }

    public static void main(String[] args) {

        Lock l = new ReentrantLock();

        for (int i = 0; i < 3; i++){
            XOMatrix.add(new ArrayList<>());
            for (int j = 0; j < 3; j++){
                XOMatrix.get(i).add(-1);
            }
        }

        System.out.println("Initial: ");
        System.out.println(getBoardNormalString());

        try(ServerSocket socket = new ServerSocket(port)){
            while (true){
                Socket xSocket = socket.accept();
                System.out.println("Got x");

                Socket oSocket = socket.accept();
                System.out.println("Got o");


                Thread xThread = new Thread(new XOServerClientHandler(xSocket, 1, l));
                Thread oThread = new Thread(new XOServerClientHandler(oSocket, 0, l));
                xThread.start();
                oThread.start();

                xThread.join();
                oThread.join();


                System.out.println("Gotova igra! Cekam nove klijente...");
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Greska na serveru: " + e.getMessage());
            e.printStackTrace();
        }
    }


}

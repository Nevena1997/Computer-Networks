package task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Task1Main {

    public static synchronized void printResults(String res){
        System.out.println(res);
    }

    public static void main(String[] args){

        try(Scanner userIn = new Scanner(System.in)){
            System.out.print("rec: ");
            String word = userIn.next();
            String path = "/home/ispit/Desktop/tests/pesme";
            Files.walk(Paths.get(path))
                    .map(Path::toFile)
                    .filter(f -> !f.isDirectory() && f.getAbsolutePath().endsWith(".txt"))
                    .forEach(f -> {
                        new SongParser(f, word).start();
                    });

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

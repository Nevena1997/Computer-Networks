package task2;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.locks.Lock;

class XOServerClientHandler implements Runnable{

    private final Socket clientSocket;
    private int move;
    private String tag;
    private Lock lock;


    public XOServerClientHandler(Socket clientSocket, int move, Lock l) {

        this.clientSocket = clientSocket;
        this.move = move;
        this.lock = l;
        tag = move == 0? "O": "X";

    }

    @Override
    public void run() {
        try(var clientOut = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()), true);
            var clientIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))){

            if (move == 1){
                clientOut.println("yes");
            }else{
                clientOut.println("no");
            }

            boolean inactiveBoardSent = false;
            while (true){
                if (XOServer.getTurnMarker() != move) {
                    if (!inactiveBoardSent){
                        clientOut.println(XOServer.getBoardString());
                        clientOut.println("END");
                        inactiveBoardSent = true;
                    }
                    continue;
                }
                System.out.println("Player " + tag + " waiting for move...");
                String clientMove = clientIn.readLine();
                System.out.println("\tPlayer " + tag + " got move!...");
                int field = 0;
                try{
                    field = Integer.parseInt(clientMove);
                }catch (Exception e){
                    System.out.println("Not number!");
                    clientOut.println("invalid");
                    clientOut.println("END");
                    continue;
                }

                if (!XOServer.playMove(field, move)){
                    clientOut.println("invalid");
                    clientOut.println("END");
                    continue;
                }

                int winMark = XOServer.getGameResult();
                if (winMark == move) {
                    clientOut.println("win");
                    clientOut.println("END");
                    break;
                }else if (winMark == 2){
                    clientOut.println("draw");
                    clientOut.println("END");
                    break;
                }else if (winMark == -1){

                    XOServer.setTurnMarker(move == 0? 1: 0);
                    inactiveBoardSent = !inactiveBoardSent;
                    System.out.println("\tThis is a valid move, go to other player and send this player the board.");
                    clientOut.println(XOServer.getBoardString());
                    clientOut.println("END");
                }else{
                    clientOut.println("lose");
                    clientOut.println("END");
                    break;
                }


            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

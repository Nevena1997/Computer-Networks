package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    public final static int PORT = 31415;
    
    public static void main(String[] args) {

        //System.out.println("Hello from: " + UDPServer.class.getName());

        try(DatagramSocket server = new DatagramSocket(PORT)){

            while(true) {
                // primamo zahtev od klijenta
                DatagramPacket request = new DatagramPacket(new byte[8], 8);
                server.receive(request);

                String req = new String(request.getData(), 0, request.getLength());
                double r = Double.parseDouble(req);
                //System.err.println(r);

                if(r < 0){
                    String res = "Neispravan poluprecnik.";

                    // saljemo odgovor klijentu
                    byte[] buf = res.getBytes();
                    DatagramPacket response = new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                    server.send(response);
                }
                else {
                    double pov = r * r * Math.PI;
                    String res = String.valueOf(pov);

                    // saljemo odgovor klijentu
                    byte[] buf = res.getBytes();
                    DatagramPacket response = new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                    server.send(response);
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

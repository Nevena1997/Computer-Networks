package task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Task1Main {

    public static List<String> datoteke = new ArrayList<>();
    
    public static void main(String[] args) {

        //System.out.println("Hello from: " + Task1Main.class.getName());
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        sc.close();

        Path path = Paths.get("/home/ispit/Desktop/tests/pesme");
        try(DirectoryStream<Path> ds = Files.newDirectoryStream(path)){

            for(Path p : ds){
                if(Files.isRegularFile(p)){
                    datoteke.add(p.toString());
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        List<Thread> threads = new ArrayList<>();
        for(String s : datoteke) {
            Thread t = new SongParser(s, word);
            t.start();
            threads.add(t);
        }

        for(Thread t : threads){
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

}

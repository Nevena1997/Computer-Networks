package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;

class XOServer {

    public static AtomicInteger count = new AtomicInteger(0);
    public static char[][] terrain = new char[3][3];
    
    public static void main(String[] args) {
        //System.out.println("Hello from: " + XOServer.class.getName());

        for(int i = 0; i < 3; i++)
            for(int j = 0; j < 3; j++)
                terrain[i][j] = '-';

        try(ServerSocket server = new ServerSocket(12345);
        ){
            while(true){
                Socket client = server.accept();
                count.getAndIncrement();
                new Thread(new XOServerClientHandler(client, terrain)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

import static task2.XOServer.terrain;

class XOClient {

    public static void main(String[] args) {

        //System.out.println("Hello from: " + XOClient.class.getName());

        try(Socket client = new Socket("localhost", 12345);
            Scanner sc = new Scanner(System.in);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
        ){

            while(true) {

                // ispis trenutnog stanja igre
                System.out.println("Trenutno stanje igre:");
                for (int x = 0; x < 3; x++) {
                    for (int y = 0; y < 3; y++) {
                        System.out.print(terrain[x][y] + " ");
                    }
                    System.out.println();
                }

                // ucitavanje poteza
                System.out.println("Uneti x i y koordinatu (0-2) i karakter:");
                int i = sc.nextInt();
                int j = sc.nextInt();
                char c = sc.next().charAt(0);

                // slanje poteza serveru
                out.write(i + " " + j + " " + c);
                out.newLine();
                out.flush();

                // provera poteza
                String resp = in.readLine();
                if(resp.equals("OK")){ // potez moze da se odigra
                    terrain[i][j] = c;
                }
                else{
                    System.out.println("Unesite validan potez:");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

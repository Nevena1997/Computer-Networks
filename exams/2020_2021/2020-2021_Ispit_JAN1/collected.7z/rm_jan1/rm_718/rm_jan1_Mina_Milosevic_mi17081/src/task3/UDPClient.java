package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        //System.out.println("Hello from: " + UDPClient.class.getName());

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){
            InetAddress addr = InetAddress.getByName("localhost");

            // slanje serveru
            String r = sc.next();
            byte[] buf = r.getBytes();
            DatagramPacket request = new DatagramPacket(buf, buf.length, addr, UDPServer.PORT);
            client.send(request);

            // primanje odgovora
            DatagramPacket response = new DatagramPacket(new byte[32], 32);
            client.receive(response);
            String pov = new String(response.getData(), 0, response.getLength());
            System.out.println(pov);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

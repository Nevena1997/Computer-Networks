package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable {

    private Socket client;
    private static char[][] terrain;

    XOServerClientHandler(Socket socket, char[][] terrain){
        this.client = socket;
        this.terrain = terrain;
    }

    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))
        ){

            while(true) {
                String[] input = in.readLine().split(" ");
                int i = Integer.parseInt(input[0]);
                int j = Integer.parseInt(input[1]);
                char c = input[2].charAt(0);
                //System.err.println(i + " " + j + " " + c);

                if (i > 2 || i < 0 || j > 2 || j < 0) {
                    String resp = "Nevalidan potez";
                    out.write(resp);
                    out.newLine();
                    out.flush();
                }
                else if(terrain[i][j] != '-'){
                    String resp = "Nevalidan potez";
                    out.write(resp);
                    out.newLine();
                    out.flush();
                }
                else {
                    terrain[i][j] = c;
                    String resp = "OK";
                    out.write(resp);
                    out.newLine();
                    out.flush();
                }

                if((terrain[0][0] == terrain[1][1] && terrain[1][1] == terrain[2][2]) ||
                   (terrain[0][0] == terrain[1][0] && terrain[1][0] == terrain[2][0]) ||
                   (terrain[0][0] == terrain[0][1] && terrain[0][1] == terrain[0][2]) ||
                   (terrain[0][1] == terrain[1][1] && terrain[1][1] == terrain[2][1]) ||
                   (terrain[0][2] == terrain[1][2] && terrain[1][2] == terrain[2][2]) ||
                   (terrain[1][0] == terrain[1][1] && terrain[1][1] == terrain[1][2]) ||
                   (terrain[2][0] == terrain[2][1] && terrain[2][1] == terrain[2][2])){
                    if(terrain[0][0] != '-' && terrain[1][1] != '-' && terrain[2][2] != '-') {
                        System.out.println("Igra gotova!");
                        client.close();
                        break;
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

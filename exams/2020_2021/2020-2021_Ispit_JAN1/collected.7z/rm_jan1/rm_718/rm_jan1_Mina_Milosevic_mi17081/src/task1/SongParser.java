package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

class SongParser extends Thread {

    String filepath;
    String word;
    AtomicInteger count = new AtomicInteger(0);

    SongParser(String path, String word){
        this.filepath = path;
        this.word = word;
    }

    @Override
    public void run() {

        String songName = filepath.substring(filepath.lastIndexOf("/")+1,
            filepath.lastIndexOf("."));

        try(Scanner sc = new Scanner(new File(filepath))){

            String line;
            int maxLine = 0;
            String maxLineStr = "";
            while(sc.hasNextLine()){
                line = sc.nextLine();
                if(line.length() > maxLine){
                    maxLine = line.length();
                    maxLineStr = line;
                }

                String[] words = line.split(" ");
                for(String w : words){
                    if(w.contains(word) || w.equalsIgnoreCase(word)){
                        count.getAndIncrement();
                    }
                }
            }

            System.out.println(songName + "\n" + maxLineStr + "\n" + count);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

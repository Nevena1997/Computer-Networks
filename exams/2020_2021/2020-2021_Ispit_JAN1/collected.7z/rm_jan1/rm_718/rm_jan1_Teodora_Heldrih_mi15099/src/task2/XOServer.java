package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

class XOServer {
    static final int PORT = 12345;
    static final String HOSTNAME = "localhost";

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());

        try (ServerSocket server = new ServerSocket(PORT)) {
            while (true) {
                Socket client1 = server.accept();
                Socket client2 = server.accept();

                new Thread(new XOServerClientHandler(client1, client2)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

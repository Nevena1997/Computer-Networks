package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPClient.class.getName());

        try (DatagramSocket socket = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            double num = sc.nextDouble();

            byte[] numToByteArr = String.valueOf(num).getBytes();
            DatagramPacket packetToSend = new DatagramPacket(numToByteArr, numToByteArr.length, InetAddress.getByName(UDPServer.HOSTNAME), UDPServer.PORT);
            socket.send(packetToSend);

            DatagramPacket packetToReceive = new DatagramPacket(new byte[UDPServer.MAX_BUFF_LENGTH], UDPServer.MAX_BUFF_LENGTH);
            socket.receive(packetToReceive);

            System.out.println(new String(packetToReceive.getData(), 0, packetToReceive.getLength(), StandardCharsets.UTF_8));
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

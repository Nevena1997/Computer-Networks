package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        sc.close();

        Path baseDir = Paths.get("/home/ispit/Desktop/tests/pesme");
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(baseDir)) {
            for (Path p: ds) {
                if (Files.isRegularFile(p)) {
                    new Thread(new SongParser(p, word)).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

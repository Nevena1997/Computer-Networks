package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.Scanner;

class SongParser implements Runnable {
    private Path path;
    private String word;

    SongParser(Path path, String word) {
        this.path = path;
        this.word = word;
    }

    @Override
    public void run() {
        String filename = path.getFileName().toString().replace(".txt", "");

        try (Scanner sc = new Scanner(new BufferedReader(new FileReader(String.valueOf(path))))) {
            String longestLine = "";
            int counter = 0;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();

                if (line.length() > longestLine.length() ) {
                    longestLine = line;
                }

                if (line.contains(word)) {
                    counter++;
                }
            }
            sc.close();

            printToSystemOut(filename, longestLine, counter);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    synchronized void printToSystemOut(String filename, String longestLine, int counter) {
        System.out.println(filename);
        System.out.println(longestLine);
        System.out.println(counter);
    }
}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    static final int PORT = 31415;
    static final String HOSTNAME = "localhost";
    static final int MAX_BUFF_LENGTH = 32;

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());

        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            while (true) {
                DatagramPacket packetToReceive = new DatagramPacket(new byte[MAX_BUFF_LENGTH], MAX_BUFF_LENGTH);
                socket.receive(packetToReceive);

                double num = Double.parseDouble(new String(packetToReceive.getData(), 0, packetToReceive.getLength(), StandardCharsets.UTF_8));
                byte[] res = num < 0 ? "Neispravan poluprecnik".getBytes() : String.valueOf(num * num * Math.PI).getBytes();

                DatagramPacket packetToSend = new DatagramPacket(res, res.length, packetToReceive.getAddress(), packetToReceive.getPort());
                socket.send(packetToSend);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

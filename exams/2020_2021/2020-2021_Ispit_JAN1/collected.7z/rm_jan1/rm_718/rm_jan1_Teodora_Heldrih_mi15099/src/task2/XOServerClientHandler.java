package task2;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

class XOServerClientHandler implements Runnable {
    private Socket x;
    private Socket o;
    private BufferedReader fromX;
    private BufferedReader fromO;
    private BufferedWriter toX;
    private BufferedWriter toY;
    private char[] table;

    XOServerClientHandler(Socket x, Socket o) {
        this.x = x;
        this.o = o;
        table = "---\n---\n---\n".toCharArray();
        try {
            fromX = new BufferedReader(new InputStreamReader(this.x.getInputStream()));
            fromO = new BufferedReader(new InputStreamReader(this.o.getInputStream()));
            toX = new BufferedWriter(new OutputStreamWriter(this.x.getOutputStream()));
            toY = new BufferedWriter(new OutputStreamWriter(this.o.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        writeTable();
        while (true) {
            playX();
        }
    }

    void playX() {
        try {
            boolean moveOk = false;
            while (moveOk == false) {
                String posStr = fromX.readLine();
                int pos = Integer.parseInt(posStr);
                if (table[pos - 1] != '-') {
                    toX.write("Nevalidan potez");
                } else {
                    table[pos - 1] = 'X';
                    moveOk = true;
                }
            }

            writeTable();
            playO();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void playO() {
        try {
            boolean moveOk = false;
            System.out.println("Ulasim");
            while (moveOk == false) {
                String posStr = fromO.readLine();
                int pos = Integer.parseInt(posStr);
                System.out.println(pos);
                if (table[pos - 1] != '-') {
                    toY.write("Nevalidan potez");
                } else {
                    table[pos - 1] = 'Y';
                    moveOk = true;
                }
            }

            writeTable();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void finishGame(char winner) {
        try {
            if (winner == 'X') {
                toX.write("You WON!");
                toY.write("You LOST :(");
            } else if (winner == 'O') {
                toY.write("You WON!");
                toX.write("You LOST :(");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                x.close();
                o.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    void writeTable() {
        try {
            System.out.println(table);
            toY.write(table);
            toY.flush();

            toX.write(table);
            toX.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

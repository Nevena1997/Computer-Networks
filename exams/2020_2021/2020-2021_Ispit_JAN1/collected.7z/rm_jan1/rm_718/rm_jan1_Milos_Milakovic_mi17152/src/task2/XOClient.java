package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        XOClient client = new XOClient();
        client.execute();
    }

    XOClient() {

    }

    private void execute() {

        try (Socket client = new Socket("localhost", XOServer.DEFAULT_PORT);
             Scanner in = new Scanner(System.in);
             BufferedWriter out = new BufferedWriter(
                     new OutputStreamWriter(
                             client.getOutputStream()
                     )
             );
             BufferedReader inPlayer = new BufferedReader(
                     new InputStreamReader(client.getInputStream())
             );
        ){

            // DOK SERVER NE JAVI DA JE KRAJ
            while (true) {
                // ISPIS TABLE
                String line;
                while (!(line = inPlayer.readLine()).equalsIgnoreCase("kraj")) {
                    System.out.println(line);
                }

                // UCITAVANJE POTEZA
                // SLANJE POTEZA SERVERU
                boolean read = true;
                while (read) {
                    String place = in.nextLine();
                    out.write(place);
                    out.newLine();
                    out.flush();


                    String response;
                    while (!(response = inPlayer.readLine()).equalsIgnoreCase("kraj")) {
                        if (!response.equalsIgnoreCase("Nevalidan potez")) {
                            System.err.println("Dobar potez :)");
                            read = false;
                        }
                    }

                    if (!read)
                        continue;

                    System.err.println("Nevalidan potez");
                }

                System.err.println("Zavrsio");
            }

        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

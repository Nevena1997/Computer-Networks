package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        String path = "../tests/pesme";

        try (Scanner in = new Scanner(System.in);
             DirectoryStream<Path> files = Files.newDirectoryStream(Paths.get(path));
        ){
            String word = in.next();

            for (var file : files) {
                new SongParser(word, file).start();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static synchronized void write(String songName, String longestLine, int num) {
        System.out.println(songName);
        System.out.println(longestLine);
        System.out.println(num);
    }
}

package task1;

import java.io.*;
import java.nio.file.Path;

class SongParser extends Thread{

    private final String word;
    private final Path file;

    SongParser(String word, Path file) {
        this.word = word;
        this.file = file;
    }

    @Override
    public void run() {
        try (BufferedReader read = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(String.valueOf(this.file))
                )
        )){
            String songName = this.file.getFileName().toString();
            Integer dot = songName.indexOf('.');
            songName = songName.substring(0, dot);
            String line;
            String longestLine = "";
            int length = 0;
            int num = 0;

            while ((line = read.readLine()) != null) {

                if (line.length() > length) {
                    longestLine = line;
                    length = line.length();
                }

                String[] words = line.split(" ");

                for (var w : words) {
                    if (this.word.equalsIgnoreCase(w))
                        num++;
                }
            }

            Task1Main.write(songName, longestLine, num);

        } catch (FileNotFoundException ex) {
            System.err.println("File not found exception");
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

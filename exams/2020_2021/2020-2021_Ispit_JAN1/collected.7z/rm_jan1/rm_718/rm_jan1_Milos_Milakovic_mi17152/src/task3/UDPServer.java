package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    public static Integer DEFAULT_PORT = 31415;

    public static void main(String[] args) {
        UDPServer s = new UDPServer();
        s.execute();
    }

    UDPServer() {

    }

    private void execute() {
        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){

            while (true) {

                try {


                    DatagramPacket receive = new DatagramPacket(new byte[512], 512);
                    server.receive(receive);
                    String data = new String(receive.getData(), 0, receive.getLength());
                    Double number = Double.parseDouble(data.trim());

                    DatagramPacket send;

                    if (number < 0) {
                        String response = "Neispravan poluprecnik";
                        byte[] responseBytes = response.getBytes();
                        send = new DatagramPacket(responseBytes, responseBytes.length, receive.getAddress(), receive.getPort());
                    } else {
                        Double p = number * number * Math.PI;
                        byte[] responseBytes = p.toString().getBytes();
                        send = new DatagramPacket(responseBytes, responseBytes.length, receive.getAddress(), receive.getPort());
                    }

                    server.send(send);

                } catch (IOException ex) {
                    ex.printStackTrace();
                } catch (NumberFormatException ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
    }
}

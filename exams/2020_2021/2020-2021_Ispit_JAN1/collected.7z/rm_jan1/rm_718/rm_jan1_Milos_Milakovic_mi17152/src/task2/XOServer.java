package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    public static Integer DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        XOServer server = new XOServer();
        server.execute();
    }

    XOServer() {

    }

    private void execute() {
        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){

            while (true) {
                Socket client1 = server.accept();
                Socket client2 = server.accept();

               try {

                   // TODO: play game!!!
                   Thread game = new XOServerClientHandler(client1, client2);
                   game.start();

                   game.join();
               } catch (InterruptedException ex) {
                   ex.printStackTrace();
               }
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        UDPClient c = new UDPClient();
        c.execute();
    }

    UDPClient() {

    }

    private void execute() {
        try (DatagramSocket client = new DatagramSocket();
             Scanner in = new Scanner(System.in)
        ){

            String num = in.next();
            byte[] sendBytes = num.getBytes();
            InetAddress host = InetAddress.getLocalHost();
            DatagramPacket send = new DatagramPacket(sendBytes, sendBytes.length, host, UDPServer.DEFAULT_PORT);

            client.send(send);

            DatagramPacket receive = new DatagramPacket(new byte[512], 512);

            client.receive(receive);

            String result = new String(receive.getData(), 0, receive.getLength());

            System.out.println(result);

        } catch (SocketException ex) {
            ex.printStackTrace();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

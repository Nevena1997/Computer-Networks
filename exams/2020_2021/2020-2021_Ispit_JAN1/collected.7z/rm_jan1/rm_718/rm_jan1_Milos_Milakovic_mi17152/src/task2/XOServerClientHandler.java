package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler extends Thread{

    private Socket p1;
    private Socket p2;
    String[] table = new String[9];

    XOServerClientHandler(Socket p1, Socket p2) {
        this.p1 = p1;
        this.p2 = p2;

        for (int i = 0; i < 9; i++)
            table[i] = "-";
    }

    @Override
    public void run() {
        try (BufferedReader inP1 = new BufferedReader(
                new InputStreamReader(this.p1.getInputStream()));
             BufferedReader inP2 = new BufferedReader(
                 new InputStreamReader(this.p2.getInputStream())
             );
             BufferedWriter outP1 = new BufferedWriter(
                     new OutputStreamWriter(this.p1.getOutputStream()));
             BufferedWriter outP2 = new BufferedWriter(
                     new OutputStreamWriter(this.p2.getOutputStream())
             )
        ){
            System.err.println("Pocinje igra");

            String ta = table();
            outP1.write(ta);
            outP1.newLine();
            outP1.write("kraj\n");
            outP1.flush();


            while (true) {

                Integer num1;

                while (true) {

                    try {
                        num1 = loadData(inP1);

                        if (addToTable(num1, "X")) {
                            System.err.println("Dodato na tablu");
                            outP1.write("Dodato na tablu");
                            outP1.newLine();
                            outP1.write("kraj\n");
                            outP1.flush();
                            outP1.write("");
                            break;
                        }

                    } catch (NumberFormatException ex) {
                        outP1.write("Nevalidan potez");
                        outP1.newLine();
                        outP1.write("kraj\n");
                        outP1.flush();
                    }
                }

                // ISPISI KOD KLIJENTA 2
                String t = table();
                outP2.write(t);
                outP2.newLine();
                outP2.write("kraj\n");
                outP2.flush();

                // PROVERI DA LI JE POBEDIO IGRAC 1
                if (win("X")) {
                    // Posalji info da je gotova igra
                    outP1.write("Gotova igra\n");
                    outP1.newLine();
                    outP1.write("kraj\n");
                    outP1.flush();
                    outP2.write("Gotova igra\n");
                    outP2.newLine();
                    outP2.write("kraj\n");
                    outP2.flush();
                    break;
                }

                Integer num2;
                while (true) {

                    try {
                        num2 = loadData(inP2);
                        if (addToTable(num2, "O")) {
                            System.err.println("Dodato na tablu");
                            outP2.write("Dodato na tablu");
                            outP2.newLine();
                            outP2.write("kraj\n");
                            outP2.flush();
                            break;
                        }
                        break;
                    } catch (NumberFormatException ex) {
                        outP2.write("Nevalidan potez");
                        outP2.newLine();
                        outP2.write("kraj\n");
                        outP2.flush();
                    }
                }

                // ISPISI KOD KLIJENTA 1
                t = table();
                outP1.write(t);
                outP1.newLine();
                outP1.write("kraj\n");
                outP1.flush();

                // PROVERI DA LI JE POBEDIO IGRAC 2
                if (win("O")) {
                    // Posalji info da je gotova igra
                    outP1.write("Gotova igra");
                    outP1.newLine();
                    outP1.write("kraj\n");
                    outP1.flush();
                    outP2.write("Gotova igra");
                    outP2.newLine();
                    outP2.write("kraj\n");
                    outP2.flush();
                    break;
                }
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {

            try {
                this.p1.close();
                this.p2.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    private Integer loadData(BufferedReader in) throws IOException, NumberFormatException{
        String number = in.readLine().trim();
        System.out.println(number);
        Integer num = Integer.parseInt(number);

        return num;
    }

    private boolean addToTable(int place, String sign) {
        if (place < 1 || place > 9)
            return false;

        if (this.table[place - 1] != "-")
            return false;

        this.table[place - 1] = sign;
        return true;
    }

    private boolean win(String sign) {
        if (this.table[0] == sign && this.table[1] == sign && this.table[2] == sign)
            return true;

        if (this.table[3] == sign && this.table[4] == sign && this.table[5] == sign)
            return true;

        if (this.table[6] == sign && this.table[7] == sign && this.table[8] == sign)
            return true;

        if (this.table[0] == sign && this.table[3] == sign && this.table[6] == sign)
            return true;

        if (this.table[1] == sign && this.table[4] == sign && this.table[7] == sign)
            return true;

        if (this.table[2] == sign && this.table[5] == sign && this.table[8] == sign)
            return true;

        if (this.table[0] == sign && this.table[4] == sign && this.table[8] == sign)
            return true;

        if (this.table[2] == sign && this.table[4] == sign && this.table[6] == sign)
            return true;

        return false;
    }

    private String table() {
        StringBuilder sb = new StringBuilder("");

        for (int i = 0; i < 9; i++) {
            if (i == 3 || i == 6)
                sb.append('\n');

            sb.append(this.table[i] + ' ');
        }

        return sb.toString();
    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {

        try (Socket server = new Socket(XOServer.HOSTNAME, XOServer.DEFAULT_PORT);
             Scanner systemIn = new Scanner(System.in)) {

            try (BufferedReader serverIn = new BufferedReader(new InputStreamReader(server.getInputStream(), StandardCharsets.UTF_8));
                 BufferedWriter serverOut = new BufferedWriter(new OutputStreamWriter(server.getOutputStream(), StandardCharsets.UTF_8))) {

                String player = serverIn.readLine();

                if (player.equalsIgnoreCase("X")) {
                    StringBuilder boardBuilderInit = new StringBuilder();

                    String boardRow1Init = serverIn.readLine();
                    String boardRow2Init = serverIn.readLine();
                    String boardRow3Init = serverIn.readLine();

                    boardBuilderInit.append(boardRow1Init).append("\n")
                            .append(boardRow2Init).append("\n")
                            .append(boardRow3Init).append("\n");
                    String validBoardInit = boardBuilderInit.toString();

                    System.out.print(validBoardInit);
                }

                while (true) {

                    if (player.equalsIgnoreCase("X")) {
                        while (true) {
                            String move = systemIn.next();
                            serverOut.write(move);
                            serverOut.newLine();
                            serverOut.flush();

                            String response = serverIn.readLine();
                            if (response.equals("jeste"))
                                break;
                            else
                                System.out.println(response);
                        }

                        StringBuilder boardBuilder = new StringBuilder();

                        String boardRow1 = serverIn.readLine();
                        String boardRow2 = serverIn.readLine();
                        String boardRow3 = serverIn.readLine();

                        boardBuilder.append(boardRow1).append("\n")
                                .append(boardRow2).append("\n")
                                .append(boardRow3).append("\n");
                        String validBoard = boardBuilder.toString();

                        System.out.print(validBoard);
                    } else {
                        StringBuilder boardBuilder = new StringBuilder();

                        String boardRow1 = serverIn.readLine();
                        String boardRow2 = serverIn.readLine();
                        String boardRow3 = serverIn.readLine();

                        boardBuilder.append(boardRow1).append("\n")
                                .append(boardRow2).append("\n")
                                .append(boardRow3).append("\n");
                        String validBoard = boardBuilder.toString();

                        System.out.print(validBoard);

                        while (true) {
                            String move = systemIn.next();
                            serverOut.write(move);
                            serverOut.newLine();
                            serverOut.flush();

                            String response = serverIn.readLine();
                            if (response.equals("jeste"))
                                break;
                            else
                                System.out.println(response);
                        }

                    }

                }
            } catch (IOException e) {
                System.out.println("Game has finished!");
            }

        } catch (IOException e) {
            System.out.println("Failed to connect to server!");
        }

    }

}

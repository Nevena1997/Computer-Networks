package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

class XOServer {

    public static int DEFAULT_PORT = 12345;
    public static String HOSTNAME = "localhost";

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)) {

            while (true) {

                Game game = new Game();

                Socket clientA = server.accept();

                Socket clientB = server.accept();



                try (BufferedReader clientAIn = new BufferedReader(new InputStreamReader(clientA.getInputStream(), StandardCharsets.UTF_8));
                     BufferedWriter clientAOut = new BufferedWriter(new OutputStreamWriter(clientA.getOutputStream(), StandardCharsets.UTF_8));
                     BufferedReader clientBIn = new BufferedReader(new InputStreamReader(clientB.getInputStream(), StandardCharsets.UTF_8));
                     BufferedWriter clientBOut = new BufferedWriter(new OutputStreamWriter(clientB.getOutputStream(), StandardCharsets.UTF_8))) {

                    clientAOut.write("X");
                    clientAOut.newLine();
                    clientAOut.flush();

                    clientBOut.write("O");
                    clientBOut.newLine();
                    clientBOut.flush();


                    clientAOut.write(game.toString());
                    clientAOut.newLine();
                    clientAOut.flush();
//                    clientBOut.write(game.toString());
//                    clientBOut.newLine();
//                    clientBOut.flush();

                    while (!game.isFinished()) {

                        String moveA;
                        String moveB;

                        // Client A move
                        while (true) {
                            moveA = clientAIn.readLine();
                            try {
                                int movePosition = Integer.parseInt(moveA);
                                if (movePosition > 9 || !game.addMove('X', movePosition))
                                    throw new NumberFormatException();
                            }
                            catch (NumberFormatException e) {
                                clientAOut.write("Nevalidan potez");
                                clientAOut.newLine();
                                clientAOut.flush();
                                continue;
                            }
                            clientAOut.write("jeste");
                            clientAOut.newLine();
                            clientAOut.flush();
                            break;
                        }

                        clientBOut.write(game.toString());
                        clientBOut.newLine();
                        clientBOut.flush();

                        // Client B move
                        while (true) {
                            moveB = clientBIn.readLine();
                            try {
                                int movePosition = Integer.parseInt(moveB);
                                if (movePosition > 9 || !game.addMove('O', movePosition))
                                    throw new NumberFormatException();
                            }
                            catch (NumberFormatException e) {
                                clientBOut.write("Nevalidan potez");
                                clientBOut.newLine();
                                clientBOut.flush();
                                continue;
                            }
                            clientBOut.write("jeste");
                            clientBOut.newLine();
                            clientBOut.flush();
                            break;

                        }

                        clientAOut.write(game.toString());
                        clientAOut.newLine();
                        clientAOut.flush();


                    }

                    System.out.println("Game finished!");
                    clientA.close();
                    clientB.close();


                } catch (IOException e) {
                    System.out.println("Game finished!");
                }



            }


        } catch (IOException e) {
            System.out.println("Failed to open server...");
        }

    }

}

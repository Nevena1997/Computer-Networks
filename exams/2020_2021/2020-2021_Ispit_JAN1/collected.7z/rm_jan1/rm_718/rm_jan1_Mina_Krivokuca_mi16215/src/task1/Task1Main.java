package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.SimpleTimeZone;
import java.util.concurrent.TimeUnit;

class Task1Main {

    public static List<Path> files;
    public static List<Thread> threads;
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String word = sc.next();

        files = new LinkedList<>();
        threads = new LinkedList<>();

        try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme/"))) {
            for (Path p : dirStream) {
                //System.out.println(p);
                Thread t = new Thread(new SongParser(p, word));
                //threads.add(t);
                t.start();
            }

            /*
            * Iz nekog razloga mi se ne startuju niti kako treba, mora da sam zaboravila nesto bitno.
            * Kod za nit je implementiran u drugom fajlu, valjda potpuno.
            * Probala sam da tredove ubacim u listu, a onda i iteriram kroz nju da sacekam svaku da se zavrsi,
            * ali ni to ne radi. Iz nekog razloga se ne startuju nijedna osim prve zasigurno.
            * Uspela sam da procitam samo tri putanje iz direktorijuma, opet nepoznat razlog, kao da izadje iz petlje
            * za izlistavanje putanji pre vremena.
            * */

            /*
            for (Thread t : threads)
                t.join();
            * */
            TimeUnit.SECONDS.sleep(10);


        } catch (IOException e) {
            System.out.println("Failed to create directory stream...");
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted for some reason...");
        }


    }

}

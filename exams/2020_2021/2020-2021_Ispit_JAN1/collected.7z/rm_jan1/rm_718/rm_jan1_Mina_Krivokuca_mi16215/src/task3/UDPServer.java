package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

class UDPServer {

    public static int DEFAULT_PORT = 31415;
    public static String HOSTNAME = "localhost";

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(DEFAULT_PORT)) {

            while (true) {

                byte[] bytesToReceive = new byte[8];
                DatagramPacket dpToReceive = new DatagramPacket(bytesToReceive, bytesToReceive.length);

                socket.receive(dpToReceive);
                ByteBuffer bbToReceive = ByteBuffer.wrap(bytesToReceive);
                double doubleToReceive = bbToReceive.getDouble();

                byte[] bytesToSend;

                if (doubleToReceive < 0) {
                    bytesToSend = "Neispravan poluprecnik".getBytes();
                } else {
                    bytesToSend = String.valueOf(Math.round(doubleToReceive * doubleToReceive * 3.1415926535897932385)).getBytes();
                }

                DatagramPacket dpToSend = new DatagramPacket(bytesToSend, bytesToSend.length, dpToReceive.getAddress(), dpToReceive.getPort());
                socket.send(dpToSend);

            }

        } catch (SocketException e) {
            System.out.println("Failed to open server socket.");
        } catch (IOException e) {
            System.out.println("Failed to receive datagram");
        }
    }

}

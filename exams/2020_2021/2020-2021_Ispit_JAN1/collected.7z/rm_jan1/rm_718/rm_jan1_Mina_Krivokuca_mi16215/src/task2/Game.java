package task2;

public class Game {

    private char[] board;

    public Game() {
        this.board = new char[9];
        for (int i = 0; i < 9; i++) {
            this.board[i] = '-';
        }
    }

    public boolean isFinished() {
        for (int i = 0; i < 9; i++) {
            if (this.board[i] == '-')
                return false;
        }
        return true;
    }

    public boolean addMove(char player, int position) {
        if (this.board[position-1] != '-')
            return false;

        this.board[position-1] = player;
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.board[0]).append(this.board[1]).append(this.board[2]).append("\n");
        sb.append(this.board[3]).append(this.board[4]).append(this.board[5]).append("\n");
        sb.append(this.board[6]).append(this.board[7]).append(this.board[8]);
        return sb.toString();
    }

}

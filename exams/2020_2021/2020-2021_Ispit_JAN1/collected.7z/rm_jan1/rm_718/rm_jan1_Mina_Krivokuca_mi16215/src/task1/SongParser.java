package task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

class SongParser implements Runnable {

    private Path fileToParse;
    private String wordToLookFor;

    private String longestLine;
    private int wordCount;

    public SongParser(Path fileToParse, String wordToLookFor) {
        this.fileToParse = fileToParse;
        this.wordToLookFor = wordToLookFor;
        this.longestLine = "";
        this.wordCount = 0;
    }

    private void doTheJob(BufferedReader fileIn) throws IOException {
        String line = null;
        while ((line = fileIn.readLine()) != null) {
            if (line.length() > this.longestLine.length())
                this.longestLine = line;

            String[] lineSplitted = line.toLowerCase().split(wordToLookFor);
            this.wordCount += lineSplitted.length - 1;
        }
        printResults();
    }

    synchronized private void printResults() {
        BufferedWriter sysOut = null;
        try {
            sysOut = new BufferedWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8));
            String[] pathSplitted = String.valueOf(fileToParse).split("/");
            String fileName = pathSplitted[pathSplitted.length-1].replace(".txt", "");
            sysOut.write(fileName);
            sysOut.newLine();
            sysOut.write(this.longestLine);
            sysOut.newLine();
            sysOut.write(String.valueOf(this.wordCount));
            sysOut.newLine();
            sysOut.close();
        } catch (IOException e) {
            System.out.println("Failed to open system out buffered writer.");
        } finally {
            if (sysOut != null) {
                try {
                    sysOut.close();
                } catch (IOException e) {}
            }
        }
    }


    @Override
    public void run() {
        try {
            BufferedReader fileIn = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(fileToParse)), StandardCharsets.UTF_8));
            doTheJob(fileIn);

        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } catch (IOException e) {
            System.out.println("Something went wrong.");
        }

    }

}

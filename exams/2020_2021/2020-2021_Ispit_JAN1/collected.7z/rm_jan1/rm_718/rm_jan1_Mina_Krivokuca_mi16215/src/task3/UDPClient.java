package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress ia = InetAddress.getByName(UDPServer.HOSTNAME);

            Scanner sc = new Scanner(System.in);
            double doubleToSend = sc.nextDouble();

            byte[] bytesToSend = ByteBuffer.allocate(8).putDouble(doubleToSend).flip().array();
            DatagramPacket dpToSend = new DatagramPacket(bytesToSend, bytesToSend.length, ia, UDPServer.DEFAULT_PORT);

            socket.send(dpToSend);

            byte[] bytesToReceive = new byte[22];
            DatagramPacket dpToReceive = new DatagramPacket(bytesToReceive, bytesToReceive.length);
            socket.receive(dpToReceive);

            String response = new String(bytesToReceive);


            if (response.startsWith("N")) {
                System.out.println(response);
            } else
                System.out.println(response.substring(0, 17));

            sc.close();

        } catch (SocketException e) {
            System.out.println("Failed to open client socket.");
        } catch (UnknownHostException e) {
            System.out.println("Unknown host.");
        } catch (IOException e) {
            System.out.println("Failed to send datagram packet.");
        }
    }

}

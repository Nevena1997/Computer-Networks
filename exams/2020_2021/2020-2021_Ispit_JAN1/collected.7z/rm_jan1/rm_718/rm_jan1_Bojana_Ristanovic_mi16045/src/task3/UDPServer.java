package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;

class UDPServer {

    public static final int DEFAULT_PORT = 31415;
    
    public static void main(String[] args) {
        try(DatagramSocket socket = new DatagramSocket(DEFAULT_PORT)) {
            while (true){
                System.err.println("Server listening on port: " + DEFAULT_PORT);
                byte[] buff = new byte[1024];
                DatagramPacket request = new DatagramPacket(buff, buff.length);
                socket.receive(request);

                double r = Double.parseDouble(new String(request.getData(), 0, request.getLength()));
                if (r < 0){
                    String msg = "Neispravan poluprecnik.";
                    buff = msg.getBytes();
                    DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
                    socket.send(response);
                } else {
                    double pov = r * r * Math.PI;
                    //System.out.println("Povrsina: " + pov);
                    buff = String.valueOf(pov).getBytes();
                    DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
                    socket.send(response);

                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Hello from: " + UDPServer.class.getName());
    }

}

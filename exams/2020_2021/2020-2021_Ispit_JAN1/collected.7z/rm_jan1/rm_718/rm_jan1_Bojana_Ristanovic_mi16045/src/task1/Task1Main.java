package task1;

import com.sun.jdi.ThreadGroupReference;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        String word;
        word = in.nextLine();

        try {
            DirectoryStream s = Files.newDirectoryStream(Paths.get("../tests/pesme"));
            for (Iterator it = s.iterator(); it.hasNext(); ) {
                new Thread(new SongParser((Path) it.next(), word)).start();
            }

            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println(word);

        //System.out.println("Hello from: " + Task1Main.class.getName());
    }

}

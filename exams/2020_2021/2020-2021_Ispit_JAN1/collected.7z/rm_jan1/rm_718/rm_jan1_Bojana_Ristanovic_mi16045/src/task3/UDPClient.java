package task3;

import java.io.IOException;
import java.net.*;
import java.util.Arrays;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket()) {
            System.out.println("Unesite jedan broj: ");
            Scanner in = new Scanner(System.in);
            double num = in.nextDouble();

            byte[] buff = String.valueOf(num).getBytes();
            //System.out.println(Arrays.toString(buff) + "\n");
            DatagramPacket request = new DatagramPacket(buff, buff.length, InetAddress.getLocalHost(), UDPServer.DEFAULT_PORT);
            socket.send(request);
            System.err.println("Datagram sent");


            byte[] buffer = new byte[1024];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            socket.receive(response);

            String msg = new String(response.getData(), 0, response.getLength());
            if(msg.equalsIgnoreCase("Neispravan poluprecnik.")){
                System.out.println(msg);
            } else {
                System.out.println("Odgovor servera: " + Float.parseFloat(new String(response.getData(), 0, response.getLength())));
            }
            in.close();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Hello from: " + UDPClient.class.getName());
    }

}

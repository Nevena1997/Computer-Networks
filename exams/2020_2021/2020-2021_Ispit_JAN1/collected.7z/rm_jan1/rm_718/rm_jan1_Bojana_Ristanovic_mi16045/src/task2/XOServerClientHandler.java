package task2;

import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.Condition;

class XOServerClientHandler extends Thread{

     private XOServer server;
     private Socket user;
     private char[][] xo;
     private PrintWriter out;

    public XOServerClientHandler(XOServer server, Socket u) {
        this.server = server;
        this.user = u;
        this.xo = new char[3][3];
        initializeState();
    }

    @Override
    public void run() {
        try {
            this.printState(this.user, this.xo);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printState(Socket user, char[][] xo) throws IOException {
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(user.getOutputStream()));
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                out.write(xo[i][j] = '-');
            }
        }
        out.newLine();
        out.flush();
    }

    private void initializeState() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++){
                this.xo[i][j] = '-';
            }
    }
}

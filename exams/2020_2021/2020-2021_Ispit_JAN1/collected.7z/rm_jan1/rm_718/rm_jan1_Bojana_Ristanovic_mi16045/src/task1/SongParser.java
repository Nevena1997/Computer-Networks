package task1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

class SongParser implements Runnable{

    private Path file;
    private String word;
    private List<String> lines;

    public SongParser(Path next, String w) {
        this.file = next;
        this.word = w;
        this.lines = new ArrayList<>();
    }

    @Override
    public void run() {
        System.out.println(this.file.toString().substring(this.file.toString().lastIndexOf('/')+1, this.file.toString().lastIndexOf('.')));
        try {
            BufferedReader in = Files.newBufferedReader(file);
            while (in.readLine() != null){
                this.lines.add(in.readLine());
            }

            int count = 0;
            String max = lines.get(0);

            for (int i = 0; i < lines.size(); i++){
                if (lines.get(i).length() > max.length()){
                    max = lines.get(i);
                }
                if (lines.get(i).contains(word))
                    count++;
            }

            System.out.println(max);
            System.out.println(count);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

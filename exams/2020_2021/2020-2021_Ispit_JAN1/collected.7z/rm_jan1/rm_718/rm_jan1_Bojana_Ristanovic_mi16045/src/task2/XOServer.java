package task2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class XOServer {

    public static final int DEFAULT_PORT = 12345;


    private List<Socket> users;

    public XOServer() {
        this.users = new ArrayList<>();
    }

    public static void main(String[] args) {
        XOServer server = new XOServer();
        server.execute();
        //System.out.println("Hello from: " + XOServer.class.getName());
    }

    public void execute(){

        try(ServerSocket serverSocket = new ServerSocket(DEFAULT_PORT)) {

            while (true){
                System.err.println("Server listening on port: " + DEFAULT_PORT);
                Socket client = serverSocket.accept();

                this.users.add(client);

                if(this.users.size() == 2){
                    this.users.stream()
                            .forEach(u-> new XOServerClientHandler(this, u).start());
                }

                // Clienta treba da zatvorimo u niti!!!
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void printMessage() {
        System.err.println("Server started!...");
    }

}

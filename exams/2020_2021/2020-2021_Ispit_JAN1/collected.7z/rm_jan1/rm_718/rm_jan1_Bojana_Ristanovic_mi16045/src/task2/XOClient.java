package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

class XOClient {
    
    public static void main(String[] args) {
        try(Socket client = new Socket("localhost", XOServer.DEFAULT_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
        ) {
           while (true) {
               System.err.println("Client connected!");

               if (in.readLine() != null){
                   System.out.println(in.readLine());
               }

               while (in.read() != -1){
                   System.out.println(in.read());
               }

               Thread.sleep(500000);
           }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //System.out.println("Hello from: " + XOClient.class.getName());
    }

}

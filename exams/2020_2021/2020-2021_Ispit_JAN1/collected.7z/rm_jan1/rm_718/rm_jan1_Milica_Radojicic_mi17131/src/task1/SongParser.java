package task1;

import java.io.*;
import java.nio.file.Path;

class SongParser extends Thread {

    private final Path p;
    private final String word;

    SongParser(Path p, String word) {
        this.p = p;
        this.word = word;
    }

    @Override
    public void run() {
        String name = String.valueOf(p.getName(5));
        int i = name.indexOf(".");
        name = name.substring(0, i);
        int counter = 0;
        String[] trazi;

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(p))));
            String stih;
            String najduzi_stih = null;
            int max_len = 0;
            while(true){
                stih = br.readLine();
                if(stih == null)
                {break;}
                trazi = stih.split(" ");
                if(trazi != null){
                    for(String s : trazi)
                    {
                        s = s.toLowerCase();
                        if(s.contains(word))
                            counter++;
                    }
                }
                if(stih != null && !stih.contains("https")){
                    if(stih.length() > max_len){
                        max_len = stih.length();
                        najduzi_stih = stih;
                    }
                }
                else
                    break;
            }
            Task1Main.ispisi(name, najduzi_stih, counter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

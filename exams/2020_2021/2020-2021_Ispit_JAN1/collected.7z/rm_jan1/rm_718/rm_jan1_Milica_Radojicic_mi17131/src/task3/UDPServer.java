package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.Charset;

class UDPServer {
    
    public static void main(String[] args){

        try{
            DatagramSocket server = new DatagramSocket(31415);
            byte[] arr = new byte[32];

            while(true){
                DatagramPacket fromUser = new DatagramPacket(arr, arr.length);
                server.receive(fromUser);

                String s = new String(arr, 0, fromUser.getLength());
                double num = Double.parseDouble(s);

                if(num < 0) {
                    String toClient = "Neispravan poluprecnik";
                    arr = toClient.getBytes(Charset.defaultCharset());
                    DatagramPacket toCl = new DatagramPacket(arr, arr.length, fromUser.getAddress(), fromUser.getPort());
                    server.send(toCl);
                }
                else{
                    double area = num * num * Math.PI;

                    String toClient = String.valueOf(area);
                    arr = toClient.getBytes();
                    DatagramPacket toCl = new DatagramPacket(arr, arr.length, fromUser.getAddress(), fromUser.getPort());
                    server.send(toCl);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

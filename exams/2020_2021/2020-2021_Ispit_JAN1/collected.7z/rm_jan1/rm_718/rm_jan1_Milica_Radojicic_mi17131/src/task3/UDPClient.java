package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in)) {

            DatagramSocket client = new DatagramSocket();
            byte[] arr;

            InetAddress host = InetAddress.getLocalHost();

            double num = sc.nextDouble();
            String s = String.valueOf(num);
            arr = s.getBytes();
            DatagramPacket request = new DatagramPacket(arr, arr.length, host, 31415);
            client.send(request);

            arr = new byte[128];

            DatagramPacket answer = new DatagramPacket(arr, arr.length);
            client.receive(answer);
            String answ = new String(answer.getData(), 0, answer.getLength());
            System.out.println(answ);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

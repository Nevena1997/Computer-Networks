package task2;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

class XOClient {
    
    public static void main(String[] args){

        try(Socket client = new Socket("localhost", 12345)) {

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

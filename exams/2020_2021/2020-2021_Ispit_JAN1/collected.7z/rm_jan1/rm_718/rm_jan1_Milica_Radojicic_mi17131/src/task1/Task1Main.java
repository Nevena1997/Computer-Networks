package task1;

import java.io.*;
import java.nio.Buffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Stream;

class Task1Main {

    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
            String word =  sc.next();
            word = word.toLowerCase();

            Path path = Paths.get("/home/ispit/Desktop/tests/pesme");

            DirectoryStream<Path> ds = Files.newDirectoryStream(path);

            for(Path p : ds){

                new SongParser(p, word).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public synchronized static void ispisi(String name, String najduzi_stih, int counter) {
        System.out.println(name);
        System.out.println(najduzi_stih);
        System.out.println(counter);
    }
}

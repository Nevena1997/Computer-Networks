package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try (DatagramSocket sock=new DatagramSocket();
             Scanner sc=new Scanner(System.in)){
            double br=sc.nextDouble();

            DatagramPacket slanje=new DatagramPacket(String.valueOf(br).getBytes(),String.valueOf(br).getBytes().length, InetAddress.getLocalHost(),UDPServer.PORT);
            sock.send(slanje);

            byte[] buff=new byte[2048];
            DatagramPacket prijem=new DatagramPacket(buff,buff.length);
            sock.receive(prijem);
            String ispis=new String(buff,0,prijem.getLength());
            System.out.println(ispis);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

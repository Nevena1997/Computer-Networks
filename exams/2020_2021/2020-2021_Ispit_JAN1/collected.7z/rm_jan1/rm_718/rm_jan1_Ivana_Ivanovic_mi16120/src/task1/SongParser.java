package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

class SongParser implements Runnable{

    private String rec;
    private Path putanja;

    public SongParser(Path p, String rec) {
        this.putanja=p;
        this.rec=rec;
    }

    @Override
    public void run() {
        try {
            BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(putanja.toString()))) ;
            String l;
            int br=0;
            int br2=0;
            String najduza="";
            while((l=in.readLine())!=null){
                if(br<l.length()) {
                    br = l.length();
                    najduza=l;
                }
                String[] reci=l.split(" ");
                for(int i=0;i<reci.length;i++){
                    if(reci[i].equals(rec))
                        br2++;

                }

            }
            String naziv=putanja.toString();
            naziv=naziv.substring(naziv.lastIndexOf("/")+1,naziv.lastIndexOf("."));
            System.out.println(naziv);
            System.out.println(najduza);
            System.out.println(br2);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

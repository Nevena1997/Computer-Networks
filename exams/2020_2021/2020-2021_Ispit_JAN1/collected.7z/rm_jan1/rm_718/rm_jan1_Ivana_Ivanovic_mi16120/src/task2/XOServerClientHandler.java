package task2;

import java.io.*;
import java.net.Socket;
import java.util.List;

class XOServerClientHandler implements Runnable{

    private  List<Character> potezi;
    private  Socket drugi;
    private  Socket prvi;

    public XOServerClientHandler(Socket poll, Socket poll1, List<Character> potezi) {
        this.prvi=poll;
        this.drugi=poll1;
        this.potezi=potezi;
    }

    @Override
    public void run() {
        try {
            BufferedWriter out1=new BufferedWriter(new OutputStreamWriter(prvi.getOutputStream()));
            BufferedWriter out2=new BufferedWriter(new OutputStreamWriter(drugi.getOutputStream()));
            BufferedReader in1=new BufferedReader(new InputStreamReader(prvi.getInputStream()));
            BufferedReader in2=new BufferedReader(new InputStreamReader(drugi.getInputStream()));
            while (true) {
                int n=Integer.parseInt(in1.readLine());
                if(potezi.indexOf(n)=='*'){

                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());
        try (Scanner sc=new Scanner(System.in)){
            String rec=sc.nextLine();
            sc.close();
            String dir="/home/ispit/Desktop/tests/pesme";

            try {
                DirectoryStream<Path> d= Files.newDirectoryStream(Paths.get(dir));
                obilazak(d,rec);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    private static synchronized void obilazak(DirectoryStream<Path> d,String rec) {
        for (Path p:d){
            new Thread(new SongParser(p,rec)).start();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

class XOServer {
    public static int PORT=12345;
    private final int port;
    public BlockingQueue<Socket> klijenti=new ArrayBlockingQueue<Socket>(200);

    public XOServer(int port) {
        this.port=port;
    }

    public static void main(String[] args) {
        XOServer server=new XOServer(PORT);
        server.execute();
    }

    private void execute() {
        try(ServerSocket server=new ServerSocket(PORT);){

            while (true){
                Socket klijent=server.accept();
                klijenti.add(klijent);
                if(klijenti.size()>=2){
                    List<Character> potezi=new ArrayList<>(9);
                    for(int i=0;i<9;i++)
                        potezi.add('*');
                    new Thread(new XOServerClientHandler(klijenti.poll(),klijenti.poll(),potezi)).start();

                }
                

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

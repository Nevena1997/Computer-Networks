package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

class XOClient {
    
    public static void main(String[] args) {
        try (Socket sock=new Socket("localhost",XOServer.PORT)){

            while(true) {

                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));

                Scanner sc = new Scanner(System.in);
                int potez=sc.nextInt();
                if(potez>9)
                    System.out.println("Neispravan unos");
                else{
                    out.write(potez);
                    out.newLine();
                    out.flush();
                }
                ispis(in.readLine());
            }



        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void ispis(String readLine) {
        System.out.println();
    }


}

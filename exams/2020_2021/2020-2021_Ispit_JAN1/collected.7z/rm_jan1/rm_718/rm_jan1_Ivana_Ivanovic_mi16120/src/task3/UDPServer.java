package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {
    public static int PORT=31415;
    
    public static void main(String[] args) {

        try (DatagramSocket server=new DatagramSocket(PORT);){
            while (true){
                byte[] buff=new byte[2048];
                DatagramPacket prijem=new DatagramPacket(buff,2048);
                server.receive(prijem);
                String ispis=new String(buff,0,prijem.getLength());

                double br=Double.valueOf(ispis);


                if(br<0){
                    String rez="Neispravan poluprecnik";
                    DatagramPacket slanje=new DatagramPacket(rez.getBytes(),rez.getBytes().length,prijem.getAddress(),prijem.getPort());
                    server.send(slanje);

                }
                else {
                    double rez = 2 * br * Math.PI;
                    String r = String.valueOf(rez);
                    DatagramPacket slanje = new DatagramPacket(r.getBytes(), r.getBytes().length, prijem.getAddress(), prijem.getPort());
                    server.send(slanje);
                }

            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

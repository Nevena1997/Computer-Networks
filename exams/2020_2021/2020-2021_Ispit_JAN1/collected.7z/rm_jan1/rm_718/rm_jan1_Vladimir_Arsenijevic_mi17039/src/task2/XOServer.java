package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {

    private static boolean isValid(String tabla,String s){
        int x = Integer.parseInt(s)-1;
        if (x<0 || x>8)
            return false;
        return (tabla.charAt(x) == ' ');
    }
    private static boolean checkTable(String s,String tabla,char x){
        int tmp = 0;
        for (int i=0;i<s.length();i++)
            if (s.charAt(i) == 'x' && tabla.charAt(i) == x)
                tmp++;
        return tmp == 3;
    }
    private static boolean isDone(String tabla,char x){
        return checkTable("xxx......", tabla, x) || checkTable("...xxx...", tabla, x) || checkTable("......xxx", tabla, x) ||
                checkTable("x..x..x..", tabla, x) || checkTable(".x..x..x.", tabla, x) || checkTable("..x..x..x", tabla, x) ||
                checkTable("x...x...x", tabla, x) || checkTable("..x.x.x..", tabla, x);
    }
    public static void main(String[] args) {
        String res;
        try(ServerSocket socket = new ServerSocket(12345)){
            while(true) { //SERVER LOOP

                StringBuilder tabla = new StringBuilder("         ");

                Socket client1 = socket.accept();
                Socket client2 = socket.accept();

                BufferedReader in1 = new BufferedReader(new InputStreamReader(client1.getInputStream()));
                BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(client1.getOutputStream()));

                BufferedReader in2 = new BufferedReader(new InputStreamReader(client2.getInputStream()));
                BufferedWriter out2 = new BufferedWriter(new OutputStreamWriter(client2.getOutputStream()));

                while(true){ //MAIN GAME LOOP
                    out1.write(tabla.toString());
                    out1.newLine();
                    out1.flush();

                    while(true) {
                        res = in1.readLine();
                        if (isValid(tabla.toString(),res)) {
                            tabla.setCharAt(Integer.parseInt(res)-1,'o');
                            out1.write(tabla.toString());
                            out1.newLine();
                            out1.flush();
                            break;
                        }
                        out1.write("err");
                        out1.newLine();
                        out1.flush();
                    }
                    if (isDone(tabla.toString(),'o')) {
                        out1.write("Pobedio je o");
                        out1.newLine();
                        out1.flush();
                        out2.write("Pobedio je o");
                        out2.newLine();
                        out2.flush();
                        break;
                    }
                    //--------------------------------Player1 Done

                    out2.write(tabla.toString());
                    out2.newLine();
                    out2.flush();

                    while(true) {
                        res = in2.readLine();
                        if (isValid(tabla.toString(),res)) {
                            tabla.setCharAt(Integer.parseInt(res)-1,'x');
                            out2.write(tabla.toString());
                            out2.newLine();
                            out2.flush();
                            break;
                        }
                        out2.write("err");
                        out2.newLine();
                        out2.flush();
                    }
                    if (isDone(tabla.toString(),'x')){
                        out1.write("Pobedio je x");
                        out1.newLine();
                        out1.flush();
                        out2.write("Pobedio je x");
                        out2.newLine();
                        out2.flush();
                        break;
                    }
                    //-----------------------------------Player2 Done
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

}

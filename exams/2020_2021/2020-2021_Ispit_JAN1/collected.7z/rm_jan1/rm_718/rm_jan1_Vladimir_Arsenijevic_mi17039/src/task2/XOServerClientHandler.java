package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

class XOServerClientHandler extends Thread {
    private Socket client;

   /* XOServerClientHandler(Socket s){
        this.client = s;
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

    }*/
}

package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

class SongParser extends Thread {
    private Path p;
    private String word;
    public SongParser(Path p,String rec) {
        this.p = p;
        this.word = rec;
    }

    @Override
    public void run() {
        try {
            List<String> lines = Files.readAllLines(p);
            int count = 0;
            String longest = "";
            for (String s:lines){
                String[] arr = s.split(" ");
                for (String tmp:arr){
                    if (tmp.compareToIgnoreCase(this.word) == 0)
                        count++;
                }
                if (s.length()>longest.length())
                    longest = s;
            }
            synchronized (System.out){
                String tmp = this.p.toString();
                String name = tmp.substring(tmp.lastIndexOf("/")+1);
                System.out.println(name.substring(0,name.length()-4));
                System.out.println(longest);
                System.out.println(count);
                System.out.println("----------------");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

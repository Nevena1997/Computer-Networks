package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket server = new DatagramSocket()){
            Scanner sc = new Scanner(System.in);
            float x = sc.nextFloat();
            byte[] buff = Float.toString(x).getBytes(StandardCharsets.UTF_8);
            DatagramPacket send = new DatagramPacket(buff,buff.length,InetAddress.getByName("localhost"),31415);
            server.send(send);
            DatagramPacket recv = new DatagramPacket(new byte[256],256);
            server.receive(recv);
            String s = new String(recv.getData(),0,recv.getLength(),StandardCharsets.UTF_8);
            System.out.println(s);
        }catch (IOException e){
            e.printStackTrace();
        }
    }

}

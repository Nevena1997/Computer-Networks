package task1;

import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String rec = sc.nextLine();
        FileTreeWalker ftw = new FileTreeWalker(rec);
        ftw.start();
    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {
        try(DatagramSocket server = new DatagramSocket(31415)){
            while(true){
                DatagramPacket recv = new DatagramPacket(new byte[256],256);
                server.receive(recv);
                String s = new String(recv.getData(),0,recv.getLength(), StandardCharsets.UTF_8);
                float x = Float.parseFloat(s);
                byte[] buff;
                if (x>=0) {
                    x = (float) (x * x * 3.14);
                     buff = Float.toString(x).getBytes(StandardCharsets.UTF_8);
                }else buff = "Neispravan poluprecnik".getBytes(StandardCharsets.UTF_8);
                DatagramPacket send = new DatagramPacket(buff,buff.length,recv.getAddress(),recv.getPort());
                server.send(send);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }

}

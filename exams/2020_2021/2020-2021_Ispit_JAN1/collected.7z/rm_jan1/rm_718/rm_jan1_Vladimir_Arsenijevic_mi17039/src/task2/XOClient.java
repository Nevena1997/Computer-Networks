package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class XOClient {

    private static void drawBoard(String s){
        for(int i=0;i<s.length();i++){
            if (i!=0 && (i%3 == 0))
                System.out.println();
            System.out.printf("|%c|",s.charAt(i));
        }
        System.out.println();
    }

    public static void main(String[] args) {
        try(Socket server = new Socket("localhost",12345)){
            BufferedReader in = new BufferedReader(new InputStreamReader(server.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(server.getOutputStream()));
            Scanner sc = new Scanner(System.in);
            String tabla;
            String polje;
            while(true){
                tabla = in.readLine();
                if (tabla.startsWith("P")){
                    System.out.println(tabla);
                    break;
                }
                drawBoard(tabla);
                while(true) {
                    polje = sc.nextLine();
                    out.write(polje);
                    out.newLine();
                    out.flush();
                    tabla = in.readLine();
                    if (tabla.compareToIgnoreCase("err") != 0)
                        break;
                    System.out.println("Neispravan potez!");
                }
                drawBoard(tabla);
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileTreeWalker extends Thread {

    private String word;
    FileTreeWalker(String s){
        this.word = s;
    }

    @Override
    public void run() {
        Path startPath = Paths.get("/home/ispit/Desktop/tests/pesme");
        try(DirectoryStream<Path> ds = Files.newDirectoryStream(startPath)){
            for (Path p:ds){
                if (Files.isDirectory(p))
                    new FileTreeWalker(p.toString()).start();
                else {
                    SongParser sp = new SongParser(p,word);
                    sp.start();
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }

    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class XOServer {
    public static final int PORT = 12345;

    private static String formatTableOut(String table) {
        return table.substring(0, 3) + '\n' + table.substring(3, 6) + '\n' + table.substring(6, 9) + '\n';
    }

    private static String updateTable(String table, int move, int playerId) {
        char[] tmp = table.toCharArray();
        if (playerId == 1) tmp[move-1] = 'X';
        else tmp[move-1] = 'O';
        return new String(tmp);
    }

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(PORT)) {
            String table = "---------";

            while (true) {
                Socket client1 = server.accept();
                System.out.println("Player 1 connected!");
                Socket client2 = server.accept();
                System.out.println("Player 2 connected!");

                XOClientIO c1 = new XOClientIO(client1);
                XOClientIO c2 = new XOClientIO(client2);

                while (true) {
                    c1.toClient("Vas potez");
                    int move = move = Integer.parseInt(c1.fromClient());
                    while (move < 1 || move > 9) {
                        c1.toClient("Nepravolan unos. Unesite ponovo.");
                        move = Integer.parseInt(c1.fromClient());
                    }

                    table = updateTable(table, move, 1);
                    c1.toClient(formatTableOut(table));
                    c2.toClient(formatTableOut(table));

                    if (!table.contains("-"))
                        break;

                    c2.toClient("Vas potez");
                    move = Integer.parseInt(c2.fromClient());
                    while (move < 1 || move > 9) {
                        c2.toClient("Nepravolan unos. Unesite ponovo.");
                        move = Integer.parseInt(c2.fromClient());
                    }
                    table = updateTable(table, move, 2);
                    c1.toClient(formatTableOut(table));
                    c2.toClient(formatTableOut(table));

                    if (!table.contains("-"))
                        break;
                }
                c1.toClient("Game over!");
                c2.toClient("Game over!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;

public class XOClientIO {
    private PrintWriter toClient;
    private BufferedReader fromClient;

    XOClientIO(Socket client) throws IOException {
        this.toClient = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
        this.fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
    }

    public void toClient(String msg) {
        toClient.println(msg);
        toClient.flush();
    }

    public String fromClient() throws IOException {
        return fromClient.readLine();
    }
}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;


class XOClient {
    
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", XOServer.PORT);
             BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
             PrintWriter toServer = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
             Scanner sc = new Scanner(System.in);
        ) {
            System.out.println("Zadatak radi preko netcat-a!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
             DatagramSocket client = new DatagramSocket();
        ) {
            Double r = sc.nextDouble();
            byte[] buff = ByteBuffer.allocate(30).putDouble(r).array();
            DatagramPacket request = new DatagramPacket(buff, buff.length, InetAddress.getByName("localhost"), UDPServer.PORT);
            client.send(request);

            DatagramPacket response = new DatagramPacket(buff, buff.length);
            client.receive(response);
            String res = new String(ByteBuffer.wrap(buff).array(), StandardCharsets.UTF_8);
            System.out.println(res.split("\n")[0]);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

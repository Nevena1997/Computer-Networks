package task1;

import java.io.File;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        String path = "/home/ispit/Desktop/tests/pesme";
        File songDir = new File(path);
        if (songDir.exists()) {
            Scanner sc = new Scanner(System.in);
            String word = sc.next();

            for (File song : songDir.listFiles()) {
                new Thread(new SongParser(song, word)).start();
            }
            sc.close();
        }
    }
}

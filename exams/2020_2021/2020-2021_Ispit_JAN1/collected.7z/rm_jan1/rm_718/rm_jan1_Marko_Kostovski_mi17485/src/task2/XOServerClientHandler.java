package task2;


import java.util.concurrent.Callable;

class XOServerClientHandler implements Callable<Integer> {
    private XOClientIO clientInstance;
    private int playerId;

    XOServerClientHandler(XOClientIO ci, int playerId) {
        this.playerId = playerId;
        this.clientInstance = ci;
    }

    @Override
    public Integer call() throws Exception {
        clientInstance.toClient("Game starting. You are player " + playerId);
        clientInstance.toClient(String.valueOf(playerId));
        int currentTurn = 1;
        clientInstance.toClient(String.valueOf(currentTurn));



        System.out.println("Player is leaving");
        return 1;
    }
}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;

class UDPServer {
    public static final int PORT = 31415;

    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(PORT)) {
            while (true) {
                byte[] buff = ByteBuffer.allocate(30).array();
                DatagramPacket request = new DatagramPacket(buff, buff.length);
                server.receive(request);

                Double r = ByteBuffer.wrap(buff).getDouble();
                String res;
                if (r < 0) {
                    res = "Neispravan poluprecnik\n";
                } else {
                    Double area = r * r * Math.PI;
                    res = area.toString() + '\n';
                }
                ByteBuffer.wrap(buff).put(res.getBytes());
                DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
                server.send(response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class SongParser implements Runnable {
    private File song;
    private String word;

    SongParser(File song, String word) {
        this.song = song;
        this.word = word;
    }


    @Override
    public void run() {
        try (Scanner sc = new Scanner(this.song)) {
            String longestVerse = "";
            int numOfOccurances = 0;
            while (sc.hasNextLine()) {
                String verse = sc.nextLine();
                if (verse.matches("[-+/@#$%^&*)(_]"))
                    continue;

                if (verse.length() > longestVerse.length()) {
                    longestVerse = verse;
                }
                String[] words = verse.split(" ");
                for (String word : words)
                    if (word.equalsIgnoreCase("kao"))
                        numOfOccurances+=1;

            }
            System.out.println(this.song.getName() + '\n' + longestVerse + '\n' + numOfOccurances);;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

class UDPServer {

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(31415)) {

            while (true) {
                try {
                    DatagramPacket request = new DatagramPacket(new byte[8], 8);
                    server.receive(request);

                    double r = ByteBuffer.wrap(request.getData()).getDouble();


                    if(r < 0) {
                        //los poluprecnik
                        byte[] badRequest = "Neispravan poluprecnik".getBytes();
                        DatagramPacket response = new DatagramPacket(badRequest, badRequest.length, request.getAddress(), request.getPort());
                        server.send(response);
                    }else{
                        double p = r*r*Math.PI;
                        byte[] responseBuf = ByteBuffer.allocate(8).putDouble(p).array();
                        DatagramPacket response = new DatagramPacket(responseBuf, responseBuf.length, request.getAddress(), request.getPort());
                        server.send(response);
                    }

                    double p = r*r*Math.PI;



                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        } catch (SocketException e) {
            e.printStackTrace();
        }

    }

}

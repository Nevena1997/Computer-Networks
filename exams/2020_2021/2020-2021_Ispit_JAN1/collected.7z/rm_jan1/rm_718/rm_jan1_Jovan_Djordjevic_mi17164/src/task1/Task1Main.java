package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

class Task1Main {

    public static AtomicBoolean threadWriting = new AtomicBoolean(false);
    
    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in)){

            String word = sc.next();
            String folderPath = "/home/ispit/Desktop/tests/pesme";

            List<String> paths = new ArrayList<>();

            try(DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get(folderPath))){
                for(Path p : ds){
                    System.out.printf(p.toString() + "\n");
                    paths.add(p.toString());
                }

                for(String path : paths){
                    (new SongParser(path, word)).start();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {

    public static void main(String[] args) {
        try(Socket client = new Socket("localhost", 12345);
            BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner sc = new Scanner(System.in);
        ){

            //ulaz je nesto od:
            // 1 2 3
            // 4 5 6
            // 7 8 9

            while(true){
                //list board
                String row1 = networkIn.readLine();
                String row2 = networkIn.readLine();
                String row3 = networkIn.readLine();
                System.out.println(row1 + "\n" + row2 + "\n" + row3 + "\n");

                //input move
                int move = sc.nextInt();
                move--;

                //send move
                networkOut.write(Integer.toString(move));
                networkOut.newLine();
                networkOut.flush();

                String isValid = networkIn.readLine();
                if(isValid.equalsIgnoreCase("no")){
                    while (isValid.equalsIgnoreCase("no")) {
                        System.out.println("Nevalidan potez");
                        //ocekuje se nov potez
                        move = sc.nextInt();
                        move--;
                        networkOut.write(move);
                        networkOut.newLine();
                        networkOut.flush();
                        isValid = networkIn.readLine();
                    }
                }

                //isfinihed
                if(networkIn.readLine().equalsIgnoreCase("finished")){
                    //igra je gotova
                    break;
                }

            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.*;
import java.nio.file.Paths;

class SongParser extends Thread{
    private String path;
    private String word;
    private int wordCount = 0;
    private String longestLine = "";
    private int longestLineLength = 0;

    SongParser(String path, String word){
        this.path = path;
        this.word = word;
    }

    @Override
    public void run() {
        try(FileInputStream fis = new FileInputStream(path);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));
           ){

            String line;
            while( (line = in.readLine()) != null){
                if(line.length() > longestLineLength && !line.contains("://")){
                    longestLine = line;
                    longestLineLength = line.length();
                }

                String[] words = line.split(" ");
                for(String w : words){
                    if(w.contains(this.word) || w.equalsIgnoreCase(this.word)){
                        wordCount++;
                    }
                }
            }

            synchronized (Task1Main.threadWriting){
                while (Task1Main.threadWriting.get() == true){
                    try {
                        Task1Main.threadWriting.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                Task1Main.threadWriting.set(true);
                String songName = Paths.get(path).getFileName().toString();
                System.out.println(songName.substring(0, songName.indexOf(".txt")));
                System.out.println(longestLine);
                System.out.println(wordCount);

                Task1Main.threadWriting.set(false);
                Task1Main.threadWriting.notifyAll();
            }


        } catch (FileNotFoundException e) {
            System.out.printf("Nepostojeci fajl");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

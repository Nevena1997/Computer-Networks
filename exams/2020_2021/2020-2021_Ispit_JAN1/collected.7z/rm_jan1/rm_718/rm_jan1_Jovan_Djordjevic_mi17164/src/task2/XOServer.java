package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;

class XOServer {

    //1 je X    2 je O
    public static AtomicInteger playerToMove = new AtomicInteger(1);
    
    public static void main(String[] args) {

       try(ServerSocket server = new ServerSocket(12345)){

           while(true) {
               Socket XPlayer = server.accept();
               Socket OPlayer = server.accept();

               char[] board = {'-', '-', '-',
                               '-', '-', '-',
                               '-', '-', '-'};

               XOServerClientHandler p1 = new XOServerClientHandler(XPlayer, 'X', board);
               XOServerClientHandler p2 = new XOServerClientHandler(OPlayer, 'O', board);

               //npr neka X u svakoj partiji igra
               playerToMove.set(1);

               p1.start();
               p2.start();

               try {
                   p1.join();
                   p2.join();
               } catch (InterruptedException e) {
                   e.printStackTrace();
               }

               //System.out.println("game finished");
           }
       } catch (IOException e) {
           e.printStackTrace();
       }
    }

}

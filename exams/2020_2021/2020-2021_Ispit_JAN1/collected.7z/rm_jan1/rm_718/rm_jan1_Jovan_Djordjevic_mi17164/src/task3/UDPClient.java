package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
           ) {

            double r = sc.nextDouble();
            byte[] requestBuf = ByteBuffer.allocate(8).putDouble(r).array();
            InetAddress host = InetAddress.getLocalHost();
            DatagramPacket request = new DatagramPacket(requestBuf, requestBuf.length, host, 31415);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[128], 128);
            client.receive(response);

            byte[] responseBuf = response.getData();

            String responseStr = new String(response.getData(), 0 , response.getLength());
            if(responseStr.equalsIgnoreCase("Neispravan poluprecnik")){
                System.out.println(responseStr);
            }else {
                System.out.println(ByteBuffer.wrap(response.getData()).getDouble());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

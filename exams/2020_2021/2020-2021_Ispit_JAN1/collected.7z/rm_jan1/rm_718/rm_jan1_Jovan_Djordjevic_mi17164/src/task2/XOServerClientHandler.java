package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler extends Thread{
    private Socket client;
    private char moveChar;
    private char[] board;
    private int playerIndex;
    private int otherPlayerIndex;
    private boolean gameFinished = false;

    XOServerClientHandler(Socket client, char moveChar, char[] board){
        this.client = client;
        this.moveChar = moveChar;
        if(moveChar == 'X'){
            this.playerIndex = 1;
            this.otherPlayerIndex = 2;
        }else{
            playerIndex = 2;
            this.otherPlayerIndex = 1;
        }
        this.board = board;
    }

    @Override
    public void run() {
       try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
           BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))
          ){

           while(true){

               synchronized (XOServer.playerToMove){
                   while(XOServer.playerToMove.get() != this.playerIndex){
                       try{
                           XOServer.playerToMove.wait();
                       } catch (InterruptedException e) {
                           e.printStackTrace();
                       }
                   }

                   XOServer.playerToMove.set(this.playerIndex);

                   //send game state
                   out.write(board[0]); out.write(board[1]); out.write(board[2]);
                   out.newLine();
                   out.flush();
                   out.write(board[3]); out.write(board[4]); out.write(board[5]);
                   out.newLine();
                   out.flush();
                   out.write(board[6]); out.write(board[7]); out.write(board[8]);
                   out.newLine();
                   out.flush();

                   //read player move
                   int move = Integer.parseInt(in.readLine());
                   String isValid = checkIfValid(move);
                   while (isValid.equalsIgnoreCase("no")){
                       out.write(isValid);
                       out.newLine();
                       out.flush();
                       move = Integer.parseInt(in.readLine());
                       isValid = checkIfValid(move);
                   }
                   out.write(isValid);
                   out.newLine();
                   out.flush();

                   board[move] = this.moveChar;
                   boolean isFinished = checkIfGameIsFinished();
                   if(isFinished){
                       out.write("finished");
                       out.newLine();
                       out.flush();
                       gameFinished = true;
                   }else{
                       out.write("not finished");
                       out.newLine();
                       out.flush();
                   }

                   XOServer.playerToMove.set(otherPlayerIndex);
                   XOServer.playerToMove.notifyAll();
               }

               if(gameFinished){
                   break;
               }

           }

       } catch (IOException e) {
           e.printStackTrace();
       }finally {
           try {
               this.client.close();
           } catch (IOException e) {
               e.printStackTrace();
           }
       }

    }

    private synchronized boolean checkIfGameIsFinished() {

        if((board[0] != '-' && (board[0] == board[1] && board[1] == board[2])) ||  //redovi
           (board[3] != '-' && (board[3] == board[4] && board[4] == board[5])) ||
           (board[6] != '-' && (board[6] == board[7] && board[7] == board[8])) ||
           (board[0] != '-' && (board[0] == board[3] && board[3] == board[6])) || // vrste
           (board[1] != '-' && (board[1] == board[4] && board[4] == board[7])) ||
           (board[2] != '-' && (board[2] == board[5] && board[5] == board[8])) ||
           (board[0] != '-' && (board[0] == board[4] && board[4] == board[8])) ||  //dijagonale
           (board[2] != '-' && (board[2] == board[4] && board[4] == board[6]))
        ){
            //imamo pobednika
            return true;
        }

        int countEmpty = 0;

        for(char c : board){
            if(c == '-') {
                countEmpty++;
            }
        }
        if(countEmpty == 9){
            //imamo nereseno
            return true;
        }


        return false;
    }

    private synchronized String checkIfValid(int move) {
        if(move < 0 || move > 8) return "no";
        for(char c : board){
            if(board[move] != '-') return "no";
        }
        return "yes";
    }
}

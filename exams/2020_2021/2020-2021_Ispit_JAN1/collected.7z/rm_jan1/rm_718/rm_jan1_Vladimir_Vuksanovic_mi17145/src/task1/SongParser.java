package task1;

import java.io.*;
import java.util.Scanner;

class SongParser extends Thread{

    private Task1Main main;
    private File file;
    private BufferedReader reader;
    private String word;

    SongParser(Task1Main main, String filename, String word) {
        this.main = main;
        this.word = word;
        this.file = new File(filename);

        try {
            this.reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        String title = file.getName();
        int count = 0;

        long maxLength = 0;
        String maxLine = "";
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.length() > maxLength) {
                    maxLength = line.length();
                    maxLine = line;
                }
                try(Scanner lineIn = new Scanner(line)) {
                    while(lineIn.hasNext()) {
                        String str = lineIn.next().toLowerCase();
                        if(str.contains(word))
                            count++;
                    }
                }

            }
            main.printResults(title + "\n" + maxLine + "\n" + count);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}

package task3;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPClient.class.getName());

        try (Scanner s = new Scanner(System.in)) {
            double r = s.nextDouble();

            try (DatagramSocket socket = new DatagramSocket()) {

                InetAddress address = InetAddress.getByName("localhost");

                ByteBuffer buf = ByteBuffer.allocate(8);
                buf.putDouble(r);
                byte[] bytes = buf.array();

                DatagramPacket req = new DatagramPacket(bytes, bytes.length, address, UDPServer.PORT);
                socket.send(req);

                bytes = new byte[100];
                DatagramPacket res = new DatagramPacket(bytes, bytes.length);
                socket.receive(res);

                if(new String(res.getData(), 0, res.getLength()).equals("Neispravan poluprecnik")) {
                    System.out.println("Neispravan poluprecnik");
                } else {
                    buf.clear();
                    buf.put(bytes, 0, res.getLength());
                    buf.flip();
                    double area = buf.getDouble();
                    System.out.println("Povrsina je: " + area);
                }

            } catch (UnknownHostException e) {
                System.err.println("Unknown host");
                e.printStackTrace();
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

}

package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

class UDPServer {

    public static final int PORT = 31415;

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());

        try (DatagramSocket server = new DatagramSocket(PORT)) {
            while(true) {
                try {
                    byte[] bytes = new byte[8];

                    DatagramPacket req = new DatagramPacket(bytes, bytes.length);
                    server.receive(req);

                    ByteBuffer buf = ByteBuffer.allocate(8);
                    buf.put(bytes);
                    buf.flip();
                    double r = buf.getDouble();

                    if (r < 0) {
                        byte[] msg = "Neispravan poluprecnik".getBytes();
                        DatagramPacket res = new DatagramPacket(msg, msg.length, req.getAddress(), req.getPort());
                        server.send(res);
                    } else {
                        // alternativa napraviti nisku od double i poslati tako
                        // onda klijent moze samo da ispise poruku
//                        bytes = String.valueOf(r * r * Math.PI).getBytes();

                        buf.clear();
                        buf.putDouble(r * r * Math.PI);
                        bytes = buf.array();

                        DatagramPacket res = new DatagramPacket(bytes, bytes.length, req.getAddress(), req.getPort());
                        server.send(res);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

class XOServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOServer.class.getName());

        int nClients = 0;
        List<Socket> clients = new ArrayList<>();

        try (ServerSocket server = new ServerSocket(PORT)) {
            while(true) {
                Socket client = server.accept();
                clients.add(client);

                nClients++;
                if(nClients == 2) {
                    try {
                        var thread = new XOServerClientHandler(clients.get(0), clients.get(1));
                        thread.start();
                        thread.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        nClients = 0;
                        clients.clear();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

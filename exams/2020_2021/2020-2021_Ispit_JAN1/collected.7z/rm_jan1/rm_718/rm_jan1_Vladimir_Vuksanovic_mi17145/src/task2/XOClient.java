package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

class XOClient {

    private char[] board;

    public static void main(String[] args) {
        System.out.println("Hello from: " + XOClient.class.getName());
        new XOClient().startGame();
    }

    private void startGame() {
        try (Socket s = new Socket("localhost", XOServer.PORT);
             Scanner in = new Scanner(s.getInputStream());
             PrintWriter out = new PrintWriter(s.getOutputStream());
             Scanner stdin = new Scanner(System.in)) {

            boolean myTurn = in.nextBoolean();
            char self = myTurn?'x':'o';
            char other = myTurn?'o':'x';

            boolean over = false;
            while (!over) {
                if(myTurn) {
                    int field;
                    while(true) {
                        System.out.print("> ");
                        field = stdin.nextInt();
                        out.println(field);
                        out.flush();
                        if(in.nextBoolean())
                            break;
                        else
                            System.out.println("Nevalidan potez");
                    }
                    board[field] = self;
                } else {
                    System.out.println("drugi igrac je na redu");
                    int field;
                    field = in.nextInt();
                    board[field] = other;
                }
                printBoard();
                myTurn = !myTurn;
                over = in.nextBoolean();
            }
            System.out.println("Igra je gotova");
            System.out.println("Pobednik je " + (myTurn?other:self));

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    XOClient() {
        board = new char[9];
        Arrays.fill(board, '-');
    }

    void printBoard() {
        for(int i = 0; i < board.length; i++) {
            if(i % 3 == 0) {
                System.out.println();
            }
            System.out.print(board[i] + " ");
        }
        System.out.println();
    }

}

package task2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

class XOServerClientHandler extends Thread {

    private Socket p1;
    private Socket p2;
    private char[] board;

    public XOServerClientHandler(Socket p1, Socket p2) {
        this.p1 = p1;
        this.p2 = p2;
        board = new char[9];
        Arrays.fill(board, '-');
    }

    @Override
    public void run() {
        try (Scanner in1 = new Scanner(p1.getInputStream());
             Scanner in2 = new Scanner(p2.getInputStream());
             PrintWriter out1 = new PrintWriter(p1.getOutputStream());
             PrintWriter out2 = new PrintWriter(p2.getOutputStream());
        ) {
            int turn = 0;

            // ko je na redu
            out1.println(true);
            out1.flush();
            out2.println(false);
            out2.flush();

            while (true) {
                if(turn == 0) {
                    int field;
                    while (true) {
                        field = in1.nextInt();
                        if (isValid(board, field)) {
                            out1.println(true);
                            out1.flush();
                            break;
                        } else {
                            out1.println(false);
                            out1.flush();
                        }
                    }
                    board[field] = 'x';
                    out2.println(field);
                    out2.flush();

                } else {
                    int field;
                    while (true) {
                        field = in2.nextInt();
                        if (isValid(board, field)) {
                            out2.println(true);
                            out2.flush();
                            break;
                        } else {
                            out2.println(false);
                            out2.flush();
                        }
                    }
                    board[field] = 'o';
                    out1.println(field);
                    out1.flush();
                }
                if(gameOver(board)) {
                    out1.println(true);
                    out1.flush();
                    out2.println(true);
                    out2.flush();
                    p1.close();
                    p2.close();
                    break;
                } else {
                    out1.println(false);
                    out1.flush();
                    out2.println(false);
                    out2.flush();
                }
                turn = (turn+1)%2;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    static boolean gameOver(char[] board) {
        for(int i = 0; i < 3; i++) {
            if(board[3*i+0]!='-' && board[3*i+0] == board[3*i+1] && board[3*i+1] == board[3*i+2])
                return true;
            if(board[i]!='-' && board[i] == board[i+3] && board[i+3] == board[i+6])
                return true;
        }
        return false;
    }

    static boolean isValid(char[] board, int field) {
        return (field >= 0 && field < 9 && board[field] == '-');
    }

}

package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());
        Task1Main main = new Task1Main();
        main.process();
    }

    private void process() {
        try {
            Scanner userIn = new Scanner(System.in);
            String w = userIn.next();
            userIn.close();

            for(Path p : Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"))) {
                new SongParser(this, p.toString(), w).start();
            }
        } catch (IOException e) {
            System.err.println("Problem sa citanjem direktorijuma");
            e.printStackTrace();
        }
    }

    public synchronized void printResults(String results) {
        System.out.println(results);
    }

}

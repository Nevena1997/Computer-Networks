package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {

    DatagramSocket client;

    private static final int PORT = 31416;
    private static final String HOST = "localhost";

    public UDPClient() throws SocketException {
        client = new DatagramSocket();
    }

    public void start(){

        try(Scanner sc = new Scanner(System.in)){
            System.out.println("Unesite poluprecnik kruga:");
            String num = sc.next();

            System.out.println("Saljem broj serveru!");
            byte[] toSend = num.getBytes();

            DatagramPacket toServer = new DatagramPacket(toSend, toSend.length, InetAddress.getByName(HOST), PORT);

            client.send(toServer);

            System.out.println("Paket poslat!");

            DatagramPacket fromServer = new DatagramPacket(new byte[8], 8);
            client.receive(fromServer);

            try{
                String res = new String(fromServer.getData());

                Double area = Double.parseDouble(res);
                System.out.println("Povrsina kruga je: " + area);
            }catch (NumberFormatException e){
                System.out.println("Neispravan poluprecnik!");
            }
        } catch (IOException e) {
            client.close();
            e.printStackTrace();
        }

    }



    public static void main(String[] args) {

        try {
            UDPClient client = new UDPClient();
            client.start();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

}

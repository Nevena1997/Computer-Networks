package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

class XOServer {

    private static final int PORT = 12346;

    private ServerSocket server;
    private int onMove = 1;
    private int playerWin = 3;

    private XOServer() throws IOException {
        server = new ServerSocket(PORT);
    }

    private void mainloop(){

        System.out.println("Server krece sa radom!");

        ArrayList<String> table = new ArrayList<>(9);
        for(int i = 0; i < 9; i++){
            table.add(i, new String("-"));
        }

        while (true){

            try(Socket client1 = server.accept();
                Socket client2 = server.accept();
                PrintWriter client1Out = new PrintWriter(new OutputStreamWriter(new BufferedOutputStream(client1.getOutputStream())), true);
                BufferedReader client1In = new BufferedReader(new InputStreamReader(new BufferedInputStream(client1.getInputStream())));
                PrintWriter client2Out = new PrintWriter(new OutputStreamWriter(new BufferedOutputStream(client2.getOutputStream())), true);
                BufferedReader client2In = new BufferedReader(new InputStreamReader(new BufferedInputStream(client2.getInputStream())));
            ) {
                System.out.println("Pocinje igra!");

                boolean shouldBreak = false;

                while (!shouldBreak){


                    if(onMove == 1){
                        String cl1In = client1In.readLine().trim();

                        int pos = Integer.parseInt(cl1In);

                        System.out.println(pos);

                        if(pos < 0 || pos > 8 || !table.get(pos).equalsIgnoreCase("-")){
                            String res1;
                            res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                            String res2;
                            res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                            String res3;
                            res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                            System.out.println("Potez igraca 2:");
                            System.out.println(res1 + "\n" + res2 + "\n" + res3);

                            client1Out.println(res1);
                            client1Out.println(res2);
                            client1Out.println(res3);
                            client1Out.println("Nevalidan potez");
                            continue;
                        }

                        table.add(pos, new String("X"));

                        String res1;
                        res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                        String res2;
                        res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                        String res3;
                        res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                        System.out.println("Potez igraca 1:");
                        System.out.println(res1 + "\n" + res2 + "\n" + res3);

                        client1Out.println(res1);
                        client1Out.println(res2);
                        client1Out.println(res3);

                        shouldBreak = endOfTheGame(table);
                        if(shouldBreak){
                            client1Out.println("kraj");
                            playerWin = 1;
                        }
                        else
                            client1Out.println("nesto");

                        onMove = 2;

                    }else{
                        String cl2In = client2In.readLine().trim();

                        int pos = Integer.parseInt(cl2In);

                        if(pos < 1 || pos > 8 || !table.get(pos).equalsIgnoreCase("-")){
                            String res1;
                            res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                            String res2;
                            res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                            String res3;
                            res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                            System.out.println("Potez igraca 2:");
                            System.out.println(res1 + "\n" + res2 + "\n" + res3);

                            client2Out.println(res1);
                            client2Out.println(res2);
                            client2Out.println(res3);
                            client2Out.println("Nevalidan potez");
                            continue;
                        }

                        table.add(pos, new String("Y"));

                        String res1;
                        res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                        String res2;
                        res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                        String res3;
                        res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                        System.out.println("Potez igraca 2:");
                        System.out.println(res1 + "\n" + res2 + "\n" + res3);

                        client2Out.println(res1);
                        client2Out.println(res2);
                        client2Out.println(res3);

                        shouldBreak = endOfTheGame(table);

                        if(shouldBreak){
                            if(playerWin != 1)
                                playerWin = 2;
                            client2Out.println("kraj");
                        }
                        else
                            client2Out.println("nesto");

                        onMove = 1;
                    }
                }

                if(playerWin == 1){
                    String res1;
                    res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                    String res2;
                    res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                    String res3;
                    res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                    System.out.println("Potez igraca 2:");
                    System.out.println(res1 + "\n" + res2 + "\n" + res3);

                    client2Out.println(res1);
                    client2Out.println(res2);
                    client2Out.println(res3);
                    client2Out.println("kraj");
                }else{
                    String res1;
                    res1 = table.get(0) + " " + table.get(1) + " " + table.get(2);
                    String res2;
                    res2 = table.get(3) + " " + table.get(4) + " " + table.get(5);
                    String res3;
                    res3 = table.get(6) + " " + table.get(7) + " " + table.get(8);

                    System.out.println("Potez igraca 1:");
                    System.out.println(res1 + "\n" + res2 + "\n" + res3);

                    client1Out.println(res1);
                    client1Out.println(res2);
                    client1Out.println(res3);
                    client1Out.println("kraj");
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    private boolean endOfTheGame(ArrayList<String> table) {

        // Najgori metod ikada napisan, al nema se vremena

        if((table.get(0).equalsIgnoreCase(table.get(1))) && (table.get(0).equalsIgnoreCase(table.get(2))) && !table.get(0).equalsIgnoreCase("-") && !table.get(1).equalsIgnoreCase("-") && !table.get(2).equalsIgnoreCase("-"))
            return true;

        if((table.get(3).equalsIgnoreCase(table.get(4))) && (table.get(3).equalsIgnoreCase(table.get(5))) && !table.get(3).equalsIgnoreCase("-") && !table.get(4).equalsIgnoreCase("-") && !table.get(5).equalsIgnoreCase("-"))
            return true;

        if((table.get(6).equalsIgnoreCase(table.get(7))) && (table.get(6).equalsIgnoreCase(table.get(8))) && !table.get(6).equalsIgnoreCase("-") && !table.get(7).equalsIgnoreCase("-") && !table.get(8).equalsIgnoreCase("-"))
            return true;

        if((table.get(0).equalsIgnoreCase(table.get(3))) && (table.get(0).equalsIgnoreCase(table.get(6))) && !table.get(0).equalsIgnoreCase("-") && !table.get(3).equalsIgnoreCase("-") && !table.get(6).equalsIgnoreCase("-"))
            return true;

        if((table.get(1).equalsIgnoreCase(table.get(4))) && (table.get(1).equalsIgnoreCase(table.get(7))) && !table.get(1).equalsIgnoreCase("-") && !table.get(4).equalsIgnoreCase("-") && !table.get(7).equalsIgnoreCase("-"))
            return true;

        if((table.get(2).equalsIgnoreCase(table.get(5))) && (table.get(2).equalsIgnoreCase(table.get(8))) && !table.get(2).equalsIgnoreCase("-") && !table.get(5).equalsIgnoreCase("-") && !table.get(8).equalsIgnoreCase("-"))
            return true;

        if((table.get(0).equalsIgnoreCase(table.get(4))) && (table.get(0).equalsIgnoreCase(table.get(8))) && !table.get(0).equalsIgnoreCase("-") && !table.get(4).equalsIgnoreCase("-") && !table.get(8).equalsIgnoreCase("-"))
            return true;

        if((table.get(2).equalsIgnoreCase(table.get(4))) && (table.get(2).equalsIgnoreCase(table.get(6))) && !table.get(2).equalsIgnoreCase("-") && !table.get(4).equalsIgnoreCase("-") && !table.get(6).equalsIgnoreCase("-"))
            return true;

        return false;
    }

    public static void main(String[] args) {
        try {
            XOServer server = new XOServer();
            server.mainloop();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

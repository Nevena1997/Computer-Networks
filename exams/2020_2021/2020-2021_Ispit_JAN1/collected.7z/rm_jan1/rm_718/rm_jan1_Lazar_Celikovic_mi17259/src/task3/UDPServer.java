package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Map;

class UDPServer {

    DatagramSocket server;

    private static final int PORT = 31416;

    public UDPServer() throws SocketException {
        server = new DatagramSocket(PORT);
    }

    public void mainloop(){

        System.out.println("Server krece sa radom!");

        try{
            while(true){

                System.out.println("Server prima poluprecnik:");

                DatagramPacket fromClient = new DatagramPacket(new byte[8], 8);
                server.receive(fromClient);

                System.out.println("Poluprecnik primjen!");

                String res = new String(fromClient.getData());

                Double num = Double.parseDouble(res);

                if(num < 0){
                    byte[] arr = "Neispravan poluprecnik".getBytes();
                    DatagramPacket toClient = new DatagramPacket(arr, arr.length, fromClient.getAddress(), fromClient.getPort());
                    server.send(toClient);
                }else{
                    Double area = num*num*Math.PI;

                    byte[] arr = Double.toString(area).getBytes();

                    System.out.println("Server salje povrsinu!");

                    DatagramPacket toClient = new DatagramPacket(arr, 8, fromClient.getAddress(), fromClient.getPort());
                    server.send(toClient);
                    System.out.println("Povrsina poslata!");
                }
            }
        } catch (IOException e) {
            server.close();
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        try {
            UDPServer server = new UDPServer();
            server.mainloop();
        } catch (SocketException e) {
            e.printStackTrace();
        }

    }

}

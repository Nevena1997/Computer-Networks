package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {

    private static class SongHandler implements Runnable{

        Path path;
        String word;

        public SongHandler(Path path, String word) {
            this.path = path;
            this.word = word;
        }

        @Override
        public void run() {

            var out = new PrintWriter(new OutputStreamWriter(System.out), true);

            String title = path.toString();
            String title1 = title.substring(0, title.lastIndexOf("."));

            String title2 = title1.substring(title1.lastIndexOf("/")+1);
            int len = 0;
            int numWords = 0;
            String longestLine = null;

            try(Scanner sc = new Scanner(new File(path.toString()))){

                String line;

                while (sc.hasNextLine()){
                    line = sc.nextLine();

                    if(line.length() > len){
                        longestLine = line;
                        len = line.length();
                    }

                    String[] arr = line.split(" ");

                    for(String w : arr){
                        if(w.trim().equals(word))
                            numWords++;
                    }
                }

                String res = title2 + "\n"
                            + longestLine + "\n"
                            + numWords;

                out.println(res);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
    }

    public static void main(String[] args) {

        System.out.println("Hello from: " + Task1Main.class.getName());

        String path = "/home/ispit/Desktop/tests/pesme";

        try(Scanner sc = new Scanner(System.in)) {
            System.out.println("Unesite rec:");
            String word = sc.next();

            var dirs = Files.newDirectoryStream(Paths.get(path));

            for(Path p : dirs){
                new Thread(new SongHandler(p, word)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

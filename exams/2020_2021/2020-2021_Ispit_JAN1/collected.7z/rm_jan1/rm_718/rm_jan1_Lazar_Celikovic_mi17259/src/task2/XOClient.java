package task2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class XOClient {

    Socket client;

    private static final int PORT = 12346;
    private static final String HOST = "localhost";

    public XOClient() throws IOException {
        client = new Socket(HOST, PORT);
    }

    public void start(){

        try(Scanner sc = new Scanner(System.in);
            PrintWriter out = new PrintWriter(new OutputStreamWriter(new PrintStream(client.getOutputStream())), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(new BufferedInputStream(client.getInputStream())))){

            while (true){
                System.out.println("Unesite komandu:");
                String line = sc.nextLine();

                try{
                    String potez = line.trim();
                    int x = Integer.parseInt(potez);
                    out.println(potez);

                    String res1 = in.readLine();
                    String res2 = in.readLine();
                    String res3 = in.readLine();

                    String res4 = in.readLine();
                    if(res4 != null && res4.trim().equalsIgnoreCase("kraj")){
                        break;
                    }else if(res4.equalsIgnoreCase("Nevalidan potez"))
                        System.out.println("Nevalidan potez!");

                    System.out.println(res1 + "\n" + res2 + "\n" + res3);

                }catch (NumberFormatException e){
                    continue;
                }
            }

            client.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        try {
            XOClient client = new XOClient();
            client.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

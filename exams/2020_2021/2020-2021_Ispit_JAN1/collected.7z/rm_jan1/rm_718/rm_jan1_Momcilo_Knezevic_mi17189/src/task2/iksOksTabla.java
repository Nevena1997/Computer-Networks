package task2;

import java.lang.reflect.Array;
import java.util.*;

/*
1 2 3
4 5 6
7 8 9

 */


public class iksOksTabla {

    //private List<String> tabla = Collections.synchronizedList(new LinkedList<>());
    private String[] tabla = new String[9];
    private int naPotezu;
    private boolean gotovaIgraInd;

    public iksOksTabla()
    {
        Arrays.fill(tabla,"-");
        this.naPotezu = 1;
        this.gotovaIgraInd = false;
    }

    public String getTabla() {
        StringBuilder trenutnoStanje = new StringBuilder();

        int indexZaNoviRed = 0;
        for(String s : tabla)
        {
            indexZaNoviRed++;
            trenutnoStanje.append(s);
            trenutnoStanje.append(",");

            //if (indexZaNoviRed == 3 || indexZaNoviRed == 6 || indexZaNoviRed == 9)
            //    trenutnoStanje.append("\n");    // zbog ispisa
        }

        trenutnoStanje.append("\n");
        return trenutnoStanje.toString();
    }

    public void setTabla(String[] tabla) {
        this.tabla = tabla;
    }

    public int getNaPotezu() {
        return naPotezu;
    }

    public void setNaPotezu(int naPotezu) {
        this.naPotezu = naPotezu;
    }

    // pp da se igraju samo ispravni potezi // todo
    public void odigrajPotez(int redniBroj, int polje) {
        // System.out.println("Igrac " + redniBroj + " je odigrao  na " + polje);
        tabla[polje] = redniBroj == 1 ? "X" : "O";
    }

    public boolean gotovaIgra()
    {
        for(int i = 0; i < this.tabla.length ; i++)
        {
            if(!tabla[i].equalsIgnoreCase("-"))
            {
                this.gotovaIgraInd = false;
                return  false;
            }
        }

        return true;
    }


}

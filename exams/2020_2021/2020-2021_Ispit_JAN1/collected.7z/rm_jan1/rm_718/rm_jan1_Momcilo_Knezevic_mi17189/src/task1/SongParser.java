package task1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;
import java.nio.file.Path;

class SongParser implements Runnable {

    private final String keyword;
    private Path filePath;
    private String longestLine;
    private int keywordCounter;
    private int l;
    private FileInfoPrinter fp;

    public SongParser(String keyword, Path filePath, FileInfoPrinter fp) {
        this.keyword = keyword;
        this.filePath = filePath;
        this.keywordCounter = 0;
        this.longestLine = "";
        this.l = 0;             // duzina najduze linije na pocetku
        this.fp = fp;
    }

    @Override
    public void run() {

        // otvori fajl
        // nadji najduzu liniju
        // broj pojavljivanje keyworda
        try (
            BufferedReader in = new BufferedReader(
                    new FileReader(filePath.toString())
            )
        ){
            // linija po linija
            // linija split(" ")
            String line;
            while((line = in.readLine()) != null){

                if(line.length() > this.l)
                {
                    this.longestLine = line;
                    this.l = line.length();
                }

                String[] words = line.split(" ");
                for(int i = 0; i < words.length; i++)
                {
                    if(words[i].equalsIgnoreCase(keyword))
                        keywordCounter++;
                }
            }

            String filename = this.filePath.toString();

            // ispis u celini
            this.fp.printFileInfo(this.keywordCounter, this.longestLine, filename);

        } catch (FileNotFoundException e) {
            //e.printStackTrace();
            System.err.println("Fajl nije pronadjen!");
        } catch (IOException e) {
            System.err.println("Greska sa fajlom");
        }
    }
}

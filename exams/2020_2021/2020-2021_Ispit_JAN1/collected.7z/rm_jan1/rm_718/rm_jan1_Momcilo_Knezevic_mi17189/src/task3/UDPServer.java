package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

// TODO server se gasi posle jednog racunanja?
class UDPServer {
    static final int port = 31415;
    static final String hostname = "localhost";

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(port)){

            System.out.println("Server radi...");

            while(true) {
                // primanje poluprecnika
                byte[] buffer = new byte[16];
                DatagramPacket fromClient = new DatagramPacket(
                        buffer,
                        buffer.length
                );
                server.receive(fromClient);

                //-------------------------Racunanje povrsine i spremanje poruke za klijenta
                String strr = new String(
                        buffer,
                        0,
                        fromClient.getLength(),
                        StandardCharsets.UTF_8
                );
                Double r = Double.parseDouble(strr);

                byte[] bufferSend = new byte[32];
                String strp;
                if (r >= 0) {
                    Double p = r * r * Math.PI;
                    strp = Double.toString(p);
                    System.out.println("r = " + strr + " ===> P = " + strp);
                } else {
                    strp = "Neispravan poluprecnik.";
                    System.out.println("Neispravan poluprecnik.");
                }

                bufferSend = strp.getBytes();

                DatagramPacket toClient = new DatagramPacket(
                        bufferSend,
                        bufferSend.length,
                        fromClient.getAddress(),
                        fromClient.getPort()
                );
                //-------------------------

                server.send(toClient);

                System.out.println("------------------------");
            }

        } catch (SocketException e) {
            System.err.println("Problem sa konekcijom!");
        } catch (IOException e) {
            System.err.println("Problem sa komunikacijom!");
        }
    }
}

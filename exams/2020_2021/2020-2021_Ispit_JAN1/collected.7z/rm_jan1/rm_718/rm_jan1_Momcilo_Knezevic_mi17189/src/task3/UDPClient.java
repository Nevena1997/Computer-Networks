package task3;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    public static void main(String[] args) {

        // port 31415
        // klijent salje jednom jedan realan broj
        // negativan broj znaci neispravan unos
        // prima P od servera
        // ispis na stdout

        try(
                DatagramSocket client = new DatagramSocket();
                Scanner stdin = new Scanner(System.in);
        ) {
            System.out.println("----------------------------");
            System.out.print("Unesi poluprecnik: ");
            Double r = stdin.nextDouble();

            /*while(r < 0)
            {
                System.err.println("Neispravan unos. Unesite pozitivan broj!");
                System.out.print("Unesi poluprecnik: ");
                r = stdin.nextDouble();
            }*/

            // priprema poruke
            byte[] buffer = new byte[8];
            String strr = Double.toString(r);
            buffer = strr.getBytes();
            DatagramPacket toServer = new DatagramPacket(
                    buffer,
                    buffer.length,
                    InetAddress.getByName(UDPServer.hostname),
                    UDPServer.port
            );

            // slanje serveru
            client.send(toServer);

            //--------------------
            // Server uzima r
            // Racuna P
            // Vraca realan broj
            //--------------------

            byte[] bufferRec = new byte[32];
            DatagramPacket fromServer = new DatagramPacket(
                    bufferRec,
                    bufferRec.length
            );
            client.receive(fromServer);

            // Parsiranje i ispis poruke
            String p = new String(
                    bufferRec,
                    0,
                    fromServer.getLength()
            );

            if(p.equalsIgnoreCase("Neispravan poluprecnik."))
                System.out.println("Neispravan unos!");
            else {
                System.out.println("P = " + p);
                System.out.println("----------------------------");
            }

        } catch (SocketException | UnknownHostException e) {
            System.err.println("Problem sa konekcijom!");
            //e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Problem sa slanjem i primanjem paketa!");
        }
    }
}

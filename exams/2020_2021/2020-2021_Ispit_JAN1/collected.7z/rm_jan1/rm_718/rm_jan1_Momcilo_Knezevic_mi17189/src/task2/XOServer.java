package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;

class XOServer {

    static final int port = 12345;
    static final String hostname = "localhost";
    static int redniBroj = 1;                   // kada se ugasi nit, smanjuje se ova vrednost zbog sledece partije !!!

    public static void main(String[] args) {

        // prosledjujem niti za oba klijenta cim se konektuju
        iksOksTabla tabla = new iksOksTabla();
        List<XOServerClientHandler> igraci = new LinkedList<>();

        try {
            ServerSocket server = new ServerSocket(port);

            while (true)
            {
                if(redniBroj < 3) {
                    Socket client = server.accept();
                    XOServerClientHandler tmp = new XOServerClientHandler(redniBroj, tabla, client);
                    igraci.add(tmp);

                    if(redniBroj == 2)
                    {
                        for(XOServerClientHandler c : igraci)
                        {
                            new Thread(c).start();
                        }
                    }
                    redniBroj++;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

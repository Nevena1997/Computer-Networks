package task1;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        //System.out.println("Hello from: " + Task1Main.class.getName());

        // unesi rec
        // za svaki fajl u diru pesme pokrenuti nit
        // stdout za svaki fajl naziv pesme(ime fajla), najduzi stih(linija), pojavljivanje unete reci u tom fajlu(pesmi)
        // ispis da se ne preplice => sync klasa

        try(Scanner stdin = new Scanner(System.in)) {

            FileInfoPrinter fp = new FileInfoPrinter();

            String keyword;
            //System.out.println("Unesi rec koja se trazi u pesmi:");
            System.out.println("Ulaz:");
            keyword = stdin.next();

            System.out.println("Izlaz:");

            // prolazak kroz dir pesme i pravljenje niti za svaki fajl (rec,putanja do fajla, dodatna sync metoda u klasi  FilePrinter)
            DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"));
            for(Path p : ds)
            {
                new Thread(new SongParser(keyword, p, fp)).start();
            }

            ds.close();

        } catch (IOException e) {
            System.err.println("Direktorijum nije pronadjen!");   // ne radi dir
        }
    }
}

/*
Poslednja najduza <= ili <
PoslednjaPesma testprimer: ima 1xkao a pise 2
MozdaSpava: link na kraju?

 */

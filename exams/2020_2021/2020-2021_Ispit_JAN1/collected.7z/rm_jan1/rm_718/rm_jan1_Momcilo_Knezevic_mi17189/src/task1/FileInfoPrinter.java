package task1;

public class FileInfoPrinter {

    public synchronized void printFileInfo(int keywordCounter, String longestLine, String fileName)
    {
        int index = fileName.indexOf(".");  // za izbacivanje .txt
        int index1 = fileName.lastIndexOf("/");
        String onlyName = fileName.substring(index1+1,index);

        System.out.println(onlyName);
        System.out.println(longestLine);
        System.out.println(keywordCounter);
    }
}

package task2;

import java.io.*;
import java.net.Socket;

class XOServerClientHandler implements Runnable {

    private Socket client;
    private int redniBroj;
    private iksOksTabla tabla;

    public XOServerClientHandler(int redniBroj, iksOksTabla tabla, Socket client) {
        this.redniBroj = redniBroj;
        this.tabla = tabla;
        this.client = client;
    }

    @Override
    public void run() {

        try(
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                client.getInputStream()
                        )
                );
                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(
                                client.getOutputStream()
                        )
                );
                )
        {
            System.out.println("Igra pocinje za igraca " + this.redniBroj);
            while (true) {
                //System.out.println(this.tabla.getNaPotezu());
                if (this.redniBroj == this.tabla.getNaPotezu()) // && !tabla.gotovaIgra())   // saljem mu tablu i >, to znaci da on igra
                {
                    // trenutno stanje
                    String trenutnaTabla = this.tabla.getTabla();
                    String msg = trenutnaTabla;
                    System.out.println(trenutnaTabla);

                    out.write(trenutnaTabla);
                    out.newLine();
                    out.flush();

                    // cekam potez od klijenta
                    String potez = in.readLine();
                    System.out.println("Igrac " + this.redniBroj + " je poslao potez: " + potez);
                    int polje = Integer.parseInt(potez);

                    while(polje < 0 || polje > 9)
                    {
                        String errorMsg = "Nevalidan potez";
                        out.write(errorMsg);
                        out.newLine();
                        out.flush();

                        potez = in.readLine();
                        polje = Integer.parseInt(potez);
                    }


                    // realizujem potez
                    this.tabla.odigrajPotez(this.redniBroj, polje);

                    // menjam potez na drugog igraca
                    if(this.redniBroj == 1) {
                        this.tabla.setNaPotezu(2);
                        System.out.println("Igrac 2 je na potezu");
                    }
                    else {
                        this.tabla.setNaPotezu(1);
                    }
                } else {
                    continue;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

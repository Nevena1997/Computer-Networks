package task2;


import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {

    public static void main(String[] args) {

        try(Scanner sc = new Scanner(System.in)) {
            System.out.println("Klijent konektovan...");
            Socket client = new Socket(XOServer.hostname, XOServer.port);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            );
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream()
                    )
            );

            while(true) {

                // ceka na trenutno stanje table
                String trenutnoStanje = in.readLine();
                System.out.println("Primljena poruka");
                ispisTrenutnogStanja(trenutnoStanje);

                // Server sad ceka ovog klijenta da odigra potez
                int potez = sc.nextInt();

                while (potez < 0 || potez > 9) {
                    // server salje error msg
                    String errorMsg = in.readLine();
                    System.out.println(errorMsg);
                    System.out.println("Odigraj ponovo: ");
                    potez = sc.nextInt();
                }

                // Klijent odigrao potez, saljem ga Serveru da azurira tablu
                out.write(Integer.toString(potez));
                out.newLine();
                out.flush();

            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void ispisTrenutnogStanja(String trenutnoStanje) {
        String[] polja = trenutnoStanje.split(",");

        for(int i = 1; i <= polja.length ; i++){
            System.out.print(polja[i-1]);
            if(i == 3 || i == 6 || i == 9)
            {
                System.out.println();
            }
        }
        System.out.println("> ");
    }
}
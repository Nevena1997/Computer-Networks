package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());


        try(DatagramSocket server = new DatagramSocket(31415)) {

        while(true){
            byte[] data = new byte[256];

            DatagramPacket fromClient = new DatagramPacket(data, data.length);
            try {
                server.receive(fromClient);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // System.out.println(new String(fromClient.getData(), 0, fromClient.getLength()));
            double r = Double.parseDouble(new String(fromClient.getData(), 0, fromClient.getLength()));
            //System.out.println(r);
            String response;
            if(r < 1)
                response = "Neispravan poluprecnik";
            else {
                double p = r * r *3.14;
                response = String.valueOf(p);
            }

            byte[] responseData = response.getBytes();
            DatagramPacket toClient = new DatagramPacket(responseData,responseData.length, fromClient.getAddress(), fromClient.getPort());
            try {
                server.send(toClient);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.Socket;
import java.util.List;

class XOServerClientHandler implements Runnable {
    private Socket client;
    private Tabela table;


    public XOServerClientHandler(Socket client, Tabela table) {
        this.client = client;
        this.table = table;

    }

    @Override
    public void run() {

    while(true){
        try {

            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Tabela nova = new Tabela(table.tableState());
            nova.printTable();
            List<String> stanje = table.tableState();
            out.write(stanje.toString());
            out.newLine();
            out.flush();
            int n;
            n = in.read();
            if(n<1 || n>9){
                out.write("Nevalidan potez");
                out.newLine();
                out.flush();
            }

            //System.out.println(n);
            table.updateTable(n, table.getNaRedu());
            table.changeNaRedu();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    }
}

package task2;

import javax.crypto.spec.PSource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.time.chrono.ThaiBuddhistChronology;

class XOServer {
    private static int clients = 0;
    private static boolean started = false;
    static private int naRedu = 1;
    static private Socket s1;
    static private Socket s2;


    
    public static void main(String[] args) {

        System.out.println("Hello from: " + XOServer.class.getName());

        Tabela table = new Tabela();

        try(ServerSocket server = new ServerSocket(12345)){

            while(true){
                Socket client = server.accept();
                new Thread(new XOServerClientHandler(client, table)).start();
                clients++;
                if (clients == 2) {
                    System.out.println("Game has started");
                    break;
                }
                }


                } catch (IOException e) {
            e.printStackTrace();
        }


}
}

package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + Task1Main.class.getName());
        String word;

        MyPrint printer = new MyPrint();

        try(Scanner in = new Scanner(System.in)) {

            DirectoryStream<Path> ds1 = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"));
            DirectoryStream<Path> ds2 = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/pesme"));

            String song;

            System.out.println("Spisak datoteka: ");
            for(Path p : ds1){
                printer.print(p.toString());
            }
            System.out.println();
            System.out.println("Unesite rec: ");
            word = in.next();
            for(Path p : ds2){
                new Thread(new songThreadRunnable(p, word, printer)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

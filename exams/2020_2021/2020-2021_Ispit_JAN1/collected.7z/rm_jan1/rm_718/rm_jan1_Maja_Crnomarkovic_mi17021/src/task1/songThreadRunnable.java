package task1;

import java.io.*;
import java.nio.file.Path;

public class songThreadRunnable implements Runnable {
    private Path p;
    private int maxLength = -1;
    private String maxLine;
    private MyPrint printer;
    int wordCounter = 0;
    private String word;
    public songThreadRunnable(Path p, String word, MyPrint printer) {
        this.p = p;
        this.word = word;
        this.printer = printer;
    }

    @Override
    public void run() {

        try {
            String line;
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toFile())));

            try {
                line = in.readLine();
                maxLine = line;
                maxLength = line.length();
                for(String s : line.split(" ")){

                    if(s.contains(word)){
                        wordCounter++;
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            while((line = in.readLine()) != null){
                for(String s : line.split(" ")) {
                    if(s.contains(".") || s.contains(",") || s.contains(":") || s.contains(";") || s.contains("!")){
                        s = s.substring(0, s.length()-1);
                    }

                    if (s.contains(word))
                        wordCounter++;
                }
                if(line.length() > maxLength){
                    maxLine = line;
                    maxLength = line.length();
                }
            }
            String name = p.getFileName().toString();
            int ext = name.indexOf(".");

            printer.print(name.substring(0, ext));
            printer.print(maxLine);
            printer.print(String.valueOf(wordCounter));


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

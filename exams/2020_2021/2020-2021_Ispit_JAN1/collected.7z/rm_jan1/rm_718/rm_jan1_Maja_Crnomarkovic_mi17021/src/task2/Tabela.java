package task2;

import java.util.LinkedList;
import java.util.List;

public class Tabela {

    static private List<String> tabela = new LinkedList<>();
    private int naRedu = 1;

    public Tabela() {
        for(int i = 0; i <9; i++)
            tabela.add("-");
    }
    public Tabela(List<String> t){
        this.tabela = t;

    }

    public synchronized void updateTable(int value, int igrac){
        if(igrac == 1) {
            tabela.set(value-1, "X");
        }
        if(igrac == 2) {
            tabela.set(value-1, "O");
        }
    }

    public synchronized List<String> tableState(){
        return tabela;
    }

    public synchronized void printTable() {
        for (int i = 0; i < 6; i += 2) {
            System.out.printf("%s %s %s", tabela.get(i), tabela.get(i + 1), tabela.get(i + 2));
            System.out.println();
        }
    }

    public synchronized void changeNaRedu(){
        if(naRedu == 1)
            naRedu = 2;
        else if(naRedu == 2)
            naRedu = 1;

    }
    public synchronized int getNaRedu(){
        return naRedu;
    }
//todo
    public synchronized boolean shouldEnd(){
        if(tabela.get(0) == tabela.get(1) && tabela.get(1) == tabela.get(2) && !tabela.get(0).equalsIgnoreCase("-"))
            return true;
        return false;
    }
}

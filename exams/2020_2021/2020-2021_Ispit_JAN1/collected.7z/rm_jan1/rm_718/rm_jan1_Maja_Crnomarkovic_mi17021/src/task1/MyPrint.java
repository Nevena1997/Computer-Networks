package task1;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MyPrint {

    private PrintWriter p = new PrintWriter(new OutputStreamWriter(System.out));

    public synchronized void print(String s){
        p.write(s);
        p.write("\n");
        p.flush();
    }
}

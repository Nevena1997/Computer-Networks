package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

class XOClient {

    static private List<String> tabela = new LinkedList<>();

    public static void main(String[] args) {

        initializeTable();

        try(Socket client = new Socket("localhost", 12345);
            Scanner in = new Scanner(System.in);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){

            while(true) {
                String line = fromServer.readLine();
                if(line.equalsIgnoreCase("end"))
                    break;
                line = line.substring(1,line.length()-1);
                String[] linija = line.split(",");

                for (int i = 0; i < linija.length; i++){
                    tabela.set(i, linija[i].trim());
                }

                printTableState();
                loadAndSendMove(toServer, in);


            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadAndSendMove(BufferedWriter toServer, Scanner in) {
        int potez;
        potez = in.nextInt();
        try {
            toServer.write(potez);
            toServer.newLine();
            toServer.flush();
            System.out.println("poslat");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printTableState() {
        for(int i = 0; i<6; i+=2){
            System.out.printf("%s %s %s", tabela.get(i), tabela.get(i+1), tabela.get(i+2));
            System.out.println();

        }
    }

    private static void initializeTable() {
        for(int i = 0; i <9; i++)
            tabela.add("-");
    }

}

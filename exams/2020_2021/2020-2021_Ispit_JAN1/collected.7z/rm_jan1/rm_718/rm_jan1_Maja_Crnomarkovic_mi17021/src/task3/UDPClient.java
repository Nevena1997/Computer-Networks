package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPClient.class.getName());

        String num;

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            InetAddress host;
            num = sc.next();
            byte[] number = num.getBytes();

            DatagramPacket toServer = new DatagramPacket(number, number.length, InetAddress.getByName("localhost"), 31415);
            try {
                client.send(toServer);
            } catch (IOException e) {
                e.printStackTrace();
            }
            byte[] data = new byte[256];

            DatagramPacket fromServer = new DatagramPacket(data, data.length);
            try {
                client.receive(fromServer);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String received = new String(fromServer.getData(), 0, fromServer.getLength());
            System.out.println("Povrsina je: " + received);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        }
    }

}

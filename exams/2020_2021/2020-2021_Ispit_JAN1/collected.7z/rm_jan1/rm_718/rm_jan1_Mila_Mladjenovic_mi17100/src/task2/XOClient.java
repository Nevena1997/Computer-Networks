package task2;

import java.io.*;
import java.net.Socket;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class XOClient {

    public static void main(String[] args) {
        String host="localhost";
        int port=12345;

        try(Socket socket=new Socket();
        Scanner sc=new Scanner(System.in)){

            BufferedReader in=new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );
            BufferedWriter out=new BufferedWriter(
                    new OutputStreamWriter(
                            socket.getOutputStream()
                    )
            );
            while(true){
                String line;

                line=in.readLine();
                String line2=line.substring(9,11);
                if(line2.equals("-X-") || line2.equals("-O-")){
                    System.out.println(line2);
                    System.exit(0);
                }

                int potez=sc.nextInt();
                out.write(potez);
                out.newLine();
                out.flush();
            }

            } catch (IOException ex) {
            ex.printStackTrace();
        }

    }


}

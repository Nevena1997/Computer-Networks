package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPServer {

    public static void main(String[] args) {
        int port = 31415;

        try (DatagramSocket ds = new DatagramSocket(port)) {
            DatagramPacket recv = new DatagramPacket(new byte[256], 256);
            ds.receive(recv);

            String line = new String(recv.getData());
            Double broj=Double.parseDouble(line);
            byte[] odgovor;
            if(broj<0){
                odgovor="Neispravan poluprecnik".getBytes();
            }
            else {
                Double povrsina=broj*broj*3.14;
                odgovor=povrsina.toString().getBytes();
            }
            DatagramPacket send = new DatagramPacket(odgovor,odgovor.length,
                    recv.getAddress(), recv.getPort());
            ds.send(send);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
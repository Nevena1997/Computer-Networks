package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
//zatvori i izuzeci
    public static void main(String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        String rec=sc.nextLine();

        Path p= Paths.get("/home/ispit/Desktop/tests/pesme");
        DirectoryStream<Path> ds= Files.newDirectoryStream(p);
        for(Path path:ds){
            new Thread(new SongParser(path, rec)).start();
        }

    }


}

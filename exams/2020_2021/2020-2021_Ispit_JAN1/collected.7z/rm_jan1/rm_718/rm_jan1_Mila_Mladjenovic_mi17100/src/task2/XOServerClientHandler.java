package task2;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

class XOServerClientHandler implements Runnable{
    private Tabela tabela;
    private Socket client;
    String znak;

    public XOServerClientHandler(Tabela tabela, Socket client, String zank) {
        this.tabela = tabela;
        this.client = client;
        this.znak=zank;
    }

    @Override
    public void run() {

            try(BufferedWriter out=new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream()
                    )
            );
                BufferedReader in=new BufferedReader(
                        new InputStreamReader(
                                client.getInputStream()
                        )
                )) {
                while(true){
                    //proveravamo pobedu
                    String line2 = null;
                    int i=tabela.pobeda();
                    if(i!=0){
                        if(i==1){
                            line2="-X-";
                        }
                        else if(i==2){
                            line2="-O-";
                        }

                    }else{
                        line2="";
                    }

                    out.write(tabela.stampajTabelu());
                    out.newLine();
                    out.flush();

                    out.write(line2);
                    out.newLine();
                    out.flush();


                    //cekamo potez
                    while(true){
                    String line=in.readLine();
                    Integer potez=Integer.parseInt(line);
                    if(potez<=0 || potez>9){
                        out.write("Nevalidan potez");
                        out.newLine();
                        out.flush();
                    }else{
                        synchronized (tabela){
                        tabela.azurirajTabelu(potez, znak);}
                        break;
                        }
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
            }

    }
}

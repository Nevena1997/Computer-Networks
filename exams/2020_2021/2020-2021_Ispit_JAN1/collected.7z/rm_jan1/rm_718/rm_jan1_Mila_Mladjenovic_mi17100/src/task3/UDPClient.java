package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        int port=31415;
        String host="localhost";
        try(DatagramSocket ds=new DatagramSocket()){
            Scanner sc=new Scanner(System.in);
            Double broj=sc.nextDouble();
            byte[] buffer=broj.toString().getBytes();
            DatagramPacket send=new DatagramPacket(buffer, buffer.length, InetAddress.getByName(host), port);
            ds.send(send);

            DatagramPacket recv=new DatagramPacket(buffer, buffer.length);
            ds.receive(recv);

            String line=new String(recv.getData());
            System.out.println(line);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

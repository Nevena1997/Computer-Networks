package task2;

import java.util.ArrayList;
import java.util.List;

public class Tabela {
    private List<String> t1 = new ArrayList<String>(3);
    private List<String> t2 = new ArrayList<String>(3);
    private List<String> t3 = new ArrayList<String>(3);

    public Tabela() {
        t1.add("-");t1.add("-");t1.add("-");
        t2.add("-");t2.add("-");t2.add("-");
        t3.add("-");t3.add("-");t3.add("-");
    }
    public String stampajTabelu() {

        return stampaj(t1) + "\n" + stampaj(t2) + "\n" + stampaj(t3);
    }

    private String stampaj(List<String> t) {
        return t.get(0) +" "+t.get(1)+" "+ t.get(2);
    }

    public void azurirajTabelu(int potez, String znak) {
        if(potez>=1 && potez<=3){
            if(!t1.get(potez-1).equalsIgnoreCase("-")){
            }else
            t1.set(potez-1, znak);
        }else if(potez>=4 && potez<=6){
            if(!t2.get(potez-4).equalsIgnoreCase("-")){
            }else
            t2.set(potez-4, znak);
        }else if(potez>=7 && potez<=9){
            if(!t3.get(potez-7).equalsIgnoreCase("-")){
            }else
            t3.set(potez-7, znak);
        }else{
            System.out.println("Nepravilan potez!");
            System.exit(1);
        }
    }
    public int pobeda(){
        if(t1.get(0)==t2.get(1) && t2.get(1)==t3.get(2) && !t1.get(0).equalsIgnoreCase("-")){
            if(t1.get(0).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(0).equalsIgnoreCase("o")){
                return 2;
            }
        }
        else if(t1.get(2)==t2.get(1) && t2.get(1)==t3.get(0) && !t1.get(2).equalsIgnoreCase("-")){
            if(t1.get(2).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(2).equalsIgnoreCase("o")){
                return 2;
            }
        }
        else if(t1.get(0)==t2.get(0) && t2.get(0)==t3.get(0) && !t1.get(0).equalsIgnoreCase("-")){
            if(t1.get(0).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(0).equalsIgnoreCase("o")){
                return 2;
            }
        }
        else if(t1.get(1)==t2.get(1) && t2.get(1)==t3.get(1) && !t1.get(1).equalsIgnoreCase("-")){
            if(t1.get(1).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(1).equalsIgnoreCase("o")){
                return 2;
            }
        }else if(t1.get(2)==t2.get(2) && t2.get(2)==t3.get(2) && !t1.get(2).equalsIgnoreCase("-")){
            if(t1.get(2).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(2).equalsIgnoreCase("o")){
                return 2;
            }
        }else if(t1.get(0)==t1.get(1) && t1.get(1)==t1.get(2) && !t1.get(0).equalsIgnoreCase("-")){
            if(t1.get(0).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t1.get(0).equalsIgnoreCase("o")){
                return 2;
            }
        }else if(t2.get(0)==t2.get(1) && t2.get(1)==t2.get(2) && !t2.get(0).equalsIgnoreCase("-")){
            if(t2.get(0).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t2.get(0).equalsIgnoreCase("o")){
                return 2;
            }
        }
        else if(t3.get(0)==t3.get(1) && t3.get(1)==t3.get(2) && !t3.get(0).equalsIgnoreCase("-")){
            if(t3.get(0).equalsIgnoreCase("x")){
                return 1;
            }
            else if(t3.get(0).equalsIgnoreCase("o")){
                return 2;
            }
        }
        return 0;
    }
}

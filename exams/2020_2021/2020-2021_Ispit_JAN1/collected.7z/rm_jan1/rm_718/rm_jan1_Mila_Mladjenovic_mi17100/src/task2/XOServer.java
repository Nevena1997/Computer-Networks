package task2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

class XOServer {

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(12345)) {
            while (true) {
                Socket client1 = server.accept();
                Socket client2 = server.accept();
                System.out.println("pocinje nova igra!");
                Tabela tabela = new Tabela();
                Thread t1=new Thread(new XOServerClientHandler(tabela, client1,"x"));
                Thread t2=new Thread(new XOServerClientHandler(tabela, client2, "o"));
                t1.start();
                t2.start();
                t1.join();
                t2.join();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }
}

package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class SongParser implements Runnable {
    private Path path;
    private String rec;

    public SongParser(Path path, String rec) {
        this.path = path;
        this.rec=rec;
    }

    @Override
    public void run() {
        synchronized (System.out) {
            if (Files.exists(path)) {

                try (BufferedReader file = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(String.valueOf(path))))) {
                    String line;
                    int pojavljivanjeReci = 0;
                    String maxString = null;
                    int maxLength = 0;

                    while ((line = file.readLine()) != null) {
                        if (line.length() > maxLength) {
                            maxLength = line.length();
                            maxString = line;
                        }

                        String[] words = line.split(" ");
                        for (String word : words) {
                            if (word.equalsIgnoreCase(rec) || word.contains(rec)) {
                                pojavljivanjeReci++;
                            }
                        }
                    }

                    int duzinaPutanje = String.valueOf(path).length();
                    int posledjaCrtica = String.valueOf(path).lastIndexOf('/');
                    String nazivPesme = String.valueOf(path).substring(posledjaCrtica+1, duzinaPutanje - 4);

                    System.out.println(nazivPesme);
                    System.out.println(maxString);
                    System.out.println(pojavljivanjeReci);
                    file.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.printf("Datoteka ne postoji!");
                System.exit(1);
            }
        }
    }
}

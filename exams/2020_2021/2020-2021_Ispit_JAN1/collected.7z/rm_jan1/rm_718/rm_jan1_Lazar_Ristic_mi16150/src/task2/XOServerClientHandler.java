package task2;

import java.net.Socket;
import java.util.List;


class XOServerClientHandler extends Thread{

    private List<Socket> players;
    private int[] stanje;
    private int id=1;

    public XOServerClientHandler(List<Socket> players, int[] stanje){
        this.players = players;
        this.stanje = stanje;
    }

    @Override
    public void run() {

        for(Socket player: players){
            new PlayerThread(id++, player, stanje).start();
        }

    }
}

package task1;

import java.io.*;

class SongParser extends Thread{
    private File file;
    private String rec;
    private int broj_pojavljivanja;

    public SongParser(File file, String rec){
        this.file = file;
        this.rec = rec;
        this.broj_pojavljivanja = 0;
    }


    @Override
    public void run() {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(this.file.getAbsolutePath())));) {
            System.out.println(this.file.getName());

            String linija;

            String najduza_linija = "";
            while((linija = br.readLine()) != null){
                if(linija.length() > najduza_linija.length()){
                    najduza_linija = linija;
                }

                String[] reci_u_liniji = linija.split(" ");
                for(String r: reci_u_liniji){
                    System.out.println(r);
                    if(r.contains(rec)){
                        broj_pojavljivanja++;
                    }
                }
            }
            System.out.println(this.file.getName() + ": " + najduza_linija);
            System.out.println(this.file.getName() + ": " + this.broj_pojavljivanja);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

class XOServer {

    public static int PORT = 12345;
    public static int playersLive = 0;
    public static int id = 1;
    public static List<Socket> players = new ArrayList<>();
    public static int na_potezu = 1;
    public static int[] stanje = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(PORT);){


            while(true){
                Socket client = server.accept();
                playersLive++;
                players.add(client);

                if(playersLive == 2){
                    System.out.println("Igraci spremni!");

                    new XOServerClientHandler(players, stanje).start();
                }else{
                    System.out.println("Cekaju se 2 igraca...");
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class PlayerThread extends Thread{

    private Socket player;
    private int id;
    private int[] stanje;

    public PlayerThread(int id, Socket player, int[] stanje){
        this.id = id;
        this.player = player;
        this.stanje = stanje;
    }


    @Override
    public void run() {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(player.getInputStream()));
            PrintWriter out = new PrintWriter(player.getOutputStream(), true)) {
            String poruka;
            out.println(this.stanjeUString(this.stanje));
            while((poruka = br.readLine()) != null){
                if(gotovaIgra(this.stanje) != 1){
                    if(Integer.parseInt(poruka.trim()) >= 0 && Integer.parseInt(poruka.trim()) < 9){
                        promeniStanje(this.stanje, Integer.parseInt(poruka.trim()));

                    }else{
                        out.println("Neispravan potez");
                    }

                    out.println(this.stanjeUString(this.stanje));
                }else{
                    out.println("Gotova igra");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int gotovaIgra(int[] stanje){
        for(int i: stanje){

            if(i == 0)
                return -1;
        }

        return 1;
    }

    public int[] promeniStanje(int[] stanje, int mesto){

        if(id == 1){
            if(stanje[mesto] == 0)
                stanje[mesto] = 1;
        }else{
            if(stanje[mesto] == 0)
                stanje[mesto] = 2;
        }

        return stanje;
    }

    public String stanjeUString(int[] stanje){
        String rez = "";

        for(int i = 0; i < stanje.length;i++){
            if(stanje[i] == 0){
                if(i == 2 || i == 5){
                    rez += "_\n";
                }else{
                    rez +=  "_ ";
                }
            }else if(stanje[i] == 1){
                if(i == 2 || i == 5){
                    rez += "X\n";
                }else{
                    rez += "X ";
                }
            }else{
                if(i == 2 || i == 5){
                    rez += "O\n";
                }else{
                    rez += "O ";
                }
            }
        }
        return rez;
    }

}

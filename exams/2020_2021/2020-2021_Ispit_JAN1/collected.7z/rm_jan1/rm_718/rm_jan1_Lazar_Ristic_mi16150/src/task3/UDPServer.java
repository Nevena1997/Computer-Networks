package task3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

class UDPServer {

    public static int PORT = 31415;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT);) {

            while(true){
                byte[] niz_za_primanje = new byte[4];
                DatagramPacket paket_za_primanje =
                        new DatagramPacket(
                                niz_za_primanje,
                                niz_za_primanje.length
                        );

                server.receive(paket_za_primanje);

                String odKlijenta = new String(niz_za_primanje);

                float broj = Float.parseFloat(odKlijenta.trim());

                byte[] niz_za_slanje = new byte[32];

                if(broj < 0){
                    niz_za_slanje = "Neispravan poluprecnik".getBytes();

                    DatagramPacket paket_za_slanje =
                            new DatagramPacket(
                                    niz_za_slanje,
                                    niz_za_slanje.length,
                                    paket_za_primanje.getAddress(),
                                    paket_za_primanje.getPort());

                    server.send(paket_za_slanje);
                }else{

                    float rez = (float) (broj*broj*Math.PI);

                    niz_za_slanje = String.valueOf(rez).getBytes();
                    DatagramPacket paket_za_slanje =
                            new DatagramPacket(
                                    niz_za_slanje,
                                    niz_za_slanje.length,
                                    paket_za_primanje.getAddress(),
                                    paket_za_primanje.getPort());

                    server.send(paket_za_slanje);
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

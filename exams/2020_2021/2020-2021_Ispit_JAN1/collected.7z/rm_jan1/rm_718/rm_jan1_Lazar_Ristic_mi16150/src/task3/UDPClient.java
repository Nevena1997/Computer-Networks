package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            while(true){
                int broj = sc.nextInt();

                byte[] niz_za_slanje = new byte[4];
                niz_za_slanje = String.valueOf(broj).getBytes();

                DatagramPacket paket_za_slanje =
                        new DatagramPacket(
                                niz_za_slanje,
                                niz_za_slanje.length,
                                new InetSocketAddress("localhost", 31415)
                        );

                client.send(paket_za_slanje);

                byte[] niz_za_primanje = new byte[32];
                DatagramPacket paket_za_primanje =
                        new DatagramPacket(
                                niz_za_primanje,
                                niz_za_primanje.length
                        );

                client.receive(paket_za_primanje);

                String odServera = new String(niz_za_primanje, 0, niz_za_primanje.length);

                System.out.println(odServera.trim());
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.*;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String rec = sc.nextLine();

        String putanja = System.getProperty("user.home") + "/Desktop/tests/pesme/";

        File file = new File(putanja);
        File[] fajlovi = file.listFiles();

        for(File f: fajlovi){
            new SongParser(f, rec).start();
        }


    }

}

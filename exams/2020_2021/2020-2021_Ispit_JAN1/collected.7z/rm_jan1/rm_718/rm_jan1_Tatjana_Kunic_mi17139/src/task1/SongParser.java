package task1;

import java.io.*;
import java.nio.file.Path;
import java.util.Scanner;

class SongParser extends Thread{

    private String keyword;
    private int keywordCounter = 0;
    private String maxLine = "";
    private String title;
    private BufferedReader in;

    public SongParser(Path songPath, String keyword) {
        this.keyword = keyword;
        String fName = String.valueOf(songPath.getFileName());
        int idx = fName.lastIndexOf(".");
        this.title = fName.substring(0, idx);
        try {
            this.in = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(songPath))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }


    @Override
    public void run() {
        try {
            String line;
            while((line = this.in.readLine()) != null) {

                if(line.length() > this.maxLine.length())
                    this.maxLine = line;

                Scanner lineSc = new Scanner(line);
                while (lineSc.hasNext()) {
                    String word = lineSc.next();
                    if (word.equalsIgnoreCase(keyword))
                        this.keywordCounter++;
                }


            }
            System.out.println(this.title);
            System.out.println(this.maxLine);
            System.out.println(this.keywordCounter);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

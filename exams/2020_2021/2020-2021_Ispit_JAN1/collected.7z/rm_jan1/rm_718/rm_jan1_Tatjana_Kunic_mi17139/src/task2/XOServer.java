package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

class XOServer {

    public static final int PORT = 12345;
    public static final String HOST = "localhost";
    
    public static void main(String[] args) throws IOException {

        XOServer server = new XOServer(PORT);
        server.execute();

 //       System.out.println("Hello from: " + XOServer.class.getName());
    }

    private int port;
    private int acceptedClients = 0;
    private ArrayList<Socket> clients;
    private Map<Integer, String> board;

    private XOServer(int port) {
        this.port = port;
        this.clients = new ArrayList<>();
        this.board = new TreeMap<>();
    }

    private void execute() throws IOException {
        try (ServerSocket server = new ServerSocket(this.port)) {
            System.err.println("Listening...");

            while (true) {


                while(this.acceptedClients < 2) {
                    this.clients.add(server.accept());
                    this.acceptedClients++;

                    if(this.acceptedClients == 2){
                        this.playGame();
                    }
                }

            }

        }
    }

    private void printBoard(Socket player, boolean isValid) throws IOException {
        PrintWriter out = new PrintWriter(player.getOutputStream(), true);
        if(isValid){
        for(int i=1;i<=9;i++) {
            out.print(this.board.get(i) + " ");
            if (i % 3 == 0)
                out.println();
            }
        if(!this.hasRemainingMoves())
            out.println("end");
        out.println("endmove");
        }
        else {
            out.println("Nevalidan potez");
            out.println("endmove");
        }
    }

    private boolean hasRemainingMoves() {
        for(int i=1;i<=9;i++) {
            if(this.board.get(i).equals("-"))
                return true;
        }
        return false;
    }


    private void playGame() {
        for(int i=1; i<=9;i++) {
            this.board.put(i, "-");
        }
        int playerTurn = 1;

        try {
            this.printBoard(this.clients.get(0), true);

            while(true) {

                if (playerTurn == 1) {
                    BufferedReader in1 = new BufferedReader(new InputStreamReader(this.clients.get(0).getInputStream()));

                    String line;
                    int move = 0;
                    while ((line = in1.readLine()) != null) {
                        if(line.equalsIgnoreCase("endmove"))
                            break;
                        move = Integer.parseInt(line.trim());
                    }
                    if (!this.board.get(move).equals("-")) {
                        printBoard(this.clients.get(0), false);
                    }
                    else {
                        this.board.put(move, "X");
                        printBoard(this.clients.get(1), true);
                        if(!hasRemainingMoves())
                            break;
                        playerTurn = 2;
                    }
                }
                if (playerTurn == 2) {
                    BufferedReader in2 = new BufferedReader(new InputStreamReader(this.clients.get(1).getInputStream()));

                    String line;
                    int move = 0;
                    while ((line = in2.readLine()) != null) {
                        if(line.equalsIgnoreCase("endmove"))
                            break;
                        move = Integer.parseInt(line.trim());
                    }
                    if (!this.board.get(move).equals("-")) {
                        printBoard(this.clients.get(1), false);
                    }
                    else {
                        this.board.put(move, "O");
                        printBoard(this.clients.get(0), true);
                        if(!hasRemainingMoves())
                            break;
                        playerTurn = 1;
                    }
                }
            }
            System.err.println("end game");
            PrintWriter out1 = new PrintWriter(this.clients.get(0).getOutputStream(), true);
            PrintWriter out2 = new PrintWriter(this.clients.get(1).getOutputStream(), true);
            out1.println("end");
            out2.println("end");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.clients.get(0).close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.clients.get(1).close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.clients.clear();
            this.acceptedClients = 0;
        }

    }

}

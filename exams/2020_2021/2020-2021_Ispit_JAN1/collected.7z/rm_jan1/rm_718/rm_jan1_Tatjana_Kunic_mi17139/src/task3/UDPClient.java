package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket()) {
 //           System.err.println("connected to server");

            Scanner sc = new Scanner(System.in);
            double r = sc.nextDouble();

            byte[] buf;
            buf = String.valueOf(r).getBytes();
            DatagramPacket sending = new DatagramPacket(buf, buf.length, new InetSocketAddress(UDPServer.HOST, UDPServer.PORT));
            client.send(sending);
//            System.err.println("packet sent");

            byte[] rec = new byte[512];
            DatagramPacket recPacket = new DatagramPacket(rec, rec.length);
            client.receive(recPacket);
//            System.err.println("packet received");

            System.out.println(new String(rec, 0, recPacket.getLength()));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Hello from: " + UDPClient.class.getName());
    }

}

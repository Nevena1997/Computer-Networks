package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

class UDPServer {
    public static final int PORT = 31415;
    public static final String HOST = "localhost";
    
    public static void main(String[] args) {

        UDPServer s = new UDPServer(PORT);
        s.execute();

        //System.out.println("Hello from: " + UDPServer.class.getName());
    }

    private DatagramSocket server;
    private int port;

    private UDPServer(int port) {
        this.port = port;
    }

    private void execute() {
        try {
            this.server = new DatagramSocket(this.port);

            while(true) {

                byte[] rec = new byte[512];
                DatagramPacket received = new DatagramPacket(rec, rec.length);
                server.receive(received);
//                System.err.println("client connected");

                double r = Double.parseDouble(new String(rec, 0, rec.length).trim());

                byte[] res;

                if (r < 0) {
                    res = "Neispravan poluprecnik.".getBytes();
                } else {
                    double P = r * r * Math.PI;
                    res = String.valueOf(P).getBytes();
                }
                DatagramPacket sending = new DatagramPacket(res, res.length, received.getAddress(), received.getPort());
                server.send(sending);
//                System.err.println("response sent");
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            this.server.close();
        }
    }

}

package task1;

import java.io.*;
import java.nio.Buffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String keyword = sc.next();

        String dir = "../tests/pesme";

        try {
            DirectoryStream<Path> dirPaths = Files.newDirectoryStream(Paths.get(dir));

            for(Path p : dirPaths) {
                // bez niti

//                String fName = String.valueOf(p.getFileName());
//                int idx = fName.lastIndexOf(".");
//                System.out.println(fName.substring(0, idx));

//                BufferedReader file = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(p))));
//
//                String line;
//                int lineCounter = 0;
//                int maxLen = 0;
//                String maxLine = "";
//                int keywordCounter = 0;
//                while((line = file.readLine()) != null){
//                    if (line.length() > maxLen) {
//                        maxLen = line.length();
//                        maxLine = line;
//                    }
//                    lineCounter++;
//
//                    Scanner lineSc = new Scanner(line);
//                    while (lineSc.hasNext()) {
//                        String word = lineSc.next();
//                        if(word.equalsIgnoreCase(keyword))
//                            keywordCounter++;
//                    }
//
//                }
//                System.out.println(maxLine);
//                System.out.println(keywordCounter);
//
//                System.out.println("------------------------------------");

                SongParser sp = new SongParser(p, keyword);
                sp.start();
                Thread.sleep(500);

            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        //System.out.println("Hello from: " + Task1Main.class.getName());
    }

}

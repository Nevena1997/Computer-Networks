package task2;

public class Tabla {

    private char[][] tabla;

    Tabla(){
        this.tabla = new char[3][3];
        for(int i=0; i<3; i++){
            for(int j=0; j<3;j++){
                tabla[i][j]='-';
            }
        }
    }



    public void setPlay(int i, int j, char play){
        this.tabla[i][j]=play;
    }

    public char[][] getTabla() {
        return tabla;
    }

    public boolean check() {
        boolean flag = true;
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                if(tabla[i][j] == '-')
                    flag=false;
            }
        }

        return flag;
    }
}

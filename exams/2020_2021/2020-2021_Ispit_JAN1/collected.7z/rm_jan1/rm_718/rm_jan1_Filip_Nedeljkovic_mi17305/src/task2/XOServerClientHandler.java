package task2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

class XOServerClientHandler implements Runnable {



    private XOServer server;
    private Socket client;
    private BufferedReader in;
    private BufferedWriter out;
    private char play;
    private int i;
    private int j;

    XOServerClientHandler(XOServer server, Socket client, char play) throws IOException {
        this.server = server;
        this.client= client;
        this.in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
        this.out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
        this.play = play;

    }

    public void run(){
        try {


            while (true) {

                while(server.getKlijetniSize() == 2) {

                      server.sendState();

                      String whereToPlay = in.readLine();
                      if (whereToPlay == null) {
                          break;
                      }
                      int p = Integer.parseInt(whereToPlay.trim());
                      //Izvinjavam se zbog ovog uzasnog koda
                      if (p == 1) {
                          this.i = 0;
                          this.j = 0;
                      } else if (p == 2) {
                          this.i = 0;
                          this.j = 1;
                      } else if (p == 3) {
                          this.i = 0;
                          this.j = 2;
                      } else if (p == 4) {
                          this.i = 1;
                          this.j = 0;
                      } else if (p == 5) {
                          this.i = 1;
                          this.j = 1;
                      } else if (p == 6) {
                          this.i = 1;
                          this.j = 2;
                      } else if (p == 7) {
                          this.i = 2;
                          this.j = 0;
                      } else if (p == 8) {
                          this.i = 2;
                          this.j = 1;
                      } else if (p == 9) {
                          this.i = 2;
                          this.j = 2;
                      } else {
                          out.write("Nevalidan potez");
                          out.newLine();
                          out.flush();
                      }

                      server.setState(this.i, this.j, this);


                      if (server.checkIfFinished()) {
                          server.removeClients();
                          break;
                      }


                }
            }

        }catch (IOException ex){
            ex.printStackTrace();
        }finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }



    }

    public char getPlay() {
        return play;
    }

    public void  sendMessage(char[] chars) {
        try {
            this.out.write(chars);
            this.out.newLine();
            this.out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            this.client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

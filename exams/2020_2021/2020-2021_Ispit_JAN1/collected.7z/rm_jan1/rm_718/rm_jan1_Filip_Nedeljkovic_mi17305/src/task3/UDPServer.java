package task3;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer implements Runnable {

    private final static int PORT = 31415;
    public static void main(String[] args) {

        UDPServer s = new UDPServer(PORT);
        new Thread(s).start();
    }

    private final int port;
    private String toSend;
    private final double pi;
    UDPServer(int port){
        this.port = port;
        this.toSend = null;
        this.pi = Math.PI;
    }

    public void run(){
        try(DatagramSocket server = new DatagramSocket(this.port)){
            while(true){

                DatagramPacket request = new DatagramPacket(new byte[30],30);
                server.receive(request);
                String recieved = new String(request.getData(),0,request.getLength());
                double r = Double.parseDouble(recieved.trim());
                if(r<0){
                    this.toSend = "Neispravan poluprecnik";
                }else{
                    double p = r*r*this.pi;
                    this.toSend = String.valueOf(p);
                }
                byte[] sending = toSend.getBytes();
                DatagramPacket answer = new DatagramPacket(sending,sending.length,request.getAddress(),request.getPort());
                server.send(answer);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

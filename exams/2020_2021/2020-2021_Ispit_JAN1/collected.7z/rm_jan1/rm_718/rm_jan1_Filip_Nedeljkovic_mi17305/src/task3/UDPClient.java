package task3;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    private final static int PORT = 31415;
    private final static String HOST = "localhost";
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try(DatagramSocket clientSocket = new DatagramSocket()){

            InetAddress address = InetAddress.getByName(HOST);
            String input = sc.next();
            byte[] toSend = input.getBytes();
            DatagramPacket request = new DatagramPacket(toSend,toSend.length,address,PORT);
            clientSocket.send(request);

            DatagramPacket recieve = new DatagramPacket(new byte[30],30);
            clientSocket.receive(recieve);

            String res = new String(recieve.getData(),0,recieve.getLength());
            System.out.println(res);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            sc.close();
        }


    }

}

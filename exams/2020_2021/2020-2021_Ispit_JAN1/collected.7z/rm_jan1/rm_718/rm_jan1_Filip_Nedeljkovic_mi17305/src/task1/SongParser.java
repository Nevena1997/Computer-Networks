package task1;

import java.io.*;
import java.nio.file.Path;

class SongParser implements Runnable{


    BufferedReader in;
    private final String keyword;
    String nazivPesme;
    String longest;

    SongParser(Path p, String keyword) throws FileNotFoundException {

        this.nazivPesme = p.getFileName().toString().substring(0,p.getFileName().toString().lastIndexOf('.'));


        in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())));
        this.keyword = keyword;
    }

    public void run(){

        try {
            read();

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }


    public synchronized void read() throws IOException {
        int line = 0;
        int num_of_appearances = 0;
        int max_length = 0;

        for(String tekst = in.readLine(); tekst!=null; tekst=in.readLine(), line++ ){
            if(tekst.length() > max_length){
                max_length = tekst.length();
                this.longest = tekst;
            }

            if(tekst.contains(this.keyword)){
                num_of_appearances++;
            }




        }


        System.out.println(this.nazivPesme);
        System.out.println(this.longest);
        System.out.println(num_of_appearances);


    }


}

package task2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class XOClient {
        private final static int PORT = 12345;
        private final static String HOST = "localhost";
    public static void main(String[] args) {




       try(Socket client = new Socket(HOST,PORT);
           BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
           BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
           Scanner sc = new Scanner(System.in)) {

           while(true){

               String red;
               String play;
               for(int i=0; i<3; i++){
                   if((red = networkIn.readLine()) != null){
                       System.out.println(red);
                   }else{
                       break;
                   }
               }
                while(true) {
                    play = sc.nextLine();

                        int num = Integer.parseInt(play.trim());
                        if(num >0 && num <10) {
                            out.write(play);
                            out.newLine();
                            out.flush();
                            break;
                        }else {
                            String error = networkIn.readLine();
                            System.out.println(error);
                        }

                    }
                }

       } catch (UnknownHostException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       }
    }

}

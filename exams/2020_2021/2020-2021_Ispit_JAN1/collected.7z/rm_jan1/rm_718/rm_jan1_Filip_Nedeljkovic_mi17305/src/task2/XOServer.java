package task2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

class XOServer {

    private final static int PORT = 12345;
    public static void main(String[] args) {
        XOServer server = new XOServer(PORT);
        server.execute();
    }


    private final int port;

    private Tabla tabla;
    private List<XOServerClientHandler> klijetni;
    private char play;
    XOServer(int port){
        this.port = port;
        this.tabla= new Tabla();
        klijetni = Collections.synchronizedList(new LinkedList<>());


    }
//
     public void execute(){

       try(ServerSocket server = new ServerSocket(this.port)){
            while(true){
                while(this.klijetni.size()<2) {

                    Socket client = server.accept();

                    if (this.klijetni.size() % 2 == 0) {
                        this.play = 'X';
                    } else {
                        this.play = 'O';
                    }
                    XOServerClientHandler sch = new XOServerClientHandler(this, client, this.play);
                    klijetni.add(sch);
                    new Thread(sch).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
//
    public synchronized void sendState() {
        char[][] stanje = tabla.getTabla();
            for (XOServerClientHandler user : klijetni) {
                user.sendMessage(stanje[0]);
                user.sendMessage(stanje[1]);
                user.sendMessage(stanje[2]);

        }

    }

 public synchronized void setState(int i, int j, XOServerClientHandler user) {
      tabla.setPlay(i,j,user.getPlay());

  }

  public synchronized boolean checkIfFinished() {
        return tabla.check();
    }

public int getKlijetniSize() {
        return klijetni.size();
    }

 public void removeClients() {
        synchronized (klijetni){
            for(XOServerClientHandler k : klijetni) {
                k.closeConnection();
                klijetni.remove(k);
            }
        }
   }
}

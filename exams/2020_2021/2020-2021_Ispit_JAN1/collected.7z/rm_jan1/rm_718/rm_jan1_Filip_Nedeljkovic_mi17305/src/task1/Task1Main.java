package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        String keyWord;
        keyWord = stdin.nextLine();
        stdin.close();


        Path dir = Paths.get("/home/ispit/Desktop/tests/pesme");

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(dir)){
            for(Path p : ds){

                SongParser sg = new SongParser(p,keyWord);
                new Thread(sg).start();
            }
        } catch (IOException e) {
            e.printStackTrace();

        }


    }

}

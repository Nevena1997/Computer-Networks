package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) throws IOException {

        Scanner scanner = new Scanner(System.in);

        String i = scanner.next();
        SocketChannel channel = SocketChannel.open(new InetSocketAddress("localhost", 12345));
        i = i + "?";
        channel.write(ByteBuffer.wrap(i.trim().getBytes()));


        ByteBuffer buffer = ByteBuffer.allocate(1024);
        channel.read(buffer);

        String rcvText = new String(buffer.array(), 0, buffer.position());

        rcvText = rcvText.substring(0, rcvText.indexOf("?"));
        System.out.println(rcvText);
    }

}

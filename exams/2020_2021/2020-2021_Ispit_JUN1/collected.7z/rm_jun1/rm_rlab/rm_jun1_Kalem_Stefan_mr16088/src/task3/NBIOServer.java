package task3;

import java.awt.font.NumericShaper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.sql.Time;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NBIOServer {

    private List<Integer> cards;

    public static void main(String[] args) throws IOException {

        NBIOServer server = new NBIOServer();
        server.start();
    }

    private void start() throws IOException {
        List<Integer> list;


        ServerSocketChannel channel = ServerSocketChannel.open();
        channel.bind(new InetSocketAddress(12345));

        channel.configureBlocking(false);
        Selector selector = Selector.open();

        channel.register(selector, SelectionKey.OP_ACCEPT);

        prepareCards();


        while (true) {
            selector.select();
            Iterator<SelectionKey> keyIterator = selector.selectedKeys().iterator();

            while (keyIterator.hasNext()) {

                SelectionKey key = keyIterator.next();
                keyIterator.remove();

                if (key.isAcceptable()) {
                    processAcceptableKey(key);
                } else if (key.isWritable()) {
                    processWritableKey(key);
                } else if (key.isReadable()) {
                    processReadableKey(key);
                }

            }

        }


    }

    private void prepareCards() {
        Set<Integer> c = new TreeSet<>();
        for (int i = 0; i <= 60; i = i + 20) {
            for (int j = 2; j <= 14; j++) {
                c.add(i + j);
            }
        }

        Random random = new Random(LocalTime.now().getSecond());
        this.cards = c.stream().sorted((integer, t1) ->
                random.nextInt())
                .collect(Collectors.toList());
        for (Integer card : cards) {
            System.out.println(card);
        }
    }

    private void processReadableKey(SelectionKey key) throws IOException {
        SocketChannel channel = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();
        int rCnt = channel.read(buffer);
        if (rCnt == 0 || rCnt == -1) {
            System.out.println("Error: 600");
            System.exit(600);
        }


        String rcvText = readFromBuffer(buffer);


        System.out.println("RcvText: " + rcvText);
        if (rcvText == null) {
            System.out.println("Not yet complete read");
            return;
        }

        try {
            int i = Integer.valueOf(rcvText);
            System.out.println("I: " + i);
            String sndText = null;
            if (i < 1 ) {
                sndText = "Invalid number";
            }
            else if (sndText == null) {
                sndText = getCards(i);
            }

            sndText = sndText + "?";
            key.attach(ByteBuffer.wrap(sndText.getBytes()));
            key.interestOps(SelectionKey.OP_WRITE);

        } catch (NumberFormatException e) {
            System.out.println("Error 500");
            System.exit(500);
        }




    }

    private String readFromBuffer(ByteBuffer buffer) {
        String rcvText = new String(buffer.array(), 0, buffer.position());

        int ind = rcvText.indexOf("?");
        if (ind == -1) {
            return null;
        }
        else {
            return rcvText.substring(0, ind);
        }

    }

    private String getCards(int i) {
        if (i > cards.size())
            return  null;

        StringBuilder builder = new StringBuilder();

//        for (Integer s : cards) {
//            builder.append(s).append(" ");
//
//        }
        return "TODO";
    }

    private void processWritableKey(SelectionKey key) throws IOException {
        SocketChannel channel = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();

        int wCnt = channel.write(buffer);
        if (wCnt == 0 || wCnt == -1) {
            System.out.println("Error 300");
            System.exit(300);
        }

        if (!buffer.hasRemaining()) {
            key.cancel();
            key.channel().close();
            System.out.println("Error 400");
        }
    }

    private void processAcceptableKey(SelectionKey key) throws IOException {
        ServerSocketChannel mainChannel = (ServerSocketChannel) key.channel();
        SocketChannel channel = mainChannel.accept();

        channel.configureBlocking(false);
        SelectionKey cKey = channel.register(key.selector(), SelectionKey.OP_READ);
        cKey.attach(ByteBuffer.allocate(1024));


    }

}

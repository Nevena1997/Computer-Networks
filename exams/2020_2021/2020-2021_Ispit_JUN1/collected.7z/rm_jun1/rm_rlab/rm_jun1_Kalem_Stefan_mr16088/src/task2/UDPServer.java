package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    Map<String, String> codes = new HashMap<>();

    public static void main(String[] args) throws IOException {
        UDPServer server = new UDPServer();
        server.start();
    }

    private void start()  {
        DatagramSocket socket = null;
        DatagramPacket packet = null;
        try {
            readCodes();
            socket = new DatagramSocket(23456);
            packet = new DatagramPacket(new byte[1024], 1024);

        } catch (IOException e) {
            e.printStackTrace();
        }





        while (true) {


            try {
                packet.setData(new byte[1024], 0, 1024);
                socket.receive(packet);
            String rcvText = new String(packet.getData(), 0, packet.getLength());

//            System.out.println("RcvText: " + rcvText);

            if (rcvText == null) {
//                System.out.println("Error 300");
                System.exit(300);
            }

            rcvText = rcvText.trim();
            String sndText = transform(rcvText) + ".-.-.-";
//            System.out.println("SndText: " + sndText);
            byte[] b = sndText.trim().getBytes();
            socket.send(new DatagramPacket(b, b.length, packet.getSocketAddress()));

        } catch (IOException e) {}


        }

    }

    private void readCodes() throws IOException {
        BufferedReader reader = Files.newBufferedReader(Path.of("./morse.txt"));
//        System.out.println((reader.lines().reduce((s, s2) -> s + "\n" + s2)));

        while (true) {
            String line = reader.readLine();

            if (line == null) {
                return;
            }
            String[] s = line.split("( )+");
            codes.put(s[0].trim() , s[1].trim());
//            System.out.println();
        }

    }

    String transformWord(String w) {
        return w.chars().mapToObj(i -> {
            String s = Character.valueOf((char) i).toString();
            return codes.get(s) + " ";
        }).reduce((s, s2) -> s + s2).orElse("");
    }

    private String transform(String rcvText) {
        System.out.println("Transform: " + rcvText);
        return Arrays.stream(rcvText.split("( )+")).map(s -> transformWord(s.toLowerCase()) + "   ")
                .reduce((s, s2) -> s + s2).orElse("");
    }

}

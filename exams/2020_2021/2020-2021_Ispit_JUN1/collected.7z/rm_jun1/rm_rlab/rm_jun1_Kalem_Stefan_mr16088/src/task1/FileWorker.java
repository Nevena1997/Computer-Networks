package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.stream.Collectors;

public class FileWorker implements Runnable {
    private BufferedReader reader = null;

    public FileWorker(BufferedReader reader) {
        this.reader = reader;
    }

    @Override
    public void run() {
//        System.out.println("Reader " + reader);
        StringBuilder builder = new StringBuilder();

    try {
        while (true) {

            String line = null;
            try {
                line = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }


            if (line == null) {
//                System.out.println("Error 333");
                break;
            }

            line = line.trim();

            try {
                URL url = new URL(line);

                String v4 = null;

                String host = url.getHost();

                if (host.contains(":")) {
                    builder.append("(v6) ");
                } else {
                    String[] s = host.split("\\.");
                    v4 = getV4(s);

                    if (v4 != null) {
                        builder.append("(v4) ");
                    }
                }


                builder.append(url.getProtocol()).append(" ")
                        .append(url.getAuthority()).append(" ")
                        .append(url.getPath()).append(" ");

                if (v4 != null) {
                    builder.append(v4);
                }
                builder.append("\r\n");

            } catch (MalformedURLException e) {
//                System.out.println("Line: " + line);
            }
        }
    } finally {
        try {
            this.reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        synchronized (System.out) {
            System.out.print(builder.toString());
        }
    }

    private String getV4(String[] s) {
        if (s.length != 4)
            return null;
        try {
            int i = Integer.valueOf(s[0]);

        } catch (NumberFormatException e) {return  null;}

        return "[" + Arrays.stream(s).collect(Collectors.joining(" ")) + "]";
    }
}

package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Task1Main {
    public static void main(String[] args) throws IOException {
        String dir = "/home/ispit/Desktop/tests/urls";
        DirectoryStream<Path> paths = Files.newDirectoryStream(Path.of(dir));

        List<Thread> threads = new ArrayList<>();
        for (Path path : paths) {


            synchronized (System.out) {
//                System.out.println("Path: " + path);
            }


            if (Files.isDirectory(path)) {
                synchronized (System.out) {
                    System.out.println("Error 500");
                }
                continue;
            }

            BufferedReader reader = null;
            try {
                reader = Files.newBufferedReader(path);
            } catch (IOException e) {
                e.printStackTrace();
            }


            Thread thread = new Thread(new FileWorker(reader));
            threads.add(thread);
            thread.start();
        }


        threads.stream().forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
    }
}

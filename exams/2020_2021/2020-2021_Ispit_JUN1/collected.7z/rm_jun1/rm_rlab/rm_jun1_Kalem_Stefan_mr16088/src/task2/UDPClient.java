package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) throws IOException {
        try (Scanner scanner = new Scanner(System.in);) {

            String s = scanner.nextLine();

            DatagramSocket socket = new DatagramSocket();

            byte[] b = s.getBytes();
            DatagramPacket packet = new DatagramPacket(b, 0, b.length,
                    new InetSocketAddress("localhost", 23456));


            socket.send(packet);

            packet.setData(new byte[1024]);

            socket.receive(packet);

            String rcvText = new String(packet.getData(), 0, packet.getLength());
            System.out.println(rcvText.trim());
//            System.out.println("End");
        }
    }

}

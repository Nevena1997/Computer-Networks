package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.*;
import java.util.Scanner;

public class FileData extends Thread {

    private File _file;

    FileData(File file){
        _file=file;
    }

    @Override
    public void run() {

        try (Scanner sc=new Scanner(_file)){

            do{

                URL url=new URL(sc.nextLine());
                InetAddress adress=InetAddress.getByName(url.getHost());
                String prefix="";
                String sufix="";

                sufix=" ["+ adress.getHostAddress().replace("."," ")+"]";

                String result=  url.getProtocol() +" " + url.getAuthority() +" " + url.getPath()+sufix;
                System.out.println(result);

            }while(sc.hasNextLine());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

    }
}

package task3;

public class NBIOServer {

    public static int PORT=12345;

    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");
    }

}

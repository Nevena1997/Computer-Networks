package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try(SocketChannel client=SocketChannel.open();
            Scanner sc=new Scanner(System.in)){

            client.connect(new InetSocketAddress("localhost",NBIOServer.PORT));

            System.out.println("Unesite broj karti");



            ByteBuffer buffer=ByteBuffer.allocate(4);
            client.write(buffer);






        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;



import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static int SIZE=1024;


    public static void main(String[] args) {


        try(DatagramSocket client =new DatagramSocket();
            Scanner sc=new Scanner(System.in);) {

            System.out.println("Unesite poruku");
            String sentence=sc.nextLine()+" . 1";

            byte[] buffer= sentence.getBytes();

            DatagramPacket request=new DatagramPacket(buffer,0,buffer.length, InetAddress.getByName("localhost"),UDPServer.PORT);


            client.send(request);


            DatagramPacket response=new DatagramPacket(new byte[SIZE],SIZE);


            client.receive(response);

            String responseString=new String(response.getData(),0,response.getLength());
            System.out.println(responseString);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

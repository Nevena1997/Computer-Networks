package task1;

import java.io.File;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    private static int MAX_PATHS=100;
    private static String testPath="/home/ispit/Desktop/tests/urls";


    public static void main(String[] args) {

        BlockingQueue<String> paths=new ArrayBlockingQueue<String>(MAX_PATHS);

        File f=new File(testPath);
        File [] allFiles=f.listFiles();

        FileData [] fileData = new FileData[MAX_PATHS];
        int size=0;


        for(File file: allFiles){
            if(!file.isDirectory()){

                fileData[size]=new FileData(file);
                fileData[size++].start();
            }
        }

        for(int i=0;i<size;i++) {
            try {
                fileData[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }



    }
}

package task2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.*;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;


public class UDPServer {

    public static int PORT = 23456;
    private static String morsePath = "/home/ispit/Desktop/rm_Jun1_Joksimovic_Miloje_mr17006/morse.txt";


    public static void main(String[] args) {


        try (DatagramSocket server = new DatagramSocket(PORT);) {


            while (true) {


                byte[] buffer = new byte[1024];

                DatagramPacket request = new DatagramPacket(buffer, 1024);


                server.receive(request);


                String requestString = new String(request.getData(), 0, request.getLength());

                String responseString = translate(requestString);
                byte[] data=responseString.getBytes();

                DatagramPacket response = new DatagramPacket(data, 0, data.length, request.getAddress(), request.getPort());

                server.send(response);

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    private static String translate(String sentence) {

        String[] words = sentence.toLowerCase().split(" ");

        StringBuilder result = new StringBuilder();

        HashMap<String, String> map = new HashMap<>();

        try (Scanner sc = new Scanner(new File(morsePath))) {

            do {

                String line = sc.nextLine();

                map.put(line.substring(0, 1), line.substring(2));


            } while (sc.hasNextLine());


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        for (int i=0;i<words.length-1;i++){
            String word=words[i];


            char[] chars = new char[word.length()];
            word.getChars(0, word.length(), chars, 0);



            for (char c : chars) {
                result.append(map.get(String.valueOf(c)));
                result.append(" ");

            }
            result.append("   ");
        }


        System.out.println(result);
        return result.toString();
    }

}

package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Scanner;

public class UDPServer {
    public static final int PORT = 23456;
    private static final int BUFFER_LEN = 1024;
    static HashMap<String, String> morseCode;

    public static void main(String[] args) {


        try {
            getMorseCoding();
        } catch(Exception e){
            e.printStackTrace();
            System.out.println("Greska pri citanju datoteke");
            System.exit(1);
        }


        try (DatagramSocket server = new DatagramSocket(PORT)) {
            while(true){

                byte buffer[] = new byte[BUFFER_LEN];
                DatagramPacket receivedPacket = new DatagramPacket(buffer, buffer.length);
                try {
                    server.receive(receivedPacket);
                }catch(Exception e){
                    e.printStackTrace();
                    System.out.println("Greska prilikom primanja paketa");
                }

                String receivedMsg = new String(receivedPacket.getData(), 0, receivedPacket.getLength());

                String msgToSend = morseCode(receivedMsg);

                InetAddress clientAddress = receivedPacket.getAddress();
                int clientPort = receivedPacket.getPort();
                byte buffer2[] = msgToSend.getBytes();
                DatagramPacket packetToSend = new DatagramPacket(buffer2, buffer2.length, clientAddress, clientPort);

                try {
                    server.send(packetToSend);
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("Greska pri slanju");
                }


            }



        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

    private static void getMorseCoding() throws FileNotFoundException {
        morseCode = new HashMap<>();

        Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("morse.txt"))));

        morseCode.put(" ","  ");
        while(sc.hasNext()){
            String c = sc.next();
            String code = sc.next();

            morseCode.put(c, code);
        }



        sc.close();

    }

    private static String morseCode(String receivedMsg) {
        int n = receivedMsg.length();

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < n; i++){
            char curr = receivedMsg.charAt(i);
            if (curr >= 'A' && curr <= 'Z')
                curr = (char)(curr - 'A' + 'a');
            String key = String.valueOf(curr);
            String code = morseCode.get(key);
            sb.append(code);
            sb.append(" ");
        }

        sb.append(".-.-.-");

        return sb.toString();
    }

}

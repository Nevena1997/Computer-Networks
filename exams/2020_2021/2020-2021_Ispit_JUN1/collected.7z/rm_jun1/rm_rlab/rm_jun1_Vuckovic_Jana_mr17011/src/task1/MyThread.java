package task1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MyThread implements Runnable {
    private Path path;


    public MyThread(Path p) {
        this.path = p;
    }


    @Override
    public void run() {

        try (Scanner sc= new Scanner(new InputStreamReader(new FileInputStream(path.toString())))){

            synchronized (System.in) {
                //System.out.println(path);
                while (sc.hasNext()) {
                    String line = sc.nextLine();

                    try {
                        URL url = new URL(line);
                        String protocol = url.getProtocol();
                        String authority = url.getAuthority();
                        String path = url.getPath();
                        String host = url.getHost();

                        if (isIP4(host))
                            System.out.println("(V4) "+protocol + " " + authority + " " + path);
                        else if (isIP6(host))
                            System.out.println("(V4) "+protocol + " " + authority + " " + path);
                        else
                            System.out.println(protocol + " " + authority + " " + path);
                    } catch (MalformedURLException e) {
                       //System.out.println("Neispavna linija"+line);
                    }


                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }



    private boolean isIP6(String host) {
        int n = host.length();
        for (int i = 0; i < n; i++){
            char c = host.charAt(i);
            if (!((c == ':') || (c >= 'a' && c<='f') || (c>='0' && c<='9')))
                return false;
        }
        return true;
    }

    private boolean isIP4(String host) {
        int n = host.length();
        for (int i = 0; i < n; i++){
            char c = host.charAt(i);
            if ((c < '0' || c > '9') &&  c!='.')
                return false;
        }
        return true;
    }
}

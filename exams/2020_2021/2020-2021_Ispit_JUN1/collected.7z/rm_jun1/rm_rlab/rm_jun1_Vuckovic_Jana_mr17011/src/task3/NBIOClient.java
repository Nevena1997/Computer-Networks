package task3;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", NBIOServer.PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in))
        {

            System.out.println("Uspostavljena veza sa serverom.");
            System.out.println("Unesite broj karata");
            int numberOfCards = sc.nextInt();
            sc.nextLine();

            out.write(numberOfCards+"#");
            out.newLine();
            out.flush();


            String answer = in.readLine();

            if (answer.contains("#"))
                answer = answer.replace("#", "\n");

            System.out.println(answer);



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

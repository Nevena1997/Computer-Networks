package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {

    private static final int BUFFER_LEN = 1024;

    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            System.out.println("Otvoren soket");

            String msg = sc.nextLine();
            byte buffer[] = msg.getBytes();
            DatagramPacket packetToSend = new DatagramPacket(buffer, buffer.length, InetAddress.getByName("localhost"), UDPServer.PORT);
            client.send(packetToSend);

            byte bufferForReceiving[] = new byte[BUFFER_LEN];
            DatagramPacket receivedPacket = new DatagramPacket(bufferForReceiving, BUFFER_LEN);
            client.receive(receivedPacket);

            String receivedMsg = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
            System.out.println(receivedMsg);



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

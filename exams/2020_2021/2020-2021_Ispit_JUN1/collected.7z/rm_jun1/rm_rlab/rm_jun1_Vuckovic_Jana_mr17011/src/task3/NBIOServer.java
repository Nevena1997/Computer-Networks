package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

public class NBIOServer {
    public static final int PORT = 12345;
    private static final int BUFFER_SIZE = 512;
    private static ArrayList<String> deck;
    private static int pointer;
    private static HashMap<String, String> cardsForClient;

    public static void main(String[] args) {
        formDeck();
        cardsForClient = new HashMap<>();

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if (!serverChannel.isOpen() || !selector.isOpen()){
                System.out.println("Greska");
                System.exit(1);
            }

            serverChannel.configureBlocking(false);
            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);


            while(true){
                selector.select();
                Iterator<SelectionKey> itr = selector.selectedKeys().iterator();

                while(itr.hasNext()){
                    SelectionKey key = itr.next();
                    itr.remove();


                    try {
                        if (key.isAcceptable()) {
                            acceptClient(key, selector);
                        } else if (key.isReadable()) {
                            readFromClient(key);
                        } else if (key.isWritable()) {
                            writeToClient(key);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                        key.channel().close();

                    }
                }

                /*if (pointer == 52)
                    break;*/

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void formDeck() {
        deck = new ArrayList<>();
        pointer = 0;

        for (int i = 1; i < 15; i++) {
            deck.add(i+".Pik");
            deck.add(i+".Tref");
            deck.add(i+".Herc");
            deck.add(i+".Karo");
        }

        Collections.shuffle(deck);

        /*for (String card : deck){
            System.out.println(card);
        }*/
    }

    private static void acceptClient(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel server = (ServerSocketChannel) key.channel();
        SocketChannel client = server.accept();

        client.configureBlocking(false);
        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

        System.out.println("Pristigao klijent");

        ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
        clientKey.attach(buffer);

    }

    private static void readFromClient(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();

        client.read(buffer);

        String readMsg = new String(buffer.array(), 0, buffer.position());
        if (readMsg.contains("#")) {
            readMsg = readMsg.substring(0, readMsg.indexOf("#"));
            int n = Integer.parseInt(readMsg);
            System.out.println("Klijent trazi "+n+" karata");
            String tmp = "";
            if (n <= 0){
                tmp = "Unesite pozitivan broj";
            }
            if (n + pointer > 52)
                tmp = "Nema toliko karata";
            else {
                for (int i = 0; i < n; i++) {
                    tmp += deck.get(pointer);
                    tmp += "#";
                    pointer++;
                }
            }
            //String clientsname = client.getRemoteAddress().toString();
            tmp += "\n";
            buffer.clear();
            buffer.put(tmp.getBytes());
            buffer.flip();
            key.interestOps(SelectionKey.OP_WRITE);
        }
    }

    private static void writeToClient(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();

        //String inBuffer = new String(buffer.array(), 0, buffer.limit());
        //System.out.println("Pisemo klijentu "+inBuffer);

        client.write(buffer);

        String sentMsg = new String(buffer.array(), 0, buffer.position());
        if (sentMsg.contains("\n")){
            client.close();
        }

    }

}

package task1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    private static final int MAX_NUM = 32;

    public static void main(String[] args) {
        String path = "/home/ispit/Desktop/tests/urls";
        Path directory = Paths.get(path);
        DirectoryStream<Path> streamOfFiles = null;
        Thread t[] = new Thread[MAX_NUM];
        int i =0;
        try {
            streamOfFiles = Files.newDirectoryStream(directory);

            for (Path p : streamOfFiles){

                //System.out.println(p.toString());
                t[i] = new Thread(new MyThread(p));
                t[i].start();
                i++;
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        for (int j = 0; j < i; j++) {
            try {
                t[j].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }





    }
}

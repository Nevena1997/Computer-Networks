package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        InetSocketAddress address=new InetSocketAddress("localhost",NBIOServer.DEFAULT_PORT);
        try(SocketChannel client=SocketChannel.open(address); Scanner sc=new Scanner(System.in)){

            while(true) {
                int broj = sc.nextInt();

                if(broj<1){
                    System.err.println("Izaberite ponovo jedan broj.");
                    continue;

                }
                ByteBuffer buffer = ByteBuffer.allocate((broj + 1) * 4);

                buffer.putInt(broj);
                buffer.flip();
                client.write(buffer);
                buffer.clear();

                client.read(buffer);
                buffer.flip();
                while(buffer.hasRemaining()){
                    int karta=buffer.getInt();
                    System.out.print(karta);
                }
                System.out.println();
                //sc.close();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static int BUFF_SIZE=256;
    public static void main(String[] args) {

       try(DatagramSocket client=new DatagramSocket(); Scanner sc=new Scanner(System.in)) {

           String niska=sc.nextLine();
           byte[] sendB=niska.getBytes();
           DatagramPacket sendPacket=new DatagramPacket(sendB,sendB.length, InetAddress.getByName("localhost"),UDPServer.DEFAULT_PORT);
           client.send(sendPacket);

           byte[] receivedB=new byte[BUFF_SIZE];
           DatagramPacket receivedPacket=new DatagramPacket(receivedB,receivedB.length);
           client.receive(receivedPacket);

           String result=new String(receivedPacket.getData(),0,receivedPacket.getLength());
           System.out.println(result);


           //sc.close();

       } catch (SocketException e) {
           e.printStackTrace();
       } catch (UnknownHostException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       }

    }

}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

        String line=sc.nextLine();

        try(DirectoryStream<Path> ds= Files.newDirectoryStream(Paths.get(line))){

            for(Path p: ds){
                new Thread(new SearchThread(p)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        sc.close();

    }
}

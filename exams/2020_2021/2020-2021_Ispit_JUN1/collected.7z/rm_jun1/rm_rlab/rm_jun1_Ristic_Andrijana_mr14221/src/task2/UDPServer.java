package task2;

import javafx.application.Preloader;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Scanner;

public class UDPServer {

    public static final int DEFAULT_PORT=23456;

    public static void main(String[] args) {

        try(DatagramSocket server=new DatagramSocket(DEFAULT_PORT);
            BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_jun1_Ristic_Andrijana_mr14221/morse.txt")))
            ){


            while(true) {
                byte[] receivedBytes = new byte[UDPClient.BUFF_SIZE];
                DatagramPacket receivedP = new DatagramPacket(receivedBytes, receivedBytes.length);
                server.receive(receivedP);

                String keyword = new String(receivedP.getData(), 0, receivedP.getLength());

                String[] niz = keyword.split("");

                String[] rez = new String[50];
                String line;
                int j = 0;
                while ((line = in.readLine()) != null) {
                    for (int i = 0; i < niz.length; i++) {
                        if (line.contains(niz[i])) {
                            rez[j] = line.substring(line.indexOf(niz[i].trim()) + 1);
                            j++;
                        }

                    }
                }

                String rezultat = Arrays.toString(rez);
                byte[] sendBytes = rezultat.getBytes();
                DatagramPacket sendP = new DatagramPacket(sendBytes, sendBytes.length, receivedP.getAddress(), receivedP.getPort());
                server.send(sendP);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;

public class SearchThread implements Runnable {

    private Path p;

    public SearchThread(Path p) {
        this.p=p;
    }

    @Override
    public void run() {

        try(Scanner in=new Scanner(this.p)){

            while(in.hasNextLine()){
                String line=in.nextLine();

               // URL u=new URL(line);
               // System.out.println(u.getProtocol()+" "+u.getAuthority()+" "+u.getPath());

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

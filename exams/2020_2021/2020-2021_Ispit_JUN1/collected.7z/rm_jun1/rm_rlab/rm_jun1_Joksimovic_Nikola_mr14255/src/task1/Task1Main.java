package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) {


        String startDirStr = "/home/ispit/Desktop/tests/urls";


        Task1Main mein = new Task1Main(startDirStr);
        mein.execute();

    }


    private String startDirStr;

    public Task1Main(String startDirStr){

        this.startDirStr = startDirStr;

    }

    private void execute(){
        try {

            DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get(this.startDirStr.toString()));

            for(Path p : ds){

                new FileThread(p, this).start();
            }


        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public static synchronized void ispisi(String message){

        System.out.println(message);
    }
}

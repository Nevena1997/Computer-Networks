package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static java.lang.System.exit;

public class NBIOServer {

    public static int PORT = 12345;
    private static Map<String, Integer> spil_karata = new HashMap<>();
    private static int ostale_karte = 52;

    public static void main(String[] args) {

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if(!serverChannel.isOpen() || !selector.isOpen()){

                System.err.println("Couldn't open server or selector.. exiting..");
                exit(1);
            }

            System.err.println("SERVER IS UP..");

            kreiraj_spil();
            ispisi_spil();

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){

                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while (iter.hasNext()){

                    SelectionKey key = iter.next();
                    iter.remove();

                    if(key.isAcceptable()){

                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);

                        System.out.println("Player connected..");

                        ByteBuffer buffer = ByteBuffer.allocate(4);

                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                        clientKey.attach(buffer);

                    }else if(key.isReadable()){

                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.read(buffer);

                        int broj_karata = 0;

                        if(!buffer.hasRemaining()){

                            buffer.flip();
                            broj_karata = buffer.getInt();
                            //System.out.println("Trazen broj karata: " + broj_karata);

                            String outputMessage;

                            if(broj_karata < 1 || broj_karata > ostale_karte){

                                outputMessage = "Neispravan unos.." + "\n";
                            }else {

                                outputMessage = izvuci_karte(broj_karata) + "\n";
                                //outputMessage = Integer.toString(broj_karata) + '\n';

                                //System.out.println(outputMessage);
                            }

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
                            ByteBuffer outputBuffer = ByteBuffer.allocate(2048);
                            outputBuffer.put(outputMessage.getBytes());
                            outputBuffer.flip();
                            clientKey.attach(outputBuffer);


                        }
                    }else if(key.isWritable()){

                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.write(buffer);

                        if(!buffer.hasRemaining()){

                            //System.out.println("Poslao celu poruku");
                            ByteBuffer buffer1 = ByteBuffer.allocate(4);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                            clientKey.attach(buffer1);

                            System.out.println("Ukupan broj karata je: " + ostale_karte);
                        }

                    }
                }
            }


        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    private static synchronized String izvuci_karte(int broj_karata){

        ostale_karte -= broj_karata;

        int brisanje = broj_karata;

        String outputMessage = "";

        Iterator<Map.Entry<String, Integer>> iterator = spil_karata.entrySet().iterator();

        String karta;

        while(iterator.hasNext() && broj_karata > 0){

            Map.Entry<String, Integer> entry = iterator.next();
            karta = entry.getKey();

            outputMessage = outputMessage + karta + " ";

            iterator.remove();
            broj_karata--;
        }




        return outputMessage;
    }

    private static void kreiraj_spil(){

        String karta;
        String[] znakovi = {"Pik", "Herc", "Tref", "Karo"};

        for(int i = 0; i < 4; i++){
            for(int j = 2; j <= 14; j++){

                karta = j + "." + znakovi[i];
                spil_karata.put(karta, j);
            }
        }
    }

    private static void ispisi_spil(){

        Iterator<Map.Entry<String, Integer> > iterator = spil_karata.entrySet().iterator();

        int ukupanBrojKarata = 0;

        while (iterator.hasNext()){

            ukupanBrojKarata++;

            Map.Entry<String, Integer> entry = iterator.next();
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        System.out.println("Ukupan broj karata je:" + ukupanBrojKarata);
    }
}

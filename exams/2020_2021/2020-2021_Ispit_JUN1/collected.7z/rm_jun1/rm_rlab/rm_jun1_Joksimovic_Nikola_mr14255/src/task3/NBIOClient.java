package task3;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        InetSocketAddress addres = new InetSocketAddress("localhost", NBIOServer.PORT);

        try( SocketChannel client = SocketChannel.open(addres);
             Scanner sc = new Scanner(System.in)) {



            System.err.println("CONNECTED TO SERVER..");

            ByteBuffer inputBuffer = ByteBuffer.allocate(2048);
            ByteBuffer buffer = ByteBuffer.allocate(4);

            while(true){

                System.out.println("Broj karata?");
                buffer.clear();
                buffer.putInt(sc.nextInt());

                buffer.flip();
                client.write(buffer);

                //System.out.println("Poslao broj serveru");
                inputBuffer.clear();

                String inputMessage;

                while (true){

                    client.read(inputBuffer);
                    inputMessage = new String(inputBuffer.array(), 0, inputBuffer.position());

                    if(inputMessage.endsWith("\n")){

                        break;
                    }
                }

                System.out.println("Izvukli ste: " + inputMessage);

            }


        } catch (IOException e) {

            e.printStackTrace();
        }
    }

}

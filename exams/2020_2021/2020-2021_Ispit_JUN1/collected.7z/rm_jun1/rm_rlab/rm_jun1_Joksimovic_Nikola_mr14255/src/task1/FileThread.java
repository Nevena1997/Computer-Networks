package task1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;

public class FileThread extends Thread {


    private Path path;
    private Task1Main task1Main;

    public FileThread(Path path, Task1Main task1Main){

        this.path = path;
        this.task1Main = task1Main;
    }
    @Override
    public void run() {

        try{

            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path.toString())));

            String line;
            String message;
            while((line = in.readLine()) != null){

                if(testURL(line)){

                    URL u = new URL(line);

                    message = "<" + u.getProtocol() + ">\t" + "<" + u.getAuthority() + ">\t" + "<" + this.path.toString() + ">\t";
                    this.task1Main.ispisi(message);
                }
            }


        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    private static boolean testURL(String url){

        try{

            URL u = new URL(url);

        } catch (MalformedURLException e) {

            return false;
        }

        return true;
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){



            byte[] bufferReceive = new byte[1024];

            while (true) {

                byte[] buffer = sc.nextLine().getBytes();

                DatagramPacket toServer = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), UDPServer.PORT);
                client.send(toServer);

                //System.out.println("POSLAT PAKET SERVERU");

                DatagramPacket fromServer = new DatagramPacket(bufferReceive, bufferReceive.length);
                client.receive(fromServer);

                String outputMessage = new String(fromServer.getData(), 0, fromServer.getLength());

                System.out.println(outputMessage);

            }

        } catch (SocketException e) {

            e.printStackTrace();
        } catch (UnknownHostException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static int PORT = 23456;

    public static void main(String[] args) {

        try( DatagramSocket server = new DatagramSocket(PORT)){


            byte[] buffer = new byte[256];
            byte[] bufferOut;

            while (true) {

                DatagramPacket fromClient = new DatagramPacket(buffer, buffer.length);
                server.receive(fromClient);

                String message = new String(fromClient.getData(), 0, fromClient.getLength());
                //System.out.println("PRIMLJEN PAKET : " + message);
                message = message.toLowerCase();


                String outputMessage = transformMorze(message);

                //System.out.println(outputMessage);

                bufferOut = outputMessage.getBytes();
                DatagramPacket toClient = new DatagramPacket(bufferOut, bufferOut.length, fromClient.getAddress(), fromClient.getPort());
                server.send(toClient);

                //System.out.println("POSLAT PAKET KLIJETNU NATRAG");

            }
        } catch (SocketException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    private static String transformMorze(String message){


        Map<Character, String> azbuka = new HashMap<>();

        String outputMessage = "";

        try {

            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_jun1_Joksimovic_Nikola_mr14255/morse.txt")));

            String line;
            while ((line = reader.readLine()) != null){

                String[] charCode = line.split(" ");

                azbuka.put(charCode[0].charAt(0), charCode[1]);
            }

            //Napravio azbuku nadam se..

            //Sad da je transformisem..


            for(char c : message.toCharArray()){

                if(c == ' '){
                    outputMessage = outputMessage + "   ";
                    continue;
                }

                outputMessage = outputMessage + azbuka.get(c) + " ";
            }

            outputMessage = outputMessage + "   .-.-.-";

        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
        return outputMessage;
    }
}

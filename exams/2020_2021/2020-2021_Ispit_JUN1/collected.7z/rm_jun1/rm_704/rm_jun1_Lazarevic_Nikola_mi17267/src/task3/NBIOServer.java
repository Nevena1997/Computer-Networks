package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {

    public static final int DEFAULT_PORT = 12345;
    private static final int INT_SIZE_IN_BYTES = 4;
    private static List<Integer> cardsDeck;

    static {
        //Svaki clan liste je jedna karta. Cifra jedinice broja odredjuje da li je karta pik, tref, karo ili herc
        cardsDeck = new ArrayList<>(Arrays.asList(21, 22, 23, 24,
                                                  31, 32, 33, 34,
                                                  41, 42 , 43, 44,
                                                  51, 52 , 53, 54,
                                                  61, 62 , 63, 64,
                                                  71, 72 , 73, 74,
                                                  81, 82 , 83, 84,
                                                  91, 92 , 93, 94,
                                                  101, 102 , 103, 104,
                                                  111, 112 , 113, 114,
                                                  121, 122 , 123, 124,
                                                  131, 132 , 133, 134,
                                                  141, 142 , 143, 144));
        Collections.shuffle(cardsDeck);
        System.out.println(Arrays.toString(cardsDeck.toArray()));
    }

    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            System.err.println("Server started...");

            serverChannel.configureBlocking(false);
            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            acceptClient(key, selector);
                        } else if (key.isReadable()) {
                            readFromClient(key);
                            getReturnData(key);
                        } else if (key.isWritable()) {
                            writeToClient(key);
                        }
                    } catch (IOException e) {
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void acceptClient(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel server = (ServerSocketChannel) key.channel();

        SocketChannel client = server.accept();
        client.configureBlocking(false);
        ByteBuffer buffer = ByteBuffer.allocate(INT_SIZE_IN_BYTES);

        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
        clientKey.attach(buffer);

        System.err.println("Client accepted.");
    }

    private static void readFromClient(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();

        ByteBuffer buffer = (ByteBuffer) key.attachment();
        client.read(buffer);

        if (!buffer.hasRemaining()) {
            System.err.println("Finished reading from client.");
            buffer.flip();
            return;
        }
    }

    private static void writeToClient(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();

        ByteBuffer buffer = (ByteBuffer) key.attachment();
        client.write(buffer);

        if (!buffer.hasRemaining()) {
            System.err.println("Finished writing to client.");
            client.close();
            return;
        }
    }

    private static void getReturnData(SelectionKey key) {
        ByteBuffer bufferIn = (ByteBuffer) key.attachment();
        IntBuffer bufferAsInt = bufferIn.asIntBuffer();

        int numOfCards = bufferAsInt.get();

        ByteBuffer bufferOut = ByteBuffer.allocate((numOfCards * INT_SIZE_IN_BYTES) + INT_SIZE_IN_BYTES);

        int clientInputFlag;
        if (numOfCards < 1 || numOfCards > cardsDeck.size()) {
            clientInputFlag = -1;
            bufferOut.putInt(clientInputFlag);
            for (int i = 0; i < numOfCards; i++) {
                bufferOut.putInt(-1);
            }
        }
        else {
            clientInputFlag = 1;
            bufferOut.putInt(clientInputFlag);
            for (int i = 0; i < numOfCards; i++) {
                bufferOut.putInt(cardsDeck.get(0));
                cardsDeck.remove(0);
            }
        }
        bufferOut.flip();
        key.attach(bufferOut);
        key.interestOps(SelectionKey.OP_WRITE);
    }
}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {

    private static final int BUFF_SIZE = 4096;

    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket()) {

            System.out.print("Enter string: ");
            String inputStr;
            try (Scanner stdin = new Scanner(System.in)) {
                inputStr = stdin.nextLine();
            }

            InetAddress address = InetAddress.getLocalHost();
            byte[] data = inputStr.getBytes();
            DatagramPacket request = new DatagramPacket(data, data.length, address, UDPServer.DEFAULT_PORT);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[BUFF_SIZE], BUFF_SIZE);
            client.receive(response);

            System.out.println(new String(response.getData(), 0, response.getLength()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

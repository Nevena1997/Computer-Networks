package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    private static final int INT_SIZE_IN_BYTES = 4;

    public static void main(String[] args) {

        InetSocketAddress address = new InetSocketAddress("localhost", NBIOServer.DEFAULT_PORT);

        try (SocketChannel client = SocketChannel.open(address)) {

            int numOfCards;
            System.out.print("Enter number of cards: ");
            try (Scanner stdin = new Scanner(System.in)) {
                numOfCards = stdin.nextInt();
            }

            ByteBuffer bufferOut = ByteBuffer.allocate(INT_SIZE_IN_BYTES);
            //IntBuffer bufferOutAsInt = bufferOut.asIntBuffer();
            //bufferOutAsInt.put(numOfCards);
            bufferOut.putInt(numOfCards);
            bufferOut.flip();
            client.write(bufferOut);

            ByteBuffer bufferIn = ByteBuffer.allocate((numOfCards * INT_SIZE_IN_BYTES) + INT_SIZE_IN_BYTES);
            client.read(bufferIn);
            bufferIn.flip();

            int isInputValid = bufferIn.getInt();
            if (isInputValid == -1) {
                throw new IllegalArgumentException();
            }

            for (int i = 0; i < numOfCards; i++) {
                System.out.println(bufferIn.getInt());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.out.println("Entered number of cards is greater then deck size or it is invalid number.");
        }
    }
}

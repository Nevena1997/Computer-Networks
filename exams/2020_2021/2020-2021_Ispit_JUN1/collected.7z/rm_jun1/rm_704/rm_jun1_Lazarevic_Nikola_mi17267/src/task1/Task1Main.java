package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Task1Main {

    private static final String pathToUrls = "/home/ispit/Desktop/tests/urls";

    public static void main(String[] args) {

        try {
            for (Path p : Files.newDirectoryStream(Paths.get(pathToUrls))) {
                if (Files.isRegularFile(p)) {
                    (new parseURLThread(p)).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

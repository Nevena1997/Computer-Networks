package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;

public class parseURLThread extends Thread{

    private Path path;

    public parseURLThread(Path path) {
        this.path = path;
    }

    @Override
    public void run() {
        try (BufferedReader fin = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(this.path.toString())
                )
        )) {
            String urlStr = "";
            while ((urlStr = fin.readLine()) != null) {
                URL url = null;
                try {
                    url = new URL(urlStr);
                } catch (MalformedURLException e) {
                    //skip invalid url
                    return;
                }

//                int addressType = -1;
//                InetAddress address = null;
//                String host = url.getHost();
//                if (host.contains(":") || host.contains(".")) {
//                    try {
//                        address = InetAddress.getByName(host);
//                    } catch (UnknownHostException e) {
//                        continue;
//                    }
//                    addressType = address.getAddress().length == 4 ? 4 : 16;
//                }

                synchronized (System.out) {
                    System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                    System.out.println("-----------------------------");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

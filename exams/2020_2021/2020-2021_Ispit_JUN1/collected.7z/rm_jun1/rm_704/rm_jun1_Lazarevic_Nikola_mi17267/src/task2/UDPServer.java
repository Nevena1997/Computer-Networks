package task2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static final int DEFAULT_PORT = 23456;
    private static final int BUFF_SIZE = 1024;
    private static Map<Character, String> morseMap;

    public static void main(String[] args) {

        try (BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream("morse.txt")))) {
            morseMap = new HashMap<>();

            String line;
            while ((line = fin.readLine()) != null) {
                String[] lineSplit = line.split(" ");
                morseMap.put(lineSplit[0].charAt(0), lineSplit[1]);
            }
        } catch (IOException e) {
            System.err.println("Can't load data from file: morse.txt");
            e.printStackTrace();
        }

        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)) {
            System.err.println("Server started...");

            while (true) {
                try {
                    DatagramPacket request = new DatagramPacket(new byte[BUFF_SIZE], BUFF_SIZE);
                    server.receive(request);

                    String inputStr = new String(request.getData(), 0, request.getLength());
                    String[] inputStrArray = inputStr.split(" ");
                    StringBuilder sb = new StringBuilder();

                    for (String s : inputStrArray) {
                        for (Character c : s.toCharArray()) {
                            c = Character.toLowerCase(c);
                            sb.append(morseMap.get(c)).append(" ");
                        }
                        sb.append("   ");
                    }
                    sb.append(".-.-.-");
                    String outputStr = String.valueOf(sb);

                    byte[] data = outputStr.getBytes();
                    DatagramPacket response = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());
                    server.send(response);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

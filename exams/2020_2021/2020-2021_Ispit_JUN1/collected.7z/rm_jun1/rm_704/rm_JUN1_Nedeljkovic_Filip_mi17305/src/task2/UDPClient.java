package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.Charset;
import java.util.Scanner;

public class UDPClient {

    private final static int PORT = 23456;
    private final static String HOST = "localhost";
    private final static int BUFF_SIZE = 1024;

    public static void main(String[] args) {
        try(DatagramSocket client = new DatagramSocket();
            Scanner stdin = new Scanner(System.in)){

            String msg = stdin.nextLine();
            msg = msg.toLowerCase();

            byte[] toEncript = msg.getBytes();

            InetAddress addr = InetAddress.getByName(HOST);

            DatagramPacket request = new DatagramPacket(toEncript, 0, toEncript.length, addr, PORT);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[BUFF_SIZE], BUFF_SIZE);
            client.receive(response);
            String result = new String(response.getData(),0,response.getLength(), Charset.defaultCharset());
            System.out.println(result);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer extends Thread{

    private final static int PORT = 23456;
    private final static int BUFF_SIZE= 1024;
    public static void main(String[] args)  {
        try {
            new UDPServer().start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        DatagramSocket server;
        Map<Character,String> morse;
    UDPServer() throws IOException {
        this.server = new DatagramSocket(PORT);
        Scanner fin = new Scanner(Paths.get("morse.txt"));
        this.morse = Collections.synchronizedMap(new HashMap<>());
        String line;
        while(fin.hasNextLine()){
            line = fin.nextLine();
            int index = line.indexOf(' ');
            Character key = line.substring(0,index).toCharArray()[0];
            String value = line.substring(index+1);
            morse.put(key,value);
        }

        fin.close();
    }

    public void run(){
        while(true){


            try {
                DatagramPacket request = new DatagramPacket(new byte[BUFF_SIZE], BUFF_SIZE);
                this.server.receive(request);

                String recievedMessage = new String(request.getData(),0,request.getLength());
                String encripted = "";
                for(int i=0; i<recievedMessage.length(); i++){
                    if(morse.containsKey(recievedMessage.charAt(i))){
                        encripted += morse.get(recievedMessage.charAt(i));
                        encripted += " ";
                    }else if(recievedMessage.charAt(i) == ' '){
                        encripted += "   ";
                    }
                }
                encripted+="   .-.-.-";

                System.out.println(encripted);

                byte[] toSend = encripted.getBytes();
                DatagramPacket response = new DatagramPacket(toSend, 0, toSend.length ,request.getAddress(), request.getPort());
                this.server.send(response);


            } catch (IOException e) {
                e.printStackTrace();
            }


        }


    }

}

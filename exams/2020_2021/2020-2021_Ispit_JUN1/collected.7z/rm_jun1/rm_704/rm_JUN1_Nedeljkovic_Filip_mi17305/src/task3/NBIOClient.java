package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {
    private final static String HOST = "localhost";
    private final static int PORT = 12345;

    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress(HOST, PORT));
            Scanner sc = new Scanner(System.in)) {

            int num_of_cards = sc.nextInt();

            ByteBuffer buffer = ByteBuffer.allocate(5*2 + 4);

            buffer.putInt(num_of_cards);
            client.write(buffer);


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

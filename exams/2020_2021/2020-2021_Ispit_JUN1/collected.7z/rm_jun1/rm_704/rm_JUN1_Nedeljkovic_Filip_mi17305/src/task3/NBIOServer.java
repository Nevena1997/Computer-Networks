package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {
    private final static  int PORT = 12345;
    public static void main(String[] args) {

        List<String> deck = Collections.synchronizedList(new LinkedList<>());

        for(int i=0; i<52; i++){
            int cardNum = new Random().nextInt(13) + 2;
            int cardSign = new Random().nextInt(4)+ 1;
            String sign;


            if(cardSign == 1){
                sign = "Pik";
            }else if(cardSign == 2){
                sign = "Karo";
            }else if(cardSign == 3){
                sign = "Tref";
            }else{
                sign = "Herc";
            }

            String card = cardNum + "." + sign;
            deck.add(card);

        }

        for(String c : deck){
            System.out.println(c);
        }

        int numOfCards = 0;

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.exit(1);
            }


            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();
                Set<SelectionKey> readyKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = readyKeys.iterator();

                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                            ByteBuffer buf = ByteBuffer.allocate(5*2 + 4);
                            clientKey.attach(buf);
                        }else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();
                            buf.clear();
                            client.read(buf);
                            if(!buf.hasRemaining()){
                                buf.flip();
                                while(buf.hasRemaining()){
                                    numOfCards = buf.getInt();
                                }
                                System.out.println(numOfCards);
                                buf.clear();

                                if(numOfCards <= deck.size()) {

                                    String card = deck.remove(numOfCards);
                                    numOfCards--;
                                    buf.put(card.getBytes());
                                    buf.put((byte)'\n');

                                }else {
                                    String message = "Spil nema dovoljno karata";
                                    buf.put(message.getBytes());
                                    }
                                buf.flip();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }




                        }else if(key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            if(!buf.hasRemaining()) {
                                if (numOfCards > 0) {
                                    buf.clear();
                                    String card = deck.remove(numOfCards);
                                    numOfCards--;
                                    System.out.println(card);
                                    System.out.println(numOfCards);
                                    buf.put(card.getBytes());
                                    buf.put((byte) '\n');
                                    buf.flip();
                                }
                                client.write(buf);
                            }
                        }




                        }
                    catch (IOException ex){
                        key.cancel();
                        key.channel().close();
                        ex.printStackTrace();
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

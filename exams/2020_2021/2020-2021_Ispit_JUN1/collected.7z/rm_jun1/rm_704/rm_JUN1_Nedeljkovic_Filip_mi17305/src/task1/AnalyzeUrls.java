package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Scanner;

public class AnalyzeUrls implements Runnable {

    Scanner sc;
    Path txtFile;

    public AnalyzeUrls(Path p) throws IOException {
        this.txtFile = p;
        this.sc = new Scanner(txtFile);
    }

    @Override
    public synchronized void  run() {
        while(sc.hasNextLine()){
            String line = sc.nextLine();
            try {
                URL u = new URL(line.trim());

                    if (u.getHost().indexOf(':') != -1) {
                        System.out.println("v6" + " " + u.getProtocol() + " " + u.getPath());
                    } else if (u.getHost().chars().anyMatch(c -> Character.isDigit(c))){
                        System.out.println("v4" + " " + u.getProtocol() + " "  + u.getPath() + " " + "[" + u.getHost() + "]");
                    } else {
                        System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());
                    }




            } catch (MalformedURLException e) {
                continue;
            }
        }


    }


}

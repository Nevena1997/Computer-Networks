package task1;

import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.util.Scanner;

public class Task1Main implements Runnable{
    File f = new File("/home/ispit/Desktop/tests/urls/2.txt");
    public static void main(String[] args){
        try (Scanner sc = new Scanner(System.in)){


            new Thread(new Task1Main()).start();
        }
    }
    //File f = new File("putanja");
    private Socket s;
    //private URL u;

    public Task1Main() {
        this.s = s;
        //this.u = u;
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f)))){
            while (true) {
                String line = reader.readLine();
                URL url = new URL(line);
                //line = line.replace(":", " ");
                line = line.replaceAll("://", " ");

                //System.out.println("Ispiti liniju2222: " + url);
                //if (url.equals("http") || url.equals("sftp") || url.equals("https") || url.equals("ftp")) {
                  //  System.out.println("Ispiti liniju: " + url.toString());
                //}
                System.out.println("" + line.toString());

                /*if (line.equals("http")) {
                    System.out.println("Ispiti liniju: " + line);
                }*/

                /*URL url= new URL();
                if (url == null) {
                    break;
                }*/
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

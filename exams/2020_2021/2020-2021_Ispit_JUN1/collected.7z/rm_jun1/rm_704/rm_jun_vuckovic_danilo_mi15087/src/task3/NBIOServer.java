package task3;



import javax.print.DocFlavor;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;


public class NBIOServer {

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            server.bind(new InetSocketAddress(12345));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()) {
                        ServerSocketChannel s = (ServerSocketChannel) key.channel();
                        SocketChannel client = s.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buf = ByteBuffer.allocate(52);
                        clientKey.attach(buf);
                    } else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buf = (ByteBuffer) key.attachment();

                        client.read(buf);
                        if (buf.hasRemaining()) {
                            String line = new String(buf.array(), 0, buf.array().length);
                            System.out.println("line on server" + line);

                            Integer d = Integer.parseInt(line);
                            buf.clear();
                            buf.putInt(d);
                            buf.flip();
                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                    } else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buf = (ByteBuffer) key.attachment();

                        Integer n = buf.getInt();
                        buf.flip();
                        //HashMap<Integer, String> mapa = new HashMap<>();
                        //Map<Integer, String> mapa1 = new HashMap<>();
                        //String[] words = new String[herc, karo, tref, pik];
                        //Integer[] brojevi = new Integer[1, 2, 3, 4];
                        //String[] reci = new String[];
                        List<Integer> lista = null;
                        lista.add(2);
                        lista.add(3);
                        lista.add(4);
                        lista.add(5);
                        lista.add(6);
                        lista.add(7);
                        lista.add(8);
                        lista.add(9);
                        lista.add(10);
                        lista.add(11);
                        lista.add(12);
                        lista.add(13);
                        lista.add(14);
                        List<String> linkedList = null;

                        linkedList.add("karo");
                        linkedList.add("herc");
                        linkedList.add("tref");
                        linkedList.add("pik");



                        Random r = new Random();
                        int k = r.nextInt();
                        //System.out.println("r" + r);
                        //System.out.println(lista.iterator() + "." + linkedList.iterator());
                        for (int i = 0; i < k; i++) {
                            System.out.println();
                        }

                        byte[] bytes = buf.array();

                        ByteBuffer b = ByteBuffer.allocate(512);
                        b.clear();
                        b.put(bytes);
                        b.flip();
                        client.write(b);
                        key.interestOps(SelectionKey.OP_READ);
                    }
                }
            }


        } catch (ClosedChannelException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

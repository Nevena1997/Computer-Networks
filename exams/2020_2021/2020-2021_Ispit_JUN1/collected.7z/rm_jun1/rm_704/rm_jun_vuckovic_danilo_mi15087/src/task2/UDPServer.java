package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

public class UDPServer {

    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket(12345)){
            byte[] buf = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            ds.receive(packet);

            String s = new String(packet.getData(), 0, packet.getLength());
            //for (int i = 0; s.length(); i++) {
            String[] words = s.split(" ");
            String[] words1;
            /*for (int i =0; ;i++) {
                if (words[i].isBlank())
                    words1[i] = " ";
            }*/



            DatagramPacket respond = new DatagramPacket(packet.getData(), packet.getLength(), packet.getAddress(), packet.getPort());
            ds.send(respond);

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Hello from UDPServer");
    }

}

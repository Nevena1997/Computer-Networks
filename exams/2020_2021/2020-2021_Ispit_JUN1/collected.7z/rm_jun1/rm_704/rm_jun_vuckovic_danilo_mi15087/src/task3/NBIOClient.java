package task3;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
        try (Socket client = new Socket(InetAddress.getLocalHost(), 12345);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in)){

                 while (true) {
                     System.out.println("Ucitaj broj");
                     //String line = sc.nextLine();
                     Integer n = Integer.parseInt(sc.nextLine());

                     if (n < 1) {
                         writer.write("Ne sme manje od 1");
                         writer.newLine();
                         writer.flush();
                         break;
                     }

                     writer.write(Integer.toString(n));
                     writer.newLine();
                     writer.flush();



                     String line = reader.readLine();
                     System.out.println(line);

                 }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket();
             Scanner sc = new Scanner(System.in)){

            while (true) {
                byte[] buf = new byte[1024];
                String line = sc.nextLine();
                //System.out.println("line: " + line.toString());
                int n = line.length();
                for (int i = 0; i < n; i++) {
                   if (line.charAt(i) == 'a') {
                       System.out.println(".-");
                   } else if (line.charAt(i) == 'b') {
                       System.out.println("-..");
                   } else if (line.charAt(i) == 'c') {
                       System.out.println("-.-.");
                   }else if (line.charAt(i) == 'd') {
                       System.out.println("-..");
                   }else if (line.charAt(i) == 'e') {
                       System.out.println(".");
                   }else if (line.charAt(i) == 'f') {
                       System.out.println("..-.");
                   }else if (line.charAt(i) == 'g') {
                       System.out.println("--.");
                   }else if (line.charAt(i) == 'h') {
                       System.out.println("....");
                   }else if (line.charAt(i) == 'i') {
                       System.out.println("..");
                   }else if (line.charAt(i) == 'j') {
                       System.out.println(".---");
                   }else if (line.charAt(i) == 'k') {
                       System.out.println("-.-");
                   }else if (line.charAt(i) == 'l') {
                       System.out.println(".-..");
                   }else if (line.charAt(i) == 'm') {
                       System.out.println("--");
                   }else if (line.charAt(i) == 'n') {
                       System.out.println("-.");
                   }else if (line.charAt(i) == 'o') {
                       System.out.println("---");
                   }else if (line.charAt(i) == 'p') {
                       System.out.println(".--.");
                   }else if (line.charAt(i) == 'q') {
                       System.out.println("--.-");
                   }else if (line.charAt(i) == 'r') {
                       System.out.println(".-.");
                   }else if (line.charAt(i) == 's') {
                       System.out.println("...");
                   }else if (line.charAt(i) == 't') {
                       System.out.println("-");
                   }else if (line.charAt(i) == 'u') {
                       System.out.println("..-");
                   }else if (line.charAt(i) == 'v') {
                       System.out.println("...-");
                   }else if (line.charAt(i) == 'w') {
                       System.out.println(".--");
                   }else if (line.charAt(i) == 'x') {
                       System.out.println("-..-");
                   }else if (line.charAt(i) == 'y') {
                       System.out.println("-.--");
                   }else if (line.charAt(i) == 'z') {
                       System.out.println("--..");
                   }else if (line.charAt(i) == '0') {
                       System.out.println("-----");
                   }else if (line.charAt(i) == '1') {
                       System.out.println(".----");
                   }else if (line.charAt(i) == '2') {
                       System.out.println("..---");
                   }else if (line.charAt(i) == '3') {
                       System.out.println("...--");
                   }else if (line.charAt(i) == '4') {
                       System.out.println("....-");
                   }else if (line.charAt(i) == '5') {
                       System.out.println(".....");
                   }else if (line.charAt(i) == '6') {
                       System.out.println("-....");
                   }else if (line.charAt(i) == '7') {
                       System.out.println("--...");
                   }else if (line.charAt(i) == '8') {
                       System.out.println("---..");
                   }else if (line.charAt(i) == '9') {
                       System.out.println("----.");
                   }else if (line.charAt(i) == '.') {
                       System.out.println(".-.-.-");
                   }else if (line.charAt(i) == ',') {
                       System.out.println("--..--");
                   }else if (line.charAt(i) == '?') {
                       System.out.println("..--..");
                   }else if (line.charAt(i) == '`') {
                       System.out.println(".----.");
                   }else if (line.charAt(i) == '!') {
                       System.out.println("-.-.--");
                   }
                }
                System.out.println(".-.-.-");
                DatagramPacket packet = new DatagramPacket(line.getBytes(), 0, line.getBytes().length, InetAddress.getLocalHost(), 23456);
                ds.send(packet);

                DatagramPacket recieve = new DatagramPacket(buf, buf.length);
                ds.receive(recieve);

                System.out.println("line" + line.toString());
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Hello from UDPClient");
    }

}

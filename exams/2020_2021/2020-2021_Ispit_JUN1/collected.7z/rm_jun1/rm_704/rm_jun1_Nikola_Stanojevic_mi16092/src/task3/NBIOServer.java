package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class NBIOServer {

    enum Znak {
        PIK,
        HERC,
        KARO,
        TREF
    }

    static class Karta{
        private int vrednost;
        private Znak znak;

        Karta(int vrednost, Znak znak){
            this.vrednost = vrednost;
            this.znak = znak;
        }

        @Override
        public String toString() {
            return this.vrednost + "." + this.znak + "\n";
        }
    }

    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {



        try(
            ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            System.out.println("Server running on port: " + DEFAULT_PORT);

            var spil = generisiSpil();
            for(var karta: spil){
                System.out.println(karta);
            }

            int requstedCardsNumber = 0;

            while(true) {

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {

                        SelectionKey key = it.next();
                        it.remove();
                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            System.out.println("Client connected!");
                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_READ);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            if(requstedCardsNumber <= 1 || requstedCardsNumber > spil.size()){
                                String message = "Los broj";
                                ByteBuffer buffer = ByteBuffer.wrap(message.getBytes(StandardCharsets.UTF_8));
                                buffer.flip();
                                client.write(buffer);
                            }else {
                                StringBuilder sb = new StringBuilder();

                                List<Karta> izabraneKarte = new ArrayList<>();
                                for (int i = 0; i < requstedCardsNumber; i++) {
                                    Karta karta = spil.get(0);
                                    spil.remove(0);
                                    izabraneKarte.add(karta);
                                    sb.append(karta.toString());
                                }
                                ByteBuffer buff = ByteBuffer.wrap(sb.toString().getBytes());
                                while(!buff.hasRemaining())
                                    client.write(buff);
                            }
                            key.cancel();
                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer buffer = ByteBuffer.allocate(4);
                            client.read(buffer);

                            buffer.rewind();
                            requstedCardsNumber = buffer.getInt();
                            System.out.println("Klijent je trazio " + requstedCardsNumber + " karata");

                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                    } catch (IOException ex){
                        key.cancel();
                        try{
                            key.channel().close();
                        } catch (IOException cex){
                            cex.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<Karta> generisiSpil(){
        var spil = new ArrayList<Karta>();
        for(int i=2; i<=14; i++){
            for(Znak z: Znak.values()){
                spil.add(new Karta(i, z));
            }
        }
        return spil;
    }

}

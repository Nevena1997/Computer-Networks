package task3;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try(
            Socket client = new Socket("localhost", NBIOServer.DEFAULT_PORT);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
        ){
            System.out.println("Connected to server");

            Scanner sc = new Scanner(System.in);
            int cardsNumber = sc.nextInt();

            client.getOutputStream().write(ByteBuffer.allocate(4).putInt(cardsNumber).array());

            String message = fromServer.readLine();
            System.out.println(message);


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UDPServer {

    public static final int DEFAULT_PORT = 23456;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){

            while(true){

                byte[] buffer = new byte[1024];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                server.receive(request);

                String message = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);

                String cryptedMessage = cryptMessage(message);

                byte[] sendBuffer = cryptedMessage.getBytes();
                DatagramPacket response = new DatagramPacket(sendBuffer, sendBuffer.length, request.getAddress(), request.getPort());
                server.send(response);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static String cryptMessage(String message) {

        var mapa = getMorseMap();

        StringBuilder sb = new StringBuilder();
        var words = message.split(" ");
        for(String word : words){
            for(var c: word.split("")){
                sb.append(mapa.get(c.toLowerCase().charAt(0)));
                sb.append(" ");
            }
            sb.append("   ");
        }
        sb.append(".-.-.-");

        return sb.toString();
    }

    public static Map<Character, String> getMorseMap(){
        Map<Character, String> map = new HashMap<>();
        Path pathToMap = Paths.get("morse.txt");
        List<String> lines = null;
        try {
            lines = Files.readAllLines(pathToMap);
            for(String line: lines){
                var character = line.charAt(0);
                var code = line.substring(2);
                map.put(character, code);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }

}

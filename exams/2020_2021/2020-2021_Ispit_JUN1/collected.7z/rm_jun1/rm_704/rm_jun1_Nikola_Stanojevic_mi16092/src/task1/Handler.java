package task1;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.regex.Pattern;

public class Handler extends  Thread {

    private Path path;

    Handler(Path path){
        this.path = path;
    }

    @Override
    public void run() {
        try {
            var lines = Files.readAllLines(path);

            for(String line: lines){
                try {
                    URL url = new URL(line);
                    StringBuilder sb = new StringBuilder();

                    var adresa = url.getHost();

                    boolean ipv4 = false;
                    boolean ipv6 = false;

                    var prvaTacka = adresa.indexOf('.');
                    var prviDeoIpv4 = adresa.substring(0, prvaTacka);

                    try{
                        int x = Integer.parseInt(prviDeoIpv4);
                        if(x > 0 && x < 256){
                            ipv4 = true;
                        }
                    } catch (NumberFormatException ex) {

                    }

                    var prvaDvotacka = adresa.indexOf(':');
                    if(prvaDvotacka > 0) {
                        var prviDeoIpv6 = adresa.substring(0, prvaDvotacka);
                        try {
                            int x = Integer.parseInt(prviDeoIpv6);
                            ipv6 = true;
                        } catch (NumberFormatException ex) {

                        }
                    }
                    sb.append(url.getProtocol());
                    sb.append(" ");
                    sb.append(url.getAuthority());
                    sb.append(" ");
                    sb.append(url.getPath());

                    sb.append("\n");

                    if(ipv4 || ipv6){
                        sb.append("(v4) ");
                        sb.append(url.getProtocol());
                        sb.append(" ");
                        sb.append(url.getPath());
                        sb.append(" ");

                        String bajtovi;
                        if(ipv4){
                            bajtovi = url.getHost().replace('.', ' ');
                        } else{
                            bajtovi = url.getHost().replace(':', ' ');
                        }
                        if(url.getProtocol().equalsIgnoreCase("http") || url.getProtocol().equalsIgnoreCase("https")) {
                            sb.append("[ ");
                            sb.append(bajtovi);
                            sb.append(" ]");
                        }
                        sb.append("\n");
                    }

                    System.out.println(sb.toString());


                } catch (MalformedURLException ex){
                    continue;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

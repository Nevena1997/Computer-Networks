package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket()){

            Scanner sc = new Scanner(System.in);
            String message = sc.nextLine();

            byte[] buffer = message.getBytes(StandardCharsets.UTF_8);

            DatagramPacket request = new DatagramPacket(buffer, buffer.length, InetAddress.getByName("localhost"), UDPServer.DEFAULT_PORT);
            client.send(request);

            byte[] receiveBuffer = new byte[1024];
            DatagramPacket response = new DatagramPacket(receiveBuffer, receiveBuffer.length);
            client.receive(response);

            String cryptedMessage = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);
            System.out.println(cryptedMessage);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {

        Path startingDirectory = Paths.get("/home/ispit/Desktop/tests/urls");
        try {
            DirectoryStream<Path> ds = Files.newDirectoryStream(startingDirectory);
            for (Path p : ds) {
                if (Files.isRegularFile(p)) {
                    var fileHandler = new Handler(p);
                    fileHandler.start();
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

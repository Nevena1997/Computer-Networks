package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class NBIOClient {
    public static int PORT = 12345;

    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", PORT));
             Scanner sc = new Scanner(System.in);
        ) {
            ByteBuffer buf = ByteBuffer.allocate(1024);
            while (true) {

                String line = sc.next();

                buf.put(line.getBytes(StandardCharsets.UTF_8));
                buf.flip();
                client.write(buf);

                buf.clear();

                client.read(buf);
                String odgovor_servera = new String(buf.array(), 0, buf.position());
                System.out.println(odgovor_servera);
//                if (client.read(buf) != -1) {
//                    odgovor_servera = new String(buf.array(), 0, buf.position());
//                    System.out.println(odgovor_servera);
//                }

                buf.clear();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static int PORT = 23456;

    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket()) {
            while (true) {
                Scanner sc = new Scanner(System.in);
                String line = sc.nextLine();
                byte[] buf = line.getBytes(StandardCharsets.UTF_8);
                DatagramPacket request = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), PORT);
                client.send(request);

                DatagramPacket response = new DatagramPacket(new byte[512], 512);
                client.receive(response);

                String answerFromServer = new String(response.getData(), 0, response.getLength());
                System.out.println(answerFromServer);

            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

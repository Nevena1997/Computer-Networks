package task2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static int PORT = 23456;
    static Map<String, String> morse = new HashMap<>();

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(new FileInputStream("/home/ispit/Desktop/rm_jun1_Vujinovic_Djordje_mi17481/morse.txt"))) {
            while (sc.hasNext()) {
                String c = sc.next();
                String c_morse = sc.next();
                morse.put(c, c_morse);
            }
//            morse.forEach((k,v) -> System.out.println(k + " " + v));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        try (DatagramSocket server = new DatagramSocket(PORT)) {
            while (true) {
                byte[] buf = new byte[512];
                DatagramPacket request = new DatagramPacket(buf, buf.length);
                server.receive(request);

                String requestFromClient = new String(request.getData(), 0, request.getLength()).toLowerCase();

                String answerToClient = "";
                for (int i = 0; i < requestFromClient.length(); i++) {
                    if (requestFromClient.charAt(i) == ' ') {
                        answerToClient += "   ";
                        continue;
                    }
                    answerToClient += morse.get(String.valueOf(requestFromClient.charAt(i))) + " ";
                }

                answerToClient += ".-.-.-";

                buf = answerToClient.getBytes(StandardCharsets.UTF_8);
                DatagramPacket response = new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                server.send(response);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

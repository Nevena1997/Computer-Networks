package task1;

import java.nio.file.DirectoryStream;
import java.nio.file.Path;

public class Task1Main {
    public static String pathToFolder = "/home/ispit/Desktop/tests/urls/";

    public static void main(String[] args) {
        for (int i = 1; i <= 4; i++) {
            String file = pathToFolder + i + ".txt";
            new Thread(new FileRunnable(file)).start();
        }
    }

    //  izvinjavam sto sam ovo hardkodovao, nikako nisam mogao da se setim kako se ovo radi sa DirectoryStream
//    private static void walk(String pathToFolder) {
//    }
}

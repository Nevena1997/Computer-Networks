package task1;

import java.io.*;
import java.net.*;

public class FileRunnable implements Runnable {
    String pathToFile;

    FileRunnable(String pathToFile) {
        this.pathToFile = pathToFile;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.pathToFile)))) {
            String line;
            while ((line = in.readLine()) != null) {
                try {
                    URL u = new URL(line);

//                    int ipStandard = isItAddress(u.getHost());
                    ispisi(u ,0);
                } catch (MalformedURLException ex) {

                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    private int isItAddress(String host) {
//        System.out.println(host);
//        if (host.contains(":")) {
//            return 6;
//        } else {
//            try {
//                String[] parsed = host.split(".");
//                if (parsed.length == 0)
//                    return 0;
//                Integer.valueOf(parsed[parsed.length-1]);
//                return 4;
//            } catch (NumberFormatException e) {
//                return 0;
//            }
//        }
//    }

    private synchronized void ispisi(URL u, int ipstandard) {
//        if (ipstandard == 0) {
//            System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getFile());
//        } else if (ipstandard == 4) {
//            System.out.println("ipv4 " + u.getProtocol() + " " + u.getAuthority() + " " + u.getFile());
//        } else if (ipstandard == 6) {
//            System.out.println("ipv6 " + u.getProtocol() + " " + u.getAuthority() + " " + u.getFile());
//        }
        System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getFile());

    }


}

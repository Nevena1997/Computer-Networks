package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class NBIOServer {

    public static int PORT = 12345;
    static ArrayList<String> cards = new ArrayList<>(52);


    public static void main(String[] args) {
        fillCards();

        Collections.shuffle(cards);

        for (int i = 0; i < cards.size(); i++) {
            System.out.println(cards.get(i));
        }

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {
            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            SocketChannel client = serverChannel.accept();
                            ByteBuffer buf = ByteBuffer.allocate(1024);

//                            System.out.println("Klijent je prihvacen");
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                            clientKey.attach(buf);
                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer)key.attachment();

                            client.read(buf);
                            String zahtev_klijenta = new String(buf.array(), 0, buf.position());

                            int broj_karata = Integer.parseInt(zahtev_klijenta);

                            String odgovor_klijentu = "";
                            if (broj_karata > cards.size() || broj_karata < 1) {
                                odgovor_klijentu = "Nema dovoljno karata u spilu ili ste upisali broj manji od 1";
                            } else {
                                // Sve radi ok dok ne ostanu 4 karte, ne znam u cemu je problem
                                // Exception in thread "main" java.lang.IndexOutOfBoundsException: Index 4 out of bounds for length 4
                                for (int i = 0; i < broj_karata; i++) {
                                    String karta = cards.get(i);
                                    cards.remove(i);
                                    odgovor_klijentu += karta + " ";
                                }
//                                System.out.println(cards.size());
                            }

                            buf.clear();
                            buf.put(odgovor_klijentu.getBytes(StandardCharsets.UTF_8));
                            key.interestOps(SelectionKey.OP_WRITE);

                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer)key.attachment();

                            buf.flip();
                            client.write(buf);
                            buf.clear();
                            key.interestOps(SelectionKey.OP_READ);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void fillCards() {
        int value = 0;
        String znak = "";
        for (int i = 1; i < 14; i++) {
            for (int j = 0; j < 4; j++) {
                value = i;
                if (i == 1) {
                    value = 14;
                }

                if (j == 0)
                    znak = "Pik";
                else if (j == 1)
                    znak = "Herc";
                else if (j == 2)
                    znak = "Tref";
                else if (j == 3)
                    znak = "Karo";

                cards.add(value + "." + znak);
            }
        }
    }


}

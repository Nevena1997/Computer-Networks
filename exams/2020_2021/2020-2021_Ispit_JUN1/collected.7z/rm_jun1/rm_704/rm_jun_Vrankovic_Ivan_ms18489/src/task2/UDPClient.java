package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

public class UDPClient {


    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("Klijent: ");
            String msg = userIn.readLine().trim();
            byte[] buf = msg.getBytes();
            DatagramPacket request = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), UDPServer.PORT);
            socket.send(request);

            DatagramPacket receive = new DatagramPacket(buf, 0, request.getLength(), request.getSocketAddress());
            socket.receive(receive);
            String receivedMsg = new String(receive.getData(), 0, receive.getLength());
            System.out.print("Server: " + receivedMsg);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

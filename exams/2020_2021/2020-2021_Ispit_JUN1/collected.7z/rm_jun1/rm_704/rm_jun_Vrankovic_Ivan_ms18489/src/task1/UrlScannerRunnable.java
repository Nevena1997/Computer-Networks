package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.stream.Stream;

public class UrlScannerRunnable implements Runnable {
    private Path path;

    public UrlScannerRunnable(Path path) throws MalformedURLException {
        this.path = path;
    }

    @Override
    synchronized public void run() {
        try {
            Scanner sc = new Scanner(path);
            while (sc.hasNextLine()) {
                URL url = new URL("http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt");
                try {
                    String  line = sc.nextLine();
                    url = new URL(line);
                } catch (MalformedURLException e) {
                    continue;
                }
                String protocol = url.getProtocol();
                String authority = url.getAuthority();
                String path = url.getPath();
                String host = url.getHost();

                if(getVersion(host) == null)
                    System.out.println(protocol + " " + authority + " " + path);
                else
                    System.out.println(getVersion(host) + " " + protocol + " " + path + " " + host.getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getVersion(String path) {
        if(path.getBytes().length == 4)
            return "(v4)";
        else if(path.getBytes().length == 6)
            return "(v6)";
        else
            return null;
    }

    public String getBytes(String path) {
        if (getVersion(path).equals("(v4)"))
            return path.getBytes().toString();
        else
            return "";
    }
}

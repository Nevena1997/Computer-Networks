package task3;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;

public class NBIOClient {

    public static void main(String[] args) {
        try(SocketChannel client = SocketChannel.open()) {

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

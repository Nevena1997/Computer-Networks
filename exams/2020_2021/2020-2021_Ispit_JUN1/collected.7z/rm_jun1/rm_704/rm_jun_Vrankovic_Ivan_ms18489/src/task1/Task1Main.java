package task1;

import java.io.IOException;
import java.nio.file.Path;

public class Task1Main {
    public static void main(String[] args) {
        try {
            new Thread(new UrlScannerRunnable(Path.of("src/task1/1.txt"))).start();
            new Thread(new UrlScannerRunnable(Path.of("src/task1/2.txt"))).start();
            new Thread(new UrlScannerRunnable(Path.of("src/task1/3.txt"))).start();
            new Thread(new UrlScannerRunnable(Path.of("src/task1/4.txt"))).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

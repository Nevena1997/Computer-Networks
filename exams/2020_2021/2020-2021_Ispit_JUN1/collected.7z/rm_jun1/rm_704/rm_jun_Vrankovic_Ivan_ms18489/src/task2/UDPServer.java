package task2;

import javax.xml.crypto.Data;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

public class UDPServer {
    public static final int PORT = 23456;
    public final static String HOST = "localhost";

    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(PORT);
             Scanner url = new Scanner(Path.of("morse.txt"));
        ) {
            System.out.print("Server: ");
            while (true) {
                try {
                    byte[] buf = new byte[512];
                    DatagramPacket receive = new DatagramPacket(buf, buf.length);
                    server.receive(receive);

                    Map mapa = new HashMap<Character, String>();
                    while(url.hasNextLine()) {
                        String line = url.nextLine();
                        String[] s1 = line.split(" ");
                        mapa.put(s1[0].trim().toCharArray()[0], s1[1].trim());
                    }

                    String msg = new String(buf, 0, receive.getLength());
                    System.out.println(msg);
                    /*Stream
                            .of(msg)
                            .forEach(e -> System.out.print(mapa.get(e.toString()) + " "));*/

                    StringBuilder s = new StringBuilder();

                    for (char p : msg.toCharArray()) {
                        if(Character.isSpaceChar(p))
                            s.append("  ");
                        s.append(mapa.get(p) + " ");
                    }
                    System.out.println(s);
                    buf = s.toString().getBytes();
                    DatagramPacket response = new DatagramPacket(buf, 0, buf.length, receive.getSocketAddress());
                    server.send(response);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

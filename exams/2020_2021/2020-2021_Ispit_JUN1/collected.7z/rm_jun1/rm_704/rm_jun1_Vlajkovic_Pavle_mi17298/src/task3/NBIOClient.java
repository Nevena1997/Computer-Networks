package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost",NBIOServer.DEFAULT_PORT));
            Scanner sc = new Scanner(System.in);
        ){
            ByteBuffer buffer = ByteBuffer.allocate(1024);

            buffer.putInt(sc.nextInt());
            buffer.flip();
            client.write(buffer);

            ByteBuffer buff1 = ByteBuffer.allocate(1024);
            client.read(buff1);
            buff1.flip();

            System.out.println(new String(buff1.array(),0,buff1.limit()));
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
}

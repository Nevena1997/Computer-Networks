package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static int DEFAULT_PORT = 23456;
    private static Map<Character,String> morse;


    public static void main(String[] args) {
        loadMorse();

        try(DatagramSocket server = new DatagramSocket(new InetSocketAddress(DEFAULT_PORT))){

              byte[] buffer = new byte[2048];
              DatagramPacket packet = new DatagramPacket(buffer, 0, buffer.length);
              server.receive(packet);

              String message = new String(buffer,0,packet.getLength());
              String codedMessage = codeToMorse(message);

              byte[] buffer1 = codedMessage.getBytes();
              DatagramPacket toClient = new DatagramPacket(buffer1,0,buffer1.length,packet.getSocketAddress());
              server.send(toClient);
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }


    private static void loadMorse(){
        morse = new HashMap<>();

        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File("morse.txt"))))){

            reader.lines()
                    .forEach(line ->{
                        char symbol = line.charAt(0);
                        String key = line.substring(2);
                        morse.put((Character)symbol,key);
                    });

        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

    private static String codeToMorse(String message){
        String result = "";
        for(int i=0;i<message.length()-1;i++){
            if(message.charAt(i) == ' ')
                result += " ";
            else{
                char curChar = message.charAt(i);
                if(Character.isDigit(curChar))
                    result += morse.get(curChar) + " ";
                else
                    result += morse.get(Character.toLowerCase(curChar)) + " ";
            }
        }

        return  result + ".-.-.-";
    }
}

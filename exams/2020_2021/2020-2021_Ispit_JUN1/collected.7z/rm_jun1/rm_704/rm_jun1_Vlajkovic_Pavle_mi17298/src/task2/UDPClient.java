package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPClient {


    public static void main(String[] args){

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){
            String message = sc.nextLine();
            byte[] buff = message.getBytes();
            DatagramPacket toServer =  new DatagramPacket(buff,0,buff.length,
                    new InetSocketAddress("localhost",UDPServer.DEFAULT_PORT));

            client.send(toServer);

            buff = new byte[2048];
            DatagramPacket fromServer = new DatagramPacket(buff,0,buff.length);
            client.receive(fromServer);


            System.out.println(new String(buff,0,fromServer.getLength()));
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }


}

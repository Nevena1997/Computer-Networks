package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;


public class ThreadHandler implements Runnable{

    private Path file;

    ThreadHandler(Path file){
        this.file = file;
    }

    @Override
    public void run(){

        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file.toFile())))){

            String curLine;
            while(true){
                curLine = reader.readLine();
                if(curLine == null)
                    break;

                URL curUrl;
                try{
                    curUrl = new URL(curLine);
                }
                catch(MalformedURLException e){
                    continue;
                }

                if(!curUrl.getAuthority().contains("www")){
                    String ip = curUrl.getAuthority();
                    if(ip.contains(":") && !ip.substring(0,ip.lastIndexOf(':')).contains(":") && countDot(ip) > 1)
                        System.out.println( "(v4)" + curUrl.getProtocol() + " " + curUrl.getAuthority() + " " + curUrl.getPath());
                    else if(ip.contains(":") && ip.substring(0,ip.lastIndexOf(':')).contains(":") ){
                        System.out.println( "(v4)" + curUrl.getProtocol() + " " + curUrl.getAuthority() + " " + curUrl.getPath());
                    }
                    else
                        System.out.println(curUrl.getProtocol() + " " + curUrl.getAuthority() + " " + curUrl.getPath());

                }
                else{
                    System.out.println(curUrl.getProtocol() + " " + curUrl.getAuthority() + " " + curUrl.getPath());
                }
            }


        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

    private int countDot(String str){
        int counter = 0;
        for(int i=0;i<str.length();i++)
            if(str.charAt(i) == '.')
                counter++;

        return counter;
    }

}

package task1;

import java.io.File;
import java.io.IOError;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    private static Set<Path> files;

    public static void main(String[] args) {

        files = Collections.synchronizedSet(new HashSet<>());
        getAllFiles();

        for(Path file: files)
            new Thread(new ThreadHandler(file)).start();

    }

    private static void getAllFiles(){
        try(DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get("tests/urls"))){

            Iterator<Path> it = ds.iterator();
            while(it.hasNext()){
                Path curFile = it.next();

                files.add(curFile);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }


    }


}

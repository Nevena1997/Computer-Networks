package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {

    public static int DEFAULT_PORT = 12345;
    private static Set<String> deck;

    public static void main(String[] args) {
        genDeck();

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector  = Selector.open()
        ){
            server.bind(new InetSocketAddress(DEFAULT_PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey curKey = it.next();
                    it.remove();

                    if(curKey.isAcceptable()){
                        ServerSocketChannel curServer = (ServerSocketChannel) curKey.channel();
                        SocketChannel client = curServer.accept();
                        client.configureBlocking(false);

                        SelectionKey clientsKey = client.register(selector,SelectionKey.OP_READ);
                        ByteBuffer buffer = ByteBuffer.allocate(1024);
                        clientsKey.attach(buffer);
                    }
                    else if(curKey.isReadable()){
                        SocketChannel client = (SocketChannel) curKey.channel();

                        ByteBuffer buff = (ByteBuffer) curKey.attachment();
                        client.read(buff);
                        buff.flip();

                        int received = buff.getInt();
                        String toSend = "";
                        int counter = 0 ;
                        for(String card: deck){
                            toSend += card + "\n";
                            counter++;
                            if(counter == received)
                                break;

                        }
                        ByteBuffer buff1 = ByteBuffer.wrap(toSend.getBytes());
                        curKey.attach(buff1);
                        curKey.interestOps(SelectionKey.OP_WRITE);
                    }
                    else if(curKey.isWritable()){
                        SocketChannel client = (SocketChannel) curKey.channel();


                        ByteBuffer buffer = (ByteBuffer) curKey.attachment();
                        while (buffer.hasRemaining())
                            client.write(buffer);

                        if(!buffer.hasRemaining()) {
                            client.close();
                        }
                    }
                }
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }


    private static void genDeck(){
        deck = new HashSet<>();


        for(int i=2;i<=14;i++){
            deck.add(i + "." + "herc");
            deck.add(i + "." + "pik");
            deck.add(i + "." + "tref");
            deck.add(i + "." + "karo");
        }

        for(String card: deck)
            System.out.println(card);

    }


}


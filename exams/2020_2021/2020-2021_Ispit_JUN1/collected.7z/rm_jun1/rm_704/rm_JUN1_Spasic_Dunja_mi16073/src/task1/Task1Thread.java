package task1;

import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.util.HashMap;

public class Task1Thread extends Thread {
    Path p;
    int count = 0;
    Task1Thread(Path p){this.p = p;}

    private boolean provera(String u)
    {
        try {
            URL url = new URL(u);
            return  true;
        }
        catch (MalformedURLException e)
        {
            return false;
        }
    }

    private String isIP(String u)
    {
        char first = u.charAt(0);
        if (first == '0' || first == '1' || first == '2' || first == '3' || first == '4' || first == '5' || first == '6' || first == '7'
                || first == '8' || first == '9')
        {
            if (u.indexOf(':') == -1)
            {
                return "(v4) ";
            }
            else return  "(v6) ";
        }
        else return "";

    }


    @Override
    public void run() {

        File input = new File(p.toString());
       try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(input))))
       {
            //System.err.println("uspesno otvoren\n");
            String line;

            while ((line = in.readLine()) != null)
            {
                if (provera(line) == true)
                {
                    URL url = new URL(line);

                    String protocol = url.getProtocol();
                    String authority = url.getAuthority();

                    System.err.println(isIP(url.getHost())+ protocol+" "+authority+ " "+ input.toString());

                }

            }

            //System.err.println(input.toString()+": "+count+"\n");
       }
       catch (IOException e)
       {
           e.printStackTrace();
       }

    }
}

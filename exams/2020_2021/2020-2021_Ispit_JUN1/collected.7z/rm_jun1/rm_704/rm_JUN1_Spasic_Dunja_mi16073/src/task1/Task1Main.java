package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Task1Main {

    static ArrayList<Thread> threads = new ArrayList<>();

    public static void main(String[] args) {

        Path pths = Paths.get("/home/ispit/Desktop/tests/urls");
        try{
            int i=0;
            for (Path p: Files.newDirectoryStream(pths)){
                BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())));
                i++;
                Task1Thread thrd = new Task1Thread(p);
                threads.add(thrd);
            }

            System.out.println(i+"\n");

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        for (Thread t: threads){
            t.start();
        }

        for (Thread t: threads){
           try{
               t.join();
           }
           catch (InterruptedException e)
           {
               System.err.println("Join interupted!\n");
               e.printStackTrace();
           }
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;

public class NBIOClient {

    public static void main(String[] args) {


        try(SocketChannel clientChannel = SocketChannel.open())
        {
            clientChannel.connect(new InetSocketAddress("localhost", NBIOServer.PORT));

            WritableByteChannel out= Channels.newChannel(System.out);
            ReadableByteChannel in = Channels.newChannel(System.in);

            ByteBuffer respondBuff = ByteBuffer.allocate(256);
            ByteBuffer recive = ByteBuffer.allocate(256);

            while (clientChannel.isConnected())
            {
                in.read(respondBuff);
            }





        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}

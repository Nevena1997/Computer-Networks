package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;

public class UDPServer {
    protected static int PORT = 23456;
    static HashMap<String, String> dict = new HashMap<>();

    static private String translate(String word)
    {
            String trans = "";
            for(int i=0; i<word.length();i++)
            {
                String key = word.charAt(i)+"";
                trans = trans+dict.get(key)+" ";
            }
        return trans;
    }

    public static void main(String[] args) {


        try(DatagramSocket server = new DatagramSocket(PORT))
        {
            byte[] receiveBuff = new byte[256];
            byte[] respondBuff = new byte[256];
            File file = new File("/home/ispit/Desktop/rm_JUN1_Spasic_Dunja_mi16073/morse.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

            String line;
            dict.put(" ", "  ");
            while((line = reader.readLine()) != null)
            {
                String key = (line.split(" ")[0]);
                String value = line.split(" ")[1];

                dict.put(key, value);
            }

            while (true){

                DatagramPacket receivePacket =
                        new DatagramPacket(receiveBuff, 0, receiveBuff.length);
                server.receive(receivePacket);
                String recive = new String(receiveBuff, 0, receiveBuff.length, StandardCharsets.UTF_8).trim();

                System.out.println(recive+"\n");
                InetSocketAddress address = (InetSocketAddress) receivePacket.getSocketAddress();

                String response = translate(recive);
                respondBuff = response.getBytes(StandardCharsets.UTF_8);
                DatagramPacket responsePacket = new DatagramPacket(respondBuff, 0, respondBuff.length, address);
                server.send(responsePacket);
            }





        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        //  System.out.println("Hello from UDPServer");
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket())
        {
            byte[] receiveBuff = new byte[256];
            byte[] respondBuff = new byte[256];
            Scanner sc = new Scanner(System.in);

            while (true)
            {
                String msg = sc.nextLine();
                msg = msg.toLowerCase();

                respondBuff = msg.getBytes(StandardCharsets.UTF_8);
                DatagramPacket respondPacket =
                        new DatagramPacket(respondBuff,   respondBuff.length, new InetSocketAddress("localhost", UDPServer.PORT));
                client.send(respondPacket);

                String response;

                DatagramPacket receivePacket = new DatagramPacket(receiveBuff, 0, receiveBuff.length);
                client.receive(receivePacket);
                response = new String(receiveBuff, 0, receiveBuff.length, StandardCharsets.UTF_8).trim();

                System.out.println(response+"\n");
            }



        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
       // System.out.println("Hello from UDPClient");
    }

}

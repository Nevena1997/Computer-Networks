package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;

public class NBIOServer {
    protected static int PORT = 12345;
    static ArrayList<String> spil = new ArrayList<>();

    public static void main(String[] args) {
        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector sel = Selector.open();)
        {
            //SocketAddress add = ;
            serverChannel.bind(new InetSocketAddress("localhost", PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(sel, SelectionKey.OP_ACCEPT);

            while(true)
            {
                sel.select();
                Iterator<SelectionKey> it = sel.selectedKeys().iterator();

                while (it.hasNext())
                {
                    SelectionKey sk = it.next();
                    it.remove();

                    if (sk.isAcceptable())
                    {
                        ServerSocketChannel server = (ServerSocketChannel) sk.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(true);

                        //client.register(sel, SelectionKey.OP_READ);

                    }
                    if (sk.isReadable())
                    {

                    }
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

       // System.out.println("Hello from NBIOServer");
    }

}

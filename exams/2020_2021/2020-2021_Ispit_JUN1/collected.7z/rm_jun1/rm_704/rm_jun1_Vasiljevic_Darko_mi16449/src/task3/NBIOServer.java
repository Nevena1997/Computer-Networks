package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class NBIOServer {

    public static final int PORT = 12345;
    private final int port;
    private final InetSocketAddress address;

    public static void main(String[] args) {

        System.out.println("Hello from NBIOServer");

        NBIOServer server = new NBIOServer(NBIOServer.PORT);
        server.start();
    }


    public NBIOServer(int port) {

        this.port = port;

        try {
            this.address = new InetSocketAddress(this.port);
        } finally {

        }
    }


    private void start() {

        try (ServerSocketChannel serverSocket = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            serverSocket.bind(this.address);
            serverSocket.register(selector, SelectionKey.OP_ACCEPT);
            serverSocket.configureBlocking(false);

            while(true){

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                try {
                    if(it.hasNext()) {

                        SelectionKey key = it.next();
                        it.remove();

                        if (key.isAcceptable()) {

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
                        }

                        else if(key.isReadable()){

                        }
                        else if(key.isWritable()){


                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

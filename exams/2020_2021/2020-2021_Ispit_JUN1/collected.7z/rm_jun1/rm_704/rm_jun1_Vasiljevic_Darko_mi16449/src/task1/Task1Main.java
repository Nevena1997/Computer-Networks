package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Task1Main {

    private static final String pathToTestDir = "/home/ispit/Desktop/tests/urls";

    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");

        try (DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get(Task1Main.pathToTestDir))){

            int numOfThreads = 0;
            for(Path path : ds)
            {
                //System.out.println(++numOfThreads + ". Thread started!");
                //System.out.println("File path: " + path);

                new Thread(new FileThread(path)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

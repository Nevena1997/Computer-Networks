package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    private final int port;
    private final String host;
    private final InetSocketAddress address;
    private int number;

    public static void main(String[] args)
    {
        System.out.println("Hello from NBIOClient");

        NBIOClient client = new NBIOClient("localhost", NBIOServer.PORT);
        client.start();
    }



    public NBIOClient(String host, int port) {

        this.host = host;
        this.port = port;

        try {
            this.address = new InetSocketAddress(this.port);
        } finally {

        }
    }

    private void start() {

        try ( SocketChannel client = SocketChannel.open(this.address);){

            this.ReadNumber();

            ByteBuffer buffer = ByteBuffer.allocate(256);
            client.write(buffer);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void ReadNumber() {

        try {
            Scanner sc = new Scanner(System.in);
             this.number = sc.nextInt();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {

    private final int port;
    private final String host;
    private InetAddress address;
    private String line;

    public static void main(String[] args) {

        System.out.println("Hello from UDPClient");

        UDPClient client = new UDPClient("localhost", UDPServer.PORT);
        client.start();
    }

   
    public UDPClient(String host, int port) {

        this.host = host;
        this.port = port;
        try {
            this.address = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    private void start() {

        try (DatagramSocket client = new DatagramSocket();
             BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in))){

            this.ReadFromStdin(stdin);

            ByteBuffer buffer = ByteBuffer.allocate(this.line.length());
            buffer.put(this.line.getBytes());


            DatagramPacket request = new DatagramPacket(buffer.array(), this.line.length(), this.address, this.port);
            client.send(request);
            
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void ReadFromStdin(BufferedReader stdin) throws IOException {

        System.out.println("Klijent: ");
        this.line = stdin.readLine();
    }


}

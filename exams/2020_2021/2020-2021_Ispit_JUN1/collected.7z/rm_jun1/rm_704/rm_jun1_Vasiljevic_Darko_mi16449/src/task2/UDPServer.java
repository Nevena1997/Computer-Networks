package task2;

import org.w3c.dom.ls.LSOutput;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Array;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class UDPServer {

    public static final int PORT = 23456;
    private static final String PATH = "/home/ispit/Desktop/rm_jun1_Vasiljevic_Darko_mi16449/morse.txt";
    private final int port;
    private final HashMap<String, String> mapa;
    private List<String> lines;
    private String filePath;

    public static void main(String[] args) {

        System.out.println("Hello from UDPServer");

        UDPServer server = new UDPServer(UDPServer.PORT);
        server.start();
    }

    public UDPServer(int port) {

        this.port = port;
        this.mapa = new HashMap<String, String>();
        this.filePath = UDPServer.PATH;
    }

    private void start() {

        try (DatagramSocket server = new DatagramSocket(this.port)){

            ByteBuffer buffer = ByteBuffer.allocate(256);

            while(true){

                DatagramPacket request = new DatagramPacket(buffer.array(), buffer.array().length);
                server.receive(request);

                String dataToTransform = new String(request.getData(), 0, request.getLength());
                //System.out.println(data);

                this.TransformString(dataToTransform);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void TransformString(String data) {

        this.ReadFileToMap();


    }

    private void ReadFileToMap() {

        try {

            this.lines = Files.readAllLines(Paths.get(this.filePath));
            this.lines.forEach(line -> line.split(" "));
            this.lines.forEach(l -> {

                String tmp =  l.split(" ").toString();
                this.mapa.put(tmp.substring(0, tmp.indexOf(" ")), tmp.substring(tmp.indexOf(" ")));
            });

            //this.mapa.forEach((e1, e2) -> System.out.println(e1 + e2));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

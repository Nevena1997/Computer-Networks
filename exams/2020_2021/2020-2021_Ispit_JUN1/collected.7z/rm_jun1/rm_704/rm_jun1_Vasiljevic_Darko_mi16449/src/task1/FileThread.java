package task1;

import org.w3c.dom.ls.LSOutput;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class FileThread extends Thread {

    private final Path filePath;
    private List<String> lines;
    private PrintWriter stdout;

    public FileThread(Path path) {
        
        this.filePath = path;
        this.lines = Collections.synchronizedList(new ArrayList<>());

        try {
            this.stdout = new PrintWriter(new OutputStreamWriter(System.out), false);

        } catch (Exception e) {
            this.stdout.close();
        }
    }

    @Override
    public void run() {

        try {
            stdout.println("\tFile path: " + filePath);

            this.ParseFile();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private synchronized void ParseFile() throws IOException {

        this.lines = Files.readAllLines(this.filePath);
        this.lines.forEach(line -> this.CreateUrl(line));
    }

    private void CreateUrl(String line) {

        try {
            URL url = new URL(line);
            this.ParseValidUrl(url);

        } catch (MalformedURLException e) {
            // bad URL
        }
    }

    private synchronized void ParseValidUrl(URL url) {

        String protocol = url.getProtocol();
        String authority = url.getAuthority();
        String path = url.getPath();

        if(!UrlHaveIP(protocol))
        {
            this.stdout.println(protocol + " " + authority + " " + path);
            this.stdout.flush();
        }
        else
        {
            //TODO: parse IP
        }
    }

    private boolean UrlHaveIP(String protocol) {

        // TODO: get IP

        return false;
    }
}

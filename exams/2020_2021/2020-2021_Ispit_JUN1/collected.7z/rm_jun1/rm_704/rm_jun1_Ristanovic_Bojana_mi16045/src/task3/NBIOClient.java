package task3;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", 12345);
             Scanner sc = new Scanner(System.in)
        ){

            int num = sc.nextInt();
            ByteBuffer buffer = ByteBuffer.allocate(512);
            buffer.put((byte) num);
            buffer.flip(); // read mode


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileSearch extends Thread {

    private Path file;
    public FileSearch(Path p) {
        this.file = p;
    }

    @Override
    public void run() {
        try (BufferedReader in = Files.newBufferedReader(this.file);){
            System.out.println("----- " + this.file.getFileName() + "-------");
            String line;
            while ((line = in.readLine()) != null){
                System.out.println(line);
                if (line.startsWith("http://") || line.startsWith("https://") ||
                        line.startsWith("ftp://") || line.startsWith("sftp://")
                ){
                    URL u = new URL(line);
                    String protocol = u.getProtocol();
                    String auth = u.getAuthority();
                    String path = u.getPath();
                    System.out.println(protocol + " " + auth + " " + path);
                }
            }

        } catch (IOException e) {
            System.out.println("Greska!!!");
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class NBIOServer {

    private static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ){

            if (!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Cannot opet server channel or selector");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()){
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        System.err.println("Server accepted client!");

                        client.configureBlocking(false);
                        client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buffer = ByteBuffer.allocate(512);
                        key.attach(buffer);
                    } else if (key.isWritable()){
                        continue;
                    } else if (key.isReadable()){
                        continue;
                    }

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

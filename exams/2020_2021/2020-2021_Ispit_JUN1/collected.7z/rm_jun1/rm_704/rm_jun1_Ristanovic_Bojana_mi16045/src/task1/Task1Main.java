package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {

//        System.out.println("Hello from Task1Main");
        try {
            Path dir = Paths.get("/home/ispit/Desktop/tests/urls");
//            DirectoryStream ds = Files.newDirectoryStream(dir);
            for (Path p: Files.newDirectoryStream(dir)){
                if (Files.isRegularFile(p)) {
                    Thread file = new Thread(new FileSearch(p));
                    file.start();
                    file.join();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

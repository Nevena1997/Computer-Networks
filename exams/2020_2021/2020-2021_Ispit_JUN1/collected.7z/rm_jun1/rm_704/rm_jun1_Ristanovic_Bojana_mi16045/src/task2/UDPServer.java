package task2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static final int DEFAULT_PORT = 23456;
    private Map<String, String> morseCode;

    public static void main(String[] args) {
//        System.out.println("Hello from UDPServer");
        UDPServer server = new UDPServer();
        server.execute();

    }
    
    public UDPServer(){
        this.morseCode = new HashMap<>();
        loadMorse(this.morseCode);
    }

    private void loadMorse(Map<String, String> morseCode) {
        try {
            Path file = Paths.get("morse.txt");
            BufferedReader in = Files.newBufferedReader(file);
            String line;
            while ((line = in.readLine()) != null){
                morseCode.put(line.split(" ")[0], line.split(" ")[1]);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void execute() {
        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){
            System.err.println("Server is listening... ");
            byte[] buff = new byte[1024];
            DatagramPacket request = new DatagramPacket(buff, buff.length);
            server.receive(request);
            System.err.println("Received packet!");

            String data = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < data.length(); i++){
                if (Character.isDefined(data.charAt(i))){
                    char c = data.charAt(i);
                    if (c == ' ') {
                        sb.append(' ');
                        sb.append(' ');
                        sb.append(' ');
                        continue;
                    }

                for (Map.Entry<String, String> k: this.morseCode.entrySet()){
                    if (k.getKey().equalsIgnoreCase(String.valueOf(c))){
                        sb.append(k.getValue());
                        sb.append(' ');
                        }
                    }
                }
            }

            sb.append("   .-.-.-");
            System.err.println(sb.toString());

            buff = sb.toString().getBytes();
            System.err.println(buff.length);

            DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
            server.send(response);
            System.err.println("Response sent!");

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

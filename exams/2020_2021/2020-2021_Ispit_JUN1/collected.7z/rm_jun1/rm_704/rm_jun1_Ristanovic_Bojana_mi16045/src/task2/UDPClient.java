package task2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
//        System.out.println("Hello from UDPClient");
        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)
        ){
            InetSocketAddress address = new InetSocketAddress(UDPServer.DEFAULT_PORT);

            byte[] buff;
            System.out.println("Enter text:");
            String line = sc.nextLine();
            buff = line.getBytes();
            DatagramPacket request = new DatagramPacket(buff, buff.length, address.getAddress(), address.getPort());
            client.send(request);
            System.err.println("Packet sent!");

            byte[] buff1 = new byte[512];
            DatagramPacket response = new DatagramPacket(buff1, buff1.length);
            client.receive(response);
            System.err.println("Response received!");

            System.out.println(new String(response.getData(), 0, response.getLength()));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

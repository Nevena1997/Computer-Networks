package task2;

public class UDPServer {

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");
    }

}

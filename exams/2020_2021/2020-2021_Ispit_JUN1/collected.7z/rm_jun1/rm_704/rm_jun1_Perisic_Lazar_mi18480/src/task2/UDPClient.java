package task2;


public class UDPClient {

    public static void main(String[] args) {

        System.out.println("Hello from UDPClient");






    }

}

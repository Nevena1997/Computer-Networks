package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static void createCode(Map<Character, String> code) {
        try(Scanner sc = new Scanner(new FileInputStream("morse.txt"))) {
            String line;
            while(sc.hasNext()) {
                line = sc.nextLine();
                code.put(line.charAt(0), line.substring(3).trim());
                // DEBUG
                // System.out.println(line.charAt(0));
                // System.out.println(line.substring(3).trim());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SocketException {
        Map<Character, String> code = new HashMap<>();
        createCode(code);

        try(DatagramSocket socket = new DatagramSocket(23456)) {
            while(true) {
                try {
                    byte[] bufReceive = new byte[4096];
                    DatagramPacket toReceive = new DatagramPacket(bufReceive, 0, bufReceive.length);
                    socket.receive(toReceive);

                    String msg = new String(toReceive.getData(), 0, toReceive.getLength());
                    String newMsg = encodeMessage(code, msg);

                    byte[] bufSend = newMsg.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket toSend = new DatagramPacket(bufSend, 0, bufSend.length,
                            toReceive.getAddress(), toReceive.getPort());
                    socket.send(toSend);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        }

    }

    private static String encodeMessage(Map<Character, String> code, String msg) {
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i <= msg.length(); i++) {
            sb.append(encodeChar(code, msg.charAt(i)));
        }

        return sb.toString();
    }

    private static String encodeChar(Map<Character, String> code, char c) {
        if (c == ' ')
            return "   ";
        else return code.get('c') + " ";
    }

}

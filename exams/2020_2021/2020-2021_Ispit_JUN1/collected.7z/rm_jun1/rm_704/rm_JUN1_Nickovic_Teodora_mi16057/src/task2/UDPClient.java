package task2;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) throws SocketException {
        try(DatagramSocket socket = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            String line = sc.nextLine();

            byte[] bufSend = line.getBytes(StandardCharsets.UTF_8);
            DatagramPacket toSend = new DatagramPacket(bufSend, 0, bufSend.length,
                                    InetAddress.getLocalHost(),23456);
            socket.send(toSend);

            // Wait for response
            byte[] bufReceive = new byte[4096];
            DatagramPacket toReceive = new DatagramPacket(bufReceive, 0, bufReceive.length);
            socket.receive(toReceive);
            String s = new String(toReceive.getData(), 0, toReceive.getLength());
            System.out.println(s);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task3;

public class Card {
    public int value;
    public String sign;

    Card(int value, String sign) {
        this.value = value;
        this.sign = sign;
    }

    @Override
    public String toString() {
        return this.value + "." + this.sign;
    }
}

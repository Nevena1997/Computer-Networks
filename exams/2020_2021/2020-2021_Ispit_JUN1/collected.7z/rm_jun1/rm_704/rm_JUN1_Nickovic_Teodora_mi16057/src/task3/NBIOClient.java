package task3;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) throws IOException {
        // TODO mozda nece moci u t-w-r bloku jer ce se zatvoriti, proveri kasnije
        try(Socket socket = new Socket("localhost", NBIOServer.DEFAULT_PORT)) {
            System.err.println("Connected to server.");

            try(BufferedOutputStream networkOut = new BufferedOutputStream(socket.getOutputStream());
                BufferedInputStream in = new BufferedInputStream(System.in))  {

                byte[] buf = new byte[4];
                in.read(buf);

                networkOut.write(buf);
                networkOut.flush();
            }
        }

    }

}

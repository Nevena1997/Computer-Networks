package task3;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class NBIOServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) throws IOException {
        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            boolean notifyClientBadNumber = false;
            Deck deck = new Deck();

            // u beskonacnoj petlji prolazimo kroz sve sto selektor nadje i obradjujemo
            while(true) {
                // selektuj
                selector.select();

                // prebaci u iterator
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                // prolazi kroz sve selektovane
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    // switch
                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            System.err.println("Accepted client.");

                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_READ);

                            deck.printRemaining();
                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buf = ByteBuffer.allocate(4);
                            //IntBuffer view = buf.asIntBuffer();
                            client.read(buf);


                            System.err.println(buf);
                            // System.err.println(view);

                            // int nCards = view.get();
                            int nCards = 0;
                            System.err.println(nCards);
                            if (nCards > deck.numRemaining() || nCards < 1) {
                                notifyClientBadNumber = true;
                            }

                            buf.clear();
                            //view.rewind();

                            // Treba attachovati bafer u koji pisemo karte
                            System.err.println("Server is sending " + nCards + " cards.");


                           // buf.putInt(nCards);
                            client.register(selector, SelectionKey.OP_WRITE);
                        } else if (key.isWritable()) {
                            ByteBuffer buf = (ByteBuffer) key.attachment();
                            if (buf == null) {
                                buf = ByteBuffer.allocate(4096);
                                key.attach(buf);
                            }

                            SocketChannel client = (SocketChannel)key.channel();

                            if (notifyClientBadNumber) {
                                String msg = "Bad number of cards!";
                                buf.put(msg.getBytes(StandardCharsets.UTF_8),
                                        0, msg.getBytes(StandardCharsets.UTF_8).length);
                                client.write(buf);
                            } else {
                                //SocketChannel client = (SocketChannel)key.channel();
                                //sendDeck();
                            }
                        }
                    } catch (IOException e) {
                        // TODO mozda i ne treba catch
                    }

                }
            }
        }
    }
}

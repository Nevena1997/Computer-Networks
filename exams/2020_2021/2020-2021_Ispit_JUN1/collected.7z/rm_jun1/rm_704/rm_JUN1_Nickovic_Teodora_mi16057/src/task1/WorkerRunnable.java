package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.locks.ReentrantLock;

public class WorkerRunnable implements Runnable {
    private Path path;
    private BufferedReader in;

    WorkerRunnable(Path path) {
        this.path = path;
        try {
            this.in = Files.newBufferedReader(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        String line;
        while(true) {
            try {
                line = this.in.readLine();
                if(line == null) {
                    break;
                }

                URL url;
                try {
                    url = new URL(line);
                } catch (MalformedURLException ex) {
                    System.err.println(line);
                    continue;
                }

                this.printStats(url);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void printStats(URL url) {
        StringBuilder sb = new StringBuilder("");
        if (url.getHost().contains(":")) {
            sb.append("(v6)    ");
        } else if (url.getHost().matches("[0-9]{0,3}.[0-9]{0,3}.[0-9]{0,3}.[0-9]{0,3}")){
            sb.append("(v4)    ");
        }
        sb.append(url.getProtocol() + "    " + url.getAuthority() + "    " + url.getFile());
        System.out.println(sb.toString());
    }
}

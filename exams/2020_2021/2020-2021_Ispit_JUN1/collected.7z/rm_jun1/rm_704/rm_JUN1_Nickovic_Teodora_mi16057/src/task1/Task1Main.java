package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {
        try {
            DirectoryStream<Path> dirStream = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/urls"));

            for (Path p : dirStream) {
                new Thread(new WorkerRunnable(p)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

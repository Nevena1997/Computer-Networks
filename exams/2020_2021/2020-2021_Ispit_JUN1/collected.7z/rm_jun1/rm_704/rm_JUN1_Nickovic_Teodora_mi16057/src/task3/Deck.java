package task3;

import java.util.*;
import java.util.stream.Collectors;

public class Deck {
    private List<Card> cards = new ArrayList<>();

    Deck() {
        for (int i = 2; i <= 14; i++) {
            this.cards.add(new Card(i, "Pik"));
            this.cards.add(new Card(i, "Herc"));
            this.cards.add(new Card(i, "Tref"));
            this.cards.add(new Card(i, "Karo"));
        }

        // Mozda treba na serveru ovo da se uradi, ali svejedno je posto cemo samo jedan
        // spil kreirati.
        Collections.shuffle(this.cards, new Random());
    }

    public List<Card> getCards(){
        return this.cards;
    }

    public List<Card> drawNCards(int n) {
        List<Card> selectedCards = this.cards.stream().limit(n).collect(Collectors.toList());
        return selectedCards;
    }

    public void printRemaining() {
        for (Card card : this.cards) {
            System.out.println(card);
        }
    }

    public int numRemaining() {
        return this.cards.size();
    }
}

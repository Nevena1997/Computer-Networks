package task1;

import java.io.File;

public class Task1Main {
    public static void main(String[] args) {


        File f=new File("/home/ispit/Desktop/tests/urls");
        String[] pathnames=f.list();

        for(String pathname : pathnames){

            new Thread(new Obradi(f,pathname)).start();

            try {
                Thread.sleep(400);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}

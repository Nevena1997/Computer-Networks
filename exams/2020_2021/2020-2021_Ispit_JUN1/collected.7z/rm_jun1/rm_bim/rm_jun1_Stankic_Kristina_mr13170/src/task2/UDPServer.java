package task2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static final int PORT=23456;

    public static void main(String[] args) {

        try(DatagramSocket server=new DatagramSocket(PORT);
            Scanner sc=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_jun1_Stankic_Kristina_mr13170/morse.txt"))))){


            byte[] niz=new byte[1024];
            DatagramPacket paket_za_prijem=new DatagramPacket(niz,niz.length);
            server.receive(paket_za_prijem);

            String prijem=new String(niz,0, paket_za_prijem.getLength());

            int duzina_poruke=prijem.length();

            Map<String,String> morze=new HashMap<>();

            while(sc.hasNextLine()){

                String linija=sc.nextLine();

                //int duzina=split.length;
                //String[] split=linija.split(" ");

                String karakter=String.valueOf(linija.charAt(0));
                String znak=linija.substring(1).trim();

                /*for (String s : split)
                    System.out.println(s);
                morze.put(split[0],split[2]);
                */

                morze.put(karakter,znak);

            }
/*
            for(Map.Entry<String,String> e: morze.entrySet()){
                System.out.println(e.getKey()+" : "+e.getValue());
            }
*/
            String nova_niska="";

            for(int i=0;i<duzina_poruke;i++){


               String c=String.valueOf(prijem.charAt(i));
               String mala_slova=c.toLowerCase();


                if(mala_slova.equalsIgnoreCase(" ")){
                    nova_niska=nova_niska+" "+" "+" ";
                }else {
                    String morzeov_znak = morze.get(mala_slova);
                    nova_niska = nova_niska + morzeov_znak + " ";
                }


            }
            nova_niska=nova_niska+".-.-.-";


            DatagramPacket paket_za_slanje=new DatagramPacket(nova_niska.getBytes(),nova_niska.length(),paket_za_prijem.getAddress(),paket_za_prijem.getPort());
            server.send(paket_za_slanje);


        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

}

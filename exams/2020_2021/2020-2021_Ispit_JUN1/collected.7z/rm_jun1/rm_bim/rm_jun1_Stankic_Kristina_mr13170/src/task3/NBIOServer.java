package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;

public class NBIOServer {

    public static final int PORT=12345;
    public static final int size=4;
    public static void main(String[] args) {


        try(ServerSocketChannel server=ServerSocketChannel.open();
            Selector selektor=Selector.open()){


            if(!selektor.isOpen() || !server.isOpen()){
                System.err.println("Selektor ili server se ne mogu otvoriti.");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selektor, SelectionKey.OP_ACCEPT);

            while(true){

                selektor.select();
                Iterator<SelectionKey> i=selektor.selectedKeys().iterator();

                while(i.hasNext()){

                    SelectionKey trenutniKljuc=i.next();
                    i.remove();


                    if(trenutniKljuc.isAcceptable()){

                        ServerSocketChannel s=(ServerSocketChannel) trenutniKljuc.channel();
                        SocketChannel klijent=s.accept();

                        System.out.println("Klijent je prihvacen.");

                        ByteBuffer buff=ByteBuffer.allocate(size);

                        klijent.configureBlocking(false);

                        SelectionKey klijent_kljuc=server.register(selektor,SelectionKey.OP_READ);


                        klijent_kljuc.attach(buff);

                    }

                    if(trenutniKljuc.isReadable()){

                        SocketChannel klijent=(SocketChannel) trenutniKljuc.channel();

                        ByteBuffer buff=(ByteBuffer) trenutniKljuc.attachment();

                        klijent.read(buff);

                        buff.flip();

                        int n=buff.getInt();

                        //ispisujemo karte koje imamo u spilu


                        //implementiramo nasumicno izvlacenje karte iz spila
                        //u promenljivoj n nam se nalazi broj karata koji nam je klijent poslao

                        //pik, herc, tref i karo odgovarace redom sledecim brojevima 1, 2, 3, 4
                        Random random=new Random();
                        int j;
                        int[] vrednost_karte=new int[100];
                        int[] vrednost_znak=new int[100];

                        for(j=0;j<n;j++){

                            //gornja granica za vrednost karte je 14
                            int vrednost=random.nextInt(14);
                            //vrednost_karte[j]=random.nextInt(14);

                            //znak ide od 1 do 4
                            int znak=random.nextInt(4);
                            //vrednost_znak[j]=random.nextInt(4);

                            while(vrednost_karte[j]==1 || (vrednost_karte[j]==vrednost && vrednost_znak[j]==znak)) {
                                //vrednost karte ide od 2 do 14
                                //moramo da izuzmemo 1 i da vodimo racuna da li se ova kombinacija
                                //vrednosti i znaka vec ponovila
                                //ako jeste, moramo opet da izvlacimo kartu
                                vrednost = random.nextInt(14);
                                znak = random.nextInt(4);
                            }
                               /* int k;
                                for(k=0;k<j;k++){
                                    if(vrednost_karte[k]==vrednost && vrednost_znak[k]==znak){
                                        vrednost=random.nextInt(14);
                                        znak=random.nextInt(4);
                                        k=0;
                                    }
                                }
*/

                            //ako je sve ok, unosimo el. u niz
                            vrednost_karte[j]=vrednost;
                            vrednost_znak[j]=znak;


                            //klijentu saljemo 2 cela broja
                            //koja predstavljaju vrednost i znak
                            buff.putInt(vrednost_karte[j]);
                            buff.putInt(vrednost_znak[j]);

                        }


                        buff.clear();
                        //buff.putInt();
                        //buff.flip();

                        trenutniKljuc.interestOps(SelectionKey.OP_WRITE);
                    }

                    if(trenutniKljuc.isWritable()){

                        SocketChannel klijent=(SocketChannel) trenutniKljuc.channel();

                        ByteBuffer buff=(ByteBuffer) trenutniKljuc.attachment();

                        klijent.write(buff);

                    }

                }

            }

        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

}

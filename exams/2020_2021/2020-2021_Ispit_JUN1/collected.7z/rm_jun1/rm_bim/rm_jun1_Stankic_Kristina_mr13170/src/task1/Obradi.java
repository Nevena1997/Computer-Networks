package task1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Obradi implements Runnable{

    private File f;
    private String pathname;
    private Lock lock;

    public  Obradi(File f, String pathname){
        this.f=f;
        this.pathname=pathname;
        this.lock=new ReentrantLock();
    }

    @Override
    public void run() {

        this.lock.lock();

        String putanja=this.f.toString()+"/"+this.pathname;

        System.out.println(this.pathname);
        try(Scanner sc=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja))))){

            while(sc.hasNextLine()){

                String linija=sc.nextLine();
                //testProtocol(linija);

                try{
                    URL url=new URL(linija);
                    System.out.println(url.getProtocol()+" "+url.getAuthority()+" "+url.getPath());
                }
                catch(MalformedURLException e){
                    continue;
                    //System.out.println(linija.substring(0,linija.lastIndexOf(":"))+": NOT SUPPORTED");
                }
            }

        }

        catch (IOException e){
            e.printStackTrace();
        }

        this.lock.unlock();
    }
/*
    private static void testProtocol(String linija){

        try{
            URL url=new URL(linija);
            System.out.println(url.getProtocol()+" "+url.getAuthority()+" "+url.getPath());
        }
        catch(MalformedURLException e){
            System.out.println(linija.substring(0,linija.lastIndexOf(":"))+": NOT SUPPORTED");
        }
    }
*/
}


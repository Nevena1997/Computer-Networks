package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;



public class NBIOClient {

    public static void main(String[] args) {


        try(SocketChannel klijent= SocketChannel.open(new InetSocketAddress("localhost",NBIOServer.PORT));
        Scanner sc=new Scanner(System.in)){

            ByteBuffer buff=ByteBuffer.allocate(NBIOServer.size);

            int n=sc.nextInt();

            while(n>52 || n<1){
                System.out.println("Voditi racuna o broju karata u spilu.");
                System.out.println("Probajte ponovo.");
                n=sc.nextInt();

            }


            buff.putInt(n);


            buff.flip();


            klijent.write(buff);

            buff.clear();

            klijent.read(buff);

            buff.flip();


            for(int j=0;j<n;j++) {
                //svaki put nam stizu po 2 cela broja
                //jedan koji predstavlja vrednost karte 2-14;
                //a drugi koji predstavlja vrednost znaka 1-4
                int vrednost = buff.getInt();
                int znak=buff.getInt();
                System.out.printf("%d ",vrednost);
                if(znak==1){
                    System.out.println("pik");
                }
                if(znak==2){
                    System.out.println("tref");
                }
                if(znak==3){
                    System.out.println("herc");
                }
                if(znak==4){
                    System.out.println("karo");
                }
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

}
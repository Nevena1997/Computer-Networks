package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try(DatagramSocket klijent=new DatagramSocket();
            Scanner sc=new Scanner(System.in)){

            String niska=sc.nextLine();
            DatagramPacket paket_za_slanje=new DatagramPacket(niska.getBytes(),niska.length(), InetAddress.getLocalHost(),UDPServer.PORT);
            klijent.send(paket_za_slanje);

            byte[] niz=new byte[1024];
            DatagramPacket paket_za_prijem=new DatagramPacket(niz,niz.length);
            klijent.receive(paket_za_prijem);

            String poruka=new String(niz,0,paket_za_prijem.getLength());
            System.out.println(poruka);


        }

        catch(IOException e){
            e.printStackTrace();
        }


    }

}

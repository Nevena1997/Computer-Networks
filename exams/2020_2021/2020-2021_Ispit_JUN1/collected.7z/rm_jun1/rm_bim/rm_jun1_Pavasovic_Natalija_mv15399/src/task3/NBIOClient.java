package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost",NBIOServer.PORT));
             Scanner sc = new Scanner(System.in)) {
            int broj = sc.nextInt();
            ByteBuffer buff = ByteBuffer.allocate(4);
            buff.putInt(broj);
            buff.flip();
            client.write(buff);

            buff.clear();

            ByteBuffer buff1 = ByteBuffer.allocate(NBIOServer.BUFF_SIZE);
            client.read(buff1);
            buff1.flip();
            int ind = buff1.getInt();
            //buff1.flip();
            if(ind == -1){
                System.out.println("Nedozvoljen broj");
                System.exit(1);
            }
            System.out.println("Izvucene karte su:");
            for(int i = 0; i < broj; i++){
                int k = buff1.getInt();
                System.out.print(k);
                System.out.print(" ");
                //System.out.println(NBIOServer.kopija.get(k).getVrednost() + "." + NBIOServer.kopija.get(k).getZnak());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

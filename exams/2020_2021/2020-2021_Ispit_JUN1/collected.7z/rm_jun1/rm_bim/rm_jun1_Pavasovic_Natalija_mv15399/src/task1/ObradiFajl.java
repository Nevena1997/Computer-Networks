package task1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ObradiFajl extends Thread{
    private Path p;
    public ObradiFajl(Path p) {
        this.p = p;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(this.p)) {
            while (sc.hasNextLine()){
                String line = sc.nextLine();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

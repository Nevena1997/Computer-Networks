package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {
       /* String s = "/home/ispit/Desktop/tests";
        *//*try (DirectoryStream<Path> ds = ) {
            *//**//*for (Path p : ds) {
                ObradiFajl t = new ObradiFajl(p);
                System.out.println(p.toString());
            }*//*
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}

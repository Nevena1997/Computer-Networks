package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Scanner;

public class UDPServer {
    public static final int PORT = 23456;
    static HashMap<Character,String> kodovi = new HashMap<>();
    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(PORT);
             Scanner sc = new Scanner(Paths.get("/home/ispit/Desktop/rm_jun1_Pavasovic_Natalija_mv15399/morse.txt"))) {

            byte[] niz = new byte[25];
            DatagramPacket paket_za_prijem = new DatagramPacket(niz,25);
            server.receive(paket_za_prijem);

            String poruka = new String(paket_za_prijem.getData(), 0, paket_za_prijem.getLength());

            while(sc.hasNextLine()){
                String line = sc.nextLine();
                kodovi.put(line.charAt(0),line.substring(1));
            }

            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < poruka.length(); i++){
                char karakter = poruka.charAt(i);
                if(kodovi.containsKey(karakter)){
                    sb.append(kodovi.get(karakter)).append(" ");
                }
                if(karakter == ' ')
                    sb.append("   ");
            }

            DatagramPacket paket_za_slanje = new DatagramPacket(sb.toString().getBytes(),sb.toString().getBytes().length,paket_za_prijem.getAddress(),paket_za_prijem.getPort());
            server.send(paket_za_slanje);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            String niska = sc.next();

            DatagramPacket paket_za_slanje = new DatagramPacket(niska.getBytes(),niska.getBytes().length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(paket_za_slanje);

            byte[] niz = new byte[25];
            DatagramPacket paket_za_prijem = new DatagramPacket(niz,niz.length);
            client.receive(paket_za_prijem);
            String poruka = new String(paket_za_prijem.getData(), 0, paket_za_prijem.getLength());
            System.out.println(poruka);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task3;

public class Karta {
    private String znak;
    private Integer vrednost;
    public Karta(String znak,Integer vrednost) {
        this.znak = znak;
        this.vrednost = vrednost;
    }

    public String getZnak() {
        return znak;
    }

    public Integer getVrednost() {
        return vrednost;
    }


}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

public class NBIOServer {
    public static final int PORT = 12345;
    public static final int BUFF_SIZE = 250;
    private static HashMap<Integer,Karta> spil = new HashMap<>();
    public static HashMap<Integer,Karta> kopija = new HashMap<>();

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Server ili selektor nisu otvoreni");
                System.exit(1);
            }
            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            kreirati_spil();
            int[] izmesan_spil = new int[52];
            Random rand = new Random();
            for(int i = 0; i < 52; i++){
                int broj  = rand.nextInt(52);
                for(int j = 0; j < i; j++){
                    if(broj == izmesan_spil[j]){
                        broj = rand.nextInt(52);
                        j = 0;
                    }
                }
                izmesan_spil[i] = broj;
            }
            for(int i = 0; i < 52; i++){
                int kljuc =izmesan_spil[i];
                System.out.println(spil.get(kljuc).getVrednost() + "." + spil.get(kljuc).getZnak());
            }
            while (true){
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();
                    if(key.isAcceptable()){
                        ServerSocketChannel s = (ServerSocketChannel) key.channel();
                        SocketChannel client = s.accept();
                        client.configureBlocking(false);
                        System.out.println("Klijent je prihvacen");
                        SelectionKey clientKey = client.register(selector,SelectionKey.OP_READ);
                        ByteBuffer buff = ByteBuffer.allocate(4);
                        clientKey.attach(buff);
                    } if(key.isReadable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();
                        client.read(buff);

                        if (!buff.hasRemaining()) {
                            buff.flip();
                            int n = buff.getInt();
                            buff.clear();
                            ByteBuffer buff1 = ByteBuffer.allocate(BUFF_SIZE);
                            if (n < 1 || n > 52) {
                                buff.putInt(-1);
                                buff.flip();
                            } else {
                                buff1.putInt(0);
                                for (int i = 0; i < n; i++) {
                                    buff1.putInt(izmesan_spil[i]);
                                    spil.remove(izmesan_spil[i]);
                                }
                                buff1.flip();
                                key.attach(buff1);
                            }
                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                    }if(key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();
                        client.write(buff);

                        if(!buff.hasRemaining()){
                            key.cancel();
                            client.close();
                        }


                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private static void kreirati_spil() {
        int i = 0;
        for(int j = 1; j <= 14; j++){
            spil.put(i,new Karta("pik",j));
            kopija.put(i,new Karta("pik",j));
            i++;
            spil.put(i,new Karta("tref",j));
            kopija.put(i,new Karta("tref",j));
            i++;
            spil.put(i,new Karta("herc",j));
            kopija.put(i,new Karta("herc",j));
            i++;
            spil.put(i,new Karta("karo",j));
            kopija.put(i,new Karta("karo",j));
            i++;

        }
        //System.out.println(i);
    }


}

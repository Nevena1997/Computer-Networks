package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        try (SocketChannel klient = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.port));
             Scanner sc = new Scanner(System.in)) {
//            System.out.println("Povezao sam se ");
            int broj = sc.nextInt();
            ByteBuffer bf = ByteBuffer.allocate(128);
            bf.putInt(broj);
            bf.flip();
            klient.write(bf);
            bf.clear();
//            System.out.println("poslao sam serveru " + broj);
            while (broj>0) {
                klient.read(bf);
//                broj = -klient.read(bf) / 8;
//                System.out.println(bf);
                bf.flip();
//                System.out.println(bf);
                while (bf.hasRemaining()) {
//                    System.out.println(bf);
                    int karta=bf.getInt();
                    if(karta==-1){
                        System.out.println("poslao si los broj ili nema vise karata");
                        System.exit(1);
                    }
                    int znak=bf.getInt();
                    String znaks="";
                    if(znak==1) znaks=".Pik";
                    if(znak==2) znaks=".Herc";
                    if(znak==3) znaks=".Tref";
                    if(znak==4) znaks=".Karo";
                    System.out.println(karta+znaks);
                    broj--;
//                    if(znak.equalsIgnoreCase("pik")) i=1;
//                    if(znak.equalsIgnoreCase("herc")) i=2;
//                    if(znak.equalsIgnoreCase("tref")) i=3;
//                    if(znak.equalsIgnoreCase("karo")) i=4;
//
                }
                bf.clear();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }



//        System.out.println("Hello from NBIOClient");
}

}

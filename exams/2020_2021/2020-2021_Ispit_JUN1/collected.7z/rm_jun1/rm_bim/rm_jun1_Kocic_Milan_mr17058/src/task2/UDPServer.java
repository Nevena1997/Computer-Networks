package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {
    public static final int port=23456;
    public static void main(String[] args) {
        Map<Character, String>map=new HashMap<Character, String>();
        try (DatagramSocket server=new DatagramSocket(port);
             Scanner sc=new Scanner(Paths.get("/home/ispit/Desktop/rm_jun1_Kocic_Milan_mr17058/morse.txt"))){
            String line;
            while(sc.hasNextLine()){
                 line=sc.nextLine();
                 map.put(line.charAt(0),line.substring(line.indexOf(' ')+1));
            }

            byte buf[]=new byte[128];
            DatagramPacket primljen=new DatagramPacket(buf,buf.length);
            server.receive(primljen);
            System.out.println("primljen paket");

            byte sad[]=new byte[primljen.getLength()];
            for(int i=0;i<primljen.getLength();i++)
                sad[i]=primljen.getData()[i];

            String s=new String(sad).toLowerCase();
            System.out.println(s);
            StringBuilder sb=new StringBuilder();
            for(Character c:s.toCharArray()){

                if(c.equals(' ')){
                    sb.append("   ");
                }else if(map.containsKey(c)){
                    sb.append(map.get(c));
                    sb.append(" ");
                }

            }
            sb.append(".-.-.-");
//            System.out.println(sb);
            DatagramPacket posalji=new DatagramPacket(sb.toString().getBytes(),sb.toString().length(),
                    primljen.getAddress(),primljen.getPort());
            server.send(posalji);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

// ne pise da cekam opet pa ne cekam :)
//        System.out.println("Hello from UDPServer");
    }

}

package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {

        String putanja="/home/ispit/Desktop/tests/urls";
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get(putanja))) {
            for(Path p:ds){
//                System.out.println(p);
                new Thread(new statistika(p)).start();
            }


//            String url="sftp://2001:0db8:85a3:::8a2e:0370:7334/dir1/dir2/test.txt";
//            URL u= new URL(url);
//            System.out.println(u.getProtocol());
//            String adr=u.getAuthority().substring(0,u.getAuthority().lastIndexOf(':'));
//            System.out.println(adr);
//            InetAddress address = InetAddress.getByName("adr");
//            System.out.println(address.getAddress().length);
//            for(byte b:address.getAddress()){
//                System.out.println(b);
//            }

        } catch (IOException e) {
            e.printStackTrace();
        }


//        System.out.println("Hello from Task1Main");
    }
}

package task3;

import javax.sound.midi.Soundbank;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;

public class NBIOServer {
    public static final int port=12345;

    public static void main(String[] args) {
//        List l=new Arr
        List<Karte> spil=new ArrayList<Karte>();
        popuni(spil);
        Collections.shuffle(spil);
        for(Karte k:spil)
            System.out.println(k);
        try (ServerSocketChannel server = ServerSocketChannel.open(); Selector selector=Selector.open()) {
            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("nisi otvorio nesto");
                System.exit(1);
            }
            server.bind(new InetSocketAddress(port));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            while(true){
                selector.select();
                Iterator<SelectionKey> it=selector.selectedKeys().iterator();

                while (it.hasNext()){
                    SelectionKey kljuc= it.next();
                    it.remove();
                    if(kljuc.isAcceptable()){
                        ServerSocketChannel sc= (ServerSocketChannel) kljuc.channel();
                        SocketChannel klient=sc.accept();
//                        System.out.println("prihvatio nekog");
                        klient.configureBlocking(false);
                        SelectionKey sad=klient.register(selector,SelectionKey.OP_READ);
                        sad.attach(ByteBuffer.allocate(32));

                    }else if(kljuc.isReadable()){
                        SocketChannel klient= (SocketChannel) kljuc.channel();
                        ByteBuffer bf= (ByteBuffer) kljuc.attachment();
                        klient.read(bf);
                        bf.flip();
                        if(bf.hasRemaining()){
//                            bf.flip();
//                            System.out.println("primio " + bf.getInt());
                            if(bf.getInt()<1) {
                                bf.clear();
                                bf.putInt(-1);
                                bf.flip();
                                klient.write(bf);
                                klient.close();
                            }

                            kljuc.interestOps(SelectionKey.OP_WRITE);
//                            System.out.println("premestio ga za pisanje");
                        }
                        bf.flip();
                    }else if(kljuc.isWritable()){
                        SocketChannel klient= (SocketChannel) kljuc.channel();
                        ByteBuffer bf= (ByteBuffer) kljuc.attachment();

//                        System.out.println(bf);
                        int broj=bf.getInt();
                        bf.clear();
//                        System.out.println("saljem karte "+ broj);
//                        ByteBuffer novi=ByteBuffer.allocate(32);

                        for(int i=0;i<broj;i++){
                            Iterator<Karte> iter=spil.iterator();
                            if(iter.hasNext()){
                            Karte sad=iter.next();
//                            System.out.println(sad);
                            iter.remove();
//                                System.out.println(bf);
                            bf.putInt(sad.getBroj());
                            bf.putInt(sad.getZnak());
//                            System.out.println(sad.getBroj()+"  "+sad.getZnak() );
                            bf.flip();
                            klient.write(bf);
                            bf.clear();
                            }else{
                                bf.clear();
                                bf.putInt(-1);
                                bf.flip();
                                klient.write(bf);
                                System.out.println("nema vise karata");
                                break;
                            }

                            }
                            klient.close();
                        }


                    }



                }

            } catch (ClosedChannelException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private static void popuni(List<Karte> spil) {
        String niz[]={"Karo","Herc","Tref","Pik"};
        for(String s:niz){
            for(int i=2;i<=14;i++){
                spil.add(new Karte(i,s));
            }
        }

    }

}

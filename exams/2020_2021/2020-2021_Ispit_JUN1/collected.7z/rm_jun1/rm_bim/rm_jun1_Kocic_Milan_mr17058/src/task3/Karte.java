package task3;

public class Karte {
    private int broj;
    private String znak;


    public Karte(int broj, String znak){
        this.broj=broj;
        this.znak=znak;
    }

    public int getBroj() {
        return broj;
    }

    public int getZnak() {
        int i=0;
        if(znak.equalsIgnoreCase("pik")) i=1;
        if(znak.equalsIgnoreCase("herc")) i=2;
        if(znak.equalsIgnoreCase("tref")) i=3;
        if(znak.equalsIgnoreCase("karo")) i=4;
        return i;
    }

    @Override
    public String toString() {
        return broj + "." + znak;
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        try (DatagramSocket klient = new DatagramSocket();
             Scanner sc=new Scanner(System.in)) {
            byte buf[]=new byte[128];
            String s=sc.nextLine();
            DatagramPacket paket=new DatagramPacket(s.getBytes(),s.getBytes().length,
                    InetAddress.getByName("localhost"),UDPServer.port);
            klient.send(paket);
            System.out.println("poslao sam poruku");

            DatagramPacket primljen=new DatagramPacket(buf,buf.length);
            klient.receive(primljen);
            System.out.println("primio sam paket");

            byte sad[]=new byte[primljen.getLength()];
            for(int i=0;i<primljen.getLength();i++)
                sad[i]=primljen.getData()[i];

            String novi=new String(sad);
            System.out.println(novi);


        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

//        System.out.println("Hello from UDPClient");
    }

}

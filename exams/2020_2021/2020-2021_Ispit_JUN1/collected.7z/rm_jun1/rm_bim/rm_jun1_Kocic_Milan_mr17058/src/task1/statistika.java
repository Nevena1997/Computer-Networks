package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Scanner;

public class statistika implements Runnable {
    Path p;
    public statistika(Path p) {
    this.p=p;
    }

    @Override
    public void run() {
        StringBuilder sb=new StringBuilder();
        try (Scanner sc = new Scanner(p)) {

            String line;
            while(sc.hasNextLine()){
                line=sc.nextLine();
                try{
                    URL u=new URL(line);
//                    sb.append(line);
//                    sb.append('\n');
                    sb.append(u.getProtocol());
                    sb.append(" ");
                    sb.append(u.getAuthority());
                    sb.append(" ");
                    sb.append(u.getPath());
                    sb.append("\n");

                    try{

                            String aut=u.getAuthority();
                            boolean provera=true;
//                            System.err.println(aut);
                            for(char c:aut.toCharArray()){
                                if((c<'z' && c>'a') ||(c<'Z' && c>'A')){
                                    provera=false;
                                    break;
                                }
                            }

//                            System.err.println(provera);
                            if(provera){
//                                System.err.println("usao sam ovde");
                            InetAddress a=InetAddress.getByName(u.getAuthority().substring(0,u.getAuthority().lastIndexOf(':')));
                            if(a.getAddress().length==4){
                                sb.append("(v4) ");
                                sb.append(u.getProtocol());
                                sb.append(" ");
                                sb.append(u.getPath());
                                sb.append(" [");
                                for(byte b:a.getAddress()){
                                    sb.append(b);
                                    sb.append(' ');
                                }
                                sb.append("]\n");

                            }else {
                                sb.append("(v6) ");
                                sb.append(u.getProtocol());
                                sb.append(" ");
                                sb.append(u.getPath());
                            }}



                    }catch (UnknownHostException e){
                    }


                } catch (MalformedURLException e){
                    continue;
                }

            }
            System.out.println(sb);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.Buffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class UDPServer {

    public static void main(String[] args) {
        Map<Character, String> mapa = new HashMap<>();
        try(DatagramSocket sever = new DatagramSocket(23456)) {

            DatagramPacket request = new DatagramPacket(new byte[34], 34);
            sever.receive(request);

            String poruka = new String(request.getData() , 0, request.getLength(), StandardCharsets.UTF_8);

            procitajFajl(mapa);

            String poruka2 = " ";
            for(char c : poruka.toCharArray()){
                if(c == ' ')
                    poruka2 += " ";
                else
                    poruka2 += " " + mapa.get(Character.toLowerCase(c)).trim();

            }

            poruka2 += " .-.-.-";

            byte[] odgovor = poruka2.getBytes();
            DatagramPacket response = new DatagramPacket(odgovor, odgovor.length, request.getAddress(), request.getPort());
            sever.send(response);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void procitajFajl(Map<Character, String> mapa) {

        Path path = Paths.get("/home/ispit/Desktop/rm_jun1_Milosavljevic_Sanja_mr16200/morse.txt");
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path.toString())));

            String linija;
            while((linija = reader.readLine()) != null) {
                String[] red = linija.split(" ");
                mapa.put(red[0].charAt(0), red[1]);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try {
            InetSocketAddress adr = new InetSocketAddress("localhost", 12345);
            SocketChannel client = SocketChannel.open(adr);
            ByteBuffer buffer = ByteBuffer.allocate(100);

            Scanner sc = new Scanner(System.in);
            System.out.println("Unesite ceo broj:");
            int broj = sc.nextInt();

            buffer.putInt(broj);
            buffer.flip();
            client.write(buffer);
            buffer.clear();

            int procitano = client.read(buffer);
            buffer.flip();

            byte[] data = new byte[procitano];
            for(int i = 0; i < buffer.limit(); i++) {
                data[i] = buffer.get();
            }

            System.out.println(Arrays.toString(data));


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

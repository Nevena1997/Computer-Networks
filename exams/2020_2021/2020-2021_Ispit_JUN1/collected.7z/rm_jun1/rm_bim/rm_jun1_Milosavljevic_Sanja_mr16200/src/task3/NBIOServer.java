package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {

    public static void main(String[] args) {

        List<Map<Integer, String[]>> lista = new ArrayList<>();
        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            serverChannel.bind(new InetSocketAddress(12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            pripremiSpil(lista);

            while(true) {
                selector.select();
                Set<SelectionKey> selectionKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = selectionKeys.iterator();

                while(it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            SelectionKey keyClient = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(100);
                            keyClient.attach(buffer);

                        }else if(key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);
                            buffer.flip();
                            int broj = buffer.getInt();
                            buffer.clear();
                            String znak = "srce";
                            for(int i = 0; i < broj; i++) {
                                buffer.putInt(4);
                                buffer.put(znak.getBytes());
                            }

                            buffer.flip();
                            key.interestOps(SelectionKey.OP_WRITE);

                        }else if(key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.write(buffer);
                            buffer.clear();
                            key.interestOps(SelectionKey.OP_READ);
                        }
                    }catch(Exception e) {

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void pripremiSpil(List<Map<Integer, String[]>> lista) {


        String [] niz = {"pik", "srce","karo", "tref"};
        for(int i= 2; i < 15; i++) {
            Map<Integer, String[]> mapa = new HashMap<>();
            mapa.put(i, niz);
            lista.add(mapa);
        }
    }

}

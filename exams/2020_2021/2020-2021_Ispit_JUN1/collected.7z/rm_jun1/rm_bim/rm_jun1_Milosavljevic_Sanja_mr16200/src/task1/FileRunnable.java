package task1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;

public class FileRunnable implements Runnable {

    private Path path;

    public FileRunnable(Path p) {
        this.path = p;
    }

    @Override
    public void run() {



            try{
                obradi();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


    }

    private synchronized void obradi() throws IOException, FileNotFoundException {

        try {

            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(this.path.toString())));
            String linija;
            while((linija = reader.readLine()) != null) {
                URL url = new URL(linija);
                String protokol = url.getProtocol();
                String authority = url.getAuthority();
                String putanja = url.getPath();
                int port = url.getPort();
                String sPort = String.valueOf(port);
                int length = authority.length() - sPort.length();

                synchronized (System.out) {
                    System.out.println();
                    System.out.println(linija);

                    if(Character.isDigit(authority.charAt(0))) {
                        String substring  = authority.substring(0, length-1);
                        String[] sub = substring.split("\\.");
                        System.out.println("(v4)" + " " + protokol + " " + putanja + " " + Arrays.toString(sub));
                    }else {

                        System.out.println(protokol + " " + authority + " " + putanja);
                    }



                }
            }

        }catch(MalformedURLException e) {
        }
    }
}

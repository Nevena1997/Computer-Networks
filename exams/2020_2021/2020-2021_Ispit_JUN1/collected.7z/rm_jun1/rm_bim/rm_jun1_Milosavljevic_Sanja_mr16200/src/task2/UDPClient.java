package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
                Scanner sc = new Scanner(System.in)) {

            System.out.println("Unesite poruku: ");
            String poruka = sc.nextLine();
            byte [] data = poruka.getBytes();

            InetAddress adresa = InetAddress.getByName("localhost");
            DatagramPacket request = new DatagramPacket(data, data.length, adresa, 23456);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[40], 40);
            client.receive(response);

            String odgovor = new String(response.getData(), 0,  response.getLength(), StandardCharsets.UTF_8);
            System.out.println(odgovor);
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

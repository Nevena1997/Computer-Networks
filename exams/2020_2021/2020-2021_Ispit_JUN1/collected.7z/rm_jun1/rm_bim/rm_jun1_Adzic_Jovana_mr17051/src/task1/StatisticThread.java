package task1;

import java.io.IOException;
import java.net.*;
import java.nio.file.Path;
import java.util.Scanner;

public class StatisticThread  extends Thread{
    private  Path f;

    public StatisticThread(Path f) {
        this.f = f;
    }

    public void run() {

        try (Scanner ulaz = new Scanner(f)) {

            String line;
            for (int ln = 0;ulaz.hasNext();ln++){

            line = ulaz.next();
            try {
                    URL u = new URL(line);
                    String protocol = u.getProtocol();
                    String autor = u.getAuthority();
                    String path = u.getPath();
                 //   System.out.println(autor);
                    if (brojevi(autor)) {
                     //  System.out.println(autor);

                        InetAddress address = InetAddress.getByName(line);
                        //   InetAddress a1 = InetAddress.getByName("sftp://2401:0db8:85a3:::::7334/dir1/dir2/test.txt");//    System.out.println(a1.toString());
                       // System.out.println(address.getAddress());
                        if (autor.contains(":")) {
                            System.out.println("(v6)" + protocol + " " + path + " " + address.getAddress());

                        } else {
                            System.out.println("(v4)" + protocol + " " + path + " " + address.getAddress());
                        }

                    } else {
                        System.out.println(protocol + " " + autor + " " + path);

                    }

                } catch (MalformedURLException | UnknownHostException e) {
                   // e.printStackTrace();
                     continue;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        private static boolean brojevi(String autor) {
        char[] autori;
        autori = autor.toCharArray();
        for(char c:autori){
            if(c == ':' || Character.isDigit(c))
                return true;
        }
        return false;

    }
}

package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {
    public static int PORT = 23456;
    public static Map<Character, String> mapa = new HashMap<>();

    public static void main(String[] args) {

        System.out.println("Hello from UDPServer");
        try(DatagramSocket server = new DatagramSocket(PORT)){
            byte[] recvB = new byte[1024];
            DatagramPacket recvP = new DatagramPacket(recvB, recvB.length);
            server.receive(recvP);
            System.out.println("Server received!");
            Path p = Paths.get("/home/ispit/Desktop/rm_jun1_Adzic_Jovana_mr17051/morse.txt");
            obradi(p);
            String data = new String(recvP.getData(), 0, recvP.getLength());
            char[] niska = data.toCharArray();

            StringBuilder sb = null;
            for(char c:niska){
                c = Character.toLowerCase(c);
                if(c == ' '){
                    sb.append("   ");
                }
                String nc  = mapa.get(c);
                System.out.println(nc);
                sb.append(nc);
                sb.append(" ");

            }
            sb.append(".-.-.-");
            String sendS = sb.toString();
            DatagramPacket sendP = new DatagramPacket(sendS.getBytes(), sendS.getBytes().length, recvP.getAddress(), recvP.getPort());
            server.send(sendP);
            System.out.println("Send packet server!");




        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void obradi(Path p) {
       /* try(Scanner sc = new Scanner(p)){
            String line;
            for(int ln=0;sc.hasNext();ln++){
                line = sc.nextLine();
                Character chr = line.charAt(0);
                String vrednost = line.substring(2);
                mapa.put(chr, vrednost);


            }*/
       try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))){
           String line;
           while((line = in.readLine())!=null){
               Character chr = line.charAt(0);
               String vrednost = line.substring(2);
               mapa.put(chr, vrednost);

           }



       } catch (FileNotFoundException ex) {
           ex.printStackTrace();
       } catch (IOException ex) {
           ex.printStackTrace();
       }


    }

}

package task3;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {
    public static  int PORT = 12345;

    public static class Karta{
        private int vrednost;
        private String znak;

        public Karta(int vr,String zn){
            this.vrednost = vr;
            this.znak = zn;
        }

        public int getVrednost() {
            return vrednost;
        }

        public void setVrednost(int vrednost) {
            this.vrednost = vrednost;
        }

        public String getZnak() {
            return znak;
        }

        public void setZnak(String znak) {
            this.znak = znak;
        }
    }
    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");
        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ) {
            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.out.println("Nije otvoren selector ili serverChannel!");
                System.exit(1);
            }
            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            ArrayList<Karta> karte = new ArrayList<>();
            for(int i = 1; i<15;i++){
                Karta k1 = new Karta(i, "tref");
                karte.add(k1);
            }

            for(int i = 1; i<15;i++){
                Karta k1 = new Karta(i, "karo");
                karte.add(k1);
            }
            for(int i = 1; i<15;i++){
                Karta k1 = new Karta(i, "pik");
                karte.add(k1);
            }
            for(int i = 1; i<15;i++){
                Karta k1 = new Karta(i, "herc");
                karte.add(k1);
            }

           for(int i = 0; i < karte.size(); i++){
               System.out.println(karte.get(i).getVrednost() + "." + karte.get(i).getZnak());
           }
           Collections.shuffle(karte);


            while(true){
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();
                    try{
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                            ByteBuffer buffer = ByteBuffer.allocate(1024);
                            clientKey.attach(buffer);


                        }else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel ();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            client.write(buffer);
                          //  buffer.flip();
                            if(!buffer.hasRemaining()){
                           //     buffer.flip();
                                System.out.println("Obradjen klijent!");
                               // key.cancel();
                                key.channel().close();

                            }


                        }else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            client.read(buffer);
                            buffer.flip();
                            int broj = buffer.getInt();
                          //  System.out.println(broj);
                            buffer.flip();
                         //   System.out.println(karte.size());
                            if(broj > karte.size() || broj<1){
                                System.out.println("Imamo manje karata!");
                                buffer.putInt(-1);
                                buffer.clear();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                            for(int i = 0;i < broj;i++){
                               // System.out.println(broj);
                                Karta k1 = karte.get(i);
                                int vrednost = k1.getVrednost();
                                String znak = k1.getZnak();
                                System.out.println(vrednost);
                                buffer.putInt(vrednost);
                                buffer.flip();
                             //   buffer.put(znak.getBytes());


                            }
                            buffer.clear();
                            key.interestOps(SelectionKey.OP_WRITE);


                        }


                    }catch (Exception e){
                        key.cancel();
                        key.channel().close();

                    }


                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

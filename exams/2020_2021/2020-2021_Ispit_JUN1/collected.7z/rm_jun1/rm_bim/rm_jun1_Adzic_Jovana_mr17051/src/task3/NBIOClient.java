package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class NBIOClient {


    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.PORT));
            Scanner sc = new Scanner(System.in)
        ){
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int broj = sc.nextInt();
            buffer.putInt(broj);
            buffer.flip();
            client.write(buffer);
            buffer.clear();
            client.read(buffer);
            buffer.rewind();
            int i = 1;
         //   buffer.clear();
            //while(buffer.hasRemaining()) {
            while(true){
               int brojR = buffer.getInt();
                buffer.flip();
                if (brojR < 0) {
                    System.out.println("Nema karata u spilu");
                 //   break;
                } else {
                    System.out.println(brojR);
                }
                if(i>=broj)
                   break;
               i++;
            }
          // }




        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

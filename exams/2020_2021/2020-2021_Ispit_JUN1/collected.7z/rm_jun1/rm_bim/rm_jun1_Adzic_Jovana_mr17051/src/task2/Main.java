package task2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static Map<String, String> mapa = new HashMap<>();
    public static void main(String[] args) {
        Path p = Paths.get("/home/ispit/Desktop/rm_jun1_Adzic_Jovana_mr17051/morse.txt");
        obradi(p);
        Iterator<String> iter = mapa.keySet().iterator();
        while(iter.hasNext()) {
            System.out.println(iter.next() + " " + mapa.get(iter.next()));
        }

        //System.out.println(mapa.get("a"));
    }


    private static void obradi(Path p) {
     /*   try(Scanner sc = new Scanner(p)){
            String line;
            for(int ln=0;sc.hasNext();ln++){
                line = sc.nextLine();
              //  System.out.println(line);
                Character chr = line.charAt(0);
                String vrednost = line.substring(2);
             //   System.out.println(chr + "  " + vrednost);
                mapa.put(chr, vrednost);
             //   System.out.println(mapa.get(chr));


            }*/
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))){
            String line;
            while((line = in.readLine())!=null){
                String chr = String.valueOf(line.charAt(0));
              //  System.out.println(chr);
                String vrednost = line.substring(2).trim();
                System.out.println(chr + " " + vrednost);
                mapa.put(chr, vrednost);


            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

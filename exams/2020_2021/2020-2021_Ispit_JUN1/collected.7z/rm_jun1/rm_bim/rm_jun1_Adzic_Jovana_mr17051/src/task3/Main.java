package task3;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static class Karta{
        private int vrednost;
        private String znak;

        public Karta(int vr,String zn){
            this.vrednost = vr;
            this.znak = zn;
        }

        public int getVrednost() {
            return vrednost;
        }

        public void setVrednost(int vrednost) {
            this.vrednost = vrednost;
        }

        public String getZnak() {
            return znak;
        }

        public void setZnak(String znak) {
            this.znak = znak;
        }
    }
    public static void main(String[] args) {
        ArrayList<NBIOServer.Karta> karte = new ArrayList<>();
        for(int i = 1; i<15;i++){
            NBIOServer.Karta k1 = new NBIOServer.Karta(i, "tref");
            karte.add(k1);
        }

        for(int i = 1; i<15;i++){
            NBIOServer.Karta k1 = new NBIOServer.Karta(i, "karo");
            karte.add(k1);
        }
        for(int i = 1; i<15;i++){
            NBIOServer.Karta k1 = new NBIOServer.Karta(i, "pik");
            karte.add(k1);
        }
        for(int i = 1; i<15;i++){
            NBIOServer.Karta k1 = new NBIOServer.Karta(i, "herc");
            karte.add(k1);
        }

        for(int i = 0; i<karte.size();i++){
            System.out.println(karte.get(i).getVrednost() + ":" + karte.get(i).getZnak());
        }
        Collections.shuffle(karte);
        for(int i = 0; i<karte.size();i++){
            System.out.println(karte.get(i).getVrednost() + ":" + karte.get(i).getZnak());
        }

    }
}

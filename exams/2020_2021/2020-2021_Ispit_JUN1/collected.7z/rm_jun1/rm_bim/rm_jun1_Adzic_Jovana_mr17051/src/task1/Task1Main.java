package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) throws IOException {
        Path p = Paths.get("/home/ispit/Desktop/tests/urls");
        obradi(p);

    }

    private static void obradi(Path p) throws IOException {
        for(Path f: Files.newDirectoryStream(p)){
            if(Files.isRegularFile(f)){
                new StatisticThread(f).start();

            }


        }
    }
}

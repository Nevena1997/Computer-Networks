package task1;

public class Main {
    public static void main(String[] args) {
        String line = "123.323.123.123:80";
        if(line.contains(":"))
            System.out.println("da");
        else{
            System.out.println("ne");
        }
    }

    private static boolean brojevi(String autor) {
        char[] autori;
        autori = autor.toCharArray();
        for(char c:autori){
            if(c == ':' || ( c > 0 && c < 9  ))
                return true;
        }
        return false;

    }
}

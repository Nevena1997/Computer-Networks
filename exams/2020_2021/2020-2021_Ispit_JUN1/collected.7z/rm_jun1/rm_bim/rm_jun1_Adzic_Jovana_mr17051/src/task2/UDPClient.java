package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        System.out.println("Hello from UDPClient");
        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){
         //  StringBuilder sb = null;
           String sb = sc.nextLine();

          /* while(true){
               line  = sc.next();
               if(line.equals("\n"))
                   break;
               sb.append(line);
           }*/
            String sendS = sb;
            byte[] bytes = sendS.getBytes();
            DatagramPacket sendP = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("localhost"), UDPServer.PORT);
            client.send(sendP);
            System.out.println("Send packet!");

            DatagramPacket recvP = new DatagramPacket(new byte[1024],1024);
            client.receive(recvP);
            System.out.println("Receive packet!");
            String data = new String(recvP.getData(), 0, recvP.getLength());





        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

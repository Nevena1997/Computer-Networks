package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.sql.Array;
import java.util.*;

public class NBIOServer {

    public static int PORT_NUMBER = 12345;

    public static Map<Integer, String> spil = new HashMap<>();

    public static int want;

    public static void main(String[] args) {
        // [0] -> 1.herc
        // [1] -> 2 herc
        // ... [12] -> kralj herc
        // [13] -> 1 pik
        // ...


        for (int i = 0; i < 52; i++) {

            if (i%13 == 0) {
                if (i/13 == 0) {
                    String znak = "herc";
                    spil.put(i, Integer.toString(14) + "." + znak);
                }
                if (i/13 == 1) {
                    String znak = "pik";
                    spil.put(i, Integer.toString(14) + "." + znak);
                } else if (i/13 == 2) {
                    String znak = "karo";
                    spil.put(i, Integer.toString(14) + "." + znak);
                } else if (i/13 == 3) {
                    String znak = "tref";
                    spil.put(i, Integer.toString(14) + "." + znak);
                }
            } else if (i%13 == 10) {
                if (i/13 == 0) {
                    String znak = "herc";
                    spil.put(i, Integer.toString(11) + "." + znak);
                }
                if (i/13 == 1) {
                    String znak = "pik";
                    spil.put(i, Integer.toString(11) + "." + znak);
                } else if (i/13 == 2) {
                    String znak = "karo";
                    spil.put(i, Integer.toString(11) + "." + znak);
                } else if (i/13 == 3) {
                    String znak = "tref";
                    spil.put(i, Integer.toString(11) + "." + znak);
                }
            } else if (i%13 == 11) {
                if (i/13 == 0) {
                    String znak = "herc";
                    spil.put(i, Integer.toString(12) + "." + znak);
                }
                if (i/13 == 1) {
                    String znak = "pik";
                    spil.put(i, Integer.toString(12) + "." + znak);
                } else if (i/13 == 2) {
                    String znak = "karo";
                    spil.put(i, Integer.toString(12) + "." + znak);
                } else if (i/13 == 3) {
                    String znak = "tref";
                    spil.put(i, Integer.toString(12) + "." + znak);
                }
            } else if (i%13 == 12) {
                if (i/13 == 0) {
                    String znak = "herc";
                    spil.put(i, Integer.toString(13) + "." + znak);
                }
                if (i/13 == 1) {
                    String znak = "pik";
                    spil.put(i, Integer.toString(13) + "." + znak);
                } else if (i/13 == 2) {
                    String znak = "karo";
                    spil.put(i, Integer.toString(13) + "." + znak);
                } else if (i/13 == 3) {
                    String znak = "tref";
                    spil.put(i, Integer.toString(13) + "." + znak);
                }
            } else {
                if (i/13 == 0) {
                    String znak = "herc";
                    spil.put(i, Integer.toString(i%13) + "." + znak);
                }
                if (i/13 == 1) {
                    String znak = "pik";
                    spil.put(i, Integer.toString(i%13) + "." + znak);
                } else if (i/13 == 2) {
                    String znak = "karo";
                    spil.put(i, Integer.toString(i%13) + "." + znak);
                } else if (i/13 == 3) {
                    String znak = "tref";
                    spil.put(i, Integer.toString(i%13) + "." + znak);
                }
            }
        }


        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if (!serverChannel.isOpen() || !selector.isOpen()) {
                System.err.println("Server or selector cannot be opened!");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT_NUMBER));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);


            // TODO : Generisanje novog spila

            for (Integer i : spil.keySet()) {
                System.out.println(spil.get(i));
            }

            while (true) {
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try {


                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();

                            SocketChannel client = server.accept();
                            System.err.println("Client accepted!");

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(4);
                            clientKey.attach(buffer);

                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);

                            if (!buffer.hasRemaining()) {
                                buffer.flip();
                                //System.out.println(buffer.getInt());
                                want = buffer.getInt();
                                buffer.clear();
                                if (spil.size() < want || want < 1) {
                                    buffer.putInt(-1);
                                    buffer.flip();
                                }

                            }
                            key.interestOps(SelectionKey.OP_WRITE);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.write(buffer);

                            if (!buffer.hasRemaining()) {

                                buffer.flip();
                                int n = buffer.getInt();
                                buffer.clear();

                                if (n == -1 ) {
                                    key.cancel();
                                    key.channel().close();
                                }

                                key.interestOps(SelectionKey.OP_READ);
                            }
                        }
                    } catch (IOException e) {
                        key.cancel();
                        key.channel().close();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.PORT_NUMBER));
             Scanner sc = new Scanner(System.in)) {

            System.err.println("Client connected!");
            ByteBuffer buffer = ByteBuffer.allocate(4);

            // TODO: obraditi pogresan ulaz
            System.out.println("Enter number:");
            int number = sc.nextInt();
            buffer.putInt(number);
            buffer.flip();
            client.write(buffer);

            buffer.clear();
            client.read(buffer);
            buffer.flip();

            int answer = buffer.getInt();
            buffer.clear();
            if (answer == -1)
                System.out.println("Uneta pogresna vrednost");

            System.err.println("Client disconnected!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class UDPServer {

    public static int PORT_NUMBER = 23456;

    public static void main(String[] args) throws IOException {

        try (DatagramSocket server = new DatagramSocket(PORT_NUMBER)) {

            while (true) {
                byte[] receivedBytes = new byte[UDPClient.MAX_SIZE];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
                server.receive(receivedPacket);
                String s = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                //System.out.println(s);


                String sendString = "";
                for (int i = 0; i < s.length(); i++) {

                    if (s.substring(i, i+1).equals(" ")) {
                        sendString += "   ";
                        continue;
                    }

                    Scanner sc = new Scanner("/home/ispit/Desktop/rm_jun1_Pantic_Ana_mn16361/src/task2/morse.txt");

                    String line;
                    while (sc.hasNextLine()) {
                        line = sc.nextLine();
                        if (line == null)
                            break;
                        if(s.substring(i, i+1).equalsIgnoreCase(line.split(" ")[0])) {
                            sendString += line.split(" ")[1];
                            break;
                        }
                    }

                }

                sendString += ".-.-.-";

                byte[] sendBytes = sendString.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, receivedPacket.getAddress(), receivedPacket.getPort());
                server.send(sendPacket);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

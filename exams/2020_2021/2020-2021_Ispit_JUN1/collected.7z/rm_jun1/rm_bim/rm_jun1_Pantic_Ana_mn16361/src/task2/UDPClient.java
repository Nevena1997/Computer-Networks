package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static int MAX_SIZE = 512;

    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            String s = sc.nextLine();
            byte[] sendBytes = s.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, InetAddress.getLocalHost(), UDPServer.PORT_NUMBER);
            client.send(sendPacket);

            byte[] receivedBytes = new byte[MAX_SIZE];
            DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
            client.receive(receivedPacket);
            String receivedString = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
            System.out.println(receivedString);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

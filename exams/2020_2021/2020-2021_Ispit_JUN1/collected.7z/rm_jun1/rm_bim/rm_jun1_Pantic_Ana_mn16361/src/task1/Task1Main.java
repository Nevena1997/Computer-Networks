package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {

    public static void main(String[] args) {

        Path dir = Paths.get("/home/ispit/Desktop/tests/urls");

        try {
            for (Path p : Files.newDirectoryStream(dir)) {
                new FileThread(p).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

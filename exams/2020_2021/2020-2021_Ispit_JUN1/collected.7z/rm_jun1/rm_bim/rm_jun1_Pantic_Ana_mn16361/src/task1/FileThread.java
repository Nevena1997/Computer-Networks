package task1;

import java.io.IOException;
import java.net.*;
import java.nio.file.Path;
import java.util.Scanner;

public class FileThread extends Thread {

    Path path;

    public FileThread(Path p) {
        this.path = p;
    }

    @Override
    public void run() {

        try (Scanner sc = new Scanner(this.path)) {

            String line;
            while (sc.hasNextLine()) {
                line = sc.nextLine();

                try {
                    URL u = new URL(line);
                    String host = u.getHost();

                    synchronized (System.out) {

                        if(isIP(host)) {
                            try {
                                InetAddress address = InetAddress.getByName(host);
                                if (address instanceof Inet6Address) {
                                    System.out.println("(v6) " + u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());
                                } else if (address instanceof Inet4Address) {
                                    System.out.print("(v4) " + u.getProtocol() + " " + u.getAuthority() + " " + u.getPath() + " [ ");

                                    for(int b : address.getAddress()) {
                                        System.out.print(b < 0 ? b+256 : b );
                                        System.out.print(" ");
                                    }
                                    System.out.println("]");

                                }
                            } catch (UnknownHostException e) {
                                System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());
                            }
                        }
                        else {
                            System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());
                        }
                    }
                } catch (MalformedURLException e) {
                    continue;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean isIP(String host) {

        if (host.chars().anyMatch(c -> c == ':'))
            return true;

        return !host.chars().anyMatch(c -> !Character.isDigit(c) && c != ':' && c != '.');
    }
}

package task3;

import javafx.util.Pair;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {

    public static final int port = 12345;
    public static List<Pair<Integer, String>> karte = new LinkedList<>();


    public static void main(String[] args) {

        System.out.println("Hello from NBIOServer");

        napraviKarte();

        try (ServerSocketChannel ssc = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            if (!ssc.isOpen() || !selector.isOpen()) {
                System.err.println("Greska");
                System.exit(1);
            }

            List<Pair<Integer, String>> spil = generisiIspisiSpil();

            ssc.bind(new InetSocketAddress(port));
            ssc.configureBlocking(false);
            ssc.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey posao = it.next();
                    it.remove();

                    try{
                        if (posao.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) posao.channel();
                            SocketChannel klijent = server.accept();
                            ByteBuffer bafer = ByteBuffer.allocate(2048);
                            klijent.configureBlocking(false);
                            SelectionKey kljuc = klijent.register(selector, SelectionKey.OP_READ);
                            kljuc.attach(bafer);

                        } else if (posao.isReadable()) {
                            SocketChannel klijent = (SocketChannel) posao.channel();
                            ByteBuffer bafer = (ByteBuffer) posao.attachment();

                            klijent.read(bafer);

                            if (bafer.toString().contains("\r\n\r\n")){
                                bafer.flip();
                                String broj = bafer.toString().substring(0, bafer.toString().indexOf("\r"));
                                int n = Integer.parseInt(broj);

                                String format;
                                if (n==1 || n < spil.size()){
                                    format = "Nedovoljan broj karata u spilu";
                                }else {
                                    int i = 0;
                                    List<Pair<Integer, String>> vrh = new LinkedList<>();
                                    for (Pair<Integer, String> p : spil){
                                        i++;
                                        if (i == n+1)
                                            break;
                                        vrh.add(p);
                                        spil.remove(p);
                                    }


                                    //posalji n karata klijentu
                                    //saljem u formatu vrednost.znak;vrednost.znak; .... ; ne ide na poslednju
                                    //kod klijenta radim split po ;
                                    format = napraviString(vrh, n);
                                }

                                bafer.clear();
                                bafer.put(format.getBytes());

                                bafer.flip();
                                posao.interestOps(SelectionKey.OP_WRITE);

                            }

                        } else if (posao.isWritable()) {
                            SocketChannel klijent = (SocketChannel) posao.channel();
                            ByteBuffer bafer = (ByteBuffer) posao.attachment();

                            klijent.write(bafer);


                            if (!bafer.hasRemaining()){
                                posao.cancel();
                            }




                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String napraviString(List<Pair<Integer, String>> vrh, int n) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Pair<Integer, String> p : vrh){
            i++;
            if (i == n){
                sb.append(p.getKey()).append(".").append(p.getValue());
                break;
            }
            sb.append(p.getKey()).append(".").append(p.getValue()).append(";");
        }

        return sb.toString();
    }



    private static List<Pair<Integer, String>> generisiIspisiSpil() {
        List<Pair<Integer, String>> spil = new LinkedList<>();
        for (Pair<Integer, String> p : karte){
            Pair<Integer, String> p1 = new Pair<>(p.getKey(), p.getValue());
            spil.add(p1);
        }

        Collections.shuffle(spil);

        for (Pair<Integer, String> p : spil){
            System.out.println(p.getKey()+"."+p.getValue());
        }

        return spil;
    }

    private static void napraviKarte() {

        for (int i = 2; i <= 14; i++){
            String[] znakovi = {"pik", "karo", "herc", "tref"};
            for (String s : znakovi){
                Pair<Integer, String> par = new Pair<>(i, s);
                karte.add(par);
            }

        }


    }

}

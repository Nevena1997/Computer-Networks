package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");

        try (DatagramSocket klijent = new DatagramSocket();
        Scanner sc = new Scanner(System.in)) {
            String linija = sc.nextLine();
            DatagramPacket zahtev = new DatagramPacket(linija.getBytes(), linija.getBytes().length,
                    InetAddress.getByName("localhost"), UDPServer.port);
            klijent.send(zahtev);

            byte [] bajtovi = new byte[1024];
            DatagramPacket odgovor = new DatagramPacket(bajtovi, bajtovi.length);
            klijent.receive(odgovor);

            String o = new String(odgovor.getData(), 0, odgovor.getLength());
            System.out.println(o);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static final int port = 23456;
    public static Map<Character, String> mapa = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");

        try (DatagramSocket server = new DatagramSocket(port)) {

            while (true) {

                byte[] bajtovi = new byte[1024];
                DatagramPacket zahtev = new DatagramPacket(bajtovi, bajtovi.length);
                server.receive(zahtev);

                ucitajMapu();

                String niska = new String(zahtev.getData(), 0, zahtev.getLength());
                String[] podaci = niska.split(" ");
                StringBuilder sb = new StringBuilder();

                for (String p : podaci) {
                    char[] karakteri = p.toCharArray();
                    for (char c : karakteri) {
                        char c1 = Character.toLowerCase(c);
                        sb.append(mapa.get(c1) + " ");
                    }
                    sb.append("   ");
                }

                sb.append(".-.-.-");
                String odg = sb.toString();
                DatagramPacket odgovor = new DatagramPacket(odg.getBytes(), odg.getBytes().length,
                        zahtev.getAddress(), zahtev.getPort());
                server.send(odgovor);

            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void ucitajMapu() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(
                "/home/ispit/Desktop/rm_jun_Djokic_Zorana_mr16071/morse.txt"
        )))) {

            String linija;
            while ((linija = in.readLine()) != null) {
                String[] podaci = linija.split(" ");
                Character c = podaci[0].toCharArray()[0];
                String kod = podaci[1];

                mapa.put(c, kod);
            }


        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

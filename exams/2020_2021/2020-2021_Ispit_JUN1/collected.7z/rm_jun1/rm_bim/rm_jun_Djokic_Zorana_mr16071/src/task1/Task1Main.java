package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");
        Path pocetni = Paths.get("/home/ispit/Desktop/tests/urls");
        try {
            DirectoryStream<Path> ds = Files.newDirectoryStream(pocetni);
            for (Path p : ds){
                if(Files.isReadable(p)){
                    new Thread(new Nit(p)).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Nit implements Runnable {

    private Path p;
    private Lock lock;

    public Nit(Path p) {
        this.p = p;
        this.lock = new ReentrantLock();
    }

    @Override
    public void run() {
        String linija;
        try (Scanner sc = new Scanner(p)) {
            while (sc.hasNextLine()) {
                linija = sc.nextLine();
                try {
                    URL url = new URL(linija);
                    String protokol = url.getProtocol();
                    String authority = url.getAuthority();
                    String path = url.getPath();

                    lock.lock();
                    System.out.println(protokol + " " + authority + " " + path);
                    String host = url.getHost();

                    if (proveriHost(host) == 1) {//v4
                        try {
                            byte[] bajtovi = InetAddress.getByName(host.trim()).getAddress();
                            for (byte b : bajtovi) {
                                b = b < 0 ? (byte) (b + 256) : b;
                            }
                            System.out.println("(v4) " + protokol + " " + path + " " + bajtovi);
                        } catch (UnknownHostException e) {

                        }

                    } else if (proveriHost(host) == -1) { //v6

                        System.out.println("(v6) " + protokol + " " + path);
                    } else {

                    }
                    lock.unlock();

                } catch (MalformedURLException e) {

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int proveriHost(String host) {
        if (host.contains(":"))
            return -1;
        boolean ind = true;
        for (char c : host.toCharArray()) {
            if (Character.isDigit(c) || c == '.') {
                continue;
            } else {
                ind = false;
                break;
            }
        }
        if (ind == true)
            return 1; //verzija 4
        else
            return 0;
    }
}

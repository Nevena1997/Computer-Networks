package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        System.out.println("Hello from NBIOClient");

        try (SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.port));
             Scanner sc = new Scanner(System.in)) {
            String broj = sc.next();

            ByteBuffer bafer = ByteBuffer.allocate(2048);

            bafer.put((broj + "\r\n\r\n").getBytes());

            bafer.flip();
            klijent.write(bafer);

            bafer.clear();
            klijent.read(bafer);
            bafer.flip();

            String odg = String.valueOf(bafer);
            String [] podaci = odg.split(";");
            for (String podatak : podaci){
                String [] karta = podatak.split(".");
                String vrednost = karta[0];
                String znak = karta[1];

                System.out.println("primljena karta: " + vrednost + " " + znak);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

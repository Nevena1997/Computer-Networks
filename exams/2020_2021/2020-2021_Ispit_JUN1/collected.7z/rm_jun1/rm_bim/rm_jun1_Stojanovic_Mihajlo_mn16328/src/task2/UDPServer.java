package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class UDPServer {

    public static void main(String[] args) throws IOException {

        Map<String, String> mapa = new HashMap<>();

        Path p = Paths.get("/home/ispit/Desktop/rm_jun1_Stojanovic_Mihajlo_mn16328/morse.txt");

        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())));

        String line;

        while((line = in.readLine()) != null){

            String[] linija = line.split(" ");
            mapa.put(linija[0], linija[1]);

        }

        //Iterator<String> iterator = mapa.keySet().iterator();
        /*while(iterator.hasNext()){
            String pom = iterator.next();
            System.out.println(pom + " " + mapa.get(pom));
        }
        */

        try (DatagramSocket socket = new DatagramSocket(23456)) {

            while (true) {
                byte[] buffer = new byte[256];
                DatagramPacket received = new DatagramPacket(buffer, buffer.length);
                socket.receive(received);
                String poruka = new String(received.getData(), 0, received.getLength(), StandardCharsets.UTF_8);

                int n = poruka.length();
                String modifikacija = "";

                for (int i = 0; i < n; i++) {

                    if (poruka.charAt(i) == ' ') {
                        modifikacija = modifikacija + "   ";
                    } else {
                        String key = poruka.charAt(i) + "";
                        modifikacija = modifikacija + mapa.get(key.toLowerCase()) + " ";

                    }
                }
                modifikacija = modifikacija + "   .-.-.-";

                byte[] b = modifikacija.getBytes(StandardCharsets.UTF_8);
                DatagramPacket send = new DatagramPacket(b, b.length, received.getAddress(), received.getPort());
                socket.send(send);

            }

        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

}

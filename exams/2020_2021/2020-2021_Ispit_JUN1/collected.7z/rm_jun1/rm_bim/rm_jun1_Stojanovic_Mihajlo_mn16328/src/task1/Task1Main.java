package task1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {


        Path p = Paths.get("/home/ispit/Desktop/tests/urls");

        try {
            for(Path put : Files.newDirectoryStream(p)){
                new Statistics(put).start();

            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }




    }
}

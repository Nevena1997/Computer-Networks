package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {

        try (DatagramSocket socket = new DatagramSocket();
        Scanner sc = new Scanner(System.in)) {

            System.out.println("Unesi rec:");
            String mess = sc.nextLine();

            byte[] buffer = mess.getBytes(StandardCharsets.UTF_8);
            DatagramPacket send = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), 23456);
            socket.send(send);

            byte[] buff = new byte[256];
            DatagramPacket receive = new DatagramPacket(buff, buff.length);
            socket.receive(receive);
            String primljeno = new String(receive.getData(), 0 , receive.getLength(), StandardCharsets.UTF_8);
            System.out.println("Odgovor servera:" + primljeno);



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

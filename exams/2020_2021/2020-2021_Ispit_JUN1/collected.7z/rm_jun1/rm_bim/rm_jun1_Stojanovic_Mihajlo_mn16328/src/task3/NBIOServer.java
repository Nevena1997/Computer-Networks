package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class NBIOServer {

    public static void main(String[] args) {

        List<String> karte = new ArrayList<>();
        String[] znakovi = {"Pik", "Karo", "Herc", "Tref"}; // 0 pik, 1 karo, 2 herc, 3 tref

        // broj znak

        for(int i = 2; i<15; i++){
            karte.add(i + " " + "0");
            karte.add(i + " " + "1");
            karte.add(i + " " + "2");
            karte.add(i + " " + "3");
        }

        Iterator<String> it = karte.iterator();
        while(it.hasNext()){
            String[] linija = it.next().split(" ");
            System.out.println(linija[0] + "." + znakovi[Integer.parseInt(linija[1])]);

        }


        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("nije dobro otboreno");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){

                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()){

                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try {


                        if (key.isAcceptable()) {

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey sk = client.register(selector, SelectionKey.OP_READ);
                            ByteBuffer buffer = ByteBuffer.allocate(52 * 8);
                            sk.attach(buffer);

                        } else if (key.isReadable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer); //upisan nas broj u bafer

                            buffer.flip(); //spreman je za citanje


                                int broj = buffer.getInt(); //broj karti koje treba poslati

                                buffer.clear(); //bafer je spreman za pisanje

                                if(broj > 0 && broj < karte.size()) {

                                    for (int i = 0; i < broj; i++) {

                                        String card = karte.get(0);
                                        karte.remove(0);

                                        String[] pom = card.split(" ");
                                        int br = Integer.parseInt(pom[0]);
                                        int znak = Integer.parseInt(pom[1]);

                                        buffer.putInt(br);
                                        buffer.putInt(znak);

                                    }



                                    buffer.flip(); //sppreman za citanje

                                    key.interestOps(SelectionKey.OP_WRITE);
                                }
                                else {

                                    buffer.putInt(1);
                                    buffer.flip();
                                    key.interestOps(SelectionKey.OP_WRITE);


                                }




                        } else if (key.isWritable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.write(buffer);

                            if(!buffer.hasRemaining()){
                                buffer.clear();
                                key.cancel();
                                key.channel().close();
                            }



                        }


                    } catch (IOException e) {
                        key.cancel();
                        key.channel().close();
                        e.printStackTrace();
                    }

                }


            }



        } catch (IOException e) {
            e.printStackTrace();
        }



    }


}

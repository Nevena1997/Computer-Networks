package task1;

import javax.naming.MalformedLinkException;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Statistics extends Thread {

    private Path p;
    List<URL> lista = new ArrayList<>();

    public Statistics(Path p) {
        this.p = p;
    }

    @Override
    public void run() {

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))) {

            String line;
            while((line = in.readLine()) != null){

                try {
                    URL u = new URL(line);
                    lista.add(u);


                }
                catch (MalformedURLException e){
                    continue;
                }



            }

            synchronized (System.out) {
                for (URL url : lista) {
                    System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

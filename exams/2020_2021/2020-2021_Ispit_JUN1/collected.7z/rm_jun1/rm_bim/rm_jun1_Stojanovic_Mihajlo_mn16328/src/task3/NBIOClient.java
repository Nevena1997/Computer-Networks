package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", 12345));
             Scanner sc = new Scanner(System.in)) {

            String[] znakovi = {"Pik", "Karo", "Herc", "Tref"};


            System.out.println("Unesi broj karata koji zelis:");
            int broj = sc.nextInt();

            ByteBuffer buffer = ByteBuffer.allocate(4);
            buffer.putInt(broj);

            /*
            broj  5
                5 * (4+4)8 bajtova
    */
            buffer.flip();//sprema se za citanje

            client.write(buffer);

            ByteBuffer primljeno = ByteBuffer.allocate(broj*8);

            client.read(primljeno);

            primljeno.flip(); //da bi mogli citati

            for(int i = 0; i < broj; i++){

                int karta = primljeno.getInt();
                if(karta == 1){
                    System.out.println("Nije poslat odgovarajuc broj (mozda je nestalo karti ako je unet broj pozitivan)");
                    break;
                }
                int znak = primljeno.getInt();

                System.out.println("Broj: " + karta + " Znak: " + znakovi[znak]);




            }







        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

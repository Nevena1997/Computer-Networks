package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public class StatRunnable implements Runnable {

    private Path p;

    public StatRunnable(Path p) {

        this.p = p;
    }

    @Override
    public void run() {

        search(p);
    }

    private void search(Path p) {

        try (BufferedReader in = new BufferedReader(new InputStreamReader(Files.newInputStream(p)))) {

            String line;
            synchronized (System.out) {
                System.out.println("***" + p.getFileName() + "***");
                while ((line = in.readLine()) != null) {

                    try {
                        URL u = new URL(line);


                        String protocol = u.getProtocol();
                        String authority = u.getAuthority();
                        String path = u.getPath();

                        System.out.println(protocol + " " + authority + " " + path);

                    } catch (MalformedURLException e) {
                        continue;
                    }
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

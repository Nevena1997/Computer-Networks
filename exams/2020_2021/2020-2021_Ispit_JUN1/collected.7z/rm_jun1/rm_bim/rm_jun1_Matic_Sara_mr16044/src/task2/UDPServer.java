package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;

public class UDPServer {

    public static int PORT_NUMBER = 23456;

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(PORT_NUMBER)) {

            byte[] receivedByte = new byte[UDPClient.BUFF_SIZE];
            DatagramPacket receivedPacket = new DatagramPacket(receivedByte, receivedByte.length);
            server.receive(receivedPacket);
            String receivedString = new String(receivedPacket.getData(), 0, receivedPacket.getLength());

            morseCode(receivedString);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void morseCode(String receivedString) {


        char[] array = receivedString.toCharArray();
        String morseCode = "";
        for (char ch : array) {

            if (ch == ' ') {
                morseCode = morseCode + "   ";
            } else {

                try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("morse.txt")))) {
                    String line;
                    while ((line = in.readLine()) != null) {

                        if (line.charAt(0) == Character.toLowerCase(ch)) {

                            String code = line.split(" ")[1]; //izdvajamo za svako slovo samo kod
                            morseCode = morseCode + code;
                            morseCode = morseCode + " ";


                        }


                    }


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        morseCode = morseCode + "   .-.-.-";
        System.out.println(morseCode);

    }

}

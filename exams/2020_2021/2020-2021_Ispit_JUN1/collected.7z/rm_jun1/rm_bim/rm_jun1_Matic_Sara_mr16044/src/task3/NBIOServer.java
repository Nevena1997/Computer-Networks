package task3;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.SocketAddress;
import java.net.SocketOption;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class NBIOServer {

    public static int PORT_NUMBER = 12345;
    public static ArrayList<String> karte = new ArrayList<>();
    public static ArrayList<String> izvucene_karte = new ArrayList<>();


    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if (!serverChannel.isOpen() || !selector.isOpen()) {
                System.err.println("server channel or selector cannot be opened");
                System.exit(1);
            }


            ArrayList<Integer> brojevi = new ArrayList<>(13); //brojevi od 2 do 14
            for (int i = 2; i <= 14; i++) {
                brojevi.add(i);
            }
            ArrayList<String> znakovi = new ArrayList<>(4); //sva 4 znaka
            znakovi.add("Pik");
            znakovi.add("Herc");
            znakovi.add("Tref");
            znakovi.add("Karo");


            //kombinujemo sve znakove sa svim brojevima da bismo dobili spil od 52 karte
            for (int j = 0; j < 13; j++) {
                for (int k = 0; k < 4; k++) {
                    String karta = String.valueOf(brojevi.get(j)) + "." + znakovi.get(k);
                    karte.add(karta);
                    System.out.println(karta); //ispisuje se spil na standardni izlaz
                }
            }

            serverChannel.bind(new InetSocketAddress(PORT_NUMBER));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {

                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try {

                        if (key.isAcceptable()) {

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(1024);
                            clientKey.attach(buffer);


                        } else if (key.isReadable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);

                            int broj_karata = 0;

                            buffer.flip();
                            broj_karata = buffer.getInt();
                            buffer.clear();

                            //proveravamo uslov
                            if (broj_karata > karte.size() || broj_karata < 1) {
                                System.err.println("Broj karata nije odgovarajuci!");
                            }

                            //izvlacimo karte iz spila i uklanjamo iz liste one koje smo izvukli
                            String izvucena_karta;
                            buffer.clear(); //pripremamo bafer da unesemo u njega izvucene karte
                            for (int i = 0; i < broj_karata; i++) {
                                izvucena_karta = karte.get(i);
                                karte.remove(izvucena_karta);
                                //System.out.println(izvucena_karta);

                                buffer.put(izvucena_karta.getBytes()); //ubacujemo u bafer izvucene karte redom

                            }
                            buffer.put((byte)'\r');
                            buffer.put((byte)'\n');


                            key.interestOps(SelectionKey.OP_WRITE);


                        } else if (key.isWritable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            buffer.flip();
                            client.write(buffer); //saljemo klijentu izvucene karte
                            buffer.clear();


                            key.interestOps(SelectionKey.OP_READ);

                        }


                    } catch (IOException e) {

                    }

                }


            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

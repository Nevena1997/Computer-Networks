package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static int BUFF_SIZE = 2048;

    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            InetAddress host = InetAddress.getByName("localhost");

            String sendString=sc.nextLine();
            byte[] sendBytes = sendString.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, host, UDPServer.PORT_NUMBER);

            client.send(sendPacket); //klijent salje serveru nisku






        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

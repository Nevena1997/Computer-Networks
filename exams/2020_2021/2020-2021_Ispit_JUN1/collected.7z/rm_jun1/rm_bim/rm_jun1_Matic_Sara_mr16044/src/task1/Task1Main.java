package task1;

import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class Task1Main {

    public static void main(String[] args) {

        Path dir = Paths.get("/home/ispit/Desktop/tests/urls");
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {

           for(Path p : ds) {
               StatRunnable sr = new StatRunnable(p);
               Thread t = new Thread(sr);
               t.start();
           }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

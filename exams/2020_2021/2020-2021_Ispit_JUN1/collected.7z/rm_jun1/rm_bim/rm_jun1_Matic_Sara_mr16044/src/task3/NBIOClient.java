package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.PORT_NUMBER));
             Scanner sc = new Scanner(System.in)) {

            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int broj_karata;

            while(true) {

                broj_karata = sc.nextInt();
                buffer.putInt(broj_karata);
                buffer.put((byte) '\r');
                buffer.put((byte) '\n');

                buffer.flip();
                client.write(buffer); //saljemo serveru broj karata
                buffer.clear();

                //dobijamo od servera karte
                client.read(buffer);
                buffer.flip();

                //nisam uspela da zavrsim do kraja...



            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

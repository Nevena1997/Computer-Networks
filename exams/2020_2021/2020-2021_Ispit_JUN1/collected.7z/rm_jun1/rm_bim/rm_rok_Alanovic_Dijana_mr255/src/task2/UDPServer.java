package task2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.channels.DatagramChannel;
import java.util.ArrayList;

import static java.nio.charset.StandardCharsets.UTF_8;

public class UDPServer {
    public static  int PORT = 23456;

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");
        try (DatagramSocket server = new DatagramSocket(PORT)) {

                byte[] bytes = new byte[512];
                DatagramPacket receive = new DatagramPacket(bytes, bytes.length);
                server.receive(receive);
                String poruka = new String(bytes, 0, receive.getLength(), UTF_8);
                System.out.println("prihvacen paket " + poruka);
                char[] reci = poruka.toCharArray();

                String rec = " ";


                for (int i = 0; i < reci.length; i++) {


                    BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("morse.txt")));
                    String pogodak;
                    while ((pogodak = in.readLine()) != null) {
                        ;
                        if ((pogodak.contains(String.valueOf(reci[i])))) {
                            rec = rec + (pogodak.substring(pogodak.indexOf(" ")));

                            break;
                        }

                    }
                    in.close();


                }
                rec = rec + "   ._._._";
                //System.out.println(rec);
                byte[] zaSlanje = rec.getBytes(UTF_8);
                DatagramPacket date = new DatagramPacket(zaSlanje, zaSlanje.length, receive.getAddress(), PORT);
                server.send(date);
            } catch(SocketException e){
                e.printStackTrace();
            } catch(IOException e){
                e.printStackTrace();
            }

    }

}

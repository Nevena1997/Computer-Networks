package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

import static java.nio.charset.StandardCharsets.UTF_8;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost",NBIOServer.PORT));
             Scanner sc = new Scanner(System.in)){

            while (true) {
                ByteBuffer buff = ByteBuffer.allocate(512);

                buff.put(sc.nextLine().getBytes(UTF_8));
                buff.flip();
                client.write(buff);
                ByteBuffer newbuff = ByteBuffer.allocate(512);
                client.read(newbuff);

                System.out.println(new String(newbuff.array(), 0, newbuff.position(), UTF_8));


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

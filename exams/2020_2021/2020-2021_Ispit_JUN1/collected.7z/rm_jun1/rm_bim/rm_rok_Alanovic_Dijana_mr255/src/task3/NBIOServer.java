package task3;


import org.w3c.dom.ranges.Range;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import static java.nio.charset.StandardCharsets.UTF_8;

public class NBIOServer {
    public static int PORT = 12345;
    private static int brojKarata = 52;
    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");
        Set<String> spil = new HashSet<>();
        Random broj = new Random();
        Random znak = new Random();
        int znak2;
        for(int i =0; i<52;i++){
            znak2 = znak.nextInt();
            //System.out.println(znak2);
            if (0 == znak2) {

                spil.add(String.valueOf(broj.nextInt(13) + 2) + "." +"herc");
            }else if (1 == znak2) {

                spil.add(String.valueOf(broj.nextInt(13)+2) + "." +"pik");
            }else if (2 == znak2) {

                spil.add(String.valueOf(broj.nextInt(13)+2) + "." +"tref");
            }else if (3 == znak2) {

                spil.add(String.valueOf(broj.nextInt(13)+2) + "." +"karo");
            }

        }

        try (ServerSocketChannel socketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()){
            if (!selector.isOpen() || !socketChannel.isOpen()){
                System.err.println("-1");
                System.exit(1);
            }
            socketChannel.bind(new InetSocketAddress(PORT));
            socketChannel.configureBlocking(false);
            socketChannel.register(selector, SelectionKey.OP_ACCEPT);
            while (true){
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()){
                        ServerSocketChannel servet = (ServerSocketChannel) key.channel();
                        SocketChannel client = servet.accept();
                        client.configureBlocking(false);
                        ByteBuffer buff = ByteBuffer.allocate(512);
                        SelectionKey clientKey = client.register(selector,SelectionKey.OP_READ);
                        clientKey.attach(buff);

                    }if (key.isReadable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();
                        client.read(buff);
                        if (buff.position()!=0){

                            String brojK1 = new String(buff.array(), 0, buff.position(), UTF_8);
                            int brojK = Integer.parseInt(brojK1);
                            buff.clear();
                            //System.out.println("ulazi");
                            if (brojK>brojKarata){
                                //System.out.println("ulazi");
                                //posalji poruku da mnogo trazi karata
                                //System.out.println("nema dob");
                                buff.put("Nema toliko karata u spilu".getBytes(UTF_8));
                            }else {
                                //salju se karte
                                //System.out.println("ulazi");
                                Iterator<String> it1 = spil.iterator();
                            for (int i = 0 ; i<brojK; i++) {
                                //System.out.println(it.next());
                                //buff.put(it1.next().getBytes(UTF_8));
                                buff.put("\n".getBytes(UTF_8));
                                //it1.remove();
                            }
                            }
                            buff.flip();
                        }

                        key.interestOps(SelectionKey.OP_WRITE);

                    }if (key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        client.write(buff);
                        //if (!buff.hasRemaining()){
                            //key.cancel();
                        //}

                    }

                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

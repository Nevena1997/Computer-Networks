package task2;

import java.io.IOException;
import java.net.*;
import java.nio.channels.DatagramChannel;
import java.util.Scanner;

import static java.nio.charset.StandardCharsets.UTF_8;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)){

            String poruka = sc.nextLine();
            byte[] bytes = poruka.getBytes();
            DatagramPacket data = new DatagramPacket(bytes, bytes.length, InetAddress.getLocalHost(),UDPServer.PORT);
            client.send(data);

            byte[] bytes1 = new byte[1024];
            DatagramPacket receive = new DatagramPacket(bytes1, bytes1.length);
            client.receive(receive);

            System.out.println( new String(bytes1, 0, receive.getLength(), UTF_8));

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");
        String put = "/home/ispit/Desktop/tests/urls";
        try (DirectoryStream ds = Files.newDirectoryStream(Paths.get(put))){
            Iterator it =ds.iterator();
            while (it.hasNext()){
                Path p = (Path) it.next();
                new Thread(new Klasa(p)).start();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.io.*;
import java.net.Inet4Address;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;

public class Klasa implements Runnable {
    private Path path;

    public Klasa(Path p) {
        this.path = p;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path.toString())))){
            String line;
            while ((line=in.readLine())!=null){
                try {
                    URL u = new URL(line);
                    System.out.println(u.getProtocol() +" "+ u.getAuthority()+ " " + u.getPath());
                }catch (Exception e){
                    continue;
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

public class UDPServer {

    public static final int PORT=23456;

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");

        try(DatagramSocket socket =new DatagramSocket(PORT)){
            while(true){
                byte [] bytes=new byte[1024];
                DatagramPacket recieved=new DatagramPacket(bytes,bytes.length,socket.getInetAddress(),PORT);

                socket.receive(recieved);

                System.out.println("Recieved");

                String line= new String(bytes,0,bytes.length);

                System.out.println("Pristigla linija je "+line);

                String newline="";



                    for (int i = 0; i < line.length(); i++) {

                        Scanner sc = new Scanner(new File("/home/ispit/Desktop/rm_jun1_Dragovic_Stevan_ml16331/morse.txt"));

                        while (sc.hasNext()) {
                            String line1 = sc.nextLine();
                            String[] tokens = line1.split(" ");
                            if(line.charAt(0)==' '){
                                newline+="   ";
                            }
                            if (tokens[0].equalsIgnoreCase(line.charAt(i)+"")) {
                                newline += tokens[1] + " ";
                            } else {
                                continue;
                            }

                        }
                        sc.close();


                    }
                    newline+="   ";


                newline+=".-.-.-";
                System.out.println("Nova linija je"+newline);

                byte [] buff=newline.getBytes(StandardCharsets.UTF_8);

                DatagramPacket send=new DatagramPacket(buff,buff.length,recieved.getAddress(),recieved.getPort());

                socket.send(send);

                System.out.println("Send!");




            }
        } catch (SocketException | FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

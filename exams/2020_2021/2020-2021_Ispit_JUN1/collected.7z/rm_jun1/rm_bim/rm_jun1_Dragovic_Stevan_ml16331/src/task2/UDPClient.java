package task2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static final int PORT=23456;

    public static int duzinaStringa=0;

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");



        try(DatagramSocket socket=new DatagramSocket(); Scanner sc=new Scanner(System.in)) {


            String line=sc.nextLine();
            duzinaStringa=line.length();

            InetAddress host=InetAddress.getByName("localhost");

            byte []buffer=line.getBytes(StandardCharsets.UTF_8);

            DatagramPacket request=new DatagramPacket(buffer,buffer.length,host,PORT);

            socket.send(request);

            byte [] buf=new byte[1024];

            DatagramPacket recieved=new DatagramPacket(buf,1000);

            socket.receive(recieved);

            String line1=new String(buf,0,buf.length);

            System.out.println("Dobijena linija je "+line1);



        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

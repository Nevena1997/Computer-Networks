import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PomocnaKlasa {

    public static void main(String[] args) throws FileNotFoundException {






    }
}

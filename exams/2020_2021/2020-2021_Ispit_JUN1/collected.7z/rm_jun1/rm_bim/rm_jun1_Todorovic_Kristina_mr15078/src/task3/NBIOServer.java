package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {
    public static final int PORT=12345;

    public static void main(String[] args) {
        Map<Integer, String> mapaZnakova = new HashMap<>();
        Map<Integer, Integer> mapaKarata = new HashMap<>();
        mapaZnakova.put(1, "Pik");
        mapaZnakova.put(2, "Herc");
        mapaZnakova.put(3, "Tref");
        mapaZnakova.put(4, "Karo");
        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Server channel or selector cannot be opened");
                System.exit(1);
            }

            Random randInteger = new Random();
            for(int i=0; i<52; i++) {
                mapaKarata.put(randInteger.nextInt(13) + 2, randInteger.nextInt(4) + 1);
            }
            for(int key : mapaKarata.keySet()){
                System.out.println(key + "." + mapaZnakova.get(mapaKarata.get(key)));
            }
            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){

                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
                while(iterator.hasNext()){
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try{

                        if(key.isAcceptable()){
                            ServerSocketChannel s = (ServerSocketChannel) key.channel();
                            SocketChannel client = s.accept();

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                            ByteBuffer buffer = ByteBuffer.allocate(4096);
                            clientKey.attach(buffer);

                        }else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);
                            if(buffer.position()==3) {
                                buffer.flip();
                                int brojKarata = buffer.getInt();

                                buffer.clear();
                                if (brojKarata < 1 || (mapaKarata.size() < brojKarata)) {
                                    String message = "Nedozvoljeno\r\n\r\n";
                                    buffer.put(message.getBytes());

                                } else {
                                    while (brojKarata > 0) {
                                        for (int k : mapaKarata.keySet()) {
                                            String karta = k + " " + mapaZnakova.get(mapaKarata.get(k)) + '\r' + '\n';
                                            buffer.put(karta.getBytes());
                                            mapaKarata.remove(k);
                                        }
                                        String dvaNovaReda = "\r\n\r\n";
                                        buffer.put(dvaNovaReda.getBytes());

                                        brojKarata--;
                                    }


                                }
                                buffer.flip();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }



                        }else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();


                            client.write(buffer);
                            if(!buffer.hasRemaining()) {
                                client.close();
                            }
                        }


                    }catch (IOException e){
                        key.cancel();
                        key.channel().close();

                    }

                }





            }






        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

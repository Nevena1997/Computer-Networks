package task1;

import java.io.*;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;

public class FileStatistics extends Thread {

    private Path file;

    FileStatistics(Path p) {
        this.file = p;
    }

    public void run() {

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.file.toString())))) {

            String lineURL;
            while ((lineURL = in.readLine()) != null) {
                try {
                    URL url = new URL(lineURL);
                    synchronized (System.out) {
                        if (hasIP(url)) {
                            byte[] bytes=getBytes(url);
                            if (bytes.length == 4) {
                                String stringBytes = new String(bytes, 0, bytes.length);
                                System.out.println("(v4)" + url.getProtocol() + " " + url.getAuthority() + " " + url.getPath() + stringBytes);

                            } else if(bytes.length==16){
                                System.out.println( "(v6)" + url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                            }
                        } else {
                            System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                        }
                    }

                } catch (MalformedURLException e) {
                    continue;
                }

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean hasIP(URL url) {
        String hostName = url.getHost();
        if (hostName.indexOf(':') != -1)
            return true;

        return hostName.chars().allMatch(c -> Character.isDigit(c) || c == '.');
    }

    private byte[] getBytes(URL url) throws UnknownHostException {

        String hostAddress = url.getHost();

        InetAddress address = InetAddress.getByName(hostAddress);
        byte[] bytes = address.getAddress();

        return bytes;


    }

}

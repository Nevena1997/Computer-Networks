package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static final int PORT=23456;
    public static final int BUF_SIZE=1024;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT)){
            byte[] bytes = new byte[BUF_SIZE];
            DatagramPacket receivedPacket = new DatagramPacket(bytes, bytes.length);
            server.receive(receivedPacket);
            String receivedMessage = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
            String codedMorse = codeMessage(receivedMessage);

            byte[] coded = codedMorse.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(coded, coded.length, receivedPacket.getAddress(), receivedPacket.getPort());
            server.send(sendPacket);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static String codeMessage(String receivedMessage) throws IOException{
        Map<Character, String> mapaMorze = new HashMap<>();
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_jun1_Todorovic_Kristina_mr15078/morse.txt")))){
            String line;
            while((line=in.readLine())!=null)
                mapaMorze.put(line.charAt(0), line.substring(line.indexOf(' ')+1, line.indexOf(' ', 2)));

            StringBuffer codedMessage=new StringBuffer("");
            for(char c : receivedMessage.toCharArray()) {
                if (c == ' ') {
                    codedMessage.append("   ");
                }
                codedMessage.append(mapaMorze.get(c));
                codedMessage.append(" ");
            }
            codedMessage.append(".-.-.-");

            return codedMessage.toString();

        }

    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    private static final int BUF_SIZE = 1024;

    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket(); Scanner sc = new Scanner(System.in)){

            String line = sc.nextLine();
            byte[] lineBytes = line.getBytes();
            InetAddress host = InetAddress.getByName("localhost");
            DatagramPacket sendPacket = new DatagramPacket(lineBytes, lineBytes.length, host, 23456);
            socket.send(sendPacket);

            byte[] receivedBytes = new byte[BUF_SIZE];
            DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, BUF_SIZE);
            socket.receive(receivedPacket);
            String receivedString = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
            System.out.println(receivedString);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

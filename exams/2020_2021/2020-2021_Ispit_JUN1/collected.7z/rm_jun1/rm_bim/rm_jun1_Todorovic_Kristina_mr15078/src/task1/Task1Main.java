package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) throws IOException {

        Path dirURL = Paths.get("/home/ispit/Desktop/tests");
        for(Path p : Files.newDirectoryStream(dirURL)){
            new FileStatistics(p).start();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.PORT));
            Scanner sc = new Scanner(System.in)){

            ByteBuffer buffer = ByteBuffer.allocate(4096);

            int br = sc.nextInt();
            buffer.putInt(br);
            buffer.flip();
            client.write(buffer);

            buffer.clear();
            client.read(buffer);
            buffer.flip();
            String line = new String(buffer.array(), 0, buffer.limit());


            if(line.equalsIgnoreCase("Nedozvoljeno\r\n\r\n")) {
                System.out.println("Nedovoljno karata u spilu\n");
            }else{
                String[] lines = line.split("\r\n");
                for(String l : lines)
                    System.out.println(l);
            }



        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

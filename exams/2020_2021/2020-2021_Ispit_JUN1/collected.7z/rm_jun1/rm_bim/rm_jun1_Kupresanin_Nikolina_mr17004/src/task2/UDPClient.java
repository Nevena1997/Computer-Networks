package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        try(DatagramSocket socket=new DatagramSocket();
            Scanner ulaz=new Scanner(System.in);
        ) {
            InetAddress host=InetAddress.getLocalHost();
            String zaSlanje=ulaz.nextLine();

            DatagramPacket request=new DatagramPacket(zaSlanje.getBytes(),zaSlanje.getBytes().length,host,UDPServer.DEF_PORT);
            socket.send(request);

            DatagramPacket response=new DatagramPacket(new byte[1024],1024);
            socket.receive(response);

            String ispis=new String(response.getData(),0,response.getLength());
            System.out.println(ispis);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

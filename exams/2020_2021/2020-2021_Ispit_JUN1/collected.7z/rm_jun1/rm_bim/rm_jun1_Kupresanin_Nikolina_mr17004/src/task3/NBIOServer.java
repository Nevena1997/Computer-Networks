package task3;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class NBIOServer {
    public static int DEF_PORT=12345;
    public static List<String> kombinacije=new ArrayList<>();

    public static void main(String[] args) {
        for (int i=2;i<=14;i++){
           kombinacije.add(i+".Pik");
            kombinacije.add(i+".Herc");
            kombinacije.add(i+".Karo");
            kombinacije.add(i+".Tref");
        }
        /*
        System.out.println("Pre mesanja: ");
        for (String s:kombinacije)
            System.out.println(s);
            */


        Collections.shuffle(kombinacije);

        System.out.println();
        System.out.println("Spil: ");
        for (String s:kombinacije)
            System.out.println(s);


        //----------------------------

        try(ServerSocketChannel serverChannel=ServerSocketChannel.open();
            Selector selector=Selector.open();
        ){
            if (!serverChannel.isOpen() || !selector.isOpen() ){
                System.err.println("nesto nije otvoreno");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(DEF_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){
                selector.select();
                Iterator<SelectionKey> it=selector.selectedKeys().iterator();

                while (it.hasNext()){
                    SelectionKey key=it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()){
                            ServerSocketChannel server= (ServerSocketChannel) key.channel();
                            SocketChannel client=server.accept();
                            //System.err.println("Primljen klijent");

                            client.configureBlocking(false);
                            SelectionKey clientKey=client.register(selector,SelectionKey.OP_READ);

                            ByteBuffer buffer=ByteBuffer.allocate(1024);
                            buffer.limit(4);
                            clientKey.attach(buffer);
                        }else if (key.isReadable()){
                            SocketChannel client= (SocketChannel) key.channel();
                            ByteBuffer buffer= (ByteBuffer) key.attachment();

                            client.read(buffer);

                            if (!buffer.hasRemaining()){
                                buffer.rewind();
                                Integer stiglo=buffer.getInt();
                                //System.err.println("stiglo od klijenta "+stiglo);

                                String zaSlanje;
                                StringBuffer sb=new StringBuffer("");
                                if (stiglo<=0 || stiglo>kombinacije.size()){
                                    zaSlanje="Nemoguce je poslati toliko karata\n";
                                }
                                else {
                                    for (int i = 0; i < stiglo; i++) {
                                        sb.append(kombinacije.get(0)).append("\n");
                                        kombinacije.remove(0);
                                    }
                                    System.err.println("velicina spila je sad " + kombinacije.size());
                                    zaSlanje = sb.toString();
                                }

                                buffer.clear();
                                buffer.put(zaSlanje.getBytes());
                                buffer.flip();
                                buffer.limit(zaSlanje.getBytes().length);

                                //System.err.println(buffer.limit()); vratim na 1024
                                key.interestOps(SelectionKey.OP_WRITE);

                            }

                        }else if (key.isWritable()){
                            SocketChannel client= (SocketChannel) key.channel();
                            ByteBuffer buffer= (ByteBuffer) key.attachment();

                            client.write(buffer);

                            if (!buffer.hasRemaining()){
                                //System.err.println("saljem ");

                                key.cancel();
                                key.channel().close();
                            }
                        }
                    }catch (Exception ex){
                        key.cancel();
                        key.channel().close();
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

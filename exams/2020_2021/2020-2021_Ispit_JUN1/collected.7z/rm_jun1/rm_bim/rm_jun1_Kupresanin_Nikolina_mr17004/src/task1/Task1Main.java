package task1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {

        String dir="/home/ispit/Desktop/tests/urls";
        Path dirp= Paths.get(dir);

        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dirp)) {
            for (Path p:ds){
                PrviNit nit=new PrviNit(p);
                nit.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task1;

import java.io.IOException;
import java.net.*;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Scanner;

public class PrviNit extends Thread {
    private Path p;

    public PrviNit(Path p) {
        this.p=p;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(p)) {
            while (sc.hasNextLine()){
                try {
                    String linija=sc.nextLine();
                    URL url=new URL(linija);

                    String host=url.getHost();
                    String ispis="";
                    if (!host.chars().anyMatch(Character::isLetter)){
                        if (host.contains(".")){
                            ispis="(v4) "+url.getProtocol()+" "+url.getPath()+" ["+host.replace("." ," ")+"]";

                        }else if (host.contains(":")){
                            ispis="(v6) "+url.getProtocol()+" "+url.getPath();
                        }
                    }

                    synchronized (System.out){

                        System.out.println("------");
                        //System.out.println(linija);
                        System.out.println(url.getProtocol()+" "+url.getAuthority()+" "+url.getPath());
                        System.out.println(ispis);

                    }


                }catch (MalformedURLException e){
                    //ignorisem nevalidan url
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.DEF_PORT));
             Scanner sc=new Scanner(System.in)
        ) {
            ByteBuffer bafer=ByteBuffer.allocate(1024);
            WritableByteChannel out= Channels.newChannel(System.out);
            /*
            radi lepo provera
            bafer.limit(2);
            System.out.println(bafer.limit());
            bafer.limit(10);
            System.out.println(bafer.limit());
            */

            bafer.limit(4);
            Integer brojKarata=sc.nextInt();
            bafer.putInt(brojKarata);
            bafer.flip();
            client.write(bafer);

            bafer.clear();
            bafer.limit(1024);


            bafer.clear();
            client.read(bafer);
            bafer.flip();
            out.write(bafer);





        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {
    public static int DEF_PORT=23456;
    private  static Map<String,String> mapa=new HashMap<>();

    public static void main(String[] args) {
        String putanjaDoFajla="/home/ispit/Desktop/rm_jun1_Kupresanin_Nikolina_mr17004/morse.txt";

        try(Scanner sc=new Scanner(new FileInputStream(putanjaDoFajla))){
            while (sc.hasNextLine()){
                mapa.put(sc.next(),sc.next());
            }
            //for (Map.Entry e: mapa.entrySet()){
            //    System.out.println(e.getKey()+" : "+ e.getValue());
            //}
            //obrisala sam prazan red u fajlu da ne pravi problem


            try(DatagramSocket socket=new DatagramSocket(DEF_PORT)){
                while (true){
                    DatagramPacket request=new DatagramPacket(new byte[1024],1024);
                    socket.receive(request);
                    String stiglo=new String(request.getData(),0,request.getLength());
                    StringBuffer sb=new StringBuffer("");
                    stiglo.chars().forEach(x->{
                        //System.out.println(String.valueOf((char)x));
                        String znak=String.valueOf((char)x).toLowerCase();
                        if (znak.equals(" ")){
                            sb.append("\t\t\t");
                            //veci razmak radi lakseg uocavanja sam stavila
                        }else {
                            sb.append(mapa.get(znak)).append("\t");
                        }
                    });
                    sb.append(".-.-.-");

                    String zaSlanje=sb.toString();
                    DatagramPacket response=new DatagramPacket(zaSlanje.getBytes(),zaSlanje.getBytes().length,request.getAddress(),request.getPort());
                    socket.send(response);
                }
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }

}

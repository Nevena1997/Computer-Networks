package task1;

import java.io.IOException;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;

class StatsNit extends Thread {

    private static final Object GLOBAL_LOCK = new Object();
    private final Path path;

    StatsNit(Path path) {

        this.path = path;
    }

    public void run() {

        try {
            Files.lines(path).forEach(
                    line -> {
                        try {
                            URL url = new URL(line);

                            synchronized (GLOBAL_LOCK) {

                                System.out.printf("%s %s %s\n", url.getProtocol(), url.getAuthority(), url.getPath());

                                InetAddress address = InetAddress.getByName(url.getHost());


                                String verzija = address.getAddress().length > 4 ? "6" : "4";

                               /* if (url.getHost().matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
                                    verzija = "4";
                                } else if (url.getHost().matches("[0-9a-f]+:+")) {

                                    verzija = "6";
                                }*/

                                System.out.printf(
                                        "(v%s) %s %s %s\n",
                                        verzija,
                                        url.getProtocol(),
                                        url.getPath(),
                                        myToString(address.getAddress()));
                            }
                        } catch (MalformedURLException | UnknownHostException e) {
                            // e.printStackTrace();
                        }
                    }
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String myToString(final byte[] niz) {

        final int[] niz2 = new int[niz.length];

        for (int i = 0; i < niz.length; ++i) {

            niz2[i] = niz[i];

            if (niz2[i] < 0) {
                niz2[i] += 255;
            }

        }

        return Arrays.toString(niz2);
    }
}

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");

        try {
            Files.walk(Paths.get("/home/ispit/Desktop/tests/urls")).forEach(
                    p -> {

                        if (!Files.isDirectory(p)) {
                            System.out.println("Obrada fajla: " + p.getFileName());
                            StatsNit nit = new StatsNit(p);
                            nit.start();
                        }

                    }

            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

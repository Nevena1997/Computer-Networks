package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");

        try (
                DatagramSocket datagramSocket = new DatagramSocket();
                Scanner scanner = new Scanner(System.in);
        ) {

            while (scanner.hasNext()) {

                final String line = scanner.nextLine();
                byte[] buff = line.getBytes(StandardCharsets.UTF_8);

                ByteArrayOutputStream baos = new ByteArrayOutputStream(4 + buff.length);
                DataOutputStream dos = new DataOutputStream(baos);

                // custom protocol - send length of the byte as int and then actual bytes
                dos.writeInt(buff.length);
                dos.write(buff);

                byte[] responseBuff = baos.toByteArray();

                DatagramPacket request = new DatagramPacket(responseBuff, responseBuff.length, InetAddress.getLoopbackAddress(), UDPServer.PORT);
                datagramSocket.send(request);
                System.out.println("Poslata poruka serveru: " + line);
                buff = new byte[UDPServer.MAX_MESSAGE_SIZE_BYTES];
                DatagramPacket response = new DatagramPacket(buff, buff.length);
                datagramSocket.receive(response);


                byte[] receivedData = response.getData();

                ByteArrayInputStream bais = new ByteArrayInputStream(receivedData);

                DataInputStream dis = new DataInputStream(bais);
                final int length = dis.readInt();

                String message = new String(receivedData, 4, length, StandardCharsets.UTF_8);

                System.out.println("Primeljena poruka od servera: " + message);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

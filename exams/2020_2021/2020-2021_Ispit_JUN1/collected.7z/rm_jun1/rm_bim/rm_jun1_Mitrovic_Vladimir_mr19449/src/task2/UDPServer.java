package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class UDPServer {

    public static final int PORT = 23456;
    public static final int MAX_MESSAGE_SIZE_BYTES = 512;

    private static final String morsePath = "morse.txt";
    private static final Map<String, String> morse = new HashMap<>();

    private static final Pattern pattern = Pattern.compile("[.,?!]");

    public static void main(String[] args) {

        System.out.println("Hello from UDPServer");


        try (DatagramSocket datagramSocket = new DatagramSocket(PORT)) {

            // read morse code
            Files.lines(Paths.get(morsePath)).forEach(
                    line -> {
                        String[] tokens = line.split(" ");
                        if (tokens.length != 2) {
                            System.err.println("Invalid morse code entry: " + line);
                        } else {
                            morse.put(tokens[0], tokens[1]);
                        }
                    }
            );

            // handle whitespace
            morse.put(" ", " ");

            while (true) {
                byte[] buff = new byte[MAX_MESSAGE_SIZE_BYTES];

                DatagramPacket packet = new DatagramPacket(buff, buff.length);
                datagramSocket.receive(packet);

                byte[] receivedData = packet.getData();
                ByteArrayInputStream bais = new ByteArrayInputStream(receivedData);

                DataInputStream dis = new DataInputStream(bais);
                final int length = dis.readInt();

                String message = new String(receivedData, 4, length, StandardCharsets.UTF_8);

                System.out.println("Primljena poruka: " + message);

                final String encodedMessage = morseEncode(message);
                final byte[] encodedMessageBuff = encodedMessage.getBytes(StandardCharsets.UTF_8); // nije moralo jer je morzeova azbuka ASCII ali ne smeta

                System.out.println("Enkodovana poruka: " + encodedMessage);

                ByteArrayOutputStream baos = new ByteArrayOutputStream(4 + encodedMessageBuff.length);
                DataOutputStream dos = new DataOutputStream(baos);

                // custom protocol - send length of the byte as int and then actual bytes
                dos.writeInt(encodedMessageBuff.length);
                dos.write(encodedMessageBuff);

                byte[] responseBuff = baos.toByteArray();

                DatagramPacket responsePacket =
                        new DatagramPacket(
                                responseBuff,
                                responseBuff.length,
                                packet.getAddress(),
                                packet.getPort());

                datagramSocket.send(responsePacket);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String morseEncode(final String message) {

        final StringBuilder sb = new StringBuilder();

        message.codePoints().forEach(
                c ->
                {

                    sb.append(morse.get(Character.toString(c)))
                            .append(" "); // add pause (1 whitespace after each character)

                    // was it end of the word?
                    if (Character.isWhitespace(c) || isSpecialCharacter(c)) {
                        sb.append("   "); // append 3 whitespaces if end of the word
                    }
                }
        );

        sb.append(".-.-.-"); // end of message indicator

        return sb.toString();
    }

    private static boolean isSpecialCharacter(int codePoint) {

        return pattern.matcher(Character.toString(codePoint)).matches();
    }

}

package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

// package-private
class Karta {

    enum Znak {
        Pik,
        Herc,
        Tref,
        Karo;
    }

    Karta(final byte vrednost, final Znak znak) {

        if (vrednost < 2 || vrednost > 14) {
            throw new IllegalArgumentException("Vrednosti mogu biti samo izmedju 2 i 14 ukljucno");
        }

        this.vrednost = vrednost;
        this.znak = znak;
    }

    private byte vrednost;
    private Znak znak;

    public byte getVrednost() {
        return vrednost;
    }

    public Znak getZnak() {
        return znak;
    }

    @Override
    public String toString() {
        return String.format("%d.%s", vrednost, znak.toString());
    }


}

public class NBIOServer {

    public static final int PORT = 12345;

    private static List<Karta> spil = generisiSpil();

    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");

        System.out.println("Generisani spil:");

        for (final Karta karta : spil) {
            System.out.println(karta.toString());
        }

        SocketAddress address = new InetSocketAddress(InetAddress.getLoopbackAddress(), PORT);

        try (
                ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
                Selector selector = Selector.open()
        ) {

            serverSocketChannel.bind(address);
            serverSocketChannel.configureBlocking(false);

            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();

                final Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> selectionKeyIterator = selectedKeys.iterator();

                while (selectionKeyIterator.hasNext()) {

                    SelectionKey key = selectionKeyIterator.next();
                    selectionKeyIterator.remove();

                    if (key.isAcceptable()) {

                        ServerSocketChannel server = (ServerSocketChannel) key.channel();

                        SocketChannel client = server.accept();

                        client.configureBlocking(false);

                        client.register(selector, SelectionKey.OP_READ | SelectionKey.OP_WRITE);

                    } else if (key.isReadable()) {

                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = ByteBuffer.allocate(1);
                        client.read(buffer);

                        buffer.flip();

                        byte numCardsToDraw = buffer.get();

                        if (numCardsToDraw > 0 && numCardsToDraw <= spil.size()) {

                            // encode cards as sequence of bytes
                            // use 2 bytes per card (yes, this could be optimized to use just 1 byte per card
                            // but I don't have time for that)

                            buffer = ByteBuffer.allocate(numCardsToDraw * 2);

                            Iterator<Karta> iterator = spil.iterator();

                            while (numCardsToDraw > 0 && iterator.hasNext()) {

                                Karta card = iterator.next();
                                iterator.remove();
                                buffer.put(card.getVrednost());
                                buffer.put((byte) card.getZnak().ordinal());
                                --numCardsToDraw;
                            }

                        } else {
                            // prepare error message
                            // my custom protocol is to send buffer of size 1 byte to indicate out of bounds error
                            // we already have such a buffer
                            // but we can do it again just in case something gets refactored above
                            buffer = ByteBuffer.allocate(1);
                            buffer.put((byte) 0xff); // this is the error code
                        }

                        buffer.flip();
                        key.attach(buffer);
                    } else if (key.isWritable()) {

                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        if (buffer != null) {

                            SocketChannel client = (SocketChannel) key.channel();

                            if (buffer.hasRemaining()) {

                                client.write(buffer);
                            } else {
                                client.close();
                                System.out.println("Closing connection");
                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<Karta> generisiSpil() {

        final List<Karta> cards = new LinkedList<>();

        for (Karta.Znak znak : Karta.Znak.values()) {
            for (byte vrednost = 2; vrednost <= 14; ++vrednost) {

                cards.add(new Karta(vrednost, znak));
            }
        }

        Collections.shuffle(cards);

        return cards;
    }
}

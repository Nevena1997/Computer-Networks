package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");

        SocketAddress address = new InetSocketAddress(InetAddress.getLoopbackAddress(), NBIOServer.PORT);
        try (
                Scanner scanner = new Scanner(System.in);
       ) {

            while (scanner.hasNext()) {
                final byte numCards = scanner.nextByte();

                // no validation, just send it to the server

                ByteBuffer buffer = ByteBuffer.allocate(1);
                buffer.put(numCards);
                buffer.flip();

                try (SocketChannel socketChannel = SocketChannel.open(address)) {
                    socketChannel.write(buffer);

                    buffer = ByteBuffer.allocate(numCards * 2);

                    int bytesRead;

                    while ((bytesRead = socketChannel.read(buffer)) != -1) {

                        buffer.flip();

                        while (buffer.hasRemaining()) {

                            byte x = buffer.get();

                            if (x == (byte) 0xff) {
                                System.out.println("out of bounds error received from the server");
                                break;
                            }

                            // we know x is not an error code, it must be card value, so go on and fetch card sign if available
                            if (buffer.hasRemaining()) {

                                System.out.println(new Karta(x, Karta.Znak.valueOf(znak(buffer.get()))));
                            }
                        }

                        buffer.clear();
                        buffer.flip();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    private static String znak(byte b) {

        switch (b) {
            case 0:
                return "Pik";
            case 1:
                return "Herc";
            case 2:
                return "Tref";
            case 3:
                return "Karo";
            default:
                return "Nepoznat znak";
        }
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class UDPServer {

    public static int PORT = 23456;

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");

        try(DatagramSocket socket = new DatagramSocket(PORT)){

            Path p = Paths.get("/home/ispit/Desktop/rm_jun_Velickovic_Anja_mr16027/morse.txt");

            String s_fajl = Files.readString(p);

            while(true){
                DatagramPacket receive = new DatagramPacket(new byte[1024], 0, 1024);
                socket.receive(receive);

                String podaci = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
                //System.out.println(podaci);

                StringBuilder kodirana_poruka = new StringBuilder("");

                for (int i = 0; i < podaci.length(); i++) {
                    //System.out.println(podaci.charAt(i));
                    int index = s_fajl.indexOf(podaci.toLowerCase().charAt(i));
                    String kod = s_fajl.substring(index + 2, s_fajl.indexOf('\n', index));
                    //System.out.println(kod);
                    kodirana_poruka.append(kod);
                    kodirana_poruka.append(" ");
                }

                kodirana_poruka.append(".-.-.-");

                String poruka = kodirana_poruka.toString();

                DatagramPacket send = new DatagramPacket(new byte[poruka.length()], 0, poruka.length(),
                        receive.getAddress(), receive.getPort());
                send.setData(poruka.getBytes(StandardCharsets.UTF_8));
                socket.send(send);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

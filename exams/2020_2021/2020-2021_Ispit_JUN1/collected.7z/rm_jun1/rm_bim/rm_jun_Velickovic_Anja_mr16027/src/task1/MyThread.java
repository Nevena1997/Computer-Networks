package task1;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;

public class MyThread extends Thread {

    Path p;

    public MyThread(Path path) {
        this.p = path;
    }

    @Override
    public void run() {

        try {
            String[] lines = Files.readAllLines(p).toArray(new String[0]);

            for (String line : lines) {
                try {
                    URL url = new URL(line);

                    String a = url.getAuthority();

                    if (a.contains(".")) {
                        try {
                            // ako ne uspe parsiranje do prve tacke onda nije v4
                            int br = Integer.parseInt(a.substring(0, a.indexOf(".")));

                            synchronized (System.out) {
                                System.out.print("(v4) " + url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                                System.out.print(" [" + a.substring(0, a.indexOf(":")).replace(":", " ") + "]");
                                System.out.println();
                            }
                        } catch (NumberFormatException e) {
                            synchronized (System.out) {
                                System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                            }
                        }
                    } else {
                        // ako ne sadrzi . onda je v6
                        System.out.println("(v6) " + url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());
                    }
                } catch (MalformedURLException e) {
                    continue;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

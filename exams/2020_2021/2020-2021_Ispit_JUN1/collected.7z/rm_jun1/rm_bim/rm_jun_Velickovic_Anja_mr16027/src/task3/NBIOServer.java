package task3;


import javafx.util.Pair;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.IntStream;

public class NBIOServer {

    public static int PORT = 12345;

    public static Map<Integer, Pair<Integer, String>> karte = new HashMap<>(52);

    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Neuspeh");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress("localhost", PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            kreiraj_spil(karte);
            
            int []karte_izmesane;

            Random r = new Random();
            IntStream stream = r.ints(52,1,52);
            List<Integer> random_niz = new ArrayList<>(52);

            for(int el : stream.toArray()){
                random_niz.add(el);
            }

            while(true){
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while(iterator.hasNext()){
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    if(key.isAcceptable()){
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();

                        client.configureBlocking(false);
                        SelectionKey keyClient = client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buffer = ByteBuffer.allocate(1024);
                        keyClient.attach(buffer);
                    } else if(key.isReadable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.read(buffer);
                        buffer.flip();

                        String s = new String(buffer.array(), 0, buffer.limit(), StandardCharsets.UTF_8);
                        //System.out.println(s);

                        StringBuilder za_slanje = new StringBuilder("");
                        for (int i = 0; i < Integer.parseInt(s); i++) {
                            Pair<Integer, String> par = karte.get(random_niz.get(i));
                            //random_niz.remove(i);
                            za_slanje.append(String.valueOf(par.getKey()));
                            za_slanje.append(".");
                            za_slanje.append(par.getValue());
                            za_slanje.append(" ");
                        }

                        za_slanje.append("$");

                        buffer.clear();
                        //System.out.println(za_slanje.toString());
                        buffer.put(za_slanje.toString().getBytes(StandardCharsets.UTF_8));
                        buffer.flip();

                        key.interestOps(SelectionKey.OP_WRITE);
                    } else if(key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.write(buffer);

                    }

                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void kreiraj_spil(Map<Integer, Pair<Integer, String>> karte) {
        String []znak = {"pik", "karo", "herc", "tref"};


        int i = 1;
            for (int j = 0; j < 4; j++) {
                for (int k = 2; k <= 14; k++) {
                    karte.put(i, new Pair<>(k, znak[j]));
                    i++;
                }
            }

    }


}

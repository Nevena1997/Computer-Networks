package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");


        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", NBIOServer.PORT));
             Scanner sc = new Scanner(System.in)) {

            String br;
            while (true) {
                br = sc.nextLine();

                ByteBuffer buffer = ByteBuffer.allocate(4);
                buffer.put(br.getBytes(StandardCharsets.UTF_8));

                buffer.flip();
                client.write(buffer);

                ByteBuffer buffer2 = ByteBuffer.allocate(1024);

                client.read(buffer2);

                String s = new String(buffer2.array(), 0, buffer2.position(), StandardCharsets.UTF_8);
                if (s.contains("$")) {
                    System.out.println(s.substring(0, s.length() - 1));
                    break;
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");

        try(DatagramSocket socket = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){

            String linija;
            while(true){
                linija = sc.nextLine();

                DatagramPacket send;
                send = new DatagramPacket(new byte[linija.length()], 0, linija.length(),
                        InetAddress.getByName("localhost"), UDPServer.PORT);

                send.setData(linija.getBytes(StandardCharsets.UTF_8));
                socket.send(send);

                DatagramPacket receive = new DatagramPacket(new byte[1024], 0, 1024);
                socket.receive(receive);

                String poruka = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
                System.out.println(poruka);
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) throws IOException {
        System.out.println("Hello from Task1Main");

        Path p = Paths.get("/home/ispit/Desktop/tests/urls");
        for (Path k : Files.newDirectoryStream(p)) {
            new FileThread(k).start();
        }


    }
}

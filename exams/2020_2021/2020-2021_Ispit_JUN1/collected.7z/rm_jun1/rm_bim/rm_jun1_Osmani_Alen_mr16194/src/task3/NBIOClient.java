package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", 12345));
             Scanner sc = new Scanner(System.in)
        ) {

            while (true){
                int broj = sc.nextInt();
                ByteBuffer buffer = ByteBuffer.allocate(4);

                buffer.putInt(broj);

                buffer.flip();

                client.write(buffer);

                buffer.clear();

                ByteBuffer recieve = ByteBuffer.allocate(1024);
                client.read(recieve);
                recieve.flip();
                ArrayList<Character> lista = new ArrayList<>();
                while (recieve.hasRemaining()){
                    char c = (char) recieve.get();
                    lista.add(c);
                }
                int indikator = 0;
                for (Character c : lista){
                    if(indikator == 1){
                        if(Character.isDigit(c)){
                            System.out.println();
                            //System.out.println(c);
                            indikator = 0;
                        }else
                            System.out.print(c);
                    }
                    if(c == '.'){
                        indikator =1;
                        System.out.print(c);
                    }
                    if(indikator==0)
                        System.out.print(c);
                }
                System.out.println();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)
        ) {
            while (true) {
                String linija = sc.nextLine();
                if (linija.equals("kraj")) {
                    break;
                }
                byte [] buf = linija.getBytes();
                DatagramPacket req = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), 23456);

                client.send(req);

                byte [] buff2 = new byte[1024];
                DatagramPacket res = new DatagramPacket(buff2 , buff2.length);
                client.receive(res);
                String resenje = new String(res.getData(), 0, res.getLength());
                System.out.println(resenje);
            }
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

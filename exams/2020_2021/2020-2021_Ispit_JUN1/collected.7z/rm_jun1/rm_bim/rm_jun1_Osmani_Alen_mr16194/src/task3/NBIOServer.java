package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class NBIOServer {


    public static void main(String[] args) {
        String [] boje = {"tref" , "herc" , "pik", "karo"};
        Map<Integer,String> map = new HashMap<>();
        System.out.println("Hello from NBIOServer");
        int p=1 ;
        for(int k = 2; k<=14; k++)
            for (int j = 0; j < boje.length; j++) {
                String karta = k + "." + boje[j];
                map.put(p, karta);
                p++;
            }
        boolean indikator = false;
        //System.out.println(map.get(1));
        int broj_karata = 52;
        int broj_karata_koje_zeli_klijent = 0;
        try (ServerSocketChannel channel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {

            if (!channel.isOpen() || !selector.isOpen()) {
                System.out.println("ERROR");
                System.exit(1);
            }

            channel.bind(new InetSocketAddress(12345));
            channel.configureBlocking(false);
            channel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try {
                        if (key.isAcceptable()) {
                            System.out.println("Prihvacen klijent");
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();

                            SocketChannel client = server.accept();


                            ByteBuffer buffer = ByteBuffer.allocate(4);

                            client.configureBlocking(false);
                            SelectionKey register = client.register(selector, SelectionKey.OP_READ);


                            register.attach(buffer);

                        }
                        if (key.isReadable()) {
                            //System.out.println("CITA klijent");

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);
                            buffer.flip();

                            int br = buffer.getInt();
                            broj_karata_koje_zeli_klijent = br;
                            if(broj_karata < broj_karata_koje_zeli_klijent) {
                                //key.cancel();
                                //key.channel().close();
                                //String nema = "Nema toliko karata, preostalo je: " + broj_karata + " ... server se gasi.";
                                //System.out.println(nema);
                                indikator = true;
                                //key.interestOps(SelectionKey.OP_READ);
                                //System.exit(1);
                            } else indikator = false;
                            //System.out.println(" BROJ JE: " + br);
                            //broj_karata = broj_karata - broj_karata_koje_zeli_klijent;

                            buffer.clear();
                            //System.out.println("Uspeo");
                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                        if (key.isWritable()) {
                            ArrayList<String> slucajni = new ArrayList<>();
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = ByteBuffer.allocate(1024);

                            if(indikator){
                                String nema = "Nema toliko karata, preostalo je: " + broj_karata ;
                                buffer.put(nema.getBytes());
                                buffer.flip();
                                client.write(buffer);
                                buffer.clear();
                                key.interestOps(SelectionKey.OP_READ);
                            }
                            else {
                                for (int i = 0; i < broj_karata_koje_zeli_klijent; i++) {
                                    Random random = new Random();
                                    int rand_karta = random.nextInt(broj_karata) + 1;
                                    slucajni.add(map.get(rand_karta));
                                    //map.remove(map.get(rand_karta));
                                    String poslednja = map.get(broj_karata);
                                    map.replace(rand_karta, poslednja);
                                    broj_karata--;
                                }

                                for (String karta : slucajni) {
                                    buffer.put(karta.getBytes());
                                }
                                buffer.flip();
                                client.write(buffer);
                                buffer.clear();
                                key.interestOps(SelectionKey.OP_READ);
                            }
                        }
                    } catch (IOException e) {
                        key.cancel();
                        e.printStackTrace();
                    } catch (BufferUnderflowException e) {
                        key.cancel();
                    }


                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

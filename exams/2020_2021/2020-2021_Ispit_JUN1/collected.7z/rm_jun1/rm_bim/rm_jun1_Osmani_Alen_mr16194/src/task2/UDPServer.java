package task2;

import com.sun.source.tree.WhileLoopTree;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class UDPServer {

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer");
        Path fajl = Paths.get("/home/ispit/Desktop/rm_jun1_Osmani_Alen_mr16194/morse.txt");

        try (DatagramSocket server = new DatagramSocket(23456);
        ) {

            while (true) {
                byte [] buf = new byte[1024];
                DatagramPacket rec = new DatagramPacket(buf , buf.length);
                server.receive(rec);
                //String recenica1 = new String(rec.getData(), 0 , rec.getLength());
                //System.out.println("PODATAK: " + recenica1);
                byte [] recenica = rec.getData();
                int kraj = rec.getLength();
                //System.out.println("KRAJ" + kraj);
                ArrayList<String> lista = new ArrayList<>();
                for(byte b : recenica){
                    if (kraj == 0) {
                        break;
                    }
                    char s = (char) b;
                    Scanner sc = new Scanner(fajl);
                    String linija_u_fajlu = sc.nextLine();
                    char razmak = ' ';
                   if(razmak == (s)){
                       //System.out.println("DESIO SE");
                       lista.add("   ");
                   }else
                        while (sc.hasNextLine()){
                            String[] niz = linija_u_fajlu.split(" ");
                            if ( niz[0].equalsIgnoreCase(String.valueOf(s))) {
                                lista.add(niz[1]);
                                lista.add(" ");
                                break;
                            }
                            linija_u_fajlu = sc.nextLine();
                        }
                    //System.out.println(s);
                    sc.close();
                    kraj--;
                }
                //System.out.println("**************");

                String linija_resenje = "";
                for (String s : lista) {
                    linija_resenje += s;
                }
                linija_resenje += "  .-.-.-";
                //System.out.println(linija_resenje);
                byte[] buff2 = linija_resenje.getBytes();
                DatagramPacket req = new DatagramPacket(buff2, buff2.length, rec.getAddress(), rec.getPort());
                server.send(req);

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task1;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;

public class FileThread extends Thread{
    Path k ;
    public FileThread(Path k) {
        this.k = k;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(this.k)) {
            while (sc.hasNextLine()) {
                //System.out.println(sc.nextLine());

                    try {
                        String line = sc.nextLine();
                        URL url = new URL(line);
                        //System.out.println(line + "            " + this.k);
                        System.out.println(url.getProtocol()+ " " + url.getAuthority() +" "+ this.k.toString());

                    }catch (MalformedURLException e){
                        return;
                    }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

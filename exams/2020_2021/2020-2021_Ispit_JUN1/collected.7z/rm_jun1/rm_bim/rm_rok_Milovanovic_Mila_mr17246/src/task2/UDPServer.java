package task2;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static void main(String[] args) {
        try(DatagramSocket socket=new DatagramSocket(23456)) {

            while (true) {

                DatagramPacket prima = new DatagramPacket(new byte[2048], 2048);
                socket.receive(prima);

                String primaString = new String(prima.getData(), 0, prima.getLength(), StandardCharsets.UTF_8);
                StringBuilder sb = new StringBuilder();

                File file = new File("/home/ispit/Desktop/rm_rok_Milovanovic_Mila_mr17246/morse.txt");
                Scanner scMoreuz = new Scanner(file);
                HashMap<String, String> mapa = new HashMap<>();
                while (scMoreuz.hasNext()) {
                    String ulazLinija = scMoreuz.nextLine();
                    String parsirano[] = ulazLinija.split(" ");
                    //System.out.println(parsirano[0] + " "+ parsirano[1]);
                    mapa.put(parsirano[0], parsirano[1]);


                }
                int duzinaStringa = primaString.length();
                int brojac = 0;
                while (brojac < duzinaStringa) {
                    String slovo = String.valueOf(primaString.charAt(brojac));
                    if(slovo.equalsIgnoreCase(" ")){
                        sb.append("   ");
                        brojac++;
                        continue;
                    }
                    String oznaka = mapa.get(slovo.toLowerCase());
                    sb.append(oznaka);
                    sb.append(" ");
                    brojac++;

                }

                sb.append(".-.-.-");
                String gotovo = sb.toString();
                byte gotovoBy[] = gotovo.getBytes();
                DatagramPacket salje = new DatagramPacket(gotovoBy, gotovoBy.length, prima.getAddress(), prima.getPort());
                socket.send(salje);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Hello from UDPServer");
    }

}

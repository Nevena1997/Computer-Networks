package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Obradi implements Runnable {
    private  Path p;
    private Lock lock;

    public Obradi(Path p) {
        this.p=p;
        this.lock=new ReentrantLock();
    }

    @Override
    public void run() {
        try {
            Scanner sc=new Scanner(p);
            String linija;
            StringBuilder sb=new StringBuilder();
            lock.lock();
            while (sc.hasNext()) {
                linija = sc.nextLine();

                if (!linija.contains(":")  || linija.contains("mreze") || linija.contains("ispit") ||
                        linija.contains("::"))
                    continue;
                URL url = new URL(linija);
                URLConnection uc = url.openConnection();

                String ispis = url.getProtocol() + " " + url.getAuthority() + " " + url.getPath();
                sb.append(ispis);
                sb.append("\n");

                if (!(url.getAuthority()).contains(":")) {
                    InetAddress addr = InetAddress.getByName(url.getAuthority());
                    if (addr.getAddress().length == 4) {
                        sb.append("(vr4) ");
                        sb.append(url.getProtocol());
                        sb.append(" ");
                        sb.append(url.getPath());
                        sb.append(" ");
                        sb.append("[");

                        sb.append(addr.getHostAddress());
                        String adresa=addr.getHostAddress();

                        /*int brojac=0;
                        while (brojac<adresa.length()){

                            sb.append(adresa.charAt(brojac));
                            brojac++;
                            if(brojac==3 || brojac==7|| brojac==11){
                                sb.append(" ");
                                brojac++;
                                continue;
                            }

                        }*/

                        sb.append("]");
                        sb.append("\n");

                    } else {
                        sb.append("(vr6) ");
                        sb.append("(vr4) ");
                        sb.append(url.getProtocol());
                        sb.append(" ");
                        sb.append(url.getPath());
                        sb.append(" ");

                        sb.append("\n");
                    }


                }
                }


            System.out.println(sb.toString());
            lock.unlock();

        } catch (UnknownHostException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

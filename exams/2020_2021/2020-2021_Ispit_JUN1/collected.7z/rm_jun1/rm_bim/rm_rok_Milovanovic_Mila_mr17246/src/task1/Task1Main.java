package task1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {
        String putanja="/home/ispit/Desktop/tests/urls";
        try (DirectoryStream<Path> ds= Files.newDirectoryStream(Paths.get(putanja))) {
            for (Path p:ds){
                if(Files.isRegularFile(p))
                    new Thread(new Obradi(p)).start();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }




    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        try (DatagramSocket socket=new DatagramSocket()){


            Scanner sc=new Scanner(System.in);
            String linija=sc.nextLine();
            InetAddress host=InetAddress.getByName("localhost");

            byte linijaBy[]=linija.getBytes();
            DatagramPacket salje=new DatagramPacket(linijaBy, linijaBy.length,host, 23456 );
            socket.send(salje);

            DatagramPacket prima=new DatagramPacket(new byte[2048], 2048);
            socket.receive(prima);
            //System.out.println("Odgovor racunara:");
            String odgovor=new String(prima.getData(), 0, prima.getLength(), StandardCharsets.UTF_8);
            System.out.println(odgovor);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }

}

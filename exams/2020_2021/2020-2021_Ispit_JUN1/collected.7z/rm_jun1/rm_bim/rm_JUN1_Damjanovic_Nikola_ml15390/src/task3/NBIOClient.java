package task3;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
    }

}

package task2;

import javax.xml.crypto.Data;
import javax.xml.stream.events.EndDocument;
import java.io.*;
import java.net.*;
import java.nio.channels.DatagramChannel;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static int PORT=23456;
    public static Map<Character, String> morz=new HashMap<>();

    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(PORT)){
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("morse.txt")));
            while(true){

                UDPServer.morz.put(' ',"  ");
                String sc=br.readLine();

                UDPServer.morz.put(sc.charAt(0),sc.substring(2));
                if(sc.charAt(0)=='!'){
                    break;
                }
            }
            while (true) {
                DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
                server.receive(request);
                String s = new String(request.getData(), 0, request.getLength()).toLowerCase();

                StringBuilder sb= new StringBuilder();
                for(int i=0;i<s.length();i++){
                    sb.append(morz.get(s.charAt(i)));
                    sb.append(" ");
                }
                sb.append("   .-.-.-");
                DatagramPacket response = new DatagramPacket(sb.toString().getBytes(),sb.toString().getBytes().length, request.getAddress(),request.getPort());

                server.send(response);
            }

        } catch (SocketException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void ucitaj_mapu() throws IOException {

    }

}

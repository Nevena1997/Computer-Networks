package task3;

public class NBIOServer {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");
    }

}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("Hello from UDPClient");
        try (DatagramSocket client = new DatagramSocket()){

            InetAddress address=InetAddress.getByName("localhost");
            client.connect(address,UDPServer.PORT);
            while(true) {
                System.out.println("Klijent:");
                Scanner sc = new Scanner(System.in);
                String c = sc.nextLine();

                DatagramPacket request = new DatagramPacket(c.getBytes(), c.getBytes().length, address, UDPServer.PORT);
                client.send(request);

                DatagramPacket response = new DatagramPacket(new byte[1024], 1024);
                client.receive(response);
                String s = new String(response.getData(), 0, response.getLength());

                System.out.println("Server:\n"+s);
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

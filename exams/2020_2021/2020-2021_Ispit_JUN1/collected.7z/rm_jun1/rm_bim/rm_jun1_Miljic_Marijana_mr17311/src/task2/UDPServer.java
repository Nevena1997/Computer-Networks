package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static int Por = 23456;

    public static void main(String[] args) {
        System.out.println("Hello from UDPServer\n");
        try (DatagramSocket server = new DatagramSocket(Por)) {

            while (true) {
                byte[] bit = new byte[UDPClient.MAX_LINE];
                DatagramPacket receivebytes = new DatagramPacket(bit, bit.length);
                server.receive(receivebytes);
                String s = new String(receivebytes.getData(), 0, receivebytes.getLength());
                StringBuilder sb = new StringBuilder("");

                String[] niske = s.split(" ");
                for (String ss : niske) {

                    char[] car = ss.toCharArray();
                    for (char c : car) {
                        String op;
                        if(Character.isUpperCase(c)) {
                            c=Character.toLowerCase(c);

                        }
                        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_jun1_Miljic_Marijana_mr17311/morse.txt")))) {
                            while ((op = in.readLine()) != null) {
                                if (op.contains(String.valueOf(c))) {
                                    sb.append(op.substring(2));
                                }
                            }
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        sb.append(" ");
                    }
                    sb.append("   ");
                }
                    sb.append(".-.-.-");


                String novo=sb.toString();
                byte[] bitt=novo.getBytes();
                DatagramPacket slanje=new DatagramPacket(bitt,bitt.length,receivebytes.getAddress(),receivebytes.getPort());
                server.send(slanje);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
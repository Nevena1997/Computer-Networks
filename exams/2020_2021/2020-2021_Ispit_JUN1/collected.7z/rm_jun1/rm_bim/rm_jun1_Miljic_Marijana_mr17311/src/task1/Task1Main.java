package task1;

import java.awt.event.MouseAdapter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Task1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Task1Main");
        try (DirectoryStream<Path> path = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/tests/urls"))) {
            for(Path p: path) {
               new Fja(p).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

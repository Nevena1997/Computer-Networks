package task1;

import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.spi.AbstractResourceBundleProvider;

public class Fja extends Thread{
    private Path p;
    public Fja(Path p) {
        this.p=p;
    }

    @Override
    public void run()  {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())))) {
            String line;
            URL u;
            int broj;
            while ((line = in.readLine()) != null) {
                broj = 0;
                int i=0;
                try {


                    u = new URL(line);
                   String hostt=u.getHost();

                   if(hostt.contains(":") && hostt.chars().allMatch(c->(Character.isDigit(c)) || (c >= 'a' && c <= 'f'))) {
                       broj=6;
                       i=1;
                   }else if(!hostt.chars().anyMatch(c->!(Character.isDigit(c)) && c != '.') ) {
                       broj=4;
                       i=1;
                   }

                } catch (MalformedURLException  ee) {
                    continue;
                }

                synchronized (System.out) {
                    if(broj!=0) {
                        System.out.printf("(v"+broj+") ");
                    }
                     System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + p.toAbsolutePath());
                    if(i==1) {
                        System.out.println("["+u.getHost().replace("."," ")+"]");
                    }

                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

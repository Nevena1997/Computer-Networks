package task2;

import javax.swing.*;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static int MAX_LINE=1024;
    public static void main(String[] args) {

        System.out.println("Hello from UDPClient\n");
        try (DatagramSocket klijent = new DatagramSocket(); Scanner sc=new Scanner(System.in)) {
            String line=sc.nextLine();
            byte[] bit=line.getBytes();
            DatagramPacket sendBytes=new DatagramPacket(bit,bit.length,InetAddress.getByName("localhost"),UDPServer.Por);
            klijent.send(sendBytes);
            byte[] pristiglo=new byte[MAX_LINE];
            DatagramPacket receivebytes=new DatagramPacket(pristiglo,pristiglo.length);
            klijent.receive(receivebytes);
            String s=new String(receivebytes.getData(),0,receivebytes.getLength());
            System.out.println(s);
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import javax.print.DocFlavor;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;

public class NBIOServer {
    public static int Porr=12346;

    public static void main(String[] args) {
        System.out.println("Hello from NBIOServer");



            Map<Integer,List<String>> map=new HashMap<>();
            List<String> lista=new ArrayList<>();
            lista.add("tref");
            lista.add("pik");
            lista.add("karo");
            lista.add("herc");
            map.put(2,lista);
            map.put(3,lista);
            map.put(4,lista);
            map.put(5,lista);
            map.put(6,lista);
            map.put(7,lista);
            map.put(8,lista);
            map.put(9,lista);
            map.put(10,lista);
            map.put(11,lista);
            map.put(12,lista);
            map.put(13,lista);
            map.put(14,lista);
            Iterator<Integer> itt=map.keySet().iterator();
            while(itt.hasNext()) {
               int bro=itt.next();
               List<String> niz=map.get(bro);
               for(String ni:niz) {
                   System.out.println(bro+"."+ni);
               }
            }
        try (ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open()) {
            if (!selector.isOpen() || !server.isOpen()) {
                System.out.println("Greska!");
                System.exit(1);
            }
            server.bind(new InetSocketAddress(Porr));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()) {
                                  ServerSocketChannel serverr= (ServerSocketChannel) key.channel();
                                  SocketChannel klijent=serverr.accept();
                                  klijent.configureBlocking(false);
                                 SelectionKey keyy= klijent.register(selector,SelectionKey.OP_READ);
                                  ByteBuffer buffer=ByteBuffer.allocate(4);
                                  keyy.attach(buffer);
                    } else if (key.isReadable()) {
                                        int broj=0;
                                        int ra=0;
                                        int i=0;
                                        SocketChannel klijent= (SocketChannel) key.channel();
                                        ByteBuffer buffer= (ByteBuffer) key.attachment();
                                        klijent.read(buffer);
                                        if(!buffer.hasRemaining())  {
                                            buffer.flip();
                                            int brojkarata=buffer.getInt();

                                            Random rand=new Random();
                                            while(i<brojkarata) {
                                                ra = rand.nextInt(12);
                                                i++;

                                                System.out.println(ra);
                                            }

                                            if(brojkarata<1 || proveri(map)<brojkarata) {
                                                broj=-1;
                                            }

                                        }

                                        buffer.clear();
                                        buffer.putInt(ra);
                                        buffer.flip();
                                        key.interestOps(SelectionKey.OP_WRITE);
                    } else if (key.isWritable()) {
                        SocketChannel klijent= (SocketChannel) key.channel();
                        ByteBuffer buffer= (ByteBuffer) key.attachment();
                        klijent.write(buffer);
                        if(!buffer.hasRemaining()) {
                            klijent.close();
                        }
                    }
                }
            }

        } catch (ClosedChannelException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private static int proveri(Map<Integer, List<String>> map) {
        Iterator<Integer> ittt=map.keySet().iterator();
        int broj=0;
        while(ittt.hasNext()) {
            int br=ittt.next();
            List<String> list=map.get(br);
            for(String li:list) {
                broj+=1;
            }

        }
        return broj;
    }


}

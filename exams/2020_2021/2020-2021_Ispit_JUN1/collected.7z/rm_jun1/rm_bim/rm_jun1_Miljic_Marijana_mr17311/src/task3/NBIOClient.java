package task3;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NBIOClient {

    public static void main(String[] args) {
        System.out.println("Hello from NBIOClient");
        try (SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost",NBIOServer.Porr)); Scanner sc=new Scanner(System.in)) {
            ByteBuffer buffer=ByteBuffer.allocate(4);
            int broj=sc.nextInt();

            buffer.putInt(broj);
            buffer.flip();
            klijent.write(buffer);
            buffer.clear();
            klijent.read(buffer);
            buffer.flip();
            int brojj=buffer.getInt();
            System.out.println(brojj);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

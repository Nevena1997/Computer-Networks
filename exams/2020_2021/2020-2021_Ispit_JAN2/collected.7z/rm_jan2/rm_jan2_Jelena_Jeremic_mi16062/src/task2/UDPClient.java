package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket socket = new DatagramSocket())
        {
            InetAddress add = InetAddress.getLocalHost();
            byte[] bufS;
            byte[] bufP = new byte[4096];
            Scanner sc = new Scanner(System.in);
            String salji = sc.nextLine();
            bufS = salji.getBytes();

            DatagramPacket request = new DatagramPacket(bufS, bufS.length, add, UDPServer.PORT);
            socket.send(request);

            DatagramPacket response = new DatagramPacket(bufP, bufP.length);
            socket.receive(response);
            String primljeno = new String(response.getData(), 0, response.getLength());

            System.err.println(primljeno);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}

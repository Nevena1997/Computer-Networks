package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

class UDPServer {
    protected final static int PORT = 12345;

    public static void main(String[] args) {
        try(DatagramSocket server = new DatagramSocket(PORT))
        {
            byte[] bufS;
            byte[] bufP = new byte[4096];

            while (true) {
                StringBuffer sb = new StringBuffer();

                DatagramPacket request = new DatagramPacket(bufP, bufP.length);
                server.receive(request);

                String primljeno = new String(request.getData(), 0, request.getLength());
                //System.err.println(primljeno);
                String[] podaci = primljeno.split("");
                for (int i = 0; i < podaci.length; i++) {
                    if (podaci[i].matches("[a-z]")) {
                        sb.append(podaci[i].toUpperCase());
                        //System.err.print(podaci[i].toUpperCase());
                    } else if (podaci[i].matches("[A-Z]")) {
                        sb.append(podaci[i].toLowerCase() + podaci[i].toLowerCase());
                        //System.err.print(podaci[i].toLowerCase()+podaci[i].toLowerCase());
                    } else if (podaci[i].matches("[0-9]")) {
                        sb.append("..");
                        //System.err.print("..");
                    } else {
                        sb.append(podaci[i]);
                    }
                }

                bufS = (sb.toString()).getBytes();
                DatagramPacket response = new DatagramPacket(bufS, bufS.length, request.getAddress(), request.getPort());
                server.send(response);
            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

class NBIOServer {

    public final static int D_PORT = 12345;
    
    public static void main(String[] args) {
        try(ServerSocketChannel serverCh = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            serverCh.bind(new InetSocketAddress(D_PORT));
            serverCh.configureBlocking(false);
            serverCh.register(selector, SelectionKey.OP_ACCEPT);

            while (true)
            {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext())
                {
                    SelectionKey sk = it.next();
                    it.remove();
                    try {
                        if (sk.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) sk.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_READ);
                        } else if (sk.isReadable()) {
                            SocketChannel client = (SocketChannel) sk.channel();
                            ByteBuffer buf = (ByteBuffer) sk.attachment();

                            if (buf == null) {
                                buf = ByteBuffer.allocate(4096);
                                sk.attach(buf);
                            } else {
                                buf.clear();
                                buf.rewind();
                            }

                            client.read(buf);

                            String stiglo = new String(buf.array(), 0, buf.position());
                            //System.err.println(stiglo);
                            int pogInt = poklapanja(stiglo);

                            String pogS = pogInt + "";

                            buf.rewind();
                            buf.put(pogS.getBytes());
                            buf.put((byte) '\n');
                            buf.flip();

                            sk.interestOps(SelectionKey.OP_WRITE);
                        } else if (sk.isWritable()) {
                            SocketChannel client = (SocketChannel) sk.channel();
                            ByteBuffer buf = (ByteBuffer) sk.attachment();

                            client.write(buf);
                        }
                    }
                    catch (IOException ee)
                    {
                        sk.cancel();

                        try {
                            sk.channel().close();
                        }
                        catch (IOException eee)
                        {

                        }
                    }
                }
            }
        }
        catch (IOException e)
        {
            //e.printStackTrace();
        }
    }

    private static int poklapanja(String kombKl) throws NumberFormatException
    {
        Random R = new Random();
        int pogodaka = 0;

        ArrayList<Integer> brKl = new ArrayList<Integer>();
        ArrayList<Integer> moje = new ArrayList<Integer>();

        String[] podaci = kombKl.split(" ");
        for(String s : podaci)
        {
            brKl.add(Integer.parseInt(s.trim()));
        }

        for(int i = 0; i < 7; i++)
        {
            int r = R.nextInt(38) + 1;
            if(moje.contains(r))
            {
                i--;
            }
            else
            {
                moje.add(r);
                //System.err.println(r);
                if(r==brKl.get(i))
                {
                    pogodaka++;
                }
            }
        }

        return pogodaka;
    }

}

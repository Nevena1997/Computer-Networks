package task3;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

class NBIOClient {
    
    public static void main(String[] args) {

        ArrayList<Integer> moje = new ArrayList<Integer>();
        int greska = 0;

        Scanner sc = new Scanner(System.in);
        String brojevi = sc.nextLine();

        String[] podaci = brojevi.split(" ");
        if(podaci.length != 7)
        {
            System.err.println("Mora biti sedam brojeva!");
            greska = 1;
        }
        for(int i = 0; i < podaci.length; i++)
        {
            int broj = Integer.parseInt(podaci[i].trim());
            if(moje.contains(broj))
            {
                System.err.println("Brojevi se ne smeju ponavljati!");
                greska = 1;
                break;
            }
            moje.add(broj);
            if((broj < 1) || (broj > 39))
            {
                System.err.println("Samo brojevi [1, 39]!");
                greska = 1;
                break;
            }
        }

        if(greska == 0) {
            try (Socket s = new Socket("localhost", NBIOServer.D_PORT);
                 BufferedReader br = new BufferedReader(new InputStreamReader(new BufferedInputStream(s.getInputStream())));
                 OutputStreamWriter out = new OutputStreamWriter(s.getOutputStream());)
            {
                out.write(brojevi);
                out.flush();

                String primljeno = br.readLine();
                System.err.println("Pogodio: " + primljeno);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

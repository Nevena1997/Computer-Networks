package task1;

import javax.print.DocFlavor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class Task1Main {
    
    public static void main(String[] args) {

        Path p = Paths.get("/home/ispit/Desktop/tests");
        String verzija = "";
        String protokol = "";
        LocalDateTime ldt = LocalDateTime.now();
        LocalDateTime dobijeno;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/mm/yyyy hh:m:ss");

        try(DirectoryStream<Path> ds = Files.newDirectoryStream(p))
        {
            for(Path path : ds)
            {
                if(!Files.isDirectory(path))
                {
                    URL u = new URL("file://" + path.toString());
                    URLConnection conn = u.openConnection();

                    try(BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream())))
                    {
                        String line;
                        while ((line=br.readLine())!=null)
                        {
                            if(line.contains("https")) {
                                //System.err.println(line);
                                protokol = "https";
                                String[] podaci = line.split("]");
                                //System.err.println(podaci[0]);


                                if(podaci[1].contains("."))
                                {
                                    verzija = "v4";
                                }
                                else {
                                    verzija = "v6";
                                }

                                int mestoP = line.lastIndexOf("[");
                                int mestoZ = line.lastIndexOf("]");
                                String deo = line.substring(mestoP+1, mestoZ-1);
                                URL u1 = new URL(deo);
                                //System.err.println(u1.getPath());
                                if(!u1.getPath().contains(":")) {
                                    System.err.println(verzija + ":" + u1.getProtocol() + ":" + u1.getPath());
                                }
                            }
                            else if(line.contains("http"))
                            {
                                //System.err.println(line);
                                protokol = "http";
                                String[] podaci = line.split("]");
                                //System.err.println(podaci[0]);


                                if(podaci[1].contains("."))
                                {
                                    verzija = "v4";
                                }
                                else {
                                    verzija = "v6";
                                }

                                int mestoP = line.lastIndexOf("[");
                                int mestoZ = line.lastIndexOf("]");
                                String deo = line.substring(mestoP+1, mestoZ-1);
                                URL u1 = new URL(deo);
                                //System.err.println(u1.getPath());
                                if(!u1.getPath().contains(":")) {
                                    System.err.println(verzija + ":" + u1.getProtocol() + ":" + u1.getPath());
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}

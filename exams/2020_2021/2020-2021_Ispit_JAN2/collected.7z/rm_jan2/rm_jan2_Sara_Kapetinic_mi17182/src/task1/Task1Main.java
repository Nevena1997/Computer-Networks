package task1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

class Task1Main {
    
    public static void main(String[] args) throws MalformedURLException {

        System.out.println("Hello from: " + Task1Main.class.getName());

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("src/task1/logfile.txt")));
            String word = null;
            String putanja = null;
            String protocol = null;
            while((word = br.readLine())!=null){
                putanja = word.substring(word.lastIndexOf('/')+1,word.lastIndexOf(']'));
                protocol = word.substring(0,word.lastIndexOf(']')); // sad je niska do http:/
                protocol = protocol.substring(word.lastIndexOf("["),word.lastIndexOf('/'));
                protocol = protocol.substring(1,protocol.indexOf(':'));
                //System.out.println(protocol);
                if(!protocol.equals("http") && !protocol.equals("https")){
                    continue;
                }

                String version = word.substring(22);
                version = version.substring(0,version.indexOf(']'));

                int vers = 0;
                vers = getVersion(version);
                String path = word.substring(0 , word.lastIndexOf(']'));
                path = path.substring(path.lastIndexOf('[')+1);
                URL url = new URL(path);

                String datum = word.substring(1,20);
                Date now = new Date();

                System.out.println("v"+vers+ ":"+protocol+":"+url.getPath()+"   " );


            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public static int getVersion(String version){
        if(version.contains(".")){
             return 4;
        }
        else if(version.contains(":")){
            String[] bytes= new String[4];
            bytes = version.split(":");
            if(bytes.length == 8)
                return 6;
        }


        return -1;
    }

}

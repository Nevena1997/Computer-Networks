package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.Scanner;

import  java.net.InetAddress.*;

class UDPClient {
    private static  int PORT = 12345;
    public static void main(String[] args)
    {
        System.out.println("Hello from: " + UDPClient.class.getName());
        String host = "localhost";

        try(DatagramSocket sock = new DatagramSocket()) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            byte[] buf = new byte[512];


            InetAddress addr = InetAddress.getByName(host);
            DatagramPacket request = new DatagramPacket(buf,buf.length ,addr,UDPServer.PORT);
            sock.send(request);

            buf = br.readLine().getBytes();

            DatagramPacket response = new DatagramPacket(buf,buf.length,addr,PORT);
            sock.receive(response);

            System.out.println(buf);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

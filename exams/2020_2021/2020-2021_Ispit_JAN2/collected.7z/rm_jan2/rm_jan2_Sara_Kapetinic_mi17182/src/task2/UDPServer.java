package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPServer.class.getName());
        byte[] buffer = new byte[512];
        try(DatagramSocket server = new DatagramSocket(PORT)) {

            DatagramPacket request = new DatagramPacket(buffer , buffer.length);
            server.receive(request);
            int i=0;
            byte[] new_buffer = new byte[1024];
            String word = buffer.toString();

            int k=0;
            while(i< word.length()){

                if(Character.isUpperCase(word.charAt(i))){
                    new_buffer[k]= (byte) Character.toLowerCase(word.charAt(i));
                    new_buffer[k+1] = (byte) Character.toLowerCase(word.charAt(i));
                    k+=2;

                }
                else if(Character.isLowerCase(word.charAt(i))){
                    new_buffer[k] = (byte) Character.toUpperCase(word.charAt(i));
                    k++;

                }
                else if(Character.isDigit(word.charAt(i))){
                    new_buffer[k] = '.';
                    new_buffer[k+1] = '.';
                    k+=2;
                }

                else {
                    System.err.println("Dont know how to translate this character");
                    return;
                }

                i++;

            }

            DatagramPacket response = new DatagramPacket(new_buffer,new_buffer.length,request.getAddress(),request.getPort());
            server.send(response);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

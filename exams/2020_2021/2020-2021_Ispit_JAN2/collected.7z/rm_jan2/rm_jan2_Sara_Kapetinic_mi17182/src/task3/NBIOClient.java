package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import  java.net.InetAddress;

class NBIOClient {
    
    public static void main(String[] args)
    {
        System.out.println("Hello from: " + NBIOClient.class.getName());

        try (Socket socket = new Socket()) {

            SocketChannel sock = socket.getChannel();


        } catch (IOException e) {
            e.printStackTrace();
        }



    }


}

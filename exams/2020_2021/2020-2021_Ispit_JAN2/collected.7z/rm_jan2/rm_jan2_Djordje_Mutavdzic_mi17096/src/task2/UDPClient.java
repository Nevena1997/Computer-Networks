package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    public static int PORT = 12345;
    public static int MAX_BUFF = 512;
    public static String host = "localhost";

    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket();
            Scanner s = new Scanner(System.in))
        {
            //load string
            String line = s.nextLine();
            byte[] data = line.getBytes(StandardCharsets.UTF_8);

            //send to server
            DatagramPacket request = new DatagramPacket(data,data.length, InetAddress.getLocalHost(),PORT);
            socket.send(request);

            //receive from server

            DatagramPacket response = new DatagramPacket(new byte[MAX_BUFF],MAX_BUFF);
            socket.receive(response);

            //print to stdout
            System.out.println(new String(response.getData(),0,response.getLength(),StandardCharsets.UTF_8));
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

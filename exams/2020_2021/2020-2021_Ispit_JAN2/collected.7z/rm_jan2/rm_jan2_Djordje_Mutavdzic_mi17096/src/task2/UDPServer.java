package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    public static int PORT = 12345;
    public static int MAX_BUFF = 512;

    public static void main(String[] args) {

        System.err.println("Starting server...");
        try(DatagramSocket server = new DatagramSocket(PORT))
        {
            System.err.println("Server bound to: " + PORT);
            while(true) {
                System.err.println("Waiting for client...");
                //receive from client
                DatagramPacket request = new DatagramPacket(new byte[MAX_BUFF], MAX_BUFF);
                server.receive(request);
                //transform string
                String str = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);

                char[] karakteri = str.toCharArray();

                String result = "";

                for(char c : karakteri)
                {
                    if(Character.isUpperCase(c))
                    {
                        char tmpc = Character.toLowerCase(c);
                        String tmp = Character.toString(tmpc).concat(Character.toString(tmpc));
                        result = result.concat(tmp);
                    }else if(Character.isLowerCase(c))
                    {
                        char tmpc = Character.toUpperCase(c);
                        result = result.concat(Character.toString(tmpc));
                    }else if(Character.isDigit(c))
                    {
                        result = result.concat("..");
                    }else
                    {
                        result = result.concat(Character.toString(c));
                    }
                }

                byte[] data = result.getBytes(StandardCharsets.UTF_8);

                //return to client
                DatagramPacket response = new DatagramPacket(data,data.length,request.getAddress(),request.getPort());
                server.send(response);

                System.err.println("Client served...");
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

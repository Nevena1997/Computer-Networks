package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Scanner;

class NBIOClient {

    public static void main(String[] args) {
        try(SocketChannel socket = SocketChannel.open(new InetSocketAddress(12345));
            Scanner s = new Scanner(System.in)) {
            //load combination
                System.out.println("Unesite svoju SRECNU kombinaciju: ");
                String line = s.nextLine();
                byte[] data = line.getBytes(StandardCharsets.UTF_8);
                ByteBuffer buff = ByteBuffer.allocate(512);

                //send it to server
                buff.put(data);
                buff.flip();
                socket.write(buff);

                //receive answer from server

                buff.clear();
                int read = socket.read(buff);
                System.out.println(new String(buff.array(), 0, read, StandardCharsets.UTF_8));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

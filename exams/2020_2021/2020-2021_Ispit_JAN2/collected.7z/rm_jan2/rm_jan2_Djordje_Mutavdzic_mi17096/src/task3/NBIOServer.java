package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

class NBIOServer {

    public static void main(String[] args) {


        Random rand = new Random();
        int broj_poklapanja = 0;
        List<Integer> loto = new LinkedList<>();

        for(int i = 0 ; i < 7 ; i++)
        {
            loto.add(rand.nextInt(39));
        }

        System.out.println(loto.toString());


        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open())
        {
            server.bind(new InetSocketAddress(12345));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);


            while(true)
            {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    if (key.isAcceptable()) {
                        System.err.println("Accepting client");
                        ServerSocketChannel s = (ServerSocketChannel) key.channel();
                        SocketChannel client = s.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                        ByteBuffer buff = ByteBuffer.allocate(512);
                        clientKey.attach(buff);

                    } else if (key.isReadable()) {
                        System.err.println("Reading from client");
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        buff.clear();
                        int read = client.read(buff);

                        if (buff.hasRemaining()) {
                            String line = new String(buff.array(), 0, read, StandardCharsets.UTF_8);
                            String[] numbers = line.split(" ");

                            for (String number : numbers) {
                                if (loto.contains(Integer.parseInt(number)))
                                {
                                    broj_poklapanja++;
                                }
                            }
                            key.interestOps(SelectionKey.OP_WRITE);
                        }

                    } else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        String response = String.valueOf(broj_poklapanja);
                        byte[] data = response.getBytes(StandardCharsets.UTF_8);

                        buff.clear();
                        buff.put(data);
                        buff.flip();
                        client.write(buff);
                        buff.flip();
                        key.interestOps(SelectionKey.OP_READ);
                        broj_poklapanja = 0;

                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;


import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;

class Task1Main {

    public static void main(String[] args) {

        String path = "/home/ispit/Desktop/tests/urls.txt";

        try(Scanner in = new Scanner(Paths.get(path)))
        {
            String line;
            while(in.hasNextLine())
            {
                line = in.nextLine();
                line = line.replaceAll("\\[","");
                line = line.replaceAll("\\]"," ");
                String[] info = line.split(" ");

//                System.out.println("Time: " + info[0] + " " + info[1] + ",IP adresa: " + info[2] + ",URL: " + info[3]);

                Date time_now = new Date();
                String time_log = info[0].concat(" ").concat(info[1]);

                String protocol;
                try {
                    URL url = new URL(info[3]);
                    protocol = url.getProtocol();
                }catch(IOException e)
                {
                    continue;
                }

                if(time_now.getTime() < new Date(time_log).getTime() ||
                    (!protocol.equalsIgnoreCase("http") &&
                    !protocol.equalsIgnoreCase("https")))
                {
                    continue;
                }

                String result = "";

//                byte[] addr_bytes = info[2].getBytes(StandardCharsets.UTF_8);
//                InetAddress addr = InetAddress.getByAddress(addr_bytes);
//                if(addr instanceof Inet4Address)
//                    result = result.concat("v4:").concat(protocol).concat(":").concat(path);
//                else if(addr instanceof Inet6Address)
//                    result = result.concat("v6:").concat(protocol).concat(":").concat(path);

                if(info[2].contains(":"))
                    result = result.concat("v6:").concat(protocol).concat(":").concat(path);
                else
                    result = result.concat("v4:").concat(protocol).concat(":").concat(path);



                System.out.println(result);



            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

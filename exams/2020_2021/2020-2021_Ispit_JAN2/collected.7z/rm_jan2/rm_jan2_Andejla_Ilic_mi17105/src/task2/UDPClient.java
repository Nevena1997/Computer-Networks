package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class UDPClient {
    private static int port = 12345;
    private DatagramSocket socket;
    private InetAddress host;

    UDPClient() throws SocketException, UnknownHostException {
        this.socket = new DatagramSocket();
        this.host = InetAddress.getByName("localhost");
    }

    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());

        try {
            UDPClient client = new UDPClient();
            client.startLogic();
        } catch (SocketException e) {
            System.err.println("Cannot connect to socket");
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

    }

    public void startLogic(){
        try(Scanner sin = new Scanner(System.in);){
            System.err.println("Inset the line: ");
            String line = sin.nextLine();
            byte[] buffer = new byte[4096*2];
            buffer = line.getBytes();
            DatagramPacket request = new DatagramPacket(buffer, buffer.length, this.host, this.port);
            this.socket.send(request);

            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            this.socket.receive(response);

            byte[] fromServer = response.getData();
            String ispis = new String(buffer, 0, buffer.length);
            System.err.println(ispis);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

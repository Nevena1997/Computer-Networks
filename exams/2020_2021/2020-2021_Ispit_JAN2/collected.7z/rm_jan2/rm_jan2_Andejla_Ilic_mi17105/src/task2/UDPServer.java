package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import static java.lang.Character.toLowerCase;
import static java.lang.Character.toUpperCase;

final class UDPServer {

    public static final int port = 12345;
    private DatagramSocket server;

    public static void main(String[] args) {
        try {
            UDPServer serever = new UDPServer();
            serever.execute();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }


    UDPServer() throws SocketException {
        this.server = new DatagramSocket(port);
    }

    public void execute(){

        try{
            while(true){
                System.err.println("Listening for clients");
                byte[] buffer = new byte[4096*2];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                server.receive(request);

                byte[] line = request.getData();
                String responsemsg = this.changeLine(line);

                buffer = responsemsg.getBytes();
                DatagramPacket response = new DatagramPacket(buffer, buffer.length, request.getSocketAddress());
                server.send(response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public String changeLine(byte[] requestMsg){
        String line = new String(requestMsg, 0,  requestMsg.length);
        char[] characters = line.toCharArray();
        StringBuilder sb = new StringBuilder("");

        for(char c : characters){
            if(c>='A' && c<='Z'){
                //veliko slovo
                sb.append(toLowerCase(c));
                sb.append(toLowerCase(c));
            }else if( c>= 'a' && c<='z'){
                //malo slovo
                sb.append(toUpperCase(c));
                sb.append(toUpperCase(c));
            }else if(c>='0' && c<='9'){
                //broj
                sb.append('.');
                sb.append('.');
            }else{
                sb.append(c);
            }
        }

        return sb.toString();
    }
}

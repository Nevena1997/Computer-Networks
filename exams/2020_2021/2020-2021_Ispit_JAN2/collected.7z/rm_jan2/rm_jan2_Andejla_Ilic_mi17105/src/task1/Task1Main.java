package task1;

import java.io.*;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {

        try{
            String fileName = new String("urls.txt");
            BufferedReader fin = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(new File(fileName)
                    )));
            String line;

            while((line = fin.readLine()) != null){
                int firstOB = line.indexOf('[');
                int firstCB = line.indexOf(']');
                String date = line.substring(firstOB +1, firstCB);

                String rest1 = line.substring(firstCB+1);
                int secondOB = rest1.indexOf('[');
                int secondCB = rest1.indexOf(']');
                String ipAdress = rest1.substring(secondOB +1, secondCB);

                String rest2 = rest1.substring(secondCB+1);
                int lastOB = rest2.indexOf('[');
                int lastCB = rest2.indexOf(']');
                String urlAdress = rest2.substring(lastOB +1, lastCB);

                boolean ipVersion4 = true;
                if(ipAdress.contains(":")){
                    ipVersion4 = false;
                }
                int indexForProtocol = urlAdress.indexOf('/');
                String protocol = urlAdress.substring(0, indexForProtocol);
                String path = urlAdress.substring(indexForProtocol+1);
                if(ipVersion4)
                    System.out.print("v4:");
                else
                    System.out.print("v6:");
                System.out.print(protocol + ":" + path + "\n");
            }

        } catch (FileNotFoundException e) {
            System.err.println("Given file cannot be found");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

class NBIOServer {

    public static final int port = 12345;

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            server.bind(new InetSocketAddress(port));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            System.err.println("Server listening for clients...");

            while (true) {
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> it = keys.iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()) {
                        accetCliet(key, selector);
                    } else if (key.isReadable()) {
                        readClientsRequest(key);
                    }else if(key.isWritable()){
                        writeToCLient(key);
                    }

                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void accetCliet(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel sereve = (ServerSocketChannel) key.channel();
        SocketChannel client  = sereve.accept();
        System.err.println("Client accepted");
        try {
            client.configureBlocking(false);
            client.register(selector, SelectionKey.OP_READ);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void readClientsRequest(SelectionKey key) {
        SocketChannel client = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();

        System.err.println("Reading clients request");

        if (buffer == null) {
            //Klijentu nie dodeljen buffer
            buffer.allocate(16384);
            key.attach(buffer);
        }

        try {
            buffer.flip();
            client.read(buffer);
            key.interestOps(SelectionKey.OP_WRITE);

        } catch (IOException e) {
            System.err.println("Neuspelo citanje iz bafera");

            try {
                key.channel().close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            key.cancel();
            e.printStackTrace();
        }

    }

    public static void writeToCLient(SelectionKey key) throws IOException {
        ByteBuffer buffer = (ByteBuffer) key.attachment();
        SocketChannel client = (SocketChannel) key.channel();

        System.err.println("Writing to client");

        buffer.flip();
        String combination = generateLotoCombionation();
        String[] loto = combination.split(" ");
        String clientsCombination = new String(buffer.array(), 0, buffer.limit());
        String[] c = clientsCombination.split(" ");

        int correct = 0;
        for(int i =0; i<7; i++){
            if(c[i].equals(loto[i])){
                correct++;
            }
        }
        String response = new String(String.valueOf(correct));
        buffer.clear();
        buffer.put(response.getBytes());
        buffer.flip();
        client.write(buffer);

        //Diskonektujem klijenta jer nema sta vise da salje
        try{
            key.channel().close();
        }catch (IOException e){
            e.printStackTrace();
        }
        key.cancel();


    }

    public static String generateLotoCombionation(){
        StringBuilder sb = new StringBuilder("");

        for(int i=0; i<7; i++){
            Random randomGenerateor = new Random(5);
            //randomGenerateor;
        }

        return "27 5 6 39 8 25 7";
    }
}

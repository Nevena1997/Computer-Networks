package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;;
import java.nio.channels.SocketChannel;
import java.util.Scanner;


class NBIOClient {
    public static final int port = 12345;

    public static void main(String[] args) {

        try(Scanner sc  = new Scanner(System.in);
            SocketChannel client  = SocketChannel.open(new InetSocketAddress(port)))
        {
            //System.err.println(client.getLocalAddress());
            StringBuilder sb = new StringBuilder("");

            for(int i=0; i<7; i++){
                System.out.println("Insert number between 1 an 39");
                String number = sc.next();
                sb.append(number);
                sb.append(" ");
            }

            String lotoCombination = sb.toString();
            //System.out.println(lotoCombination);
            byte[] buffer = lotoCombination.getBytes();
            ByteBuffer buf = ByteBuffer.wrap(buffer);

            buf.flip();
            client.write(buf);
            buf.clear();
            client.read(buf);

            buf.flip();
            String correct = new String(buf.array(), 0, buf.limit());
            System.err.println(correct);


        } catch (IOException e) {
            System.err.println("connection");
            e.printStackTrace();
        }
    }

}

package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class NBIOClient {
    
    public static void main(String[] args) {
        try (SocketChannel sc = SocketChannel.open(new InetSocketAddress(12345))) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Unesite loto brojeve:");

            int[] komb = new int[7];
            ByteBuffer bb = ByteBuffer.allocate(7*4);

            for(int i=0;i<komb.length;i++){
                komb[i]=scan.nextInt();
                bb.putInt(komb[i]);
            }

            bb.flip();
            sc.write(bb);
            bb.clear();
            ByteBuffer bb_w = ByteBuffer.allocate(4);

            sc.read(bb);

            bb.rewind();
            IntBuffer ib = bb.asIntBuffer();
            System.out.println("Pogodjeno je "+ib.get(0));


            scan.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

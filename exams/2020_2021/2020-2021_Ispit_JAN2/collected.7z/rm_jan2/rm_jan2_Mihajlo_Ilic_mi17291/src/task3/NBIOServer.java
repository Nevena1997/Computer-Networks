package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;

class NBIOServer {

    static int[] gen=new int[7];

    static boolean occ(int i){
        for(var e:gen)
            if(e==i)
                return true;
            return false;
    }
    
    public static void main(String[] args) {

        gen[0]=5;
        gen[1]=7;
        gen[2]=13;
        gen[3]=15;
        gen[4]=20;
        gen[5]=25;
        gen[6]=30;


        try (ServerSocketChannel serv = ServerSocketChannel.open()) {
            Selector sel = Selector.open();


            serv.bind(new InetSocketAddress(12345));
            serv.configureBlocking(false);

            serv.register(sel, SelectionKey.OP_ACCEPT);

            while (true){
                sel.select();
                Iterator<SelectionKey> it = sel.selectedKeys().iterator();

                while (it.hasNext()){


                    var key =it.next();

                    it.remove();

                    if(key.isAcceptable()){
                        ServerSocketChannel s = (ServerSocketChannel) key.channel();
                        SocketChannel sc = s.accept();
                        sc.configureBlocking(false);
                        System.out.println("konektovao se korisnik");

                        SelectionKey k = sc.register(sel,SelectionKey.OP_READ);
                        ByteBuffer bb = ByteBuffer.allocate(7*4);
                        k.attach(bb);
                    }
                     else
                    if(key.isReadable()){
                        SocketChannel sc = (SocketChannel) key.channel();
                        ByteBuffer bb = (ByteBuffer) key.attachment();


                        sc.read(bb);

                        if(!bb.hasRemaining())
                            key.interestOps(SelectionKey.OP_WRITE);

                    } else
                    if(key.isWritable()){
                        SocketChannel sc = (SocketChannel) key.channel();
                        ByteBuffer kombinacija = (ByteBuffer) key.attachment();

                        kombinacija.rewind();
                        IntBuffer ib = kombinacija.asIntBuffer();

                        int broj_pogodjenih = 0;
                        for(int i=0;i<7;i++){
                            int a=ib.get(i);
                            if(occ(a))
                                broj_pogodjenih++;
                        }

                        ByteBuffer sw = ByteBuffer.allocate(4);
                        sw.putInt(broj_pogodjenih);

                        sw.flip();
                        sc.write(sw);
                        sw.clear();
                        key.cancel();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

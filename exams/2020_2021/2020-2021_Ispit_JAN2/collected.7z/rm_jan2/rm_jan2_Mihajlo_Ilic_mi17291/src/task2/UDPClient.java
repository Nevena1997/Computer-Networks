package task2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket()) {
            Scanner sc =new Scanner(System.in);
            System.out.println("unesite nisku:");
            String niska = sc.nextLine();

            DatagramPacket dp = new DatagramPacket(niska.getBytes(StandardCharsets.US_ASCII),0,niska.getBytes().length
                                                    , InetAddress.getLocalHost(),12345);
            ds.send(dp);

            byte[] bits = new byte[niska.length() * 3];

            DatagramPacket rec = new DatagramPacket(bits,0,bits.length);

            ds.receive(rec);

            String primljen = new String(rec.getData(),0,rec.getLength(),StandardCharsets.US_ASCII);
            System.out.println("server salje: "+primljen);

            sc.close();

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("nije uspesno poslata poruka");
            e.printStackTrace();
        }


    }

}

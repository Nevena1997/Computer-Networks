package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;

class UDPServer {
    
    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket(12345, InetAddress.getLocalHost())) {


            while(true) {
                byte[] b = new byte[512];

                DatagramPacket dp = new DatagramPacket(b, 0, b.length);

                ds.receive(dp);

                String niska = new String(dp.getData(), 0, dp.getLength(), StandardCharsets.US_ASCII);
                System.out.println("primljena niska: "+niska);

                String nova_niska="";
                for(int i=0;i<niska.length();i++){

                    char curr = niska.charAt(i);
                    if(Character.isUpperCase(curr)){
                        char n_c = Character.toLowerCase(curr);
                        String n = new String();
                        n += (char)n_c;
                        n += (char)n_c;
                        nova_niska+=n;
                    } else
                    if(Character.isLowerCase(curr)){
                        char n_c = Character.toUpperCase(curr);
                        String n = new String();
                        n +=(char) n_c;
                        nova_niska+=n;
                    } else
                    if(Character.isDigit(curr)){
                        nova_niska+="..";
                    }
                    else {
                        nova_niska+=(char)curr;
                    }
                }
                System.out.println("saljem nisku: "+ nova_niska);

                DatagramPacket send_packet = new DatagramPacket(nova_niska.getBytes(),0,nova_niska.getBytes().length,
                                                                dp.getAddress(),dp.getPort());
                ds.send(send_packet);

            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

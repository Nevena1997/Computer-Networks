package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("unesite putanju:");
        Scanner sc = new Scanner(System.in);
        String putanja = sc.next();
        try {
            URL url = new URL("FILE","localhost",putanja);
            BufferedReader br =new BufferedReader(new InputStreamReader(url.openStream()));
            List<String> lista = new ArrayList<>();
            String linija = "";
            while ((linija=br.readLine())!=null)
                lista.add(linija);
            Date datum = new Date();

            lista.stream()
                    .filter(a->{ if(a.contains("http") || a.contains("https")) return true;     return false;}) //samo HTTp

                    .map(a->{ var niz = a.split("\\]");   //MAPIRANJE U DOBRE
                                  for(int i=0;i<niz.length;i++)
                                     niz[i] = niz[i].substring(1);
                                     return niz; })
                    .filter(a->{  Date d = new Date(a[0]); return d.before(datum);   }) // IZBACIVANJE STARIJIH
                    .filter(a->{            //IZBACIVANJE LOSIH PORTOVA
                        try {
                            URL u = new URL(a[2]);
                            return u.getPort()==-1;
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        return true;
                    })
                    .map(a->{                              //PREBACIVANJE U DOBRU FORMU
                           String verzija = "6";
                           if(a[1].contains("."))
                               verzija="4";
                        try {
                            URL u = new URL(a[2]);

                            return "v"+verzija+":"+a[2].substring(0,a[2].indexOf("/"))+ u.getPath();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return  "v"+verzija+":"+a[2].substring(0,a[2].indexOf("/"));

                    } )
                    .forEach(a-> System.out.println(a));


            br.close(); // zatvaranje

        } catch (MalformedURLException e) {
            System.err.println("ne postoji putanja za datoteku");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

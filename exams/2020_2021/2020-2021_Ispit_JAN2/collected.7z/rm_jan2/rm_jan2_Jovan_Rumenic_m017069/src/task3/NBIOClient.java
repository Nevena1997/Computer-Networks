package task3;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class NBIOClient {
    
    public static void main(String[] args) {
        try(SocketChannel s = SocketChannel.open();
            Scanner sc=new Scanner(System.in)){

            SocketAddress sa = new InetSocketAddress("localhost",12345);


            s.configureBlocking(true);


            s.connect(sa);

            int[] l = new int[7];


            for(int i = 0; i<7;i++){
                l[i]=sc.nextInt();
                if(l[i]<1 || l[i]>39){
                    System.out.println("Pogresan broj je unet!");
                    return;
                }
            }







        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

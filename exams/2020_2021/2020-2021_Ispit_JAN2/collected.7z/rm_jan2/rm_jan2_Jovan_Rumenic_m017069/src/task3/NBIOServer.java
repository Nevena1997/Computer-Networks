package task3;

class NBIOServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + NBIOServer.class.getName());
    }

}

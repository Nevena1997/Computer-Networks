package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {

    public static void main(String[] args) {
            try (DatagramSocket ds = new DatagramSocket(12345)) {

                while(true) {

                    DatagramPacket dp = new DatagramPacket(new byte[512], 512);
                    ds.receive(dp);

                    StringBuilder ss = new StringBuilder();

                    String s = new String(dp.getData(), 0, dp.getLength(), StandardCharsets.UTF_8);


                    for (int i = 0; i < s.length(); i++) {
                        if (Character.isUpperCase(s.charAt(i))) {
                            ss.append(Character.toLowerCase(s.charAt(i)));
                            ss.append(Character.toLowerCase(s.charAt(i)));
                        } else if (Character.isLowerCase(s.charAt(i))) {
                            ss.append(Character.toUpperCase(s.charAt(i)));
                        } else if (Character.isDigit(s.charAt(i))) {
                            ss.append('.');
                            ss.append('.');
                        } else {
                            ss.append(s.charAt(i));
                        }
                    }

                    String sss = ss.toString();

                    byte[] b = sss.getBytes();

                    DatagramPacket c = new DatagramPacket(b, b.length, dp.getAddress(), dp.getPort());

                    ds.send(c);

                }

            } catch (SocketException e) {
                System.out.println("1");
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("2");
                e.printStackTrace();
            }

        }
    }
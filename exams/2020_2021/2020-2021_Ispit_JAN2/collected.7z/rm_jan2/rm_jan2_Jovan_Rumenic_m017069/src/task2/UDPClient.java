package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try(DatagramSocket ds = new DatagramSocket();
            Scanner sc=new Scanner(System.in)){

            String niska = sc.nextLine();
            byte[] bb = niska.getBytes();
            DatagramPacket dp = new DatagramPacket(bb,bb.length,InetAddress.getByName("localhost"),12345);
            ds.send(dp);

            DatagramPacket r = new DatagramPacket(new byte[512],512);
            ds.receive(r);

            String s=new String(r.getData(),0,r.getLength(), StandardCharsets.UTF_8);
            System.out.println(s);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

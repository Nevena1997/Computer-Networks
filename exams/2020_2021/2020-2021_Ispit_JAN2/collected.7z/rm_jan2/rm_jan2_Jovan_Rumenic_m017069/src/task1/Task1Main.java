package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        try(Scanner sc = new Scanner(System.in)){

            String pathname=sc.next();


            URL u= new URL("file","localhost", pathname);
            URLConnection c=u.openConnection();

            StringBuilder ss = new StringBuilder();
            StringBuilder sss = new StringBuilder();

            Scanner scu = new Scanner(u.openStream());
            while(scu.hasNextLine()){
                String s = scu.nextLine();
                if(s.contains("https") || s.contains("http")){
                    ss.append("v");
                    String helper = s.substring(21,30);
                    if(helper.contains(":")){
                        ss.append("6:");
                    }
                    else
                        ss.append("4:");

                    if(s.contains("https")){
                        ss.append("https:");
                    }
                    else
                        ss.append("http:");


                    int i = s.length()-1;

                    while(true){
                        sss.append(s.charAt(i));
                        if(s.charAt(i)=='[')
                            break;
                        i--;
                    }

                    ss.append(sss.reverse());

                    String g = s.substring(1,20);
                    Date gg=new Date(g);
                    Date n = new Date();
                    if(gg.before(n))
                        System.out.println(ss.toString());
                    ss=new StringBuilder();
                    sss=new StringBuilder();
                }

            }
            Date n= new Date("06/10/2020 10:09:55");

            Date gg=new Date();
            if(n.after(gg))
                System.out.println(n.toString());
            ///home/ispit/Desktop/tests/urls.txt


        } catch (FileNotFoundException | MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

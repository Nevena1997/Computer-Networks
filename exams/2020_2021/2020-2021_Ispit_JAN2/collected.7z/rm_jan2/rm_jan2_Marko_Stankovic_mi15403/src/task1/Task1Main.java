package task1;


import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.util.Date;

class Task1Main {

    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());

        parse("/home/ispit/Desktop/tests/urls.txt");
    }

    private static void parse(String pathToFile) {

        try (FileInputStream file = new FileInputStream(pathToFile);
             BufferedReader reader = new BufferedReader(new InputStreamReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {
                process(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void process(String line) {
        String[] parts = line.split("]");

        String timeStr = parts[0].substring(1);
        String ipStr = parts[1].substring(1);
        String urlStr = parts[2].substring(1);


        boolean printLine = false;

        try {
            URL url = new URL(urlStr);

            if (url.getProtocol().equals("http") || url.getProtocol().equals("https")) {
                printLine = true;
            }


            InetAddress address = InetAddress.getByName(ipStr);

            String newFormat = "v";

            if (address instanceof Inet4Address) {
                newFormat += "4";
            } else if (address instanceof Inet6Address) {
                newFormat += "6";
            }


            newFormat += ":" + url.getProtocol() + ":" + url.getPath();



            Date date = new Date(timeStr);
            long now = System.currentTimeMillis();
            if ((now > date.getTime()) && printLine) {
                System.out.println(newFormat);
            }

        } catch (MalformedURLException | UnknownHostException e) {
            // e.printStackTrace();
        }
    }

}

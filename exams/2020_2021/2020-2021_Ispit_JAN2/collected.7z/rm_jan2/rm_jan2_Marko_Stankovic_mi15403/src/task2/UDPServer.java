package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class UDPServer {

    private int port;

    UDPServer(int port) {
        this.port = port;
    }

    public void start() {
        try (DatagramSocket server = new DatagramSocket(this.port);) {

            while (true) {
                byte[] buffer = new byte[MainTask2.BUFFER_SIZE];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                server.receive(request);

                String msgFromClient = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
                System.out.println("From client: " + msgFromClient);

                byte[] responseData = this.processRequest(msgFromClient);
                DatagramPacket packet = new DatagramPacket(responseData, responseData.length, request.getAddress(), request.getPort());
                server.send(packet);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private byte[] processRequest(String requestData) {
        List<String> response = new ArrayList<>();
        String[] arr = requestData.trim().split("");

        Arrays.stream(arr).forEach(s -> {
            if (s.matches("[A-Z]")) {
                response.add(s.toLowerCase());
                response.add(s.toLowerCase());
            } else if (s.matches("[a-z]")) {
                response.add(s.toUpperCase());
            } else if (s.matches("[0-9]")) {
                response.add("..");
            } else {
                response.add(s);
            }
        });

        response.add("\n");

        StringBuilder sb = new StringBuilder();
        for (String s : response) {
            sb.append(s);
        }

        String resultingStr = sb.toString();

        return resultingStr.getBytes();
    }

}

package task2;

public class MainTask2Client {
    public static void main(String[] args) {
        UDPClient client = new UDPClient(MainTask2.HOST, MainTask2.PORT);
        client.start();
    }
}

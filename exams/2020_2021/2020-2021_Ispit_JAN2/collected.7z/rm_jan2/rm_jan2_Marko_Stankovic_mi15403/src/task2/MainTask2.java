package task2;

public class MainTask2 {

    public static int BUFFER_SIZE = 1024;
    public static int PORT = 12345;
    public static String HOST = "localhost";

    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());

        UDPServer server = new UDPServer(PORT);

        server.start();



    }
}

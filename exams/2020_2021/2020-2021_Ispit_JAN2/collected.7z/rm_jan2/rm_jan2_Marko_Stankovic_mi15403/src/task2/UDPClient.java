package task2;

import javax.xml.crypto.Data;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

class UDPClient {

    String host;
    int port;

    UDPClient(String host, int port) {
        this.host = host;
        this.port = port;
    }


    public void start() {

        try (DatagramSocket client = new DatagramSocket()) {
            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter message for server: ");
            String userInput = userIn.readLine();


            DatagramPacket request = new DatagramPacket(userInput.getBytes(), userInput.getBytes().length,
                    InetAddress.getByName(host), this.port);
            client.send(request);

            byte[] buffer = new byte[MainTask2.BUFFER_SIZE];

            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            client.receive(response);

            String outputMsg = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);

            System.out.println(outputMsg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Loto {

    public static List<Integer> generateCombination() {
        ArrayList<Integer> combination = new ArrayList<Integer>();

        Random rand = new Random();
        while(combination.size() < 7) {
            Integer randNum = rand.nextInt(38) + 1;
            if (combination.contains(randNum))
                continue;
            combination.add(randNum);
        }

        return combination;
    }

    public static Integer checkScore(List<Integer> combination, List<Integer> ticket) {
        Integer guessedCount = 0;
        for (Integer i : ticket) {
            if (combination.contains(i))
                guessedCount++;
        }

        return guessedCount;
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

class NBIOServer {

    public static String HOST = "localhost";
    public static int PORT = 12345;

    public static int BUFFER_SIZE = 1024;

    private static List<Integer> combination;
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + NBIOServer.class.getName());

        combination = Loto.generateCombination();
        Collections.sort(combination);
        System.out.println("Generated combination: " + combination.toString());

        List<Integer> ticket = Loto.generateCombination();
        Collections.sort(ticket);
        System.out.println("Test ticket combination: " + ticket.toString());
        Integer score = Loto.checkScore(combination, ticket);

        System.out.println("Test ticket score: " + score);

        start();
    }



    public static void start() {
        try (ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if (!server.isOpen() || !selector.isOpen()) {
                System.err.println("Error while opening server or selector, exiting...");
                System.exit(-1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            System.out.println("Server listening on port: " + PORT);

            while (true) {

                try {
                    selector.select();
                    Set<SelectionKey> selectedKeys = selector.selectedKeys();

                    Iterator<SelectionKey> it = selectedKeys.iterator();

                    while (it.hasNext()) {
                        SelectionKey key = it.next();
                        it.remove();

                        if (key.isAcceptable()) {
                            processAccept(key, selector);
                        } else if (key.isReadable()) {
                            processRead(key, selector);
                        } else if (key.isWritable()) {
                            processWrite(key, selector);
                        }
                    }
                } catch (IOException e) {
                    System.out.println("pap");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processAccept(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel channel = (ServerSocketChannel) key.channel();
        SocketChannel client = channel.accept();
        client.configureBlocking(false);
        client.register(selector, SelectionKey.OP_READ);
        System.out.println("Client from " + client.getRemoteAddress());
    }

    private static void processRead(SelectionKey key, Selector selector) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();

        ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
        client.read(buffer);

        // Read data from client in form "num,num,num,num,num,num,num\n"
        String clientMsg = new String(buffer.array(), 0, buffer.position(), StandardCharsets.UTF_8);
        List<Integer> ticket = parseClientMessage(clientMsg);

        // Attach score for this ticket
        Integer score = Loto.checkScore(combination, ticket);
        key.attach(score);

        buffer.flip();

        key.interestOps(SelectionKey.OP_WRITE);
    }

    private static void processWrite(SelectionKey key, Selector selector) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        Integer score = (Integer) key.attachment();

        ByteBuffer response = ByteBuffer.wrap(String.valueOf(score).getBytes());
        client.write(response);
        response.clear();
        client.close();
    }

    private static List<Integer> parseClientMessage(String message) {
        // TODO: Throw exception if message is not valid
        String[] stringNumbers = message.trim().split(",");
        List<Integer> integers = new ArrayList<>();
        Arrays.stream(stringNumbers).forEach(stringNumber -> integers.add(Integer.valueOf(stringNumber)));
        return integers;
    }
}

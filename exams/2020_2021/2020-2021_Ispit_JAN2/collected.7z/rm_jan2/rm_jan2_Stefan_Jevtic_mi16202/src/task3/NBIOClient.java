package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ScatteringByteChannel;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class NBIOClient {
    
    public static void main(String[] args) {

        System.out.println("Hello from: " + NBIOClient.class.getName());

        try(SocketChannel connection = SocketChannel.open(new InetSocketAddress(NBIOServer.PORT));) {
            connection.configureBlocking(true);

            Scanner sc = new Scanner(System.in);

            ByteBuffer luckyBuffer = ByteBuffer.allocate(28);
            for(int i=0; i<7; i++) {
                int num = sc.nextInt();
                luckyBuffer.putInt(num);
            }

            luckyBuffer.flip();
            while (luckyBuffer.hasRemaining())
                connection.write(luckyBuffer);

            ByteBuffer responseBuffer = ByteBuffer.allocate(4);
            connection.read(responseBuffer);
            System.out.println(responseBuffer.getInt());


        }
        catch (IOException e) {
            System.err.println("Failed to conn to server");
            e.printStackTrace();
        }

    }

}

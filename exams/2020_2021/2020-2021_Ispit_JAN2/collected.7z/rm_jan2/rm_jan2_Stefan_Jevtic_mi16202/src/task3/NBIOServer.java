package task3;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

class NBIOServer {

    static final int PORT = 12345;
    static int[] lotoNumbers;


    public static void main(String[] args) {


        lotoNumbers = lotoInit();

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();) {

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
                            SocketChannel client = serverSocketChannel.accept();

                            client.configureBlocking(false); //Check this
                            client.register(selector, SelectionKey.OP_READ);

                            System.out.println("Client accepted");
                        }
                        else if(key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer requestBuff = ByteBuffer.allocate(28);
                            while (requestBuff.hasRemaining())
                                client.read(requestBuff);

                            int[] luckyNumbers = new int[7];
                            requestBuff.flip();
                            requestBuff.asIntBuffer().get(luckyNumbers);



                            ByteBuffer responseBuff = ByteBuffer.allocate(4);
                            responseBuff.putInt(numOfHits(luckyNumbers));

                            responseBuff.flip();
                            key.attach(responseBuff);
                            client.register(selector, SelectionKey.OP_WRITE);
                        }
                        else if(key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer reponseBuff = (ByteBuffer) key.attachment();
                            while (reponseBuff.hasRemaining())
                                client.write(reponseBuff);
                        }
                    }
                    catch (IOException ke) {
                        System.err.println("Problem with key");
                        ke.printStackTrace();
                        try {
                            key.channel().close();
                        }
                        catch (IOException e) {
                            System.err.println("Channel closed");
                            e.printStackTrace();
                        }

                        key.cancel();
                    }
                }

            }

        }
        catch (IOException se) {
            System.err.println("Failed to start server!");
            se.printStackTrace();
        }
    }

    private static int[] lotoInit() {
        Random r = new Random();
        int[] lotoNumbers = new int[7];
        for(int i=0; i< 7; i++) {
            lotoNumbers[i] = r.nextInt(40);
        }

        return lotoNumbers;
    }

    private static int numOfHits(int[] luckyNumbers) {

        if(!isValidCombination(luckyNumbers)) return 0;


        return 7;
    }

    private static boolean isValidCombination(int[] luckyNumbers) {
        return true;
    }

}

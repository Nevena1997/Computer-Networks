package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;

class UDPServer {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + UDPServer.class.getName());


        try(DatagramSocket server = new DatagramSocket(12345)) {

            byte[] msgBuff = new byte[256];
            DatagramPacket request = new DatagramPacket(msgBuff, 0, msgBuff.length);

            while (true) {
                server.receive(request);
                System.out.println("Msg recived");
                System.out.println(new String(msgBuff));

                char [] chars = (new String(msgBuff)).toCharArray();
                StringBuilder modifiedMsg = new StringBuilder();

                for(char nextChar : chars) {
                    if (Character.isLowerCase(nextChar))
                        modifiedMsg.append(Character.toUpperCase(nextChar));
                    else if (Character.isUpperCase(nextChar)) {
                        modifiedMsg.append(Character.toLowerCase(nextChar));
                        modifiedMsg.append(Character.toLowerCase(nextChar));
                    }
                    else if (Character.isDigit(nextChar)) {
                        modifiedMsg.append('.');
                        modifiedMsg.append('.');
                    }
                    else {
                        modifiedMsg.append(nextChar);
                    }
                }

                System.out.println("String modified");
                System.out.println(modifiedMsg);

                byte[] responseBuff = modifiedMsg.toString().getBytes();
                DatagramPacket response = new DatagramPacket(responseBuff, 0, responseBuff.length,
                                                            request.getAddress(), request.getPort());
                server.send(response);

                System.out.println(new String(responseBuff));
            }

        }
        catch (IOException e) {
            System.err.println("Server problem");
            e.printStackTrace();
        }


    }

}

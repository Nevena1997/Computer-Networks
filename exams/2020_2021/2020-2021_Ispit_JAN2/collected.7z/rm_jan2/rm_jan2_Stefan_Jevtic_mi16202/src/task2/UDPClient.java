package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String msg = sc.next();
        System.out.println(msg);


        try (DatagramSocket connection = new DatagramSocket()) {

            byte[] requestBuff = msg.getBytes();
            DatagramPacket request = new DatagramPacket(requestBuff, 0, requestBuff.length, InetAddress.getLocalHost(), 12345);
            connection.send(request);


            byte[] responseBuff = new byte[256];
            DatagramPacket response = new DatagramPacket(responseBuff, 0, requestBuff.length);
            connection.receive(response);

            System.out.println(new String(responseBuff));
        }
        catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Hello from: " + UDPClient.class.getName());
    }

}

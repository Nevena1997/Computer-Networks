package task1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

class Task1Main {

    public static void main(String[] args) throws MalformedURLException {
        try {
            URL url = new URL("file:///home/ispit/Desktop/tests/urls.txt");
            InputStream is = url.openStream();

//            int b;
//            while((b = is.read()) != -1){
//                System.out.println();
//            }
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = in.readLine()) != null) {
                if(line.contains("http") || line.contains("https"))
                    System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

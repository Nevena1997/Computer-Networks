package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;

class NBIOServer {

    public static void main(String[] args) throws IOException {

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            Integer[] lotoNums = generateNumbers();
//            System.out.println(Arrays.toString(lotoNums));
            int size = Arrays.toString(lotoNums).getBytes().length;

            server.bind(new InetSocketAddress(12345));
            server.configureBlocking(false);

            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel serverSocket = (ServerSocketChannel) key.channel();
                            SocketChannel client = serverSocket.accept();
                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_READ);
                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            if (buf == null) {
                                buf = ByteBuffer.allocate(size + 2);
                                key.attach(buf);
                            }

                            while (client.read(buf) != -1) {
                                client.read(buf);
                            }

                            String userNumbers = buf.toString();
                            String[] numsStr = userNumbers.split(" ");
                            int sizeOfStr = numsStr.length;
                            Integer[] userNum = new Integer[sizeOfStr];

                            if (sizeOfStr == 7) {

                                for (int i = 0; i < sizeOfStr; i++)
                                    userNum[i] = Integer.getInteger(numsStr[i]);


                                int count = 0;

                                for (int num : lotoNums) {
                                    for (int userN : userNum) {
                                        if (num == userN)
                                            count++;
                                    }
                                }

                                buf.flip();
                                byte[] numToBytes = Integer.toString(count).getBytes();
                                buf.put(numToBytes, 0, numToBytes.length);
                                buf.put((byte) '\r');
                                buf.put((byte) '\n');
                                buf.clear();

                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            client.write(buf);
                        }


                    } catch (IOException e) {
                        key.channel().close();
                        e.printStackTrace();
                    }
                }
            }

        }

    }

    private static Integer[] generateNumbers() {

        Integer[] lotoNums = new Integer[7];
        for (int i = 0; i < 7; i++) {
            Random r = new Random();
            int num = r.nextInt(40);
            lotoNums[i] = num;
            if (i > 0) {
                for (int j = 0; j < i; j++) {
                    if (lotoNums[i].equals(lotoNums[j]))
                        lotoNums[i] = r.nextInt(40);
                }
            }
        }

        return lotoNums;
    }

}

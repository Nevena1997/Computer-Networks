package task3;

import javax.sound.midi.Soundbank;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;


class NBIOClient {

    public static void main(String[] args) throws IOException {

        InetSocketAddress address = new InetSocketAddress("localhost", 12345);
        try (SocketChannel client = SocketChannel.open(address);
             Scanner in = new Scanner(System.in)) {

            System.out.printf("Unesite 7 razlicitih brojeva u opsegu od 1 do 39: ");
            Integer[] nums = new Integer[7];
            for (int i = 0; i < 7; i++) {
                nums[i] = in.nextInt();
            }
            in.close();

            ByteBuffer buf = ByteBuffer.allocate(Arrays.toString(nums).getBytes().length);
            client.write(buf);

            if(client.read(buf) != -1){
                System.out.println("Dobili ste " + buf);
            }
        }
    }

}

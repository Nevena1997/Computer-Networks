package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(12345)) {

            while(true) {
                try {
                    DatagramPacket request = new DatagramPacket(new byte[256], 256);
                    server.receive(request);

                    String toTransform = new String(request.getData(), 0, request.getLength());
                    int length = toTransform.length();

                    StringBuilder transformed = new StringBuilder();

                    for (int i = 0; i < length; i++) {
                        char ch = toTransform.charAt(i);
                        if (Character.isUpperCase(ch)) {
                            transformed.append(Character.toLowerCase(ch));
                            transformed.append(Character.toLowerCase(ch));
                        } else if (Character.isLowerCase(ch)) {
                            transformed.append(Character.toUpperCase(ch));
                        } else if (Character.isDigit(ch)) {
                            transformed.append('.');
                            transformed.append('.');
                        } else {
                            transformed.append(ch);
                        }
                    }

                    byte[] toSend = transformed.toString().getBytes();

                    DatagramPacket response = new DatagramPacket(toSend, toSend.length, request.getAddress(), request.getPort());
                    server.send(response);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (
                IOException e) {
            e.printStackTrace();
        }

    }

}

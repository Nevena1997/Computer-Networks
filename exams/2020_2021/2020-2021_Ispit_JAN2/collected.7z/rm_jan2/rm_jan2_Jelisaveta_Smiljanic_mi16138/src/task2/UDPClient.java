package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket()){

            Scanner sc = new Scanner(System.in);
            String line;
            line = sc.nextLine();
            sc.close();

            byte[] buf = line.getBytes(StandardCharsets.UTF_8);

            DatagramPacket request = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), 12345);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[128], 128);
            client.receive(response);

            //System.out.println(Arrays.toString(response.getData()));
            String transformed = new String(response.getData(), 0, response.getLength());
            System.out.println(transformed);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

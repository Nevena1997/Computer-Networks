package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    private static final int PORT=12345;

    public static void main(String[] args) {
        String niska;
        try(Scanner sc=new Scanner(System.in)) {
            niska=sc.nextLine();
        }

        try(DatagramSocket socket=new DatagramSocket()){
            byte[] buf=niska.getBytes();
            DatagramPacket request=new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), PORT);
            socket.send(request);

            byte[] bufForResponse=new byte[512];

            DatagramPacket response=new DatagramPacket(bufForResponse, bufForResponse.length);
            socket.receive(response);

            String result=new String(response.getData(), 0, response.getLength());
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

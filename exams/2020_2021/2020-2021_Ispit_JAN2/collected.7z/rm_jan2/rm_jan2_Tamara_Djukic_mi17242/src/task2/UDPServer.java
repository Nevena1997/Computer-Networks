package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Scanner;

class UDPServer {
    private static final int PORT=12345;

    public static void main(String[] args) {
        try (DatagramSocket socket=new DatagramSocket(PORT)) {
            byte[] buf=new byte[512];

            DatagramPacket request=new DatagramPacket(buf, buf.length);
            socket.receive(request);

            String niskaOdKlijenta=new String(request.getData(), 0, request.getLength());


            String novaRec="";
            try (Scanner sc=new Scanner(niskaOdKlijenta)) {
                while (sc.hasNext()){
                    String rec=sc.next();
                    char[] recChars=rec.toCharArray();


                    for(int i=0;i<recChars.length;i++){
                        if(Character.isUpperCase(recChars[i])){
                            novaRec+=Character.toLowerCase(recChars[i]);
                            novaRec+=Character.toLowerCase(recChars[i]);
                        }
                        else if(Character.isLowerCase(recChars[i])){
                            novaRec+=Character.toUpperCase(recChars[i]);
                        }
                        else if(Character.isDigit(recChars[i])){
                            novaRec+=".";
                            novaRec+=".";
                        }
                        else if(Character.isSpaceChar(recChars[i])){
                            novaRec+=" ";
                        }
                    }
                }
            }

            byte[] bufToSend=novaRec.getBytes();

            DatagramPacket response=new DatagramPacket(bufToSend, bufToSend.length, request.getAddress(), request.getPort());
            socket.send(response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

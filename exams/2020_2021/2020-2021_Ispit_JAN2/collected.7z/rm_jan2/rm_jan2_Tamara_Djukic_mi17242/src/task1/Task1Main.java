package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

class Task1Main {
    
    public static void main(String[] args){
        try {
            URL url=new URL("FILE", "localhost", "/home/ispit/Desktop/tests/urls.txt");
            URLConnection conn=url.openConnection();

            try (BufferedReader in=new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                while ((line=in.readLine())!=null){
                    if (line.contains("http")){
                        int indexBegin=line.lastIndexOf('[')+8;
                        int indexEnd=line.lastIndexOf(']');
                        String putanjaDoFajla=line.substring(indexBegin, indexEnd);
                        System.out.println("v"+"   "+":http:"+putanjaDoFajla);
                    }
                    if(line.contains("https")){
                        int indexBegin=line.lastIndexOf('[')+9;
                        int indexEnd=line.lastIndexOf(']');
                        String putanjaDoFajla=line.substring(indexBegin, indexEnd);
                        System.out.println("v"+"   "+":https:"+putanjaDoFajla);
                    }
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

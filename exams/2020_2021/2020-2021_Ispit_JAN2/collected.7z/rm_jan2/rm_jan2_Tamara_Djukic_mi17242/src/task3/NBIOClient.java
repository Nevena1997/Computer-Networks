package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class NBIOClient {
    private static final int PORT=12345;

    public static void main(String[] args) {
        try (SocketChannel socket=SocketChannel.open(new InetSocketAddress("localhost", PORT))) {

            ByteBuffer buf=ByteBuffer.allocate(512);

            int i=0;
            try (Scanner sc=new Scanner(System.in)) {
                while (i<7 && sc.hasNextInt()){
                    buf.putInt(sc.nextInt());

                    i++;
                }
            }

            socket.write(buf);

            WritableByteChannel out= Channels.newChannel(System.out);
            while ((socket.read(buf))!=-1){
                out.write(buf);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

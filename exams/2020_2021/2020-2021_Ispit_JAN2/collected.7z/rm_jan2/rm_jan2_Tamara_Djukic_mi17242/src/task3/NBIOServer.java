package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;

class NBIOServer {
    private static final int PORT=12345;

    public static void main(String[] args) {

        ThreadLocalRandom r = ThreadLocalRandom.current();
        byte[] bufOfRandoms=new byte[512];
        for(int i=0;i<7;i++){
            bufOfRandoms[i]=(byte) r.nextInt(40);
        }

        try (ServerSocketChannel serverChannel=ServerSocketChannel.open();
             Selector selector=Selector.open()
        ) {
            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){
                selector.select();

                Iterator<SelectionKey> it=selector.selectedKeys().iterator();
                while (it.hasNext()){
                    SelectionKey key=it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()){
                            ServerSocketChannel server=(ServerSocketChannel)key.channel();
                            SocketChannel client=server.accept();
                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_READ);
                        }
                        else if(key.isReadable()){
                            SocketChannel client=(SocketChannel)key.channel();
                            ByteBuffer buf=(ByteBuffer)key.attachment();

                            client.read(buf);

                            if (!buf.hasRemaining() && buf.toString()==bufOfRandoms.toString()){
                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                            buf.flip();
                        }
                        else if(key.isWritable()){
                            SocketChannel client=(SocketChannel)key.channel();
                            ByteBuffer buf=(ByteBuffer)key.attachment();
                            byte[] bufByte=buf.array();

                            byte pogodaka=0;
                            for (int i=0;i<7;i++){
                                if(bufByte[i]==bufOfRandoms[i]){
                                    pogodaka++;
                                }
                            }

                            buf.clear();
                            buf.put(pogodaka);
                            client.write(buf);

                            buf.flip();
                        }
                    } catch (IOException e){
                        key.cancel();

                        try {
                            key.channel().close();
                        } catch (IOException ex){
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.io.*;
import java.net.*;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

class Task1Main {

    private static String putanja = "FILE:///home/ispit/Desktop/tests/urls.txt";

    public static void main(String[] args) {

        URL putanjaUrl = null;
        try {
            putanjaUrl = new URL(putanja);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try(BufferedReader in = new BufferedReader(new InputStreamReader(putanjaUrl.openStream()))){
            List<String> linijee = in.lines()
                    // filter protokola i preskakanje onih koji imaju postavljen nepodrazumevani port ???
                    .filter((linija)->{
                        try {
                            String urlStr = linija.split("\\[")[3].replace(']',' ').trim();
                            URL tmpUrl = new URL(urlStr);
                                    // protokol koji se trazi            i preskoci onaj kome je postavljen nedefault => znaci uzmi one kojima je -1
                            return (tmpUrl.getProtocol().equals("http") || tmpUrl.getProtocol().equals("https")) && (tmpUrl.getPort() == -1);
                        } catch (MalformedURLException e) {
//                            System.out.println(e.getLocalizedMessage() + " -> "+ linija);
                            return false;
                        }
                    })
                    // filter protokola prosti
//                    .filter( (linija) -> linija.contains("https") || linija.contains("http") ) // prosto bez provere urla
                    // filter vremena
                    .filter((linija) -> {
                        String datum = linija.split("\\[")[1].replace(']',' ').trim();
                        SimpleDateFormat formater = new SimpleDateFormat("dd.mm.yyyy HH:MM:SS");
                        Date datumLoga;
                        try {
                            datumLoga = formater.parse(datum);
                        } catch (ParseException e) {
                            formater.applyPattern("dd/mm/yyyy HH:MM:SS");
                            try {
                                datumLoga = formater.parse(datum);
                            } catch (ParseException ex) {
                                ex.printStackTrace();
                                System.out.println("nece biti ukljucen ne moze da parsira datum -> "+ linija);
                                return false;
                            }
                        }
                        return datumLoga.before(Calendar.getInstance().getTime());
                    })
                    // mapiranje ispisa
                    .map((linija)->{
                        String[] delovi = linija.split("\\["); // 0 index se ne racuna jer je u pitanju prazan string
                        int verzija = 0;
                        if(delovi[2].contains(":")){
                            verzija = 4;
                        }
                        if(delovi[2].contains(".")){
                            verzija = 6;
                        }
                        String urlStr = linija.split("\\[")[3].replace(']',' ').trim();
                        String protocol = "-", putanja = "-";
                        try {
                            URL url = new URL(urlStr);
                            protocol = url.getProtocol();
                            putanja = url.getPath();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                        return "v"+verzija+":"+protocol+":"+putanja;
                    })
                    // sakupljanje
                    .collect(Collectors.toList());
            // NAPOMENA sve je to tehnicki moglo u jedan filter, ostavila sam ovako da bi se iole razdvojili delovi funkcionalnosti
            // ako ostane vremena prebacicu sve u jedan
            for(String linija : linijee){
                System.out.println(linija);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

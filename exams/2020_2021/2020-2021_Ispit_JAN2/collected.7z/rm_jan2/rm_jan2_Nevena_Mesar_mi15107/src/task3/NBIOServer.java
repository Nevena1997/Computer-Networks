package task3;

class NBIOServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {


    }

}

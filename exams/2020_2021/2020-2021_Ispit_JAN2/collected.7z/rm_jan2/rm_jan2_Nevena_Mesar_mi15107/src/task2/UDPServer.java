package task2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.stream.Collectors;

class UDPServer {

    public final static int PORT = 12345;
    public final static int BUF_LEN = 1024;

    private static String transformString(String toTransform){
        if(toTransform == null){
            return null;
        }
        StringBuilder transformed = new StringBuilder("");

        for (char c : toTransform.toCharArray()){
            if(Character.isLowerCase(c)){
                transformed.append(Character.toUpperCase(c));
            }
            else if(Character.isUpperCase(c)){
                transformed.append(Character.toLowerCase(c));
                transformed.append(Character.toLowerCase(c));
            }
            else if(Character.isDigit(c)){
                transformed.append("..");
            }
            else {
                transformed.append(c);
            }
        }
        return transformed.toString();
    }

    private static String bytesToString(byte[] bytes){
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(bytes)))){
            return in.lines().collect(Collectors.joining());
        } catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
//        System.out.println(transformString("mReze Ispit 2"));

        try (DatagramSocket socket = new DatagramSocket(PORT)){
//            socket.setReceiveBufferSize(); // moze da se iskoristi nekako da se ne koristi onako staticka promenljiva
            byte[] buffer = new byte[BUF_LEN];
            DatagramPacket packet = new DatagramPacket(buffer, BUF_LEN);
            socket.receive(packet);
            byte[] data = packet.getData();

            String transformedMsg = transformString(bytesToString(data));
            if(transformedMsg == null){
                transformedMsg = "sipak";
            }
            DatagramPacket packetToSend = new DatagramPacket(transformedMsg.getBytes(), transformedMsg.getBytes().length, packet.getAddress(), packet.getPort());
            socket.send(packetToSend);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

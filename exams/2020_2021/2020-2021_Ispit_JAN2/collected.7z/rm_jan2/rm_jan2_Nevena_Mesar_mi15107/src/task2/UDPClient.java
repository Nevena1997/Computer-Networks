package task2;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;
import java.util.stream.Collectors;

import static task2.UDPServer.BUF_LEN;
import static task2.UDPServer.PORT;

class UDPClient {

    private static String bytesToString(byte[] bytes){
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(bytes)))){
            return in.readLine().trim();
        } catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        String msg = "";
        do {
            Scanner scIn = new Scanner(System.in);
            System.out.println("Unesite nisku koju zelite da server transformise: ");
            if (scIn.hasNextLine()) {
                msg = scIn.nextLine();
            }
            scIn.close();
            if(msg.getBytes().length > BUF_LEN){
                System.out.println("preduga poruka, skrati je :(");
            }
        } while(msg.getBytes().length > BUF_LEN);

        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            DatagramPacket paket = new DatagramPacket(msg.getBytes(), msg.getBytes().length, socket.getLocalAddress(), PORT);
            socket.send(paket);
            byte[] buff = new byte[BUF_LEN];
            DatagramPacket answer = new DatagramPacket(buff, BUF_LEN);
            socket.receive(answer);
            String transformed = bytesToString(answer.getData());
            System.out.println(transformed);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(socket!= null){
            socket.close();
        }
    }

}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UDPServer {
    public static final String HOSTNAME = "localhost";
    public static final int DEFAULT_PORT = 12345;
    public static final int BUF_SIZE = 1024;

    public static void main(String[] args) {
        var server = new UDPServer();
        server.execute();
    }

    UDPServer() {}

    private void execute() {
        try (var server = new DatagramSocket(DEFAULT_PORT)) {
            System.err.println("UDP Server listening on port " + DEFAULT_PORT + " ...");

            while (true) {
                // Receive request (message) from client
                byte[] requestBuf = new byte[BUF_SIZE];
                var request = new DatagramPacket(requestBuf, requestBuf.length);
                server.receive(request);

                // Parse request as a String
                String requestMessage = new String(request.getData(), 0, request.getLength());
                System.err.println("Received from client: " + requestMessage);

                // Transform request message
                String requestMessageTransformed = this.transform(requestMessage);
                System.err.println("Transformed message: " + requestMessageTransformed);

                // Send transformed request message back to client
                var response = new DatagramPacket(
                        requestMessageTransformed.getBytes(),
                        requestMessageTransformed.length(),
                        request.getAddress(),
                        request.getPort()
                );
                System.err.println("Sending transformed message to client ...");
                server.send(response);
                System.err.println("Client served successfully.");
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String transform(String message) {
        StringBuilder transformed = new StringBuilder();

        message.chars()
                .forEach(ch -> {
                    char c = (char) ch;
                    if (Character.isUpperCase(c)) {
                        char lower = Character.toLowerCase(c);
                        transformed.append(lower).append(lower);
                    } else if (Character.isLowerCase(c)) {
                        char upper = Character.toUpperCase(c);
                        transformed.append(upper);
                    } else if (Character.isDigit(c)) {
                        transformed.append("..");
                    } else {
                        transformed.append(c);
                    }
                });

        return transformed.toString();
    }

}

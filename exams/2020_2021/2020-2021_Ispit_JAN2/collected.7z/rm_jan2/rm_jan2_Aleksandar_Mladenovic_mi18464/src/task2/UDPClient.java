package task2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) throws UnknownHostException {
        var client = new UDPClient(UDPServer.HOSTNAME, UDPServer.DEFAULT_PORT);
        client.execute();
    }

    private static final int BUF_SIZE = 1024;

    private final InetAddress host;
    private final int port;

    UDPClient(String hostname, int port) throws UnknownHostException {
        this.host = InetAddress.getByName(hostname);
        this.port = port;
    }

    private void execute() {
        try (var client = new DatagramSocket();
             var stdin = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.err.println("Unesite nisku:");
            String input = stdin.readLine();

            var request = new DatagramPacket(input.getBytes(), input.length(), host, port);
            client.send(request);

            byte[] responseBuf = new byte[BUF_SIZE];
            var response = new DatagramPacket(responseBuf, responseBuf.length);
            client.receive(response);

            System.err.println("Received from server:");
            String responseParsed = new String(response.getData(), 0, response.getLength());
            System.out.println(responseParsed);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Arrays;

class NBIOClient {
    
    public static void main(String[] args) {
        var client = new NBIOClient(NBIOServer.HOSTNAME, NBIOServer.DEFAULT_PORT);
        client.execute();
    }

    private final InetSocketAddress serverAddress;

    NBIOClient(String hostname, int port) {
        this.serverAddress = new InetSocketAddress(hostname, port);
    }

    private void execute() {
        try (var client = SocketChannel.open(this.serverAddress);
             var stdin = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.print("Unesite Loto kombinaciju (7 razlicitih brojeva u opsegu 1-39): ");
            String combination = stdin.readLine();

            var numbers = getNumbersAsInts(combination);
            System.out.println("Parsed array of numbers: " + Arrays.toString(numbers));

//            // Allocate 1 byte for each number (1 byte is enough for number is range 1-39)
//            var buf = ByteBuffer.allocate(7);
//            buf.put(numbers);

            // Allocate size for 7 integers and fill buffer with parsed numbers
            var buf = ByteBuffer.allocate(7 * 4);
            for (var number : numbers) {
                buf.putInt(number);
            }

            // Prepare buffer for writing
            buf.flip();

            // Write to server until all bytes are sent
            System.err.println("Sending combination to server ...");
            while (buf.hasRemaining()) {
                client.write(buf);
            }

            System.err.print("Sanity check what is in the buffer: ");
            this.checkBufferIntData(buf);

            // Now prepare buffer for reading
//            buf.clear();

            System.err.println("Ready to receive server response ...");
            while (buf.hasRemaining()) {
                client.read(buf);
            }

            // Prepare buffer for reading and get number of hits (integer)
            buf.rewind();
            System.out.println("Number of hits: " + buf.getInt());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private byte[] getNumbersAsBytes(String combinationInput) {
//        return Arrays.stream(combinationInput.trim().split(" "))
//                .map(s -> Integer.valueOf(s))
//                .
        var strNumbers = combinationInput.trim().split(" ");
        byte[] numbers = new byte[7];

        for (int i = 0; i < 7; i++) {
            numbers[i] = Byte.valueOf(strNumbers[i]);
        }

        return numbers;
    }

    private int[] getNumbersAsInts(String combinationInput) {
        var strNumbers = combinationInput.trim().split(" ");
        int[] numbers = new int[7];

        for (int i = 0; i < 7; i++) {
            numbers[i] = Integer.valueOf(strNumbers[i]);
        }

        return numbers;
    }

    private void checkBufferByteData(ByteBuffer buf) {
        var data = buf.array();
        System.err.print("[");
        for (int i = 0; i < data.length; i++) {
            System.err.print(data[i]);
            if (i < data.length - 1) {
                System.err.print(" ");
            }
        }
        System.err.println("]");
    }

    private void checkBufferIntData(ByteBuffer buf) {
        buf.flip();

        System.err.print("[ ");
        while (buf.hasRemaining()) {
            var number = buf.getInt();
            System.err.print(number + " ");
        }

        buf.clear();
        System.err.println("]");
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

class NBIOServer {
    public static final String HOSTNAME = "localhost";
    public static final int DEFAULT_PORT = 12345;
    public static final int BUF_SIZE = 7 * 4;

    public static void main(String[] args) {
        var server = new NBIOServer();
        server.execute();
    }

    Map<String, Integer> clientHits;

    NBIOServer() {
        this.clientHits = new HashMap<>();
    }

    private void execute() {
        try (var serverChannel = ServerSocketChannel.open();
             var selector = Selector.open()
        ) {
            // Configure non-blocking server
            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);

            // Prepare server to accept clients
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);
            System.err.println("Server listening on port " + DEFAULT_PORT + " ...");

            System.err.println("Generating combination ...");
            var serverCombination = this.generateCombination();
            System.err.println("Generated combination: " + serverCombination);

            while (true) {
                selector.select();
                var readyKeys = selector.selectedKeys();
                var it = readyKeys.iterator();

                while (it.hasNext()) {
                    var key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            // Accept clients
                            var server = (ServerSocketChannel) key.channel();
                            var client = server.accept();
                            client.configureBlocking(false);
                            System.err.println("Accepted client at " + client.getRemoteAddress().toString());

                            // Save client in map
                            this.clientHits.put(client.getRemoteAddress().toString(), 0);

                            // Prepare server channel to read client's request
                            var clientKey = client.register(selector, SelectionKey.OP_READ);

                            // Create buffer for this client and prepare server for reading
                            var buf = ByteBuffer.allocate(BUF_SIZE);
                            clientKey.attach(buf);
                        } else if (key.isReadable()) {
                            // Read request from clients
                            var client = (SocketChannel) key.channel();

                            // Get client's corresponding buffer
                            var buf = (ByteBuffer) key.attachment();

                            // Read buffer data
                            System.err.println("Reading from client ...");
                            client.read(buf);

                            if (!buf.hasRemaining()) {
                                System.err.println("Successfully read all numbers ...");
                                // Reset buffer pos and read all ints recieved
                                buf.rewind();

                                for (int i = 0; i < 7; i++) {
                                    var number = buf.getInt();
                                    System.out.println(number);

                                    // Check if this client has guessed this number correctly
                                    if (serverCombination.contains(number)) {
                                        // Increase hits for this client
                                        this.clientHits.put(
                                                client.getRemoteAddress().toString(),
                                                this.clientHits.get(client.getRemoteAddress().toString()) + 1
                                        );
                                    }
                                }

                                //

                                System.err.println("Preparing buffer for writing ...");
                                // Prepare buffer for writing
                                buf.clear();

                                // Put in the number of hits for this client
                                int hits = this.clientHits.get(client.getRemoteAddress().toString());
                                buf.putInt(hits);

                                // Again, prepare buffer for reading
                                buf.flip();

                                key.interestOps(SelectionKey.OP_WRITE);
                            }

                            // STARA IMPLEMENTACIJA SA BAJTOVIMA
//                            if (buf.position() == 6 || !buf.hasRemaining()) {
//                                // We have read entire request, now process data
//                                String combination = new String(buf.array(), 0, buf.limit());
//                                System.out.println("Server received combination: " + combination);
//
//                                // Prepare buffer for new data (pos -> 0, limit -> capacity)
//                                buf.clear();
//
//                                // Prepare server for writing to client
//                                key.interestOps(SelectionKey.OP_WRITE);
//                            }
                        } else if (key.isWritable()) {
//                            System.err.println("Writing to client ...");
                            // Write response to clients
                            var client = (SocketChannel) key.channel();

                            // Get client's corresponding buffer
                            var buf = (ByteBuffer) key.attachment();
                            client.write(buf);

//                            if (!buf.hasRemaining()) {
////                                buf.flip();
//                                client.close();
//                            }
                            buf.flip();
//
//                            // Retrive client's hits and store it in the buffer
//                            int hits = this.clientHits.get(client.getRemoteAddress().toString());
//                            buf.putInt(hits);
//
//                            // Prepare buffer for writing the number of hits and write
//                            buf.flip();
//                            client.write(buf);
//
//                            // Prepare buffer for reading from client's side
//                            buf.clear();

//                            key.interestOps(SelectionKey.OP_ACCEPT);
                        }
                    } catch (IOException e) {
                        key.cancel();
                        key.channel().close();
                        System.err.println("Closing connection with clientt at : " +
                                ((SocketChannel) key.channel()).getRemoteAddress().toString());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Set<Integer> generateCombination() {
        var rndEngine = new Random();
        Set<Integer> combination = new HashSet<>();

        // Generate 7 random numbers within bounds [1, 39]
        for (int i = 0; i < 7; i++) {
            int rndNumber = rndEngine.nextInt(39) + 1;

            while (combination.contains(rndNumber)) {
                rndNumber = rndEngine.nextInt(39) + 1;
            }

            combination.add(rndNumber);
        }

        return combination;
    }
}

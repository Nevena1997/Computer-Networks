package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.spi.DateFormatProvider;
import java.util.Calendar;
import java.util.Date;
import java.util.spi.CalendarDataProvider;

class Task1Main {
    
    public static void main(String[] args) {

        String pathToFile = System.getProperty("user.home") + "/Desktop/tests/urls.txt";

        try {
            URL url = new URL("file://" + pathToFile);

            URLConnection connection = url.openConnection();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            connection.getInputStream()
                    )
            );

            String line;

            while ((line = in.readLine()) != null) {

                String[] parts = line.split("]");

                String date = parts[0].substring(1);
                String ipAddress = parts[1].substring((1));
                String urlServer = parts[2].substring(1);

                if (isProtocolHttpOrHttps(urlServer) && noPort(urlServer)) {
                    if ((new Date().after(new Date(date)))) {
                        String formattedString = formatString(ipAddress, urlServer);
                        System.out.println(formattedString);
                    }
                }

            }

            in.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static boolean noPort(String urlServer) {
        return urlServer.substring(urlServer.indexOf('/')).indexOf(':') == -1;
    }

    private static String formatString(String ipAddress, String urlServer) throws MalformedURLException {
        int ipAddressVersion = ipAddress.contains(".") ? 4 : 6;
        URL url = new URL(urlServer);

        StringBuilder sb = new StringBuilder("");
        sb.append("v");
        sb.append(ipAddressVersion);
        sb.append(":");
        sb.append(url.getProtocol());
        sb.append(":");
        sb.append(url.getPath());

        return sb.toString();
    }

    private static boolean isProtocolHttpOrHttps(String urlServer) {
        try {
            URL url = new URL(urlServer);

            if (url.getProtocol().equalsIgnoreCase("http") || url.getProtocol().equalsIgnoreCase("https")) {
                return true;
            }
            else {
                return false;
            }

        } catch (MalformedURLException e) {
            return false;
        }

    }

}

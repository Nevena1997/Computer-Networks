package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            String line = sc.nextLine();

            DatagramPacket request = new DatagramPacket(
                    line.getBytes(),
                    line.getBytes().length,
                    InetAddress.getByName("localhost"),
                    12345
            );

            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[1024], 1024);

            client.receive(response);

            System.out.println(new String(response.getData(), 0, response.getLength()));

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package task2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPServer {
    
    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(12345)) {

            while (true) {
                DatagramPacket request = new DatagramPacket(new byte[1024], 1024);

                server.receive(request);

                String sentByClient = new String(request.getData(), 0, request.getLength());

                String transformedData = encode(sentByClient);

                DatagramPacket response = new DatagramPacket(
                        transformedData.getBytes(),
                        transformedData.getBytes().length,
                        request.getAddress(),
                        request.getPort()
                );

                server.send(response);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static String encode(String sentByClient) {
        StringBuilder codedString = new StringBuilder();

        for (char c : sentByClient.toCharArray()) {
            if (Character.isUpperCase(c)) {
                codedString.append(Character.toLowerCase(c));
                codedString.append(Character.toLowerCase(c));
            }
            else if (Character.isLowerCase(c)) {
                codedString.append(Character.toUpperCase(c));
            }
            else if (Character.isDigit(c)) {
                codedString.append("..");
            } else {
                codedString.append(c);
            }
        }

        return codedString.toString();
    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Random;

class NBIOServer {
    
    public static void main(String[] args) {

        int[] realCombination = generateCombination();
        int numberOfHits = 0;

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            serverChannel.bind(new InetSocketAddress(12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    if (key.isAcceptable()) {

                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);

                        client.register(selector, SelectionKey.OP_READ);

                    } else if (key.isWritable()) {

                        SocketChannel client = (SocketChannel) key.channel();

                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        if (buffer == null) {
                            buffer = ByteBuffer.allocate(1024);
                        }

                        buffer.put(String.valueOf(numberOfHits).getBytes());

                        buffer.flip();

                        client.write(buffer);

                        client.close();


                    } else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();

                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        if (buffer == null) {
                            buffer = ByteBuffer.allocate(1024);
                        }

                        client.read(buffer);

                        buffer.rewind();

                        String clientCombinationString = StandardCharsets.UTF_8.decode(buffer).toString().trim();

                        int[] clientCombination = getClientCombination(clientCombinationString);

                        numberOfHits = checkClientCombination(realCombination, clientCombination);

                        key.interestOps(SelectionKey.OP_WRITE);
                    }
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static int checkClientCombination(int[] realCombination, int[] clientCombination) {
        int guesses = 0;

        for (int i : clientCombination) {
            if (hasNumber(realCombination, i)) {
                guesses++;
            }
        }
        return guesses;
    }

    private static int[] getClientCombination(String clientCombinationString) {
        String[] parts = clientCombinationString.split(" ");
        int[] clientCombination = new int[7];

        for (int i = 0; i < 7; i++) {
            clientCombination[i] = Integer.parseInt(parts[i]);
        }
        return clientCombination;
    }

    private static int[] generateCombination() {
        int[] combination = new int[7];
        Random random = new Random();
        for (int i = 0; i < 7; i++) {
            int randomNumber = random.nextInt(38)+1;
            while (hasNumber(combination, randomNumber)) {
                randomNumber = random.nextInt(38)+1;
            }
            combination[i] = randomNumber;
        }
        return combination;
    }

    private static boolean hasNumber(int[] combination, int randomNumber) {
        for (int i : combination) {
            if (i == randomNumber)
                return true;
        }
        return false;
    }

}

package task3;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class NBIOClient {
    
    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", 12345);
             Scanner sc = new Scanner(System.in)) {
            int[] combination = new int[7];

            for (int i = 0; i < 7; i++) {
                combination[i] = sc.nextInt();
            }

            String transformedData = transformToString(combination);

            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream()
                    )
            );

            out.write(transformedData);
            out.newLine();
            out.flush();

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            );

            String line;

            while ((line = in.readLine()) != null) {
                System.out.println(line.trim());
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static String transformToString(int[] combination) {
        String data = "";

        for (int i : combination) {
            data += i;
            data += " ";
        }

        return data;
    }

    private static boolean hasNumber(int[] combination, int randomNumber) {
        for (int i : combination) {
            if (i == randomNumber)
                return true;
        }
        return false;
    }

}

package task3;

class NBIOClient {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + NBIOClient.class.getName());
    }

}

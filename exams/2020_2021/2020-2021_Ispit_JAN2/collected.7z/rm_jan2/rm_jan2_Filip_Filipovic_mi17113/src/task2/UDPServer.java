package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

class UDPServer {
    private DatagramSocket datagramSocket;

    public static void main(String[] args) {
        UDPServer server = new UDPServer(12345);
        server.execute();
    }

    public UDPServer(int port) {
        try {
            this.datagramSocket = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }



    private void execute() {
        try {
            while (true) {
                byte[] toRecive = new byte[512];
                DatagramPacket req = new DatagramPacket(toRecive, toRecive.length);
                this.datagramSocket.receive(req);
                String originalnaNiska = new String(toRecive, 0, req.getLength(), StandardCharsets.UTF_8);

                String transformisanaNiska = transformisiNisku(originalnaNiska);
                System.out.printf(transformisanaNiska);
                byte[] toSend = transformisanaNiska.getBytes(StandardCharsets.UTF_8);
                DatagramPacket res = new DatagramPacket(toSend, toSend.length, req.getAddress(), req.getPort());
                this.datagramSocket.send(res);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            this.datagramSocket.close();
        }
    }

    private String transformisiNisku(String niska) {
        return niska
            .chars()
            .mapToObj(Character::toString)
            .map(UDPServer::transformisiKarakter)
            .collect(Collectors.joining(""))
            ;
    }

    private static String transformisiKarakter(String karakterKaoString) {
        char karakter = karakterKaoString.charAt(0);
        String rezultat;
        if (Character.isUpperCase(karakter)) {
            String maloSlovoKaoString = Character.toString(Character.toLowerCase(karakter));
            rezultat = maloSlovoKaoString + maloSlovoKaoString;
        } else if (Character.isLowerCase(karakter)) {
            rezultat = Character.toString(Character.toUpperCase(karakter));
        } else if (Character.isDigit(karakter)) {
            rezultat = "..";
        } else {
            rezultat = karakterKaoString;
        }
        return rezultat;
    }
}

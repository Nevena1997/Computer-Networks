package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try (
            DatagramSocket datagramSocket = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ) {
            System.out.print("Usesite nisku: ");
            String userInput = sc.nextLine();
            byte[] toSend = userInput.getBytes(StandardCharsets.UTF_8);
            InetAddress host = InetAddress.getLocalHost();
            DatagramPacket req = new DatagramPacket(toSend, toSend.length, host, 12345);
            datagramSocket.send(req);

            byte[] toRecive = new byte[512];
            DatagramPacket res = new DatagramPacket(toRecive, toRecive.length);
            datagramSocket.receive(res);
            String odgovorServera = new String(toRecive, 0, res.getLength(), StandardCharsets.UTF_8);
            System.out.println("Transformisana niska: " + odgovorServera);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

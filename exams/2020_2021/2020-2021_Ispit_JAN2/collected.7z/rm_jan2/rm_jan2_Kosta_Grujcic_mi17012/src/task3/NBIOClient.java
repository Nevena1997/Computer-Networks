package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

class NBIOClient {

    public static void main(String[] args) {
        NBIOClient client = new NBIOClient("localhost", 12345);
        client.start();
    }

    private static final int BUFFER_SIZE = 14;

    private List<Integer> ticket;
    private String rawTicket;
    private final String hostname;
    private final int port;

    public NBIOClient(String hostname, int port) {
        this.hostname = hostname;
        this.port = port;

        ticket = new ArrayList<>();
    }

    private void parseTicket() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < 7; i++) {
            int x = ticket.get(i);

            String rawX = null;
            if (x < 10) {
                rawX = "0" + x;
            } else {
                rawX = Integer.toString(x);
            }
            sb.append(rawX);
        }

        rawTicket = sb.toString();
    }

    public void start() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Insert 7 numbers in range [1, 39]:");
            for (int i = 0; i < 7; i++) {
                int x = sc.nextInt();
                while (x < 1 || x > 39) {
                    System.out.println("Invalid input. Range is [1, 39]!");
                    x = sc.nextInt();
                }
                ticket.add(x);
            }
        }
        parseTicket();

        try (SocketChannel socket = SocketChannel.open(new InetSocketAddress(hostname, port))) {
            socket.configureBlocking(true);
            ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
            buffer.put(rawTicket.getBytes());
            buffer.clear();

            while (buffer.hasRemaining()) {
                socket.write(buffer);
            }

            buffer.clear();
            socket.read(buffer);
            buffer.rewind();
            byte[] rawHits = new byte[1];
            buffer.get(rawHits);
            String hits = new String(rawHits, 0, 1, StandardCharsets.US_ASCII);
            System.out.println("Number of hits: " + hits);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

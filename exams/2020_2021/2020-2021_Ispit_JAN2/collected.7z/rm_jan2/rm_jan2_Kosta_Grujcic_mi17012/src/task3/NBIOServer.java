package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

class NBIOServer {

    public static void main(String[] args) {
        NBIOServer server = new NBIOServer(12345);
        server.start();
    }

    private static final int BUFFER_SIZE = 14;

    private final int port;
    private List<Integer> winningTicket;

    public NBIOServer(int port) {
        this.port = port;
        winningTicket = new ArrayList<>();
    }

    private void generateTicket() {
        for (int i = 0; i < 7; i++) {
            int x = ThreadLocalRandom.current().nextInt(1, 40);
            while (winningTicket.contains(x)) {
                x = ThreadLocalRandom.current().nextInt(1, 40);
            }

            winningTicket.add(x);
        }
    }

    private List<Integer> parseTicket(ByteBuffer src) {
        src.rewind();
        byte[] buffer = new byte[BUFFER_SIZE];
        src.get(buffer);
        String s = new String(buffer, 0, buffer.length, StandardCharsets.US_ASCII);
        src.clear();

        List<Integer> ticket = new ArrayList<>();
        for (int i = 0; i <= BUFFER_SIZE - 2; i += 2) {
            String rawValue = s.substring(i, i + 2);
            ticket.add(Integer.parseInt(rawValue));
        }

        return ticket;
    }

    private String numberOfHits(List<Integer> ticket) {
        int hits = 0;

        // Server intentionally sends zero hits in case duplicates exist
        Set<Integer> uniques = new HashSet<>();
        for (Integer value : ticket) {
            if (uniques.contains(value)) {
                return "0";
            }

            uniques.add(value);
        }

        for (Integer value : ticket) {
            if (winningTicket.contains(value)) {
                hits++;
            }
        }

        return Integer.toString(hits);
    }

    public void start() {
        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            serverChannel.bind(new InetSocketAddress(port));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);
            System.out.println("server started");

            generateTicket();
            System.out.println("Winning ticket is: " + Arrays.toString(winningTicket.toArray()));

            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
                            clientKey.attach(buffer);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buffer = (ByteBuffer)key.attachment();

                            if (buffer.position() == buffer.capacity()) {
                                List<Integer> ticket = parseTicket(buffer);
                                String hits = numberOfHits(ticket);
                                buffer.clear();
                                buffer.put(hits.getBytes());
                                buffer.flip();
                                client.write(buffer);
                            }
                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buffer = (ByteBuffer)key.attachment();

                            if (!buffer.hasRemaining()) {
                                key.interestOps(SelectionKey.OP_WRITE);
                            } else {
                                client.read(buffer);

                                if (!buffer.hasRemaining()) {
                                    key.interestOps(SelectionKey.OP_WRITE);
                                }
                            }
                        }
                    } catch (IOException e) {
                        key.cancel();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("servet shutdown");
        }
    }
}

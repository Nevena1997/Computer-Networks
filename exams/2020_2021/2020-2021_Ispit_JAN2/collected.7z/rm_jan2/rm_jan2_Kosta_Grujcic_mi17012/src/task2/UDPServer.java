package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

class UDPServer implements AutoCloseable {

    public static void main(String[] args) {
        try (UDPServer server = new UDPServer(12345)) {
            server.start();
        } catch (IOException e) {
            System.err.println("Fatal error with server");
        }
    }

    private static final int BUFFER_SIZE = 128;

    private DatagramSocket socket;

    public UDPServer(int port) throws IOException  {
        socket = new DatagramSocket(port);
        System.out.println("server started");
    }

    private String transform(String msg) {
        StringBuilder sb = new StringBuilder();

        char[] chs = msg.toCharArray();
        for (char ch : chs) {
            if (Character.isUpperCase(ch)) {
                sb.append(Character.toLowerCase(ch));
                sb.append(Character.toLowerCase(ch));
            } else if (Character.isLowerCase(ch)) {
                sb.append(Character.toUpperCase(ch));
            } else if (Character.isDigit(ch)) {
                sb.append("..");
            } else {
                sb.append(ch);
            }
        }

        return sb.toString();
    }

    public void start() {
        while (true) {
            try {
                // receiving
                byte[] buffer = new byte[BUFFER_SIZE];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                socket.receive(request);
                String msg = new String(buffer, 0, request.getLength(), StandardCharsets.UTF_8);

                // transformation
                String msgTransformed = transform(msg);

                // sending
                buffer = msgTransformed.getBytes();
                DatagramPacket response = new DatagramPacket(buffer, 0, buffer.length, request.getAddress(), request.getPort());
                socket.send(response);
            } catch (IOException e) {
                System.err.println("problem occurred");
            }
        }
    }

    @Override
    public void close() {
        socket.close();
        System.out.println("server shutdown");
    }
}

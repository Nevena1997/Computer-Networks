package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient implements AutoCloseable {

    public static void main(String[] args) {
        try (UDPClient client = new UDPClient("localhost", 12345);
             Scanner sc = new Scanner(System.in)) {
            client.send(sc.nextLine());
            client.receive();
        } catch (IOException e) {
            System.out.println("Fatal error with client");
        }
    }

    private static final int BUFFER_SIZE = 128;

    private DatagramSocket socket;
    private final InetAddress addr;
    private final int port;

    public UDPClient(String hostname, int port) throws IOException {
        this.port = port;

        addr = InetAddress.getByName(hostname);
        socket = new DatagramSocket();
    }

    public void receive() throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        DatagramPacket response = new DatagramPacket(buffer, buffer.length);
        socket.receive(response);

        String msg = new String(buffer, 0, response.getLength(), StandardCharsets.UTF_8);
        System.out.println(msg);
    }

    public void send(String forSend) throws IOException {
        byte[] buffer = forSend.getBytes();
        DatagramPacket request = new DatagramPacket(buffer, 0, buffer.length, addr, port);
        socket.send(request);
    }

    @Override
    public void close() {
        socket.close();
    }
}

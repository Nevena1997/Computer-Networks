package task1;

import java.io.*;
import java.net.*;
import java.util.*;

class Task1Main {

    private static URLConnection establishConnection(String path) throws IOException {
        File f = new File(path);
        String fullPath = f.getAbsolutePath();
        URL u = new URL("file://" + fullPath);

        return u.openConnection();
    }

    private static List<String> filterHTTP(List<String> content) {
        List<String> filtered = new ArrayList<>();
        for (String line : content) {
            String s = line.toLowerCase();

            if (s.contains("http://") || s.contains("https://")) {
                filtered.add(s);
            }
        }

        return filtered;
    }

    private static List<String> filterByTime(List<String> content) {
        List<String> filtered = new ArrayList<>();
        Date curr = new Date();

        for (String line : content) {
            int pos1 = line.indexOf('[') + 1;
            int pos2 = line.indexOf(']');
            String s = line.substring(pos1, pos2);

            // Vidim da je deprecated, ali radio posao :D
            Date d = new Date(s);
            if (d.before(curr)) {
                filtered.add(line);
            }
        }

        return filtered;
    }

    private static String fetchIP(String line) {
        int pos1 = line.indexOf('[');
        pos1 = line.indexOf('[', pos1 + 1) + 1;
        int pos2 = line.indexOf(']', pos1);

        return line.substring(pos1, pos2);
    }

    private static String fetchURL(String line) {
        int pos = line.indexOf('[');
        pos = line.indexOf('[', pos + 1);
        pos = line.indexOf('[', pos + 1);

        return line.substring(pos + 1, line.length() - 1);
    }

    private static void printContent(List<String> content) {
        for (String line : content) {
            String rawURL = fetchURL(line);
            String rawIP = fetchIP(line);

            try {
                URL u = new URL(rawURL);
                InetAddress addr = InetAddress.getByName(rawIP);

                int version = 6;
                if (addr instanceof Inet4Address) {
                    version = 4;
                }

                System.out.println("v" + version + ":" + u.getProtocol() + ":" + u.getPath());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
        }
    }

    private static List<String> parseInput(InputStream is) throws IOException {
        List<String> content = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                content.add(line);
            }
        }

        return content;
    }

    private static List<String> filterByPort(List<String> content) {
        List<String> filtered = new ArrayList<>();
        for (String line : content) {
            int pos = line.indexOf('[');
            pos = line.indexOf('[', pos + 1);
            pos = line.indexOf('[', pos + 1);
            String src = line.substring(pos + 1, line.length() - 1);

            try {
                URL u = new URL(src);
                int port = u.getPort();

                if (port == -1 || port == u.getDefaultPort()) {
                    filtered.add(line);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }

        return filtered;
    }
    
    public static void main(String[] args) {
        try {
            String path = "/home/ispit/Desktop/tests/urls.txt";
            URLConnection conn = establishConnection(path);

            List<String> content = parseInput(conn.getInputStream());

            content = filterHTTP(content);
            content = filterByTime(content);
            content = filterByPort(content);

            printContent(content);
        } catch (IOException e) {
            System.err.println("Problem with I/O");
        }
    }
}

package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class NBIOClient {

    private final int port;
    private InetSocketAddress address;
    public NBIOClient(String localhost, int i) {
        port = i;
        address = new InetSocketAddress(port);
    }

    public static void main(String[] args) {


        System.out.println("Hello from: " + NBIOClient.class.getName());

        NBIOClient client = new NBIOClient("localhost",12345);
        client.execute();
    }

    private void execute() {

        try(SocketChannel socket = SocketChannel.open(address);
            Scanner sc = new Scanner(System.in)) {

            ByteBuffer buf = ByteBuffer.allocate(28);

            for(int i =0;i <7 ;i++){
                int num = sc.nextInt();
                buf.putInt(num);
            }

            buf.flip();

            while(buf.hasRemaining())
                socket.write(buf);

            ByteBuffer buf1 = ByteBuffer.allocate(4);

            while (buf1.hasRemaining())
                socket.read(buf1);

            //WritableByteChannel out = Channels.newChannel(System.out);
            //out.write(buf1);
            buf1.flip();
            System.out.println(buf1.getInt());

        }
        catch (IOException e){
            e.printStackTrace();
        }


    }

}

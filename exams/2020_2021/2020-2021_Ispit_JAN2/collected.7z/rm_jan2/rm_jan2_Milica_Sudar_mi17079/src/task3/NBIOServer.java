package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

class NBIOServer {
    public static final int PORT = 12345;
    private List<Integer> kombinacija = new ArrayList<>();
    private List<Integer> serverskaKombinacija = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("Hello from: " + NBIOServer.class.getName());
        NBIOServer server = new NBIOServer();
        server.execute();
    }

    private void execute() {
        randomCombination();
        try(ServerSocketChannel serverSocket = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            serverSocket.bind(new InetSocketAddress(PORT));
            serverSocket.configureBlocking(false);
            serverSocket.register(selector, SelectionKey.OP_ACCEPT);


            while (true){

                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> it = keys.iterator();

                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    if(key.isAcceptable()){
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        System.err.println("Klijent prihvacen");
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        client.register(selector,SelectionKey.OP_READ);




                    }
                    else if(key.isReadable()){
                        SocketChannel channel = (SocketChannel) key.channel();
                        ByteBuffer buf = (ByteBuffer) key.attachment();
                        if(buf == null){
                            buf = ByteBuffer.allocate(28);
                            key.attach(buf);
                        }

                        channel.read(buf);

                        if(!buf.hasRemaining()){
                            buf.flip();

                            for(int i =0;i<7;i++){
                                kombinacija.add(buf.getInt());
                            }
                            int pogodjeno = checkCombination(kombinacija);
                            buf.clear();
                            buf.putInt(pogodjeno);
                            buf.flip();
                            key.interestOps(SelectionKey.OP_WRITE);
                        }



                    }
                    else if(key.isWritable()){
                        SocketChannel channel = (SocketChannel) key.channel();
                        ByteBuffer buf = (ByteBuffer)key.attachment();

                        channel.write(buf);
                        if(!buf.hasRemaining()){
                            channel.close();
                        }

                    }


                }

            }


        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

    private int checkCombination(List<Integer> kombinacija) {
        int pogodjeno = 0;
        for(int i: kombinacija){
            for(int j:serverskaKombinacija){
                if( i == j)
                    pogodjeno++;
            }
        }
        return pogodjeno;
    }

    private void randomCombination() {
        Random random = new Random();
        int n = 7;
        while (n != 0) {
            int num = random.nextInt(40);
            if (serverskaKombinacija.contains(num))
                continue;
            serverskaKombinacija.add(num);
            n--;
        }
    }

}

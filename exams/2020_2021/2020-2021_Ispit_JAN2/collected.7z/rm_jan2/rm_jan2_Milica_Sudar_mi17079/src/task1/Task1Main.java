package task1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Array;
import java.util.Arrays;

class Task1Main {
    
    public static void main(String[] args) {
        System.out.println("Hello from: " + Task1Main.class.getName());

        Path path = Paths.get("/home/ispit/Desktop/tests/urls.txt");
        String fileProtocol = "file://" + path.toString();
        try {
            URL url = new URL(fileProtocol);
            BufferedReader buf = new BufferedReader(new InputStreamReader(url.openStream()));

            String line;
            while((line = buf.readLine()) != null){
                String[] niz = line.split("]");
                //System.out.println(Arrays.asList(niz));

                String urlString = niz[2].substring(1);
                String adresa = niz[2].substring(1);

                int version;
                if(adresa.contains("."))
                    version = 4;
                else
                    version =6;

                try {
                    URL url1 = new URL(urlString);

                    //if(urlString.startsWith("http") || urlString.startsWith("https"))
                    if (url1.getProtocol().equalsIgnoreCase("http") || url1.getProtocol().equalsIgnoreCase("https")){
                        if(url1.getDefaultPort() == url1.getPort() || (url1.getPort()==-1)) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("v").append(version).append(":").append(url1.getProtocol()).append(":").append(url1.getFile());
                            System.out.println(sb.toString());

                        }


                    }

                }
                catch (MalformedURLException e){
                    //preskacem ako nije postojeci protokol
                }
                finally {
                    buf.close();
                }
            }




        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

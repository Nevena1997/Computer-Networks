package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

class UDPClient {


    private final int PORT;
    private InetAddress address;

    public UDPClient(String localhost, int i) {
        this.PORT = i;
        try {
            address = InetAddress.getByName(localhost);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPClient.class.getName());
        UDPClient client = new UDPClient("localhost",12345);
        client.execute();
    }

    private void execute() {

        try(DatagramSocket soket = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            String line = sc.nextLine();
            byte[] buf = line.getBytes();

            //slanje zahteva
            DatagramPacket request = new DatagramPacket(buf,buf.length,address,PORT);
            soket.send(request);

            //primanje odgvoora
            byte[] buf1 = new byte[128];
            DatagramPacket response = new DatagramPacket(buf1,buf1.length);
            soket.receive(response);

            String res = new String(buf1,0,response.getLength());
            System.out.println(res);


        }
        catch (IOException e ){
            e.printStackTrace();
        }

    }

}

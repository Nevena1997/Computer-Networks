package task2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Arrays;

class UDPServer {

    private static final int PORT = 12345;
    public static void main(String[] args) {

        System.out.println("Hello from: " + UDPServer.class.getName());
        UDPServer server = new UDPServer();
        server.execute();
    }

    private void execute() {

        try(DatagramSocket serverSoket = new DatagramSocket(PORT)){

            while (true){

                byte[] buf = new byte[128];
                DatagramPacket request = new DatagramPacket(buf,buf.length);
                serverSoket.receive(request);

                String niska = new String(buf,0,request.getLength());
                //obradi nisku
                String[] niz = niska.split(" ");
                StringBuilder sb = new StringBuilder();
                for(String s: niz){
                    String novaNiska = obradiNisku(s);
                    sb.append(novaNiska).append(" ");
                }



                byte[] buf1 = sb.toString().getBytes();
                DatagramPacket response = new DatagramPacket(buf1,buf1.length,request.getAddress(),request.getPort());
                serverSoket.send(response);


            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    private String obradiNisku(String s) {

        StringBuilder sb = new StringBuilder();
        s.chars().forEach(c->{
            if(Character.isDigit(c)){
                sb.append("..");
            }
            else if(Character.isUpperCase(c)){
                sb.append((char)Character.toLowerCase(c)).append((char)Character.toLowerCase(c));
            }
            else if(Character.isLowerCase(c)){
                sb.append((char) Character.toUpperCase(c));
            }
            else
                sb.append(c);
        });


        return sb.toString();

    }

}

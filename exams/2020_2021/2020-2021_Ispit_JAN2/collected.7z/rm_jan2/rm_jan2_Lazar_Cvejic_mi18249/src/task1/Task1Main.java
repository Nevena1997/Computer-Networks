package task1;

import java.io.*;
import java.net.*;
import java.util.Date;

class Task1Main {
    private static String fileName = "/home/ispit/Desktop/tests/urls.txt";
    
    public static void main(String[] args) {
        File f = new File(fileName);
        try (BufferedReader rd = new BufferedReader(new InputStreamReader(new FileInputStream(f)))){
            URL u;
            String line;
            while((line = rd.readLine()) != null){
                String[] parts = line.split("]");
                try {
                    u = new URL(parts[2].substring(1));
                    if(!u.getProtocol().equalsIgnoreCase("http") && !u.getProtocol().equalsIgnoreCase("https")){
                        continue;
                    }
                    if ((u.getPort() != u.getDefaultPort()) && (u.getPort() != -1)) {
                        continue;
                    }
                    if(checkDate(parts[0].substring(1))){
                        continue;
                    }

                    String[] path = u.getPath().split(":");

                    System.out.println("v" + checkVersion(parts[1].substring(1)) + ":" + u.getProtocol() + ":" + path[0]);
                } catch (MalformedURLException e){

                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    private static int checkVersion(String addr) {
        if(addr.contains(":"))
            return 6;
        else if(addr.contains("."))
            return 4;
        else return -1;
    }

    private static boolean checkDate(String d){
        String[] parts = d.split(" ");
        String date = parts[0];
        String time = parts[1];

        String[] dateA = date.split("/");
        String[] timeA = time.split(":");

        int day = Integer.parseInt(dateA[0]);
        int month = Integer.parseInt(dateA[1]);
        int year = Integer.parseInt(dateA[2]);

        int hours = Integer.parseInt(timeA[0]);
        int minutes = Integer.parseInt(timeA[1]);
        int seconds = Integer.parseInt(timeA[2]);

        Date current = new Date(System.currentTimeMillis());
        Date given = new Date(year-1900, month-1, day, hours-1, minutes-1, seconds-1);
        return current.compareTo(given) < 0;
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in))
        {
            String line = sc.nextLine();
            byte[] buff1 = line.getBytes(StandardCharsets.UTF_8);
            DatagramPacket req = new DatagramPacket(buff1, 0, buff1.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(req);

            byte[] buff2 = new byte[line.length() * 2];
            DatagramPacket res = new DatagramPacket(buff2, buff2.length);
            client.receive(res);

            String retVal = new String(res.getData(), 0, res.getLength(), StandardCharsets.UTF_8);
            System.out.println(retVal);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

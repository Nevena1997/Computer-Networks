package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

class UDPServer {
    public static int PORT = 12345;
    
    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT)) {
            while (true) {
                byte[] buff1 = new byte[1024];
                DatagramPacket req = new DatagramPacket(buff1, buff1.length);
                server.receive(req);

                String line = new String(req.getData(), 0, req.getLength(), StandardCharsets.UTF_8);
                line = refactoring(line);

                byte[] buff2 = line.getBytes();
                DatagramPacket res = new DatagramPacket(buff2, 0, buff2.length, req.getAddress(), req.getPort());
                server.send(res);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static String refactoring(String line){
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < line.length(); i++){
            char c = line.charAt(i);
            if(c >= 48 && c <=57){
                sb.append("..");
            } else if(c >= 65 && c <=90){
                c += 32;
                sb.append(c);
                sb.append(c);
            } else if(c >= 97 && c <= 122){
                c -= 32;
                sb.append(c);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

}

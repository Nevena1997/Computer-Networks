package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

import static java.lang.Character.*;

class UDPServer {
    
    public static void main(String[] args) {
        DatagramSocket sck = null;

        try {
            sck = new DatagramSocket(12345);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        byte[] buf1 = new byte[1024];
        DatagramPacket pck1 = new DatagramPacket(buf1, 1024);

        try {
            if (sck != null) {
                sck.receive(pck1);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] data = pck1.getData();

        String inputstr = new String(data, StandardCharsets.UTF_8);

        char[] inputchars = inputstr.toCharArray();

        StringBuilder buil = new StringBuilder(2048);

        for (char inputchar : inputchars) {
            if (isLowerCase(inputchar)) {
                buil.append(toUpperCase(inputchar));
            }else if (isUpperCase(inputchar)){
                buil.append(toLowerCase(inputchar));
                buil.append(toLowerCase(inputchar));
            }else if (isDigit(inputchar)){
                buil.append('.');
                buil.append('.');
            }else{
                buil.append(inputchar);
            }
        }

        String outputstr = buil.toString();

        byte[] buf2 = outputstr.getBytes();

        DatagramPacket pck2 = new DatagramPacket(buf2, 0, buf2.length, sck.getInetAddress(), 12345);

        try {
            sck.send(pck2);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

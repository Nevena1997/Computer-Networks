package task2;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

class UDPClient {

    public static void main(String[] args) {
        byte[] buf1 = new byte[1024];
        int readBytes = 0;
        try {
            readBytes = System.in.read(buf1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        DatagramSocket sck = null;

        try {
            sck = new DatagramSocket(12345);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        DatagramPacket pck1 = new DatagramPacket(buf1, 0, readBytes, sck.getInetAddress(), 12345);

        try {
            sck.send(pck1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] buf2 = new byte[2048];
        DatagramPacket pck2 = new DatagramPacket(buf2, 2048);

        try {
            sck.receive(pck2);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String result = null;

        result = new String(pck2.getData(), StandardCharsets.UTF_8);


        System.out.println(result);
    }


}

package task1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

class Task1Main {
    
    public static void main(String[] args){
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("log.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        byte[] buf = new byte[1024];
        String bufstr;

        while(true){
            try {
                if ((fis.read(buf) == -1)) break;
            } catch (IOException e) {
                e.printStackTrace();
            }

            bufstr = new String(buf, StandardCharsets.UTF_8);

            System.out.println(bufstr);
        }


    }

}

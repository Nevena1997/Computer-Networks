package task1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Scanner;

class Task1Main {
    
    public static void main(String[] args) {
        //System.out.println("Hello from: " + Task1Main.class.getName());
        String path;
        path="file:///home/ispit/Desktop/tests/urls.txt";
        BufferedReader reader=null;
        try {
            URL url=new URL(path);

            reader=new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
            ispisiHTTP(reader);

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (reader!=null)
                    reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /*public static void ispisiFile(BufferedReader reader)
    {
        while(true)
        {
            try {
                String s=reader.readLine();
                if (s==null)
                {
                    break;
                }
                System.out.println(s);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }*/
    public static void ispisiHTTP(BufferedReader reader) throws IOException
    {
        while(true)
        {
                String s=reader.readLine();
                if (s==null)
                {
                    break;
                }
                String[] parsirano=s.split("[]]");
                String datum=parsirano[0].substring(1,parsirano[0].length());
                String ip=parsirano[1].substring(1,parsirano[1].length());
                String url=parsirano[2].substring(1,parsirano[2].length());
                if (url.contains("https://") || url.contains("http://"))
                {
                   String verzija="v4";
                   String protokol="http";
                   String pathToRes;
                   if (isV6(ip))
                   {
                       verzija="v6";
                   }
                   if (url.contains("https://"))
                   {
                       protokol="https";
                   }
                   URL temp=new URL(url);

                   pathToRes=temp.getPath();
                   int portPos=pathToRes.indexOf(":");
                   if (portPos>0) {
                       pathToRes=pathToRes.substring(0,portPos);
                   }
                   Date date=new Date(datum);
                   if (date.before(new Date()))
                   {
                       if (temp.getPort()==temp.getDefaultPort())
                       {
                           System.out.println(verzija+":"+protokol+":"+pathToRes);
                       }

                   }

                }
        }
    }
    public static boolean isV6(String ip)
    {
        if (ip.contains(":"))
        {
            return true;
        }
        else{
            return false;
        }
    }

}

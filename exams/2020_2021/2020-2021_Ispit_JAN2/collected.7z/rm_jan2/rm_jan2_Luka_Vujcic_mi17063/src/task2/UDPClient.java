package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class UDPClient {
    private String ip;
    private int port;

    public UDPClient(int port) {
        this.port = port;
    }
    public void start()
    {
        Scanner sc=new Scanner(System.in);
        String niska;
        try (DatagramSocket socket=new DatagramSocket();) {
            niska=sc.nextLine();
            byte[] buffer=niska.getBytes(StandardCharsets.UTF_8);
            DatagramPacket send=new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), this.port);
            socket.send(send);

            byte[] bufferReceive=new byte[2*buffer.length];
            DatagramPacket receive=new DatagramPacket(bufferReceive,bufferReceive.length);
            socket.receive(receive);

            String result=new String(receive.getData(),0,receive.getLength(),StandardCharsets.UTF_8);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        //System.out.println("Hello from: " + UDPClient.class.getName());
        final int port=12345;
        UDPClient client=new UDPClient(port);
        client.start();

    }

}

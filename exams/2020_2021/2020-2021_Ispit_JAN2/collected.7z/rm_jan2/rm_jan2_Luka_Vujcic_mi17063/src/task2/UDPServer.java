package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

class UDPServer {
    private int port;

    public UDPServer(int port) {
        this.port = port;
    }
    public void start()
    {
        final int MAXBUFFER=500;
        try (DatagramSocket socket=new DatagramSocket(this.port);){
            while(true) {
                try{
                    byte[] buffer=new byte[MAXBUFFER];
                    DatagramPacket receive=new DatagramPacket(buffer,buffer.length);
                    socket.receive(receive);
                    String s=new String(receive.getData(),0,receive.getLength(), StandardCharsets.UTF_8);
                    String result=transform(s);
                    byte[] bufferSend=result.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket send=new DatagramPacket(bufferSend,bufferSend.length,receive.getAddress(),receive.getPort());
                    socket.send(send);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String transform(String s)
    {
        StringBuilder sb=new StringBuilder("");
        for (int i=0;i<s.length();i++)
        {
            char c=s.charAt(i);
            if (Character.isUpperCase(c))
            {
                sb.append(Character.toLowerCase(c));
                sb.append(Character.toLowerCase(c));
            }
            else if (Character.isLowerCase(c))
            {
                sb.append(Character.toUpperCase(c));

            }
            else if (Character.isDigit(c))
            {
                sb.append(".");
                sb.append(".");
            }
            else
            {
                sb.append(c);
            }

        }
        return sb.toString();
    }
    public static void main(String[] args) {
        final int port=12345;
        UDPServer server=new UDPServer(port);
        server.start();
        //System.out.println("Hello from: " + UDPServer.class.getName());
    }

}

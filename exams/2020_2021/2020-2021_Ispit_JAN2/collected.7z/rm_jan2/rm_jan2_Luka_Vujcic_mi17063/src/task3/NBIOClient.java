package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Random;

class NBIOClient {
    private String ip;
    private int port;

    public NBIOClient(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }
    int [] getKombinacija()
    {
        int length=7;
        int[] ponovljeni=new int[40];
        Arrays.fill(ponovljeni,0);

        int [] komb=new int [length];
        Random rnd=new Random();
        for (int i=0;i<7;i++){
            int gen=1+rnd.nextInt(39);
            if (ponovljeni[gen]==0)
            {
                komb[i]=gen;
                ponovljeni[gen]=1;

            }
            else{
                i--;
            }
        }
        return komb;
    }
    public void stampajKombinaciju(int[] komb){
        for (int i=0;i<7;i++)
        {
            System.out.println(komb[i]+" ");
        }
        System.out.println("");
    }
    public void start()
    {
        int[] kombinacija=getKombinacija();
        try {
            SocketChannel socket= SocketChannel.open(new InetSocketAddress(this.port));
            socket.configureBlocking(true);
            ByteBuffer buffer=ByteBuffer.allocate(4*7);
            for (int i=0;i<7;i++)
            {
                buffer.putInt(kombinacija[i]);
            }
            buffer.flip();
            while(socket.write(buffer)>0)
            {
                //System.out.println(buffer.position());
            }
            buffer.clear();

            socket.read(buffer);

            //System.out.println("Nesto");
            buffer.flip();
            int n=buffer.getInt();
            stampajKombinaciju(kombinacija);
            System.out.println(n);



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public static void main(String[] args) {

        //System.out.println("Hello from: " + NBIOClient.class.getName());
        final int port=12345;
        NBIOClient client=new NBIOClient("127.0.0.1",port);
        client.start();

    }

}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

class NBIOServer {
    private int port;

    public NBIOServer(int port) {
        this.port = port;
    }
    private int getPogodjeni(int[] klijent,int server [])
    {
        int length=7;
        int br=0;
        for (int i=0;i<length;i++)
        {
            for (int j=0;j<length;j++)
            {
                if (klijent[i]==server[j])
                {
                    br++;
                }
            }
        }
        return br;
    }
    public void stampajKombinaciju(int[] komb){
        for (int i=0;i<7;i++)
        {
            System.out.println(komb[i]+" ");
        }
        System.out.println("");
    }
    int [] getKombinacija()
    {
        int length=7;
        int[] ponovljeni=new int[40];
        Arrays.fill(ponovljeni,0);

        int [] komb=new int [length];
        Random rnd=new Random();
        for (int i=0;i<7;i++){
            int gen=1+rnd.nextInt(39);
            if (ponovljeni[gen]==0)
            {
                komb[i]=gen;
                ponovljeni[gen]=1;

            }
            else{
                i--;
            }
        }
        return komb;
    }
    public void start()
    {
        try (ServerSocketChannel serverChannel=ServerSocketChannel.open();
             Selector selector=Selector.open();) {
            if (!selector.isOpen() || !serverChannel.isOpen())
            {
                System.err.println("Selector ili Channel nisu otvoreni");
                return;
            }
            serverChannel.configureBlocking(false);
            serverChannel.bind(new InetSocketAddress(this.port));
            serverChannel.register(selector,SelectionKey.OP_ACCEPT);
            while(true)
            {
                selector.select();
                Set<SelectionKey> keys=selector.selectedKeys();
                Iterator<SelectionKey> it=keys.iterator();
                while(it.hasNext())
                {
                    SelectionKey key=it.next();
                    try{
                        if (key.isAcceptable())
                        {
                            ServerSocketChannel server=(ServerSocketChannel) key.channel();
                            SocketChannel socket=server.accept();
                            socket.configureBlocking(false);
                            SelectionKey socketKey=socket.register(selector,SelectionKey.OP_READ);
                            ByteBuffer buffer=ByteBuffer.allocate(4*7);
                            socketKey.attach(buffer);
                        }
                        else if (key.isReadable())
                        {
                            SocketChannel socket=(SocketChannel)key.channel();
                            ByteBuffer buffer=(ByteBuffer) key.attachment();

                            socket.read(buffer);
                            if (buffer.position()==28)
                            {
                                buffer.flip();
                                System.out.println(5);
                                int[] niz=new int[7];
                                for (int i=0;i<7;i++)
                                {
                                    niz[i]=buffer.getInt();
                                }
                                buffer.clear();
                                int[] serverKomb=getKombinacija();
                                int brojPogodjenih=getPogodjeni(niz,serverKomb);
                                stampajKombinaciju(serverKomb);
                                buffer.putInt(brojPogodjenih);
                                buffer.flip();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }

                        }
                        else if (key.isWritable())
                        {
                            SocketChannel socket=(SocketChannel)key.channel();
                            ByteBuffer buffer=(ByteBuffer) key.attachment();
                            if (!buffer.hasRemaining())
                            {

                                key.interestOps(SelectionKey.OP_READ);
                                buffer.clear();
                            }
                            else{
                                socket.write(buffer);
                            }
                        }
                    }
                    catch (IOException e)
                    {
                        key.cancel();
                        try{
                            key.channel().close();
                        }
                        catch (IOException k) {
                            k.printStackTrace();
                        }

                    }
                    it.remove();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        final int port=12345;
        //System.out.println("Hello from: " + NBIOServer.class.getName());
        NBIOServer server=new NBIOServer(port);
        server.start();
    }

}

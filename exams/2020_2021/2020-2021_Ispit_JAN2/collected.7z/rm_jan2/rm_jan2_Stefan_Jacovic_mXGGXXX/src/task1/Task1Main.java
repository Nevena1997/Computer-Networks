package task1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

class Task1Main {
    
    public static void main(String[] args) {
        try {
            URL u = new URL("file:/home/ispit/Desktop/tests/dir2/2.test");


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Hello from: " + Task1Main.class.getName());
    }

}

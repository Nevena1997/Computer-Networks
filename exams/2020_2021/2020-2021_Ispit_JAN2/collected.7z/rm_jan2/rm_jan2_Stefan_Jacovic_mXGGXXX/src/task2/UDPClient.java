package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

class UDPClient {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String niska = sc.next();
        byte[] buf = new byte[512];

        try(DatagramSocket socket = new DatagramSocket()){

            InetAddress host = InetAddress.getLocalHost();

            buf = niska.getBytes();
            DatagramPacket request = new DatagramPacket(buf,buf.length,host,12345);
            socket.send(request);

            DatagramPacket response = new DatagramPacket(buf,buf.length);
            socket.receive(response);


        }

        catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }


    }


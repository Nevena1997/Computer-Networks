package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

class UDPServer {

    public  static  int PORT = 12345;
    private static int SIZE = 10;
    public static void main(String[] args) {


        try(DatagramSocket socket = new DatagramSocket(PORT)) {
            while(true)
            {
                byte[] buf = new byte[512];

                DatagramPacket request = new DatagramPacket(buf,buf.length);
                socket.receive(request);

                String linija = new String(request.getData(),0,request.getLength());

                String obrada = obradi(linija);

                buf = obrada.getBytes();

                DatagramPacket response = new DatagramPacket(buf,0,request.getLength(),
                        request.getAddress(),request.getPort());
                socket.send(response);


            }


        }catch(SocketException e)
        {
            e.printStackTrace();
        }catch(IOException e)
        {
            e.printStackTrace();
        }



    }

    private static String obradi(String linija) {
        String novaLinija="";

        String[] split = linija.split("");
        ByteBuffer buf = ByteBuffer.allocate(linija.length());

       // int duzina = buf.getInt();


        for(int i=0;i<linija.length();i++){

            if (split[i].matches("[a-z]")) {

                novaLinija += split[i].toUpperCase();

            } else if (split[i].matches("[A-Z]")) {

               novaLinija += split[i].toLowerCase();
               novaLinija += split[i].toLowerCase();


            } else if (split[i].matches("[0-9]+")) {

               novaLinija+="..";
               // novaLinija +='.';


            }else if(split[i].matches(" "))
            {

                novaLinija+=' ';
            }
        }



            return novaLinija;

    }

}

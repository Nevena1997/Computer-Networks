package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

class UDPClient {

    private static int SIZE = 512;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String niska = sc.nextLine();
        sc.close();

    try(DatagramSocket socket = new DatagramSocket())
    {

        byte[] buf=niska.getBytes();
        InetAddress adr = InetAddress.getLocalHost();

        DatagramPacket request = new DatagramPacket(buf,buf.length,adr,UDPServer.PORT);
        socket.send(request);

        DatagramPacket response = new DatagramPacket(new byte[SIZE],SIZE);
        socket.receive(response);

        String odg = new String(response.getData(),0, response.getLength());
        System.out.println(odg);




    }catch(SocketException e)
    {
        e.printStackTrace();
    }catch(IOException e)
    {
        e.printStackTrace();
    }





    }

}

package task1;

import java.io.*;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

class Task1Main {

    private static String host = "localhost";

    public static void main(String[] args) {

    String path = "/home/ispit/Desktop/tests/urls.txt";

    try
    {
        URL u = new URL("FILE",host,path);

        URLConnection uc = u.openConnection();

        BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream()));
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out));

        String line;
        String newLine="";
        while((line=in.readLine())!=null)
        {
            if(line.contains("http") || line.contains("https"))
            {

                String verzija = version(line);
                String protokol= protocol(line);
                String putanja = put(line);

                if(putanja!=" ") {

                    String kraj = verzija.concat(protokol).concat(putanja);


                    out.write(kraj);  //verzija+protokol+putanja);

                    //out.write(putanja);
                    out.newLine();
                    out.flush();
                }
                }
        }

        in.close();
        out.close();

    }catch(IOException e)
    {
        e.printStackTrace();
    }


    }



    private static String put(String line) throws MalformedURLException {
        String linija = line.substring(line.lastIndexOf('[')+1);
        String linija2 = linija.substring(0,linija.indexOf(']'));

        URL u = new URL(linija);
        String put = u.getPath();

        if(!put.contains(":"))
        {
            return " ";
        }

         return u.getPath();

    }

    private static String protocol(String line) {
        String linija = line.substring(line.lastIndexOf('[')+1);
        String linija2 = linija.substring(0,linija.indexOf(':')+1);

        return linija2;
    }

    private static String version(String line) {

        String linija = line.substring(21);
        String line2  =linija.substring(0,linija.indexOf(']')+1);

        if(line2.contains(":"))
            return "v16:";

        return "v4:";

    }

}

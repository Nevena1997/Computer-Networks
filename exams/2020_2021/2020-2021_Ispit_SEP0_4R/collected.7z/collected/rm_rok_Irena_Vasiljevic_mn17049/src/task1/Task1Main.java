package task1;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static int[][] m3;
    public static int zbir = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String prvi = sc.nextLine();
        String drugi = sc.nextLine();
        sc.close();

        try (Scanner sc1 = new Scanner(Paths.get(prvi));
             Scanner sc2 = new Scanner(Paths.get(drugi))) {
            String[] linija = sc1.nextLine().split(" ");
            int n1 = linija.length;
            int[][] m1 = new int[n1][n1];
            int[][] m2 = new int[n1][n1];

            for (int i = 0; i < n1; i++)
                m1[0][i] = Integer.valueOf(linija[i]);

            linija = sc2.nextLine().split(" ");
            int n2 = linija.length;

            if (n1 != n2) {
                System.err.println("Matrice ne mogu da se mnoze!");
                System.exit(1);
            }

            for (int i = 0; i < n1; i++)
                m2[0][i] = Integer.valueOf(linija[i]);

            for (int i = 1; i < n1; i++) {
                for (int j = 0; j < n1; j++) {
                    m1[i][j] = sc1.nextInt();
                    m2[i][j] = sc2.nextInt();
                }
            }

            for (int i = 0; i < n1; i++) {
                for (int j = 0; j < n1; j++) {
                    System.out.print(m1[i][j]);
                    System.out.print(" ");
                }
                System.out.println();
            }
            System.out.println();

            for (int i = 0; i < n1; i++) {
                for (int j = 0; j < n1; j++) {
                    System.out.print(m2[i][j]);
                    System.out.print(" ");
                }
                System.out.println();
            }
            System.out.println();

            m3 = new int[n1][n1];
            Nit[] niti = new Nit[n1 * n1];
            int k = 0;
            for (int i = 0; i < n1; i++)
                for (int j = 0; j < n1; j++) {
                    niti[k] = new Nit(m1, m2, i, j, n1);
                    niti[k].start();
                    k++;
                }

            for (int i = 0; i < k; i++)
                niti[i].join();

            for (int i = 0; i < n1; i++) {
                for (int j = 0; j < n1; j++) {
                    System.out.print(m3[i][j]);
                    System.out.print(" ");
                }
                System.out.println();
            }
            System.out.println();

            System.out.println(zbir);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
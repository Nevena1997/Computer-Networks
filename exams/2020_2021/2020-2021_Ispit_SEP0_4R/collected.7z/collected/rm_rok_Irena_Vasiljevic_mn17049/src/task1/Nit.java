package task1;

public class Nit extends Thread {
    private int[][] m1;
    private int[][] m2;
    private int i;
    private int j;
    private int n;

    public Nit(int[][] m1, int[][] m2, int i, int j, int n) {
        this.m1 = m1;
        this.m2 = m2;
        this.i = i;
        this.j = j;
        this.n = n;
    }

    @Override
    public synchronized void run() {
        Task1Main.m3[i][j] = 0;
        for (int k = 0; k < n; k++) {
            Task1Main.m3[i][j] += m1[i][k] * m2[k][j];
        }
        Task1Main.zbir += Task1Main.m3[i][j];
    }
}
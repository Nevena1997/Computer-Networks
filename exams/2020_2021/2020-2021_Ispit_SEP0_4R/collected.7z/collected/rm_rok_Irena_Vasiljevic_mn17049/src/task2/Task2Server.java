package task2;

import java.io.IOException;
import java.net.*;

public class Task2Server {
    public static final int PORT = 12345;

    public static void main(String[] args) {
        int[] brojevi = new int[80];
        brojevi[0] = 0;
        brojevi[1] = 1;
        for (int i = 2; i < 80; i++)
            brojevi[i] = brojevi[i - 1] + brojevi[i - 2];

        try (DatagramSocket server = new DatagramSocket(PORT)) {
            while (true) {
                byte[] niz = new byte[4];
                DatagramPacket prijem = new DatagramPacket(niz, 4, InetAddress.getByName("localhost"), PORT);
                server.receive(prijem);

                System.out.println("Stigao datagram!");

                int n = Integer.valueOf(new String(prijem.getData()));
                for (int i = 0; i < n; i++) {
                    byte[] novi = String.valueOf(brojevi[i]).getBytes();
                    DatagramPacket slanje = new DatagramPacket(novi, 8, prijem.getAddress(), prijem.getPort());
                    server.send(slanje);
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
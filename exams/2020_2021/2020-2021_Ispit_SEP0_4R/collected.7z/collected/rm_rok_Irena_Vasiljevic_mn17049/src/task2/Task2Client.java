package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            System.out.print("Uneti prirodan broj (ne veci od 80): ");
            int n = sc.nextInt();

            if (n > 80) {
                System.err.println("Broj ne sme biti veci od 80!");
                System.exit(1);
            }

            byte[] niz = String.valueOf(n).getBytes();

            DatagramPacket slanje = new DatagramPacket(niz, niz.length, InetAddress.getByName("localhost"), Task2Server.PORT);
            klijent.send(slanje);

            for (int i = 0; i < n; i++) {
                byte[] broj = new byte[8];
                DatagramPacket prijem = new DatagramPacket(broj, 8);

                klijent.receive(prijem);
                System.out.println(new String(prijem.getData()));
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
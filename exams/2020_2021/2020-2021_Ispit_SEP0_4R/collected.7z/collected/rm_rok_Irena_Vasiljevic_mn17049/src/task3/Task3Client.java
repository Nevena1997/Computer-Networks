package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.PORT));
             Scanner sc = new Scanner(System.in)) {
            ByteBuffer bafer = ByteBuffer.allocate(16);
            byte[][] niz = new byte[4][4];

            while (true) {
                System.out.println("Uneti 4 cela broja:");

                niz[0] = sc.next().getBytes();
                niz[1] = sc.next().getBytes();
                niz[2] = sc.next().getBytes();
                niz[3] = sc.next().getBytes();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
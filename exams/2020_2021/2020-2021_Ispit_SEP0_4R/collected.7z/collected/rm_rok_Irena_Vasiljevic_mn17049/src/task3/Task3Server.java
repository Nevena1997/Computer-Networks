package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Task3Server {
    public static final int PORT = 54321;

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selektor = Selector.open()) {
            if (!server.isOpen() || !selektor.isOpen()) {
                System.err.println("Greska");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selektor, SelectionKey.OP_ACCEPT);

            while (true) {
                selektor.select();
                Iterator<SelectionKey> it = selektor.selectedKeys().iterator();

                while (it.hasNext()) {
                    SelectionKey kljuc = it.next();
                    it.remove();

                    try {
                        if (kljuc.isAcceptable()) {
                            ServerSocketChannel s = (ServerSocketChannel) kljuc.channel();
                            SocketChannel klijent = s.accept();

                            klijent.configureBlocking(false);
                            SelectionKey k1 = klijent.register(selektor, SelectionKey.OP_WRITE);
                            SelectionKey k2 = klijent.register(selektor, SelectionKey.OP_READ);

                            ByteBuffer b1 = ByteBuffer.allocate(4);
                            ByteBuffer b2 = ByteBuffer.allocate(16);

                            k1.attach(b1);
                            k2.attach(b2);
                        } else if (kljuc.isReadable()) {

                        } else if (kljuc.isWritable()) {

                        }
                    } catch (IOException e) {
                        kljuc.cancel();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
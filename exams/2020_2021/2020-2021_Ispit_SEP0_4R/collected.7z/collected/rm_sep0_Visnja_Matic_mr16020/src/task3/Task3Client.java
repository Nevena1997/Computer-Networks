package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        System.out.println("Hello!");


        InetSocketAddress adresa = new InetSocketAddress("localhost",Task3Server.SERVER_PORT);
        try (SocketChannel client = SocketChannel.open(adresa);
             Scanner sc = new Scanner(System.in)){
            while (true){
                int a,b,c,d;
                a=sc.nextInt();
                b=sc.nextInt();
                c=sc.nextInt();
                d=sc.nextInt();
                ByteBuffer buffer = ByteBuffer.allocate(4*4);
                buffer.putInt(a);
                buffer.putInt(b);
                buffer.putInt(c);
                buffer.putInt(d);

                buffer.flip();
                client.write(buffer);
                buffer.clear();
                client.read(buffer);
                buffer.flip();

                int p = buffer.getInt();
                System.out.println(p);
                buffer.clear();
            }





      } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

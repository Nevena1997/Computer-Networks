package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.util.Scanner;

public class Task3Server {

    public static int SERVER_PORT = 54321;
    public static void main(String[] args) {
        System.out.println("Hello!");

        InetSocketAddress adresa = new InetSocketAddress(SERVER_PORT);
        try {
            ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector =Selector.open();

            if (! server.isOpen() || !server.isOpen()){
                System.err.println("Greska");
                System.exit(1);
            }




        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task1;


import javax.sound.sampled.FloatControl;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Nit implements Runnable {

    private int[][] mat1;
    private int[][] mat2;
    private int i;
    private int l;
    private int[][] rezultat;

    public Nit(int[][] mat1, int[][] mat2, int i, int l, int[][] rezultat) {

        this.mat1=mat1;
        this.mat2=mat2;
        this.i=i;
        this.l=l;
        this.rezultat = rezultat;

    }

    @Override
    public void run() {
        int rez = 0;
        for (int j = 0,k=0;j<mat1.length;j++,k++){
            rez += mat1[i][j]*mat2[k][l];

        }

        Task1Main.lock.lock();
        rezultat[i][l] =rez;
        //Azuriranje globalog zbira
        int staraVrednost = Task1Main.ZBIR;
        int novaVrednost = staraVrednost+rez;
        Task1Main.ZBIR=novaVrednost;
        Task1Main.lock.unlock();
        }

}

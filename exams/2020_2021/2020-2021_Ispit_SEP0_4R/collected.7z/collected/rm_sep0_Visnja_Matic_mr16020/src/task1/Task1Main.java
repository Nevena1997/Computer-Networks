package task1;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Task1Main {



    public static int ZBIR;
    public static Lock lock = new ReentrantLock();
    public static void main(String[] args) {
        System.out.println("Hello!");
        String fajl1;
        String fajl2;
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Uneti putanje do tekstualnih fajlova u kome se nalaze kvadratne matrice");
            fajl1 = sc.nextLine();
            fajl2 = sc.nextLine();
            String putanjaS = "/home/user/Desktop/rm_sep0_Visnja_Matic_mr16020/src/task1";
            Path putanja1 = Paths.get(putanjaS+"/"+ fajl1);
            Path putanja2 = Paths.get(putanjaS+"/"+fajl2);

            try (BufferedReader in1 = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(putanja1))));
                BufferedReader in2 = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(putanja2))))) {
                String linija;
                int n=0,m=0;
                while ((linija = in1.readLine()) != null){

                    //System.out.println(linija);
                    n++;
                }

                System.out.println();

                while ((linija = in2.readLine()) != null){
                    //System.out.println(linija);
                    m++;
                }

                int[][] mat1 = new int[n][n];
                int[][] mat2 = new int[m][m];


                try (BufferedReader ulaz1 = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(putanja1))))) {

                    String line;
                    int brojac = 0;
                    while ((line = ulaz1.readLine())!=null){
                        String[] podaci = line.split(" ");
                        for (int i = 0;i<n;i++){
                            mat1[brojac][i] = Integer.parseInt(podaci[i]);
                        }
                        brojac++;
                    }
                }
                ////
                try (BufferedReader ulaz2 = new BufferedReader(new InputStreamReader(new FileInputStream(String.valueOf(putanja2))))) {

                    String line;
                    int broj = 0;
                    while ((line = ulaz2.readLine())!=null){
                        String[] podatak = line.split(" ");
                        for (int i = 0;i<m;i++){
                            mat2[broj][i] = Integer.parseInt(podatak[i]);
                        }
                        broj++;
                    }
                }
                 /////Ispis matrica
                for (int i = 0;i<n;i++){
                    for (int j = 0;j<n;j++) {
                        System.out.printf("%d ",mat1[i][j]);
                    }
                    System.out.println();
                }

                System.out.println();

                for (int i = 0;i<m;i++){
                    for (int j = 0;j<m;j++){
                        System.out.printf("%d ",mat2[i][j]);
                    }
                    System.out.println();
                }

                if (n != m){
                    System.err.println("Kvadratne matrice nisu istih dimenzija, stoga ne mogu da se pomnoze");
                    //prekinuti program
                    System.exit(1);
                }

                int[][] rezultat = new int[n][n];

                for (int i =0;i<n;i++){
                    for (int l = 0;l<n;l++){
                        new Thread(new Nit(mat1,mat2,i,l,rezultat)).start();
                    }
                }

                Thread.sleep(5000);

                System.out.println("Proizvod matrica je:");

                for (int i = 0;i<n;i++){
                    for (int j = 0;j<n;j++){
                        System.out.printf("%d ",rezultat[i][j]);
                    }
                    System.out.println();
                }

                System.out.println("Rezultujuci zbir je:");
                System.out.println(ZBIR);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }



    }
}

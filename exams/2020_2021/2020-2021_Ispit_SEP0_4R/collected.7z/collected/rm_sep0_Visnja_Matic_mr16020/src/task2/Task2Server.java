package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class Task2Server {

    public static Map<Integer,Long> mapa = new HashMap<>();
    public static int SERVER_PORT = 12345;
    public static void main(String[] args) {
        System.out.println("Hello!");

        long[] fib = new long[80];
        fib[0] = 0;
        fib[1] = 1;
        for (int i = 2; i < 80; i++)
            fib[i] = fib[i-1] + fib[i - 2];

        for (int i = 0; i < 80; i++)
            System.out.println(fib[i]);

        try (DatagramSocket server = new DatagramSocket(SERVER_PORT)) {

            while (true){

                byte[] bajtovi = new byte[4];
                DatagramPacket zahtev = new DatagramPacket(bajtovi,bajtovi.length);
                server.receive(zahtev);
                int n = 0;
                for (int i = 0;i<4;i++){
                    n = n<<8 | bajtovi[i];
                }
                //System.out.println(n);
                byte[] b = new byte[8];
                for (int j = 0;j<n;j++){
                    b[0] = (byte) (fib[j]>>56);
                    b[1] = (byte) (fib[j]>>48);
                    b[2] = (byte) (fib[j]>>40);
                    b[3] = (byte) (fib[j]>>32);
                    b[4] = (byte) (fib[j]>>24);
                    b[5] = (byte) (fib[j]>>16);
                    b[6] = (byte) (fib[j]>>8);
                    b[7] = (byte) (fib[j]>>0);
                    DatagramPacket odgovor = new DatagramPacket(b,b.length,zahtev.getAddress(),
                            zahtev.getPort());
                    server.send(odgovor);

                }


            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static long Fibonaci(int j) {

        if (j == 0){
            mapa.put(j,0l);
            return 0;
        }
        else if (j == 1){
            mapa.put(j,1l);
            return 1;
        }
        else{
            long prvi = mapa.get(j-2);
            long drugi = mapa.get(j-1);
            mapa.put(j,prvi+drugi);
            return mapa.get(j);
        }


    }
}

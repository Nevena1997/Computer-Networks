package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        System.out.println("Hello!");

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            System.out.printf("Uneti pozitivan ceo broj");
            System.out.println();
            int n = sc.nextInt();
            byte[] bajtovi = new byte[4];

            bajtovi[0] = (byte) (n>>24);
            bajtovi[1] = (byte) (n>>16);
            bajtovi[2] = (byte) (n>>8);
            bajtovi[3] = (byte) (n >> 0);
            DatagramPacket zahtev = new DatagramPacket(bajtovi,bajtovi.length,
                    InetAddress.getByName("localhost"),Task2Server.SERVER_PORT);
            client.send(zahtev);

            byte[] b = new byte[8];
            for (int i = 0;i<n;i++){

                DatagramPacket odgovor = new DatagramPacket(b,b.length);
                client.receive(odgovor);
                long rezultat=0;
                for (int j = 0;j<8;j++){
                    rezultat = rezultat<<8 | b[j];
                }
                System.out.println(rezultat);

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

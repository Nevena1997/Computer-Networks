package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;

public class Task2Server {


    public static final int broj_porta = 12345;

    public static void main(String[] args) {

        ArrayList<Integer> niz = new ArrayList<>();

        niz.add(0);
        niz.add(1);

        for(int i=2;i<80;i++)
        {
            niz.add(niz.get(i-2) + niz.get(i-1));
        }

        try(DatagramSocket server = new DatagramSocket(broj_porta))
        {


            while(true)
            {
                byte[] receiveBytes = new byte[4];
                DatagramPacket dpReceive = new DatagramPacket(receiveBytes,receiveBytes.length);
                server.receive(dpReceive);
                System.out.println("Stigao datagram!");


                String Stringbroj = new String(dpReceive.getData(),0,dpReceive.getLength());

                int broj = Integer.parseInt(Stringbroj);



                for(int i=0;i<broj;i++)
                {
                    Stringbroj = String.valueOf(niz.get(i));
                    byte[] sendBytes = Stringbroj.getBytes();
                    DatagramPacket dpSend = new DatagramPacket(sendBytes,sendBytes.length,dpReceive.getAddress(),dpReceive.getPort());
                    server.send(dpSend);
                }





            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}

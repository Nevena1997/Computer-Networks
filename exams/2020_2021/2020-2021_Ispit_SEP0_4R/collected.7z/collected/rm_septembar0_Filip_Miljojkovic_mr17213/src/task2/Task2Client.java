package task2;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {




    public static void main(String[] args) {

        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in))
        {


            System.out.println("Unesite broj");
            String broj = sc.nextLine();
            byte[] sendBytes = broj.getBytes();




            InetAddress host = InetAddress.getByName("localhost");
            DatagramPacket dpSend = new DatagramPacket(sendBytes,sendBytes.length,host,Task2Server.broj_porta);
            klijent.send(dpSend);


            byte[] receiveBytes = new byte[8];
            DatagramPacket dpReceive = new DatagramPacket(receiveBytes,receiveBytes.length);
            klijent.receive(dpReceive);

            for(int i =0;i<Integer.parseInt(broj);i++)
            {

                String Stringizlaz = new String(dpReceive.getData(), 0, dpReceive.getLength());
                Integer izlaz = Integer.parseInt(Stringizlaz);
                System.out.println(izlaz);
            }


        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

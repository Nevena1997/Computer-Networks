package task1;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {



        File fajl = new File("");






    }


}

package task3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.channels.Channel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class Task3Client {



    public static void main(String[] args) {



        SocketAddress address = new InetSocketAddress("localhost",Task3Server.broj_porta);


        //zaboravimo sam kako da deklarisem wbc


        try(SocketChannel client = SocketChannel.open(address);
            WritableByteChannel out= new WritableByteChannel() {
                @Override
                public boolean isOpen() {
                    return false;
                }

                @Override
                public void close() throws IOException {

                }

                @Override
                public int write(ByteBuffer src) throws IOException {
                    return 0;
                }
            })
        {


            while (true) {
                ByteBuffer buffer = ByteBuffer.allocate(4 * 4);
                for (int i = 0; i < 4; i++) {
                    buffer.putInt(i);
                }

                // [1 2 3 4]
                //        p,l

                buffer.rewind();
                out.write(buffer);

                // [1 2 3 4]
                // p      l


                buffer.rewind();
                // server vraca samo jedan broj [broj _ _ _]

                int izlaz = buffer.getInt();

                System.out.println(izlaz);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

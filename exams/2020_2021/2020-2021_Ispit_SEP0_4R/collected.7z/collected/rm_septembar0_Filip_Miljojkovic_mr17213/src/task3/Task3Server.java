package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Task3Server {


    public static final int  broj_porta = 54321;



    public static void main(String[] args) {


        try(ServerSocketChannel serverSocket = ServerSocketChannel.open();
            Selector selector = Selector.open())
        {
            if(!serverSocket.isOpen() || !selector.isOpen())
            {
                System.out.println("Greska");
                System.exit(-1);
            }


            serverSocket.bind(new InetSocketAddress(broj_porta));
            serverSocket.configureBlocking(false);
            serverSocket.register(selector, SelectionKey.OP_ACCEPT);

            while (true)
            {
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext())
                {
                    SelectionKey key = it.next();
                    it.remove();

                    if(key.isAcceptable())
                    {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();

                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        SelectionKey aKey = client.register(selector,SelectionKey.OP_READ);
                        ByteBuffer buffer = ByteBuffer.allocate(4*4);
                        aKey.attach(buffer);
                    }
                    if(key.isReadable())
                    {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        if(!buffer.hasRemaining())
                        {

                        }


                    }
                    if (key.isWritable())
                    {

                    }

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task1;

import java.util.Vector;

public class Task1MnozenjeMatrica implements Runnable{
    private int el;
    private int n;
    private Vector<Integer> vrsta;

    public Task1MnozenjeMatrica(int el, Vector<Integer> vrsta, int n) {
        this.el = el;
        this.n = n;
        this.vrsta = vrsta;
    }

    @Override
    public void run() {
        // TODO pomnoziti el sa vrstom i sabrati
    }
}

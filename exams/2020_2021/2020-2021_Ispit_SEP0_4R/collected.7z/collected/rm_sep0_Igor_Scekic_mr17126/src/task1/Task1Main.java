package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.Vector;

public class Task1Main {
    public static final int MAX = 10;

    public static void main(String[] args) {
        String dir = "/home/ispit/Desktop/tests";
        String file1 = "/home/ispit/Desktop/tests/primer1/matrica1.txt";
        String file2 = "/home/ispit/Desktop/tests/primer1/matrica2.txt";
        Vector<Vector<Integer>> matrica = null;
        Vector<Vector<Integer>> matrica2 = null;


        if (!Files.isDirectory(Paths.get(dir))) {
            System.err.println("Nepostojeci direktorijum!");
        }

        int n = 3;
        Vector<Integer> vrsta = null;

        try (Scanner in = new Scanner(new FileInputStream(new File(file1)))) {
                while(in.hasNextInt()) {
                    for (int i = 0; i < n; i++) {
                        //vrsta.add(in.nextInt());
                    }
                    //matrica.add(vrsta);

                }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

       //System.out.println(matrica);

        int m = 0;

        try (Scanner in = new Scanner(new FileInputStream(new File(file2)))) {
            while(in.hasNextInt()) {
                System.out.println(in.nextLine());
                m++;

                for (int i = 0; i < m; i++) {
                    vrsta.add(in.nextInt());
                }
                matrica2.add(vrsta);
            }
            //System.out.println(m);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        if (n != m) {
            System.err.println("Matrice ne mogu da se pomnoze!");
            return;
        }

        if (matrica == null) {
            Vector<Integer> v = null;
            v.add(1);
            v.add(2);
            v.add(3);

            matrica.add(v);
        }
        // Pokrecemo n^2 niti
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                new Thread(new Task1MnozenjeMatrica(matrica.get(i).get(j), matrica2.get(i),n)).start();
        }




    }
}





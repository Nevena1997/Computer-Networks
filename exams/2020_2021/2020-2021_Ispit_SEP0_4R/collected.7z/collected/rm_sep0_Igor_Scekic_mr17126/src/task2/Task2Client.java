package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            InetAddress host = InetAddress.getByName("localhost");
            int n = sc.nextInt();
            byte[] sendBytes = Integer.toString(n).getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, host, Task2Server.PORT);
            client.send(sendPacket);

            for (int i = 0; i < n; i++) {
                byte[] receivedBytes = new byte[Task2Server.BUFFSIZE];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
                client.receive(receivedPacket);

                String s = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                int fib = Integer.parseInt(s);
                System.out.println(fib);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Task2Server {
    public static final int PORT = 12345;
    public static final int BUFFSIZE = 256;
    private static final int FIB_NUM = 80;

    public static void main(String[] args) {
        int[] fibonaci = new int[FIB_NUM];
        fibonaci[0] = 0;
        fibonaci[1] = 1;

        for (int i = 2; i < FIB_NUM; i++) {
            fibonaci[i] = fibonaci[i-1] + fibonaci[i-2];
        }

        try(DatagramSocket server = new DatagramSocket(PORT)) {
            while (true) {
                byte[] receivedBytes = new byte[BUFFSIZE];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
                server.receive(receivedPacket);
                System.out.println("Stigao datagram!");

                String s = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                int n = Integer.parseInt(s);

                for (int i = 0; i < n; i++) {
                    byte[] sendBytes = Integer.toString(fibonaci[i]).getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, receivedPacket.getAddress(), receivedPacket.getPort());
                    server.send(sendPacket);
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

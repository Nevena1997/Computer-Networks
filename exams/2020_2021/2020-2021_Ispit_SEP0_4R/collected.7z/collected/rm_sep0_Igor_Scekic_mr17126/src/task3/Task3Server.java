package task3;

import java.io.IOException;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Server {
    public static final int PORT = 54321;
    public static final int BUFFSIZE = 512;

    public static void main(String[] args) {
       try (ServerSocketChannel server = ServerSocketChannel.open()){
           SocketChannel client = server.accept();


           //client.finishConnect();

       } catch (IOException e) {
           e.printStackTrace();
       }
    }
}

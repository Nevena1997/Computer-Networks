package task3;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.sql.Connection;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open();
             Scanner sc = new Scanner(System.in)) {
            int x1 = sc.nextInt();
            int y1 = sc.nextInt();
            int x2 = sc.nextInt();
            int y2 = sc.nextInt();



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

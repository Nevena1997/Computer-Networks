package task3;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Task3Server {

    public  static  int SERVER_PORT=54321;
    public static void main(String[] args){


        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector= Selector.open();
        ) {

            if(!selector.isOpen() || !serverChannel.isOpen()){
                System.err.println("Server or selector cannot be opened");
                System.exit(1);

            }


            serverChannel.bind(new InetSocketAddress(SERVER_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);


            while (true){

                selector.select();
                Iterator<SelectionKey> iterator= selector.selectedKeys().iterator();

                while (iterator.hasNext()){

                    SelectionKey key=iterator.next();
                    iterator.remove();

                    try {


                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel klijent = server.accept();

                            klijent.configureBlocking(false);
                            SelectionKey klijentKey = klijent.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(4 * 4);


                            klijentKey.attach(buffer);


                        } else if (key.isWritable()) {
                            SocketChannel klijent = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();


                            klijent.write(buffer);
                            if(!buffer.hasRemaining()) {
                                buffer.clear();

                            }


                        } else if (key.isReadable()) {

                            SocketChannel klijent = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            klijent.read(buffer);

                            if (!buffer.hasRemaining()) {

                                buffer.flip();

                                int x1 = buffer.getInt();
                                int y1 = buffer.getInt();
                                int x2 = buffer.getInt();
                                int y2 = buffer.getInt();

                                //System.out.println(x1+" "+ x2+" "+y1+" "+y2);
                                if (x1 == 0 && x2 == 0 && y1 == 0 && y2 == 0) {
                                    key.cancel();
                                    klijent.close();
                                    System.exit(1);
                                }
                                int povrsina = Math.abs(x1 - x2) * Math.abs(y1 - y2);
                                buffer.clear();
                                buffer.putInt(povrsina);
                                buffer.flip();

                                key.interestOps(SelectionKey.OP_WRITE);

                            }


                        }
                    }catch (IOException e){
                        e.printStackTrace();
                    }








                }





            }






        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

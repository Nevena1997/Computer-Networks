package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {

        try (SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.SERVER_PORT));
             Scanner sc = new Scanner(System.in)
        ) {

            ByteBuffer buffer = ByteBuffer.allocate(4 * 4);
            while (true) {
                buffer.clear();
                int x1 = sc.nextInt();
                int y1 = sc.nextInt();
                int x2 = sc.nextInt();
                int y2 = sc.nextInt();

                buffer.putInt(x1);
                buffer.putInt(y1);
                buffer.putInt(x2);
                buffer.putInt(y2);

                buffer.flip();
                klijent.write(buffer);

                if (x1 == 0 && x2 == 0 && y1 == 0 && y2 == 0) {
                    break;

                }

                buffer.clear();
                klijent.read(buffer);
                buffer.flip();

                int povrsina = buffer.getInt();
                System.out.println(povrsina);



            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Task2Server {

    public  static  int SERVER_PORT=12345;

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(SERVER_PORT)) {

            while(true) {


                byte[] receivedByte = new byte[4];
                DatagramPacket receivedPacket = new DatagramPacket(receivedByte, receivedByte.length);
                server.receive(receivedPacket);

                System.out.println("Stigao datagram!");


                String brojString=new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                Integer broj=Integer.valueOf(brojString);


                for(int i=0; i<broj; i++) {

                    int fib=fibonaci(i);

                    String fibString=String.valueOf(fib);
                    byte[] fibByte=fibString.getBytes();


                    DatagramPacket sendString = new DatagramPacket(fibByte, fibByte.length, receivedPacket.getAddress(), receivedPacket.getPort());
                    server.send(sendString);


                }


            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static int fibonaci(int i) {

            if(i == 0 || i ==1)
                return i;
            return fibonaci(i-1)+fibonaci(i-2);


    }
}

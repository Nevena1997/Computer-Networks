package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {


        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc=new Scanner(System.in)
        ) {

            InetAddress host=InetAddress.getByName("localhost");

            int broj=sc.nextInt();

            String s=String.valueOf(broj);


            byte[] bytesSend=s.getBytes();
            System.out.println(bytesSend.length);
            DatagramPacket sendPacket=new DatagramPacket(bytesSend, bytesSend.length, host,Task2Server.SERVER_PORT );
            klijent.send(sendPacket);


            /*citaaa*/
            while (true) {

                byte[] bytesRecived = new byte[8];
                DatagramPacket receivedPacket = new DatagramPacket(bytesRecived, bytesRecived.length);
                klijent.receive(receivedPacket);
                String s1 = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                Integer br = Integer.valueOf(s1);
                System.out.println(br);
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

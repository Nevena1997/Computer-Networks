package task1;

import java.util.concurrent.locks.Lock;

public class Nit extends Thread {


    private int[][] m1;
    private int[][] m2;
    private int i;
    private int j;
    private int[][] mrez;
    private int n;

    public int zbir=0;

    public Nit(int[][] m1, int[][] m2, int i, int j, int n, int[][] mrez) {

        this.m1 = m1;
        this.m2 = m2;
        this.i = i;
        this.j = j;
        this.n = n;
        this.mrez = mrez;

    }



    @Override
    public synchronized void run() {

        for (int k = 0; k < this.n; k++){
            this.mrez[this.i][this.j]+= this.m1[this.i][k]*this.m2[k][this.j];
            this.zbir+=this.mrez[this.i][this.j];
        }



    }
    public int getZbir(){
        return  this.zbir;
    }
}

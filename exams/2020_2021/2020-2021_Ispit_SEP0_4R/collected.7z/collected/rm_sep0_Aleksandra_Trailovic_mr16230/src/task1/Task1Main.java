package task1;

import java.awt.image.BufferedImageOp;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {

    public static void main(String[] args) {

          Scanner sc=new Scanner(System.in);


        System.out.println("Unesite putanju 1");
        String s1=sc.nextLine();
        //String s1 = "/home/ispit/Desktop/tests/primer1/matrica1.txt";

        System.out.println("Unesite putanju2");
        String s2=sc.nextLine();
        //String s2 = "/home/ispit/Desktop/tests/primer1/matrica2.txt";


        try (Scanner sc1 = new Scanner(new FileInputStream(s1));
             Scanner sc2 = new Scanner(new FileInputStream(s1));
             Scanner sc3 = new Scanner(new FileInputStream(s2));
             Scanner sc4 = new Scanner(new FileInputStream(s2))

        ) {

            //ucitavamo matricu 1

            int n = 0;
            while (sc1.hasNextLine()) {
                String line = sc1.nextLine();
                n++;
            }

            //ucitavamo prvu matricu
            int[][] matrix1 = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++)
                    matrix1[i][j] = sc2.nextInt();
            }
            //ispis prve matrice

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++)
                    System.out.print(matrix1[i][j] + " ");
                System.out.println();
            }
            System.out.println();
            //ucitavamo matricu 2
            int m = 0;
            while (sc3.hasNextLine()) {
                String line = sc3.nextLine();
                m++;
            }

            //ucitavamo matricu 2
            int[][] matrix2 = new int[3][3];
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < m; j++)
                    matrix2[i][j] = sc4.nextInt();
            }
            //ispis matrice 2
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < m; j++)
                    System.out.print(matrix2[i][j] + " ");
                System.out.println();
            }
            System.out.println();
            //provera dimenzija
            if (n != m) {
                System.err.println("Ne mogu se mnoziti");
                System.exit(1);
            }
            System.out.println("Mnozenje");
            //mnozenje
            int[][] matricapomnozeno = new int[n][n];

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {

                    Nit niti=new Nit(matrix1, matrix2, i, j,n,  matricapomnozeno);
                    Thread t=new Thread(niti);
                    t.start();
                }
            }


            System.out.println();
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < m; j++)
                    System.out.print(matricapomnozeno[i][j] + " ");
                System.out.println();
            }



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }


}


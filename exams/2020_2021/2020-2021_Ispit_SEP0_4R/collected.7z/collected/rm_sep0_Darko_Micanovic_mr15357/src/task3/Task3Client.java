package task3;

import task2.Task2Server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {

    public static void main(String[] args)
    {
        InetSocketAddress address = new InetSocketAddress("localhost", Task3Server.SERVER_PORT);

        try (SocketChannel client = SocketChannel.open(address);
             Scanner sc = new Scanner(System.in))
        {
            ByteBuffer buffer = ByteBuffer.allocate(16);
            int n;

            while (true) {

//                Popunjavam bafer:
                buffer.clear();
                for (int i = 0; i < 4; i++)
                {
                    n = sc.nextInt();
                    buffer.putInt(n);
                }

//                Saljem paket:
                buffer.flip();
                client.write(buffer);

//               Citam paket:
                buffer.clear();
                client.read(buffer);
                buffer.flip();

                n = buffer.getInt();
                if (n == -1)
                    break;
                System.out.println("Povrsina je: " + n);
            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

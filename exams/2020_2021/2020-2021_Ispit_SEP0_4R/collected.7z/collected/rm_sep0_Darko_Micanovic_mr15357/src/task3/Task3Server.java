package task3;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class Task3Server {
    public static int SERVER_PORT = 54321;

    public static void main(String[] args)
    {
        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open())
        {
            if (!serverChannel.isOpen() || !selector.isOpen())
            {
                System.err.println("Greska prilikom pokretanja servera!");
                System.exit(1);
            }
            System.err.println("Server radi!");

            serverChannel.bind(new InetSocketAddress(SERVER_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true)
            {
                selector.select();
                Iterator<SelectionKey> it = (Iterator<SelectionKey>) selector.selectedKeys().iterator();

                while (it.hasNext())
                {
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable())

               {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector,SelectionKey.OP_READ);

                        ByteBuffer buffer = ByteBuffer.allocate(16);
                        clientKey.attach(buffer);
                    }
                    else if (key.isReadable())
                    {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        int n;
                        int[] arr = new int[4];

                        client.read(buffer);
                        buffer.flip();

                        for (int i = 0; i < 4; i++) {
                            n = buffer.getInt();
                            arr[i] = n;
                        }

                        if (arr[0] == 0 &&  arr[1] == 0 && arr[2] == 0 && arr[3] == 0) {
//                            Saljem kraj
                            buffer.clear();
                            buffer.putInt(-1);
                            buffer.flip();
                        }
                        else {
//                        Saljem povrsinu:
                            int vol = Math.abs(arr[2] - arr[0]) * Math.abs(arr[3] - arr[1]);
                            buffer.clear();
                            buffer.putInt(vol);
                            buffer.flip();
                        }

                        key.interestOps(SelectionKey.OP_WRITE);
                    }
                    else if (key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.write(buffer);
                        client.close();
                    }
                }

            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

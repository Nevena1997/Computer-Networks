package task1;

import java.util.List;

public class Task1Thread implements Runnable {
    private List<Integer> lA, lB;

    public Task1Thread(List<Integer> lA, List<Integer> lB) {this.lB = lA; this.lB = lB;}

    @Override
    public void run() {
//        lA i lB su mi vektori dimenzije n
        int n = lA.size();
        int sum = 0;
        for ( int i = 0; i < n; i++ )
            sum += lA.get(i) + lB.get(i);

        System.out.println(sum);
    }
}

package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.locks.Lock;


// /home/ispit/Desktop/tests/primer1/matrica1.txt
// /home/ispit/Desktop/tests/primer1/matrica2.txt

public class Task1Main {
    public static void main(String[] args)
    {

        Scanner input = new Scanner(System.in);

        String matrixA = input.nextLine();
        String matricaB = input.nextLine();

        input.close();

        try (Scanner inputA = new Scanner(new File(matrixA));
             Scanner inputB = new Scanner(new File(matricaB)))
        {

            StringBuilder sbA = new StringBuilder();
            StringBuilder sbB = new StringBuilder();

//            Popunjavam dimenziju matrica
            String line = inputA.nextLine();
            sbA.append(line);
            int sizeA = line.split(" ").length;

            line = inputB.nextLine();
            sbB.append(line);
            int sizeB = line.split(" ").length;

            if ( sizeA != sizeB)
            {
                System.err.println("Nije moguce mnoziti matrice");
                System.exit(1);
            }

//           Citam matrice
            while (inputA.hasNextLine())
                sbA.append(" " + inputA.nextLine()); // Morao sam da dodajem " " umesto novih redova, da bih splitovao
            while (inputB.hasNextLine())
                sbB.append(" " + inputB.nextLine()); // Isto...

//            Popunjavam matricu u niz
//            int[] mA = new int[sizeA * sizeA];
            List<Integer> mA = new ArrayList<Integer>();
            List<Integer> mB = new ArrayList<Integer>();

            int i = 0;
            for ( String num : sbA.toString().split(" ") )
                mA.add(Integer.parseInt(num));


            i=0;
            for ( String num : sbB.toString().split(" ") )
                mB.add(Integer.parseInt(num));

            System.out.print("[ ");
            for ( int a : mA )
                System.out.print(a + " ");
            System.out.print("]");
            System.out.print(" * ");
            System.out.print("[ ");
            for ( int b : mB )
                System.out.print(b + " ");
            System.out.println("]");



//             Ideja je bila da napravim dve podliste i da saljem niti...
//             Ali sve bi to trebalo sinhronizovati dodatno

//            System.out.print("[ ");
//            for (int i = 0; i < sizeA; i++){
//                for (int j = 0; i < sizeB; j++)
//                {
//                    List<Integer> tmp = new ArrayList<Integer>();
//                    tmp.add()
//
//                    new Thread(new Task1Thread(mA.subList(),tmp)).start();
//                }
//            }
//            System.out.println(" ]");



        }
        catch (FileNotFoundException e)
        {
            System.err.println("Nepostojeci fajl !");
        }
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static int BUF_SIZE = 4;

    public static void main(String[] args)
    {
        try (DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in))
        {
            int n = sc.nextInt();
            byte[] sendBytes = new byte[BUF_SIZE];
            sendBytes = Integer.toString(n).getBytes();

//            Saljem paket
            DatagramPacket sendPacket = new DatagramPacket(sendBytes,sendBytes.length,
                    InetAddress.getLocalHost(),Task2Server.SERVER_PORT);

            client.send(sendPacket);

//            Primam paket
            while (true) {
                byte[] reciveBytes = new byte[BUF_SIZE];
                DatagramPacket recivedPacket = new DatagramPacket(reciveBytes, reciveBytes.length);
                client.receive(recivedPacket);

                String recivedString = new String(recivedPacket.getData(), 0, recivedPacket.getLength());
                int recivedInt = Integer.parseInt(recivedString);

                if (recivedInt == -1)
                    break;

                System.out.println(recivedInt);
            }
        }
        catch (SocketException e)
        {
            e.printStackTrace();
        }
        catch (UnknownHostException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }
}

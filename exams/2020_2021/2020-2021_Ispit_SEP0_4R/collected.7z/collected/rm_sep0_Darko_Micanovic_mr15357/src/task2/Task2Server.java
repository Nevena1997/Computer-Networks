package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Task2Server {
    public static int SERVER_PORT = 12345;
    public static int BUF_SIZE = 8;

    public static void main(String[] args)
    {
//        Pravim Fibonacijev niz (kesiran stoji)
//        Uz pretpstavku da necu imati vise od 80 na ulazu

        int[] fibonaci = new int[80];
        fibonaci[0] = 0;
        fibonaci[1] = 1;
        for (int i = 2; i < 80 ; i++)
            fibonaci[i] = fibonaci[i-1] + fibonaci[i - 2];

        try (DatagramSocket server = new DatagramSocket(SERVER_PORT))
        {
            System.err.println("Server radi !");
            while (true) {
//            Cekam da primi paket:
                byte[] recivedBytes = new byte[Task2Client.BUF_SIZE];
                DatagramPacket recivedPacket = new DatagramPacket(recivedBytes, recivedBytes.length);
                server.receive(recivedPacket);

//                Citam paket:
                String recivedString = new String(recivedPacket.getData(), 0, recivedPacket.getLength());
                int n = Integer.parseInt(recivedString);

                if ( n >= 1 && n <= 80 )
                    System.out.println("Stigao datagram !");
                else
                {
                    System.err.println("Neispravan paket");
                    continue;
                }

//               Saljem pakete:
                byte[] sendBytes = new byte[BUF_SIZE];
                for (int i = 0; i < n; i++) {

                    sendBytes = Integer.toString(fibonaci[i]).getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length,
                            recivedPacket.getAddress(), recivedPacket.getPort());
                    server.send(sendPacket);
                }
//                Naglasavam da je kraj slanjem kontrolnog paketa -1:
                sendBytes = Integer.toString(-1).getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length,
                        recivedPacket.getAddress(), recivedPacket.getPort());
                server.send(sendPacket);
            }

        }
        catch (SocketException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task2Client {

    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            byte[] bytesReq = new byte[4];
            //System.out.println("Unesite broj: ");
            String number = sc.nextLine();
            bytesReq = number.getBytes(StandardCharsets.UTF_8);

            DatagramPacket request = new DatagramPacket(bytesReq, bytesReq.length, InetAddress.getByName("localhost"), Task2Server.DEFAULT_PORT);
            client.send(request);

            byte[] bytesResp = new byte[8];
            Integer numFib = Integer.parseInt(number);

            for(int i=0; i<numFib; i++) {

                DatagramPacket response = new DatagramPacket(bytesResp, bytesResp.length);
                client.receive(response);

                String odg = new String(response.getData(), 0, response.getLength());
                System.out.println(odg);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task2Server {

    public static int DEFAULT_PORT = 12345;
    public static int[] nizFibonaci = new int[81];

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)) {

            nizFibonaci[0] = 0;
            nizFibonaci[1] = 1;
            for (int i = 2; i <= 80; i++) {
                int num = nizFibonaci[i - 1] + nizFibonaci[i - 2];
                nizFibonaci[i] = num;
            }

            byte[] bytesReq = new byte[4];
            byte[] bytesResp = new byte[8];

            while (true) {

                DatagramPacket request = new DatagramPacket(bytesReq, bytesReq.length);
                server.receive(request);

                System.out.println("Stigao datagram!");

                String number = new String(request.getData(), 0, request.getLength());
                Integer intFib = Integer.parseInt(number);
                //System.out.println(number);

                for(int i=0; i<intFib; i++) {
                    String numToSend = new String(String.valueOf(nizFibonaci[i]));
                    bytesResp = numToSend.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket response = new DatagramPacket(bytesResp, bytesResp.length, request.getAddress(), request.getPort());
                    server.send(response);
                }
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

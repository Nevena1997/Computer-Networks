package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task1Main {

    public static List<Nit> niti = new ArrayList<>();
    public static int globalanZbir;

    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {

            System.out.println("Unesite prvu putanju: ");
            String pathPrvaStr = sc.nextLine();

            System.out.println("Unesite drugu putanju: ");
            String pathDrugaStr = sc.nextLine();

            globalanZbir = 0;

            try (BufferedReader inPrva = new BufferedReader(new InputStreamReader(new FileInputStream(pathPrvaStr)));
                BufferedReader inDruga = new BufferedReader(new InputStreamReader(new FileInputStream(pathDrugaStr)))) {

                String line;
                int brojVrstaPrva = 0;
                int brojVrstaDruga = 0;
                List<Integer> listNumPrva = new ArrayList<>();
                List<Integer> listNumDruga = new ArrayList<>();

                while((line = inPrva.readLine()) != null){
                    Scanner scLine = new Scanner(line);

                    if(line.trim().equalsIgnoreCase(""))
                        break;

                    while(scLine.hasNext()){
                        int number = scLine.nextInt();
                        listNumPrva.add(number);
                    }
                    brojVrstaPrva++;
                }

                while((line = inDruga.readLine()) != null){
                    Scanner scLine = new Scanner(line);

                    if(line.trim().equalsIgnoreCase(""))
                        break;

                    while(scLine.hasNext()){
                        int number = scLine.nextInt();
                        listNumDruga.add(number);
                    }
                    brojVrstaDruga++;
                }

               /* System.out.println(brojVrstaPrva + " " + brojVrstaDruga);
                for(int i : listNumPrva)
                    System.out.printf("%d ", i);
                System.out.println();
                for(int i : listNumDruga)
                    System.out.printf("%d ", i);
                */
                if(brojVrstaPrva != brojVrstaDruga){
                    System.err.println("Greska! Matrice se ne mogu pomnoziti!");
                    System.exit(1);
                }

                System.out.println("Prva matrica: ");
                int[][] matrixPrva = new int[brojVrstaPrva][brojVrstaPrva];
                for(int i=0; i<brojVrstaPrva; i++){
                    for(int j=0; j<brojVrstaPrva; j++){
                        matrixPrva[i][j] = listNumPrva.get(i * brojVrstaPrva + j);
                        System.out.printf("%d ", matrixPrva[i][j]);
                    }
                    System.out.println();
                }

                System.out.println("Druga matrica: ");
                int[][] matrixDruga = new int[brojVrstaDruga][brojVrstaDruga];
                for(int i=0; i<brojVrstaDruga; i++){
                    for(int j=0; j<brojVrstaDruga; j++){
                        matrixDruga[i][j] = listNumDruga.get(i * brojVrstaDruga + j);
                        System.out.printf("%d ", matrixDruga[i][j]);
                    }
                    System.out.println();
                }

                int[][] matrixRes = new int[brojVrstaPrva][brojVrstaPrva];

                for(int i=0; i<brojVrstaPrva; i++){
                    for(int j=0; j<brojVrstaPrva; j++){
                        Nit nit = new Nit(matrixPrva, matrixDruga, matrixRes, i, j, brojVrstaPrva);
                        nit.start();
                        niti.add(nit);
                    }
                }

                for(Nit n : niti){
                    n.join();
                }

                System.out.println("Rezultat: ");
                for(int i=0; i<brojVrstaPrva; i++){
                    for(int j=0; j<brojVrstaDruga; j++){
                        System.out.printf("%d ", matrixRes[i][j]);
                    }
                    System.out.println();
                }

                System.out.println("Globalan zbir: " + globalanZbir);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}

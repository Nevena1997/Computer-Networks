package task1;

public class Nit extends Thread{

    private int[][] matrixPrva;
    private int [][] matrixDruga;
    private int[][] matrixRes;
    private int i;
    private int j;
    private int n;

    public Nit(int[][] matrixPrva, int [][] matrixDruga, int[][] matrixRes, int i, int j, int n){
        this.matrixPrva = matrixPrva;
        this.matrixDruga = matrixDruga;
        this.matrixRes = matrixRes;
        this.i = i;
        this.j = j;
        this.n = n;
    }

    @Override
    public void run() {

        synchronized (this) {
            int sum = 0;

            for (int k = 0; k < n; k++) {
                sum += this.matrixPrva[i][k] * this.matrixDruga[k][j];
            }
            this.matrixRes[i][j] = sum;
            Task1Main.globalanZbir += sum;
        }
    }
}

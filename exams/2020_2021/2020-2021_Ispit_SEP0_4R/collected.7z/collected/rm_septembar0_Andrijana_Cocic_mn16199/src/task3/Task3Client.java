package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {

    public static void main(String[] args) {

        InetSocketAddress address = new InetSocketAddress("localhost", Task3Server.DEFAULT_PORT);
        try (SocketChannel client = SocketChannel.open(address);
             Scanner sc = new Scanner(System.in)) {

            ByteBuffer byteBuffer = ByteBuffer.allocate(4*4);

            while(true){

                System.out.println("Unesite koordinate: ");

                int x = sc.nextInt();
                int y = sc.nextInt();
                int z = sc.nextInt();
                int t = sc.nextInt();

                byteBuffer.putInt(x);
                byteBuffer.putInt(y);
                byteBuffer.putInt(z);
                byteBuffer.putInt(t);
                byteBuffer.flip();
                client.write(byteBuffer);

                byteBuffer.clear();
                if((client.read(byteBuffer)) == -1)
                    break;

                byteBuffer.flip();
                int result = byteBuffer.getInt();
                System.out.println(result);
                byteBuffer.clear();

            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

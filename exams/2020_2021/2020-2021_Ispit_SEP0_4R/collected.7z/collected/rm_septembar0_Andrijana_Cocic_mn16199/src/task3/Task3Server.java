package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Task3Server {

    public static int DEFAULT_PORT = 54321;

    public static void main(String[] args) {

        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if(!serverSocketChannel.isOpen() || !selector.isOpen()){
                System.err.println("Error!");
                System.exit(1);
            }

            serverSocketChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()){

                    SelectionKey key = it.next();
                    it.remove();

                    try {

                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            System.out.println("Client accepted!");

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer byteBuffer = ByteBuffer.allocate(4*4);
                            byteBuffer.clear();

                            clientKey.attach(byteBuffer);

                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer byteBuffer = (ByteBuffer) key.attachment();

                            client.read(byteBuffer);

                            if(!byteBuffer.hasRemaining()){
                                byteBuffer.flip();
                                int x = byteBuffer.getInt();
                                int y = byteBuffer.getInt();
                                int z = byteBuffer.getInt();
                                int t = byteBuffer.getInt();
                                //System.out.printf("%d %d %d %d\n",x,y,z,t);

                                if(x == 0 && y == 0 && z == 0 && t == 0){
                                    key.cancel();
                                    key.channel().close();
                                    break;
                                }

                                int povrsina = getPovrsina(x, y, z, t);
                                //System.out.println(povrsina);
                                byteBuffer.clear();
                                byteBuffer.putInt(povrsina);
                                byteBuffer.flip();
                                key.interestOps(SelectionKey.OP_WRITE);

                            }

                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer byteBuffer = (ByteBuffer) key.attachment();

                            client.write(byteBuffer);

                            if(!byteBuffer.hasRemaining()){
                                byteBuffer.clear();
                                key.interestOps(SelectionKey.OP_READ);
                            }
                        }
                    } catch (IOException e){
                        key.cancel();
                        key.channel().close();
                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static int getPovrsina(int x, int y, int z, int t) {

        int a = z - x;
        int b = y - t;

        return a * b;
    }
}

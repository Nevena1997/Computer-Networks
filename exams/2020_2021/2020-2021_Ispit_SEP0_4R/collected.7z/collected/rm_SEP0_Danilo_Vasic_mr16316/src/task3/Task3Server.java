package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Task3Server {
    public static void main(String[] args) {
        try(ServerSocketChannel ssc = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if(!ssc.isOpen()&& !selector.isOpen()){
                System.out.println("Server nije pokrenut");
                System.exit(0);
            }

            ssc.bind(new InetSocketAddress(54321));
            ssc.configureBlocking(false);
            ssc.register(selector , SelectionKey.OP_ACCEPT);
            selector.select();

            while(true){

                Set<SelectionKey> selectionKeys = selector.keys();
                Iterator<SelectionKey> it = selectionKeys.iterator();

                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if(key.isAcceptable()){

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            ByteBuffer bf = ByteBuffer.allocate(4*4);
                            key.attach(bf);
                            client.register(selector, SelectionKey.OP_READ);

                        }
                        else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer bf = (ByteBuffer) key.attachment();
                            bf.clear();
                            client.read(bf);
                            bf.flip();
                            int x1 = bf.getInt();
                            int y1 = bf.getInt();
                            int x2 = bf.getInt();
                            int y2 = bf.getInt();
                            int x = Math.abs(x1 -x2);
                            int y = Math.abs(y1-y2);
                            bf.putInt(x*y);
                            key.attach(bf);
                            client.register(selector, SelectionKey.OP_WRITE);

                        }
                        else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer bf = (ByteBuffer) key.attachment();
                            client.write(bf);
                            client.close();

                        }
                    } catch (Exception e) {
                        izbaciKlijenta(key);
                    }

                }




            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void izbaciKlijenta(SelectionKey key) throws IOException {
        key.cancel();
        key.channel().close();
    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        try(SocketChannel client = SocketChannel.open();
            Scanner sc = new Scanner(System.in)) {
            System.out.println("Unesite x osu");
            int x1 = sc.nextInt();
            System.out.println("Unesite y osu");
            int y1 = sc.nextInt();
            System.out.println("Unesite x osu");
            int x2 = sc.nextInt();
            System.out.println("Unesite y osu");
            int y2 = sc.nextInt();
            if(!client.isOpen()){
                System.out.println("Ne radi klijent");
                System.exit(0);
            }
            client.configureBlocking(true);
            client.connect(new InetSocketAddress(54321));
            ByteBuffer bf = ByteBuffer.allocate(4*4);
            bf.clear();
            bf.putInt(x1);
            bf.putInt(y1);
            bf.putInt(x2);
            bf.putInt(y2);
            bf.clear();
            client.write(bf);
            bf.clear();

            ByteBuffer bf1 = ByteBuffer.allocate(4);
            bf1.clear();
            client.read(bf1);
            bf1.clear();
            bf1.getInt();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Task1MainRunnable implements Runnable {
    public static int zbir = 0;
    private static int brojac = 0;
    private static int[][] matrica;
    private Lock lock = new ReentrantLock();
    private List<String[]> matrica1;
    private List<String[]> matrica2;
    private int n;


    public Task1MainRunnable(int n,List<String[]> matrica1,List<String[]> matrica2){
        matrica = new int[n][n];
        this.n = n;
        this.matrica1 = matrica1;
        this.matrica2 = matrica2;
    }

    @Override
    public void run() {
        lock.lock();
        int visina = brojac / n;
        int sirina = brojac % n;
        matrica[visina][sirina]=0;
        for(int i = 0; i< n;i++){
            matrica[visina][sirina]+= Integer.parseInt(matrica1.get(visina)[i])*Integer.parseInt(matrica2.get(i)[sirina]);
        }
        zbir+=matrica[visina][sirina];
        brojac++;
        lock.unlock();
//        System.out.println(zbir);
    }

    public void ispisiMatricu(){
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf(matrica[i][j]+" ");
            }
            System.out.println();
        }
    }
}

package task1;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Task1Main {
    private static List<String[]> Matrica1 = new ArrayList<>();
    private static List<String[]> Matrica2 = new ArrayList<>();
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String putanjaMatrice1 = sc.next();
        String putanjaMatrice2 = sc.next();
        sc.close();
        Path path1 = Paths.get(putanjaMatrice1);
        Path path2 = Paths.get(putanjaMatrice2);
        try(Scanner sc1 = new Scanner(path1);
        Scanner sc2 = new Scanner(path2)){
            while(sc1.hasNext()){
                String[] unetaVrednost = sc1.nextLine().split(" ");
                Matrica1.add(unetaVrednost);
            }
            for(String[] s : Matrica1){
                for(String s1 : s){
                    System.out.printf(s1+" ");
                }
                System.out.println();
            }
            System.out.println();
            while(sc2.hasNext()){
                String[] unetaVrednost = sc2.nextLine().split(" ");
                Matrica2.add(unetaVrednost);
            }
            for(String[] s : Matrica2){
                for(String s1 : s){
                    System.out.printf(s1+" ");
                }
                System.out.println();
            }
            if(Matrica1.size() != Matrica2.size()){
                System.out.println("Matrice se ne mogu pomnoziti");
                System.exit(0);
            }

            Task1MainRunnable izracunatiMatricu = new Task1MainRunnable(Matrica1.size(),Matrica1,Matrica2);
            for (int i = 0; i < Matrica1.size()*Matrica1.size(); i++) {
                new Thread(izracunatiMatricu).start();
            }
            System.out.println();

            izracunatiMatricu.ispisiMatricu();


        } catch (IOException e) {
            System.out.println("NIJE PRONADJEN FAJL");
        }

    }
}

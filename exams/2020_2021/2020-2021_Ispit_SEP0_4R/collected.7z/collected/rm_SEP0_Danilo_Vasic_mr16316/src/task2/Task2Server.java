package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class Task2Server {
    public static final int port = 12345;
    private static List<Integer> fibonacijevNiz = new ArrayList<Integer>(80);



    public static void main(String[] args) {
        izracunajFibonacijevNiz();
        try(DatagramSocket DS = new DatagramSocket(port)) {
            byte[] primljeniBajt = new byte[256];
            DatagramPacket receivedPacket = new DatagramPacket(primljeniBajt,0,primljeniBajt.length);
            DS.receive(receivedPacket);
            System.out.println("Primljen Paket "+receivedPacket.toString());
            //Ne znam kako da konvertiram receivedPacket;
            //pa je primljeni broj zamena za to
            int PRIMLJENIBROJ= 10;


            for (int i = 0; i < PRIMLJENIBROJ; i++) {
                DatagramPacket sendPacket = new DatagramPacket((fibonacijevNiz.get(i)+"").getBytes(),0,receivedPacket.getAddress(),receivedPacket.getPort());
                DS.send(sendPacket);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void izracunajFibonacijevNiz() {
        fibonacijevNiz.add(0);
        fibonacijevNiz.add(1);
        for (int i = 2; i < 80; i++) {
            fibonacijevNiz.add(fibonacijevNiz.get(i-1)+fibonacijevNiz.get(i-2));
        }
    }
}

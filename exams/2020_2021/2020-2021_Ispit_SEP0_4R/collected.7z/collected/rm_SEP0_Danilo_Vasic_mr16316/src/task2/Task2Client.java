package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {
        try(DatagramSocket DS = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            String unetiBroj = sc.next();
//            byte[] bajtBroj = new byte[4];
            byte[] bajtBroj = unetiBroj.getBytes();
//            System.out.println(bajtBroj.toString());
            InetAddress add = InetAddress.getByName("localhost");
            DatagramPacket sendPacket = new DatagramPacket(bajtBroj,bajtBroj.length,add,Task2Server.port);
            DS.send(sendPacket);

            int POSLATIBROJ = 10;
            byte[] primljeniBroj = new byte[8];
            //Ne znam kako da konvertiram receivedPacket;
            //pa je primljeni broj zamena za to

            for (int i = 0; i < POSLATIBROJ; i++) {
                DatagramPacket receivedPacket = new DatagramPacket(primljeniBroj,primljeniBroj.length);
                DS.receive(receivedPacket);
                System.out.println(primljeniBroj.toString());
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

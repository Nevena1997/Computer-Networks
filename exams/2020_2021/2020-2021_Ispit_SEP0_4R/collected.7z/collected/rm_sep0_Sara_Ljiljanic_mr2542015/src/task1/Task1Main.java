package task1;

import java.io.*;
import java.nio.Buffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

        //zadaje se putanja do fajlova sa standardnog ulaza
        Scanner scener = new Scanner(System.in);

        System.out.println("Unesite putanju do fajlova u kojima se nalaze matrice: ");
        String putanja = scener.nextLine();

        //sada pravim putanju
        Path path = Paths.get(putanja);

        //treba da se ucitaju matrice iz fajlova koje treba da se mnoze
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)))) {
            while (true) {

                String line = in.readLine();
                if (line == null)
                    break;

                DirectoryStream<Path> ds = Files.newDirectoryStream(path);

            }

        } catch (FileNotFoundException e) {
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

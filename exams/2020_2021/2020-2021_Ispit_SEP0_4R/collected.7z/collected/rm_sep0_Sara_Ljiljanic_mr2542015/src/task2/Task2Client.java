package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {

        try (DatagramSocket klijent = new DatagramSocket()) {

            Scanner sc = new Scanner(System.in);
            System.out.println("Koji broj saljes serveru?");
            int broj = sc.nextInt();

            //klijent serveru salje prirodni broj ne veci od 80
            if (broj <= 0 || broj > 80) {
                System.err.println("Broj nije u odgovarajucem intervalu.");
                return;
            }

            //prvo nesto saljemo serveru
            String slanje = "poruka";
            byte[] slanjeBytes = slanje.getBytes(StandardCharsets.UTF_8);
            DatagramPacket slanjePaket = new DatagramPacket(slanjeBytes, slanjeBytes.length, InetAddress.getByName("localhost"), Task2Server.PORT);
            klijent.send(slanjePaket);

            //primamo potvrdu o slanju
            byte[] potvrdaBytes = new byte[4];
            DatagramPacket prijem = new DatagramPacket(potvrdaBytes, potvrdaBytes.length);
            String prijemString = new String(prijem.getData());


        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package task2;

import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

public class Task2Server {

    //aplikacija koja ima ulogu udp servera
    //osluskuje na portu 12321
    //velicina svakog datagrama koji dobije od klijenta je 4b
    //kada datagram stigne postati poruku da je stigao

    public static int PORT = 12321;

    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(PORT)) {

            //prvo treba da se primi paket od klijenta
            byte[] prijem = new byte[4];
            DatagramPacket prijemPaket = new DatagramPacket(prijem, prijem.length);
            String prijemstring = new String(prijemPaket.getData());
            int broj = 10;

            //salje se potvrda o prijemu paketa od klijenta
            /*String poruka = "Stigao je datagram";
            byte[] slanje = poruka.getBytes(StandardCharsets.UTF_8);
            DatagramPacket slanjePaket = new DatagramPacket(slanje, slanje.length, prijemPaket.getAddress(), prijemPaket.getPort());
            */
            System.out.println("Stigao je datagram");



           /*
            for (int i = 0; i < broj; i++) {
                System.out.println(Fibonaci(i));
            }
            */

        } catch (SocketException e) {
            e.printStackTrace();
        }

    }

    public static int Fibonaci(int n) {

        if (n == 0 || n == 1)
            return n;
        else
            return Fibonaci(n-1) - Fibonaci(n-2);
    }

}

package task3;

public class Task3Server {
    public static void main(String[] args) {
        System.out.println("Hello!");
    }
}

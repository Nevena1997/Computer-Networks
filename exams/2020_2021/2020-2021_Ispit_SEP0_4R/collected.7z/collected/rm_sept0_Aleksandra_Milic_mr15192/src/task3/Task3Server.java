package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Task3Server {

    public static int PORT_SERVER = 54321;

    public static void main(String[] args) {

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            if (!serverChannel.isOpen() || !selector.isOpen()) {
                System.err.println("Server channel or selector can't be opened!");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT_SERVER));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();
                Set<SelectionKey> readyKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = readyKeys.iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);

                        ByteBuffer buffer = ByteBuffer.allocate(4*4);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                        clientKey.attach(buffer);

                    } else if(key.isWritable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        buffer.flip();
                        client.write(buffer);
                        buffer.clear();

                        key.interestOps(SelectionKey.OP_READ);

                    } else if(key.isReadable()) {
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();

                        client.read(buffer);
                        if (!buffer.hasRemaining()) { //ako smo procitali sva 4 broja koja nam je klijent poslao
                            //dohvatamo ih i racunamo duzinu stranica i povrsinu
                            buffer.flip();
                            int x1 = buffer.getInt();
                            int y1 = buffer.getInt();
                            int x2 = buffer.getInt();
                            int y2 = buffer.getInt();

                           /* if (x1 == 0 && y1 == 0 && x2 == 0 && y2 == 0) {
                                key.channel();
                                key.channel().close();
                            }*/

                            int sirina = x2 - x1;
                            int visina = y1 - y2;
                            int povrsina = sirina * visina;
                            buffer.clear();
                            buffer.putInt(povrsina);
                            //System.out.println(povrsina);
                        }
                        key.interestOps(SelectionKey.OP_WRITE);
                    }
                } //end while(it.hasNext())

            } //end while(true)

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

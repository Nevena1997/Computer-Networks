package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.PORT_SERVER));
            Scanner sc = new Scanner(System.in)) {

            int broj;

            ByteBuffer buffer = ByteBuffer.allocate(4*4);

            while (true) {

                for (int i = 0; i < 4; i++) {
                    broj = sc.nextInt();
                    buffer.putInt(broj);
                }
                buffer.flip();
                client.write(buffer);
                buffer.clear();

                //sada klijent ceka odgovo

                client.read(buffer);
                buffer.flip();
                int povrsina = buffer.getInt();
                System.out.println(povrsina);
                buffer.clear();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

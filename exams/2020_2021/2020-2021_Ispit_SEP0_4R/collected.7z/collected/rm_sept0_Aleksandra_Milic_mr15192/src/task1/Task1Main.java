package task1;

import java.io.*;
import java.util.Scanner;

public class Task1Main {
    public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            String file1 = sc.next();
            String file2 = sc.next();
            sc.close();

           //int n = ucitajMatricu(file1);
            try(BufferedReader in1 = new BufferedReader(new InputStreamReader(new FileInputStream(file1)));
            BufferedReader in2 = new BufferedReader(new InputStreamReader(new FileInputStream(file2))) ) {

                //raciunam dimenzije matrica, kvadratne su pa cu prebrojati linije u fajlu
                String line;
                int n1 = 0;
                while ((line = in1.readLine()) != null)
                    n1++;

                int[][] matrix1 = new int[n1][n1];

                //while ((line = in1.readLine()) != null) {
                    for (int i = 0; i < n1; i++) {
                        line = in1.readLine();
                        for (int j = 0; j < n1; j++) {
                            String[] brojevi = line.trim().split(" ");
                            matrix1[i][j] = Integer.parseInt(brojevi[j]);
                        }
                    }
                //}

                //ispis matrice
                for (int i = 0; i < n1; i++) {
                    for (int j = 0; j < n1; j++) {
                        System.out.print(matrix1[i][j] + " ");
                    }
                    System.out.println();
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
}

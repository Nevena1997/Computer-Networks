package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            //System.out.printf("Unesite broj: ");
            String numString = sc.next();

            InetAddress addr = InetAddress.getByName("localhost");
            byte[] sendBytes = numString.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length,
                    addr, Task2Server.PORT_SERVER);
            client.send(sendPacket);
            //broj smo posalai kao string, pa to treba konvertovati u int na strani servera

            while (true) {
                //primanje odgovora od servera, parsiranje u int i ispis na izlaz
                byte[] receivedBytes = new byte[Task2Server.MAX_BUFF];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
                client.receive(receivedPacket);

                String receivedString = new String(receivedPacket.getData(), 0, receivedPacket.getLength());
                int receivedInt = Integer.parseInt(receivedString);
                System.out.println(receivedInt);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

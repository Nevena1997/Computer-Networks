package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

public class Task2Server {
    public static int PORT_SERVER = 12345;
    public static int MAX_BUFF = 512;
    private static int[] Fibonaci = fibonaci(80);

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT_SERVER)) {

            byte[] receivedBytes = new byte[MAX_BUFF];
            DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
            server.receive(receivedPacket);
            String receivedString = new String(receivedPacket.getData(), 0, receivedPacket.getLength());

            int n = Integer.parseInt(receivedString);
            //System.out.printf("Klijent mi je posalo broj: " + n);

            if (n <= 80) {
                //Fibonaci = fibonaci(n);
               for (int i = 0; i < n; i++) {
                   int sendInt = Fibonaci[i];
                   //System.out.println(sendInt);
                   String sendString = String.valueOf(sendInt);

                   //slacu broj kao string, ali na strani klijenta cu parsirati u int
                   byte[] sendByte = sendString.getBytes();
                   DatagramPacket sendPacket = new DatagramPacket(sendByte, sendByte.length, receivedPacket.getAddress(), receivedPacket.getPort());
                   server.send(sendPacket);
               }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static int[] fibonaci(int n) {
        int[] fibonaciNiz = new int[n];
        fibonaciNiz[0] = 0;
        fibonaciNiz[1] = 1;

        for (int i = 2; i < n; i++)
            fibonaciNiz[i] = fibonaciNiz[i-1] + fibonaciNiz[i-2];

        return fibonaciNiz;
    }
}

package task1;

public class ThreadMultiply implements Runnable {


    private int i;
    private int j;

    public ThreadMultiply(int i, int j)
    {
        this.i = i;
        this.j = j;


    }


    @Override
    public void run()
    {

    }

}

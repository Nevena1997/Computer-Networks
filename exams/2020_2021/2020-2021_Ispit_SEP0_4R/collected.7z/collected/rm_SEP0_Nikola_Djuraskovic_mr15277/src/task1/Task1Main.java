package task1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Task1Main {

    public static int [][] matrix1;
    public static int [][] matrix2;


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String path1 = sc.nextLine();
        String path2 = sc.nextLine();

        sc.close();

        Path p1 = Paths.get(path1);
        Path p2 = Paths.get(path2);

        try (Scanner sc1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p1.toString()))));
             Scanner sc2 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p2.toString()))));) {

            while(sc1.hasNextLine())
                System.out.println(sc1.nextLine());
            System.out.println();
            while(sc2.hasNextLine())
                System.out.println(sc2.nextLine());




        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try (Scanner sc1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p1.toString()))));
             Scanner sc2 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p2.toString()))));) {

            int m1 = 0;
            int m2 = 0;


                while(sc1.hasNextInt()) {
                    m1++;
                    sc1.nextInt();
                }


                while(sc2.hasNextInt()) {
                    m2++;
                    sc2.nextInt();
                }


            //System.out.println("m1: " + m1 + " m2:" + m2);

            if(m1 != m2)
            {
                System.err.println("Matrice se ne mogu mnoziti.");
                System.exit(1);

            }

            double N = m1;

            int n = (int) Math.sqrt(N);

            //System.out.println(n);

            matrix1 = new int[n][n];
            matrix2 = new int[n][n];

            try (Scanner sc3 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p1.toString()))));
                Scanner sc4 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p2.toString()))));) {


                for(int i = 0; i < n; i++)
                {
                    for(int j = 0; j < n; j++)
                    {
                        matrix1[i][j] = sc3.nextInt();
                        matrix2[i][j] = sc4.nextInt();
                    }
                }

            }


            for(int i = 0; i < n; i++)
            {
                for(int j = 0; j < n; j++)
                {
                    ThreadMultiply tm = new ThreadMultiply(i,j);
                    new Thread(tm).start();
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }



}

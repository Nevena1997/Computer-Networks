package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

public class Task2Server {

    public static final int PORT = 12345;



    public static void main(String[] args) {

        long [] numbers = new long[80];


        try (DatagramSocket server = new DatagramSocket(PORT)) {

            numbers[0] = 0;
            numbers[1] = 1;

            for(int i = 2; i < 80; i++)
            {
                numbers[i] = numbers[i-2] + numbers[i-1];

            }



            while(true) {

                byte[] buff = new byte[4];
                DatagramPacket request = new DatagramPacket(buff, 4);
                server.receive(request);

                System.out.println("Stigao datagram!");

                int n = Integer.parseInt(new String(request.getData(), 0, request.getLength(), StandardCharsets.US_ASCII));

                //System.out.println(n);


                byte[] buff2 = new byte[8];
                int i = 0;
                while (i < n) {

                    //int fib = fibonacci(i);

                    long fib = numbers[i];

                    String fibString = String.valueOf(fib).trim();

                    buff2 = fibString.getBytes(StandardCharsets.US_ASCII);

                    DatagramPacket response = new DatagramPacket(buff2, buff2.length, request.getAddress(), request.getPort());

                    server.send(response);

                    i++;
                }

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static int fibonacci(int n)
    {
        if( n == 0 || n == 1)
            return n;
        else
            return fibonacci(n-1) + fibonacci(n-2);
    }
}

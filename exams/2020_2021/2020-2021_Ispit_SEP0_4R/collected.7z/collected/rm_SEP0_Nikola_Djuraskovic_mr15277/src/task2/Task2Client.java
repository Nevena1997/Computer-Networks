package task2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Task2Client {
    public static void main(String[] args) {

        //ctr+q dokumentacija



        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in);) {

            int num = sc.nextInt();

            String numString = String.valueOf(num).trim();

            byte [] buff = new byte[4];
            buff = numString.getBytes(StandardCharsets.US_ASCII);
            InetAddress adr = InetAddress.getLocalHost();


            DatagramPacket request = new DatagramPacket(buff, buff.length, adr, Task2Server.PORT);
            client.send(request);

            int i = 0;

            byte [] buff2 = new byte[1024];

            while(i < num) {

                DatagramPacket response = new DatagramPacket(buff2, buff2.length);
                client.receive(response);

                String fibString = new String(response.getData(), 0, response.getLength(), StandardCharsets.US_ASCII);

                System.out.println(fibString);

                i++;
            }



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Task3Client {

    public static void main(String[] args) {

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Task3Server.PORT));
             Scanner sc = new Scanner(System.in);) {


            ByteBuffer buffer = ByteBuffer.allocate(4*4);

            int x1,x2;
            int y1,y2;

            while(true)
            {

                x1 = sc.nextInt();
                x2 = sc.nextInt();
                y1 = sc.nextInt();
                y2 = sc.nextInt();

                if(x1 == 0 && x2 == 0 && y1 == 0 && y2 == 0)
                {
                    client.close();
                    break;
                }


                buffer.putInt(x1);
                buffer.putInt(x2);
                buffer.putInt(y1);
                buffer.putInt(y2);

                buffer.flip();

                client.write(buffer);

                buffer.clear();

                client.read(buffer);

                buffer.flip();

                int povrsina = buffer.getInt();

                System.out.println(povrsina);

                buffer.clear();

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

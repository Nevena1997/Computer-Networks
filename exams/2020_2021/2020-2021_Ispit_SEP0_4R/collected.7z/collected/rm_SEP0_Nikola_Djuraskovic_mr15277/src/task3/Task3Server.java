package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Task3Server {

    public static final int PORT = 54321;



    public static void main(String[] args) {


        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();) {

            if(!serverChannel.isOpen() || !selector.isOpen())
            {
                System.err.println("Server Channel or Selector isn't open!");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true)
            {

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()) {

                    SelectionKey key = it.next();

                    it.remove();

                    try {

                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(4 * 4);

                            clientKey.attach(buffer);


                        } else if (key.isReadable()) {

                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.read(buffer);

                            if (!buffer.hasRemaining()) {
                                buffer.flip();
                                int x1 = buffer.getInt();
                                int x2 = buffer.getInt();
                                int y1 = buffer.getInt();
                                int y2 = buffer.getInt();

                                if(x1 == 0 && x2 == 0 && y1 == 0 && y2 == 0)
                                {
                                    key.cancel();
                                    key.channel().close();
                                    break;
                                }

                                int a = x2 - y2;
                                int b = y1 - x1;
                                int povrsina = a * b;

                                buffer.clear();
                                buffer.putInt(povrsina);
                                buffer.flip();

                            }

                            key.interestOps(SelectionKey.OP_WRITE);

                        } else if (key.isWritable()) {

                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            client.write(buffer);

                            buffer.clear();

                            key.interestOps(SelectionKey.OP_READ);

                        }

                    } catch (Exception e){
                        key.cancel();

                        try {
                            key.channel().close();
                        } catch (IOException e2)
                        {
                            e2.printStackTrace();
                        }
                    }

                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

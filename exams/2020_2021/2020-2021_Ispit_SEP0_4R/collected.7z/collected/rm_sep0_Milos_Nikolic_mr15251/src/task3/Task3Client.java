package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class Task3Client {
    public static void main(String[] args) {
        int port = Task3Server.DEFAULT_PORT;
        String host="localhost";
        InetSocketAddress adress = new InetSocketAddress(host,port);

        try {
            SocketChannel client = SocketChannel.open(adress);

            client.configureBlocking(true);
            Scanner sc = new Scanner(System.in);
            System.err.println("connected!");
            ByteBuffer buffer = ByteBuffer.allocate(5);
            WritableByteChannel out = Channels.newChannel(System.out);
            for(int i=0;i<4;i++){
                int a =sc.nextInt();

                buffer.put((byte) a);
                buffer.rewind();
            }
            out.write(buffer);
            client.write(buffer);
            sc.close();
            client.close();
            System.err.println("disconnected!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

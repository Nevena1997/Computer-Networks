package task3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.Set;

public class Task3Server {
    public static int DEFAULT_PORT=54321;
    public static void main(String[] args) {
        try {
            ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
            if(!serverChannel.isOpen() || !selector.isOpen())
                System.err.println("error");


            SocketAddress adress = new InetSocketAddress(DEFAULT_PORT);
            serverChannel.bind(adress);
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();

                Set<SelectionKey>readyKeys=selector.selectedKeys();
                Iterator<SelectionKey>it=readyKeys.iterator();

                while(it.hasNext()){
                    SelectionKey key=it.next();
                    it.remove();


                    if(key.isAcceptable()){
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();
                        SelectionKey clientKey=client.register(selector,SelectionKey.OP_WRITE);
                        ByteBuffer buffer=ByteBuffer.allocate(5);
                        clientKey.attach(buffer);

                    }
                    if(key.isWritable()){

                        //ByteBuffer buffer = (ByteBuffer) key.attachment();



                    }

                    //client.write(buffer);

                }



            }


        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

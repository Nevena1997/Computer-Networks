package task2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Task2Server {
    public static int DEFAULT_PORT=12345;
    public static int BUF_SIZE=8;
    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)) {
            while(true) {
                byte[] receivedBytes = new byte[BUF_SIZE];
                DatagramPacket receivedPacket = new DatagramPacket(receivedBytes, receivedBytes.length);
                server.receive(receivedPacket);
                if (receivedBytes.length == 4)
                    System.err.println("Stigao Datagram");

                byte[] sendBytes = new byte[BUF_SIZE];
                receivedBytes = receivedPacket.getData();
                String receivedString = receivedBytes.toString();
                System.out.println(receivedString);
                Integer receivedInt = Integer.getInteger(receivedString);
                System.out.println(receivedInt);
                int[] niz = new int[receivedInt+1];
                niz[0]=0;
                Integer prvi=niz[0];
                String sendString1= prvi.toString();
                sendBytes = sendString1.getBytes();
                DatagramPacket sendPacket1 = new DatagramPacket(sendBytes, sendBytes.length, receivedPacket.getAddress(), receivedPacket.getPort());
                server.send(sendPacket1);
                niz[1]=1;
                Integer drugi=niz[1];
                String sendString2= drugi.toString();
                sendBytes = sendString2.getBytes();
                DatagramPacket sendPacket2 = new DatagramPacket(sendBytes, sendBytes.length, receivedPacket.getAddress(), receivedPacket.getPort());
                server.send(sendPacket2);

                for(int i=2;i<receivedInt;i++) {
                    niz[i]=niz[i-1]+niz[i-2];
                    Integer fib= niz[i];
                    String sendString= fib.toString();
                    sendBytes = sendString.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, receivedPacket.getAddress(), receivedPacket.getPort());
                    server.send(sendPacket);
                }




            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package task2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Task2Client {
    public static int clientBufSize=4;
    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            while(true) {
                byte[] sendBytes = new byte[clientBufSize];
                Integer nextInt=sc.nextInt();
                if(nextInt > 80){
                    break;
                }
                String toString = nextInt.toString();
                sendBytes = toString.getBytes();
                InetAddress address = InetAddress.getByName("localhost");
                DatagramPacket sendPacket = new DatagramPacket(sendBytes,sendBytes.length,address, Task2Server.DEFAULT_PORT);
                client.send(sendPacket);

                byte[] recievedBytes = new byte[Task2Server.BUF_SIZE];
                DatagramPacket receivedPacket = new DatagramPacket(recievedBytes,recievedBytes.length);
                client.receive(receivedPacket);
                recievedBytes = receivedPacket.getData();
                String receivedString = recievedBytes.toString();
                Integer receivedInt = Integer.getInteger(receivedString);
                System.out.println(receivedInt);




            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

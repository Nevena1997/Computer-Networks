package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;


public class IOThread extends Thread {
    private int PORT = 12345;
    private UDPServer server;

    public IOThread(UDPServer udpServer) {
        this.server = udpServer;
    }

    @Override
    public void run() {
        try (DatagramSocket ds = new DatagramSocket(PORT)) {
            // RECEIVE
            var buffReq = new byte[256];
            DatagramPacket request = new DatagramPacket(buffReq, buffReq.length);
            ds.receive(request);
            var resBuff = ByteBuffer.wrap(request.getData());
            resBuff.rewind();
            var acc_num = String.valueOf(resBuff);
            Double amount = this.server.getAmount(acc_num);

            // SEND
            var bb = ByteBuffer.allocate(256);
            bb.putDouble(amount);
            bb.flip();
            var buffRes = bb.array();
            DatagramPacket response = new DatagramPacket(buffRes, buffRes.length, ds.getLocalAddress(), PORT);
            ds.send(response);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.util.Scanner;

public class InputThread extends Thread {
    private UDPServer server;

    public InputThread(UDPServer server) {
        this.server = server;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(System.in)) {
            if (sc.hasNext()) {
                String new_acc = sc.next();
                if (sc.hasNextDouble()) {
                    double new_amount = sc.nextDouble();
                    this.server.addAccount(new_acc, new_amount);
                }
            }
        }
    }
}

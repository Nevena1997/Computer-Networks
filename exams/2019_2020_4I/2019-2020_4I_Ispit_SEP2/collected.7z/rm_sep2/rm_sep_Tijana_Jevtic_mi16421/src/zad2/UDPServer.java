package zad2;

import java.util.HashMap;

public class UDPServer {
    private HashMap<String, Double> accounts;

    public  Double getAmount(String account) {
        return accounts.getOrDefault(account, -1.0);
    }

    public void addAccount(String account, Double amount) {
        accounts.put(account, amount);
    }

    UDPServer() {
        accounts = new HashMap<>();
        new InputThread(this).start();
        new IOThread(this).start();
    }

    public static void main(String[] args) {
        new UDPServer();
    }
}

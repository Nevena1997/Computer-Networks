package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;

import static java.net.InetAddress.getLocalHost;

public class UDPClient {

    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket()) {
            // Send data
            var buffReq = new byte[256];
            String acc_number = "427894278942";
            buffReq = acc_number.getBytes();
            int PORT = 12345;
            DatagramPacket response = new DatagramPacket(buffReq, buffReq.length, getLocalHost(), PORT);
            client.send(response);

            // Get data
            var buff = new byte[256];
            DatagramPacket request = new DatagramPacket(buff, buff.length);
            client.receive(request);
            var resBuff = ByteBuffer.wrap(request.getData());
            resBuff.rewind();
            var amount = resBuff.getDouble();
            if (amount == -1.0) {
                System.out.println("-1");
            } else {
                System.out.println(amount);
            }
            resBuff.flip();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashSet;

public class BankServer {
    private static HashSet<String> clients;
    private static int PORT  = 12221;

    public static void main(String[] args) {

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            clients = new HashSet<>();

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                var keys = selector.selectedKeys();
                var it = keys.iterator();
                while (it.hasNext()) {
                    var key = it.next();
                    it.remove();

                    if (key.isAcceptable()) {
                        try (ServerSocketChannel cChannel = (ServerSocketChannel) key.channel()) {
                            SocketChannel sc = cChannel.accept();
                            ByteBuffer buff = ByteBuffer.allocate(256);
                            sc.read(buff);
                            clients.add(String.valueOf(buff.get()));
                        }
                    } else if (key.isReadable()) {

                    } else if (key.isWritable()) {

                    }
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {

    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open();
        Scanner sc = new Scanner(System.in)) {
            client.connect(new InetSocketAddress(12221));
            // Salje svoj broj racuna
            var buff = ByteBuffer.allocate(256);
            String acc_number = "3245355353";
            buff.put(acc_number.getBytes());
            buff.flip();
            client.write(buff);

            // Cita listu povezanih
            var connected_users = ByteBuffer.allocate(1024);
            client.read(connected_users);
            while (!connected_users.hasRemaining()) {
                connected_users.rewind();
                System.out.println(connected_users);
                //connected_users.flip();
            }

            // Ucitava i salje
            String send_acc_number = sc.nextLine();
            int amount = sc.nextInt();
            var buffSend = ByteBuffer.allocate(256);
            buffSend.rewind();
            buffSend.put(send_acc_number.getBytes());
            buffSend.putInt(amount);
            buffSend.flip();
            client.write(buffSend);

            // potvrda 1
            var buff_approve_1 = ByteBuffer.allocate(128);
            client.read(buff_approve_1);
            buff_approve_1.rewind();
            System.out.println(String.valueOf(buff_approve_1.get()));

            // potvrda 2
            var buff_approve_2 = ByteBuffer.allocate(128);
            client.read(buff_approve_2);
            buff_approve_2.rewind();
            System.out.println(String.valueOf(buff_approve_2.get()));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

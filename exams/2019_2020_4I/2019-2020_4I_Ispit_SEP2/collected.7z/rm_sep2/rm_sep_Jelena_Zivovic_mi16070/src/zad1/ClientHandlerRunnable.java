package zad1;

import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class ClientHandlerRunnable implements Runnable {

    private SocketChannel client;

    public ClientHandlerRunnable(SocketChannel client) {
        this.client = client;
    }

    @Override
    public void run() {
        //System.out.println("Handling client: " + Thread.currentThread());


        ByteBuffer buffer = ByteBuffer.allocate(100);

        try {
            this.client.read(buffer);

            String data = (new String(buffer.array())).trim();
            //System.out.println("Client sent: " + data);

            BankServer.sviPoslatiRacuni.add(data);
            BankServer.klijenti.put(data, this.client);

            for (String racun : BankServer.sviPoslatiRacuni) {

                //System.out.println(racun);
                buffer = ByteBuffer.wrap(racun.getBytes());
                this.client.write(buffer);
                buffer.flip();
            }

            //buffer.flip();
            ByteBuffer novi = ByteBuffer.allocate(50);
            this.client.read(novi);

            String dataFromClient = (new String(novi.array())).trim();

            //System.out.println(dataFromClient);

            String[] parts = dataFromClient.split(",");

            if (parts.length == 2) {
                String dataToSend = "Transfer na racun " + parts[0] + " (" + parts[1] + ") je uspesno izvrsen";
                novi = ByteBuffer.wrap(dataToSend.getBytes());
                this.client.write(novi);

                SocketChannel primalac = BankServer.klijenti.get(parts[0]);

                if (primalac == null || !primalac.isConnected()){
                    dataToSend = "Primalac nije pronadjen";
                    novi = ByteBuffer.wrap(dataToSend.getBytes());
                    this.client.write(novi);
                }
                else {
                    dataToSend = "Primljeno " + parts[1] + " od " + parts[0];
                    novi = ByteBuffer.wrap(dataToSend.getBytes());
                    primalac.write(novi);
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

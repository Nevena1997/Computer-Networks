package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {

        //System.out.println("BankClient");

        InetSocketAddress address = new InetSocketAddress("localhost", 12221);

        try (SocketChannel client = SocketChannel.open(address);
             Scanner sc = new Scanner(System.in)) {

            //System.out.println("Unesite broj racuna:");
            String brojRacuna = sc.nextLine();

            //System.out.println(brojRacuna);
            ByteBuffer buffer;
            buffer = ByteBuffer.wrap(brojRacuna.getBytes());
            client.write(buffer);
            buffer.flip();
            buffer.rewind();

            while (true) {

                int n = client.read(buffer);
                //buffer.flip();
                //System.out.println(n);
                if (n <= 0) {
                    break;
                }
                String dataFromServer = (new String(buffer.array())).trim();
                System.out.println(dataFromServer);
            }

            String brojDrugogRacuna = sc.nextLine();

            int iznos = sc.nextInt();

            //System.out.println(brojDrugogRacuna);
            //System.out.println(iznos);

            while (true) {
                if (brojDrugogRacuna.equals("")) {
                    buffer = ByteBuffer.wrap(String.valueOf(iznos).getBytes());
                    client.write(buffer);
                }
                else {
                    //System.out.println(brojDrugogRacuna + " " + iznos);
                    buffer = ByteBuffer.wrap((brojDrugogRacuna + "," + iznos).getBytes());
                    client.write(buffer);
                    buffer.flip();
                    ByteBuffer nekiBafer = ByteBuffer.allocate(100);
                    client.read(nekiBafer);
                    System.out.println(
                            (new String(nekiBafer.array())).trim()
                    );

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

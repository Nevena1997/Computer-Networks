package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class BankServer {

    public static List<String> sviPoslatiRacuni = new LinkedList<>();
    public static Map<String, SocketChannel> klijenti = new HashMap<>();

    public static void main(String[] args) {

        //System.out.println("BankServer");

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            serverChannel.bind(new InetSocketAddress(12221));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                //System.out.println("Listening for clients...");

                selector.select();

                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()) {

                    SelectionKey key = iterator.next();
                    iterator.remove();

                    if (key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel) key.channel();
                        SocketChannel client = server.accept();

                        //System.out.println("Client accepted...");

                        Thread t = new Thread(new ClientHandlerRunnable(client));
                        t.start();


                    }

                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

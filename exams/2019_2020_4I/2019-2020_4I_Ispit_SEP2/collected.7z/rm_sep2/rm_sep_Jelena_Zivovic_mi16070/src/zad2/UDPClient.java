package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        //System.out.println("UDPClient");

        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            InetAddress address = InetAddress.getByName("localhost");

            String brojRacuna = sc.nextLine();

            DatagramPacket request = new DatagramPacket(brojRacuna.getBytes(), brojRacuna.getBytes().length, address, 12345);
            client.send(request);

            DatagramPacket response = new DatagramPacket(new byte[1024], 1024);
            client.receive(response);

            double iznos = Double.parseDouble(new String(response.getData(), 0, response.getLength()));

            System.out.println(iznos);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

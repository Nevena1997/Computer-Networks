package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class SlanjePrimanjeDatagramRunnable implements Runnable{

    private DatagramSocket server;

    public SlanjePrimanjeDatagramRunnable(DatagramSocket server) {
        this.server = server;
    }

    @Override
    public void run() {
        try {

            while (true) {
                DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
                this.server.receive(request);

                String brojRacuna = new String(request.getData(), 0,request.getLength());

                if (UDPServer.aktivniRacuni.containsKey(brojRacuna)) {
                    byte[] dataToSend = String.valueOf(UDPServer.aktivniRacuni.get(brojRacuna)).getBytes();
                    DatagramPacket response = new DatagramPacket(
                            dataToSend,
                            dataToSend.length,
                            request.getAddress(),
                            request.getPort()
                    );
                    this.server.send(response);
                }
                else {
                    byte[] dataToSend = String.valueOf(-1).getBytes();
                    DatagramPacket response = new DatagramPacket(
                            dataToSend,
                            dataToSend.length,
                            request.getAddress(),
                            request.getPort()
                    );
                    this.server.send(response);
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

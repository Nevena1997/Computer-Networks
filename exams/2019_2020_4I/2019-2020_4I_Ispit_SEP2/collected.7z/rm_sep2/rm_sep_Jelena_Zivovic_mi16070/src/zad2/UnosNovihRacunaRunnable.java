package zad2;

import java.util.Scanner;

public class UnosNovihRacunaRunnable implements Runnable{


    @Override
    public void run() {

        try (Scanner sc = new Scanner(System.in)) {
            while (true) {
                String line = sc.nextLine();
                String brojRacuna = line.split(" ")[0];
                double iznos = Double.parseDouble(line.split(" ")[1]);
                UDPServer.aktivniRacuni.put(brojRacuna, iznos);
            }
        }

    }
}

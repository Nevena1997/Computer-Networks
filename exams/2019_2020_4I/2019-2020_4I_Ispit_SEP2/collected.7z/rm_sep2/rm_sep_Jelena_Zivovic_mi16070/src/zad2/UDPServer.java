package zad2;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static Map<String, Double> aktivniRacuni = new HashMap<>();

    public static void main(String[] args) {

        //System.out.println("UDPServer");

        try  {

            DatagramSocket server = new DatagramSocket(12345);

            Thread t1 = new Thread(new UnosNovihRacunaRunnable());
            t1.start();

            Thread t2 = new Thread(new SlanjePrimanjeDatagramRunnable(server));
            t2.start();





        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

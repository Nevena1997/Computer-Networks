package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");

        try {
            InetSocketAddress address = new InetSocketAddress(BankServer.host, BankServer.PORT);
            SocketChannel socket = SocketChannel.open(address);

            Scanner sc = new Scanner(System.in);
            int accountId = sc.nextInt();
            ByteBuffer buff = ByteBuffer.allocate(4).putInt(accountId).flip();
            socket.write(buff);
            buff.clear();

            while (true) {
                int n = socket.read(buff);
                if (n > 0) {
                    int id = buff.flip().getInt();
                    buff.clear();
                    if (id == -1){
                        break;
                    }
                    System.out.println(id);
                } else if (n == -1) {
                    socket.close();
                    return;
                }
            }

            System.out.println();
            String line = sc.nextLine();
            line = sc.nextLine();
            Pattern p1 = Pattern.compile("^([0-9]+) ([0-9]+)$");
            Pattern p2 = Pattern.compile("([0-9]+)$");
            Matcher m1 = p1.matcher(line);
            Matcher m2 = p2.matcher(line);
            if (m1.find() || m2.find()) {
                buff = ByteBuffer.allocate(128).put(line.getBytes()).flip();
                socket.write(buff);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

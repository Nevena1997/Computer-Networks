package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BankServer extends Thread{
    public static final int PORT = 12221;
    public static final String host = "localhost";
    private HashMap<Integer, Integer> activeAccounts = new HashMap<>();
    private Set<Integer> primaoci = new HashSet<>();
    private Set<Integer> posaljioci = new HashSet<>();

    public static void main(String[] args) {
        System.out.println("BankServer");
        BankServer server = new BankServer();
        server.start();
    }

    @Override
    public void run() {
        try (ServerSocketChannel socketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if (!socketChannel.isOpen() || !selector.isOpen()) {
                System.err.println("Failed to open socketChannel or selector");
                System.exit(1);
            }

            socketChannel.bind(new InetSocketAddress(PORT));
            socketChannel.configureBlocking(false);
            socketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();
                Set<SelectionKey> readyKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = readyKeys.iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            System.out.println("Accepted client");

                            ByteBuffer buff = ByteBuffer.allocate(4);
                            client.read(buff);
                            int id = buff.flip().getInt();
                            if (!activeAccounts.containsKey(id)) {
                                activeAccounts.put(id, 0);
                                primaoci.add(id);
                            }
                            buff.clear();

                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_WRITE);
                        }
                        else if (key.isReadable()) {
                            SocketChannel socket = (SocketChannel)key.channel();
                            ByteBuffer buff = ByteBuffer.allocate(128);

                            socket.read(buff);
                            String input = new String(buff.flip().array(), StandardCharsets.US_ASCII);
                            Pattern p1 = Pattern.compile("^([0-9]+) ([0-9]+)");
                            Pattern p2 = Pattern.compile("^([0-9]+)");
                            Matcher m1 = p1.matcher(input);
                            Matcher m2 = p2.matcher(input);
                            if (m1.find()) {
                                int id = Integer.parseInt(m1.group(1));
                                int amount = Integer.parseUnsignedInt(m1.group(2));
                                if (activeAccounts.containsKey(id)) {
                                    primaoci.remove(id);
                                    posaljioci.add(id);
                                    activeAccounts.replace(id, activeAccounts.get(id) + amount);
                                    System.out.println("Transfer na racun " + id + " (" + amount + ") je uspeno izvrsen");
                                }
                            } else if (m2.find()) {
                                System.out.println("Nisam stigao da implementiram");
                            }

                            socket.register(selector, SelectionKey.OP_WRITE);
                        }
                        else if (key.isWritable()) {
                            SocketChannel socket = (SocketChannel)key.channel();
                            ByteBuffer buff = ByteBuffer.allocate(4);

                            Iterator<Integer> iter = activeAccounts.keySet().iterator();
                            while (iter.hasNext()) {
                                int accountId = iter.next();
                                buff.rewind().clear().putInt(accountId).flip();
                                socket.write(buff);
                            }
                            buff.rewind().clear().putInt(-1).flip();
                            socket.write(buff);
                            buff.clear();
                            socket.register(selector, SelectionKey.OP_READ);
                        }
                    } catch (IOException e){
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;

public class UDPServer {
    public static final int PORT = 12345;
    private static DatagramSocket socket;
    private static HashMap<Integer, Float> activeAccounts = new HashMap<>();

    public static void main(String[] args) throws SocketException {
        System.out.println("UDPServer");
        socket = new DatagramSocket(PORT);
        new UDPAccountManagerThread().start();
        new UDPCommunicationManagerThread(socket).start();
    }

    public static boolean addAccount(int id, float amount) {
        if (!activeAccounts.containsKey(id)) {
            activeAccounts.put(id, amount);
            return true;
        }
        return false;
    }

    public static boolean accountExists(int id) {
        if (activeAccounts.containsKey(id))
            return true;

        return false;
    }

    public static float getAccountBalance(int id) {
        return activeAccounts.get(id);
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {


    public static void main(String[] args) {
        System.out.println("UDPClient");

        try {
            DatagramSocket socket = new DatagramSocket();

            Scanner sc = new Scanner(System.in);
            int accountId = sc.nextInt();

            byte[] buff = ByteBuffer.allocate(4).putInt(accountId).array();
            DatagramPacket request = new DatagramPacket(buff, buff.length, InetAddress.getLoopbackAddress(), UDPServer.PORT);
            socket.send(request);

            buff = ByteBuffer.allocate(8).array();
            DatagramPacket response = new DatagramPacket(buff, buff.length);
            socket.receive(response);

            float balance = ByteBuffer.wrap(buff).getFloat();
            System.out.println(balance);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

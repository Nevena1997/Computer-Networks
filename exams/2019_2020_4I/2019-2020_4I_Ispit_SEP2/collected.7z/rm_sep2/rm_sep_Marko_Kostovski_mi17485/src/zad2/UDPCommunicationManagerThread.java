package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;

public class UDPCommunicationManagerThread extends Thread {
    private DatagramSocket socket;

    UDPCommunicationManagerThread(DatagramSocket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        while (true) {
            try {
                byte[] buff = ByteBuffer.allocate(4).array();
                DatagramPacket request = new DatagramPacket(buff, buff.length, InetAddress.getLoopbackAddress(), UDPServer.PORT);
                socket.receive(request);

                int id = ByteBuffer.wrap(request.getData()).getInt();
                if (UDPServer.accountExists(id)) {
                    buff = ByteBuffer.allocate(8).putFloat(UDPServer.getAccountBalance(id)).array();
                } else {
                    buff = ByteBuffer.allocate(8).putFloat(-1.0f).array();
                }
                DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
                socket.send(response);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

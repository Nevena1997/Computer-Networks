package zad2;

import java.util.Scanner;

public class UDPAccountManagerThread extends Thread {

    @Override
    public void run() {
        try (Scanner sc = new Scanner(System.in)) {
            while (sc.hasNextLine()) {
                int accountId = sc.nextInt();
                float amount = sc.nextFloat();

                if (UDPServer.addAccount(accountId, amount)) {
                    System.out.println("Account added.");
                } else {
                    System.err.println("Account already exists!");
                }
            }
        }
    }
}

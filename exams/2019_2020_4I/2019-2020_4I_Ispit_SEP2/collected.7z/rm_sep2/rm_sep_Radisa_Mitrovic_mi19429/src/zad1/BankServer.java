package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Map;

public class BankServer {

    public static int PORT = 12221;
    public static  boolean prvoCitanje = true;
    public static boolean prvoPisanje = true;


    public static void main(String[] args) {


        System.out.println("BankServer");

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selektor = Selector.open()){

            if (!selektor.isOpen() || !server.isOpen()){

                System.err.println("Server ili selektor nije otvoren");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selektor, SelectionKey.OP_ACCEPT);

            while (true){

                selektor.select();
                Iterator<SelectionKey> iter = selektor.selectedKeys().iterator();

                while (iter.hasNext()) {

                    SelectionKey tekuciKljuc = iter.next();
                    iter.remove();


                    if (tekuciKljuc.isAcceptable()) {
                        //serverov deo za prihvtanje klijena

                        ServerSocketChannel s = (ServerSocketChannel) tekuciKljuc.channel();
                        SocketChannel klijent = server.accept();
                        klijent.configureBlocking(false);
                        //prvo citampo od servera
                        SelectionKey klijentKlju8c = klijent.register(selektor, SelectionKey.OP_READ);

                    } else if (tekuciKljuc.isReadable()) {

                        //pocetno citanje od klijenta
                        if (prvoCitanje) {
                            ByteBuffer buff = (ByteBuffer) tekuciKljuc.attachment();
                            if (tekuciKljuc.attachment() == null) {
                                //dodeljujem bu bByfer
                                buff = ByteBuffer.allocate(16);
                                tekuciKljuc.attach(buff);
                            }

                            //citanje poruke od klijenta

                            SocketChannel klijentkanal = (SocketChannel) tekuciKljuc.channel();
                            klijentkanal.read(buff);

                            ByteBuffer poruka = (ByteBuffer) tekuciKljuc.attachment();

                            String sadrzaj = new String(poruka.array());

                            //provera da li smo procitali celu poruku
                            if (sadrzaj.contains("\r\n")){
                                buff.flip();
                                tekuciKljuc.interestOps(SelectionKey.OP_WRITE);
                                prvoCitanje=false;
                            }

                        }
                        else
                        {
                            //drugo citanje ocekujem "brijracuna\r\niznos\r\n"
                            ByteBuffer buff = (ByteBuffer) tekuciKljuc.attachment();
                            SocketChannel klijentKanal = (SocketChannel) tekuciKljuc.channel();
                            klijentKanal.read(buff);
                            String porukaOdklijenta = new String(buff.array());

                            if (porukaOdklijenta.endsWith("\r\n")){
                                //samo izvrsi drugo pisanje
                                buff.flip();
                                tekuciKljuc.interestOps(SelectionKey.OP_WRITE);

                            }

                        }

                    } else if (tekuciKljuc.isWritable()) {

                        ByteBuffer buff = (ByteBuffer) tekuciKljuc.attachment();
                        SocketChannel klijentKanal = (SocketChannel) tekuciKljuc.channel();
                        String sadrzaj = new String(buff.array());
                        //prvoslanje ka klijentu
                        if (prvoPisanje && sadrzaj.endsWith("\r\n")) {
                            String brojRacuna = sadrzaj.substring(0, sadrzaj.indexOf('\r'));
                            //posalji brojeve racuna svih aktivnih kljuceva  povezanih klijenata, sem serveru i meni samom
                            selektor.selectedKeys().stream().filter(kljuc -> {

                                if (kljuc != tekuciKljuc && !kljuc.isAcceptable())
                                    return true;
                                else
                                    return false;
                            }).forEach(kljuc -> {
                                //posalji trenutnom kljucu broj racuna ovog kljuca(nalazi se u baferu)
                                ByteBuffer b = (ByteBuffer) kljuc.attachment();
                                String racun = new String(b.array());

                                b.clear();
                                b.put(racun.getBytes());

                                try {
                                    b.flip();
                                    klijentKanal.write(b);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                            });
                            //sada klijentu menjam op na read, ocekuje se da mi prosledi br racuna i iznos
                            tekuciKljuc.interestOps(SelectionKey.OP_READ);
                            prvoCitanje=false;
                        }
                        //ako je drugo pisanje
                        ByteBuffer buffer = (ByteBuffer) tekuciKljuc.attachment();
                        String sadrzajbafera =new String(buffer.array());
                        if (!prvoPisanje){

                            //TODO

                        }


                    }








                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");

        try(Socket klijent = new Socket("localhost",BankServer.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()))
            ) {

            //pocetnoi slanje broja racuna serveru
            String brojRacunja = sc.nextLine();
            out.write(brojRacunja);
            //\n je signal serveru da je procitao celu poruku od klijenta
            out.write('\r');
            out.write('\n');
            out.flush();
            //citanje broja racuna
            brojRacunja=null;
            while ((brojRacunja = in.readLine())!=null)
                System.out.println(brojRacunja);

            //unos broja racuna sa tastature
            String brojRacuna = null;
            System.out.print("Broj racuna: ");
            brojRacuna = sc.nextLine();
            //
            System.out.print("Iznos: ");
            Integer iznos = sc.nextInt();
            //format u koji ocekuje server
            if (iznos<0)
            {
                System.err.println("pogresdan unos iznosa na racunu");
                System.exit(1);
            }
            String porukaZaSlanje = brojRacuna.trim() + "\n" + iznos.toString() + "\r\n";
            out.write(porukaZaSlanje);
            out.flush();
            //citanje poruyke o uspesnosgti transakcije
            String odgovor = in.readLine();
            System.out.println(odgovor);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

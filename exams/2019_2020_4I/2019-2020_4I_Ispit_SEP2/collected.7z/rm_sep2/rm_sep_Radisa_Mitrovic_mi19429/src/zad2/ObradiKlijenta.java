package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

public class ObradiKlijenta extends Thread{
    DatagramSocket server;
    Map<String,Float> racuni;

    public ObradiKlijenta(DatagramSocket server, Map<String, Float> racuni) {

        this.server = server;
        this.racuni = racuni;
    }

    @Override
    public void run() {
        //obrada klijenta, imam klijentski soket

        while (true){

            try {
                DatagramPacket paketZaPrijem  = new DatagramPacket(new byte[8],8,(InetAddress.getByName("localhost")),UDPServer.PORT);
                //primam paket
                server.receive(paketZaPrijem);
                //prebacujem broj racuna u String
                String brojRacuna = new String(paketZaPrijem.getData(),paketZaPrijem.getData().length);
                byte[] podaciZaSlanje = new byte[8];
                //DatagramPacket packetZaSlanje = new DatagramPacket(podaciZaSlanje,8,paketZaPrijem.getAddress(),paketZaPrijem.getPort());
                if (racuni.containsKey(brojRacuna)){

                    //posali iznos
                    Float iznos = racuni.get(brojRacuna);
                    DatagramPacket paketZaSlanje = new DatagramPacket(iznos.toString().getBytes(),iznos.toString().length(),paketZaPrijem.getAddress(),paketZaPrijem.getPort());
                    server.send(paketZaSlanje);

                }
                else
                {
                    //poaslji -1
                   server.send(new DatagramPacket("-1".getBytes(),"-1".getBytes().length,paketZaPrijem.getAddress(),paketZaPrijem.getPort()));

                }

            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

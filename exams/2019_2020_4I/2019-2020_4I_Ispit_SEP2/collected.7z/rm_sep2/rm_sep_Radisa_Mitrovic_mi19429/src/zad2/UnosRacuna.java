package zad2;

import java.net.DatagramSocket;
import java.util.Map;
import java.util.Scanner;

public class UnosRacuna extends Thread{

    Map<String,Float> racuni;

    public UnosRacuna (Map<String, Float> racuni) {

        this.racuni = racuni;
    }


    @Override
    public void run() {
        //azuriranje racuna sa standardnog ulaza
        try(Scanner sc = new Scanner(System.in)) {
            String brojRacuna;
            Float iznos;
            while (sc.hasNext()) {
                brojRacuna = sc.nextLine();
                iznos = sc.nextFloat();
                this.ubaciRacun(brojRacuna,iznos);

            }
        }
    }

    private void ubaciRacun(String brojRacuna, Float iznos) {

        racuni.put(brojRacuna,iznos);


    }
}

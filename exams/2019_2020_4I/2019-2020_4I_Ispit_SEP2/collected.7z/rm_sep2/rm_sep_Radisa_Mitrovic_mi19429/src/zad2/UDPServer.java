package zad2;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static int PORT = 12345;


    public static void main(String[] args) {
        System.out.println("UDPServer");

        try{
            DatagramSocket server = new DatagramSocket(PORT);
            //sve se obradjuje u posebnim nitima
            //u mapi cuvam info o tekucim, racunima
            Map<String,Float> racuni = new HashMap<>();
            new UnosRacuna(racuni).start();
            new ObradiKlijenta(server,racuni).start();

        } catch (SocketException e) {
            e.printStackTrace();
        }


    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("UDPClient");

        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){

            String brojRacuna = sc.nextLine();
            byte[] podaciZaSlanje = brojRacuna.getBytes();
            DatagramPacket paketZaSalnje = new DatagramPacket(podaciZaSlanje,podaciZaSlanje.length,InetAddress.getByName("localhost"),UDPServer.PORT);
            //saljem paket
            klijent.send(paketZaSalnje);

            //primanje paketa
            DatagramPacket paketZaPrijem = new DatagramPacket(new byte[8],8);
            klijent.receive(paketZaPrijem);
            System.err.println( Arrays.toString(paketZaPrijem.getData()));
            String ss = new String(paketZaPrijem.getData(), StandardCharsets.US_ASCII);
            System.out.println("Iznos na racunu: " + ss.substring(0,ss.indexOf(0)));



        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
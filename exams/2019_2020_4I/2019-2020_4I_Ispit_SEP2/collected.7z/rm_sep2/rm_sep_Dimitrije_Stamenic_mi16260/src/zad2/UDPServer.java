package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class UDPServer {
    public static int DEFAULT_PORT = 12345;

    private int port;
    private Map<Integer, Integer> racuni = new HashMap<>();

    UDPServer(int port) {this.port = port;}
    UDPServer() {this.port = DEFAULT_PORT;}


    public static void main(String[] args) {
        UDPServer server = new UDPServer();
        server.execute();
    }

    private void execute() {
        try {
            DatagramSocket server = new DatagramSocket(
                    new InetSocketAddress(this.port));

            new NoviRacun(this).start();
            new CitanjePisanje(this, server).start();


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addRacun(int brRacuna, int iznos) {
        this.racuni.put(brRacuna, iznos);
    }

    public int getIznos(int brRacuna) {
        if (this.racuni.get(brRacuna) == null) return -1;
        return this.racuni.get(brRacuna);
    }
}

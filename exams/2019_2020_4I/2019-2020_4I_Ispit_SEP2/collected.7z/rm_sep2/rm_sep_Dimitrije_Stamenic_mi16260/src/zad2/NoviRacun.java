package zad2;

import java.util.Scanner;

public class NoviRacun extends Thread {
    private UDPServer server;

    public NoviRacun(UDPServer udpServer) {
        this.server = udpServer;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Scanner in = new Scanner(System.in);
                int brRacuna = in.nextInt();
                int iznos = in.nextInt();
                this.server.addRacun(brRacuna, iznos);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class CitanjePisanje extends Thread {
    private UDPServer udpServer;
    private DatagramSocket server;

    public CitanjePisanje(UDPServer udpServer, DatagramSocket server) {
        this.udpServer = udpServer;
        this.server = server;
    }

    @Override
    public void run() {
        while (true) {
            try {
                byte[] brRacunaByte = new byte[16];
                DatagramPacket fromUser = new DatagramPacket(brRacunaByte, 16);
                this.server.receive(fromUser);
                String brRacunaS = new String(brRacunaByte).trim();
                int brRacuna = Integer.parseInt(brRacunaS);

                int iznos;
                iznos = this.udpServer.getIznos(brRacuna);

                byte[] iznosByte = String.valueOf(iznos).trim().getBytes();
                DatagramPacket toUser = new DatagramPacket(iznosByte,
                        iznosByte.length,
                        fromUser.getAddress(),
                        fromUser.getPort());
                server.send(toUser);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
            Scanner userIn = new Scanner(System.in)
        ) {

            int brRacunaI = userIn.nextInt();
            String brRacuna = String.valueOf(brRacunaI).trim();
            byte[] brRacunaByte = brRacuna.getBytes();
            DatagramPacket toServer = new DatagramPacket(brRacunaByte,
                                        brRacunaByte.length,
                                        InetAddress.getLocalHost(),
                                        UDPServer.DEFAULT_PORT);
            client.send(toServer);

            byte[] iznosByte = new byte[16];
            DatagramPacket fromServer = new DatagramPacket(iznosByte, 16);
            client.receive(fromServer);
            int iznos = Integer.parseInt(new String(iznosByte).trim());

            System.out.println(iznos);


        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

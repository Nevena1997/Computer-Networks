package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        try (SocketChannel client = SocketChannel.open(
                new InetSocketAddress("localhost", BankServer.DEFAULT_PORT)
            );
            Scanner userIn = new Scanner(System.in);
        ) {
            client.configureBlocking(true);

            int brRacuna = userIn.nextInt();
            byte[] brRacunaNiz = String.valueOf(brRacuna).trim().getBytes();

            ByteBuffer buf = ByteBuffer.wrap(brRacunaNiz);
            client.write(buf);

            ByteBuffer nizPrimljeno = ByteBuffer.allocate(16);



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

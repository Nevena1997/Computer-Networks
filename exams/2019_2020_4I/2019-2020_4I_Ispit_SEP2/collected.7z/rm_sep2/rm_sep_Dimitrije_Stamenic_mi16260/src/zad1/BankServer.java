package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BankServer {
    public static final int DEFAULT_PORT = 12221;

    private Map<Integer, Integer> racuni = new HashMap<>();

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {
            if (!selector.isOpen() || !server.isOpen()) {
                System.exit(-1);
            }

            server.bind(new InetSocketAddress(DEFAULT_PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    SelectionKey trenutni = it.next();
                    it.remove();

                    if (trenutni.isAcceptable()) {
                        ServerSocketChannel serverKanal = (ServerSocketChannel) trenutni.channel();

                        SocketChannel klijentKanal = serverKanal.accept();
                        klijentKanal.configureBlocking(true);
                        klijentKanal.register(selector, SelectionKey.OP_WRITE);



                    } else if (trenutni.isWritable()) {


                    }
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.rmi.ServerError;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class BankServer {

    public static int DEFAULT_PORT = 12221;

    private static HashMap<String, Integer> accounts = new HashMap<>();
    private static ArrayList<String> connectedAccounts = new ArrayList<>();

    public static void main(String[] args) {

        //System.out.println("BankServer");

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if(!serverChannel.isOpen() || !selector.isOpen()) {
                System.err.println("Failed to open server or selector.");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);


            while(true){

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()){

                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = (SocketChannel) server.accept();

                            client.configureBlocking(false);
                            ByteBuffer buff = ByteBuffer.allocate(1024);
                            buff.clear();
                            key.attach(buff);

                            client.register(selector, SelectionKey.OP_READ);

                        } else if (key.isWritable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buff = (ByteBuffer) key.attachment();

                            for (var acc : connectedAccounts) {
                                buff.put((acc + "\r\n").getBytes());
                            }

                            while (!buff.hasRemaining()) {
                                client.write(buff);
                            }

                            buff.rewind();
                            buff.clear();


                        } else if (key.isReadable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buff = (ByteBuffer) key.attachment();

                            while (buff.hasRemaining()) {
                                client.read(buff);
                            }

                            String clientMsg = buff.toString();

                            Scanner sc = new Scanner(clientMsg);
                            String accountNo = sc.next();

                            insertAccount(accountNo);

                            buff.rewind();
                            buff.flip();

                        }
                    } catch(IOException ioEx){
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }


                }


            }




        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static synchronized void insertAccount(String accountNo){
        if(!accounts.containsKey(accountNo)){
            accounts.put(accountNo, 0);
        }

        connectedAccounts.add(accountNo);
    }

    private static boolean isConnected(String accountNo){
        if(connectedAccounts.contains(accountNo))
            return true;
        else
            return false;
    }

    private static synchronized void disconnectAccount(String accountNo){
        connectedAccounts.remove(accountNo);
    }

    private static synchronized void transfer(String from, String to, int amount){
        // imaginary logic
    }
}

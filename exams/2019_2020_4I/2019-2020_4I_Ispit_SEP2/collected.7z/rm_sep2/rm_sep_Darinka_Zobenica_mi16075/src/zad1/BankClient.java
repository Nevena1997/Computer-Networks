package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        //System.out.println("BankClient");

        try(SocketChannel client = SocketChannel.open();
            Scanner sc = new Scanner(System.in)){

            if(!client.isOpen()){
                System.err.println("Failed to open channel.");
            }

            //client.bind(new InetSocketAddress("localhost", BankServer.DEFAULT_PORT));

            WritableByteChannel sysout = Channels.newChannel(System.out);

            Socket cl = client.socket();
            cl.connect(new InetSocketAddress("localhost", BankServer.DEFAULT_PORT));

            BufferedReader in = new BufferedReader(new InputStreamReader(cl.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(cl.getOutputStream()));

            String accNo = sc.next();
            out.write(accNo);


            String line;
            while((line = in.readLine()) != null){
                System.out.println(line);
            }

            String accNoForTransfer = sc.next();
            int amount = sc.nextInt();
            //TODO



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;

public class UDPServer {
    private static HashMap<String, Double> accounts = new HashMap<>();

    public static int DEFAULT_PORT = 12345;
    public DatagramSocket sock;

    UDPServer(DatagramSocket sock){
        this.sock = sock;
    }

    public static void main(String[] args) {

        //System.out.println("UDPServer");
        UDPServer server = null;
        try {
            server = new UDPServer(new DatagramSocket(UDPServer.DEFAULT_PORT));

            new Thread(new UDPAcceptDatagramsRunnable(server)).start();

        } catch (SocketException e) {
            e.printStackTrace();
        }



    }


    public synchronized void insertAccount(String accountNo, double amount){
        if(!accounts.containsKey(accountNo)){
            accounts.put(accountNo, amount);
        }
    }

    public synchronized double checkAmount(String accountNo){
        return accounts.getOrDefault(accountNo, -1d);
    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Arrays;
import java.util.Scanner;

public class UDPClient {

    private static String hostname = "localhost";

    public static void main(String[] args) {

        try(DatagramSocket sock = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){


            while (true) {
                byte[] buff = sc.next().getBytes();

                /*
                int accNo = sc.nextInt();
                byte[] buff = new byte[4];
                buff[0] = (byte) (accNo >> 3);
                buff[1] = (byte) (accNo >> 2);
                buff[2] = (byte) (accNo >> 1);
                buff[3] = (byte) (accNo);
                */

                DatagramPacket req = new DatagramPacket(buff, buff.length, InetAddress.getByName(hostname), UDPServer.DEFAULT_PORT);
                sock.send(req);

                byte[] res = new byte[128];
                DatagramPacket response = new DatagramPacket(buff, buff.length, req.getAddress(), req.getPort());
                sock.receive(response);

                String amount = Arrays.toString(response.getData());// Double.parseDouble(Arrays.toString(response.getData()));
                System.out.println(amount);
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Arrays;
import java.util.Scanner;

public class UDPAcceptDatagramsRunnable implements Runnable{

    UDPServer server;

    UDPAcceptDatagramsRunnable(UDPServer server){
        this.server = server;
    }

    @Override
    public void run() {
        try {

            while(true) {

                byte[] accNoBuff = new byte[1024];
                DatagramPacket rec = new DatagramPacket(accNoBuff, accNoBuff.length);
                server.sock.receive(rec);

                String msg = Arrays.toString(rec.getData());

                Scanner sc = new Scanner(msg);
                String accNo = sc.next();


                /*
                if (sc.hasNext()) {
                    double amount = sc.nextDouble();

                    server.insertAccount(accNo, amount);

                } else {*/

                    double amount = server.checkAmount(accNo);
                    byte[] amountBuff = String.valueOf(amount).getBytes();
                    DatagramPacket send = new DatagramPacket(amountBuff, amountBuff.length, rec.getAddress(), rec.getPort());
                    server.sock.send(send);
                /*}*/

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

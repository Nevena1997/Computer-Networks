package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClientThread implements Runnable {

    private SocketChannel client;

    public BankClientThread(SocketChannel client) {
        this.client = client;
    }

    @Override
    public void run() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite broj racuna: ");
        String brojRacuna = sc.nextLine();

        ByteBuffer buffer = ByteBuffer.allocate(brojRacuna.length());
        try {
            buffer.put(brojRacuna.getBytes());
            client.write(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }

        sc.close();
    }
}

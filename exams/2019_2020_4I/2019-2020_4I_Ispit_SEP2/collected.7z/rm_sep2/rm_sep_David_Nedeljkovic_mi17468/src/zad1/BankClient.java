package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.nio.channels.SocketChannel;

public class BankClient {

    public static void main(String[] args) throws UnknownHostException {
        System.out.println("BankClient");

        SocketAddress address = new InetSocketAddress("localhost",BankServer.DEFAULT_PORT);
        try(SocketChannel client = SocketChannel.open(address)) {

            client.configureBlocking(true);
            Thread t = new Thread(new BankClientThread(client));
            t.start();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

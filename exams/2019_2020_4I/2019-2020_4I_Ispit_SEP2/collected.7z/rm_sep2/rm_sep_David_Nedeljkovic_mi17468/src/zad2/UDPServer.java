package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

public class UDPServer {

    public static final int DEFAILT_PORT = 12345;

    public static void main(String[] args) {
        System.out.println("UDPServer");


        try(DatagramSocket server = new DatagramSocket(DEFAILT_PORT)) {

            System.err.println("Server je pokrenut...");
            HashMap<String, Double> aktivniRacuni = new HashMap<String, Double>();

            while (true) {
                byte[] buffer = new byte[512];
                DatagramPacket receive = new DatagramPacket(buffer, buffer.length);
                server.receive(receive);

                String result = new String(receive.getData(), StandardCharsets.US_ASCII);
                result = result.substring(0, result.indexOf(0));
                String[] vrednosti = result.split(" ");

                String key = vrednosti[0];
                double value = Double.parseDouble(vrednosti[1]);
                aktivniRacuni.put(key, value);

                // ova obrada treba za nit slanje/primanje
                double iznos = aktivniRacuni.get(key);
                String iznosZaSlanje = String.valueOf(iznos);
                DatagramPacket forSend = new DatagramPacket(iznosZaSlanje.getBytes(), iznosZaSlanje.length(), receive.getAddress(), receive.getPort());
                server.send(forSend);

            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

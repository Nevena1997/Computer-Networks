package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class UDPClient {

    public static void main(String[] args) {
        System.out.println("UDPClient");

        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("localhost");
            String racun = "124512312345";
            byte[] zaSlanje = racun.getBytes();
            DatagramPacket send = new DatagramPacket(zaSlanje, zaSlanje.length, address, UDPServer.DEFAILT_PORT);
            socket.send(send);

            //DatagramPacket receive = new DatagramPacket(new byte[512], 512);
            //socket.receive(receive);

            //String iznos = new String(receive.getData(), StandardCharsets.US_ASCII);
            //System.out.println(iznos.substring(0, iznos.indexOf(0)));

            Thread t = new Thread(new UDPClientThread(socket));
            t.start();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

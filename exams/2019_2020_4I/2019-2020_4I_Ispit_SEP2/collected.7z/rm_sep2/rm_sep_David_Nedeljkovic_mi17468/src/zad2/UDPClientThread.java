package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClientThread implements Runnable {

    private DatagramSocket socket;


    public UDPClientThread(DatagramSocket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {

        while (true) {

            System.out.println("Unesite broj racuna i iznos: ");

            Scanner sc = new Scanner(System.in);
            String brojRacunaIznos = sc.nextLine();

            byte[] racunIznos = brojRacunaIznos.getBytes(StandardCharsets.US_ASCII);
            try {
                InetAddress address = InetAddress.getByName("localhost");
                DatagramPacket forSend = new DatagramPacket(racunIznos, racunIznos.length, address, UDPServer.DEFAILT_PORT);
                this.socket.send(forSend);

                DatagramPacket receive = new DatagramPacket(new byte[512], 512);
                this.socket.receive(receive);

                String result = new String(receive.getData(), StandardCharsets.US_ASCII);
                System.out.println("Iznos na ovom racunu je: " + Double.parseDouble(result.substring(0, result.indexOf(0))));

            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}

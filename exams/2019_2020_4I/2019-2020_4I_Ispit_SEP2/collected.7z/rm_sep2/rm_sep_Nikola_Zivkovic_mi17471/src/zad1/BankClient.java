package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {

        System.out.println("BankClient");

        try {
            InetSocketAddress addr = new InetSocketAddress("localhost", 12221);
            SocketChannel client = SocketChannel.open(addr);
            if(client.isConnected()){
                System.out.println("Connected to server");
            }

            Scanner sc = new Scanner(System.in);

            String br_racuna = sc.next();
            byte[] message = br_racuna.getBytes();
            ByteBuffer buffer = ByteBuffer.allocate(message.length);

            System.out.println(new String(message, 0, message.length));

            buffer.put(message);
            buffer.flip();
            client.write(buffer);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class BankServer {
    public static void main(String[] args) {

        System.out.println("BankServer");

        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            if(!serverSocketChannel.isOpen() || !selector.isOpen())
                System.exit(1);

            serverSocketChannel.bind(new InetSocketAddress(12221));
            serverSocketChannel.configureBlocking(false);

            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            selector.select();

            while (true){
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> i = keys.iterator();

                while(i.hasNext()){
                    SelectionKey key = i.next();
                    keys.remove(key);
                    if(key.isAcceptable()){

                        ServerSocketChannel server = (ServerSocketChannel) key.channel();

                        SocketChannel client = server.accept();
                        client.configureBlocking(false);
                        System.out.println("Client accepted!");

                        client.register(selector, SelectionKey.OP_READ);

                    }else if(key.isReadable()){

                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = ByteBuffer.allocate(256);
                        client.read(buffer);

                        System.out.println(buffer.array().toString());

                    }else if(key.isWritable()){



                    }

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

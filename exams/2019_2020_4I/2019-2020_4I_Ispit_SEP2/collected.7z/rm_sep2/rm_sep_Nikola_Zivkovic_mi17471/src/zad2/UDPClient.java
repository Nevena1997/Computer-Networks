package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("UDPClient");

        try {
            InetAddress addr = InetAddress.getLocalHost();
            DatagramSocket client = new DatagramSocket();

            Scanner sc = new Scanner(System.in);
            String br_racuna = Integer.toString(sc.nextInt());
            byte[] buffer = br_racuna.getBytes();

            DatagramPacket request = new DatagramPacket(buffer, buffer.length, addr, 12345);
            client.send(request);
            System.out.println("Request sent");


            buffer = new byte[256];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            client.receive(response);

            String iznos = new String(response.getData(), 0, response.getLength());
            System.out.println(iznos);

            client.close();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

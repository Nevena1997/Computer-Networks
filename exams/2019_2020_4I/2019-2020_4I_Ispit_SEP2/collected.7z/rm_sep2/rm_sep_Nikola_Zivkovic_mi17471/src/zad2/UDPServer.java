package zad2;

import java.util.ArrayList;
import java.util.Collection;

public class UDPServer {
    private Collection<Racun> racuni;

    public static void main(String[] args) {

        System.out.println("UDPServer");

        UDPServer server = new UDPServer();
        server.execute();
    }

    private UDPServer(){
        this.racuni = new ArrayList<>();
    }

    private void execute() {

        new InputThread(this).start();
        new SendRecieveThread(this).start();
    }

    public Collection<Racun> getRacuni() {
        return this.racuni;
    }

    public double find(int br_racuna) {
        for(Racun r : this.racuni){
            if(r.getBrRacuna() == br_racuna) return r.getIznos();
        }
        return -1;
    }
}

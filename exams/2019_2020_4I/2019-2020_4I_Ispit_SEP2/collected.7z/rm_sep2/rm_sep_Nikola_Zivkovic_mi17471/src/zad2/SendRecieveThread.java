package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class SendRecieveThread extends Thread{
    private final UDPServer server;

    public SendRecieveThread(UDPServer udpServer) {

        this.server = udpServer;
    }

    @Override
    public void run() {

        try (DatagramSocket socket = new DatagramSocket(12345)) {

            while (true){
                byte[] buffer = new byte[256];
                InetAddress addr = InetAddress.getLocalHost();
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                socket.receive(request);

                System.out.println("Request received");

                String msg = new String(request.getData(), 0, request.getLength());

                int br_racuna = Integer.parseInt(msg);
                double iznos = this.server.find(br_racuna);

                msg = Double.toString(iznos);
                buffer = msg.getBytes();

                DatagramPacket response = new DatagramPacket(buffer, buffer.length, request.getAddress(), request.getPort());
                socket.send(response);
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.util.Scanner;

public class InputThread extends Thread{
    private final UDPServer server;

    public InputThread(UDPServer udpServer) {
        this.server = udpServer;
    }

    @Override
    public void run() {

        Scanner sc = new Scanner(System.in);

        while (true){

            int br_racuna = sc.nextInt();
            double iznos = sc.nextDouble();

            this.server.getRacuni().add(new Racun(br_racuna, iznos));
            System.out.println("Racun broj " + br_racuna + " je uspesno dodat.");
        }
    }
}

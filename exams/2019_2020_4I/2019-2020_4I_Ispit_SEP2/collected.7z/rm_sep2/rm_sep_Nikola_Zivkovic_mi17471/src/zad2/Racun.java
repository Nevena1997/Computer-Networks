package zad2;

public class Racun {
    private final int br_racuna;
    private final double iznos;

    public Racun(int br_racuna, double iznos) {
        this.br_racuna = br_racuna;
        this.iznos = iznos;
    }

    public int getBrRacuna() {
        return this.br_racuna;
    }

    public double getIznos() {
        return this.iznos;
    }
}

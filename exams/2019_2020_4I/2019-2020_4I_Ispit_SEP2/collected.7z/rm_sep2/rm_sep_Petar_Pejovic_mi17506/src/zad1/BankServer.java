package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;

public class BankServer {

    public final static int PORT = 12221;

    private HashMap<String, Integer> racuni;

    BankServer(){
        this.racuni = new HashMap<>();
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        for(String s : racuni.keySet()){
//            sb.append(s).append(" ").append(String.valueOf(racuni.get(s)));
            sb.append(this.racuni.get(s) + "\n");
        }
        return sb.toString();
    }

    public static void main(String[] args){
        BankServer bankServer = new BankServer();
        bankServer.start();
    }

    private void start() {
        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){
            if(!server.isOpen() || !selector.isOpen()){
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);

            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();

                Iterator<SelectionKey> kljucevi = selector.selectedKeys().iterator();

                while(kljucevi.hasNext()){
                    SelectionKey kljuc = kljucevi.next();
                    kljucevi.remove();

                    try{
                        if(kljuc.isAcceptable()){
                            ServerSocketChannel serv = (ServerSocketChannel) kljuc.channel();
                            SocketChannel client = serv.accept();

                            client.configureBlocking(false);
                            ByteBuffer buffer = ByteBuffer.allocate(256);

                            SelectionKey klijentKljuc = client.register(selector, SelectionKey.OP_WRITE);

                            buffer.put(this.toString().getBytes(), 0, this.racuni.size());
                            buffer.put((byte) '\n');
                            buffer.put((byte) '\r');

                            buffer.flip();

                            klijentKljuc.attach(buffer);
                        } else if(kljuc.isWritable()){
                            SocketChannel client = (SocketChannel) kljuc.channel();
                            ByteBuffer buff = (ByteBuffer) kljuc.attachment();

//                            if(!buff.hasRemaining()){
//                                buff.rewind();
//
//                                buff.put(this.toString().getBytes(), 0, this.racuni.size());
//                                buff.put((byte) '\n');
//                                buff.put((byte) '\r');
//
//                                buff.flip();
//                            }

                            client.write(buff);
                        } else if(kljuc.isReadable()){
                            SocketChannel client = (SocketChannel) kljuc.channel();
                            ByteBuffer buff = (ByteBuffer) kljuc.attachment();


                        }
                    } catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

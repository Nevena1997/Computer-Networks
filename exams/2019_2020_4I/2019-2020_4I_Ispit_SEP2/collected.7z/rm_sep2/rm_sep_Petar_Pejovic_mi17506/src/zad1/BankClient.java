package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {

        SocketAddress add = new InetSocketAddress(BankServer.PORT);

        try(SocketChannel client = SocketChannel.open(add);
            Scanner sc = new Scanner(System.in);
            WritableByteChannel out = Channels.newChannel(System.out)
        ){

            String brojRacuna = sc.next();
            ByteBuffer buffer = ByteBuffer.allocate(256);

            buffer.put(brojRacuna.getBytes(), 0 , brojRacuna.length());
            buffer.flip();

            client.write(buffer);

            buffer.clear();
            while(client.read(buffer) > 0){
                out.write(buffer);
            }

            buffer.flip();

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

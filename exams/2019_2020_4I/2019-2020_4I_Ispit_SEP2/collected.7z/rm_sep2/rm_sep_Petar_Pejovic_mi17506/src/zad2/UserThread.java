package zad2;

import java.util.Scanner;

public class UserThread extends Thread{

    private UDPServer server;

    UserThread(UDPServer server){
        this.server = server;
    }

    public void run(){
        try(Scanner sc = new Scanner(System.in)){

            String line;
            while((line = sc.nextLine()) != null){
                String[] parts = line.split(" ");

                //Pretpostavljam da ce se format unosa uvek postovati, pa nema dodatnih provera
                String s = parts[0];
                Float f = Float.parseFloat(parts[1]);

                this.server.unesiRacun(s,f);
            }
        }
    }
}

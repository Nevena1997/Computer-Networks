package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){

            byte[] req = sc.nextLine().getBytes();
            DatagramPacket request = new DatagramPacket(req, req.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(request);

            byte[] res = new byte[124];
            DatagramPacket response = new DatagramPacket(res, res.length);
            client.receive(response);

            String account = new String(response.getData(), 0, response.getLength());
            System.out.println(account);

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;

public class UDPServer {

    public final static int PORT = 12345;

    private HashMap<String, Float> racuni;

    public void unesiRacun(String s, Float f){
        this.racuni.put(s,f);
    }

    public float getIznos(String s){
        float iznos;
        if(this.racuni.get(s) != null)
            return this.racuni.get(s);
        return -1;
    }

    public static void main(String[] args) {

        UDPServer server = new UDPServer();
        server.start();

    }

    UDPServer(){
        this.racuni = new HashMap<>();
        this.racuni.put("123", (float) 3000);
    }

    private void start(){
        (new UserThread(this)).start();
        (new ClientThread(this)).start();
    }

//    private void start() {
//        try(DatagramSocket server = new DatagramSocket(PORT)){
//
//            byte[] buff = new byte[8];
//            DatagramPacket prijem = new DatagramPacket(buff, buff.length);
//            server.receive(prijem);
//
//            String s = new String(prijem.getData(), 0 , prijem.getLength());
//
//            byte[] buff1 = String.valueOf(this.getIznos(s)).getBytes();
//
//            DatagramPacket slanje = new DatagramPacket(buff, buff.length, prijem.getAddress(), prijem.getPort());
//            server.send(prijem);
//
//        } catch (SocketException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


}

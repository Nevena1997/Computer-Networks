package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class ClientThread extends Thread{

    private UDPServer server;

    ClientThread(UDPServer server){
        this.server = server;
    }


    public void run(){
        try(DatagramSocket server = new DatagramSocket(UDPServer.PORT)){

            byte[] buff = new byte[256];
            DatagramPacket prijem = new DatagramPacket(buff, buff.length);
            server.receive(prijem);

            String s = new String(prijem.getData(), 0 , prijem.getLength());

            byte[] buff1;
            Float iznos = this.server.getIznos(s);
            if(iznos != -1)
                buff1 = String.valueOf(this.server.getIznos(s)).getBytes();
            else
                buff1 = String.valueOf(-1).getBytes();

            DatagramPacket slanje = new DatagramPacket(buff1, buff1.length, prijem.getAddress(), prijem.getPort());
            server.send(slanje);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

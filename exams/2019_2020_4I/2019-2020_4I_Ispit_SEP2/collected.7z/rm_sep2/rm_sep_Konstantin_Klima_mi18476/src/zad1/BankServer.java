package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.*;

public class BankServer {
    public static void main(String[] args) {
        try(Selector sel = Selector.open(); ServerSocketChannel s = ServerSocketChannel.open()) {

            s.configureBlocking(false);
            s.bind(new InetSocketAddress(InetAddress.getLocalHost(), 12345));


            while(true){
                //Accept
                SocketChannel c = s.accept();
                c.register(sel, SelectionKey.OP_WRITE | SelectionKey.OP_READ);
                var allKeys = sel.keys();

                //Read
                sel.select(SelectionKey.OP_READ);
                for(var conn : sel.selectedKeys())
                {
                    if(conn.isReadable()){
                        ByteBuffer buff = ByteBuffer.allocate(4);
                        SocketChannel srv = (SocketChannel) conn.channel();

                        srv.read(buff);
                        int broj_racuna = buff.getInt();

                        if(conn.attachment() == null){
                            conn.attach(broj_racuna);
                        }


                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

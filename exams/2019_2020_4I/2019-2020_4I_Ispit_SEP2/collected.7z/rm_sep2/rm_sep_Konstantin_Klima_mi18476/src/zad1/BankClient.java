package zad1;

import java.io.IOException;
import java.net.SocketAddress;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

public class BankClient {
    public static void main(String[] args) {
        try {
            SocketChannel s = SocketChannel.open();
            s.connect(s.getRemoteAddress());



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

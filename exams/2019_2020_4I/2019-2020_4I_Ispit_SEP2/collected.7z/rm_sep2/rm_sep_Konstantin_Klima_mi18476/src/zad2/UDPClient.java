package zad2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) throws SocketException {

        Scanner sc = new Scanner(new InputStreamReader(System.in));
        int id = sc.nextInt();

        try (DatagramSocket s = new DatagramSocket()) {
            InetAddress host = InetAddress.getLocalHost();
            int port = UDPServer.DEFAULT_PORT;

            DatagramPacket toServer = new DatagramPacket(ByteBuffer.allocate(4).putInt(id).array(),4, host, port);
            DatagramPacket fromServer = new DatagramPacket(new byte[4], 4);

            s.send(toServer);
            s.receive(fromServer);

            float amount = ByteBuffer.wrap(fromServer.getData()).getFloat();
            if(amount == -1.0)
                System.out.println(-1);
            else
                System.out.println(amount);

        }catch (SocketException | UnknownHostException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

public class DatagramThread extends Thread {
    public void run(){
        try (DatagramSocket s = new DatagramSocket(UDPServer.DEFAULT_PORT);){

            DatagramPacket toClient = new DatagramPacket(new byte[4], 4);
            DatagramPacket fromClient = new DatagramPacket(new byte[4], 4);

            while(true){
                s.receive(fromClient);
                toClient.setAddress(fromClient.getAddress());
                toClient.setPort(fromClient.getPort());

                int id = ByteBuffer.wrap(fromClient.getData()).getInt();
                float payload = UDPServer.getAmount(id);

                toClient.setData(ByteBuffer.allocate(4).putFloat(payload).array());
                s.send(toClient);
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.InputStreamReader;
import java.util.Scanner;

public class CreatorThread extends Thread {

    public void run(){
        Scanner sc = new Scanner(new InputStreamReader(System.in));

        int brojRacuna = sc.nextInt();
        float iznos = sc.nextFloat();

        UDPServer.updateStore(brojRacuna, iznos);

    }
}

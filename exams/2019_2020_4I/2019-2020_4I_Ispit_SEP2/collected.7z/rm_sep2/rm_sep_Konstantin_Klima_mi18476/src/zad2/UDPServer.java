package zad2;

import java.util.HashMap;

public class UDPServer {
    private static HashMap<Integer, Float> store = new HashMap<>();
    public static int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        CreatorThread ct = new CreatorThread();
        DatagramThread dt = new DatagramThread();

        try{
            ct.start();
            dt.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateStore(int id, float amount){
        store.put(id, amount);
    }

    public static float getAmount(int id){
        Float amount = store.get(id);
        if(amount == null)
            return -1;
        else
            return amount;
    }
}

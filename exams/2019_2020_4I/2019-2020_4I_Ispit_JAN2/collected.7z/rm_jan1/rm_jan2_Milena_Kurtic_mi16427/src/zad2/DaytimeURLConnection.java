package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    private Socket connection = null;
    public static final int DEFAULT_PORT = 12345;

    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected){
            return null;
        }
        return this.getInputStream();
    }

    @Override
    public void connect() throws IOException {
        // TODO
        if(this.connection == null){
            this.connection = new Socket(this.url.getHost(), this.url.getPort());
        }
    }
}

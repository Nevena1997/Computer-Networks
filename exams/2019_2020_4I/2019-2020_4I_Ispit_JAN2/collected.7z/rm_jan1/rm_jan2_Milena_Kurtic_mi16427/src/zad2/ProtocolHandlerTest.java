package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException {
        System.out.println("Hello from protocol test method!");
        URL u = new URL(null, "daytime://localhost:12345", new Handler());
        var conn = u.openConnection();
    }
}

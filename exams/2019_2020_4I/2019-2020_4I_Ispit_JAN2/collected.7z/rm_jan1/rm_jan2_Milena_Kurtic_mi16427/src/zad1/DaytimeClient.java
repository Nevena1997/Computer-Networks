package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class DaytimeClient extends Thread{
    public static void main(String[] args) {
        //System.out.println("Hello from DaytimeClient!");

         Thread t = new DaytimeClient();
         t.start();
         try(Scanner sc = new Scanner(System.in)){

            while (sc.hasNext()){
                    //System.out.println(sc.nextLine());
                    System.exit(0);
            }

         }

    }
    @Override
    public void run(){

        InetSocketAddress addr = new InetSocketAddress("localhost", 12345);
        System.out.println("Connecting...");
        try (SocketChannel channel = (SocketChannel) SocketChannel.open(addr)){

            ByteBuffer buffer = ByteBuffer.allocate(23);
            // channel.configureBlocking(false);
            WritableByteChannel out = Channels.newChannel(System.out);

            while (true){
                while (channel.read(buffer) != -1) {
                    buffer.rewind();
                    out.write(buffer);
                    buffer.clear();
                }
            }


        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

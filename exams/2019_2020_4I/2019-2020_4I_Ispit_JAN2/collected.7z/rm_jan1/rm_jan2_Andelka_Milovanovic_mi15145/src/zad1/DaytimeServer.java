package zad1;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.sql.Time;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {

    public static final int port = 12345;
    public static final int TIME_INTERVAL = 5000;

    public static void main(String[] args) {

        System.out.println("Hello from DaytimeServer!");

        long lastTime = System.currentTimeMillis();
        int flag = 0;

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){

            serverChannel.bind(new InetSocketAddress(port));
            System.err.println("Server slusa na portu " + port);
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {

                if(System.currentTimeMillis() - lastTime > TIME_INTERVAL){
                    flag = 1;
                    lastTime = System.currentTimeMillis();
                }

                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()){
                            // server moze da prima klijente

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            System.err.println("Client has accepted.");
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                            ByteBuffer buf = ByteBuffer.allocate(21);

                            Date now = new Date();
                            StringBuilder sb = new StringBuilder();
                            sb.append(now.getDate()).append(".").append(now.getMonth()+1).append(".").append(now.getYear()+1900);
                            sb.append(" | ");
                            sb.append(now.getHours()).append(":").append(now.getMinutes()).append(":").append(now.getSeconds());

                            buf.put(sb.toString().getBytes());
                            buf.put((byte) '\n');
                            clientKey.attach(buf);
                            buf.flip();
                            client.write(buf);
                        }

                        else if(key.isWritable()){
                            // klijent
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

//                            String date = new String(buf.array(), StandardCharsets.UTF_8);
//                            date = date.substring(0, date.indexOf(0));
//                            Date theDate = new Date(date);

                            buf.clear();
                            Date now = new Date();
                            StringBuilder sb = new StringBuilder();
                            sb.append(now.getDate()).append(".").append(now.getMonth()+1).append(".").append(now.getYear()+1900);
                            sb.append(" | ");
                            sb.append(now.getHours()).append(":").append(now.getMinutes()).append(":").append(now.getSeconds());
                            buf.put(sb.toString().getBytes());
//                            buf.put((byte) '\n');

//                            System.out.println(new String(buf.array()));
//                            buf.rewind();
                            buf.flip();

                            if(flag == 1) {
                                flag = 0;
                                client.write(buf);
                                System.out.println(new String(buf.array()));
                            }
                        }

                    } catch (Exception e) {
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        e.printStackTrace();
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

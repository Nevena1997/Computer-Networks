package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class DaytimeClient {

    private static final long TIME_INTERVAL = 5000;

    public static void main(String[] args) throws IOException {
        System.out.println("Hello from DaytimeClient!");

//        new ClientThread(client).start();


        try (Scanner sc = new Scanner(System.in)) {

            SocketChannel client = SocketChannel.open(new InetSocketAddress(DaytimeServer.port));
            System.err.println("Client has opened channel.");

//            new ClientReadThread(client).start();

            while(true){
                ByteBuffer buf = ByteBuffer.allocate(21);
                buf.clear();
                client.read(buf);
                String str = new String(buf.array(), StandardCharsets.UTF_8);
                System.out.println(str);
//                buf.clear();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

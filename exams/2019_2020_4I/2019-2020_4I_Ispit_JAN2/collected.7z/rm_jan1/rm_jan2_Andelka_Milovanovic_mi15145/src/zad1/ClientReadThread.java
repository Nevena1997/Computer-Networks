package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;

public class ClientReadThread extends Thread {

    private SocketChannel socket;

    public ClientReadThread(SocketChannel client) {
        this.socket = client;
    }

    @Override
    public void run() {
        while(true) {
            try {
                ByteBuffer buf = ByteBuffer.allocate(21);
                buf.clear();
                this.socket.read(buf);
                String str = new String(buf.array(), StandardCharsets.UTF_8);
                System.out.println(str);
                //                buf.clear();
            }catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    this.socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException {
        System.out.println("Hello from protocol test method!");

        URL u = new URL(null, "daytime://localhost:12345", new Handler());
        URLConnection conn = u.openConnection();
        conn.connect();
        try(BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))){

            String line;
            while((line = in.readLine()) != null){
                System.out.println(line);
            }
        }
    }
}

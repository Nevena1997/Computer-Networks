package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {

    public static final int DEFAULT_PORT = 12345;
    private Socket socket = null;
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if(!this.connected){
            this.connect();
            return null;
        }
        return this.socket.getInputStream();
    }

    @Override
    public synchronized void connect() throws IOException {
        if(!this.connected){
            int port = this.url.getPort();
            if (port < 1 || port > 65535) {
                port = this.DEFAULT_PORT;
            }

            try{
                this.socket = new Socket(this.url.getHost(), port);
            } catch (IOException e) {
                System.err.println("Connection failed.");
            }

            this.connected = true;
        }
    }
}

package zad2;

import java.net.URL;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        System.out.println("Hello from protocol test method!");

        try {
            URL URLtest = new URL(null, "daytime://localhost:12345", new Handler());

            URLtest.openConnection();

        }
        catch (Exception e){
            e.printStackTrace();
        }

    }
}

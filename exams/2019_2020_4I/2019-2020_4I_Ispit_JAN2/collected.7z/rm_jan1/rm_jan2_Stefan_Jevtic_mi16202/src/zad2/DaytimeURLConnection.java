package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    Socket connection = null;

    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        try {
            if(connected) return;


            int port = url.getPort();
            if(port == -1) {
                port = 12345;
            }



            connection = new Socket(url.getHost(), port);
            connected = true;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        // TODO
    }

    @Override
    public String getContentType() {
        return "text/html";
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(connected) {
            return connection.getInputStream();
        }
        else {
            return null;
        }
    }
}

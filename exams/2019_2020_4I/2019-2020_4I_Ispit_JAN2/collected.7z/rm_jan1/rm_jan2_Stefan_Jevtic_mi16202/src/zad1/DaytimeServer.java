package zad1;

import javax.swing.text.DateFormatter;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

class DaytimeServer {

    public static void main(String[] args) {
        final int DEF_PORT = 12345;

        try(ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
        ) {
            serverSocketChannel.bind(new InetSocketAddress(DEF_PORT));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);


            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {

                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                            Date date = new Date(0);
                            clientKey.attach(date);

                            System.out.println("Accepted");
                        }
                        else if(key.isWritable()) {
                            System.out.println("Ready to write");
                            SocketChannel client = (SocketChannel) key.channel();

                            Date previousDate = (Date) key.attachment();


                                DateFormat df = new SimpleDateFormat("dd.mm.yyyy | hh:mm:ss");
                                Date date = new Date();
                                String response = df.format(date);

                                if(date.getTime() - previousDate.getTime() >= 5000) {
                                    ByteBuffer response_buf = ByteBuffer.wrap(response.getBytes());
                                    client.write(response_buf);

                                    key.attach(date);
                                }
                                else {
                                    //key.cancel();
                                }






                        }
                    }
                    catch (IOException ek) {
                        ek.printStackTrace();
                        System.err.println("Key failed");

                        key.cancel();
                        try {
                            key.channel().close();
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
  /*                  catch (InterruptedException te) {
                        te.printStackTrace();
                        System.err.println("Timer failed");

                        key.cancel();
                        try {
                            key.channel().close();
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
*/
                }
            }


        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed to open server");
        }



    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;

class DaytimeClient {




    public static void main(String[] args) {
        System.out.println("Hello from DaytimeClient!");

        try(SocketChannel sc = SocketChannel.open()) {
            sc.configureBlocking(true);
            sc.connect(new InetSocketAddress(12345));

            (new Thread(new DaytimeClient.EnderThread(sc))).start();

            ByteBuffer buffer = ByteBuffer.allocate(21);
            while (sc.isConnected()) {
                buffer.clear();
                while (buffer.hasRemaining())
                    sc.read(buffer);

                String response = new String(buffer.array(), StandardCharsets.UTF_8);
                System.out.println(response);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed to connect");
        }




    }


    public static class EnderThread implements Runnable {

        BufferedReader input_reader;
        SocketChannel sc;
        public EnderThread(SocketChannel sc) {
            input_reader = new BufferedReader(new InputStreamReader(System.in));
            this.sc = sc;
        }

        public void run() {
            while (true) {
                try {
                    String inputMsg = input_reader.readLine();

                    if(inputMsg.trim().equalsIgnoreCase("end")) {
                        sc.close();
                        break;
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }
    }


}

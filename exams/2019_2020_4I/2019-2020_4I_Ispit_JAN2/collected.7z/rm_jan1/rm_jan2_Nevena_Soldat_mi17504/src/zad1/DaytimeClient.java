package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;


class DaytimeClient extends Thread{
    public static void main(String[] args) {
        DaytimeClient client = new DaytimeClient("localhost", DaytimeServer.DEFAULT_PORT);
        client.start();
        Scanner sc = new Scanner(System.in);
        System.err.println("Unesi nesto za prekid rada klijenta:");
        client.signal = sc.next();
    }

    private String host;
    private int port;
    private String signal;

    DaytimeClient(String hostname, int port)
    {
        this.host = hostname;
        this.port = port;
        this.signal = null;
    }

    @Override
    public void run()
    {
        InetSocketAddress address = new InetSocketAddress(this.host, this.port);
        try {
                SocketChannel client = SocketChannel.open(address);

                while(true)
                {
                    ByteBuffer buf = ByteBuffer.allocate(512);
                    client.read(buf);

                    WritableByteChannel out = Channels.newChannel(System.out);
                    out.write(buf);

                    buf.clear();

                    if(this.signal != null){
                        client.close();
                        break;
                    }
                }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

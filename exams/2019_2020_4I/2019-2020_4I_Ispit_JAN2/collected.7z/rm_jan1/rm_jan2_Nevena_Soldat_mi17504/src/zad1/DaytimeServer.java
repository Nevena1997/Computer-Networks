package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        System.err.println("Server listening on port " + DEFAULT_PORT);
        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open())
        {

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true)
            {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext())
                {
                    SelectionKey key = it.next();
                    it.remove();

                    try
                    {
                        if(key.isAcceptable())
                        {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                            String date = new Date().toString();
                            byte[] dateBytes = date.getBytes();
                            int size = dateBytes.length;


                            ByteBuffer buf = ByteBuffer.allocate(size);
                            buf.put(dateBytes);

                            buf.flip();

                            clientKey.attach(buf);

                        }
                        else if(key.isWritable())
                        {
                            SocketChannel client = (SocketChannel) key.channel();

                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            if(!buf.hasRemaining())
                            {
                                buf.clear();
                                String date = new Date().toString();
                                byte[] dateBytes = date.getBytes();
                                buf.put(dateBytes);
                                buf.flip();
                                Thread.sleep(5000);
                            }
                            client.write(buf);
                        }

                    }
                    catch (IOException e)
                    {
                        key.cancel();
                        try{
                            key.channel().close();
                        }
                        catch (IOException ex)
                        {
                            ex.printStackTrace();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    public static final int DEFAULT_PORT = 12345;
    private Socket socket;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if(!this.connected)
        {
            return null;
        }
        return this.socket.getInputStream();
    }

    @Override
    public synchronized void connect() throws IOException {
        int port = url.getPort();
        if(port < 1 || port > 65535)
        {
            port = DEFAULT_PORT;
        }

        try{
            this.socket = new Socket(url.getHost(), port);

            this.connected = true;

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally {
            this.socket.close();
        }
    }
}

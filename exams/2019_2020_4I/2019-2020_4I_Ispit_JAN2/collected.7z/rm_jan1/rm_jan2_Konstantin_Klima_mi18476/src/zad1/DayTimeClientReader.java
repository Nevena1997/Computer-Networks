package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class DayTimeClientReader extends Thread{
    private SocketChannel c;

    public DayTimeClientReader(SocketChannel c){
        this.c = c;
    }

    @Override
    public void run(){
        while(DaytimeClient.shouldRun){
            ByteBuffer readBuff = ByteBuffer.allocate(22);
            try {
                c.read(readBuff);
                readBuff.rewind();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            c.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

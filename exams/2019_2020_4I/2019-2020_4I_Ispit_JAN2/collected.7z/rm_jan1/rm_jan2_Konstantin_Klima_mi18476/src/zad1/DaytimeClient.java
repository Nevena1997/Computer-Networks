package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class DaytimeClient {
    public static  boolean shouldRun = true;

    public static void main(String[] args) {

        System.out.println("Connecting...");



        try (SocketChannel from = SocketChannel.open()) {
            from.connect(new InetSocketAddress("localhost", DaytimeServer.DEFAULT_PORT));
            DayTimeClientReader t = new DayTimeClientReader(from);
            Scanner s = new Scanner(System.in);
            shouldRun = false;


        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

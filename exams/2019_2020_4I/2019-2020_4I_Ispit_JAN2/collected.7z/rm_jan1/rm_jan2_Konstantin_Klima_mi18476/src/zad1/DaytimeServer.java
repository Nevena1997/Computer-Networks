package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.text.DateFormat;
import java.util.Iterator;

class DaytimeServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            server.bind(server.getLocalAddress());
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);


            while(true){
                server.accept();
                Iterator<SelectionKey> keys = (Iterator<SelectionKey>) selector.keys();

                while(keys.hasNext()){
                    SelectionKey key = keys.next();
                    keys.remove(); //Zatvaranje?

                    if(key.isAcceptable()){
                        ServerSocketChannel client = ServerSocketChannel.open();

                        server.bind(server.getLocalAddress());
                        client.configureBlocking(false);
                        SelectionKey ck = client.register(selector, SelectionKey.OP_WRITE);

                        ByteBuffer buff = ByteBuffer.allocate(22);
                        for(
                            String c : getFormatedCurrentTime().split("")
                        ){
                            buff.putChar(c.charAt(0));
                        }
                        buff.flip();
                        ck.attach(buff);
                    }
                }
            }
        }
        catch (IOException e){

        }

        System.out.println("Hello from DaytimeServer!");
    }

    private static String getFormatedCurrentTime(){
        long currentMillis = System.currentTimeMillis();
        long current= currentMillis/1000;
        long seconds = current % 60;
        current = current/60;
        long minutes = current % 60;



        return "" +current;
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;


class DaytimeClient {
    public static void main(String[] args) {
        System.out.println("Hello from DaytimeClient!");
        try (SocketChannel sock = SocketChannel.open()) {
            sock.connect(DaytimeServer.address);
            System.out.println(sock.isConnected());
        }catch(IOException e){
            e.printStackTrace();
        }
    }


}

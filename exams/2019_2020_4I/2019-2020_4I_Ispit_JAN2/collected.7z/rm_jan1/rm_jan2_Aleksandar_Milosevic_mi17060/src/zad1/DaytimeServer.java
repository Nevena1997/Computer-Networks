package zad1;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

class DaytimeServer {
    public static int PORT = 12345;
    public static SocketAddress address;


    public static void main(String[] args) {
        System.out.println("Hello from DaytimeServer!");


        try (ServerSocketChannel server = ServerSocketChannel.open()) {
            Selector selector = Selector.open();
            address = new InetSocketAddress("localhost",PORT);
            server.bind(address);
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);



            System.out.println("keys" + selector.selectedKeys());

            while (true){
                selector.select(5000);
                System.out.println("===============================");
                Iterator it = selector.selectedKeys().iterator();
                System.out.println("keys" + selector.selectedKeys());
                while(it.hasNext()){
                    SelectionKey key = (SelectionKey) it.next();
                    System.out.println(key);
                    it.remove();
                    if(key.isAcceptable()){
                        System.out.println("server otvorio kanal");
                    }
                    else if (key.isWritable()){

                        SocketChannel client = SocketChannel.open();
                        server.accept();
                        ByteBuffer buf = ByteBuffer.allocate(4).putInt(2);
                        client.write(buf);
                        System.out.println("klijent se prikacio");
                    }
                }
            }

        }catch(IOException e){
            e.printStackTrace();
        }

    }


}

package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    public static final int PORT = 12345;

    Socket connection = null;

    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if (!this.connected) {
            this.connect();
        }
        return this.connection.getInputStream();
    }

    @Override
    public void connect() throws IOException {
        int port = url.getPort();
        if (port < 1 || port > 65535) {
            port = PORT;
        }

        connection = new Socket(url.getHost(), port);
        OutputStream out = this.connection.getOutputStream();
        this.connected = true;
    }
}

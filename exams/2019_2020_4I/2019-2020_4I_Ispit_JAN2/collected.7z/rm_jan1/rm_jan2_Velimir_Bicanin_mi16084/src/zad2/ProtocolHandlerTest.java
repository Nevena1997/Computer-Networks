package zad2;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        try {
            URL url = new URL(null, "daytime://localhost:12345", new Handler());
            var conn = url.openConnection();

            InputStreamReader in = new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8);

            char[] time = new char[512];
            int numRead;
            while ((numRead = in.read(time)) != -1) {
                String result = new String(time);
                result = result.substring(0, numRead);
                System.out.println(result);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Connection failed.");
        }
    }
}

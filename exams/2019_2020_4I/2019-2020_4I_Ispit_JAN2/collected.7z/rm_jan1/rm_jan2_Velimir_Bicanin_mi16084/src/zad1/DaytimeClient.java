package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Scanner;

class DaytimeClient {

    public SocketChannel client;
    public boolean finished;

    public DaytimeClient() throws IOException {
        this.client = SocketChannel.open(new InetSocketAddress("localhost", DaytimeServer.PORT));
        this.finished = false;
    }


    public static void main(String[] args) {
        try {
            DaytimeClient client = new DaytimeClient();

            new DaytimeThread(client).start();

            Scanner in = new Scanner(System.in);
            while (in.hasNext()) {
                in.next();
                client.finished = true;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

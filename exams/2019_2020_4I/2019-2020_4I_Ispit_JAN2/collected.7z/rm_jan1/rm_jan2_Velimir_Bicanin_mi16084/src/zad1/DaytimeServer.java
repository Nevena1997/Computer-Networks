package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Thread.sleep(5000);

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();
                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
                            SocketChannel client = (SocketChannel) serverChannel.accept();

                            client.configureBlocking(false);
                            client.register(selector, SelectionKey.OP_WRITE);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            if (buffer == null) {
                                buffer = ByteBuffer.allocate(100);
                                key.attach(buffer);
                            }

                            String time = getTime();
                            buffer.clear();
                            buffer.put(time.getBytes(StandardCharsets.UTF_8));
                            buffer.flip();

                            while (buffer.hasRemaining())
                                client.write(buffer);

                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                    } catch (IOException e) {
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static String getTime() {
        StringBuffer time = new StringBuffer();
        Date currentTime = new Date();
        time.append(currentTime.getDate());
        time.append('.');
        time.append(currentTime.getMonth()+1);
        time.append('.');
        time.append(currentTime.getYear()+1900);
        time.append(" | ");
        time.append(currentTime.getHours());
        time.append(':');
        time.append(currentTime.getMinutes());
        time.append(':');
        time.append(currentTime.getSeconds());
        return time.toString();
    }
}

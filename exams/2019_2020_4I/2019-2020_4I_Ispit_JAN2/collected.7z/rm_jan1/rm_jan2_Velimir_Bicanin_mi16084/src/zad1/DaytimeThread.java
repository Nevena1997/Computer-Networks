package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class DaytimeThread extends Thread {

    DaytimeClient client;

    public DaytimeThread (DaytimeClient client) {
        this.client = client;
    }

    @Override
    public void run() {
        try {
            ByteBuffer buffer = ByteBuffer.allocate(100);
            while (!this.client.finished) {
                this.client.client.read(buffer);
                buffer.flip();
                String msg = new String(buffer.array(), 0, buffer.limit(), StandardCharsets.UTF_8);
                buffer.clear();

                System.out.println(msg);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;

class ProtocolHandlerTest {
    public static void main(String[] args) throws MalformedURLException {
        System.out.println("Hello from protocol test method!");

        URL url = new URL(null, "daytime://localhost:12345", new Handler());
        URLConnection con = null;
        try {
            con = url.openConnection();
        } catch (IOException e) {
            System.out.println("Connection failed");
            e.printStackTrace();
        }


        try
        {
            if(con.getInputStream()==null)
                con.connect();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String str = null;
            while( (str= in.readLine())!=null)
                System.out.println(str);



        } catch (IOException e) {
            e.printStackTrace();
        }





    }
}

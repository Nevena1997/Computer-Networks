package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Time;
import java.util.Date;

class DaytimeURLConnection extends URLConnection {

    private  Socket connection = null;
    private  int PORT= 12345;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        // TODO
        if(!this.connected) {
            if (url.getPort()>-1) {
                this.PORT = url.getPort();
            }
            this.connection = new Socket(url.getHost(), this.PORT);

        }

        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.connection.getOutputStream()));

        for(int i =0; i<3; i++) {

            try {
                this.wait(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            String[] d = new Date().toString().split(" ");
            String date = "";
            String day = d[2];
            String year = d[5];
            String month = null;

            switch (d[1]) {
                case "Jan":
                    month = "1";
                    break;
                case "Feb":
                    month = "2";
                    break;
                case "Mar":
                    month = "3";
                    break;
                case "Apr":
                    month = "4";
                    break;
                case "May":
                    month = "5";
                    break;
                case "Jun":
                    month = "6";
                    break;
                case "Jul":
                    month = "7";
                    break;
                case "Aug":
                    month = "8";
                    break;
                case "Sep":
                    month = "9";
                    break;
                case "Oct":
                    month = "10";
                    break;
                case "Nov":
                    month = "11";
                    break;
                case "Dec":
                    month = "12";
                    break;
                default:
                    month = "";
            }

            String time = d[3];

            date.concat(day).concat(".").concat(month).concat(".").concat(year).concat(".");
            date.concat(" | ");
            date.concat(time);

            out.write(date);
            out.newLine();
            out.flush();
        }

        out.close();



    }

    @Override
    public InputStream getInputStream() throws IOException {

        if(this.connected)
            return this.connection.getInputStream();
        else
            return null;
    }
}

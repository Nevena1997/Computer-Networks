package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class ClientThread extends Thread {

    @Override
    public void run() {

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", DaytimeServer.PORT)))
        {

            client.configureBlocking(true);
            ByteBuffer buff = ByteBuffer.allocate(256);
            while(true) {

                if(buff.hasRemaining()) {
                    buff.clear();
                    client.read(buff);
                    System.out.println(buff.get());
                }
            }



        } catch (IOException e) {
            e.printStackTrace();
        }





        return;
    }
}

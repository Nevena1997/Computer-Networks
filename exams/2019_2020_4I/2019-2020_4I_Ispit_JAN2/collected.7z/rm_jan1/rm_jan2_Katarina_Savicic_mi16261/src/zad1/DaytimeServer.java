package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {

    public static int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from DaytimeServer!");

        try(ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open())
        {

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true)
            {
                selector.select();
                Iterator<SelectionKey> it = selector.keys().iterator();
                while (it.hasNext())
                {
                    SelectionKey key = it.next();

                    try
                    {

                        if(key.isAcceptable())
                        {
                            ServerSocketChannel s = (ServerSocketChannel) key.channel();
                            SocketChannel client = s.accept();
                            client.configureBlocking(false);

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                            String date = new Date().toString();

                            ByteBuffer buff = ByteBuffer.wrap(date.getBytes());
                            buff.flip();

                            clientKey.attach(buff);

                        } else if(key.isWritable())
                        {
                            key.wait(5000);

                            SocketChannel client = (SocketChannel) key.channel();
                            client.configureBlocking(false);
                            //client.wait(5000);

                            String date = new Date().toString();
                            ByteBuffer buff = ByteBuffer.wrap(date.getBytes());
                            buff.flip();
                            client.write(buff);

                        }

                    } catch (IOException e )
                    {
                        key.cancel();
                        try
                        {
                            key.channel().close();
                        }catch (IOException ex)
                        {
                            ex.printStackTrace();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

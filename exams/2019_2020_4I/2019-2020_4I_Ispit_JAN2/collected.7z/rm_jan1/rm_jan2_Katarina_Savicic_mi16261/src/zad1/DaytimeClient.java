package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) {
        System.out.println("Hello from DaytimeClient!");

       Thread t =  new ClientThread();
       t.start();

        Scanner sc = new Scanner(System.in);
       while (true)
       {
           if(sc.hasNext())
           {
               String in = sc.nextLine();
               if(in.equalsIgnoreCase("end"))
               {
                   t.interrupt();
                   break;
               }
           }
       }
       sc.close();

    }
}

package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;

class DaytimeURLConnection extends URLConnection {
    public static final int DEFAULT_PORT = 12345;

    private Socket connection;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
        this.connected = false;
    }

    @Override
    public synchronized InputStream getInputStream() throws IOException {

        if (!this.connected) {
            return null; // return null if the connection is not established
        }

        return connection.getInputStream();
    }

    @Override
    public synchronized void connect() throws IOException {
        if (!this.connected) {

            int port = url.getPort();

            //System.out.println("port from url" + url.getPort());
            if (port == -1) {
                port = DEFAULT_PORT;
            }

            //System.out.println("url host:" +url.getHost());
            connection = new Socket(url.getHost(), port);
            this.connected = true;
        }
    }
}

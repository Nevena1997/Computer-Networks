package zad2;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

class ProtocolHandlerTest {
    public static void main(String[] args) {

        try {
            //String t1 = "daytime://localhost:12345";
            String t1 = "daytime://localhost";
            //String t1 = "daytime://asdf:12345";
            //String t1 = "daytime://asdf:999";
            System.out.println(t1);
            URL url = new URL(null, t1, new Handler());

            URLConnection client = url.openConnection();

            client.connect();

            try(BufferedReader r = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

                String line;
                while((line = r.readLine()) != null) {
                    System.out.println(line);
                }
            }


        } catch (MalformedURLException e) {
            //e.printStackTrace();
            System.out.println("Malformed url!");
        }catch (IOException e) {
            System.out.println("Connection refused.");
        }
    }

    private void testUrl(URL url) throws IOException {

        URLConnection client = url.openConnection();

        client.connect();

        try(BufferedReader r = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

            String line;
            while((line = r.readLine()) != null) {
                System.out.println(line);
            }
        }
    }
}

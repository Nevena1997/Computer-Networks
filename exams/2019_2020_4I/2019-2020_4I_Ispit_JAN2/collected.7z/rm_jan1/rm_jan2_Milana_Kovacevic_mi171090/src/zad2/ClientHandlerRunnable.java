package zad2;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Date;

public class ClientHandlerRunnable implements Runnable {

    public static final int BUF_SIZE = 256;
    private SocketChannel client;

    public ClientHandlerRunnable(SocketChannel sc) {
        client = sc;
    }

    @Override
    public void run() {
        ByteBuffer buffer = ByteBuffer.allocate(BUF_SIZE);
        System.out.println("Serving time...");

        try {
            while (true)
            {
                client.configureBlocking(false);

                Date now = new Date();
                //msg format: dd.mm.yyyy | hh:mm:ss
                String response = now.getDate() + "." + (now.getMonth() + 1) + "." + (now.getYear() + 1900) + " | "
                        + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds() + "\n";
                buffer.put(response.getBytes());
                buffer.flip();

                client.write(buffer);

                // prepare for next write
                buffer.clear();

                Thread.sleep(5000);
            }

        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Client disconnected");
        } catch ( InterruptedException ie) {
            System.out.println("Interrupted!");
        }

    }

}

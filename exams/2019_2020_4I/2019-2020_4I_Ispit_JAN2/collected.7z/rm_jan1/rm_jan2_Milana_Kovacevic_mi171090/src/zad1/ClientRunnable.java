package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;

public class ClientRunnable implements Runnable {
    public static final int DEFAULT_PORT = 12345;
    public static final int BUF_SIZE = 256;
    public static final String HOST = "localhost";



    @Override
    public void run() {

        SocketAddress sa = new InetSocketAddress(HOST, DEFAULT_PORT);

        System.out.println("Connecting...");
        ByteBuffer buffer = ByteBuffer.allocate(BUF_SIZE);

        try (SocketChannel client = SocketChannel.open(sa)) {
            client.configureBlocking(true);

            while (true) {
                int n = client.read(buffer);
                if (n > 0) {

                    String msg = new String (buffer.array(), 0, buffer.position(), StandardCharsets.US_ASCII);
                    System.out.print(msg);
                    buffer.clear();
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Client thread finished");

    }
}

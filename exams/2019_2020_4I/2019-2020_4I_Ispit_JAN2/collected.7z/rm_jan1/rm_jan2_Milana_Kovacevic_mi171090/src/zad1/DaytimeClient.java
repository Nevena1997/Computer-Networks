package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class DaytimeClient {

    public static void main(String[] args) {

        System.out.println("[start]");

        // separate thread for getting responses from server
        Thread thr = new Thread (new ClientRunnable());
        thr.start();

        try (Scanner sc = new Scanner(System.in)) {
            // wait for any input from the user
            sc.nextLine();
        }

        thr.interrupt(); // this will kill the thread

        System.out.println("[end]");

    }
}

package zad1;

import zad2.ClientHandlerRunnable;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

class DaytimeServer {

    public static final int DEFAULT_PORT = 12345;
    public static final int BUF_SIZE = 256;
    public static final String HOST = "localhost";

    public static void main(String[] args) {
        System.out.println("[start]");


        try (ServerSocketChannel server =  ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            server.bind(new InetSocketAddress(HOST, DEFAULT_PORT));
            server.configureBlocking(false);

            server.register(selector, SelectionKey.OP_ACCEPT);
            ByteBuffer buffer = ByteBuffer.allocate(BUF_SIZE);

            while (true) {

                selector.select();

                Set<SelectionKey> keys = selector.keys();
                Iterator<SelectionKey> it = keys.iterator();

                while (it.hasNext()) {

                    SelectionKey key = it.next();

                    if (key.isAcceptable()) {
                        //System.out.println("client acceptable");

                        ServerSocketChannel channel = (ServerSocketChannel) key.channel();

                        SocketChannel client = channel.accept();
                        System.out.println("Accepted client");

                        new Thread(new ClientHandlerRunnable(client)).start();

                    }

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;

public class readThread extends Thread{
    Socket server;

    public readThread(Socket server) {
        server = server;
    }

    @Override
    public void run() {
        ByteBuffer buf = ByteBuffer.allocate(10);
        try {
            while (true)
            {
                while (buf.hasRemaining())
                {
                    buf.get(server.getInputStream().read());
                    char text = buf.asCharBuffer().get();
                    System.out.println("Poruka od servera: "+text);
                    buf.flip();
                }
                buf.clear();
                buf.rewind();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

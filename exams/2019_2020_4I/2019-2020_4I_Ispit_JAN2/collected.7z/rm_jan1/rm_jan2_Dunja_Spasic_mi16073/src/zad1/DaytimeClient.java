package zad1;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) {
        System.out.println("Hello from DaytimeClient!");
        SocketAddress addr = new InetSocketAddress("localhost",12345);

        try(SocketChannel s = SocketChannel.open(addr)){
            System.out.println("Connected to server!");
            Socket server = s.socket();
            new readThread(server).start();

            Scanner sc = new Scanner(System.in);
            String end = sc.nextLine();
            if (end.equals("quit"))
                System.exit(0);

        }catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

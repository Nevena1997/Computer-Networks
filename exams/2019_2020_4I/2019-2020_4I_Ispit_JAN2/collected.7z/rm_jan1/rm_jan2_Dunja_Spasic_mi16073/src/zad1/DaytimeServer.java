package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {
    public static void main(String[] args) {
        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()){
            serverChannel.bind(new InetSocketAddress("localhost",12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);


            while(true)
            {
                Iterator<SelectionKey> it = selector.keys().iterator();
                SelectionKey key = it.next();
                //it.remove();
                SocketChannel clientChannel;
                ByteBuffer toClient = ByteBuffer.allocate(10);

                if (key.isAcceptable())
                {
                    System.out.println("Accepted client.");
                    clientChannel = serverChannel.accept();
                    clientChannel.configureBlocking(false);
                    clientChannel.register(selector,SelectionKey.OP_WRITE);
                    key.attach(new Date().getTime());
                }
                else if (key.isWritable())
                {
                    Date time = new Date();
                    if ((time.getTime() - (long)key.attachment()) == 50000)
                    {
                        System.out.println("Dosli smo do pisanja u klijenta.");
                        clientChannel = (SocketChannel) key.channel();
                        clientChannel.configureBlocking(false);
                        clientChannel.register(selector,SelectionKey.OP_WRITE);

                        String msg = time.toString();
                        toClient.clear();
                        toClient.rewind();
                        toClient.put(msg.getBytes());
                        System.out.println("Poruka 'a' je poslata klijentu.");
                        toClient.flip();
                    }
                    //clientChannel.write(toClient);
                }

                //key.cancel();
            }

        }catch (IOException e)
        {
            e.printStackTrace();
        }

    }
}

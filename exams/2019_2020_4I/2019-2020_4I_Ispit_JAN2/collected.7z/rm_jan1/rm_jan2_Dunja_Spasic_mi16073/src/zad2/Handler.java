package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.nio.channels.SocketChannel;

class Handler extends URLStreamHandler{
    InputStream in = null;
    @Override
    protected URLConnection openConnection(URL u) throws IOException {
        SocketAddress URLaddr;
        if (u.getPort() == 0)
            URLaddr = new InetSocketAddress(u.getHost(),12345);

        URLaddr = new InetSocketAddress(u.getHost(),u.getPort());
        SocketChannel s = SocketChannel.open(URLaddr);
        in = s.socket().getInputStream();
        return null;
    }


    public InputStream getInputStream() throws IOException {
        return this.in;
    }
}

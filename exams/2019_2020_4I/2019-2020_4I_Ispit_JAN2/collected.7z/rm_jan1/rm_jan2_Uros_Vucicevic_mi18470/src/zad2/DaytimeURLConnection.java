package zad2;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        // TODO
    }
}

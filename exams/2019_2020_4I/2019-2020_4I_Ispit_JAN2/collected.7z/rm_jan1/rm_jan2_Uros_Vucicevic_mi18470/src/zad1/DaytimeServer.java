package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

class DaytimeServer {

    public static final int PORT =  12345;


    public static void main(String[] args) {

        //System.out.println("Hello from DaytimeServer!");
        try {
            ServerSocketChannel server = ServerSocketChannel.open();
            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);

            while(true) {
                try(SocketChannel client = server.accept()) {

                    Date datum = new Date();

                    String niska = format(datum);

                    byte[] buf = new byte[512];

                    buf = niska.getBytes();

                    ByteBuffer buffer = ByteBuffer.allocate(512);

                    buffer.put(buf);

                    client.write(buffer);
                }
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }







    }

    public static String format (Date datum) {

        String niska = datum.toString();
        String dan = niska.substring(8,10);
        String mesec = niska.substring(4,7  );
        String godina = niska.substring(24);

        String vreme = niska.substring(11,19);

        Map<String,String> mapa = new HashMap<>();
        mapa.put("Jan","01");mapa.put("Feb","02");mapa.put("Mar","03");
        mapa.put("Apr","04");mapa.put("May","05");mapa.put("Jun","06");
        mapa.put("Jul","07");mapa.put("Aug","08");mapa.put("Sep","09");
        mapa.put("Oct","10");mapa.put("Nov","11");mapa.put("Dec","12");

        return dan + "." + mapa.get(mesec) + "." + godina + " | " + vreme;

    }
}

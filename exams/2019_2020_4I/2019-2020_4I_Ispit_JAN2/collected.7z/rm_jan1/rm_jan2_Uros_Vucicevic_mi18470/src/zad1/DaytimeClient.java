package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

class DaytimeClient {




    public static void main(String[] args) {


        //System.out.println("Hello from DaytimeClient!");

        SocketAddress address = new InetSocketAddress("localhost",DaytimeServer.PORT);
        try {
            SocketChannel channel = SocketChannel.open(address);

            channel.configureBlocking(true);

            channel.connect(address);

            ByteBuffer buffer = ByteBuffer.allocate(512);






        } catch (IOException e) {
            e.printStackTrace();
        }



    }








}

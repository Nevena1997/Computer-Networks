package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

class DaytimeServer {

    public static final int DEFAULT_PORT = 12345;
    public static final long DEFAULT_PAUSE = 5000;

    public static int BUFFER_SIZE = 30;

    public static long currentTime;

    public static void main(String[] arg){
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            InetSocketAddress address = new InetSocketAddress(DEFAULT_PORT);
            server.bind(address);
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            currentTime = System.currentTimeMillis();

            while(true){
                selector.select();
                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = selectedKeys.iterator();

                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    if(key.isAcceptable()){
                        ServerSocketChannel serverSocket = (ServerSocketChannel) key.channel();
                        SocketChannel client = serverSocket.accept();
                        client.configureBlocking(false);
                        client.register(selector, SelectionKey.OP_WRITE);


                    }else if(key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);

                        if(!client.isConnected()){
                            System.out.println("Client disconnected");
                            client.close();
                            key.cancel();
                        }

                        if(System.currentTimeMillis() - currentTime > DEFAULT_PAUSE) {

                            Date date = new Date();
                            DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT); // TODO - namestiti format
                            String dateTime = df.format(date);


                            buffer.put(dateTime.getBytes());
                            buffer.flip();
                            client.write(buffer);

                            currentTime = System.currentTimeMillis();
                        }


                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

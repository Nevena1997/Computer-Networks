package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousCloseException;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class DaytimeClient {
    public static int BUFFER_SIZE = 30;
    public static boolean active;

    public static void main(String[] args){

        InetSocketAddress address = new InetSocketAddress("localhost", DaytimeServer.DEFAULT_PORT);
        try (SocketChannel socket = SocketChannel.open(address);
             Scanner sc = new Scanner(System.in)) {
            socket.configureBlocking(true);

            active = true;

            new Thread(() -> {


                while (true) {
                    try {
                        if (active == true) {

                            ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);

                            socket.read(buffer);

                            String response = new String(buffer.array(), 0, buffer.position());
                            System.out.println(response);
                        } else {
                            return;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();


            while (active) {
                String fromUser = sc.next();
                System.err.println(fromUser);
                if (fromUser.compareToIgnoreCase("bye") == 0) {
                    active = false;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        try{
            URL url = new URL(null,"daytime://localhost:12345",new Handler());
            var con = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
//            ne radi jer server ne stavlja novi red na kraj!
//            String line;
//            while((line = in.()) != null){
//                System.err.println(line);
//            }
            CharBuffer buf = CharBuffer.allocate(new Date().toString().getBytes().length);
            System.err.println("from server:");
            while(true){
                while(buf.hasRemaining()){
                    in.read(buf);
                }
                String date = new String(buf.array(),0,buf.array().length);
                System.err.println(date);
                buf.clear();

            }
        } catch (UnknownHostException e) {
//            e.printStackTrace();
            System.err.println("Connection failed...");
        } catch (IOException e) {
//            e.printStackTrace();
            System.err.println("Konekcija odbijena najverovatnije jer server nije aktivan ili nije zadatat dobar port pri zadavanju url adrese!");
        }
    }
}

package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {

    public static final int DEFAULT_PORT = 12345;
    private Socket connection;
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected){
            this.connect();
        }
        return this.connection.getInputStream();
    }

    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port = this.url.getPort();
            if(port <= 0 || port >= 65535){
                port = DEFAULT_PORT;
            }

            this.connection = new Socket(this.url.getHost(),port);
            this.connected = true;
        }
    }
}

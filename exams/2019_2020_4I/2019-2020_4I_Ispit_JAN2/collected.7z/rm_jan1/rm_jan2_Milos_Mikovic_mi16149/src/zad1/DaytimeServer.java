package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {

    public static int DEFAULT_PORT = 12345;


    public static void main(String[] args) {

        System.err.println("Nekada slanje traje malo vise od 5 sec,sacekati malo i bice poslato sve :)");

        try(ServerSocketChannel serverChanel = ServerSocketChannel.open();
            Selector selector = Selector.open();
        ) {

            if(!serverChanel.isOpen() || !selector.isOpen()){
                System.err.println("Ne uspelo otvaranje serChanel-a ili selector-a...");
                System.exit(1);
            }

            serverChanel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChanel.configureBlocking(false);
            serverChanel.register(selector, SelectionKey.OP_ACCEPT);

            System.err.println("Server started..");
            boolean sleepInd = false;
            while(true){
                if(sleepInd){
                    Thread.sleep(3000);
                }
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();
                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
                            System.err.println("Client accepted!");
                            //namestanje vremena
//                        Date now  = new Date();
//                        int day = now.getDay();
//                        int month = now.getMonth();
//                        int year = now.getYear();
//                        int hour = now.getHours();
//                        int min = now.getMinutes();
//                        int sec = now.getSeconds();
//                        System.err.println(day + " " +month + " " + year + " " + hour + " " + min + " " + sec);
//                        System.err.println(new Date().toString());
                            String toClint = new Date().toString();
                            ByteBuffer buf = ByteBuffer.allocate(toClint.getBytes().length);
                            buf.put(toClint.getBytes(), 0, toClint.getBytes().length);
                            clientKey.attach(buf);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();
                            String tmp = new String(buf.array(), 0, buf.array().length, StandardCharsets.UTF_8);
//                        System.err.println(tmp);
                            while (buf.hasRemaining()) {
                                client.write(buf);
                            }
                            buf.clear();
                            String toClint = new Date().toString();
                            buf.put(toClint.getBytes(), 0, toClint.getBytes().length);
                            buf.flip();
                            sleepInd = true;
                        }
                    }catch (IOException e){
                        key.channel().close();
                        System.err.println("Client pukao/diskonektovao se...");
                    }
                }
            }

        } catch (IOException | InterruptedException e) {

            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;

public class runableClient implements Runnable {


    private ByteBuffer buf;
    private SocketChannel socket;

    public runableClient(ByteBuffer buf, SocketChannel socket) {
        this.buf = buf;
        this.socket = socket;
    }

    @Override
    public void run() {

        while(true) {
            while (this.buf.hasRemaining()) {
                try {
                    socket.read(buf);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            buf.rewind();
            String date = new String(buf.array(), 0, buf.array().length, StandardCharsets.UTF_8);
            System.err.println(date);
        }
    }
}

package zad1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) {
        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost",DaytimeServer.DEFAULT_PORT))){
            System.err.println("povezan sam na server...(ako zelimo da ubijemo klijenta pre nego sto on dobije i jednu poruku,nekada ce potrajati par sekundi" +
                    "delay-a za citanje i slanje(server))");
            System.err.println("[start]");
            ByteBuffer fromServer = ByteBuffer.allocate(new Date().toString().getBytes().length);

            Thread t = new Thread(new runableClient(fromServer,client));
            System.err.println("Ako hocete da ubijete klijenta unesite bilo koji char(string/text) sa ulaza:");
            t.start();
            Scanner in = new Scanner(System.in);
            String stop = in.nextLine();

//            mozda ima i neki lepsi nacin da se zaustavi thread
            t.stop();

            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.err.println("[end]");


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    final static int DEFAULT_PORT = 12345;

    private Socket soket = null;

    DaytimeURLConnection(URL url) {
        super(url);
    }


    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected)
            return null;
        return this.getInputStream();
    }

    public static int getDefaultPort() {
        return DEFAULT_PORT;
    }

    @Override
    public void connect() throws IOException {
        int port = this.url.getPort();

        if(port <= -1 || port > 66666)
            port = getDefaultPort();

        this.soket = new Socket(url.getHost(), port);

        BufferedReader in = new BufferedReader(new InputStreamReader(soket.getInputStream()));

    }
}

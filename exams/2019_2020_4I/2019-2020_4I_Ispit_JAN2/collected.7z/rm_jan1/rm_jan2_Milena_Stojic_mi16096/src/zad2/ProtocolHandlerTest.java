package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        System.out.println("Hello from protocol test method!");

        try {
            URL u = new URL(null, "daytime://localhost", new Handler());
            URLConnection url_connection = u.openConnection();

            Scanner in = new Scanner(new BufferedReader(new InputStreamReader(url_connection.getInputStream())));
            long today = in.nextLong();

            Date today_date = new Date(today);

            System.out.println(today_date.getDate() + "." +
                    (today_date.getMonth() + 1) + "." + (today_date.getYear() + 1900)
                    + " | " + today_date.getHours() + ":" + today_date.getMinutes()
                    + ":" + today_date.getSeconds());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch(Exception e) {
            System.err.println("Neka druga greska");
            e.printStackTrace();
        }
    }
}

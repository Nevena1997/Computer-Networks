package zad2;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.concurrent.locks.Lock;

class Handler extends URLStreamHandler {

    private Lock lock;
    @Override
    protected int getDefaultPort() {
        return DaytimeURLConnection.DEFAULT_PORT;
    }

    @Override
    protected URLConnection openConnection(URL u) throws IOException {
        try {
            this.lock.lock();
            return new DaytimeURLConnection(u);
        }  finally {
            this.lock.unlock();
        }
    }
}

package zad1;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class DaytimeClient {

    final static String host = "localhost";
    final static int PORT = 12345;

    public static void main(String[] args) {

        System.out.println("Hello from DaytimeClient!");
        System.out.println("[start]");

        try (SocketChannel sc = SocketChannel.open(new InetSocketAddress(PORT))) {
            ByteBuffer buf = ByteBuffer.allocate(24);

            Scanner user_in = new Scanner(System.in);
            System.out.println("Connecting...");

            (new Stampanje(sc,buf)).start();

            while(true) {
                if(user_in.hasNext()) {
                    if (user_in.next().equalsIgnoreCase("exit")) {
                        sc.close();
                        System.out.println("[end]");
                        break;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch(Exception e){
            e.printStackTrace();
        }

    }



}

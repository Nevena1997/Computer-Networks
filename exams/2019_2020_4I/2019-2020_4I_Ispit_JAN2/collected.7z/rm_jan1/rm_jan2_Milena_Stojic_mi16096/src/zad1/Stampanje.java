package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;

public class Stampanje extends Thread {
    private SocketChannel sc;
    private ByteBuffer buf;

    public Stampanje(SocketChannel sc, ByteBuffer buf){
        this.sc = sc;
        this.buf = buf;
    }


    @Override
    public void run() {
        try {
            var out = Channels.newChannel(System.out);
            while (true) {
                int n = sc.read(buf);
                if (n > 0) {
                    out.write(buf);
                } else if (n == -1) {
                    System.err.println("Neka greska");
                    System.exit(1);
                }

                try {
                    Thread.sleep(5 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }
        finally{
            try{
                sc.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

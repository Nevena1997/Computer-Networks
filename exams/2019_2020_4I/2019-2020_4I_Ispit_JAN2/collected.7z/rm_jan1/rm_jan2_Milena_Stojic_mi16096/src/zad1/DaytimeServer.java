package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Date;

class DaytimeServer {
    final static int DEFAULT_PORT = 12345;


    public static void main(String[] args) {
        System.out.println("Hello from DaytimeServer!");
        System.out.println("[start]");

        try (
                ServerSocketChannel s_channel = ServerSocketChannel.open();
                Selector selector = Selector.open();
                ) {

            if(!s_channel.isOpen() || !selector.isOpen())
            {
                System.err.println("Greska");
                System.exit(1);
            }

            s_channel.configureBlocking(false);
            s_channel.bind(new InetSocketAddress(DEFAULT_PORT));
            s_channel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();

                var selectedKeys = selector.selectedKeys();
                var it = selectedKeys.iterator();

                while (it.hasNext()) {
                    var key = it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()) {
                            ServerSocketChannel _s_channel = (ServerSocketChannel) key.channel();
                            var client = _s_channel.accept();

                            System.out.println("Accepting client... ");
                            System.out.println("Serving time... ");

                            ByteBuffer buffer = ByteBuffer.allocate(24);
                            var client_key = client.register(selector, SelectionKey.OP_WRITE);
                            client_key.attach(buffer);
                        } else if (key.isWritable()){

                            Date d = new Date();
                            ByteBuffer buf = (ByteBuffer) key.attachment();
                            buf.clear();
                            String date_content = "" + d.getDate() + "." +
                                    (1 + d.getMonth()) + "." + (1900 + d.getYear())
                                    + " | " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
                            buf.put(date_content.getBytes(), 0, date_content.getBytes().length);
                            buf.flip();
                        }
                    } catch(NotYetConnectedException e){
                        key.cancel();

                        try{
                            key.channel().close();
                        } catch (Exception cexception) {
                            cexception.printStackTrace();
                        }

                        System.out.println("Client disconnected");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}

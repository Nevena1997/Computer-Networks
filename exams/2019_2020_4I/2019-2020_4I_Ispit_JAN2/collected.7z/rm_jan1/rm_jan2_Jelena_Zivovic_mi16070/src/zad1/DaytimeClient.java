package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SocketChannel;

class DaytimeClient {
    public static void main(String[] args) {

        //System.out.println("Hello from DaytimeClient!");

        try (SocketChannel client = SocketChannel.open(new InetSocketAddress(12345))) {

            //client.configureBlocking(true);

            System.out.println("[start]");

            while (true) {


                (new GetDataClient(client)).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

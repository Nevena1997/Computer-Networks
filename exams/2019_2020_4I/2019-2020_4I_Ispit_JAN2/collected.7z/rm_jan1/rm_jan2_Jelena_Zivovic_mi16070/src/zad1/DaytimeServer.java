package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.sql.Time;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;

class DaytimeServer {
    public static void main(String[] args) {

        //System.out.println("Hello from DaytimeServer!");

        SocketAddress address = new InetSocketAddress("localhost", 12345);

        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            serverSocketChannel.bind(address);
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();

                            client.configureBlocking(false);
                            System.out.println("Accepted client");

                            client.register(selector, SelectionKey.OP_WRITE);

                        } else if (key.isWritable()) {



                            SocketChannel client = (SocketChannel)key.channel();
                            client.configureBlocking(false);


                            Date date = new Date();

                            Time now = new Time(date.getTime());

                            StringBuilder sb = new StringBuilder("");

                            String[] parts = String.valueOf(date).split(" ");

                            sb.append(parts[2]);
                            sb.append(".");

                            if (parts[1].equals("Jan")) {
                                sb.append("01");
                            } else if (parts[1].equals("Feb")) {
                                sb.append("02");
                            } else if (parts[1].equals("Mar")) {
                                sb.append("03");
                            } else if (parts[1].equals("Apr")) {
                                sb.append("04");
                            } else if (parts[1].equals("May")) {
                                sb.append("05");
                            } else if (parts[1].equals("Jun")) {
                                sb.append("06");
                            } else if (parts[1].equals("Jul")) {
                                sb.append("07");
                            } else if (parts[1].equals("Aug")) {
                                sb.append("08");
                            } else if (parts[1].equals("Sep")) {
                                sb.append("09");
                            } else if (parts[1].equals("Oct")) {
                                sb.append("10");
                            } else if (parts[1].equals("Nov")) {
                                sb.append("11");
                            } else if (parts[1].equals("Dec")) {
                                sb.append("12");
                            }

                            sb.append(".");
                            sb.append(parts[5]);

                            String message = sb.toString() + " | " + String.valueOf(now) + "\n";
                            ByteBuffer buffer = ByteBuffer.wrap(message.getBytes());


                            client.write(buffer);


                            buffer.clear();
                            System.out.println("Serving time...");
                            Thread.sleep(5000);


                            //client.register(selector, SelectionKey.OP_READ);


                        }
                    } catch(IOException e1) {
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException e2) {

                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

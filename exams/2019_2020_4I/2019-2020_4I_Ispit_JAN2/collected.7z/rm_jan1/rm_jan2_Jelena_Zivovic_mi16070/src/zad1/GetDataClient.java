package zad1;

import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SocketChannel;

public class GetDataClient extends Thread {
    SocketChannel client;

    public GetDataClient(SocketChannel s) {
        this.client = s;
    }

    public void run() {
        try {
            ByteBuffer buffer = ByteBuffer.allocate(100);

            CharBuffer cb = buffer.asCharBuffer();

            int n = client.read(buffer);
            if (n < 0) {
                System.out.println("[end]");
                System.exit(0);
            }
            buffer.flip();

            String str = new String(buffer.array());

            System.out.println(str.substring(0, str.indexOf(0)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Time;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.util.Date;

class DaytimeURLConnection extends URLConnection {
    public static int DEFAULT_PORT = 12345;
    private Socket connection;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {

        if (!this.connected) {
            int port = url.getPort();
            if (port < 1 || port > 65535) {
                port = DEFAULT_PORT;
            }

            this.connection  = new Socket(url.getHost(), port);
            this.connected = true;
        }

        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(
                        this.connection.getOutputStream()
                )
        );

        for (int i = 0; i < 3; i++) {
            Date date = new Date();

            Time now = new Time(date.getTime());

            StringBuilder sb = new StringBuilder("");

            String[] parts = String.valueOf(date).split(" ");

            sb.append(parts[2]);
            sb.append(".");

            if (parts[1].equals("Jan")) {
                sb.append("01");
            } else if (parts[1].equals("Feb")) {
                sb.append("02");
            } else if (parts[1].equals("Mar")) {
                sb.append("03");
            } else if (parts[1].equals("Apr")) {
                sb.append("04");
            } else if (parts[1].equals("May")) {
                sb.append("05");
            } else if (parts[1].equals("Jun")) {
                sb.append("06");
            } else if (parts[1].equals("Jul")) {
                sb.append("07");
            } else if (parts[1].equals("Aug")) {
                sb.append("08");
            } else if (parts[1].equals("Sep")) {
                sb.append("09");
            } else if (parts[1].equals("Oct")) {
                sb.append("10");
            } else if (parts[1].equals("Nov")) {
                sb.append("11");
            } else if (parts[1].equals("Dec")) {
                sb.append("12");
            }

            sb.append(".");
            sb.append(parts[5]);

            String message = sb.toString() + " | " + String.valueOf(now);

            out.write(message);
            out.newLine();
        }

        out.flush();

        out.close();





    }

    public InputStream getInputStream() throws IOException {

        if (!this.connected) {
            this.connect();


        }

        return this.connection.getInputStream();
    }
}

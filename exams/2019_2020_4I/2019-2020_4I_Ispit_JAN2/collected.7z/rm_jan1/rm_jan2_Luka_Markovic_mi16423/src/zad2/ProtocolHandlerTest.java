package zad2;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        System.out.println("Hello from protocol test method!");
    }
}

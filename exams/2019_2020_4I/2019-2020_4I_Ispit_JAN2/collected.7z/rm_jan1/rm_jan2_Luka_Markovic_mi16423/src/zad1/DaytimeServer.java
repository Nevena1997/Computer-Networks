package zad1;

import java.awt.desktop.SystemSleepEvent;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

class DaytimeServer extends Thread{


    public static void main(String[] args) {
        new DaytimeServer().start();

    }

    @Override
    public void run() {


        Date d = new Date();
        String dodatak;
        if(d.getMonth()+1>9){
            dodatak = "";
        }else{
            dodatak = "0";
        }
        String vreme = new String(Integer.toString(d.getDate()) + "." + dodatak + Integer.toString(d.getMonth()+1) +
                "." + Integer.toString(d.getYear()+1900) + " | " + new Time(d.getTime()));


        byte[] b=vreme.getBytes();
        ServerSocketChannel serverChannel;


        try {
            System.err.println("server listening on port 12345");
            serverChannel = ServerSocketChannel.open();
            Selector selector= Selector.open();

            serverChannel.bind(new InetSocketAddress(12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> it = keys.iterator();

                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            System.err.println("server accepted new client");

                            SelectionKey clientkey = client.register(selector,SelectionKey.OP_WRITE);


                            ByteBuffer buf = ByteBuffer.allocate(b.length);
                            buf.put(b);
                            buf.flip();
                            clientkey.attach(buf);

                        }
                        if(key.isWritable()){
                            System.err.println("server spreman za pisanje");
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer out = (ByteBuffer)key.attachment();
                            client.write(out);
                            out.flip();
                            sleep(5000);


                        }

                    } catch (Exception e) {
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }

                    }
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}







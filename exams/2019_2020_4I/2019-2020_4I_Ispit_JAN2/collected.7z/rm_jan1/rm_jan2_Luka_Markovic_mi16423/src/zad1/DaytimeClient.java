package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) {
        try{
            SocketChannel client = SocketChannel.open();


            client.connect(new InetSocketAddress(12345));


            System.err.println("client open");
            WritableByteChannel out = Channels.newChannel(System.out);
            ByteBuffer buffer = ByteBuffer.allocate(10);
            while (true) {
                int n = client.read(buffer);
                if (n == -1) {
                    System.err.println("greskaaaaaa");
                    break;
                }
                out.write(buffer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

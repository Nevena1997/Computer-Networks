package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;

import static java.nio.channels.Channels.newChannel;

class DaytimeClient {
    public static void main(String[] args) {
        System.out.println("Hello from DaytimeClient!");

        try(SocketChannel socket = SocketChannel.open(new InetSocketAddress(DaytimeServer.PORT))){

            ByteBuffer buf = ByteBuffer.allocate(30);
            while(buf.hasRemaining()){
                socket.read(buf);
            }
            System.out.println("sdfsdf");
            buf.flip();
            var channel = Channels.newChannel(System.out);
            channel.write(buf);
        }
        catch(IOException e){
            System.err.println("greska");
            e.printStackTrace();
        }
    }
}

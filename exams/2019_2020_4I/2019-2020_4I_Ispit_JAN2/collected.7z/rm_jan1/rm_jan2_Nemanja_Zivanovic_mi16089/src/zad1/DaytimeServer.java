package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Date;

class DaytimeServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from DaytimeServer!");

        try(
                ServerSocketChannel server = ServerSocketChannel.open();
                Selector selector = Selector.open()
                ){

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                //System.out.println("1 = " + selector.selectedKeys());
                selector.select();
                var it = selector.selectedKeys().iterator();
                //System.out.println("2 = " + selector.selectedKeys());

                //System.out.println("3 = " + selector.selectedKeys().size());
                while(it.hasNext()){
                    System.out.println("prva petlja");
                    System.out.println("3 = " + selector.selectedKeys().size());
                    SelectionKey selectedKey = it.next();
                    it.remove();
                    if(selectedKey.isAcceptable()){

                        ServerSocketChannel serv = (ServerSocketChannel)selectedKey.channel();
                        SocketChannel client = serv.accept();
                        client.configureBlocking(false);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                        System.out.println("10 = " + clientKey.isReadable());
                        System.out.println("10 = " + clientKey.isAcceptable());
                        System.out.println("10 = " + clientKey.isWritable());
                        System.out.println("10 = " + clientKey.isConnectable());
                        System.out.println("10 = " + clientKey.isValid());


                        break;
                        /*ByteBuffer buf = ByteBuffer.allocate(30);
                        buf.put(new Date().toString().getBytes());
                        buf.flip();
                        client.write(buf);
                        clientKey.attach(buf);

                        System.out.println("druga petlja");*/

                    }
                    else if(selectedKey.isReadable()){
                        System.out.println("treca petlja");
                        SocketChannel client = (SocketChannel)selectedKey.channel();
                        ByteBuffer buf = (ByteBuffer)selectedKey.attachment();
                        System.out.println("ovde");
                        client.write(buf);
                    }
                    System.out.println("van petlje");
                    break;
                }
            }

        }
        catch(IOException e){
            System.err.println("greska");
            e.printStackTrace();
        }

    }
}

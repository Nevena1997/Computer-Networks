package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

class DaytimeServer {

    public static int PORT = 12345;

    public static void main(String[] args) {

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {
            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);

            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if(key.isAcceptable()) {
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE );
                            ByteBuffer buf = ByteBuffer.allocate(512);

                            byte[] b = new byte[1];
                            buf.put(b); //TODO
                            buf.flip();
                            clientKey.attach(buf);

                        } else if(key.isReadable()) {
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buf = ByteBuffer.allocate(512);
                            client.read(buf);

                            key.cancel();
                            key.channel().close();


                        } else if(key.isWritable()) {

                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buf = (ByteBuffer)key.attachment();
                            client.write(buf);

                            while(true) {

                                byte[] b = new byte[512];
                                buf.clear();
                                buf.rewind();
                                buf.put(b);
                                buf.flip();
                            }

                        }
                    } catch (IOException e) {
                        key.cancel();
                        try{
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}






























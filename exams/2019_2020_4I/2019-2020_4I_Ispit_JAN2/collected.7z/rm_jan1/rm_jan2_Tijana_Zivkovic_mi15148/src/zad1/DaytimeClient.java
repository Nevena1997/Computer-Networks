package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class DaytimeClient extends Thread{

    private static SocketChannel client = null;

    private DaytimeClient(SocketChannel client) throws IOException {
        this.client = client;
        }


    public static void main(String[] args) throws IOException {

        client = SocketChannel.open(new InetSocketAddress("localhost", 12345));
        client.configureBlocking(true);
        new DaytimeClient(client).start();

        Scanner sc = new Scanner(System.in);
        String signal = sc.next();
        ByteBuffer buf = ByteBuffer.allocate(512);
        buf.put(signal.getBytes());
        client.write(buf);

        client.close();
    }

    @Override
    public void run(){

        try {

            while(true) {
                try {
                    sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                ByteBuffer buf = ByteBuffer.allocate(10);
                this.client.read(buf);
                String ispis = new String(buf.array());
                System.out.println(ispis);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }

    }
}

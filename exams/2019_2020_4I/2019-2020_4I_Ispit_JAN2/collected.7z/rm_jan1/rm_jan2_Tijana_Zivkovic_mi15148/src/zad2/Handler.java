package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

class Handler extends URLStreamHandler {
    @Override
    protected URLConnection openConnection(URL u) throws IOException {

        new DaytimeURLConnection(u);

        return null;
    }
}

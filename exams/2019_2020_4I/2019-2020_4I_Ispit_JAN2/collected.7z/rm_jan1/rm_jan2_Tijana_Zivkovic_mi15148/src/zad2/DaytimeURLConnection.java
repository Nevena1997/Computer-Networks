package zad2;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    Socket connection;

    public synchronized InputStream getInputStream() throws IOException{
        if(this.connected)
            return this.connection.getInputStream();
        else
            return null;
    }


    DaytimeURLConnection(URL url) {
        super(url);
    }

    @Override
    public synchronized void connect() throws IOException {

        if(this.connected == false) {
            int port = url.getPort();
            if (port == -1)
                port = 12345;

            Socket socket = new Socket(url.getHost(), port);
            BufferedInputStream in = new BufferedInputStream(socket.getInputStream());

            this.connected = true;
        }
    }
}

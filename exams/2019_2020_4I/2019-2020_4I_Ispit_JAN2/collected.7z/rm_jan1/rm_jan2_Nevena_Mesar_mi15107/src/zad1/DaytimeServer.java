package zad1;

import java.io.IOException;
import java.net.ServerSocket;

class DaytimeServer {

    public static final int DEFAUL_PORT = 12345;

    public static void main(String[] args) {

        try {
            ServerSocket server = new ServerSocket(DEFAUL_PORT);
            Socket client = server.accept();

        } catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }
}

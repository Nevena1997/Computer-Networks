package zad2;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException {
        URL url = new URL(null,"daytime://localhost:12345", new Handler());
        URLConnection con = url.openConnection();
        if(con.getInputStream()==null)return;
        try(BufferedReader input = new BufferedReader(new InputStreamReader(con.getInputStream())))
        {
            String response = input.readLine();
            System.out.println(response);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

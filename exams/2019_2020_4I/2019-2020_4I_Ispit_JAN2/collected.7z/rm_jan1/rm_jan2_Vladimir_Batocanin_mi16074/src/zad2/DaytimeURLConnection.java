package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection implements AutoCloseable {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    private Boolean connected;
    private Socket socket;
    private static int DEFPORT = 12345;
    private int port;

    DaytimeURLConnection(URL url) throws IOException {
        super(url);
        connected = false;
        connect();
    }

    @Override
    synchronized public void connect() throws IOException {
        if (!connected) {

            try {
                if (url.getPort() == -1)
                    port = DEFPORT;
                else
                    port = url.getPort();
                if (url.getProtocol().equals("datetime"));
                {
                    socket = new Socket(url.getHost(), port);
                    connected = true;
                }
            } catch (Exception e) {

            }
        }
    }

    @Override
    synchronized public InputStream getInputStream() throws IOException {
        if (!connected) {
            return null;

        } else {
            return socket.getInputStream();
        }


    }

    synchronized public InputStream openConnection() throws IOException {
        connect();
        return getInputStream();
    }

    @Override
    public void close() throws Exception {
        socket.close();
    }
}

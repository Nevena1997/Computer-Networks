package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) throws IOException, InterruptedException {
        InetSocketAddress adress = new InetSocketAddress("localhost",DaytimeServer.PORT);

        try{

            ClientThread thread = new ClientThread(adress);
            thread.start();
            while(true) {
                Scanner sc = new Scanner(System.in);
                String s = sc.next();
                if (s.trim().equals("stop"))
                {
                    thread.halt();
                    break;
                }
            }

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

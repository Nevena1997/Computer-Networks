package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;

class DaytimeServer {

    public static final int PORT = 12345;
    public static final int BUFF_SIZE = 42;

    public static void main(String[] args) {
        try (
                ServerSocketChannel serverSocket = ServerSocketChannel.open();
                Selector selector = Selector.open()
        ) {
            InetSocketAddress adress = new InetSocketAddress(12345);
            serverSocket.bind(adress);
            serverSocket.configureBlocking(false);

            serverSocket.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                if (selector.select() > 0) {
                    var keys = selector.selectedKeys().iterator();
                    while (keys.hasNext()) {
                        SelectionKey key = keys.next();
                        keys.remove();


                        if (key.isAcceptable()) {
                            System.out.println("Accepted client...");
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);

                            ByteBuffer buf = ByteBuffer.allocate(BUFF_SIZE);
                            buf.clear();

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
                            clientKey.attach(buf);
                        } else if (key.isWritable()) {
                            try {
                                Thread.sleep(5000);
                                System.out.println("Serving time...");
                                System.out.println();

                                //TODO: fix encoding bug
                                //For the love of me i can't find where i screwed up the encoding
                                SocketChannel client = (SocketChannel) key.channel();
                                ByteBuffer buf = (ByteBuffer) key.attachment();

                                byte[] currTS = getCurrTS();
                                buf.clear();
                                buf.put(currTS);
                                buf.flip();
                                System.out.println();
                                buf.rewind();
                                client.write(buf);
                            } catch (IOException e) {
                                System.out.println("Client disconnected");
                                key.cancel();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    private static byte[] getCurrTS() {
        Date date = new Date();
        String day = date.toString().substring(8, 10);
        String month = date.toString().substring(4, 7);
        String year = date.toString().substring(24, 28);
        String hour = date.toString().substring(11, 13);
        String minute = date.toString().substring(14, 16);
        String second = date.toString().substring(17, 19);
        switch (month) {
            case "Jan":
                month = "1";
                break;
            case "Feb":
                month = "2";
                break;
            case "Mar":
                month = "3";
                break;
            case "Apr":
                month = "4";
                break;
            case "May":
                month = "5";
                break;
            case "Jun":
                month = "6";
                break;
            case "Jul":
                month = "7";
                break;
            case "Aug":
                month = "8";
                break;
            case "Sep":
                month = "9";
                break;
            case "Oct":
                month = "10";
                break;
            case "Nov":
                month = "11";
                break;
            case "Dec":
                month = "12";
                break;
        }
        String finalDate = day + "." + month + "." + year + " | " + hour + ":" + minute + ":" + second;


        return finalDate.getBytes();

    }
}

package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class ClientThread extends Thread {

    private SocketChannel socket;
    private ByteBuffer buf;
    private Boolean stop;

    ClientThread(SocketAddress adress) throws IOException {
        stop=false;
        this.socket = SocketChannel.open();
        this.socket.connect(adress);

        buf = ByteBuffer.allocate(DaytimeServer.BUFF_SIZE);
        Boolean stop;
    }

    @Override
    public void run() {
        try {
            while (!stop) {
                buf.clear();
                socket.read(buf);
                buf.rewind();
                byte[] tmpBuf = new byte[DaytimeServer.BUFF_SIZE];
                while (buf.hasRemaining()) {
                    char c = buf.getChar();
                    System.out.print(c);
                }
                System.out.print("\r\n");

            }
            this.socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void halt() throws IOException {
        this.stop = true;
    }
}

package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class DaytimeURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    DaytimeURLConnection(URL url) {
        super(url);
    }

    private static int DEFAULT_PORT = 12345;
    private Socket socket;
    private boolean connected = false;

    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if (!this.connected) {
            connect();
            return null;
        }

        return this.socket.getInputStream();
    }



    @Override
    public synchronized void connect() throws IOException {
        if (!this.connected) {
            String host = url.getHost();
            int port = url.getPort();

            if (port == -1)
                port = DEFAULT_PORT;

            if (port != DEFAULT_PORT)
                throw new IOException("Bad port");

            this.socket = new Socket(host, port);
            this.connected = true;
        }
    }
}

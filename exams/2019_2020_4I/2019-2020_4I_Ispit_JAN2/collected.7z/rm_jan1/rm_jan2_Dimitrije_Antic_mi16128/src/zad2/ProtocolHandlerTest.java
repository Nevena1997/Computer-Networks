package zad2;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        try {
            URL u = new URL(null, "daytime://localhost", new Handler());

            var conn = u.openConnection();

            if (conn.getInputStream() == null)
                conn.connect();

            BufferedInputStream reader = new BufferedInputStream(conn.getInputStream());

            byte[] buf = new byte[21];
            while (true) {
                int bytesRead = 0;
                while (-1 != (bytesRead = reader.read(buf, bytesRead, buf.length-bytesRead))) {
                    if (buf.length == 21)
                        break;
                }

                System.out.println(new String(buf));
            }

            // reader treba da se zatvori, ali zbog while(true) je unreachable code
//            reader.close();
        } catch (UnknownHostException e) {
            System.out.println("Connection failed.");
        } catch (IOException e) {
            System.out.println("Connection failed.");
        }
    }
}

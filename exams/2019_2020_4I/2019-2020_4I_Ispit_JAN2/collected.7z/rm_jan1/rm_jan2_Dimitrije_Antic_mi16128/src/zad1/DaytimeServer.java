package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Date;

class DaytimeServer {
    public static void main(String[] args) {
        try (ServerSocketChannel socketChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()) {

            socketChannel.bind(new InetSocketAddress(12345));
            socketChannel.configureBlocking(false);
            socketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                var it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    var key = it.next();

                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            var server = (ServerSocketChannel) key.channel();
                            var client = (SocketChannel) server.accept();

                            client.configureBlocking(false);

                            var clientKey = client.register(selector, SelectionKey.OP_WRITE);
                            ByteBuffer buffer = ByteBuffer.wrap(prepareData().getBytes());
                            buffer.flip();
                            clientKey.attach(buffer);

                            System.out.println("Accepted client!");
                        } else if (key.isWritable()) {
                            var client = (SocketChannel) key.channel();

                            var buff = (ByteBuffer) key.attachment();

                            if (!buff.hasRemaining()) {
                                System.out.println("Serving time...");
                                buff.clear();

                                buff.put(ByteBuffer.wrap(prepareData().getBytes()));
                                buff.flip();
                            }

                            client.write(buff);
                        }
                    } catch (IOException e) {
                        System.out.println("Client disconnected.");
                        key.cancel();
                        try {
                            key.channel().close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
                Thread.sleep(5000);
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }


    }

    private static String prepareData() {
        Date current = new Date();
        String month = current.getMonth() + 1 < 10 ? "0"+(current.getMonth()+1) : current.getMonth() + "";
        String minutes = current.getMinutes() < 10 ? "0"+current.getMinutes() : current.getMinutes() + "";
        String seconds = current.getSeconds() < 10 ? "0"+current.getSeconds() : current.getSeconds() + "";
        return current.getDate() + "." + month + "." + (current.getYear()+1900) + " | "
                + current.getHours() + ":" + minutes + ":" + seconds;
    }

}

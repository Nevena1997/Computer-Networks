package zad1;

import java.util.Scanner;

class DaytimeClient {
    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Connecting...");
            Worker worker = new Worker();
            worker.start();
            String command = scanner.next();
            if (command.equalsIgnoreCase("bye")) {
                System.exit(0);
            }
        }
    }
}

package zad1;

import javax.swing.plaf.TableHeaderUI;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Worker extends Thread {

    public Worker() {
    }

    @Override
    public void run() {
        try (SocketChannel s = SocketChannel.open(new InetSocketAddress(12345))) {

            s.configureBlocking(true);
            ByteBuffer buff = ByteBuffer.allocate(21);

            while (true) {

                while (buff.hasRemaining())
                    s.read(buff);

                buff.rewind();
                System.out.println(new String(buff.array()));
                buff.clear();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try(    DatagramSocket socket = new DatagramSocket();
                Scanner scanner = new Scanner(System.in)){
            System.out.println("Klijent pokrenut!");
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            byte[] niz = ByteBuffer.allocate(4+4).putInt(x).putInt(y).array();
            DatagramPacket packet = new DatagramPacket(niz, 0, niz.length, new InetSocketAddress("localhost", 12345));
            socket.send(packet);

            DatagramPacket answerPacket = new DatagramPacket(new byte[10], 10);
            socket.receive(answerPacket);

            for(byte bajt : answerPacket.getData()){
                System.out.println(bajt);
            }

            String string = new String(answerPacket.getData(), 0, answerPacket.getLength(), StandardCharsets.UTF_8);
            System.out.println(string);

//            if(n){
//                System.out.println("Pokriven!");
//            }
//            else
//                System.out.println("Nije pokriven!");

        }catch(IOException e){

        }

    }
}

package zad2;

import zad1.Position;

import javax.xml.crypto.Data;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static Map<Position, Integer> mapa;

    public static void inicijalizuj_mapu(int x, int y){
        mapa = new HashMap<>();
        for(int currW = 0; currW <= x; currW++){
            for(int currH = 0; currH <= y; currH++){
                Position pos = new Position(currW, currH);
                mapa.put(pos, 0);
            }
        }

    }

    public static void dodaj_pozicije_u_mapu(int x, int y, int r){
        for(int currW = Math.max(x - r,0 ); currW <= x+r; currW++){
            for(int currH =  Math.max(y-r, 0); currH <=y+r; currH++){
                Position pos = new Position(currW, currH);
                int pojaviljivanja = mapa.get(pos);
                mapa.put(pos, pojaviljivanja+1);
            }
        }
//        mapa.forEach((k,v) -> {
//            System.out.println(k + " " + v);
//        });
//        System.out.println("ispisano");
    }


    public static void main(String[] args) {

        try(Scanner scanner = new Scanner(new FileInputStream("terrain.txt"));
            DatagramSocket socket = new DatagramSocket(12345)){
            int m, n;
            m = scanner.nextInt();
            n = scanner.nextInt();
            inicijalizuj_mapu(m,n);
            while(scanner.hasNextLine()){
                int x = scanner.nextInt();
                int y = scanner.nextInt();
                int r = scanner.nextInt();
                dodaj_pozicije_u_mapu(x,y,r);
            }
            System.out.println("terrain.txt ucitan!");
            System.out.println("Server pokrenut!");
            while(true){
                byte[] niz = new byte[8];
                DatagramPacket packet = new DatagramPacket(niz, 8);
                socket.receive(packet);
                System.out.println("Pristigao klijent!");
                ByteBuffer buffer = ByteBuffer.wrap(packet.getData());
                int x = buffer.getInt();
                int y = buffer.getInt();
                if(mapa.get(new Position(x,y)) == 0){
//                    byte bajt[] = {0};
                    System.out.println("usao gde ne treba");
                    byte[] bajt = "true".getBytes(StandardCharsets.UTF_8);
                    DatagramPacket packetAnswer = new DatagramPacket(bajt , bajt.length, packet.getAddress(), packet.getPort());
                    socket.send(packet);
                }
                else {
                    byte[] bajt = {0};
                    DatagramPacket packetAnswer = new DatagramPacket(bajt , bajt.length, packet.getAddress(), packet.getPort());
                    socket.send(packet);;
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }

    }
}

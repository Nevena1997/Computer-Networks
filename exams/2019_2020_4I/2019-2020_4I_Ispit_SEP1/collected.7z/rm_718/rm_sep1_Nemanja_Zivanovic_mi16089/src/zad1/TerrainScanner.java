package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        try(SocketChannel socket = SocketChannel.open(  new InetSocketAddress("localhost", Hub.DEFAULT_PORT)      );
            Scanner scanner = new Scanner(System.in)){
            socket.configureBlocking(true);
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            int r = scanner.nextInt();

            ByteBuffer buffer = ByteBuffer.allocate(4+4+4);
            buffer.putInt(x);
            buffer.putInt(y);
            buffer.putInt(r);
            buffer.flip();
            while(buffer.hasRemaining()==true){
                socket.write(buffer);
            }
            buffer = ByteBuffer.allocate(100);
            while(true){
                int vrednost = socket.read(buffer);
                if(vrednost == -1)
                    break;
                buffer.flip();
                double teren = buffer.getDouble();
                System.out.println(teren);
                buffer.clear();
            }

            System.out.println("zavrseno slanje");

        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

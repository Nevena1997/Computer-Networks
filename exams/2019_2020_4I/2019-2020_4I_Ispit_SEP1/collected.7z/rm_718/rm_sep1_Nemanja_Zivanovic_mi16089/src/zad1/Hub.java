package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class Hub {

    public static final int DEFAULT_PORT = 7337;

    public static Map<Position, Integer> mapa;
    public static Map<SocketChannel, ByteBuffer> soketMapa = new HashMap<>();


    public static void inicijalizuj_mapu(int x, int y){
        mapa = new HashMap<>();
        for(int currW = 0; currW <= x; currW++){
            for(int currH = 0; currH <= y; currH++){
                Position pos = new Position(currW, currH);
                mapa.put(pos, 0);
            }
        }

    }

    public static void dodaj_pozicije_u_mapu(int x, int y, int r){
        for(int currW = Math.max(x - r,0 ); currW <= x+r; currW++){
            for(int currH =  Math.max(y-r, 0); currH <=y+r; currH++){
                Position pos = new Position(currW, currH);
                int pojaviljivanja = mapa.get(pos);
                mapa.put(pos, pojaviljivanja+1);
            }
        }
//        mapa.forEach((k,v) -> {
//            System.out.println(k + " " + v);
//        });
    }

    public static void ukloni_pozicije_u_mapi(int x, int y, int r){
        for(int currW = Math.max(x - r, 0); currW <= x+r; currW++){
            for(int currH = Math.max(y-r, 0); currH <=y+r; currH++){
                Position pos = new Position(currW, currH);
                int pojaviljivanja = mapa.get(pos);
                mapa.put(pos, pojaviljivanja-1);
            }
        }
    }

    public static double pokrivenost_terena(int x, int y){
        int ukupno = 0;
        int ukupnoPozicija = 0;
        for(int currW = 0; currW <= x; currW++){
            for(int currH = 0; currH <= y; currH++){
                Position pos = new Position(currW, currH);
                int pojaviljivanja = mapa.get(pos);
                if(pojaviljivanja!=0)
                    ukupno+=1;
                ukupnoPozicija += 1;
            }
        }
//        System.out.println("ukupno pokriveno " + ukupno);
//        System.out.println("ukupnoi pozicija" + ukupnoPozicija);
        return ukupno*1.0 / ukupnoPozicija;
    }


    public static void main(String[] args) {

        try(ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner scanner = new Scanner(System.in)){

            int m, n;
            m = scanner.nextInt();//sirina
            n = scanner.nextInt();//visina
            inicijalizuj_mapu(m, n);
            serverSocketChannel.bind(new InetSocketAddress(Hub.DEFAULT_PORT));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = keys.iterator();
                while(iterator.hasNext()){

                    SelectionKey key = iterator.next();
                    iterator.remove();
                    if(key.isAcceptable()){
                        ServerSocketChannel server = (ServerSocketChannel)key.channel();
                        SocketChannel socket = server.accept();
                        socket.configureBlocking(false);
//                        System.out.println("ispis");
                        SelectionKey socketKey = socket.register(selector, SelectionKey.OP_READ);
                        socketKey.attach(ByteBuffer.allocate(4+4+4));
                    } else if(key.isReadable()){
//                        System.out.println("ispis2");
                        SocketChannel socketChannel = (SocketChannel)key.channel();
                        ByteBuffer buffer = (ByteBuffer)key.attachment();
                        socketChannel.read(buffer);
                        buffer.flip();
                        int x = buffer.getInt();
//                        System.out.println(x);
                        int y = buffer.getInt();
//                        System.out.println(y);
                        int r = buffer.getInt();
//                        System.out.println(r);
//                        System.out.println("(" + x + ", " + y + ") " + r);
                        buffer.flip();
                        soketMapa.put(socketChannel, buffer);
                        if(x > m || x < 0 || y > n || y < 0 || r < 0) {
                            try {
                                key.cancel();
                                key.channel().close();
                                continue;
                            } catch (IOException e) {
                                System.err.println("dimenzije terena");
                            }
                        }
                        dodaj_pozicije_u_mapu(x,y,r);

                        if(pokrivenost_terena(m, n) == 1)
                            break;

                        key.attach(System.currentTimeMillis());

                        key.interestOps(SelectionKey.OP_WRITE);

                    } else if(key.isWritable()){
                        try {
                            long vreme = System.currentTimeMillis();
                            if (vreme - (long) key.attachment() < 5000)
                                continue;
                            double teren = pokrivenost_terena(m, n);
                            ByteBuffer buffer = ByteBuffer.allocate(8).putDouble(teren);
                            buffer.flip();
                            ((SocketChannel) key.channel()).write(buffer);
                            key.attach(System.currentTimeMillis());
                        }catch(IOException e){
                            ByteBuffer buffer = soketMapa.get(key.channel());
                            int x = buffer.getInt();
                            int y = buffer.getInt();
                            int r = buffer.getInt();
                            ukloni_pozicije_u_mapi(x,y,r);
                            key.cancel();
                            key.channel().close();
                        }
                    }
                }
            }

        }catch(IOException e){
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {

    public static void main(String[] args) throws IOException {

        Scanner scanner = new Scanner(System.in);

        int x = scanner.nextInt();
        int y = scanner.nextInt();
        int r = scanner.nextInt();

        var socketChannel = SocketChannel.open(new InetSocketAddress(7337));

        var buffer = ByteBuffer.allocate(12);
        buffer.putInt(x);
        buffer.putInt(y);
        buffer.putInt(r);

        buffer.flip();

        socketChannel.write(buffer);

        var receivingBuffer = ByteBuffer.allocate(8);

        //noinspection InfiniteLoopStatement
        while (true) {
            receivingBuffer.clear();
            socketChannel.read(receivingBuffer);
            receivingBuffer.flip();
            System.out.println(receivingBuffer.getDouble());
        }


    }

}

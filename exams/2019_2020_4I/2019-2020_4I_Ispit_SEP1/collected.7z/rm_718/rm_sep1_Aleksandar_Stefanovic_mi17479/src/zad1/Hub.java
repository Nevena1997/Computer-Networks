package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Hub {

    private static class Node {
        int x, y, r;
        SocketChannel channel;

        Node(int x, int y, int r, SocketChannel channel) {
            this.x = x;
            this.y = y;
            this.r = r;
            this.channel = channel;
        }
    }

    private static double coveredAreaRatio = 0.0;
    private static int m, n;

    private static List<Node> nodes = new ArrayList<>();

    public static void main(String[] args) throws IOException {

        var scanner = new Scanner(System.in);

        m = scanner.nextInt();
        n = scanner.nextInt();

        var serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.configureBlocking(false);
        serverSocketChannel.bind(new InetSocketAddress(7337));

        var selector = Selector.open();

        serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

        new NotifyingThread().start();

        //noinspection InfiniteLoopStatement
        while (true) {
            selector.select();

            var iterator = selector.selectedKeys().iterator();
            while (iterator.hasNext()) {
                var key = iterator.next();
                iterator.remove();

                if (key.isAcceptable()) {

                    var sSocketChannel = (ServerSocketChannel) key.channel();

                    var clientSocketChannel = sSocketChannel.accept();
                    clientSocketChannel.configureBlocking(false);
                    clientSocketChannel.register(selector, SelectionKey.OP_READ);
                }

                if (key.isReadable()) {

                    var socketChannel = (SocketChannel) key.channel();

                    var byteBuffer = ByteBuffer.allocate(12);

                    while (byteBuffer.hasRemaining()) {
                        socketChannel.read(byteBuffer);
                    }

                    byteBuffer.rewind();

                    int x = byteBuffer.getInt();
                    int y = byteBuffer.getInt();
                    int r = byteBuffer.getInt();

                    if (x < 0 || x > m || y < 0 || y > n) {
                        socketChannel.close();
                        continue;
                    }
                    // No need for non-blocking
                    socketChannel.configureBlocking(false);
                    nodes.add(new Node(x, y, r, socketChannel));
                    updateCoveredArea();
                    if (coveredAreaRatio == 1) {
                        // Client channels are closed in a separate thread
                        serverSocketChannel.close();
                        selector.close();
                        break;
                    }

                    // Further work with clients is done in a separate thread
                    key.cancel();
                }
            }

        }


    }

    private static void updateCoveredArea() {
        var area = new boolean[m][n];
        final int[] coveredCells = {0}; // A dirty hack to enable non-final variables in lambdas
        nodes.forEach(node -> {

            int topBound = Math.min(node.y + node.r, n);
            int bottomBound = Math.max(node.y - node.r, 0);
            int leftBound = Math.max(node.x - node.r, 0);
            int rightBound = Math.min(node.x + node.r, m);

            for (int i = leftBound; i < rightBound; i++) {
                for (int j = bottomBound; j < topBound; j++) {
                    // If not previously covered, increment coverage
                    if (!area[i][j]) {
                        coveredCells[0]++;
                    }
                    area[i][j] = true;
                }
            }
        });

        coveredAreaRatio = ((double) coveredCells[0]) / (m * n);
    }

    private static class NotifyingThread extends Thread{

        @Override
        public void run() {
            while (coveredAreaRatio != 1) {
                var buffer = ByteBuffer.allocate(8);
                buffer.putDouble(coveredAreaRatio);

                buffer.flip();

                var nodeIterator = nodes.iterator();

                while (nodeIterator.hasNext()) {
                    var node = nodeIterator.next();
                    var channel = node.channel;
                    try {
                        buffer.rewind();
                        channel.write(buffer);
                    } catch (IOException e) {
                        // The client disconnected
                        nodeIterator.remove();
                        updateCoveredArea();
                    }
                }

                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Time to close
            nodes.forEach(node -> {
                try {
                    node.channel.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
    }

}

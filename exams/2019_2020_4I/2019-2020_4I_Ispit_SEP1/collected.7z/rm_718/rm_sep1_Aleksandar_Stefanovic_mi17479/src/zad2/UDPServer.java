package zad2;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Scanner;

public class UDPServer {

    public static class Node {
        int x, y, r;

        Node(int x, int y, int r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
    }

    public static void main(String[] args) {


        try (var socket = new DatagramSocket(12345)) {

            var scanner = new Scanner(new File("terrain.txt"));

            int m = scanner.nextInt();
            int n = scanner.nextInt();

            var nodes = new ArrayList<Node>();

            while (scanner.hasNextInt()) {
                int x = scanner.nextInt();
                int y = scanner.nextInt();
                int r = scanner.nextInt();
                nodes.add(new Node(x, y, r));
            }


            boolean[][] covered = new boolean[m][n];

            nodes.forEach(node -> {
                int topBound = Math.min(node.y + node.r, n);
                int bottomBound = Math.max(node.y - node.r, 0);
                int leftBound = Math.max(node.x - node.r, 0);
                int rightBound = Math.min(node.x + node.r, m);

                for (int i = leftBound; i <= rightBound; i++) {
                    for (int j = bottomBound; j <= topBound; j++) {
                        covered[i][j] = true;
                    }
                }
            });


            var receivingBuffer = ByteBuffer.allocate(8);
            var receivingPacket = new DatagramPacket(receivingBuffer.array(), 8);

            var sendingBuffer = ByteBuffer.allocate(4);
            var sendingPacket = new DatagramPacket(sendingBuffer.array(), 4);

            //noinspection InfiniteLoopStatement
            while (true) {
                receivingBuffer.clear();
                socket.receive(receivingPacket);
                System.out.println("Pristigao klijent!");
                int x = receivingBuffer.getInt();
                int y = receivingBuffer.getInt();

                int retVal = (x < 0 || x > m || y < 0 || y > n) ? 0 : covered[x][y] ? 1 : 0;

                var socketAddress = receivingPacket.getSocketAddress();
                sendingPacket.setSocketAddress(socketAddress);
                sendingBuffer.rewind();
                sendingBuffer.putInt(retVal);
                sendingBuffer.flip();
                sendingPacket.setData(sendingBuffer.array()); // This may be unnecessary
                socket.send(sendingPacket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

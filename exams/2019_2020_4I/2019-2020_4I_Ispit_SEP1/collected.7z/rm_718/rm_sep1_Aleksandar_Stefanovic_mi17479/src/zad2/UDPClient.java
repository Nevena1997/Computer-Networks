package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {


        var scanner = new Scanner(System.in);

        var x = scanner.nextInt();
        var y = scanner.nextInt();

        var byteBuffer = ByteBuffer.allocate(8);
        byteBuffer.putInt(x);
        byteBuffer.putInt(y);
        byteBuffer.flip();

        try(var socket = new DatagramSocket()) {
            var local = InetAddress.getLocalHost();
            var packet = new DatagramPacket(byteBuffer.array(), 8, local, 12345);

            socket.send(packet);

            var receivingBuffer = ByteBuffer.allocate(4);

            var receivingPacket = new DatagramPacket(receivingBuffer.array(), 4);

            socket.receive(receivingPacket);

            receivingBuffer.rewind();

            int covered = receivingBuffer.getInt();

            if (covered == 1) {
                System.out.println("Pokriven!");
            } else {
                System.out.println("Nije pokriven!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

public class Skener {
    private int x;
    private int y;
    private int r;

    Skener(int x, int y, int r) {
        this.r = r;
        this.x = x;
        this.y = y;
    }

    public boolean pripada(int a, int b) {
        if (a < this.x-this.r | a > this.x+this.r | b < this.y-this.r | b > this.y+this.r) {
            return false;
        } else {
            return true;
        }
    }


}

package zad2;

import java.io.*;
import java.net.*;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class UDPServer {
    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(12345)) {

            Set<Skener> skeneri = new HashSet();

            Scanner file  = new Scanner(new FileInputStream("terrain.txt"));

            String mapa = file.nextLine();
            String[] mapDimensions = mapa.split(" ");
            int m = Integer.parseInt(mapDimensions[0]);
            int n = Integer.parseInt(mapDimensions[1]);

            while (file.hasNextLine()) {
                String terrainScanner = file.nextLine();
                String[] scannerCoords = terrainScanner.split(" ");
                int x = Integer.parseInt(scannerCoords[0]);
                int y = Integer.parseInt(scannerCoords[1]);
                int r = Integer.parseInt(scannerCoords[2]);

                skeneri.add(new Skener(x,y,r));
            }


            byte[] niz = new byte[1024];
            DatagramPacket hello = new DatagramPacket(niz, 1024);
            server.receive(hello);
            System.out.println("Pristigao klijent!");

            String poruka = new String(hello.getData());
            poruka = poruka.trim();
//            System.out.println(poruka);

            String[] poz = poruka.split(" ");
            int xClient = Integer.parseInt(poz[0]);
            int yClient = Integer.parseInt(poz[1]);

//                System.out.println(poruka);

            boolean indikator = false;
            for (Skener e : skeneri) {
                if (e.pripada(xClient, yClient)) {
                    indikator = true;
                    break;
                }
            }

            String porukaZaKlijenta;

            if (indikator) {
                porukaZaKlijenta = "pokriven";
            } else {
                porukaZaKlijenta = "nepokriven";
            }

//            System.out.println(porukaZaKlijenta);

            byte[] nizSlanje = porukaZaKlijenta.getBytes();
            DatagramPacket slanje = new DatagramPacket(nizSlanje, porukaZaKlijenta.length(), hello.getAddress(), 12345);
            server.send(slanje);



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try (DatagramSocket ds = new DatagramSocket()) {

            Scanner userIn = new Scanner(System.in);

            int x = userIn.nextInt();
            String xS = String.valueOf(x);

            int y = userIn.nextInt();
            String yS = String.valueOf(y);

            String slanjeString = xS + " " + yS;
            byte[] nizSlanje = slanjeString.getBytes();
            DatagramPacket slanje = new DatagramPacket(nizSlanje, slanjeString.length(), InetAddress.getLocalHost(), 12345);
            ds.send(slanje);

//            System.out.println("Pre odgovora");
            String odgovorServera;
            byte[] nizOdgovor = new byte[1024];
            DatagramPacket response = new DatagramPacket(nizOdgovor, 1024);
            ds.receive(response);
//            System.out.println("posle odgovora");

            odgovorServera = new String(response.getData());
            odgovorServera = odgovorServera.trim();
            if (odgovorServera.equals("pokriven")) {
                System.out.println("Pokriven!");
            } else {
                System.out.println("Nije pokriven!");
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

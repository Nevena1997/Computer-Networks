package zad1;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        System.out.println("glhf from TerrainScanner");
        try (SocketChannel socket = SocketChannel.open(
                new InetSocketAddress("localhost", 7337)
            );
             Scanner userIn = new Scanner(System.in);
        ) {
            ByteBuffer buff = ByteBuffer.allocate(4);


            int x = userIn.nextInt();
            int y = userIn.nextInt();
            int r = userIn.nextInt();


            String serverResponse;

//            while (true) {
//                serverResponse = fromServer.readLine();
//                if (serverResponse == null) {
//                    break;
//                }
//                System.out.println(serverResponse);
//            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

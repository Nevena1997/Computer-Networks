package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    public static void main(String[] args) {

        try (Scanner serverIn = new Scanner(System.in)) {
            int m = serverIn.nextInt();
            int n = serverIn.nextInt();
        }

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open();
        ) {
            if (!server.isOpen() | ! selector.isOpen()) {
                System.err.println("Nisu otvoreni server ili selektor!");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(7337));
            server.register(selector, SelectionKey.OP_ACCEPT);
            server.configureBlocking(false);

            while (true) {
                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while (iter.hasNext()) {
                    SelectionKey currentKey = iter.next();
                    iter.remove();

                    SocketChannel clientChannel = (SocketChannel) currentKey.channel();

                    if (currentKey.isAcceptable()) {

                    } else if (currentKey.isWritable()) {

                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("glhf from Hub");
    }
}

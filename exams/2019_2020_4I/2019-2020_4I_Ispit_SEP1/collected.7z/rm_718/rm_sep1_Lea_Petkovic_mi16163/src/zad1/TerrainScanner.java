package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Arrays;
import java.util.Scanner;

public class TerrainScanner {
    //private int x, y, r;

    public static void main(String[] args) {
        try {
            InetSocketAddress address = new InetSocketAddress("localhost", Hub.PORT);
            SocketChannel socket = SocketChannel.open(address);

            Scanner sc = new Scanner(System.in);
            System.err.println("Please, enter x:");
            int x = sc.nextInt();
            System.err.println("Please, enter y:");
            int y = sc.nextInt();
            System.err.println("Please, enter r:");
            int r = sc.nextInt();
            ByteBuffer buf = ByteBuffer.allocate(128);
            buf.putInt(x).putInt(y).putInt(r);
            buf.putInt('\n');

            buf.flip();
            socket.write(buf);

            WritableByteChannel out = Channels.newChannel(System.out);

            buf.clear();
            socket.read(buf);
            buf.flip();
            System.err.println(Arrays.toString(buf.array()));
            out.write(buf);
            //buf.clear();

            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    public static final int PORT = 7337;

    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open(); ) {
            System.err.println("Server pokrenut");

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            // unos m,n
            Scanner sc = new Scanner(System.in);
            int m = sc.nextInt();
            int n = sc.nextInt();
            int teren = m*n;
            int pokrivenost = 0;

            while (true) {
                System.err.println();
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                //Thread.sleep(5000);
                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            System.err.println("Accept");
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);

                            client.register(selector, SelectionKey.OP_READ);

                        } else if (key.isReadable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            if (buf == null) {
                                buf = ByteBuffer.allocate(256);
                                key.attach(buf);
                            }

                            System.err.println("isReadable");

                            buf.clear();
                            client.read(buf);

                            //client.read(buf);
                            buf.rewind();
                            int x = buf.getInt();
                            System.err.println("x: " + x);
                            int y = buf.getInt();
                            System.err.println("y: " + y);
                            int r = buf.getInt();
                            System.err.println("r: " + r);

                            // provera ispravnosti pozicije
                            if (x < 0 || y < 0 || r < 0 || x > m || y > n) {
                                key.cancel();
                                key.channel().close();
                            }

                            // koliko kvadrata je u terenu
                            if (x+r <= n || x-r>=0 || y+r <= m || y-r>=0) {
                                pokrivenost += 4*r*r;
                            } else {
                                // TODO da li su svi unutar terena
                            }

                            // napuniti bafer za pisanje posle
                            ByteBuffer buffer = ByteBuffer.allocate(256);
                            buffer.putDouble(pokrivenost/teren);
                            buffer.flip();
                            key.attach(buffer);
                            //System.err.println(Arrays.toString(buffer.array()));

                            key.interestOps(SelectionKey.OP_WRITE);
                        } else if (key.isWritable()) {
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buf = (ByteBuffer) key.attachment();

                            if (!buf.hasRemaining()) {
                                buf.flip();
                                key.cancel();
                                key.channel().close();
                            }
                            // ispisi bafer
                            client.write(buf);

                            // proveri jesmo li sve pokrili
                            if (pokrivenost >= teren) {
                                key.cancel();
                                key.channel().close();
                            }

                        }
                    } catch (Exception e) {
                        key.cancel();
                        key.channel().close();
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

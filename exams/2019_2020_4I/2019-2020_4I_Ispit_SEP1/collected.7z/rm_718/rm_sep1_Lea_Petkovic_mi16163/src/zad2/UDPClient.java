package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try (DatagramSocket socket = new DatagramSocket();) {
            System.err.println("Klijent pokrenut!");

            Scanner sc = new Scanner(System.in);
            int x = sc.nextInt();
            int y = sc.nextInt();

            ByteBuffer buf = ByteBuffer.allocate(128);
            buf.putInt(x).putInt(y);

            DatagramPacket req = new DatagramPacket(buf.array(), buf.array().length,
                                                    InetAddress.getByName("localhost"),
                                                    UDPServer.PORT);
            socket.send(req);

            byte[] res = new byte[256];
            DatagramPacket response = new DatagramPacket(res, res.length);
            socket.receive(response);

            System.out.println(new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8));

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class UDPServer {
    public static final int PORT = 12345;

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(PORT);
             BufferedReader fin = Files.newBufferedReader(Paths.get("terrain.txt"))) {
            System.err.println("Server pokrenut!");

            // m i n
            String line = fin.readLine();
            int n = Integer.parseInt(line.substring(0, line.indexOf(" ")));
            int m = Integer.parseInt(line.substring(2));

            // lista skenera
            List<String> scanners = new LinkedList<>();
            while ((line = fin.readLine()) != null) {
                scanners.add(line);
            }

            while(true) {
                byte[] buf = new byte[512];
                DatagramPacket req = new DatagramPacket(buf, buf.length);
                server.receive(req);
                System.out.println("Pristigao klijent!");

                ByteBuffer location = ByteBuffer.wrap(req.getData());
                location.rewind();
                int x = location.getInt();
                int y = location.getInt();

                byte[] pokriven = "Pokriven!".getBytes();
                byte[] nijepokriven = "Nije pokriven!".getBytes();

                if (y >=0 && y <= m && x >= 0 && x <= n) {

                    var it = scanners.iterator();
                    boolean ind = false;
                    while (it.hasNext()) {
                        String scanner = it.next();
                        // vrednosti trenutnog skenera
                        int xs = Integer.parseInt(scanner.substring(0, scanner.indexOf(" ")));
                        scanner = scanner.substring(2);
                        System.err.println(xs);
                        int ys = Integer.parseInt(scanner.substring(0, scanner.indexOf(" ")));
                        System.err.println(ys);

                        int rs = Integer.parseInt(scanner.substring(2));
                        System.err.println(rs);

                        // da li skener obuhvata lokaciju
                        if (y >=ys-rs && y <= ys+rs && x >= xs-rs && x <= xs+rs) {
                            DatagramPacket response = new DatagramPacket(pokriven, pokriven.length, req.getAddress(), req.getPort());
                            server.send(response);
                            ind = true;
                            break;
                        }
                    }

                    if (!ind) {
                        DatagramPacket response = new DatagramPacket(nijepokriven, nijepokriven.length, req.getAddress(), req.getPort());
                        server.send(response);
                    }

                } else {
                    DatagramPacket response = new DatagramPacket(nijepokriven, nijepokriven.length, req.getAddress(), req.getPort());
                    server.send(response);
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

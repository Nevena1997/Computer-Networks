package zad2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Scanner;

public class UDPServer {
    public static final int PORT = 12345;

    public static void main(String[] args)  {
        int m, n;
        int[] x = new int[1024];
        int[] y = new int[1024];
        int[] r = new int[1024];
        int i = 0;
        try {
            Scanner file_scanner =  new Scanner(new File("terrain.txt"));
            System.out.println("terrain.txt ucitan!");

            m = file_scanner.nextInt();
            n = file_scanner.nextInt();
            while(file_scanner.hasNextInt()) {
                x[i] = file_scanner.nextInt();
                y[i] = file_scanner.nextInt();
                r[i] = file_scanner.nextInt();
                i++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try(DatagramSocket server = new DatagramSocket(PORT)) {
            System.out.println("Server pokrenut!");

            while (true) {
                DatagramPacket primljen_paket = new DatagramPacket(new byte[1024], 1024);
                server.receive(primljen_paket);
                System.out.println("Stigao datagram!");

                String primljeno = new String(primljen_paket.getData(), 0, primljen_paket.getLength());
                String[] niz = primljeno.split(" ");

                int x1 = Integer.valueOf(niz[0]);
                int y1 = Integer.valueOf(niz[1]);
                String pokriven = "false";
                for (int j = 0; j < i; j++) {
                    if ((x1 >= x[j] - r[j]) && (x1 <= x[j] + r[j]) && (y1 >= y[j] - r[j]) && (y1 <= y[j] + r[j]) ) {
                        pokriven = "true";
                        break;
                    }
                }

                DatagramPacket paket_za_slanje = new DatagramPacket(pokriven.getBytes(), pokriven.length(), primljen_paket.getAddress(), primljen_paket.getPort());
                server.send(paket_za_slanje);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

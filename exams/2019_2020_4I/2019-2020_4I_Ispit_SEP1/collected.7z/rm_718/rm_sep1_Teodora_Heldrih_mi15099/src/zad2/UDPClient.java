package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {
            System.out.println("Klijent pokrenut!");

            String lokacija_klijenta = sc.nextLine();
            DatagramPacket paket_za_slanje = new DatagramPacket(lokacija_klijenta.getBytes(), lokacija_klijenta.length(), new InetSocketAddress("localhost", UDPServer.PORT));
            klijent.send(paket_za_slanje);

            DatagramPacket primljen_paket = new DatagramPacket(new byte[1024], 1024);
            klijent.receive(primljen_paket);

            String primljeno = new String(primljen_paket.getData(), 0, primljen_paket.getLength());
            if (primljeno.equalsIgnoreCase("false")) {
                System.out.println("Nije pokriven!");
            } else {
                System.out.println("Pokriven!");
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

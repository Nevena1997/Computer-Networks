package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class Hub {
    public static void main(String[] args) {
        try (SocketChannel klijent = SocketChannel.open();
             Scanner sc = new Scanner(System.in)) {
            klijent.connect(new InetSocketAddress("localhost", TerrainScanner.PORT));
            klijent.configureBlocking(true);

            String linija = sc.nextLine();
            ByteBuffer buff1 = ByteBuffer.allocate(1024);
            buff1.put(linija.getBytes());
            buff1.put((byte) '\n');

            buff1.flip();
            klijent.write(buff1);

            ByteBuffer buff = ByteBuffer.allocate(5);
            klijent.read(buff);

            System.out.println(buff.get());
            buff.clear();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

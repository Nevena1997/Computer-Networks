package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class TerrainScanner {
    public static final int PORT = 7337;

    public static void main(String[] args) {
        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner sc = new Scanner(System.in)) {

            if (!server.isOpen() || !selector.isOpen()) {
                System.err.println("Nije uspeo da otvori server ili selektor!");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            int m, n;
            m = sc.nextInt();
            n = sc.nextInt();

            String procenat = "1";

            while (true) {
                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while (iter.hasNext()) {
                    SelectionKey trenutan = iter.next();

                    iter.remove();

                    // Server
                    if (trenutan.isAcceptable()) {
                        ServerSocketChannel server_kljuc = (ServerSocketChannel) trenutan.channel();

                        SocketChannel klijent = server_kljuc.accept();
                        klijent.configureBlocking(false);
                        SelectionKey klijent_kljuc =  klijent.register(selector, SelectionKey.OP_WRITE);

                        ByteBuffer buff = ByteBuffer.allocate(5);
                        buff.put(procenat.getBytes());
                        buff.put((byte) '\n');

                        buff.flip();
                        klijent_kljuc.attach(buff);
                    } else if (trenutan.isWritable()) {
                        SocketChannel klijent = (SocketChannel) trenutan.channel();

                        ByteBuffer buff = (ByteBuffer) trenutan.attachment();
                        klijent.write(buff);
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", 7337))){

            if(!client.isOpen()){
                System.err.println("client is not open");
                System.exit(1);
            }
            client.configureBlocking(true);

            System.out.println("Unesite x: ");
            int x = in.nextInt();

            System.out.println("Unesite y: ");
            int y = in.nextInt();

            System.out.println("Unesite r: ");
            int r = in.nextInt();


            ByteBuffer buff = ByteBuffer.allocate(1024);

            buff.clear();

            buff.put((x + " " + y + " " + r + "\r\n").getBytes());

            buff.flip();

            client.write(buff);
            buff.clear();

            ByteBuffer buffRead = ByteBuffer.allocate(1024);
            buffRead.clear();

            while (client.read(buffRead) != -1){

                System.out.println(new String(buffRead.array(), 0, buffRead.position()));
                buffRead.clear();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

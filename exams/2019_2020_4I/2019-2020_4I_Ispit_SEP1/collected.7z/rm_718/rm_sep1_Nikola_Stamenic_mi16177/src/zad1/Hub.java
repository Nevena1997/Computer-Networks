package zad1;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Hub {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Unesite m: ");
        int m = in.nextInt();
        System.out.println("Unesite n: ");
        int n = in.nextInt();

        in.close();

        int nextId = 1;

        HashMap<Integer, ClientData> clientSpace = new HashMap<>();
        boolean[][] usedSpace = new boolean[m][n];

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){

            if(!selector.isOpen() || !server.isOpen()){
                System.err.println("Something went wrong");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(7337));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();

                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = keys.iterator();

                while (iterator.hasNext()){
                    SelectionKey key = iterator.next();
                    iterator.remove();
                    Thread.sleep(5000);
                    String usedSpacePct = usedSpacePercenate(usedSpace);
                    try{
                        if(key.isAcceptable()){
                            //server
                            System.err.println("client accept");
                            ServerSocketChannel s = (ServerSocketChannel) key.channel();
                            SocketChannel client = s.accept();
                            client.configureBlocking(false);

                            ByteBuffer buff = ByteBuffer.allocate(1024);
                            Integer id = nextId;
                            nextId++;

                            ClientData dat = new ClientData(id, buff);

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            clientKey.attach(dat);
                        }
                        else if(key.isWritable()){
                            //client

                            System.err.println("client write");
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buff = ((ClientData)key.attachment()).buff;

                            if(buff.hasRemaining()){
                                client.write(buff);
                            }else{
                                buff.clear();
                                buff.put(usedSpacePct.getBytes());
                                buff.put((byte)'\r');
                                buff.put((byte)'\n');
                                buff.flip();
                                client.write(buff);
                            }

                        }
                        else if(key.isReadable()){
                            System.err.println("client read");
                            SocketChannel client = (SocketChannel) key.channel();
                            ClientData data  = (ClientData) key.attachment();

                            ByteBuffer buff = data.buff;

                            buff.clear();
                            client.read(buff);
                            System.err.println(new String(buff.array(), 0, buff.position()));
                            String[] dataFromClient = (new String(buff.array(), 0, buff.position()).trim()).split(" ");
                            int clientX = Integer.parseInt(dataFromClient[0]);
                            int clientY = Integer.parseInt(dataFromClient[1]);
                            int clientR = Integer.parseInt(dataFromClient[2]);
                            buff.clear();
                            System.err.println("X: " + clientX + " Y: " + clientY + " M: " + m + " N: " + n);

                            if(clientX > m || clientY > n){
                                key.cancel();
                                key.channel().close();
                            }else{
                                System.err.println("Else");
                                buff.clear();
                                data.m = clientX;
                                data.n = clientY;
                                data.r = clientR;
                                useSpace(usedSpace, clientX, clientY, clientR, m, n);
                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                        }

                    } catch (Exception e) {
                        ClientData data = (ClientData) key.attachment();
                        key.cancel();
                        key.channel().close();
                        freeSpace(usedSpace, data.m, data.n, data.r, m, n);
                        //e.printStackTrace();
                    }

                    }
                }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }

    private static String usedSpacePercenate(boolean[][] usedSpace) {
        int used = 0;

        for(int i = 0; i < usedSpace.length; i++){
            for(int j = 0; j < usedSpace[i].length; j++){
                if(usedSpace[i][j])
                    used++;
            }
        }

        return String.valueOf((float)used/(usedSpace.length * usedSpace[0].length));
    }

    private static void useSpace(boolean[][] usedSpace, int clientX, int clientY, int clientR, int m, int n) {
        int lowerBoundX = clientX - clientR;
        int lowerBoundY = clientY - clientR;
        int upperBoundX = clientX + clientR;
        int upperBoundY = clientY + clientR;

        lowerBoundX  = lowerBoundX < 0 ? 0 : lowerBoundX;
        lowerBoundY  = lowerBoundY < 0 ? 0 : lowerBoundY;
        upperBoundX = upperBoundX > n ? n : upperBoundX;
        upperBoundY = upperBoundY > m ? m : upperBoundY;

        for(int i = lowerBoundY; i < upperBoundY; i++){
            for(int j = lowerBoundX; j < upperBoundX; j++){
                usedSpace[i][j] = true;
            }
        }

    }

    private static void freeSpace(boolean[][] usedSpace, int clientX, int clientY, int clientR, int m, int n) {
        int lowerBoundX = clientX - clientR;
        int lowerBoundY = clientY - clientR;
        int upperBoundX = clientX + clientR;
        int upperBoundY = clientY + clientR;

        lowerBoundX  = lowerBoundX < 0 ? 0 : lowerBoundX;
        lowerBoundY  = lowerBoundY < 0 ? 0 : lowerBoundY;
        upperBoundX = upperBoundX > n ? n : upperBoundX;
        upperBoundY = upperBoundY > m ? m : upperBoundY;

        for(int i = lowerBoundY; i < upperBoundY; i++){
            for(int j = lowerBoundX; j < upperBoundX; j++){
                usedSpace[i][j] = false;
            }
        }

    }

    private static class ClientData {
        public Integer id;
        public ByteBuffer buff;
        public int m, n, r;

        public ClientData(Integer id, ByteBuffer buff) {
            this.id = id;
            this.buff = buff;
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        String lineToSend = in.nextLine();

        try(DatagramSocket client = new DatagramSocket()) {

            byte[] buff = lineToSend.getBytes();

            DatagramPacket req = new DatagramPacket(buff, buff.length, InetAddress.getLoopbackAddress(), 12345);

            client.send(req);


            byte[] resBuff = new byte[1024];
            DatagramPacket res = new DatagramPacket(resBuff, resBuff.length);
            client.receive(res);

            System.out.println(new String(res.getData(), 0, res.getLength()));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

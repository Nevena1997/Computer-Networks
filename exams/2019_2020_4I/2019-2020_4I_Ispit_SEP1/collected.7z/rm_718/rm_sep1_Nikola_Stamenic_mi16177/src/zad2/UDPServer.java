package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPServer {
    public static void main(String[] args)  {

        boolean[][] usedSpace;

        try (BufferedReader fileIn = new BufferedReader(new InputStreamReader(new FileInputStream("./src/zad2/tereni.txt")))){
            String line;

            String size = fileIn.readLine();
            String[] mn = size.split(" ");
            int m = Integer.parseInt(mn[0]);
            int n = Integer.parseInt(mn[1]);

            usedSpace = new boolean[n][m];

            for(int i = 0; i < usedSpace.length; i++){
                for(int j = 0; j < usedSpace[i].length; j++){
                    usedSpace[i][j] = false;
                }
            }

            while((line = fileIn.readLine()) != null){
                String[] data = line.split(" ");


                int x = Integer.parseInt(data[0]);
                int y = Integer.parseInt(data[1]);
                int z = Integer.parseInt(data[2]);

                useSpace(usedSpace, x, y, z);
            }

            //for(int i = 0; i < usedSpace.length; i++){
                //for(int j = 0; j < usedSpace[i].length; j++){
                 //   System.out.print(usedSpace[i][j] + " ");
               // }
             //   System.out.println();
           // }

            try(DatagramSocket server = new DatagramSocket(12345)) {
                byte[] buff = new byte[1024];
                while(true) {

                    DatagramPacket req = new DatagramPacket(buff, buff.length);
                    server.receive(req);

                    System.out.println("Stigao klijent");

                    String[] data = (new String(req.getData(), 0, req.getLength())).split(" ");

                    String used = usedSpace[Integer.parseInt(data[1])-1][Integer.parseInt(data[0])-1] ? "Pokriven!" : "Nije pokriven";

                    byte[] resData = used.getBytes();

                    DatagramPacket response = new DatagramPacket(resData, resData.length, req.getAddress(), req.getPort());
                    server.send(response);
                }
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }





    }

    private static void useSpace(boolean[][] usedSpace, int clientX, int clientY, int clientR) {
        int lowerBoundX = clientX - clientR;
        int lowerBoundY = clientY - clientR;
        int upperBoundX = clientX + clientR;
        int upperBoundY = clientY + clientR;

        //System.out.println(clientX);
        //System.out.println(clientY);
        //System.out.println(clientR);

        int y = usedSpace[0].length;
        int x = usedSpace.length;


        lowerBoundX  = lowerBoundX < 0 ? 0 : lowerBoundX;
        lowerBoundY  = lowerBoundY < 0 ? 0 : lowerBoundY;
        upperBoundX = upperBoundX > x ? x : upperBoundX;
        upperBoundY = upperBoundY > y ? y : upperBoundY;

        //System.out.println("lx: " + lowerBoundX);
        //System.out.println("ly: " + lowerBoundY);
        //System.out.println("ux: " + upperBoundX);
        //System.out.println("uy: " + upperBoundY);

        for(int i = lowerBoundY; i < upperBoundY; i++){
            for(int j = lowerBoundX; j < upperBoundX; j++){
                usedSpace[i][j] = true;
            }
        }

    }

}

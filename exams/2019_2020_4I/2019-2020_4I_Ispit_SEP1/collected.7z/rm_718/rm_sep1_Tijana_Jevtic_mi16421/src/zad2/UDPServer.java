package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;


import static java.net.InetAddress.getLocalHost;

public class UDPServer extends Thread {
    private DatagramSocket socket;
    private ArrayList<Integer> x;
    private ArrayList<Integer> y;
    private ArrayList<Integer> r;

    public static void main(String[] args) {
        new UDPServer().start();
    }

    @Override
    public void run() {
        Path path = Paths.get("./terrain.txt");
        readFileSaveData(path);
        while (true) {
            try {
                socket = new DatagramSocket(12345, getLocalHost());
                byte[] buffReceive = ByteBuffer.allocate(4).array();
                DatagramPacket request = new DatagramPacket(buffReceive, buffReceive.length);
                socket.receive(request);
                System.out.println("Pristigao klijent");
                int p1 = ByteBuffer.wrap(request.getData()).getInt();
                ByteBuffer.wrap(request.getData()).asCharBuffer();
                DatagramPacket request1 = new DatagramPacket(buffReceive, buffReceive.length);
                socket.receive(request);
                int p2 = ByteBuffer.wrap(request1.getData()).getInt();

                byte[] buffSend;
                if (covered(p1, p2)) {
                    buffSend = new String("Pokriven!").getBytes();
                } else {
                    buffSend = new String("Nije pokriven!").getBytes();
                }
                DatagramPacket response = new DatagramPacket(buffSend, buffSend.length,  getLocalHost(), 12345);
                socket.send(response);
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private boolean covered(int p1, int p2) {
        var n = this.x.size();
        for (int i = 0; i < n; i++) {
            var currentX = x.get(i);
            var currentY = y.get(i);
            var currentR = r.get(i);
            if (currentX + currentR >= p1 || currentX - currentR <= p1) {
                if (currentY + currentR >= p2 || currentY - currentR <= p2) {
                    return true;
                }
            }
        }
        return false;
    }

    private void readFileSaveData(Path path) {
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                var parts = line.split(" ");
                x.add(Integer.getInteger(parts[0]));
                y.add(Integer.getInteger(parts[1]));
                r.add(Integer.getInteger(parts[2]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

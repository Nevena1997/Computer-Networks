package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) throws IOException {
        try (DatagramSocket socket = new DatagramSocket(); Scanner sc = new Scanner(System.in)) {
            System.out.println("Klijent pokrenut.");
            int x;
            if (sc.hasNextInt()) {
                x = sc.nextInt();
                int y;
                if (x > 0 && sc.hasNextInt()) {
                    y = sc.nextInt();
                    if (y > 0) {
                        byte[] buffSendX = ByteBuffer.allocate(4).putInt(x).array();
                        byte[] buffSendY = ByteBuffer.allocate(4).putInt(y).array();
                        DatagramPacket requestX = new DatagramPacket(buffSendX, buffSendX.length, InetAddress.getLocalHost(), 12345);
                        DatagramPacket requestY = new DatagramPacket(buffSendY, buffSendY.length, InetAddress.getLocalHost(), 12345);
                        socket.send(requestX);
                        socket.send(requestY);

                        byte[] buffReceive = new byte[16];
                        DatagramPacket response = new DatagramPacket(buffReceive, buffReceive.length);
                        socket.receive(response);
                        System.out.println(new String(response.getData()));
                    }
                }
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

}

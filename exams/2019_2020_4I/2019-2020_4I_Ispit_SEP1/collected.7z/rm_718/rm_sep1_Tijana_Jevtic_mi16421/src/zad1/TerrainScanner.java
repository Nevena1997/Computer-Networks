package zad1;

import java.nio.channels.ServerSocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args){
        try (Scanner sc  = new Scanner(System.in)) {
            int x;
            if (sc.hasNextInt()) {
                x = sc.nextInt();
            }
            int y;
            if (sc.hasNextInt()) {
                y = sc.nextInt();
            }

        }

    }



}

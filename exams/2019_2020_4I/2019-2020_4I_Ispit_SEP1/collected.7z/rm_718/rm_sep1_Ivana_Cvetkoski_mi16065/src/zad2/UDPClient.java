package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            InetAddress adr = InetAddress.getLocalHost();

            System.out.println("Klijent je pokrenut");
            String line;
            while((line=sc.nextLine())!=null) {
                byte[] b = line.getBytes();
                DatagramPacket prvi = new DatagramPacket(b, b.length, adr, UDPServer.PORT);
                klijent.send(prvi);

                byte[] pb = new byte[10];
                DatagramPacket primljen = new DatagramPacket(pb, pb.length);
                klijent.receive(primljen);

                String rez = new String(pb, 0, pb.length, StandardCharsets.UTF_8);
                System.out.println(rez);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.channels.DatagramChannel;
import java.nio.file.Files;
import java.nio.file.Paths;

public class UDPServer {

    public static int PORT = 12345;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT);
            BufferedReader r = Files.newBufferedReader(Paths.get("terrain.txt"))){
            System.out.println("Server je pokrenut");

            while(true) {
                byte[] buf = new byte[15];
                DatagramPacket primljen = new DatagramPacket(buf, buf.length);
                server.receive(primljen);
                System.out.println("Stigao datagram");

                String brojevi = new String(buf, 0, buf.length);
                String[] br = brojevi.split(" ");

                int x = Integer.parseInt(br[0].trim());
                int y = Integer.parseInt(br[1].trim());

                String odg="";
                String line;
                int i=0;
                while((line=r.readLine())!=null){
                    if(i!=0) {
                        String[] broj = line.split(" ");
                        int xx = Integer.parseInt(broj[0].trim());
                        int yy = Integer.parseInt(broj[1].trim());
                        int rr = Integer.parseInt(broj[2].trim());

                        int donja = yy-rr;
                        int gornja = yy+rr;
                        int desno = xx+rr;
                        int levo = xx-rr;
                        if(x<levo || x>desno || y>gornja || y<donja){
                            odg="Ne pripada";
                        }else{
                            odg="Pripada";
                            break;
                        }
                    }else{
                        String[] broj = line.split(" ");
                        int m = Integer.parseInt(broj[0].trim());
                        int n = Integer.parseInt(broj[1].trim());
                        if(m>x || y<n){
                            odg = "Ne pripada";
                            break;
                        }
                    }
                    i++;
                }

                byte[] b = odg.getBytes();
                DatagramPacket salji = new DatagramPacket(b, b.length, primljen.getAddress(), primljen.getPort());
                server.send(salji);
                odg="";
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

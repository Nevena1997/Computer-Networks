package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        try(Socket klijent = new Socket("localhost", Hub.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()))){

            while(true) {
                String line = sc.nextLine();

                out.write(line.trim());
                out.newLine();
                out.flush();


                System.out.println(in.readLine());
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

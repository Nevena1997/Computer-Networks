package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.PortUnreachableException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Hub {

    public static final int PORT = 7337;


    public static void main(String[] args) {

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner sc = new Scanner(System.in)){
            List<Integer> lista = new ArrayList<>();
            int m, n;
            m = sc.nextInt();
            n = sc.nextInt();

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Nije otvoreno nesto");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){

                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while(iter.hasNext()){

                    SelectionKey key = iter.next();
                    iter.remove();

                    try{
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel klijent = server.accept();
                            klijent.configureBlocking(false);
                            klijent.register(selector, SelectionKey.OP_READ);
                        }else if(key.isReadable()){

                            SocketChannel klijent = (SocketChannel)key.channel();

                            ByteBuffer buff = ByteBuffer.allocate(15);
                            buff.clear();
                            klijent.read(buff);

                            String linija = new String(buff.array(), 0, buff.array().length, StandardCharsets.US_ASCII);

                            String[] brojevi = linija.split(" ");
                            int x = Integer.parseInt(brojevi[0].trim());
                            int y = Integer.parseInt(brojevi[1].trim());
                            int r = Integer.parseInt(brojevi[2].trim());

                            if(x>m || y>n){
                                key.cancel();
                                try{
                                    key.channel().close();
                                }catch(IOException er){
                                    er.printStackTrace();
                                }
                            }else{

                                lista.add(x);
                                lista.add(y);
                                lista.add(r);

                                Iterator<Integer> it = lista.iterator();
                                int suma = 0;
                                while(true) {

                                    if(it.hasNext()) {

                                        int a = it.next();
                                        int b = it.next();
                                        int c = it.next();

                                        int l, d, g, dole;

                                        if (a - c < 0)
                                            l = 0;
                                        else
                                            l = a - c;
                                        if (a + c > m)
                                            d = m;
                                        else
                                            d = a + c;
                                        if (b - c < 0)
                                            dole = 0;
                                        else
                                            dole = b - c;
                                        if (b + c > n)
                                            g = n;
                                        else
                                            g = b + c;

                                        suma = suma + (g - dole) * (d - l);

                                    }else
                                        break;
                                }

                                int proizvod = m*n;
                                double pokrivenost = suma*100/proizvod;
                                String s = String.valueOf(pokrivenost) + "\n";

                                ByteBuffer b = ByteBuffer.allocate(10);
                                b.put(s.getBytes());
                                b.flip();
                                key.attach(b);

                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                        }else if(key.isWritable()){

                            SocketChannel klijent = (SocketChannel) key.channel();
                            ByteBuffer bbb = (ByteBuffer) key.attachment();

                            if(!bbb.hasRemaining()){
                                key.interestOps(SelectionKey.OP_READ);
                            }else{
                                klijent.write(bbb);
                            }

                        }

                    }catch(IOException e){
                        key.cancel();
                        try{
                            key.channel().close();
                        }catch(IOException er){
                            er.printStackTrace();
                        }
                    }


                }
                Thread.sleep(5000);
            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}

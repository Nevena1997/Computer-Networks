package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Scanner;

public class UDPServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(DEFAULT_PORT);
//             BufferedReader fileIn = new BufferedReader(new InputStreamReader(new FileInputStream("terrain.txt")))
             Scanner fileIn = new Scanner(new FileInputStream("terrain.txt"))
        ) {
            int m = fileIn.nextInt();
            int n = fileIn.nextInt();
            Integer[][] pokriveni = new Integer[3][3];
            while (fileIn.hasNext()) {
                for (int i = 0; i < 3;  i++)
                    for (int j = 0; j < 3; j++)
                        pokriveni[i][j] = fileIn.nextInt();
            }
            System.out.println("Server pokrenut");
            while (true) {
                try {
                    byte[] buff = new byte[2];
                    DatagramPacket request = new DatagramPacket(buff, buff.length);
                    socket.receive(request);

                    System.out.println("Pristigao klijent");

                    int x = buff[0];
                    int y = buff[1];

                    int yes = 0;
                    for (int i = 0; i < pokriveni.length; i++) {
                        if ((pokriveni[i][0] + pokriveni[i][2] >= x) && (pokriveni[i][0] - pokriveni[i][2] <= x) && (pokriveni[i][1] + pokriveni[i][2] >= y) && (pokriveni[i][1] - pokriveni[i][2] <= y))
                            yes = 1;
                    }

                    byte[] buff2 = new byte[1];

                    if (yes == 1) {
                        buff2[0] = 1;
                        DatagramPacket response = new DatagramPacket(buff2, buff2.length, request.getAddress(), request.getPort());
                        socket.send(response);
                    } else {
                        buff2[0] = 0;
                        DatagramPacket response = new DatagramPacket(buff2, buff2.length, request.getAddress(), request.getPort());
                        socket.send(response);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

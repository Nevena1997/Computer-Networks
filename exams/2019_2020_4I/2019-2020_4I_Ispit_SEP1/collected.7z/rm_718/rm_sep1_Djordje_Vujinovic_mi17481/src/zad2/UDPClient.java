package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {
    public static final int DEFAULT_PORT = 12345;
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            System.out.println("Klijent pokrenut");

            byte[] buff = new byte[2];
            buff[0] = sc.nextByte();
            buff[1] = sc.nextByte();

            System.out.println(buff);

            InetAddress host = InetAddress.getByName("localhost");
            DatagramPacket request = new DatagramPacket(buff, buff.length, host, DEFAULT_PORT);
            socket.send(request);

            DatagramPacket response = new DatagramPacket(buff, buff.length);
            socket.receive(response);

            byte[] odgovor = response.getData();
            if (odgovor[0] == 1) {
                System.out.println("Pokriven");
            } else {
                System.out.println("Nije pokriven");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

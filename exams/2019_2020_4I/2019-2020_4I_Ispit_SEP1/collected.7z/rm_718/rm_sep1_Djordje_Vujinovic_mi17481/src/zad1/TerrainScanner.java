package zad1;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static final int DEFAULT_PORT = 7337;

    public static void main(String[] args) {

        InetSocketAddress addr = new InetSocketAddress("localhost", DEFAULT_PORT);

        try (SocketChannel client = SocketChannel.open(addr);
             Scanner sc = new Scanner(System.in)){
            byte[] buff = new byte[3];
            buff[0] = sc.nextByte();
            buff[1] = sc.nextByte();
            buff[2] = sc.nextByte();

            client.write(ByteBuffer.wrap(buff));

            WritableByteChannel out = Channels.newChannel(System.out);
//            byte[] buffer = new byte[1];
            ByteBuffer buffer = ByteBuffer.allocate(1);
            while (client.read(buffer) != -1) {
//                int broj;
//                broj = ByteBuffer.wrap(buffer).getInt();
                out.write(buffer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("glhf from TerrainScanner");

    }
}

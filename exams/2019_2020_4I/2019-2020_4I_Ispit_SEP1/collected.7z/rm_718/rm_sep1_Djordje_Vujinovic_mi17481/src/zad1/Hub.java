package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    public static final int DEFAULT_PORT = 7337;
    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open();
             Scanner sc = new Scanner(System.in);) {

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            int m = sc.nextInt();
            int n = sc.nextInt();

            Integer[][] matrix = new Integer[m][n];
            for (int i =0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    matrix[i][j] = 0;
                }
            }

            while (true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();

                    it.remove();

                    if (key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel)key.channel();
                        SocketChannel client = server.accept();

                        client.configureBlocking(false);

                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                    } else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel)key.channel();

                        while (true) {
                            Thread.sleep(5000);
                            int suma1 = 0;
                            for (int i =0; i < m; i++) {
                                for (int j = 0; j < n; j++) {
                                    if (matrix[i][j] == 1)
                                        suma1++;
                                }
                            }
                            float pokrivenost = (float)suma1/(n*m)*100;
                            System.out.println(pokrivenost);
                            byte[] buff = new byte[1];
                            buff[0] = (byte) pokrivenost;

                            client.write(ByteBuffer.wrap(buff));
                        }


                    } else if (key.isReadable()) {
                        SocketChannel client = (SocketChannel)key.channel();

                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                        byte[] buf = new byte[3];

                        client.read(ByteBuffer.wrap(buf));
                        int x = buf[0];
                        int y = buf[1];
                        int r = buf[2];

                        if (x + r > m || x - r < 0 || y + r > n || y - r < 0)
                            client.close();

                        for (int i = y-r; i < y+r; i++) {
                            for (int j = x-r; j < x+r; j++) {
                                matrix[i][j] = 1;
                            }
                        }

//                        for (int i = 0; i < m; i++) {
//                            for (int j = 0; j < n; j++) {
//                                if (matrix[i][j] == 1)
//                                    System.out.print(matrix[i][j] + " ");
//                                else
//                                    System.out.print(0 + " ");
//
//                            }
//                            System.out.println();
//                        }
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        System.out.println("glhf from TerrainScanner");

        InetSocketAddress address = new InetSocketAddress(7337);
        try(SocketChannel client = SocketChannel.open()){
            client.bind(address);

            ByteBuffer buffer = ByteBuffer.allocate(512);
            Scanner sc = new Scanner(System.in);
            int x = sc.nextInt();
            int y = sc.nextInt();
            int r = sc.nextInt();

            buffer.putInt(x);
            buffer.putInt(y);
            buffer.putInt(r);
            buffer.flip();
            client.write(buffer);

            int read;
            while((read = client.read(buffer)) != -1){
                    String line = buffer.toString();
                    buffer.rewind();
                    System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

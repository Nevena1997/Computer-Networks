package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Hub {

    public int m;
    public int n;
    public int p;
    public int clientP = 0;
    private Set<ClientThread> clients = new HashSet<>();


    public static void main(String[] args) {
        System.out.println("glhf from Hub");

        Hub server = new Hub();
        server.execute();


    }

    private void execute() {


        InetSocketAddress address = new InetSocketAddress(7337);
        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Nesto nije otvoreno");
                return;
            }
            server.bind(address);
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);



            Scanner sc = new Scanner(System.in);
            this.m = sc.nextInt();
            this.n = sc.nextInt();
            this.p = m*n;


            while(true){

                try{
                    this.wait(5000);
                    this.sendToAll();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){

                    SelectionKey key = it.next();
                    it.remove();
                    if(key.isAcceptable()) {

                        ClientThread client = new ClientThread(key, selector, this);
                        this.clients.add(client);
                        client.start();
                    }


                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void sendToAll(){
        this.clients.stream().forEach(client -> {
            try{
            client.write(this.p/this.clientP);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}

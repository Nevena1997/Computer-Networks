package zad1;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.Selector;

public class ClientThread extends Thread{

    private SelectionKey key;
    private Selector selector;
    private Hub server;
    private ByteBuffer buffer;
    private SocketChannel client;

    public ClientThread(SelectionKey key, Selector selector, Hub server) {
        this.key = key;
        this.selector = selector;
        this.server = server;
    }


    @Override
    public void run() {

    try {
        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
        this.client = (SocketChannel) serverChannel.accept();
        this.buffer = ByteBuffer.allocate(512);
        SelectionKey clientKey = client.register(this.selector, SelectionKey.OP_WRITE);
        clientKey.attach(buffer);

        client.read(buffer);
        int[] data = ByteBuffer.wrap(buffer.array()).asIntBuffer().array();
        int x = data[0];
        int y = data[1];
        int r = data[2];

        if (x > server.m || y > server.n) {
            try {
                clientKey.cancel();
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            if (x == 0 || y == 0) {
                server.clientP += 2 * r * r;

            } else
                server.clientP += 4 * r * r;
        }


    } catch (ClosedChannelException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }

    }

    public void write(double number) throws IOException {
        this.buffer.putDouble(number);
        buffer.flip();
        this.client.write(this.buffer);

    }
}

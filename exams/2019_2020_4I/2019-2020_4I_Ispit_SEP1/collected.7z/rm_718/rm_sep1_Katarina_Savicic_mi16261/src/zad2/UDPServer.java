package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class UDPServer {



    public static void main(String[] args) {
        System.out.println("glhf from UDPServer");
        try{

            FileInputStream fis = new FileInputStream(new File("terrain.txt"));

            String line;
            BufferedReader read = new BufferedReader(new InputStreamReader(fis));
            line = read.readLine();
            String [] coord = line.split(" ");
            int m = Integer.parseInt(coord[0]);
            int n = Integer.parseInt(coord[1]);

            List<int []> centers = new ArrayList<>();

            while((line = read.readLine()) != null){

                coord = line.split(" ");
                int [] cd = new int [3];
                cd[0] = Integer.parseInt(coord[0]);
                cd[1] = Integer.parseInt(coord[1]);
                cd[2] = Integer.parseInt(coord[2]);
                centers.add(cd);
            }
            System.out.println("terrain.txt je ucitan!");

            DatagramSocket server = new DatagramSocket(12345);
            System.out.println("Server pokrenut!");

            byte [] r = new byte[12];
            DatagramPacket rec = new DatagramPacket(r, 12);
            server.receive(rec);


            String [] received = ByteBuffer.wrap(rec.getData()).toString().split("");
            int x = Integer.parseInt(received[0]);
            int y = Integer.parseInt(received[1]);

            AtomicInteger res = new AtomicInteger(1);

            centers.stream().forEach(c -> {
                if(x < (c[0]-c[2]) || x > (c[0]+c[2]) || y < (c[1]-c[2]) || y > (c[1]+c[2]))
                    res.set(0);
            });

            byte[] s = new byte[4];
            ByteBuffer buffer = ByteBuffer.allocate(4);
            if(res.equals(1)){
                s = buffer.putInt(1).array();
            }
            else if(res.equals(0)){
                s = buffer.putInt(0).array();
            }

            DatagramPacket send = new DatagramPacket(s, s.length, rec.getAddress(), rec.getPort());




        } catch (SocketException | FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

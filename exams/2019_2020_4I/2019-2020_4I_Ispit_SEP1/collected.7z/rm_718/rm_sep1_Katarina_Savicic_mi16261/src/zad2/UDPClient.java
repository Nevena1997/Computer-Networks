package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("glhf from UDPClient");

        System.out.println("Klijent pokrenut!");
        try (DatagramSocket client = new DatagramSocket()){

            Scanner sc = new Scanner(System.in);
            int[] xy = new int[2];
            xy[0] = sc.nextInt();
            xy[1] = sc.nextInt();

            ByteBuffer bb = ByteBuffer.allocate(16);
            bb.putInt(xy[0]);
            bb.putInt(xy[1]);
            bb.flip();
            byte [] buffer = bb.array();
            System.out.println(bb.toString());
            DatagramPacket send = new DatagramPacket(buffer, buffer.length, InetAddress.getLoopbackAddress(), 12345);
            client.send(send);


            byte[] r = new byte[4];

            DatagramPacket rec = new DatagramPacket(r, 4);
            client.receive(rec);
            int response = ByteBuffer.wrap(rec.getData()).getInt();
            if(response == 0)
                System.out.println("Nije pokriven!");
            else if(response == 1)
                System.out.println("Pokriven!");
            else
                System.out.println("Doslo je do greske -.-");

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

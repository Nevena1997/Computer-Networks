package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class Hub {
    private static int m;
    private static int n;
    private static Map<SocketChannel, ScannerData> mapa = new HashMap<>();

    private static class ScannerData {
        int x, y, r;
        long prethodni;

        ScannerData(int x, int y, int r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
    }

    private static double pokrivenost() {
        var pokrivenost = new Boolean[m][n];
        for (var i = 0; i < m; i++) {
            for (var j = 0; j < n; j++) {
                for (var sock : mapa.keySet()) {
                    var sockData = mapa.get(sock);
                    if (sockData.x+sockData.r >= i && sockData.x-sockData.r <= i &&
                        sockData.y+sockData.r >= j && sockData.y-sockData.r <= j) {
                        pokrivenost[i][j] = true;
                    }
                }
            }
        }

        var pokrInt = 0;
        for (var i = 0; i < m; i++) {
            for (var j = 0; j < n; j++) {
                if (pokrivenost[i][j]) {
                    pokrInt++;
                }
            }
        }

        return (double)pokrInt/(m*n)*100;
    }

    public static void main(String[] args) {
        try (var serverSock = ServerSocketChannel.open();
             var selector = Selector.open();
             var sc = new Scanner(System.in)) {
            int m = sc.nextInt();
            int n = sc.nextInt();

            serverSock.bind(new InetSocketAddress("localhost", 7337));
            serverSock.configureBlocking(false);
            serverSock.register(selector, SelectionKey.OP_ACCEPT);

            glavna:
            while (true) {
                selector.select();
                var it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    var key = it.next();
                    it.remove();

                    try {
                        if (key.isAcceptable()) {
                            var server = (ServerSocketChannel)key.channel();
                            var client = server.accept();
                            client.configureBlocking(false);
                            var clientKey = client.register(selector, SelectionKey.OP_READ);

                            var buff = ByteBuffer.allocate(Integer.BYTES * 3);
                            clientKey.attach(buff);
                        } else if (key.isReadable()) {
                            var client = (SocketChannel)key.channel();
                            var buff = (ByteBuffer)key.attachment();

                            if (!buff.hasRemaining()) {
                                buff.rewind();
                                var x = buff.getInt();
                                var y = buff.getInt();

                                if (x < 0 || y < 0 || x > m || y > n) {
                                    throw new IOException();
                                }

                                var r = buff.getInt();
                                mapa.put(client, new ScannerData(x, y, r));

                                buff.rewind();
                                buff.clear();
                                buff.flip();
                                key.interestOps(SelectionKey.OP_WRITE);
                            }

                            client.read(buff);
                        } else if (key.isWritable()) {
                            var client = (SocketChannel)key.channel();
                            var buff = (ByteBuffer)key.attachment();

                            long trenutno = new Date().getTime();
                            if (!buff.hasRemaining() && mapa.get(client).prethodni <= trenutno+5000) {
                                mapa.get(client).prethodni = trenutno;

                                double pokr = pokrivenost();
                                if (pokr == 100) {
                                    break glavna;
                                }
                                buff.clear();
                                buff.put(String.format("%.1f%%", pokr).getBytes());
                                buff.flip();
                            }

                            client.write(buff);
                        }
                    } catch (IOException e) {
                        key.cancel();
                        mapa.remove((SocketChannel)key.channel());
                        try {
                            key.channel().close();
                        } catch (IOException ignored) {

                        }
                    }
                }
            }

            for (var client: mapa.keySet()) {
                try {
                    client.close();
                } catch (IOException ignored) {

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

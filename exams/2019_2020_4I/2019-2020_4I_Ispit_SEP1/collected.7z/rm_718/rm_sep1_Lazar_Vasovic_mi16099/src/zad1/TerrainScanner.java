package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        try (var client = SocketChannel.open(new InetSocketAddress("localhost", 7337));
             var sc = new Scanner(System.in)) {
            var x = sc.nextInt();
            var y = sc.nextInt();
            var r = sc.nextInt();

            var buff = ByteBuffer.allocate(Integer.BYTES * 3).putInt(x).putInt(y).putInt(r);
            buff.flip();
            client.write(buff);
            buff.flip();

            var out = Channels.newChannel(System.out);

            while (client.read(buff) != -1) {
                buff.rewind();
                out.write(buff);
                buff.clear();
                buff.flip();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try (var ds = new DatagramSocket();
             var sc = new Scanner(System.in)) {
            var buff = ByteBuffer.allocate(2*Integer.BYTES).putInt(sc.nextInt()).putInt(sc.nextInt()).array();
            var dp = new DatagramPacket(buff, buff.length, InetAddress.getByName("localhost"), 12345);
            ds.send(dp);

            ds.receive(dp);
            long rez = ByteBuffer.wrap(dp.getData()).getLong();
            if (rez == 1) {
                System.out.println("Pokriven!");
            } else {
                System.out.println("Nije pokriven!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

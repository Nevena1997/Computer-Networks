package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class UDPServer {
    private static List<ScannerData> lista = new ArrayList<>();

    private static class ScannerData {
        int x, y, r;

        ScannerData(int x, int y, int r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
    }
    public static void main(String[] args) {
        try (var ds = new DatagramSocket(12345);
             var sc = new Scanner(Paths.get("src/zad2/primer.txt"))) {
            var m = sc.nextInt();
            var n = sc.nextInt();

            while (sc.hasNextInt()) {
                var c1 = sc.nextInt();
                var c2 = sc.nextInt();
                var r = sc.nextInt();
                lista.add(new ScannerData(c1, c2, r));
            }

            // noinspection InfiniteLoopStatement
            while (true) {
                var buff = ByteBuffer.allocate(2 * Integer.BYTES).array();
                var dp = new DatagramPacket(buff, buff.length);
                ds.receive(dp);
                System.out.println("Pristigao klijent!");

                var buff2 = ByteBuffer.wrap(dp.getData());
                var x = buff2.getInt();
                var y = buff2.getInt();

                boolean ok = false;
                if (x < 0 || y < 0 || x > m || x > n) {
                    ok = false;
                } else {
                    for (var data : lista) {
                        if (data.x+data.r >= x && data.x-data.r <= x &&
                            data.y+data.r >= y && data.y-data.r <= y) {
                            ok = true;
                            break;
                        }
                    }
                }

                buff2.rewind();
                buff2.clear();
                if (ok) {
                    buff2.putLong(1);
                } else {
                    buff2.putLong(0);
                }

                buff = buff2.array();
                dp = new DatagramPacket(buff, buff.length, dp.getAddress(), dp.getPort());
                ds.send(dp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

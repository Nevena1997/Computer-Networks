package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Hub {
    public static final int DEFAULT_PORT = 7337;
    ArrayList<ArrayList<Integer>> cover;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int n = sc.nextInt();
        int x, y, r;

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {
                selector.select();

                Set<SelectionKey> readKeys = selector.selectedKeys();
                Iterator<SelectionKey> it = readKeys.iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()) {
                        ServerSocketChannel server = (ServerSocketChannel)key.channel();
                        SocketChannel client = server.accept();

                        client.configureBlocking(false);
                        client.register(selector, SelectionKey.OP_READ);


                        ByteBuffer buff = ByteBuffer.allocate(4);
                        client.read(buff);

                        x = buff.get();
                        y = buff.get();
                        r = buff.get();

                        if (x > m || x > n || y > m || y > n || x < 0 || y < 0) {
                            client.close();
                        }

                        buff.clear();
                    }
                    else if (key.isWritable()) {
                        SocketChannel client = (SocketChannel)key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        client.socket().setSoTimeout(5000);

                        if (buff.hasRemaining()) {
                            int area = m * n;
                            buff.putInt(area);
                            buff.flip();
                            client.write(buff);
                            buff.clear();
                        }

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

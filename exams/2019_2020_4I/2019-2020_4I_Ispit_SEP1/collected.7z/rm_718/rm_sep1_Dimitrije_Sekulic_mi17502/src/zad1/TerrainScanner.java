package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        try(SocketChannel client = SocketChannel.open()
        ) {
            client.bind(new InetSocketAddress(7337));

            ByteBuffer buff = ByteBuffer.allocate(12);

            Scanner sc = new Scanner(System.in);
            int x = sc.nextInt();
            buff.putInt(x);

            int y = sc.nextInt();
            buff.putInt(y);

            int r = sc.nextInt();
            buff.putInt(r);

            buff.flip();

            client.write(buff);

            buff.clear();

            while (client.read(buff) > 0) {
                System.out.println(buff.toString());
                buff.rewind();
            }

            buff.clear();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

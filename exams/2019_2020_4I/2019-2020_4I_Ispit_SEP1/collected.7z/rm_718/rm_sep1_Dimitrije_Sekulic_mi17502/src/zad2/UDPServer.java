package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Scanner;

public class UDPServer {
    public static void main(String[] args) {
        try {
            Scanner fin = new Scanner(new FileInputStream(new File("./terrain.txt")));

            try (DatagramSocket socket = new DatagramSocket(12345)) {
                DatagramPacket recv = new DatagramPacket(new byte[2], 2);
                socket.receive(recv);

                System.out.println("Pristigao klijent!");

                int x = recv.getData()[0];
                int y = recv.getData()[1];

                int m = fin.nextInt();
                int n = fin.nextInt();
                byte[] ans = new byte[1];
                boolean trth = false;
                while (fin.hasNext()) {
                    int tx = fin.nextInt();
                    int ty = fin.nextInt();
                    int r = fin.nextInt();

                    if (x <= tx + r && x >= tx - r) {
                        if (y <= ty + r && y >= ty - r) {
                            trth = true;
                            break;
                        }
                    }
                    trth = false;
                }
                if (trth)
                    ans[0] = 1;
                else
                    ans[0] = 0;

                DatagramPacket send = new DatagramPacket(ans, ans.length, recv.getAddress(), recv.getPort());
                socket.send(send);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

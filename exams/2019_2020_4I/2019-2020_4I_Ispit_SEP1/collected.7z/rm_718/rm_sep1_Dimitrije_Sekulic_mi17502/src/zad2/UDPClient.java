package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             Scanner sc = new Scanner(System.in)
        ) {
            byte[] buff = new byte[2];
            buff[0] = sc.nextByte();
            buff[1] = sc.nextByte();

            DatagramPacket send = new DatagramPacket(buff, buff.length, InetAddress.getByName("localhost"), 12345);
            socket.send(send);

            DatagramPacket rec = new DatagramPacket(new byte[4], 4);
            socket.receive(rec);

            if (rec.getData()[0] == 1) {
                System.out.println("Pokriven!");
            }
            else {
                System.out.println("Nije pokriven");
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

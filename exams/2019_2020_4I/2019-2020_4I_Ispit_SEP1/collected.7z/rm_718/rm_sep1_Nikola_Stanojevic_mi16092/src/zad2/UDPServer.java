package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

class Scaner{
    int x;
    int y;
    int r;

    public Scaner(int x, int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
    }

    boolean inRange(int p, int q) {
        boolean result = true;
        if(p < x-r || p > x+r)
            result = false;
        if(q < y-r || q > y+r)
            result = false;
        return result;
    }
}

public class UDPServer {

    public static final int DEFAULT_PORT  = 12345;



    public static void main(String[] args){





        int m, n;
        List<Scaner> scaners = new LinkedList<>();
        String filename = "terrain.txt";
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(filename);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Scanner sc = new Scanner(fileReader);

        System.out.println(filename + " ucitan!");

        m = sc.nextInt();
        n = sc.nextInt();

        while(sc.hasNextInt()){
            int x = sc.nextInt();
            int y = sc.nextInt();
            int r = sc.nextInt();
            Scaner s = new Scaner(x,y,r);
            scaners.add(s);
        }

        try (DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){
            System.out.println("Server pokrenut!");

            while (true){

                byte[] buffer = new byte[512];
                DatagramPacket initialPackage = new DatagramPacket(buffer, buffer.length);
                server.receive(initialPackage);
                System.out.println("Stigao datagram!");

                String message = new String(buffer, 0, buffer.length);
                String[] parts = message.split(",");
                int p = Integer.parseInt(parts[0]);
                int q = Integer.parseInt(parts[1]);

                boolean result = checkCoverage(scaners, p, q);
                String sendToClient;
                if (result)
                    sendToClient = "Pokriven!";
                else sendToClient = "Nije Pokriven!";

                DatagramPacket response = new DatagramPacket(sendToClient.getBytes(), sendToClient.length(), initialPackage.getAddress(), initialPackage.getPort());
                server.send(response);
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static boolean checkCoverage(List<Scaner> scaners, int p, int q) {
        for(Scaner s: scaners){
            if (s.inRange(p, q))
                return true;
        }
        return false;
    }
}

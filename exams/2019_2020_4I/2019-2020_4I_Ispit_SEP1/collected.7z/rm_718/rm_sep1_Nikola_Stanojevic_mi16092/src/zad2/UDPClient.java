package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        int x,y;
        System.out.println("Klijent pokrenut!");
        Scanner sc = new Scanner(System.in);
        x = sc.nextInt();
        y = sc.nextInt();

        try {
            DatagramSocket client = new DatagramSocket();
            byte[] buffer = new String(x + "," + y + ",").getBytes();
            DatagramPacket request = new DatagramPacket(buffer, buffer.length, new InetSocketAddress("localhost", UDPServer.DEFAULT_PORT));
            client.send(request);

            byte[] responseBuffer = new byte[512];
            DatagramPacket response = new DatagramPacket(responseBuffer, responseBuffer.length);
            client.receive(response);

            String fromServer = new String(responseBuffer);
            System.out.println(fromServer.substring(0, fromServer.indexOf('!') + 1));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

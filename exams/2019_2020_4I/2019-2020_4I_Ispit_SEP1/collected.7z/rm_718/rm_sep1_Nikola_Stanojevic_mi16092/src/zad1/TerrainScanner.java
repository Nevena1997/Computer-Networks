package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        String hostname = "localhost";
        int port = Hub.DEFAULT_PORT;

        int x, y, r;

        try{
            SocketChannel client = SocketChannel.open(new InetSocketAddress(hostname, port));
            ByteBuffer buffer = ByteBuffer.allocate(3*4);

            System.err.println("Connected to server...");

            Scanner sc = new Scanner(System.in);
            System.err.println("Enter x, y and r: ");
            x = sc.nextInt();
            y = sc.nextInt();
            r = sc.nextInt();

            buffer.clear();
            buffer.putInt(x);
            buffer.putInt(y);
            buffer.putInt(r);
            buffer.flip();

            client.write(buffer);

            while(true){
                buffer.clear();
                while (buffer.hasRemaining())
                    client.read(buffer);
//                System.out.println(buffer.getInt());
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

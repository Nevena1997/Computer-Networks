package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    public static final int DEFAULT_PORT  = 7337;

    public static void main(String[] args) {

        try(ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){



            serverSocketChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            int m, n;
            double coverage = 0;

            System.err.println("Enter terrain dimensions: ");
            Scanner sc = new Scanner(System.in);
            m = sc.nextInt();
            n = sc.nextInt();

            if(!serverSocketChannel.isOpen() || !selector.isOpen()){
                System.err.println("Error creating server or selector");
                System.exit(1);
            }

            while(true){

                if(coverage == 1.0){
                    System.err.println("Coverage is 100%, now exiting...");
                    System.exit(0);
                }

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while(it.hasNext()){

                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if (key.isAcceptable()) {
                            // System.err.println("Naiso je server, otvori konekciju i spremi za prijem.");

                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            System.err.println("Client accepted!");
                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);

                        } else if (key.isWritable()) {
                            // System.err.println("Naiso je klijent, saljemo mu coverage");
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buffer = ByteBuffer.allocate(3*4);
                            buffer.putInt(4);
                            buffer.flip();
                            client.write(buffer);

                        } else if(key.isReadable()){
                            // System.err.println("Naiso je klijent, procitaj dimenzije");
                            SocketChannel client = (SocketChannel)key.channel();
                            ByteBuffer buffer = ByteBuffer.allocate(3*4);

                            while(!buffer.hasRemaining())
                                client.read(buffer);

                        }
                    } catch (IOException ex){
                        key.cancel();
                        try{
                            key.channel().close();
                        } catch (IOException cex){
                            cex.printStackTrace();
                        }
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

public class UDPServer {
    public static void main(String[] args) {
        System.out.println("glhf from UDPServer");


    }
}

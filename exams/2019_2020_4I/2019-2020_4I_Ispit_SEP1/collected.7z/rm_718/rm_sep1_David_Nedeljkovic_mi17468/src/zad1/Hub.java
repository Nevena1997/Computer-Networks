package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Hub {

    public static final int DEFAULT_PORT = 7337;

    public static void main(String[] args) {
        //System.out.println("glhf from Hub");

        Scanner sc = new Scanner(System.in);
        int m,n;
        System.out.println("Unesite m: ");
        m = sc.nextInt();
        System.out.println("Unesite n: ");
        n = sc.nextInt();

        try(ServerSocketChannel serverChanel = ServerSocketChannel.open();
            Selector selektor = Selector.open()) {

            ServerSocket server = serverChanel.socket();
            SocketAddress address = new InetSocketAddress(DEFAULT_PORT);
            server.bind(address);
            serverChanel.configureBlocking(false);
            serverChanel.register(selektor, SelectionKey.OP_ACCEPT);

            selektor.select();

            while (true) {

                Set<SelectionKey> spremniKljucevi = selektor.selectedKeys();
                Iterator<SelectionKey> iter = spremniKljucevi.iterator();
                while (iter.hasNext()){
                    SelectionKey key = iter.next();
                    iter.remove();

                    if(key.isAcceptable()){
                        ServerSocketChannel serverChan = (ServerSocketChannel) key.channel();
                        ServerSocket serverr = serverChan.socket();

                    }
                    else if(key.isWritable()) {

                    }
                    else if(key.isReadable()) {

                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

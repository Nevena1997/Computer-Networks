package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        //System.out.println("glhf from TerrainScanner");

        try {
            SocketAddress address = new InetSocketAddress(Hub.DEFAULT_PORT);
            SocketChannel client = SocketChannel.open(address);
            client.configureBlocking(true);

            Scanner sc = new Scanner(System.in);
            int x,y,r;
            System.out.println("Unesi kordinatu x:" );
            x = sc.nextInt();
            System.out.println("Unesi kordinatu y:" );
            y = sc.nextInt();
            System.out.println("Unesi r:" );
            r = sc.nextInt();

            ByteBuffer buffer = ByteBuffer.allocate(12);
            buffer.putInt(x);
            buffer.putInt(y);
            buffer.putInt(r);
            client.write(buffer);


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

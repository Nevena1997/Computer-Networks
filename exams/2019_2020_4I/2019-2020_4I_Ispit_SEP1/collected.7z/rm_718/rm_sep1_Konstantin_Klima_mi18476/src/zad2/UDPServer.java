package zad2;

import java.io.*;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Scanner;

public class UDPServer {
    public static final int DEFAULT_PORT = 12345;
    public static void main(String[] args) {

        int xBound = 0;
        int yBound = 0;

        ArrayList<ArrayList<Integer>> scanners = new ArrayList<>();

        try(Scanner f = new Scanner(new InputStreamReader(new FileInputStream("terrain.txt"))) ) {
            xBound = f.nextInt();
            yBound = f.nextInt();

            while (f.hasNextInt())
            {
                var dot = new ArrayList<Integer>();
                dot.add(f.nextInt());
                dot.add(f.nextInt());
                dot.add(f.nextInt());

                scanners.add(dot);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("terrain.txt ucitan!");

        try(DatagramSocket socket = new DatagramSocket(DEFAULT_PORT)) {
            System.out.println("Server pokrenut!");

            while(true){
                DatagramPacket request = new DatagramPacket(new byte[8], 8);
                socket.receive(request);
                System.out.println("Pristigao klikent!");

                var data = request.getData();
                int x = getIntFromByteArray(data, 0);
                int y = getIntFromByteArray(data, 1);

                boolean isCovered = checkIfCovered(scanners, x, y);
                String payload = x >= 0 && y >= 0 && x <= xBound && y <= yBound && isCovered ? "Pokriven!" : "Nije Pokriven!";

                DatagramPacket response = new DatagramPacket(payload.getBytes(), payload.getBytes().length, request.getAddress(), request.getPort());

                socket.send(response);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static int getIntFromByteArray(byte[] data, int item){
        byte[] x = ByteBuffer.allocate(4).array();
        int start = 4 * item;

        x[0] = data[start];
        x[1] = data[start+1];
        x[2] = data[start+2];
        x[3] = data[start+3];

        return ByteBuffer.wrap(x).getInt();
    }

    private static boolean checkIfCovered(ArrayList<ArrayList<Integer>> scanners, int x, int y)
    {
        for(var scanner : scanners){
            int sX = scanner.get(0);
            int sY = scanner.get(1);
            int sR = scanner.get(2);

            if(x >= sX - sR && x <= sX + sR && y >= sY - sR && y <= sY + sR)
            {
                return true;
            }

        }

        return false;
    }
}

package zad2;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    private static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket()) {
            final InetAddress HOST= InetAddress.getLocalHost();
            socket.setSoTimeout(5000);

            Scanner sc = new Scanner(System.in);
            int x = sc.nextInt();
            int y = sc.nextInt();

            DatagramPacket request = new DatagramPacket(ByteBuffer.allocate(8).putInt(x).putInt(y).array(), 8, HOST, DEFAULT_PORT);
            socket.send(request);

            DatagramPacket response = new DatagramPacket(new byte[256], 256);
            socket.receive(response);

            var data = response.getData();
            var r = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(data)));

            System.out.print(r.readLine().trim());

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

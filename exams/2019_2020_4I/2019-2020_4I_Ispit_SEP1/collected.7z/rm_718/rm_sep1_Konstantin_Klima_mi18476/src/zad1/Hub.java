package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Hub {
    public static void main(String[] args){
        try(ServerSocketChannel socket = ServerSocketChannel.open(); Selector sel = Selector.open()) {
            var key = sel.select();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

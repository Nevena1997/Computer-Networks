package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    static int m;
    static int n;
    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = (ServerSocketChannel) ServerSocketChannel.open();
             Selector selector = Selector.open()
        ){
            serverChannel.bind(new InetSocketAddress(12345));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            Scanner sc = new Scanner(System.in);
            String line = sc.nextLine();
            String[] dimArray = line.split(" ", 2);
            m = Integer.parseInt(dimArray[0]);
            n = Integer.parseInt(dimArray[1]);

            while (true){
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try {
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel)key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);

                            SelectionKey keyClient = client.register(selector, SelectionKey.OP_READ);

                        }
                        if(key.isReadable()){
                            SocketChannel socket = (SocketChannel)key.channel();
                            ByteBuffer buffer1 = ByteBuffer.allocate(500);
                            socket.read(buffer1);
                            buffer1.flip();
                            String s = new String(buffer1.array(), StandardCharsets.US_ASCII);
                            s = s.trim();
                            buffer1.clear();
                            System.err.println(s);

                            key.interestOps(SelectionKey.OP_WRITE);

                            ByteBuffer buffer2 = ByteBuffer.allocate(500);

                            while (true) {

                                buffer2.put("Nisam implementirala odgovor".getBytes());
                                buffer2.flip();
                                socket.write(buffer2);
                                buffer2.clear();
                                Thread.sleep(5000);
                            }


                        }if (key.isWritable()){
                            SocketChannel socket = (SocketChannel)key.channel();
                            ByteBuffer buffer2 = ByteBuffer.allocate(500);
                            //System.out.println("U write");
                            while (true) {

                                buffer2.put("Nisam implementirala odgovor".getBytes());
                                buffer2.flip();
                                socket.write(buffer2);
                                buffer2.clear();
                                Thread.sleep(5000);
                            }

                        }
                    }finally {
                        key.channel().close();
                        key.cancel();
                    }
                }
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }
}

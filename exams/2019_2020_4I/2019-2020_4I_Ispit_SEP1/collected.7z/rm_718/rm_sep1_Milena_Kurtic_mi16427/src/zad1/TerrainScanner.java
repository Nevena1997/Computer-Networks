package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TerrainScanner {

    static SocketChannel client;
    static Scanner sc;
    InetSocketAddress addr = new InetSocketAddress("localhost",12345);

    TerrainScanner() throws IOException {
        this.client =  SocketChannel.open(addr);

        this.sc = new Scanner(System.in);
    }
    public static void main(String[] args) throws IOException {
        try {
            TerrainScanner s = new TerrainScanner();
            s.execute();
        }catch (IOException e){
            e.printStackTrace();
            sc.close();
            client.close();;
        }


    }
    void execute() throws IOException {
        String line;
        line = sc.nextLine();
        line = line.trim();

        ByteBuffer buffer = ByteBuffer.allocate(100);
        byte[] lineByte = line.getBytes(StandardCharsets.US_ASCII);
        buffer.put(lineByte);
        buffer.flip();
        client.write(buffer);
        buffer.clear();

        ByteBuffer buffer2 = ByteBuffer.allocate(100);
        WritableByteChannel output = Channels.newChannel(System.out);
        while (  true){
            client.read(buffer2);
            if (buffer2 == null){
                break;
            }
            buffer2.flip();
            output.write(buffer2);
            System.out.println("\n");
            buffer2.clear();

        }



    }
}

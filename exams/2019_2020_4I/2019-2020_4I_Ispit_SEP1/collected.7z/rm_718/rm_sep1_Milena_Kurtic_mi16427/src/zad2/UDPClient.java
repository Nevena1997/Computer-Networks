package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.channels.Channel;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {
    DatagramSocket client ;
    Scanner sc;
    int port;
    InetAddress addr;


    UDPClient() throws SocketException, UnknownHostException {
        this.client = new DatagramSocket();
        this.sc = new Scanner(System.in);
        this.addr = InetAddress.getByName("localhost");
        this.port = 12345;

    }

    public static void main(String[] args) throws SocketException, UnknownHostException {
        UDPClient c = new UDPClient();
        c.execute();

    }
    private void execute(){
        try{
            String line;
            line = sc.nextLine();
            byte[] buf = line.getBytes(StandardCharsets.US_ASCII);
            DatagramPacket request = new DatagramPacket(buf, buf.length, addr, port);
            this.client.send(request);
            byte[] buf2 = new byte[800];
            DatagramPacket response = new DatagramPacket(buf, buf.length);
            this.client.receive(response);
            String responseStr = new String(response.getData(), 0, response.getLength(), StandardCharsets.US_ASCII);
            if (responseStr.equalsIgnoreCase("P")){
                System.out.println("Pokriven");
            }
            if (responseStr.equalsIgnoreCase("N")){
                System.out.println("Nije pokriven");
            }



        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            this.client.close();
            this.sc.close();
        }
    }
}

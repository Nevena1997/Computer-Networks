package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class UDPServer {
    public static DatagramSocket server ;
    Scanner sc;
    int port;
    Set<int[]> teren = new HashSet<>();
    int m;
    int n;



    UDPServer() throws SocketException {
        this.port = 12345;
        this.server = new DatagramSocket(port);
    }
    public static void main(String[] args) throws IOException {
       UDPServer s = new UDPServer();
       s.execute();
    }
    void execute() throws IOException {

            //ucitavanje podataka
            BufferedReader in = Files.newBufferedReader(Paths.get("/home/ispit/Desktop/rm_sep1_Milena_Kurtic_mi16427/terrain.txt"));
            String dimenzije = in.readLine();
            String[] dimArray = dimenzije.split(" ");

            this.m = Integer.parseInt(dimArray[0]);
            this.n = Integer.parseInt(dimArray[1]);
           // System.out.println(this.m + " " + this.n);
            String red;
            int x;
            int y;
            int r;
            int i = 0;
            String[] redArray;

            while ((red = in.readLine()) != null){
                redArray = red.split(" ", 3);
                x = Integer.parseInt(redArray[0]);
                y = Integer.parseInt(redArray[1]);
                r = Integer.parseInt(redArray[2]);
               // System.out.println(x + " " + y + " " + r);
                int[] niz = new int[3];
                niz[0] = x;
                niz[1] = y;
                niz[2] = r;
                this.teren.add(niz);


            }
            //System.out.println("Izasao iz petlje");
            while (true) {
                try {
                    byte[] buf1 = new byte[100];
                    DatagramPacket dp = new DatagramPacket(buf1, buf1.length);
                    this.server.receive(dp);
                    System.out.println("Pristigao klijent!");

                    String request = new String(dp.getData(), 0, dp.getLength(), StandardCharsets.US_ASCII);
                    String[] nizpom = request.split(" ", 3);
                  //  System.err.println(request);
                    int pozicijaX = Integer.parseInt(nizpom[0]);
                    int pozicijaY = Integer.parseInt(nizpom[1]);
                    int pozicijaR = Integer.parseInt(nizpom[2]);
                    String provera = this.proveriPokrivenost(pozicijaX, pozicijaY);
                   // System.out.println(provera);
                    byte[] buf2 = provera.getBytes(StandardCharsets.US_ASCII);
                    DatagramPacket dp2 = new DatagramPacket(buf2, buf2.length, dp.getAddress(), dp.getPort());
                    server.send(dp2);
                }catch (IOException e){
                    this.sc.close();
                    server.close();
                    e.printStackTrace();
                }
            }

    }
    private String proveriPokrivenost(int x, int y){


        return "P" ;
    }

}

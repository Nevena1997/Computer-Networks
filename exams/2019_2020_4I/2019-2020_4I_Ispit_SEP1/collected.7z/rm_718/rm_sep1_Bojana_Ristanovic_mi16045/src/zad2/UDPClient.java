package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient extends Thread{
    public static void main(String[] args) {
        System.out.println("glhf from UDPClient");
        try (DatagramSocket client = new DatagramSocket()){
            System.out.println("Klijent pokrenut");

            Scanner userIn = new Scanner(System.in);
            StringBuilder sb = new StringBuilder();
            int x = userIn.nextInt();
            int y = userIn.nextInt();
            sb.append(x);
            sb.append("\n");
            sb.append(y);
          //  System.err.println(sb.toString());
            byte[] buff = sb.toString().getBytes();
            DatagramPacket request = new DatagramPacket(buff, buff.length, InetAddress.getLoopbackAddress(), 12345);
            client.send(request);

            byte[] buffer = new byte[256];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            client.receive(response);

            System.out.println(new String(response.getData(), 0, response.getLength()));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

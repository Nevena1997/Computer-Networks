package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.channels.FileChannel;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class UDPServer extends Thread{

    public static final int DEFAULT_PORT = 12345;
    private int port;
    private int m;
    private int n;
    private HashMap<Integer, List<Integer>> scanners = new HashMap<>();


    UDPServer(int port) {
        this.port = port;
        this.ucitaj(Paths.get("terrain.txt"));
    }

    private void ucitaj(Path path) {

        if (Files.isRegularFile(path)) {
            try {
                BufferedReader in = new BufferedReader(Files.newBufferedReader(path));
                String line = in.readLine();

                this.m = Integer.parseInt(line.split(" ")[0]);
                this.n = Integer.parseInt(line.split(" ")[1]);
                System.err.println(m + " " + n);
                int id = 1;
                while ((line = in.readLine()) != null) {
                    List<Integer> position = new ArrayList<>();
                    position.add(Integer.parseInt(line.split(" ")[0]));
                    position.add(Integer.parseInt(line.split(" ")[1]));
                    position.add(Integer.parseInt(line.split(" ")[2]));
                    this.scanners.put(id, position);
                    id++;
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

      /*  this.m = 9;
        this.n = 6;
        this.scanners = new HashMap<>();
        List<Integer> position1 = new ArrayList<>();
        position1.add(3);
        position1.add(4);
        position1.add(1);
        this.scanners.put(1, position1);

        List<Integer> position2 = new ArrayList<>();
        position2.add(2);
        position2.add(0);
        position2.add(1);
        this.scanners.put(1, position2);


        List<Integer> position3 = new ArrayList<>();
        position3.add(6);
        position3.add(2);
        position3.add(2);
        this.scanners.put(1, position3);*/
        System.out.println("terrain.txt ucitan");
        }
    }

    public static void main(String[] args) {
        System.out.println("glhf from UDPServer");
        new UDPServer(DEFAULT_PORT).start();
    }

    @Override
    public void run() {
        try (DatagramSocket server = new DatagramSocket(this.port)){
            System.err.println("Server is listening on port 12345");
            while (true){
                byte[] buff = new byte[256];
                try {
                    DatagramPacket request = new DatagramPacket(buff, buff.length);
                    server.receive(request);
                    System.out.println("Stigao datagram");
                  //  System.err.println("Server received: " + new String(request.getData(), 0, request.getLength()));

                    byte[] buffer = new byte[256];
                    if (this.izracunajPokrivenost(new String(request.getData(), 0, request.getLength())) == true){
                        buffer = "Pokriven!".getBytes();
                    } else {
                        buffer = "Nije pokriven!".getBytes();
                    }

                    DatagramPacket response = new DatagramPacket(buffer, buffer.length, request.getAddress(), request.getPort());
                    server.send(response);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

    private boolean izracunajPokrivenost(String s) {
        String[] pozicije = s.split("\n");
        int x = Integer.parseInt(pozicije[0]);
        int y = Integer.parseInt(pozicije[1]);
     //   System.err.println(x + " " + y);

        if (x < 0 || x  > m || y < 0 || y > n)
            return false;

        for (Iterator<Integer> iterator = this.scanners.keySet().iterator(); iterator.hasNext();){
            List<Integer> poz = this.scanners.get(iterator.next());
            int x1 = poz.get(0);
            int y1 = poz.get(1);
            int r= poz.get(2);

            if ((x >= x1-r && x <= x1+r) && (y >= y1-r && y <= y1+r))
                return true;
        }

        return false;
    }
}

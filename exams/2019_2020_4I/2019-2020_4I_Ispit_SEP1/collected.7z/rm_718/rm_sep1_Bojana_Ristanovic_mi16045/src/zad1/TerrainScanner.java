package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        System.out.println("glhf from TerrainScanner");

        try(Socket client = new Socket("localhost", 7337);
        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(client.getOutputStream(), true)
        ) {

            System.err.println("Client connected");

            Scanner userIn = new Scanner(System.in);
            int x = userIn.nextInt();
            int y = userIn.nextInt();
            int r = userIn.nextInt();

            out.print(x + "\r");
            out.print(y + "\r");
            out.println(r);

            String odgovor;
            while ((odgovor = in.readLine()) != null){
                System.out.println(odgovor);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.err.println("Client: disconnected!");

    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;

public class Hub {

    private int port;
    private int n;
    private int m;
    private int povrsina;

    public Hub(int port) {
        this.port = port;
    }

    public static void main(String[] args) {
        System.out.println("glhf from Hub");
        Hub server = new Hub(7337);
        server.execute();
    }

    private void execute() {
        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ){

            if (!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Couldn't open channel or selector");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(this.port));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            System.out.println("Unesite velicinu terena:");
            Scanner in = new Scanner(System.in);
            this.m = in.nextInt();
            this.n = in.nextInt();
            this.povrsina = this.m * this.n;
            System.err.println("Povrsina: " + povrsina);

            long currentTime = System.currentTimeMillis();
            HashMap<Integer, List<Integer>> scanners = new HashMap<>();
            long pokrivenost = 0;
           // List<SelectionKey> clients = new ArrayList<>();
            int id = 1;


            while (true){
                selector.select();

                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()){
                    SelectionKey key = iterator.next();
                    iterator.remove();

                    try {
                        if (key.isAcceptable()){
                            this.acceptScanner(key, selector);
                        } else if (key.isReadable()){
                            this.read(key, scanners, id);
                            id++;
                        }else if (key.isWritable()){
                            this.write(key, pokrivenost);
                        }

                    }catch (IOException e){
                        key.cancel();
                        try {
                            key.channel().close();
                        }catch (IOException ex){
                            ex.printStackTrace();
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void write(SelectionKey key, long pokrivenost) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        ByteBuffer buffer = (ByteBuffer) key.attachment();

        if (buffer.hasRemaining()){
            client.write(ByteBuffer.allocateDirect((byte)pokrivenost));
        }
    }

    private void read(SelectionKey key, HashMap<Integer, List<Integer>> scanners, int id) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        ByteBuffer buff = (ByteBuffer) key.attachment();

        if (buff == null){
            buff = ByteBuffer.allocate(256);
            key.attach(buff);
        }

        client.read(buff);
        String odgovor = new String(buff.array());
      /*  String[] s = odgovor.substring(0, odgovor.lastIndexOf("\n")).split("\r");
        System.err.println(Integer.parseInt(s[0]));
        System.err.println(Integer.parseInt(s[1]));
        System.err.println(Integer.parseInt(s[2]));*/
       List<Integer> position = new ArrayList<>();
       if (odgovor.contains("\n")){
           String[] s = odgovor.substring(0, odgovor.lastIndexOf("\n")).split("\r");
           int x = Integer.parseInt(s[0]);
           int y = Integer.parseInt(s[1]);
           int r = Integer.parseInt(s[2]);
           if (x > m || x < 0 || y > n || y < 0){
               System.err.println("Wrong position");
               key.cancel();
               return;
           }
           position.add(x);
           position.add(y);
           position.add(r);
       }
       scanners.put(id, position);
       buff.flip();
       key.interestOps(SelectionKey.OP_WRITE);
    }

    private void acceptScanner(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel server = (ServerSocketChannel) key.channel();
        SocketChannel client = server.accept();
        client.configureBlocking(false);
        SelectionKey k = client.register(selector, SelectionKey.OP_READ);

        System.err.println("Client accepted");
    }
}

package zad2;

import zad1.Hub;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPServer {
    public static void main(String[] args){
        try {
            DatagramSocket ds = new DatagramSocket(12345);
            System.out.println("[start]");
            while(true) {
                byte[] buff = new byte[8];
                DatagramPacket dp = new DatagramPacket(buff, buff.length);
                ds.receive(dp);
                System.out.println("primio klijenta");
//                System.out.println(dp.getData().toString());
                ByteBuffer b = ByteBuffer.allocate(8).wrap(dp.getData());
//                System.out.println(b);
                b.rewind();
                int x = b.getInt();
                int y = b.getInt();
                boolean pok = pokriven(x,y);
                String s;
                if(pok){
                    s = "Pokriven je!";
                }
                else  s = "Nije pokriven!";
//                System.out.println(s);

                buff = s.getBytes();
//                ByteBuffer bufg = ByteBuffer.wrap(s.getBytes());
                DatagramPacket res = new DatagramPacket(buff, buff.length, dp.getAddress(), dp.getPort());
                ds.send(res);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static boolean pokriven(int x, int y) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("/home/ispit/Desktop/rm_sep1_Aleksandar_Milosevic_mi17060/terrain.txt"));
        System.out.println("ucitan fajl terrain.txt");
        int n = sc.nextInt();
        int m = sc.nextInt();
        int[][] teren = new int[m][n];
        while(sc.hasNextInt()) {
            int p = sc.nextInt();
            int r = sc.nextInt();
            int q = sc.nextInt();
            for (int i = p - q; i <= p + q; i++) {
                if (i < 0 || i >= m)
                    continue;
                for (int j = r - q; j <= r + q; j++) {
                    if (j < 0 || j >= n)
                        continue;
                    teren[i][j] = 1;
                }
            }
        }
//        for(int i=0;i<m;i++){
//            for(int j=0;j<n;j++){
//                System.out.print(teren[i][j]);
//                System.out.print(" ");
//            }
//            System.out.println("");
//        }
        return teren[x][y] == 1;
    };

}

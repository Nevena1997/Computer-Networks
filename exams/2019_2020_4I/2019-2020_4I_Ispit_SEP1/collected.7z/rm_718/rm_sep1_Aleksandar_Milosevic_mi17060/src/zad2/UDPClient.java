package zad2;

import zad1.Hub;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try {
            InetAddress addr = InetAddress.getByName("localhost");
            DatagramSocket ds = new DatagramSocket();
            Scanner sc = new Scanner(System.in);
            int n = sc.nextInt();
            int m = sc.nextInt();
            byte[] buff = new byte[512];
            ByteBuffer koord = ByteBuffer.allocate(8).putInt(n).putInt(m);
            koord.rewind();
            DatagramPacket dp = new DatagramPacket(koord.array(), koord.array().length,addr,12345);
            ds.send(dp);

            DatagramPacket recv = new DatagramPacket(buff,buff.length);
            ds.receive(recv);

            String s = recv.getData().toString();
            ByteBuffer bux = ByteBuffer.wrap(recv.getData());
            System.out.println(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

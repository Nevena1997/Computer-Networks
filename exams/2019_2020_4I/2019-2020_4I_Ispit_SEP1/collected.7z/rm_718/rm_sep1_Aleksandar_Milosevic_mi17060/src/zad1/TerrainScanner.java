package zad1;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        InetSocketAddress addr = new InetSocketAddress("localhost",Hub.PORT);
        try {
            SocketChannel client = SocketChannel.open(addr);
            ByteBuffer buff = ByteBuffer.allocate(12);
            WritableByteChannel out = Channels.newChannel(System.out);
//            Scanner sc = new Scanner(new File("/home/ispit/Desktop/rm_sep1_Aleksandar_Milosevic_mi17060/terrain.txt"));
            Scanner sc = new Scanner(System.in);
//            int n = sc.nextInt();
//            int m = sc.nextInt();
            int x = sc.nextInt();
            int y = sc.nextInt();
            int r = sc.nextInt();
            buff.putInt(x);
            buff.putInt(y);
            buff.putInt(r);
            buff.rewind();

            client.write(buff);
            buff.clear();
            while(true){
                int n = client.read(buff);
                if(n>0){
                    buff.flip();
                    out.write(buff);
                    buff.clear();
                }
                else if(n==-1){
                    System.out.println("Scanner error");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Hub {


    public static final int PORT = 7337;
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int[][] teren = new int[n][m];

        for(int i=0;i<n;i++){
            for (int j=0;j<m;j++){
                teren[i][j] = 0;
            }
        }

        try {
            ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();
            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            System.out.println("[start]");
            while(true){
                selector.select();
                Set<SelectionKey> keys = selector.selectedKeys();
                Iterator<SelectionKey> it = keys.iterator();
                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();
                    if(key.isAcceptable()){
                        System.out.println("Prihvatio klijenta.");
                        ServerSocketChannel s = (ServerSocketChannel)key.channel();
                        SocketChannel client = s.accept();
                        ByteBuffer buff = ByteBuffer.allocate(12);
                        client.read(buff);
                        buff.flip();
                        while(buff.hasRemaining()){
                            System.out.println(buff.getInt());
                        }
                        client.configureBlocking(false);
                        client.register(selector,SelectionKey.OP_WRITE);
                        buff.rewind();
                        client.write(buff);
                        key.attach(buff);
                    }
                    else if(key.isWritable()){
                        SocketChannel client = (SocketChannel)key.channel();
                        ByteBuffer buff = (ByteBuffer)key.attachment();
//                        buff.rewind();
                        if(!buff.hasRemaining()){
                            float procenat = pokrivenost(teren,n,m);
                            System.out.println(procenat + "%");
                            buff.putFloat(procenat);
                            buff.flip();
                        }

                        client.write(buff);
                        Thread.sleep(5000);
                        buff.clear();
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static float pokrivenost(int[][] teren,int n, int m){
        float zbir = 0;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                zbir += teren[i][j];
            }
        }
        return zbir/(n*m);
    };
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

public class UDPClient {
    public static void main(String[] args) throws IOException {

        try (DatagramSocket socket = new DatagramSocket()) {

            byte[] buffer = new byte[64];
            InetSocketAddress address = new InetSocketAddress("localhost", UDPServer.PORT);
            DatagramPacket request = new DatagramPacket(buffer,buffer.length, address);
            socket.send(request);

            DatagramPacket response = new DatagramPacket(buffer, buffer.length);

            socket.receive(response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UDPServer {

    public final static int PORT = 12345;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT);
            BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                new FileInputStream("terrain.txt")
            ));
        ) {
            String line;
            boolean first = true;
            int m=0,n=0,i=0;
            int[] fields = new int[9];
            while((line = in.readLine()) != null){
                if(!first){
                    fields[i++] = line.charAt(0)-'0';
                    fields[i++] = line.charAt(2)-'0';
                    fields[i++] = line.charAt(4)-'0';
                } else {
                    m = Integer.parseInt(String.valueOf(line.charAt(0)));
                    n = Integer.parseInt(String.valueOf(line.charAt(2)));
                }
                first = false;
            }

            byte[] buffer = new byte[64];
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);

            DatagramPacket response = new DatagramPacket(buffer, buffer.length,
                                                         request.getAddress(), PORT);

            server.receive(request);

            server.send(response);

        } catch (IOException e){
            System.err.println("Problem sa serverom");
            e.printStackTrace();
        }
    }
}

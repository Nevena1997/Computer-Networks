package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        InetSocketAddress address = new InetSocketAddress(Hub.PORT);
        try (SocketChannel client = SocketChannel.open(address);
             Scanner stdIn = new Scanner(System.in);
        ) {

            System.out.println("Unesite brojeve: (x,y) i r: ");
            int x = stdIn.nextInt();
            int y = stdIn.nextInt();
            int r = stdIn.nextInt();

            ByteBuffer buff = ByteBuffer.allocate(12);
            buff.put((byte) x);
            buff.put((byte) y);
            buff.put((byte) r);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

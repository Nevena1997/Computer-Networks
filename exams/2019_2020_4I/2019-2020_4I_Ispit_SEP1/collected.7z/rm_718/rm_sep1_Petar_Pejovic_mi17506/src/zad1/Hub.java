package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    public final static int PORT = 7337;

    public static void main(String[] args) {

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open();
        ) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Unesite velicinu terena");
            int m = sc.nextInt();
            int n = sc.nextInt();
            sc.close();

            int pokrivenost = 0;

            if(m < 0 || n < 0){
                System.err.println("Lose unete dimenzije terena");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {
                selector.select();

                if(pokrivenost >= 1){
                    break;
                }

                try {
                    Iterator<SelectionKey> iter = selector.selectedKeys().iterator();
                    ByteBuffer buffer = ByteBuffer.allocate(12);
                    while (iter.hasNext()) {
                        SelectionKey key = iter.next();
                        iter.remove();

                        if (key.isAcceptable()) {
                            ServerSocketChannel channel = (ServerSocketChannel) key.channel();
                            SocketChannel client = channel.accept();

                            buffer.put((byte) pokrivenost);
                            buffer.flip();


                        } else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel();

                            client.register(selector, SelectionKey.OP_WRITE);

                            if(buffer.hasRemaining()){
                                buffer.rewind();
                                buffer.put((byte) pokrivenost);
                                buffer.flip();
                            }

                        } else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();

                            client.register(selector, SelectionKey.OP_READ);
                        }
                    }
                } finally {
                }
            }

        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    //klijent

    private int x;
    private int y;
    private int r;

    //teren: mreza duzine m i sirine n
    //(x,y) jedno teme mreze
    //skener pokriva kvadrat velicine 2r sa centrom u (x,y)
    //m,n,x,y,r su int, >=0

    public static void main(String[] args) {

        //System.out.println("glhf from TerrainScanner");

        try(SocketChannel klijent = SocketChannel.open(new InetSocketAddress(7337))){
            klijent.configureBlocking(true);


            Scanner sc = new Scanner(System.in);
//JEL TREBA WRITABLESTREAM??
            //klijent salje serveru (x,y) i r

            System.out.println("Unesi x");
            //int x = Integer.parseInt(sc.nextLine());
            String x = sc.nextLine();

            System.out.println("Unesi y");
            //int y = Integer.parseInt(sc.nextLine());
            String y = sc.nextLine();

            System.out.println("Unesi r");
            //int r = Integer.parseInt(sc.nextLine());
            String r = sc.nextLine();

            String xyr = x + "*" + y + "*" + r + "!";
            //format koji saljem :  x*y*r!

            //sad klijent pise na server::
            ByteBuffer buff = ByteBuffer.allocate(16);
            buff.clear();
            buff.put(xyr.getBytes());
            buff.flip();
            klijent.write(buff);

            //poslali smo serveru x,y,r
            //sad ispisujemo odg od servera ::


            while(true){
                int procitano = klijent.read(buff);
                if(procitano == -1)
                    break;
                buff.rewind();
                int a = buff.getInt();
                System.out.println(a);
                //String linija = new String(buff.array());
                //System.out.println(linija);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

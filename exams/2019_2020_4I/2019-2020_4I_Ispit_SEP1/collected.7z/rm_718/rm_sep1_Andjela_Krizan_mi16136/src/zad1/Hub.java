package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.*;

public class Hub {
    //server

    Map<Integer, Skener> skeneri = new HashMap<>();
    int nextID=1;
    int m;
    int n;

    int pokrivenost = 0;


    public static void main(String[] args) {

        new Hub().execute();
        //System.out.println("glhf from Hub");

    }

    private void execute() {

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("nesto nije ok");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(7337));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            Scanner sc= new Scanner(System.in);
            //unesi velicinu terena
            //teren: mreza duzine m i sirine n
            System.out.println("Unesite duzinu terena m:");
            m = sc.nextInt();
            System.out.println("Unesite sirinu terena n:");
            n = sc.nextInt();

            //int povrsinaTerena = m*n;

            while(true){
                selector.select();

                Set<SelectionKey> spremni = selector.selectedKeys();
                Iterator<SelectionKey> iter = spremni.iterator();

                while(iter.hasNext()){
                    SelectionKey trenutniKljuc = iter.next();
                    iter.remove();
                    try {
                        if (trenutniKljuc.isAcceptable()) {
                            //server
                            //prihvata klijenta i priprema ga
                            ServerSocketChannel serverKanal = (ServerSocketChannel) trenutniKljuc.channel();
                            SocketChannel klijentKanal = serverKanal.accept();
                            klijentKanal.configureBlocking(false);
                            SelectionKey klijentKljuc = klijentKanal.register(selector, SelectionKey.OP_READ);
                            //jer za svaki klijent prvo se cita sa njega

                            ByteBuffer buff = ByteBuffer.allocate(16);
                            buff.clear();
                            klijentKljuc.attach(buff);
                        }
                        if (trenutniKljuc.isReadable()) {
                            //cita sa klijenta
                            //cita (x,y) i r
                            //ovde treba da se promeni operacija od interesa(na kraju)
                            SocketChannel klijentKanal = (SocketChannel) trenutniKljuc.channel();

                            ByteBuffer buff = (ByteBuffer) trenutniKljuc.attachment();
                            //String procitano;
                            while(true){
                                int procitano = klijentKanal.read(buff);
                                if(procitano > 0){
                                    String niska = new String(buff.array(),0,buff.array().length);
                                    if(niska.contains("!") ){
                                        //celu smo procitali, niska: x*y*r!
                                        String xStr = niska.substring(0,niska.indexOf("*"));
                                        String yStr = niska.substring(niska.indexOf("*")+1, niska.lastIndexOf("*"));
                                        String rStr = niska.substring(niska.lastIndexOf("*")+1, niska.indexOf("!"));

                                        int x = Integer.parseInt(xStr);
                                        int y = Integer.parseInt(yStr);
                                        int r = Integer.parseInt(rStr);

                                        //duzina m:  m i y gledam
                                        //siria n :  n i x gledam
                                        if(y>m || x>n || y<0 || x<0){
                                            //raskidam konekciju
                                            klijentKanal.close();
                                            trenutniKljuc.cancel();
                                        }

                                        skeneri.put(nextID, new Skener(x,y,r));
                                        nextID++;
                                        pokrivenost = pokrivenost + (2*r)/(m*n);

                                        //System.out.println(xStr);
                                        //System.out.println(yStr);
                                        //System.out.println(rStr);
                                        break;
                                    }
                                }
                            }
                            trenutniKljuc.interestOps(SelectionKey.OP_WRITE);
                        }
                        if (trenutniKljuc.isWritable()) {
                            //pise na klijent
                            //na svakih 5s pise trenutnu pokrivenost terena
                            Thread.sleep(5000);

                            SocketChannel klijentKanal = (SocketChannel) trenutniKljuc.channel();

                            ByteBuffer buff = (ByteBuffer) trenutniKljuc.attachment();
                            buff.clear();
                            buff.rewind();
                            //pisem:
                            buff.putInt(pokrivenost);
                            System.out.println(pokrivenost);
                            buff.flip();

                            klijentKanal.write(buff);
                        }
                    }catch (Exception e){
                        trenutniKljuc.cancel();
                        trenutniKljuc.channel().close();
                    }


                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }



    }

    private class Skener {
        private int x;
        private int y;
        private int r;


        public Skener(int x, int y, int r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }




    }
}

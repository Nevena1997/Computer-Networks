package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        //System.out.println("glhf from UDPClient");
        try(DatagramSocket klijent = new DatagramSocket()){

            Scanner sc = new Scanner(System.in);

            //klijent salje inicijalni datagram sa x i y
            System.out.println("unesite x");
            int x = sc.nextInt();
            System.out.println("unesite y:");
            int y = sc.nextInt();
            byte[] buffer = new byte[8];
            String xy = x + "*" + y + "!";
            //System.out.println(xy);
            buffer = xy.getBytes();
            DatagramPacket zaSlanje = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), 12345);
            klijent.send(zaSlanje);



            //odgovara jel pokriven ili ne
            byte[] buffer1 = new byte[16];
            while(true) {
                DatagramPacket zaPrijem = new DatagramPacket(buffer1, buffer1.length);
                klijent.receive(zaPrijem);
                String odg = new String(buffer1);
                odg = odg.trim();
                System.out.println(odg);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

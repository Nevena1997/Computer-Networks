package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.security.interfaces.RSAKey;
import java.util.HashSet;
import java.util.Set;

public class UDPServer {

    Set<Skener> skeneri = new HashSet<>();
    public static double pokivenost = 0;


    public static void main(String[] args) {
        new UDPServer().execute();
        //System.out.println("glhf from UDPServer");
    }

    private void execute() {
        try(DatagramSocket server = new DatagramSocket(12345)){

            BufferedReader fileIn = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_sep1_Andjela_Krizan_mi16136/terrain.txt")));
            //ucitavanje:
            String prvaLinija = fileIn.readLine().trim();
            String mStr = prvaLinija.substring(0,prvaLinija.indexOf(" "));
            String nStr = prvaLinija.substring(prvaLinija.indexOf(" ")+1);
            int m = Integer.parseInt(mStr);
            int n = Integer.parseInt(nStr);

            String linija;
            while(null!=(linija = fileIn.readLine())){
                String xStr = linija.substring(0, linija.indexOf(" "));
                String yStr = linija.substring(linija.indexOf(" ")+1, linija.lastIndexOf(" "));
                String rStr = linija.substring(linija.lastIndexOf(" ")+1);
                int x = Integer.parseInt(xStr);
                int y = Integer.parseInt(yStr);
                int r = Integer.parseInt(rStr);
                skeneri.add(new Skener(x,y,r));
            }



            //klijent mi salje koordinare x i y
            byte[] buffer = new byte[16];
            while(true) {
                DatagramPacket zaPrijem = new DatagramPacket(buffer, buffer.length);
                server.receive(zaPrijem);
                System.out.println("Pristigao klijent!");
                //prijem je oblika:  x*y!
                String xy = new String(zaPrijem.getData(), 0, zaPrijem.getLength());
                String xStr = xy.substring(0, xy.indexOf("*"));
                String yStr = xy.substring(xy.indexOf("*") + 1, xy.indexOf("!"));
                int x = Integer.parseInt(xStr);
                int y = Integer.parseInt(yStr);


                //mi saljemo klijentu odg

                String odg = generisiOdg(x,y);
                buffer = odg.getBytes();
                DatagramPacket zaSlanje = new DatagramPacket(buffer, buffer.length, zaPrijem.getAddress(), zaPrijem.getPort());
                server.send(zaSlanje);
            }



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String generisiOdg(int x, int y) {
        //ovde bi trebalo u odnosu na x i y da izr pokrivenost
        return "Pokriven!";
    }

    private class Skener {
        int x;
        int y;
        int r;

        public Skener(int x, int y, int r) {
            this.x=  x;
            this.y = y;
            this.r = r;
            //pokivenost += (2*r)/m*n;
        }
    }
}

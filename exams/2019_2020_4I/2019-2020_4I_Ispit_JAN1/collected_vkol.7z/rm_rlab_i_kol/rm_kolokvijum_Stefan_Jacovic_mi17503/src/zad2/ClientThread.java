package zad2;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
}

package zad2;

final class ChessPlayer {
    // id
    // naziv
    // elo

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

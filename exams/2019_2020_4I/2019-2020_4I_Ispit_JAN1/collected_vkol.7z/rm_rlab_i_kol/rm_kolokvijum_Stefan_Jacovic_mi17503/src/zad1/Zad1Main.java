package zad1;

import javax.print.DocFlavor;
import java.io.*;
import java.net.URL;
import java.util.Scanner;

final class Zad1Main {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            String tag = sc.next();
            int br = 0;
            BufferedReader bf = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"
            )));
            String s;
            while((s = bf.readLine()) != null){
                br++;
                try{
                    URL u = new URL(s);
                    String p = u.getProtocol();

                    if(p.equals("file") && s.endsWith("html") ){
                        //System.out.println("Kreiranje zasebne niti i citanje fajla");
                    }
                }
                catch(Exception e){
                    //System.out.println("Nije validan URL");
                }
            }
            System.out.println("lines: " +br);
        }
        catch(FileNotFoundException e){
            System.out.println("Fajl nije pronadjen");
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

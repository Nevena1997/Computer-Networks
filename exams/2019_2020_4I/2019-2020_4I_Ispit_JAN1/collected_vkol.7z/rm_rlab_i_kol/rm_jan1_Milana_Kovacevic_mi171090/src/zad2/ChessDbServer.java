package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

final class ChessDbServer {
    public static Map<Integer, ChessPlayer> players = Collections.synchronizedMap(new HashMap<Integer, ChessPlayer>());
    public static AtomicInteger totalId = new AtomicInteger(1);

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(ChessDbClient.DEFAULT_PORT)) {

            while(true) {
                Socket client = server.accept();
                System.out.println("Accepted client " + client);

                new Thread(new ClientThread(client)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.util.concurrent.atomic.AtomicInteger;

final class ChessPlayer {

    private int id;
    private String naziv;
    private int elo;

    public ChessPlayer (int id, String n) {
        this.naziv = n.trim();
        this.id = id;
        this.elo = 1300;
    }

    public void setElo(int value) {
        this.elo = value;
    }


    @Override
    public String toString() {
        // naziv: elo
        return this.naziv + ":\t" + this.elo;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;

final class ClientThread implements Runnable {
    // User thread for the ChessDbServer
    private Socket client;

    public ClientThread(Socket c) {
        this.client = c;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            while (true) {
                String req = in.readLine();
                if (req == null)
                    continue;

                if (req.startsWith("sel")) {
                    int id = Integer.parseInt(req.substring(3).trim());
                    ChessPlayer p = selectPlayer(id);
                    if (p == null) {
                        out.write("id not found");
                    } else {
                        out.write(p.toString());
                        out.flush();
                    }

                } else if (req.startsWith("ins")) {
                    String naziv = req.substring(3).trim();
                    int nextId = ChessDbServer.totalId.getAndAdd(1);
                    ChessPlayer p = new ChessPlayer(nextId, naziv);
                    insertPlayer(nextId, p);
                    out.write("ins je uspesno izvrsen");
                    out.newLine();
                    out.flush();

                } else if (req.startsWith("upd")) {
                    String args = req.substring(3).trim();
                    int i = req.indexOf(" ");
                    int id = Integer.parseInt(args.substring(0, i).trim());
                    int elo = Integer.parseInt(args.substring(i + 1).trim());

                    updatePlayer(id, elo);
                    out.write("upd je uspesno izvrsen");
                    out.newLine();
                    out.flush();
                } else continue;


            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    private static void updatePlayer(int id, int elo) {
        synchronized (ChessDbServer.players) {
            if (ChessDbServer.players.containsKey(id)) {
                ChessPlayer p = ChessDbServer.players.get(id);
                p.setElo(elo);
            }
        }
    }

    private static ChessPlayer selectPlayer(int id) {
        if (ChessDbServer.players.containsKey(id)) {
            return ChessDbServer.players.get(id);
        }
        else {
            return null;
        }
    }

    private static void insertPlayer(int id, ChessPlayer p) {
        synchronized (ChessDbServer.players) {
            ChessDbServer.players.put(id, p);
        }
    }

}



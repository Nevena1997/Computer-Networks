package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static int DEFAULT_PORT = 1996;

    public static void main(String[] args) {

        //System.out.println("Hello from ChessDbClient!");

        try(Socket client = new Socket("localhost", DEFAULT_PORT)) {
            try(Scanner sc = new Scanner(System.in);
                BufferedWriter out = new BufferedWriter( new OutputStreamWriter(client.getOutputStream()))) {
                while (true) {
                    // user input
                    String req;

                    req = sc.nextLine();

                if (req.equalsIgnoreCase("bye")) {
                    break;
                } else if (req.startsWith("sel") || req.startsWith("ins") || req.startsWith("upd")) {

                    System.out.println("Sending request " + req);

                    out.write(req);
                    out.newLine();
                    out.flush();


                    // read server response
/*
                    try( BufferedReader in = new BufferedReader (new InputStreamReader(client.getInputStream()))) {
                        String response = in.readLine();
                        System.out.println("response:\t" + response);
                    }*/
                }
            }

            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

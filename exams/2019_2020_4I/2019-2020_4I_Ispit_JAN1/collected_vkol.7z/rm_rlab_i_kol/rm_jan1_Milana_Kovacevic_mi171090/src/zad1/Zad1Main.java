package zad1;


/*
Napisati  program  koji  ispisuje  ukupan  broj  pojavljivanja  zadatog  HTML  tag-a  u  svim  HTML  fajlovima  sazadatog spiska URL-ova.
U datoteci urls.txt unutar direktorijuma tests na Desktop-u se nalazi spisak URL-ova (po jedan u svakojliniji).
Koriste ́ci odgovaraju ́cebaferisaneulazne tokove proˇcitati sadrˇzaj pomenutog fajla i ispisati brojlinija u tom fajlu.(2p)

Za svaku proˇcitanu liniju fajlaurls.txtkreirati novi URL objekat koriste ́ciURLklasu.  Preskoˇciti sve linijekoje ne predstavljaju validan URL.(1p)

Za  svaki  validni  URL  proveriti  protokol  koji  se  koristi.   Ukoliko  je  protokolFILEi  ukoliko  putanja  vodido HTML fajla (ekstenzija.html),
 kreirati zasebnu nit koja  ́ce otvoritibaferisaniulazni tok do tog fajlaputem  URL  klase  i  proˇcitati  sadrˇzaj  fajla  (detalji  obrade  su  u  narednoj  stavci).
 Kodnu  stranu  prilikomuˇcitavanja  postaviti  na  UTF-8.   Ukoliko  fajl  na  datoj  putanji  ne  postoji,  ispisati  odgovaraju ́cu  poruku
 iugasiti nit koja je pokrenuta da ga obradi.(5p)

 Pre parsiranja fajlaurls.txt, sa standardnog ulaza uˇcitati jednu nisku koja predstavlja naziv HTML tag-a.Prebrojati koliko se puta zadati tag pojavljuje u svim fajlovima iz prethodne stavke tako ˇsto  ́ce svaka nitprebrojati pojavljivanja za fajl koji joj je dodeljen.  Ispisati ukupan broj na standardni izlaz (videti primereispisa ispod teksta zadatka).  Pritom, paziti na sinhronizaciju niti ukoliko se koristi deljeni brojaˇc.(5p)Postarati se da program ispravno barata specijalnim sluˇcajevima (npr.  ako fajl ne postoji na datoj putanji)i ispravno zatvoriti sve koriˇs ́cene resurse u sluˇcaju izuzetka.

*/

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

final class Zad1Main {
    public static AtomicInteger TOTAL_TAGS = new AtomicInteger(0);
    public static AtomicInteger THREADS_FINISHED = new AtomicInteger(0);

    public static void main(String[] args) {
        // user input
        String tag;
        try(Scanner sc = new Scanner(new BufferedInputStream(System.in))) {
            tag = sc.nextLine().trim();
        }


        String fileName = "/home/ispit/Desktop/tests/urls.txt";

        int numLines = 0;
        int numThreads = 0;
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)))){
            String line;
            while((line = in.readLine()) != null) {
                //System.out.println(line);
                numLines++;

                try {
                    URL url = new URL(line);
                    String protocol = url.getProtocol();
                    if (protocol.equalsIgnoreCase("file") && line.endsWith(".html")) {
                        //System.out.println(line);
                        // start thread
                        new Thread(new HTMLReaderThread(url, tag)).start();
                        numThreads++;
                    }

                } catch (MalformedURLException e) {
                    // skip invalid urls
                    continue;
                }
            }

            System.out.println("lines:\t" + numLines);

        } catch (FileNotFoundException e) {
            System.err.println("File does not exist on desktop.\t" + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("num threads:\t" + numThreads);
        // wait for all threads to finish
        while (THREADS_FINISHED.get() != numThreads){
            try {
                Thread.sleep(200);
                System.out.println("finished threads:\t" + THREADS_FINISHED.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("result:\t" + TOTAL_TAGS.get());

    }
}

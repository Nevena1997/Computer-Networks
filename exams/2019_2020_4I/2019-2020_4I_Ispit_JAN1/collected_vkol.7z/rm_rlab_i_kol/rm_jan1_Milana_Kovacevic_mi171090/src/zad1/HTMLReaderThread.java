package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class HTMLReaderThread implements Runnable {

    private URL url;
    private String tag;

    public HTMLReaderThread(URL u, String tag) {
        this.url = u;
        this.tag = tag;
    }

    @Override
    public void run() {

        //System.out.println("Hello from thread " + Thread.currentThread());

        int total = 0;
        try(BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8))) {

            String line;

            while((line = in.readLine()) != null) {
                //System.out.println(line);
                total += countTags(line);
            }
            //System.out.println("finished sum in thread " + Thread.currentThread());


        } catch (IOException e) {
            System.err.println("not found:\t" + url);
        }

        // total result
        //System.out.println("sum in thread " + Thread.currentThread());
        Zad1Main.TOTAL_TAGS.addAndGet(total);
        //System.out.println("finished sum in thread " + Thread.currentThread());
        Zad1Main.THREADS_FINISHED.addAndGet(1);
        //System.out.println("bye from thread " + Thread.currentThread());

    }

    private int countTags(String line) {
        int i = 0;
        int result = 0;
        while (true) {
            int index = line.substring(i).indexOf(this.tag);
            if (index == -1)
                break;
            else
                i = index + 1;
        }

        return result;
    }
}

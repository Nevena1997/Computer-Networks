package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;


final class ChessDbClient {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");
        String hostName = "localhost";
        int portNum = 1996;

        try(Socket s = new Socket(hostName, portNum)) {
            PrintStream out = new PrintStream(new BufferedOutputStream(s.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(new BufferedInputStream(s.getInputStream())));
            BufferedReader Sin = new BufferedReader(new InputStreamReader(new BufferedInputStream(System.in)));

            while(true){
                String line = Sin.readLine().trim();
                if(line.equalsIgnoreCase("bye"))
                    break;
                out.println(line);
                out.flush();
                String response = in.readLine();
                System.out.println("Odogovor od servera za igre:  " + response);
            }

            System.out.println("--- Kraj ---");

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

final class ChessDbServer {
    static Map<Integer, ChessPlayer> players = new TreeMap<>();

    static Lock katanac;
    static int freeId = 0;
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");
        int portNum = 1996;
        katanac = new ReentrantLock();
        try(ServerSocket sc = new ServerSocket(portNum)) {
            while (true) {
                Socket client = sc.accept();
                System.out.println("Pristigao klijent. Dobrodosao :)");
                (new ClientThread(client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

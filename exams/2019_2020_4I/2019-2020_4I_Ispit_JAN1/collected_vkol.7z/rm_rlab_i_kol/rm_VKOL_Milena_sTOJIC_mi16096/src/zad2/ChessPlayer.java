package zad2;

import java.util.concurrent.BlockingQueue;

final class ChessPlayer {
    int id;
    String naziv;
    int elo;

    ChessPlayer(int id, String naziv){
        this.id = id;
        this.naziv = naziv;
        this.elo = 1300;
    }

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

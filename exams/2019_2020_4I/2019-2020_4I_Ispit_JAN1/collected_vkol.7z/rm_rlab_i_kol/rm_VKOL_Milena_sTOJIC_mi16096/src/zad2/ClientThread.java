package zad2;

import java.io.*;
import java.net.Socket;

final class ClientThread extends Thread {
    Socket client;


    ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        super.run();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new BufferedInputStream(client.getInputStream())))) {
            PrintStream out = new PrintStream(new BufferedOutputStream(client.getOutputStream()));
            while(true){
                String line = in.readLine().trim();
                if(line.equalsIgnoreCase("bye"))
                    break;
                String[] komponente = line.split(" ");
                if(komponente[0].equals("sel"))
                {
                    if(komponente.length == 1)
                    {
                        System.err.println("Neispravno");
                        continue;
                    }else {
                        int id = Integer.parseInt(komponente[1]);
                        boolean found = false;

                        try {
                            ChessDbServer.katanac.lock();
                            if (!ChessDbServer.players.containsKey(id)) {
                                System.err.println("Nema tog igraca u bazi!");
                            } else
                                out.println("" + ChessDbServer.players.get(id).naziv + " " + ChessDbServer.players.get(id).elo);
                            out.flush();
                        } finally{
                            ChessDbServer.katanac.unlock();

                        }
                    }
                }

                else if(komponente[0].equals("ins")){
                    if(komponente.length < 2)
                    {
                        System.err.println("Neispravno");
                    }
                    else{
                        String naziv = komponente[1];
                        int id;
                        try{
                            ChessDbServer.katanac.lock();
                            id = ChessDbServer.freeId;
                            ChessDbServer.freeId++;
                        } finally{
                            ChessDbServer.katanac.unlock();
                        }
                        ChessPlayer player = new ChessPlayer(id, naziv);
                        ChessDbServer.players.put(id, player);
                        out.println("Uspesno dodat igrac!");
                        out.flush();

                    }
                }

                else if(komponente[0].equals("upd")){
                    if(komponente.length < 3)
                        System.err.println("Neispravno!");
                    else {
                        try {
                            ChessDbServer.katanac.lock();
                            int id = Integer.parseInt(komponente[1]);
                            int deltaE = Integer.parseInt(komponente[2]);

                            if (!ChessDbServer.players.containsKey(id))
                                System.err.println("Nema igraca");
                            else {
                                ChessDbServer.players.get(id).elo += deltaE;
                                out.println("Promenjeno");
                                out.flush();
                            }
                        }
                    finally{
                        ChessDbServer.katanac.unlock();
                    }}
                }
                else{
                    System.err.println("Nepodrzana opcija!");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;

final class HTMLReaderThread extends Thread {
    URL url;
    String tag;
    Lock katanac;

    HTMLReaderThread(URL url, String tag, Lock katanac){
        this.url = url;
        this.tag = tag;
        this.katanac = katanac;
    }

    @Override
    public void run() {
        super.run();
        System.out.println("-- Hello from file processing thread!");
        try {
            URLConnection uc = url.openConnection();

            int numberOfTags = 0;
            try(Scanner in = new Scanner(new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8)))) {

                while (in.hasNext()) {
                    String word = in.next();
                    System.out.println(word);
                    if (word.equals(tag))
                        numberOfTags++;
                }
            }



            try{
            this.katanac.lock();
            Zad1Main.brojac += numberOfTags;}

            finally {
                this.katanac.unlock();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

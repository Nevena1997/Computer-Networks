package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

final class Zad1Main {
    static int brojac = 0;
    public static void main(String[] args) {
        System.out.println("Hello from Zad1Main!");

        Scanner sc = new Scanner(System.in);
        String t = sc.next();
        String tag = "<" + t + ">";
        Lock katanac = new ReentrantLock();
        try (BufferedReader inFiles = new BufferedReader( new InputStreamReader
                    ( new BufferedInputStream( new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))))
        {
            int numLines = 0;
            String line;
            while((line = inFiles.readLine()) != null){
                numLines++;
                try {
                    URL u = new URL(line.trim());

                    if(u.getProtocol().equalsIgnoreCase("FILE") && line.trim().endsWith(".html")){
                        Thread nit = new HTMLReaderThread(u, tag, katanac);
                        nit.start();
                        nit.join(); //TODO: ZNam da se ovde narusava paralelizam! Ovo bismo ispravili sa listom gde bi nadovezivali niti
                    }

                } catch(MalformedURLException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            System.out.println("Broj linija u fajlu urls.txt je " + numLines);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Broj html tagova je " + brojac);
        sc.close();
    }
}

package zad2;

import javax.swing.*;
import java.io.*;

import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

final class ClientThread implements Runnable {
    // User thread for the ChessDbServer
    private Socket client;
    private static ArrayList<ChessPlayer> igraci=new ArrayList<>();
    ClientThread(Socket client) {
        this.client=client;
    }

    @Override
    public void run() {

        try(BufferedReader in =new BufferedReader(new InputStreamReader(this.client.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream(),StandardCharsets.UTF_8))){

            String poruka;
            while ((poruka=in.readLine())!=null) {
            System.out.println("> "+poruka);

            String[] pomocna=poruka.split(" ");
            Integer duz=pomocna.length;


            Integer brojIgraca=igraci.size();
            if (pomocna[0].equalsIgnoreCase("sel")){
                //System.out.println("usli ste u sel");
                Integer id= new Integer(pomocna[1]);


                ChessPlayer neki;
                //for (i=0;i<brojIgraca;)
                out.write(igraci.get(id-1).toString());
                out.newLine();
                out.flush();

            } else if(pomocna[0].equalsIgnoreCase("ins")){
                //System.out.println("usli ste u ins");
                String pom=new String("");
                for (int i=1;i<duz;i++) {
                    pom=pom+pomocna[i]+" ";
                }

                igraci.add(new ChessPlayer(pom));

                out.write("ins je uspesno izvrsen");
                out.newLine();
                out.flush();

            }else if(pomocna[0].equalsIgnoreCase("upd")){
                System.out.println("Kriticna sekcija");
                Integer promena=Integer.getInteger(pomocna[2]);
                Integer id=Integer.getInteger(pomocna[1]);



                out.write("upd je uspesno izvrsen");
                out.newLine();
                out.flush();

            }}
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            try {
                this.client.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

final class ChessDbServer {
    public final static int PORT=1996;

    public static void main(String[] args) {

        System.out.println("Hello from ChessDbServer!");
        try(ServerSocket server=new ServerSocket(PORT)){
            while(true) {
                Socket client=server.accept();
                new Thread(new ClientThread(client)).start();
            }
        }catch (IOException e) {
            e.printStackTrace();
        }

    }
}

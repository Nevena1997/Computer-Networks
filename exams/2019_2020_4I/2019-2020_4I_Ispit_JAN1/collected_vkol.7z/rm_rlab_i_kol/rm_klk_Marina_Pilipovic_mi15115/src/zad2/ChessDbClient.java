package zad2;

import javax.net.ssl.StandardConstants;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

final class ChessDbClient {
    public final static int PORT=1996;
    public static void main(String[] args) {

        System.out.println("Hello from ChessDbClient!");
        String name="localhost";
        try (Socket client=new Socket(name,PORT);
             BufferedReader ulaz=new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter out=new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
             BufferedReader in=new BufferedReader(new InputStreamReader(client.getInputStream(),StandardCharsets.UTF_8))){
            String zahtev;
            while(!(zahtev=ulaz.readLine()).equalsIgnoreCase("bye")) {
                System.out.println("jdl\nfs\n");
                out.write(zahtev);
                out.newLine();
                out.flush();

                System.out.println(in.readLine());
            }



        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

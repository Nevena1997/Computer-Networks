package zad2;

import java.lang.reflect.Array;
import java.util.ArrayList;

final class ChessPlayer {
    private Integer id;
    private String naziv;
    private Integer elo;

    private static Integer brojac=1;

    ChessPlayer(String ime){
        this.naziv=ime;
        this.elo=1300;
        this.id=brojac;
        brojac++;
    }
    public boolean provera(Integer i) {
        if (id==i)
            return true;
        return false;
    }

    @Override
    public String toString() {
        // naziv: elo
        return naziv+": "+elo;
    }

    public boolean namesti(Integer el) {
        this.elo+=el;
        return true;
    }


}

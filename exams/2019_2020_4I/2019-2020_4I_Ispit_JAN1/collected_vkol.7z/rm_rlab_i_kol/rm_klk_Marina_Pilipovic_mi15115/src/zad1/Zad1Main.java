package zad1;

import java.io.*;
import java.net.URL;

final class Zad1Main {
    public static void main(String[] args) {
        System.out.println("Hello from Zad1Main!");

        try(BufferedReader fajl=new BufferedReader(new InputStreamReader(new FileInputStream("urls.txt")))) {
            String red;
            Integer brojac=0;
            while((red=fajl.readLine())!=null) {
                brojac++;

                try {
                    URL url=new URL(red);

                }catch (Exception e) {
                    continue;
                }

            }
            System.out.println("lines: "+brojac);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

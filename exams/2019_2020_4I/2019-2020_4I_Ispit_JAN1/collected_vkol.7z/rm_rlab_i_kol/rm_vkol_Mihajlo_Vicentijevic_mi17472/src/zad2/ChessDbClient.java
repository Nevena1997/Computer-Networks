package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", ChessDbServer.DEFAULT_PORT)){
            try (Scanner sc = new Scanner(System.in);
                 BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                 BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()))){
                while (true){
                    System.out.print("> ");
                    String req = sc.next();
                    if(req.equals("sel")){
                        int id = sc.nextInt();

                        toServer.write(req + " " + id);
                        toServer.newLine();
                        toServer.flush();
                    }
                    else if(req.equals("ins")){
                        String naziv = sc.nextLine();

                        toServer.write(req + " " + naziv);
                        toServer.newLine();
                        toServer.flush();
                    }
                    else if(req.equals("upd")){
                        int id = sc.nextInt();
                        int elo = sc.nextInt();

                        toServer.write(req + " " + id + " " + elo);
                        toServer.newLine();
                        toServer.flush();
                    }
                    else if(req.equals("bye")){
                        toServer.write("bye");
                        toServer.newLine();
                        toServer.flush();
                        break;
                    }
                    else{
                        break;
                    }

                    String msg = fromServer.readLine().trim();
                    System.out.println(msg);
                }
            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}

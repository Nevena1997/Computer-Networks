package zad2;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;

    public ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    public void incElo(int elo) {
        this.elo += elo;
        if(this.elo < ChessDbServer.ELO_INIT){
            this.elo = ChessDbServer.ELO_INIT;
        }
    }

    @Override
    public String toString() {
        // naziv: elo
        return naziv + ": " + elo;
    }
}

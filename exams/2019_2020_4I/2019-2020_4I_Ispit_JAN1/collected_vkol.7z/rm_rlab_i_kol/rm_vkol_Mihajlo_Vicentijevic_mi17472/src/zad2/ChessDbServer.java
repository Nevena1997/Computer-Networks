package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;


final class ChessDbServer {

    public static final int DEFAULT_PORT = 1996;
    public static final int ELO_INIT = 1300;

    private static Map<Integer, ChessPlayer> players = new HashMap<>();
    public static int idCounter = 1;

    public static synchronized void insPlayer(String name){
        players.put(idCounter, new ChessPlayer(idCounter, name, ELO_INIT));
        idCounter++;
    }

    public static synchronized String selPlayer(int id){
        ChessPlayer player = players.get(id);
        if(player == null){
            return "Igrac ne postoji";
        }
        return player.toString();
    }

    public static synchronized int updPlayer(int id, int elo){
        ChessPlayer player = players.get(id);
        if(player == null){
            return -1;
        }

        player.incElo(elo);
        return 0;
    }

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){
            while(true){
                Socket client = server.accept();


                new ClientThread(client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

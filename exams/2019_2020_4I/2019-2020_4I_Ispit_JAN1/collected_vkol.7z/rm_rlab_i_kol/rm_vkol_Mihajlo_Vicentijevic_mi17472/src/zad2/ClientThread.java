package zad2;


import java.io.*;
import java.net.Socket;

final class ClientThread extends Thread {
    private Socket client;

    ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter toClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
            while(true) {
                String line = fromClient.readLine();
                System.err.println(line);
                String[] req = line.split(" ");

                if (req[0].equals("sel")) {
                    System.err.println("sel");
                    String retMsg = ChessDbServer.selPlayer(Integer.parseInt(req[1]));

                    toClient.write(retMsg);
                    toClient.newLine();
                    toClient.flush();
                }
                if (req[0].equals("ins")) {

                    String name = line.substring(4);
                    System.err.println("ins " + name);
                    ChessDbServer.insPlayer(name);

                    toClient.write("ins je uspesno izveden");
                    toClient.newLine();
                    toClient.flush();

                }
                if (req[0].equals("upd")) {
                    System.err.println("upd");
                    int ret = ChessDbServer.updPlayer(Integer.parseInt(req[1]), Integer.parseInt(req[2]));
                    String msg;
                    if(ret == -1){
                        msg = "Igrac ne postoji";
                    }
                    else{
                        msg = "upd je uspesno izvrsen";
                    }

                    toClient.write(msg);
                    toClient.newLine();
                    toClient.flush();

                }
                if(req[0].equals("bye")){
                    return;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

final class HTMLReaderThread extends Thread {

    private URL url;
    private String tag;
    private int tagCount;

    HTMLReaderThread(URL url, String tag) {
        this.url = url;
        this.tag = tag;
        this.tagCount = 0;
    }


    @Override
    public void run() {

        if(!Files.exists(Paths.get(url.getPath()))){
            System.out.println("not found:\t" + url.getPath());
            return;
        }


        try (BufferedReader fromURL = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8))){


            String line;
            while((line = fromURL.readLine()) != null){
                int index;
                do{
                    index = line.indexOf("<" + tag);
                    if(index != -1) {
                        line = line.substring(index + tag.length() + 1);
                        tagCount++;
                    }
                } while (index != -1);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

        Zad1Main.add(tagCount);
    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;
import java.util.Vector;

final class Zad1Main {

    public static final String DEFAULT_DIR = "/home/ispit/Desktop/tests";
    private static Vector<HTMLReaderThread> threads = new Vector<>();
    private static int numOfTag = 0;


    public static synchronized void add(int tagCount){
        numOfTag += tagCount;
    }

    public static void main(String[] args){

        String tag;
        try (Scanner sc = new Scanner(System.in)){
            tag = sc.next();
        }

        try (BufferedReader fromFile = new BufferedReader(new InputStreamReader(new FileInputStream(DEFAULT_DIR + "/urls.txt")))){

            int linesNum = 0;
            String line;
            while((line = fromFile.readLine()) != null){
                if(line.startsWith("file") && line.endsWith(".html")){
                    threads.add(new HTMLReaderThread(new URL(line.trim()), tag));
                }

                linesNum++;
            }

            System.out.println("lines:\t\t" + linesNum);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (HTMLReaderThread t : threads){
            t.start();
        }


        for(HTMLReaderThread t : threads){
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("result:\t\t" + numOfTag);




    }
}

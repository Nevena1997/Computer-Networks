package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.Scanner;

final class Zad1Main {
    public static void main(String[] args) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))) {
            int count = 0;
            String ln;
            int brojTagova = 0;
            while((ln = in.readLine()) != null){
                count++;
                if(!ln.contains("//"))
                    continue;
                URL u = new URL(ln.trim());
                if(ln.toLowerCase().startsWith("file") && ln.toLowerCase().endsWith(".html")){
                    URLConnection con = u.openConnection();
                    Scanner sc = new Scanner(System.in);
                    String tag = sc.next();
                    new Thread(new HTMLReaderThread(con, tag)).start();

                }
            }

            System.out.println("Lines: " + count);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

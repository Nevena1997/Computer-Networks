package zad1;

import java.io.*;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

final class HTMLReaderThread extends Thread {

    private URLConnection con;
    private String tag;

    public HTMLReaderThread(URLConnection con, String tag) {
        this.con = con;
        this.tag = tag;
    }

    @Override
    public void run() {
            try (BufferedReader b = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                String ln;
                int counter = 0;
                while((ln = b.readLine()) != null) {
                    if(ln.toLowerCase().contains(this.tag))
                        counter++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;

final class ChessDbServer {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(1996);
            while(true) {
                server.accept();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

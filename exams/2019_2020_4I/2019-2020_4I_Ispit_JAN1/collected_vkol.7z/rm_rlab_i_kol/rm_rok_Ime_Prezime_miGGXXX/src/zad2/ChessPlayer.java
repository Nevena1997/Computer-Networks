package zad2;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

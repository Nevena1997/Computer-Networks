package zad2;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) throws IOException {
        try {
            Socket klijent = new Socket(InetAddress.getLocalHost(), 1996);
            try (BufferedReader in = new BufferedReader(new InputStreamReader(System.in))) {
                try (BufferedOutputStream out = new BufferedOutputStream(klijent.getOutputStream())) {
                    byte[] buf = new byte[512];
                    int k;
                    while((k = in.read()) != 0)
                        out.write(buf, 0, k);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

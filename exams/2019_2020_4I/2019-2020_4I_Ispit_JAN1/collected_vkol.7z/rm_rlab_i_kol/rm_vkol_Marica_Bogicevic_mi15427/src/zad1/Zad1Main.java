package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Zad1Main {

    public static void main(String[] args) {

        int brLinija=0,br=0;
        String s=null;
        try {

            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")));
            System.out.print("Ulaz: ");
            Scanner sc = new Scanner(System.in);
            String niska =  '<' + sc.nextLine();
            String niska2=niska +">";

            String line = null;
            while ((line = in.readLine()) != null) {
                brLinija++;
                try {
                     URL u = new URL(line);
                     br=0;
                    if (u.getProtocol().equalsIgnoreCase("file") && line.contains(".html"))
                    {
                        URLConnection uc = u.openConnection();
                        System.out.print("izlaz: ");
                        System.out.println(u.getPath());
                       try(BufferedReader sadrzaj = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8)))
                       {
                        String q = null;
                        while ((q= sadrzaj.readLine()) != null) {
                           if (q.contains(niska) || q.contains(niska2))
                              br++;
                        }

                           System.out.println("result: " + br);
                           System.out.println("------------");

                        sc.close();
                        sadrzaj.close();
                    }

                    }


                } catch (MalformedURLException e) {

                   // line=in.readLine();
                    //e.printStackTrace();
                }catch(FileNotFoundException e)
                {
                    System.out.println("not found: ");
                    System.out.println("-------------");
                            //+ "result " + br);

                   // s=e.toString();
                    //e.printStackTrace();
                }
            }

           System.out.println("izlaz:  lines:" + brLinija + "\n" ); //+ br);

        in.close();
        }catch(IOException ex)
        {
            ex.printStackTrace();
        }


    }
}


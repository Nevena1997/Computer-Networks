package zad1;

final class ChessDbClient {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");
    }
}

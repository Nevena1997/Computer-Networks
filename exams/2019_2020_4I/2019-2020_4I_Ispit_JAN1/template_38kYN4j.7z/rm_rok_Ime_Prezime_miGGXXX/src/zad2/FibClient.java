package zad2;

final class FibClient {
    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");
    }
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

final class ChessDbServer {
    public static void main(String[] args) {
       // System.out.println("Hello from ChessDbServer!");
        ChessDbServer server = new ChessDbServer(1996);
        server.execute();
    }

    public int index = 0;
    private int port;
    private List<ChessPlayer> players = new LinkedList<>();

    ChessDbServer(int port){
        this.port = port;
    }

    void execute(){
        try(ServerSocket server = new ServerSocket(this.port)){
            while(true){
                Socket client = server.accept();
                new ClientThread(client,this).start();
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    void addPlayer(int index, String name, int eol){
        synchronized (players){
            players.add(index,new ChessPlayer(index,name,eol));
        }
    }

    ChessPlayer getPlayer(int idx) {
        if(idx >= players.size() || idx < 0)
            throw new IllegalArgumentException("ilegal index");
        return players.get(idx);
    }

    void changePlayer(int idx, int delta){
        if(idx >= players.size() || idx < 0)
            throw new IllegalArgumentException("ilegal index");
        players.get(idx).changeElo(delta);
    }
}

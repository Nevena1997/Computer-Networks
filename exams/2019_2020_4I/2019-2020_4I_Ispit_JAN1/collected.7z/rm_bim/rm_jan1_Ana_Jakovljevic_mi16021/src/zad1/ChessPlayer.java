package zad1;

final class ChessPlayer {
    int id;
    String naziv;
    int elo;

    ChessPlayer(int id, String naziv, int elo){
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return this.naziv + ": " + this.elo;
    }

    public int getId() {
        return id;
    }

    synchronized void changeElo(int delta){
        this.elo += delta;
    }

}

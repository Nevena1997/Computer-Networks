package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;


final class ClientThread extends Thread {
    // User thread for the ChessDbServer

    private Socket socket;
    private ChessDbServer server;
    ClientThread(Socket client, ChessDbServer server){
        this.socket = client;
        this.server = server;
    }

    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            PrintWriter out = new PrintWriter(this.socket.getOutputStream())){
            String line;
            while(true){
                line = in.readLine();
                if(line.equals("bye"))
                    break;
                if(line.startsWith("sel")){
                    int index = Integer.parseInt(line.substring(line.indexOf(' ') +1));
                    ChessPlayer player = this.server.getPlayer(index-1);
                    out.println(player);
                    out.flush();
                } else if (line.startsWith("ins")){
                    String name = line.substring(line.indexOf(' ') + 1);
                    this.server.addPlayer(this.server.index++,name,1300);
                    out.println("ins je uspesno izvrsen");
                    out.flush();
                } else if (line.startsWith("upd")){
                    Scanner sc = new Scanner(line);
                    sc.next();
                    int index = sc.nextInt();
                    int delta = sc.nextInt();
                    //int index = Integer.parseInt(line.substring(line.indexOf(' ') + 1));
                    //int delta = Integer.parseInt(line.substring(line.trim().lastIndexOf(' ')+1));
                    this.server.changePlayer(index-1, delta);
                    out.println("upd je uspesno izvrsen");
                    out.flush();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

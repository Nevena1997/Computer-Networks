package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        //System.out.println("Hello from FibClient!");
        try(DatagramSocket ds = new DatagramSocket();
            Scanner sc = new Scanner(System.in);
        ){
            InetAddress host = InetAddress.getByName("localhost");
            int num = sc.nextInt();

            ByteBuffer buffer = ByteBuffer.allocate(4);
            byte[] data = buffer.putInt(num).array();

            DatagramPacket request = new DatagramPacket(data, data.length, host, FibServer.PORT) ;
            ds.send(request);

            for(int i=0; i< num;i++){
                byte[] element = new byte[8];
                DatagramPacket response = new DatagramPacket(element,8);
                ds.receive(response);
                System.out.println(parse(response.getData()));
            }

        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public static long parse(byte[] data){
        ByteBuffer buffer = ByteBuffer.allocate(8);
        buffer.put(data);
        buffer.rewind();
        return  buffer.asLongBuffer().get();
    }

}

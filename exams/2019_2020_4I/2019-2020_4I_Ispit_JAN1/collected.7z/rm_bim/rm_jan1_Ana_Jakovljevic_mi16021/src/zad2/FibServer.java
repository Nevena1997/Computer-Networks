package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.LinkedList;
import java.util.List;

final class FibServer {
    public static final int PORT = 12345;

    private static List<Long> fib = new LinkedList<>();

    public static void main(String[] args) {
      //  System.out.println("Hello from FibServer!");
        fib.add(0,(long)1);
        fib.add(1,(long)1);
        try(DatagramSocket ds = new DatagramSocket(PORT)) {
            while (true){
                ByteBuffer buffer = ByteBuffer.allocate(4);
                DatagramPacket request = new DatagramPacket(buffer.array(), 4);
                ds.receive(request);

                if(request != null){
                    System.out.println("Stigao datagram!");
                }

                int num = buffer.asIntBuffer().get();
                buffer = ByteBuffer.allocate(8);
                for(int i=0;i < num;i++) {
                    if (fib.size() > i) {
                        buffer.putLong(fib.get(i)).array();
                    } else {
                        fib.add(i, fib.get(i - 1) + fib.get(i - 2));
                        buffer.putLong(fib.get(i)).array();
                    }
                    DatagramPacket dp = new DatagramPacket(buffer.array(), 8, request.getAddress(), request.getPort());
                    ds.send(dp);
                    buffer.clear();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

final class ChessDbServer {

    private List<ChessPlayer> players = Collections.synchronizedList(new LinkedList<>());

    public static void main(String[] args)
    {
        new ChessDbServer().execute();
    }

    private void execute()
    {
        try (ServerSocket server = new ServerSocket(1996))
        {
            //noinspection InfiniteLoopStatement
            while (true)
            {
                Socket client = server.accept();

                new ClientThread(client, this).start();
            }

        } catch (IOException e) {
            System.out.println("Server: IO greska...");
        }
    }

    synchronized String getId(int id)
    {
        for (ChessPlayer player : players) {
            if (player.getId() == id) {
                return player.toString();
            }
        }

        return "Ne postoji sahista sa rednim brojem " + id + " u tabeli";
    }

    synchronized void insertPlayer(String naziv)
    {
        ChessPlayer player = new ChessPlayer(naziv);
        players.add(player);
    }

    synchronized boolean setElo(int id, int deltae)
    {
        boolean found = false;
        for (ChessPlayer player : players) {
            if (player.getId() == id) {
                player.setElo(deltae);
                found = true;
                break;
            }
        }

        return found;
    }
}

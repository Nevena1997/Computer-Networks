package zad1;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;

    private static int identifikator = 1;

    ChessPlayer(String naziv)
    {
        this.naziv = naziv;
        this.id = identifikator++;
        this.elo = 1300;
    }

    int getId()
    {
        return id;
    }

    void setElo(int delta)
    {
        if (this.elo + delta < 1300)
            this.elo = 1300;
        else
            this.elo += delta;
    }

    @Override
    public String toString() {
        return naziv + ": " + elo;
    }
}

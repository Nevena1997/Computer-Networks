package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

final class ClientThread extends Thread {
    private BufferedReader fromUser;
    private BufferedWriter toUser;
    private ChessDbServer server;
    private Socket client;

    ClientThread(Socket client, ChessDbServer server)
    {
        this.server = server;
        this.client = client;
        try
        {
            this.fromUser = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.toUser = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        } catch (IOException e) {
            System.out.println("Nit: IO greska...");
        }
    }

    @Override
    public void run() {
        try {
            String request;
            while ((request = fromUser.readLine()) != null) {
                if (request.equalsIgnoreCase("bye"))
                    break;

                String[] parts = request.split(" ");
                switch (parts[0]) {
                    case "sel":
                        int id = Integer.parseInt(parts[1]);
                        String answer = server.getId(id);
                        this.toUser.write(answer);
                        this.toUser.newLine();
                        this.toUser.flush();
                        break;
                    case "ins":
                        int index = request.indexOf(" ");
                        server.insertPlayer(request.substring(index));
                        this.toUser.write("ins je uspesno izvrsen");
                        this.toUser.newLine();
                        this.toUser.flush();
                        break;
                    case "upd":
                        int i = Integer.parseInt(parts[1]);
                        int elo = Integer.parseInt(parts[2]);
                        boolean status = server.setElo(i, elo);
                        if (status)
                            this.toUser.write("upd je uspesno izvrsen");
                        else
                            this.toUser.write("Ne postoji sahista u tabeli pod brojem " + i);
                        this.toUser.newLine();
                        this.toUser.flush();
                        break;
                    default:
                        System.out.println("Ovo ne bi trebalo da se desi...");
                }
            }
        } catch (IOException e) {
            System.out.println("Nit - run: IO greska...");
        }

        try {
            this.fromUser.close();
            this.toUser.close();
            this.client.close();
        } catch (IOException e) {
            System.out.println("Nit: greska pri zatvaranju resursa...");
        }
    }
}

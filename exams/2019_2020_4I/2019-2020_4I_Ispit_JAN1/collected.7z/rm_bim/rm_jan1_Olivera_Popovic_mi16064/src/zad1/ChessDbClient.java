package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", 1996);
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             Scanner stdin = new Scanner(System.in))
        {
            String request;
            while (true)
            {
                request = stdin.nextLine();

                if (!isRequestGood(request))
                {
                    System.out.println("Zahtev nije dobro formiran...");
                    continue;
                }

                out.write(request);
                out.newLine();
                out.flush();

                if (request.trim().equalsIgnoreCase("bye"))
                    break;

                String serverResponse = in.readLine();
                System.out.println(serverResponse);
            }

        } catch (UnknownHostException e) {
            System.out.println("Klijent: Nepoznat host...");
        } catch (IOException e) {
            System.out.println("Klijent: IO greska...");
        }
    }

    private static boolean isRequestGood(String request)
    {
        String[] parts = request.split(" ");

        switch (parts[0])
        {
            case "bye": if (parts.length != 1) return false;
                        break;
            case "sel": if (parts.length != 2) return false;
                        try
                        {
                            Integer.parseInt(parts[1]);
                        } catch (NumberFormatException e)
                        {
                            return false;
                        }
                        break;
            case "ins": break;
            case "upd": if (parts.length != 3) return false;
                        try
                        {
                            Integer.parseInt(parts[1]);
                            Integer.parseInt(parts[2]);
                        } catch (NumberFormatException e)
                        {
                            return false;
                        }
                        break;
            default: return false;
        }

        return true;
    }
}

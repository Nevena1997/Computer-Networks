package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

final class FibServer {
    final private static Map<Integer, Long> fibNumbers = Collections.synchronizedMap(new HashMap<>());

    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(12345))
        {
            byte[] intBuffer = new byte[4];
            DatagramPacket received = new DatagramPacket(intBuffer, intBuffer.length);

            //noinspection InfiniteLoopStatement
            while (true)
            {
                server.receive(received);
                System.out.println("Stigao datagram!");

                ByteBuffer intHelper = ByteBuffer.wrap(received.getData());
                int arrived = intHelper.getInt();

                ByteBuffer longHelper = ByteBuffer.allocate(8);
                for (int i = 0; i < arrived; i++)
                {
                    longHelper.clear();
                    long number = getI(i);
                    longHelper.putLong(number);
                    longHelper.flip();

                    DatagramPacket toSendDP = new DatagramPacket(longHelper.array(), longHelper.array().length,
                                                            received.getAddress(), received.getPort());
                    server.send(toSendDP);
                }
            }
        } catch (SocketException e) {
            System.out.println("Server: soket greska...");
        } catch (IOException e) {
            System.out.println("Server: IO greska...");
        }
    }

    private static synchronized long getI(int i)
    {
        if (fibNumbers.containsKey(i))
            return fibNumbers.get(i);
        else
        {
            switch (i)
            {
                case 0: fibNumbers.put(0, 0L);
                        return 0L;
                case 1: fibNumbers.put(1, 1L);
                        return 1L;
                default: fibNumbers.put(i, (fibNumbers.get(i - 1) + fibNumbers.get(i - 2)));
                         return fibNumbers.get(i - 1) + fibNumbers.get(i - 2);
            }
        }
    }
}

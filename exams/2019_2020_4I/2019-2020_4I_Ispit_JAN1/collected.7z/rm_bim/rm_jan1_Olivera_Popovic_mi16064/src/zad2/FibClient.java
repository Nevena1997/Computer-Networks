package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in))
        {
            ByteBuffer intHelper = ByteBuffer.allocate(4);

            if (!sc.hasNextInt())
            {
                System.out.println("Na ulazu ne postoji broj...");
                System.exit(1);
            }

            int numToSend = sc.nextInt();
            intHelper.putInt(numToSend);
            intHelper.flip();
            byte[] buffer = intHelper.array();

            InetAddress address = InetAddress.getByName("localhost");
            DatagramPacket toSend = new DatagramPacket(buffer, buffer.length, address, 12345);

            client.send(toSend);

            byte[] longBuffer = new byte[8];
            DatagramPacket recv = new DatagramPacket(longBuffer, longBuffer.length);
            for (int i = 0; i < numToSend; i++)
            {
                client.receive(recv);

                intHelper.clear();
                intHelper = ByteBuffer.wrap(recv.getData());
                System.out.println(intHelper.getLong());
            }
        } catch (SocketException e) {
            System.out.println("Klijent: Soket greska...");
        } catch (UnknownHostException e) {
            System.out.println("Klijent: Nepoznat host...");
        } catch (IOException e) {
            System.out.println("Klijent: IO greska...");
        }

    }
}

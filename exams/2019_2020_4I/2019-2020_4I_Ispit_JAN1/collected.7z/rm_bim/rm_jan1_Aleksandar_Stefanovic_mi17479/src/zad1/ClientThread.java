package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

final class ClientThread extends Thread {

    private final BufferedReader bufferedReader;
    private final BufferedWriter bufferedWriter;

    private static final Map<Integer, ChessPlayer> playerMap = Collections.synchronizedMap(new HashMap<>());

    ClientThread(Socket clientSocket) throws IOException {
        this.bufferedReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
    }

    @Override
    public void run() {
        try {

            String receivedLine;
            do {
                receivedLine = bufferedReader.readLine();
                var scanner = new Scanner(receivedLine);
                var command = scanner.next();

                // Ovde bi lepo dosao jedan switch, ali ne mogu da ga koristim jer mi treba equalsIgnoreCase
                if ("sel".equalsIgnoreCase(command)) {
                    int id = scanner.nextInt();
                    var player = playerMap.get(id);
                    sendMessage(player != null ? player : "Ne postoji igrac sa id-jem " + id);
                } else if ("ins".equalsIgnoreCase(command)) {
                    String naziv = scanner.next();
                    var newPlayer = new ChessPlayer(naziv);
                    playerMap.put(newPlayer.getId(), newPlayer);
                    sendMessage("ins je uspesno izvrsen");
                } else if ("upd".equalsIgnoreCase(command)) {
                    int updId = scanner.nextInt();
                    int deltae = scanner.nextInt();
                    var updPlayer = playerMap.get(updId);
                    if (updPlayer != null) {
                        updPlayer.setElo(updPlayer.getElo() + deltae);
                        sendMessage("upd uspesno izvrsen");
                    } else {
                        sendMessage("Ne postoji igrac sa id-jem " + updId);
                    }
                } else {
                    sendMessage("Nije prepoznata komanda " + command);
                }
            } while (!receivedLine.equalsIgnoreCase("bye"));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedWriter.close();
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendMessage(Object message) throws IOException {
        bufferedWriter.write(message.toString());
        bufferedWriter.write("\n");
        bufferedWriter.flush();
    }



}

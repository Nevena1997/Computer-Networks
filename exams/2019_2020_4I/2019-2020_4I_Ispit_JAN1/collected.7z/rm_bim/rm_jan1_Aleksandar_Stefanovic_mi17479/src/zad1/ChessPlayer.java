package zad1;

final class ChessPlayer {

    private static int idCounter = 1;

    private final int id;
    private final String naziv;
    private int elo;

    ChessPlayer(String naziv) {
        this.id = idCounter++;
        this.naziv = naziv;
        this.elo = 1300;
    }

    int getId() {
        return id;
    }

    int getElo() {
        return elo;
    }

    void setElo(int elo) {
        this.elo = elo;
    }

    @Override
    public String toString() {
        return String.format("%s: %s", naziv, elo);
    }
}

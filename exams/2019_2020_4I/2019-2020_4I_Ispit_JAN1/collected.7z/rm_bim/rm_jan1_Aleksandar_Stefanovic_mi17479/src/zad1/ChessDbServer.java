package zad1;

import java.io.IOException;
import java.net.ServerSocket;

final class ChessDbServer {
    public static void main(String[] args) {
        try (var serverSocket = new ServerSocket(1996)) {
            //noinspection InfiniteLoopStatement
            while (true) {
                var socket = serverSocket.accept();
                System.out.println("Primljen klijent sa portom " + socket.getPort());
                var clientThread = new ClientThread(socket);
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

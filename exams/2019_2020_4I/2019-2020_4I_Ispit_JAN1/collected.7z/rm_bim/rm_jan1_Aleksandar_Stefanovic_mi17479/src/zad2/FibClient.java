package zad2;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {

        var scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        scanner.close();

        if (num < 0 || num > 80) {
            System.err.println("Broj mora biti pozitivan i manji od 80!");
        }

        var byteBuffer4 = ByteBuffer.allocate(4);
        byteBuffer4.putInt(num);
        var sendingPacket = new DatagramPacket(byteBuffer4.array(), 4);

        var receivingPacket = new DatagramPacket(new byte[8], 8);

        try (var datagramSocket = new DatagramSocket()) {
            sendingPacket.setSocketAddress(new InetSocketAddress(InetAddress.getLocalHost(), 12345));
            datagramSocket.send(sendingPacket);

            for (int i = 0; i < num; i++) {
                datagramSocket.receive(receivingPacket);
                var byteBuffer8 = ByteBuffer.wrap(receivingPacket.getData());
                long broj = byteBuffer8.getLong();
                System.out.println(broj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

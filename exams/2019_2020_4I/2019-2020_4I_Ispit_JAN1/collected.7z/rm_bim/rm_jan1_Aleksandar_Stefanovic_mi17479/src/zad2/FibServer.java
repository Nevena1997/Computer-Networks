package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.ArrayList;

final class FibServer {

    private static final ArrayList<Long> fibNumbers = new ArrayList<>(80);

    static {
        fibNumbers.add(0L);
        fibNumbers.add(1L);
    }

    public static void main(String[] args) {

        try (var socket = new DatagramSocket(12345)) {
            var receivingPacket = new DatagramPacket(new byte[4], 4);
            var sendingPacket = new DatagramPacket(new byte[8], 8);

            //noinspection InfiniteLoopStatement
            while (true) {
                socket.receive(receivingPacket);
                var receivingByteBuffer = ByteBuffer.wrap(receivingPacket.getData());

                int number = receivingByteBuffer.getInt();

                if (!(number < 0 || number > 80)) {
                    System.out.println("Stigao datagram!");
                } else {
                    System.err.printf("Stigao datagram sa neispravnim brojem %d!", number);
                    continue;
                }

                sendingPacket.setAddress(receivingPacket.getAddress());
                sendingPacket.setPort(receivingPacket.getPort());

                var byteBuffer = ByteBuffer.allocate(8);
                for (int i = 0; i < number; i++) {
                    long num = getFibNum(i);

                    byteBuffer.clear();
                    byteBuffer.putLong(num);

                    sendingPacket.setData(byteBuffer.array());
                    socket.send(sendingPacket);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static long getFibNum(int index) {
        // Based on a way this function is called, the body of this loop will execute either once or never, and in this
        // way it behaves like an 'if' statement, but it is worth keeping it this way, in case the way this function is
        // called changes.
        while (fibNumbers.size() <= index) {
            long a = fibNumbers.get(fibNumbers.size() - 2);
            long b = fibNumbers.get(fibNumbers.size() - 1);
            fibNumbers.add(a + b);
        }

        return fibNumbers.get(index);
    }
}

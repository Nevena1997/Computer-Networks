package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket()){
            Scanner sc = new Scanner(System.in);
            int num = sc.nextInt();
            if (num > 80) {
                return;
            }
            byte[] buff = new byte[4];
            InetAddress local = InetAddress.getLocalHost();
            DatagramPacket request = new DatagramPacket(buff, buff.length, local, 12345);
            request.setData((String.valueOf(num)).getBytes(StandardCharsets.US_ASCII));
            socket.send(request);

            byte[] respBuff = new byte[8];
            DatagramPacket response = new DatagramPacket(respBuff, respBuff.length);
            for (int i=0; i<num;i++) {
                socket.receive(response);
                ByteBuffer buf = ByteBuffer.wrap(respBuff);
                System.out.println("I got: " + buf.getLong());
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

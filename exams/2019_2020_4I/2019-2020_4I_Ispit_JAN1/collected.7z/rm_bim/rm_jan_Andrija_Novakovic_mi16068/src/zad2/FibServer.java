package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

final class FibServer {

    private DatagramSocket serverSocket;
    private int max = 80;
    private long[] fibs;

    private FibServer() throws SocketException {
        serverSocket = new DatagramSocket(12345);
        generateFibs();
    }

    private void generateFibs() {
        fibs = new long[80];
        fibs[0] = 0;
        fibs[1] = 1;
        for (int i = 2; i < max; i++) {
            fibs[i] = fibs[i-1] + fibs[i-2];
        }
    }

    private void start() {
        //noinspection InfiniteLoopStatement
        while (true) {
            try {
                byte[] buff = new byte[4];
                DatagramPacket request = new DatagramPacket(buff, buff.length);
                serverSocket.receive(request);
                System.out.println("New request is here");
                send(request);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void send(DatagramPacket request) throws IOException {
        int numOfNumbers = Integer.parseInt(new String(request.getData(), 0, request.getLength(), StandardCharsets.US_ASCII));
        if (numOfNumbers > 80) {
            return;
        }
        byte[] buff = new byte[8];
        DatagramPacket response = new DatagramPacket(
                buff, buff.length, request.getAddress(), request.getPort()
        );
        for (int i=0;i<numOfNumbers;i++) {
            ByteBuffer buf = ByteBuffer.allocate(8).putLong(fibs[i]);
            response.setData(buf.array());
            serverSocket.send(response);
        }

    }

    public static void main(String[] args) {
        try {
            FibServer server = new FibServer();
            server.start();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
}

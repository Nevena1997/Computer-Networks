package zad1;

import java.io.*;
import java.net.Socket;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer

    private Socket socket;
    private ChessDbServer server;
    private BufferedReader in;
    private PrintWriter out;

    ClientThread(Socket socket, ChessDbServer server) {
        try {
            this.server = server;
            this.socket = socket;
            in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {

        while(true) {

            try {
                String query = in.readLine();
                if (query == null) {
                    System.out.println("Null query");
                    in.close();
                    socket.close();
                    break;
                }
                if (query.equalsIgnoreCase("bye")) {
                    in.close();
                    socket.close();
                    break;
                }


                if(query.startsWith("ins")) {
                    String name = query.substring(4);
                    System.out.println("Ddoso je " + name);
                    boolean res = server.insert(name);
                    if (res)
                        System.out.println("Uspesno sam dodao: " + name);
                } else if (query.startsWith("sel")) {
                    String id = query.substring(4);
                    ChessPlayer selected = server.select(Integer.parseInt(id));
                    if (selected != null)
                        System.out.println(selected.toString());
                    else {
                        System.out.println("No such player");
                    }
                } else if (query.startsWith("upd")) {
                     String[] values = query.split(" ");
                     boolean updated = server.update(Integer.parseInt(values[1]), Integer.parseInt(values[2]));
                     if (updated) {
                         System.out.println("Uspesno izvrsen update");
                     }
                     else {
                         System.out.println("No such player");
                     }
                } else {
                    System.out.println("Bad query");
                }

            } catch (IOException e) {

                try {
                    in.close();
                    socket.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                e.printStackTrace();
            }

        }

    }
}

package zad1;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {

    public static void main(String[] args) {
        Socket socket = null;
        PrintWriter out = null;
        try {
            socket = new Socket("localhost", 1996);
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            while(true) {

                Scanner sc = new Scanner(System.in);
                String query = sc.nextLine();
                if (query.equalsIgnoreCase("bye")) {
                    System.out.println("About to send: " + query);
                    out.println(query);
                    out.flush();
                    out.close();
                    socket.close();
                    break;
                }
                System.out.println("About to send: " + query);

                out.println(query);
                out.flush();

            }
        } catch (IOException e) {
            if (out != null) {
                out.close();
            }
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        }

    }

}

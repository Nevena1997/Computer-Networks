package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

final class ChessDbServer {

    private ServerSocket serverSocket;
    private static int numPlayers;
    private static int DEF_PORT = 1996;
    private HashMap<Integer, ChessPlayer> table;

    private ChessDbServer() throws IOException {
        serverSocket = new ServerSocket(DEF_PORT);
        numPlayers = 1;
        table = new HashMap<>();
    }

    public static void main(String[] args) {
        try {
            ChessDbServer server = new ChessDbServer();
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void start() {

        //noinspection InfiniteLoopStatement
        while(true) {
            try {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client");
                ClientThread client = new ClientThread(clientSocket, this);
                client.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    synchronized boolean insert(String name) {
        table.put(numPlayers, new ChessPlayer(numPlayers, name, 1300));
        numPlayers++;
        return true;
    }

    ChessPlayer select(int id) {
        if (table.containsKey(id))
            return table.get(id);
        return null;
    }

    synchronized boolean update(int id, int delta) {
        if (table.containsKey(id)) {
            ChessPlayer player = table.get(id);
            player.setElo(delta);
            return true;
        }
        return false;
    }
}

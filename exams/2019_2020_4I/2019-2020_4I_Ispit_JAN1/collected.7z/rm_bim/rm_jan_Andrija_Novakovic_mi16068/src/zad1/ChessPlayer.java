package zad1;

final class ChessPlayer {
    // id
    // naziv
    // elo
    private Integer id;
    private String name;
    private int elo;

    ChessPlayer(Integer id, String name, int elo) {
        this.elo = elo;
        this.id = id;
        this.name = name;
    }

    public void setElo(int delta) {
        this.elo += delta;
    }

    public int getElo() {
        return this.elo;
    }

    @Override
    public String toString() {
        StringBuilder res = new StringBuilder("");
        res.append(this.name);
        res.append(": ");
        res.append(this.elo);
        return res.toString();
        // naziv: elo;
    }
}

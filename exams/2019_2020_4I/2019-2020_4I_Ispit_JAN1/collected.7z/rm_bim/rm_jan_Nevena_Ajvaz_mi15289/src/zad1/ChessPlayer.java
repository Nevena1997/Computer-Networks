package zad1;

final class ChessPlayer {

    public ChessPlayer(String sahista) {


    }

    // id
    // naziv
    // elo

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

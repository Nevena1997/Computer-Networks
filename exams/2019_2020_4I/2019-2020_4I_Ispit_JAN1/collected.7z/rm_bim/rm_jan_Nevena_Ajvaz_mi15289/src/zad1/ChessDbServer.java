package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;

final class ChessDbServer {
    public static void main(String[] args) {

        //System.out.println("Hello from ChessDbServer!");

        try (ServerSocket server = new ServerSocket(1996)){

            while (true) {


                Socket klijent = server.accept();

                ClientThread t = new ClientThread(klijent);
                t.start();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        //System.out.println("Hello from ChessDbClient!");
        try (Socket klijent = new Socket("localhost", 1996)){



            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            Scanner sc = new Scanner(System.in);
            while (sc.hasNext()){
                String x = sc.next();
                if(x.equalsIgnoreCase("bye"))
                    break;
                bw.write(x);
                bw.newLine();
                bw.flush();
            }



            sc.close();
            bw.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

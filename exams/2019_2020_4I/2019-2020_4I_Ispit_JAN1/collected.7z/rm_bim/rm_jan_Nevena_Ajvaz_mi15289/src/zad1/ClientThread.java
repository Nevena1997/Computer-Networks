package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

final class ClientThread extends Thread {

    private final Socket soc;
    private Set<ChessPlayer> skup = new HashSet<>();

    ClientThread(Socket soket) {
        this.soc = soket;
    }

    @Override
    public void run() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        String linija;
        while (true) {
            try {

                if (!((linija = br.readLine()) != null))
                    break;
                ChessPlayer sahista = new ChessPlayer(linija);
                skup.add(sahista);
                System.out.println(linija);


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    // User thread for the ChessDbServer
}

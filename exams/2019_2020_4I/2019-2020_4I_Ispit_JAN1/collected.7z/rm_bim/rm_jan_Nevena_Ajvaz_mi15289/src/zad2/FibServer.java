package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;

final class FibServer {
    public static void main(String[] args) {

        //System.out.println("Hello from FibServer!");

        try(DatagramSocket server = new DatagramSocket(12345)){

            byte[] bafer = new byte[4];
            DatagramPacket zahtev = new DatagramPacket(bafer, 4);
            server.receive(zahtev);
            System.out.println("Stigao datagram!");

            String primljeno = zahtev.getData().toString();

            //int n = Integer.parseInt(primljeno);

            // hardcode, TODO

            int n = 5;
            if (n < 0 || n > 80) {
                System.err.println("Broj n nije pravilno unesen!");
            }

            byte[] baf = new byte[8];
            int fib = fibonaci(n);
            byte fibZaSlanje = (byte)fib;
            for (int i = 0; i < n; i++) {
                Arrays.fill(baf, fibZaSlanje);
                DatagramPacket odgovor = new DatagramPacket(baf, 8, zahtev.getAddress(), zahtev.getPort());
                server.send(odgovor);
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int fibonaci(int n) {
        if(n == 0){
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        return fibonaci(n-1) + fibonaci(n-2);
    }
}

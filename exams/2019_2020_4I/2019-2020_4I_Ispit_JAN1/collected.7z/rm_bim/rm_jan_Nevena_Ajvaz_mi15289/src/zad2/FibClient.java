package zad2;

import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.Scanner;

final class FibClient {

    public static void main(String[] args) {

        //System.out.println("Hello from FibClient!");

        try(DatagramSocket soket = new DatagramSocket()){

            InetAddress adresa = InetAddress.getByName("localhost");
            byte[] bafer = new byte[4];

            Scanner sc = new Scanner(System.in);

            while (sc.hasNextByte()){
                Arrays.fill(bafer, sc.nextByte());
            }


            DatagramPacket zahtev = new DatagramPacket(bafer, 4, adresa, 12345);
            soket.send(zahtev);

            DatagramPacket odg = new DatagramPacket(bafer, 4);
            soket.receive(odg);

            System.out.println(odg.getData().toString());

            sc.close();
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }



}

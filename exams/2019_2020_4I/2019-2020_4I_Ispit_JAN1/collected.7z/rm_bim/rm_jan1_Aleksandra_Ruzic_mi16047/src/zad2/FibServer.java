package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;

final class FibServer {
    public static void main(String[] args) {
        System.out.println("Hello from FibServer!");

        try (DatagramSocket server = new DatagramSocket(12345)) {

            long[] fibNiz = new long[81];
            fibNiz[0] = 0; fibNiz[1] = 1;
            int maxNum = 2;
            while (true) {
                byte[] bytes = new byte[4];
                DatagramPacket dp = new DatagramPacket(bytes, bytes.length);
                server.receive(dp);
                System.out.println("Stigao datagram!");
                int num = ByteBuffer.wrap(bytes).getInt();
                byte[] sentBytes = new byte[16];
                ByteBuffer buf = ByteBuffer.allocate(16);
                if (num > maxNum) {

                    long fib = fibNiz[maxNum -1], prevFib = fibNiz[maxNum -2];
                    for (int i = 0; i < maxNum; i++) {

                        buf.putLong(fibNiz[i]);
                        buf.flip();
                        sentBytes = buf.array();
                        buf.clear();
                        DatagramPacket sentPacket = new DatagramPacket(sentBytes, sentBytes.length, dp.getAddress(), dp.getPort());
                        server.send(sentPacket);
                    }
                    for (int i = maxNum; i < num; i++) {

                        fibNiz[i] = fib + prevFib;
                        buf.putLong(fibNiz[i]);
                        buf.flip();
                        sentBytes = buf.array();
                        buf.clear();
                        DatagramPacket sentPacket = new DatagramPacket(sentBytes, sentBytes.length, dp.getAddress(), dp.getPort());
                        server.send(sentPacket);
                        prevFib = fib;
                        fib = fibNiz[i];
                    }
                    maxNum = num;
                } else {
                    for (int i = 0; i < num; i++) {

                        buf.putLong(fibNiz[i]);
                        buf.flip();
                        sentBytes = buf.array();
                        buf.clear();
                        DatagramPacket sentPacket = new DatagramPacket(sentBytes, sentBytes.length, dp.getAddress(), dp.getPort());
                        server.send(sentPacket);
                    }
                }
            }
        } catch (IOException e) {

            System.err.println("DatagramSocket u Server");
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");

        Scanner stdIn = new Scanner(System.in);
        int num = stdIn.nextInt();
        if (num > 80) {

            System.out.println("Ne moze veci broj od 80!");
        } else {

            try (DatagramSocket client = new DatagramSocket()) {

                DatagramPacket dp = new DatagramPacket(ByteBuffer.allocate(4).putInt(num).array(), 4, InetAddress.getByName("localhost"), 12345);
                client.send(dp);
                byte[] recBytes = new byte[8];
                for (int i = 0; i < num; i++) {

                    DatagramPacket recPacket = new DatagramPacket(recBytes, recBytes.length);
                    client.receive(recPacket);
                    System.out.println(ByteBuffer.wrap(recBytes).getLong());
                }
            } catch (IOException e) {

                System.err.println("DatagramSocket u Client");
            }
        }
    }
}

package zad1;

final class ChessPlayer {
    private int id = 0;
    private String naziv;
    private int elo;

    private static int nextId = 0;

    public ChessPlayer(String ime) {

        id = nextId;
        nextId++;
        naziv = ime;
        elo = 1300;
    }

    public int getId() {
        return id;
    }

    public String getNaziv() {
        return naziv;
    }

    public int getElo() {
        return elo;
    }

    public void setElo(int elo) {

        this.elo -= elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

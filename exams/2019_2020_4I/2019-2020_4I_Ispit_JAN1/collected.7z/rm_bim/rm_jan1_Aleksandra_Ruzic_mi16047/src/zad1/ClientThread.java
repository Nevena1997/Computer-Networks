package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

final class ClientThread extends Thread {
    private Socket client;

    public ClientThread (Socket sock) {

        client = sock;
    }

    @Override
    public void run() {

        try (Scanner fromClient = new Scanner(client.getInputStream());
             PrintWriter toClient = new PrintWriter(client.getOutputStream(), true)) {

            while (true) {
                String com = fromClient.nextLine();
                if (com.equalsIgnoreCase("bye")) {

                    break;
                }
                String action = com.substring(0, 4);
                if (action.equalsIgnoreCase("ins ")) {

                    String name = com.substring(4);
                    ChessPlayer cp = new ChessPlayer(name);

                    synchronized (this) {

                        ChessDbServer.mapOfPlayers.put(cp.getId(), cp);
                    }
                    toClient.println("ins je uspesno izvrsen");
                } else if (action.equalsIgnoreCase("sel ")) {

                    int id = Integer.parseInt(com.substring(4));
                    try {

                        synchronized (this) {

                            ChessPlayer cp = ChessDbServer.mapOfPlayers.get(id);
                            toClient.println(cp.getNaziv() + ": " + cp.getElo());
                        }
                    } catch (NullPointerException np) {

                        toClient.println("Ne postoji igrac sa tim indeksom");
                    }
                } else if (action.equalsIgnoreCase("upd ")) {

                    int id = Integer.parseInt(com.substring(4, com.lastIndexOf(' ')));
                    int newElo = Integer.parseInt(com.substring(com.lastIndexOf(' ') + 1));
                    synchronized (this) {

                        try {

                            ChessPlayer cp = ChessDbServer.mapOfPlayers.remove(id);
                            cp.setElo(newElo);
                            ChessDbServer.mapOfPlayers.put(cp.getId(), cp);
                        } catch (NullPointerException np) {


                            toClient.println("Ne postoji igrac sa tim indeksom");
                        }
                    }
                    toClient.println("upd je uspesno izvrsen");
                }
                 else {

                    toClient.println("Idiot");
                }
            }
        } catch (IOException e) {

            System.err.println("Scanner ili PrintWriter u ClientThread");
        }
    }

    // User thread for the ChessDbServer
}

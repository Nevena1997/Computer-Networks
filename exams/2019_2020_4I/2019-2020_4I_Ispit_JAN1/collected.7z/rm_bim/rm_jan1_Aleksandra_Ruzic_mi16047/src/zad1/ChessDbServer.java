package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

final class ChessDbServer {

    public static Map<Integer, ChessPlayer> mapOfPlayers = Collections.synchronizedMap(new HashMap<>());
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");

        Scanner stdIn = new Scanner(System.in);
        try (ServerSocket server = new ServerSocket(1996)) {

            while(true) {
                new ClientThread(server.accept()).start();
            }
        } catch (IOException e) {

            System.err.println("ServerSocket u Server");
        }
    }
}

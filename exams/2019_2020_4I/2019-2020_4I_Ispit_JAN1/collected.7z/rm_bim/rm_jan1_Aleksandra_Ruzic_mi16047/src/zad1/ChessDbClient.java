package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");
        Scanner stdIn = new Scanner(System.in);
        try (Socket client = new Socket("localhost", 1996);
            Scanner fromServer = new Scanner(client.getInputStream());
             PrintWriter toServer = new PrintWriter(client.getOutputStream(), true)) {

            do {

                String com = stdIn.nextLine();
                toServer.println(com);
                if(com.equalsIgnoreCase("bye")) {

                    break;
                }
                String result = fromServer.nextLine();
                System.out.println(result);
            } while (true);
            stdIn.close();
        } catch (IOException e) {

            System.err.println("Socket u Client");
        }
    }
}

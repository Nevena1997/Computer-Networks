package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

final class ChessDbServer {
    static Set<ChessPlayer> playersTable = Collections.synchronizedSet(new HashSet<>());
    static int id = 1;

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(1996)) {
            while (true) {
                Socket client = server.accept();
                new ClientThread(client).start();
                System.out.println("Klijent je stigao.");
            }
        } catch (IOException e) {
            System.err.println("Klijent je otisao.");
        }

    }
}

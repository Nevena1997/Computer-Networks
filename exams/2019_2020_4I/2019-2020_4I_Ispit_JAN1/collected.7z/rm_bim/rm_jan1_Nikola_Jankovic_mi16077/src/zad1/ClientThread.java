package zad1;

import java.io.*;
import java.net.Socket;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    private Socket clientSock;
    private BufferedReader in;
    private PrintWriter out;

    public ClientThread(Socket client) throws IOException {
        this.clientSock = client;
        this.in = new BufferedReader(new InputStreamReader(this.clientSock.getInputStream()));
        this.out = new PrintWriter(new OutputStreamWriter(this.clientSock.getOutputStream()), true);
    }

    @Override
    public void run() {
        try {
            while (true) {
                String query = this.in.readLine();
                System.err.println(query);
                if (query.matches("sel [0-9]+")) {
                    String[] queryParts = query.split(" ");
                    int id = Integer.parseInt(queryParts[1]);
                    boolean playerExists = false;
                    synchronized (ChessDbServer.playersTable) {
                        for (var player : ChessDbServer.playersTable)
                            if (player.id == id) {
                                this.out.println(player.toString());
                                playerExists = true;
                            }
                    }
                    if (!playerExists)
                        this.out.println("neispravan id");
                } else if (query.matches("ins [ A-Za-z]+")) {
                    String name = query.substring(query.indexOf(" ")+1);
                    synchronized (ChessDbServer.playersTable) {
                        ChessDbServer.playersTable.add(new ChessPlayer(ChessDbServer.id++, name, 1300));
                    }
                    this.out.println("ins je uspesno izvrsen");
                } else if (query.matches("upd [0-9]+ (-)?[0-9]+")) {
                    String[] queryParts = query.split(" ");
                    int id = Integer.parseInt(queryParts[1]);
                    int deltae = Integer.parseInt(queryParts[2]);
                    boolean playerExists = false;
                    synchronized (ChessDbServer.playersTable) {
                        for (var player : ChessDbServer.playersTable)
                            if (player.id == id) {
                                player.elo += deltae;
                                playerExists = true;
                            }
                    }
                    if (playerExists)
                        this.out.println("upd uspesno izvrsen");
                    else
                        this.out.println("neispravan id");
                } else this.out.println("los zahtev");
            }
        } catch (IOException e) {

            e.printStackTrace();
        } finally {
            try {
                this.in.close();
                this.out.close();
                this.clientSock.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 1996);
             Scanner sc = new Scanner(System.in);
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
             ) {
            String req_str;
            while (true) {
                req_str = sc.nextLine();
                if (req_str.equalsIgnoreCase("bye"))
                    break;
                out.println(req_str);
                System.out.println(in.readLine());
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

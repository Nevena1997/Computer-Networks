package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {
            int value = sc.nextInt();
            if (value >= 0 && value <= 80) {
                DatagramPacket request = new DatagramPacket(ByteBuffer.allocate(4).putInt(value).array(),
                        4, new InetSocketAddress(12345));
                socket.send(request);
                for (int i = 0; i < value; i++) {
                    byte[] respBuff = new byte[8];
                    DatagramPacket response = new DatagramPacket(respBuff, respBuff.length);
                    socket.receive(response);
                    System.out.println(ByteBuffer.wrap(respBuff).getLong());
                }
            } else
                System.err.println("Broj je izvan intervala [0-80]");

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

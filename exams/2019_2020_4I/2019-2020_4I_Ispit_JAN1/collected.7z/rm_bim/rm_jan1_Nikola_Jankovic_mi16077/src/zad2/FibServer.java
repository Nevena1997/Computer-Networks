package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Vector;

final class FibServer {
    static Vector<Long> bufferVec = new Vector();
    public static void main(String[] args) {
        bufferVec.add((long) 0);
        bufferVec.add((long) 1);
        try (DatagramSocket server = new DatagramSocket(new InetSocketAddress(12345))) {
            while (true) {
                byte[] recvBuffer = new byte[4];
                DatagramPacket request = new DatagramPacket(recvBuffer, recvBuffer.length);
                server.receive(request);
                System.out.println("Stigao paket");

                int value = ByteBuffer.wrap(request.getData()).getInt();
                System.err.println(value);


                long fn1 = 1;
                long fn = 1;
                for (int i = 0; i < value; i++) {
                    DatagramPacket dp;
                    if (0 == i || 1 == i)
                        dp = new DatagramPacket(ByteBuffer.allocate(8).putLong(i).array(), 8,
                                request.getAddress(), request.getPort());
                    else
                        dp = new DatagramPacket(ByteBuffer.allocate(8).putLong(fn).array(), 8,
                                request.getAddress(), request.getPort());
                    server.send(dp);

                    if (i > 1 && i < FibServer.bufferVec.size()) {

                        fn = bufferVec.elementAt(i);
                        fn1 = bufferVec.elementAt(i-1);
                    } else if (i > 1) {
                        long tmp = fn;
                        fn += fn1;
                        fn1 = tmp;
                        bufferVec.add(fn);
                    }

                }


            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

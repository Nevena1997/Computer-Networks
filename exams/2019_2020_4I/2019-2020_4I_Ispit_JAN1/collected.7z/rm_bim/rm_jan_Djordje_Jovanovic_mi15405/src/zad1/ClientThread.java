package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

final class ClientThread extends Thread {

    private Socket socket;
    private ChessDbServer server;

    // User thread for the ChessDbServer
    public ClientThread(Socket socket, ChessDbServer server) {
        this.socket = socket;
        this.server = server;
    }

    public void run() {
        try (BufferedReader fromClient = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter toClient = new PrintWriter(socket.getOutputStream(), true)) {

            while (true) {
                String message = fromClient.readLine();
                if (message == null) break;
                String command = message.substring(0, 2);

                if (command.equals("sel")) {
                    int id = Integer.valueOf(message.substring(4));
                    String response = this.server.selectPlayer(id);
                    toClient.println(response);
                } else if (command.equals("ins")) {
                    this.server.insertPlayer(message.substring(4));
                    toClient.println("ins je uspesno izvrsen.");
                } else if (command.equals("upd")) {
                    String[] str = message.split(" ");
                    int id = Integer.valueOf(str[1]);
                    int points = Integer.valueOf(str[2]);
                    this.server.updatePlayer(id, points);
                    toClient.println("upd je uspesno izvrsen");
                } else {
                    toClient.println("Nepostojeca komanda");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

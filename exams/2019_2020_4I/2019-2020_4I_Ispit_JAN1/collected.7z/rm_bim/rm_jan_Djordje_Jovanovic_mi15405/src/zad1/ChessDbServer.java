package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

final class ChessDbServer {

    public static final int PORT = 1996;
    public static int playerCount = 0;

    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");
        ChessDbServer chessServer = new ChessDbServer();

        try (ServerSocket server = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = server.accept();
                System.out.println("New client connected.");
                new ClientThread(socket, chessServer).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Map<Integer, ChessPlayer> players = new HashMap<>();

    public String selectPlayer(int id) {
        ChessPlayer player = players.get(id);
        if (player == null) return null;
        else return String.format("%s %d", player.getNaziv(), player.getElo());
    }

    public void insertPlayer(String name) {
        ChessPlayer player = new ChessPlayer(playerCount++, name, ChessPlayer.MIN_ELO);
        players.put(player.getId(), player);
    }

    synchronized public void updatePlayer(int id, int points) {
        ChessPlayer player = players.get(id);
        if (player == null) return;
        player.updateElo(points);
    }
}

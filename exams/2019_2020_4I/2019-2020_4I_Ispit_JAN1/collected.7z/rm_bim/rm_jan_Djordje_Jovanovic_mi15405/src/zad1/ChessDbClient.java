package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");

        try (
            Socket socket = new Socket("localhost", ChessDbServer.PORT);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter toServer = new PrintWriter(socket.getOutputStream(), true)) {

            Scanner sc = new Scanner(System.in);
            String command;
            do {
                command = sc.nextLine();
                if (command == null) {
                    break;
                }
                toServer.println(command);

                String response = fromServer.readLine();
                System.out.println(response);
            } while (!command.equals("bye"));

            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

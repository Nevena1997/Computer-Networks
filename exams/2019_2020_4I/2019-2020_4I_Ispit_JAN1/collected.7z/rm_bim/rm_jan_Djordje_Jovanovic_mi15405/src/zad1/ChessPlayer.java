package zad1;

final class ChessPlayer {
    // id
    // naziv
    // elo
    private int id;
    private String naziv;
    private int elo;
    public static final int MIN_ELO = 1300;

    public ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return String.format("%s: %d", this.naziv, this.elo);
    }

    public void updateElo(int points) {
        this.elo += points;
        if (this.elo < MIN_ELO) this.elo = MIN_ELO;
    }

    public int getId() {return this.id;}
    public String getNaziv() {return this.naziv;}
    public int getElo() {return this.elo;}
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");

        try (DatagramSocket socket = new DatagramSocket()) {
            Scanner sc = new Scanner(System.in);
            String number = sc.next();
            byte[] data = number.getBytes();

            InetAddress address = InetAddress.getLocalHost();
            DatagramPacket request = new DatagramPacket(data, data.length, address, FibServer.PORT);
            socket.send(request);

            final int SIZE = 8;
            byte[] fib = new byte[SIZE];
            DatagramPacket response = new DatagramPacket(fib, SIZE);

            while (true) {
                socket.receive(response);
                String responseStr = new String(response.getData(), 0, SIZE);
                System.out.println(responseStr);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;

final class FibServer {

    public static final int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from FibServer!");

        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            byte[] data = new byte[4];
            DatagramPacket request = new DatagramPacket(data, data.length);

            byte[] sendData = new byte[8];
            while (true) {
                socket.receive(request);
                System.out.println("Stigao datagram!");

                String numberStr = new String(request.getData(), 0, 4);
                int number = Integer.valueOf(numberStr);
                List<Integer> fibs = getFibs(number);
                for (Integer i : fibs) {
                    sendData = String.valueOf(i).getBytes();
                    DatagramPacket packet = new DatagramPacket(sendData, sendData.length, request.getAddress(), request.getPort());
                    socket.send(packet);
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static List<Integer> getFibs(int number) {
        int first = 0, second = 1;
        List<Integer> fibs = new LinkedList<>();
        fibs.add(first);
        fibs.add(second);
        for (int i = 0; i < number-2; i++) {
            int third = first + second;
            fibs.add(third);
            first = second;
            second = third;
        }
        return fibs;
    }
}

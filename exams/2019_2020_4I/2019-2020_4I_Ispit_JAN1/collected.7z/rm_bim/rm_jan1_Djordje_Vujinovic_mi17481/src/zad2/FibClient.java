package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static final int DEFAULT_PORT = 12345;


    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket()) {
            DatagramPacket request = new DatagramPacket(new byte[4],4, InetAddress.getByName("localhost"), DEFAULT_PORT);

            Scanner sc = new Scanner(System.in);
            String broj = sc.next();

            DatagramPacket response = new DatagramPacket(broj.getBytes(), broj.length());

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

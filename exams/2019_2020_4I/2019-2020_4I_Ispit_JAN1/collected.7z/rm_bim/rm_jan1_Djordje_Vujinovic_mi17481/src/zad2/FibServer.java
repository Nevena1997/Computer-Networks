package zad2;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;

final class FibServer {
    public static final int DEFAULT_PORT = 12345;

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(DEFAULT_PORT)) {
            DatagramPacket request = new DatagramPacket(new byte[4], 4, DEFAULT_PORT);

            String data = new String(request.getData(), StandardCharsets.UTF_8);

            if (data != null)
                System.out.println(data);
            
            int broj = ((int) data.charAt(0));

            int prvi = 0;
            int drugi = 1;
            Integer konacan = 0;
            String rez;
            for(int i = 2; i < broj; i++) {
                konacan = prvi + drugi;
                prvi = drugi;
                drugi = konacan;
                byte[] buf = konacan.toString().getBytes();
                DatagramPacket response = new DatagramPacket(buf, 8, request.getAddress(), request.getPort());
                socket.send(response);
                System.out.println(buf);
            }



            socket.receive(request);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

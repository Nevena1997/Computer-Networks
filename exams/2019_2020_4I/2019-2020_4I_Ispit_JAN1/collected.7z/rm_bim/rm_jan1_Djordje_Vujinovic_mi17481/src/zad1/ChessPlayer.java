package zad1;

final class ChessPlayer {
//    private static final int id;
//    private static final String naziv;
//    private static final int elo;

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

package zad1;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public final static int DEFAULT_PORT = 1996;

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("hostname",DEFAULT_PORT);
//            socket.connect();

            Scanner sc = new Scanner(System.in);

        }catch (IOException e) {
            e.printStackTrace();
        }

    }
}

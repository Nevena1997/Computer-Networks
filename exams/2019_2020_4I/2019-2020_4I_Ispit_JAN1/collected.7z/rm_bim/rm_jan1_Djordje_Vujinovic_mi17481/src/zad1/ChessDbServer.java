package zad1;

final class ChessDbServer {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");

    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

final class FibServer {
    private static int PORT=12345;
    private static long[] fibonacijevi=new long[80];
    public static void main(String[] args) {


        System.out.println("Hello from FibServer!");

        inicijalizuj_fibonacijeve();

        try(DatagramSocket server=new DatagramSocket(PORT)) {
            while(true) {
                byte[] buffer = new byte[4];
                DatagramPacket received = new DatagramPacket(buffer, buffer.length);
                server.receive(received);
                int n=Integer.parseInt(new String(received.getData(), 0, received.getLength(), StandardCharsets.UTF_8));

                if(n<80 && n>0) {
                    System.out.println("Stigao datagram!");

                    for (int i = 0; i < n; i++) {
                        byte[] bajt = Long.toString(fibonacijevi[i]).getBytes(StandardCharsets.UTF_8);
                        DatagramPacket send = new DatagramPacket(bajt, bajt.length, received.getAddress(), received.getPort());
                        server.send(send);
                    }
                }else{


                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void inicijalizuj_fibonacijeve() {
        fibonacijevi[0]=0;
        fibonacijevi[1]=1;
        fibonacijevi[2]=1;
        for(int i=3;i<80;i++){
            fibonacijevi[i] = fibonacijevi[i-1] + fibonacijevi[i-2];
        }
    }

}

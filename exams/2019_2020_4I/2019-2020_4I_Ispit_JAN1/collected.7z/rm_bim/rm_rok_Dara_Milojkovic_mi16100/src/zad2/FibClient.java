package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {


        System.out.println("Hello from FibClient!");
        try (DatagramSocket client=new DatagramSocket();
             Scanner sc=new Scanner(System.in)){

            int broj=sc.nextInt();

            byte buffer[]= Integer.toString(broj).getBytes(StandardCharsets.UTF_8);
            DatagramPacket send= new DatagramPacket(buffer, buffer.length,InetAddress.getByName("localhost"), 12345);
            client.send(send);



            for(int i=0;i<broj;i++) {

                byte buf[]= new byte[8];
                DatagramPacket received= new DatagramPacket(buf, buf.length);
                client.receive(received);
                String rec = new String(received.getData(), 0, received.getLength(), StandardCharsets.UTF_8);
                System.out.println(rec);

            }
        } catch (SocketException | UnknownHostException e) {

            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();
        }


    }
}

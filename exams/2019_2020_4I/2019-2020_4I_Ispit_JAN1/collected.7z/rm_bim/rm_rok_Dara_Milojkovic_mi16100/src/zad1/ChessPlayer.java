package zad1;

final class ChessPlayer {
    // id
    // naziv
    // elo

    private  int id;
    private  String naziv;
    private int elo;

    ChessPlayer(int id, String naziv, int elo){
        this.id=id;
        this.naziv=naziv;
        this.elo=elo;
    }
    public  int getId() {
        return id;
    }

    public int getElo() {
        return elo;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return this.naziv+": "+this.elo;
    }
}

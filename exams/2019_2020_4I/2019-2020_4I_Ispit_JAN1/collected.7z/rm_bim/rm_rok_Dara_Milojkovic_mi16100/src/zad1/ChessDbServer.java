package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

final class ChessDbServer {

    private static Set<ChessPlayer> lista=new HashSet<>(10);
    public static void main(String[] args) {


        System.out.println("Hello from ChessDbServer!");

        try(ServerSocket server=new ServerSocket(1996)){
            while (true){
                Socket client=server.accept();

                ClientThread ct=new ClientThread(server, client, lista.size()+1);
                ct.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public  static synchronized  void insertChessPlayer(int id, String naziv, int elo){
        for(ChessPlayer cp: lista){
            if(cp.getId()==id && cp.getElo()==elo && cp.getNaziv().equalsIgnoreCase(naziv)){
                System.out.println("Igrac vec postoji");
                return;
            }
        }

        lista.add(new ChessPlayer(id, naziv, elo));
        System.out.println("ins je uspesno izvrsen");
    }

    public static synchronized void writePlayerWithId(int id){
        ChessPlayer cpp=lista.stream().filter(cp->cp.getId()==id).findFirst().get();
        if(cpp==null){
            System.out.println("ne postoji igrac sa ovim id-jem");
        }
        else
            System.out.println(cpp);

    }

    public static synchronized  void changeEloWithChessPlayerId(int id, int elo){
        ChessPlayer cp= lista.stream().filter(tp->tp.getId()==id).findFirst().get();
        if (cp==null){
            System.out.println("upd nije nasao korisnika sa tim imenom");
        }else {
            cp.setElo(cp.getElo() + elo);
            System.out.println("upd je uspesno izvrsen");
        }
    }
}

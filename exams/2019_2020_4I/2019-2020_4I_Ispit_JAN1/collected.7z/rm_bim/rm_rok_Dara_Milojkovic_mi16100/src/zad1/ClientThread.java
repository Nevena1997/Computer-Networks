package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

final class ClientThread extends Thread {
    private ServerSocket server;
    private  Socket client;
    private  int i;
    ClientThread(ServerSocket server, Socket client, int i){
            this.server=server;
            this.client=client;
            this.i=i;
    }

    @Override
    public  void run(){
        while (true) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));

                String identifikacija = br.readLine().trim();

                String[] opt = identifikacija.split(" ");

                if (opt[0].equalsIgnoreCase("sel")) {

                    ChessDbServer.writePlayerWithId(Integer.parseInt(opt[1]));

                } else if (opt[0].equalsIgnoreCase("ins")) {

                    String ime= opt[1];

                    for(int i=2;i<opt.length;i++)
                        ime+=" "+opt[i];

                    ChessDbServer.insertChessPlayer(i++, ime, 1300);

                } else if (opt[0].equalsIgnoreCase("upd")) {

                    ChessDbServer.changeEloWithChessPlayerId(Integer.parseInt(opt[1]), Integer.parseInt(opt[2]));

                } else if(opt[0].equalsIgnoreCase("bye"))
                    break;
                else {
                    System.out.println("losa komanda");
                }


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    // User thread for the ChessDbServer
}

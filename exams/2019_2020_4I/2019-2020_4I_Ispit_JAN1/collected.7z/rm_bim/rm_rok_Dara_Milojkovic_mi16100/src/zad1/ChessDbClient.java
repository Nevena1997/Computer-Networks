package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        System.out.println("Hello from ChessDbClient!");

        try(Socket client=new Socket("localhost", 1996);
            Scanner sc=new Scanner(System.in)){

            PrintWriter pw=new PrintWriter(new BufferedOutputStream(client.getOutputStream()),true);
            String text;
            while (true){
                text=sc.nextLine();
                pw.println(text);
                if(text.equalsIgnoreCase("bye"))
                    break;


            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

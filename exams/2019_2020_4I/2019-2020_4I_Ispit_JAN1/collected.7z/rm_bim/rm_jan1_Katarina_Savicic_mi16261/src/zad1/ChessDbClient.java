package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {

    public static final int PORT = 1996;

    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");

        try(Socket client = new Socket("localhost", PORT))
        {

            String line;
            Scanner sc = new Scanner(System.in);
            line=sc.nextLine();
            while(!(line.equalsIgnoreCase("bye")))
            {
                BufferedWriter out = new BufferedWriter( new OutputStreamWriter(client.getOutputStream()));
                out.write(line);

                BufferedReader in = new BufferedReader( new InputStreamReader(client.getInputStream()));
                String rec;
                rec=String.valueOf(in.read());
                System.out.println(rec);

                line=sc.nextLine();
            }

            sc.close();


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

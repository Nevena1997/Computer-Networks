package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class ChessDbServer {


    public static int PORT = 1996;
   // public Map<Integer, ChessPlayer> table = new HashMap<>();





    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");

        List<Thread> niti = new ArrayList<>();

        try(ServerSocket server = new ServerSocket(PORT))
        {
            while(true)
            {
                Socket client = server.accept();

                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String rec;
                rec=String.valueOf(in.read());

                Thread nit = new ClientThread(rec);
                niti.add(nit);
                nit.start();

                /*for(int i = 0; i < niti.size(); i++)
                    niti.get(i).join();*/

            }


        } catch (IOException e) {
            e.printStackTrace();
        } /*catch (InterruptedException e) {
            e.printStackTrace();
        }*/


    }
}

package zad1;

import java.util.HashMap;
import java.util.Map;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer

    public Map<Integer, ChessPlayer> table = new HashMap<>();
    private static String line;
    public int maxIndex = 0;

    public ClientThread(String line) {
        this.line=line;

    }

    @Override
    public void run() {

        String [] niz = line.split(" ");
        if(niz[0].equals("sel"))
        {
            int id = Integer.parseInt(niz[1]);
            if(table.get(id) != null)
            System.out.printf(table.get(id).toString());
            else
                System.out.println("Nije dobar zahtev");
        }
        else if(niz[0].equals("ins"))
        {
            maxIndex+=1;
            ChessPlayer player = new ChessPlayer(maxIndex, niz[1], 1300);
            if((table.put(maxIndex, player))!=null)
                System.out.println("ins je buspesno izvrsen");
            else
                System.out.println("Nije dobar zahtev");
        }
        else if(niz[0].equals("upd"))
        {
            int id = Integer.parseInt(niz[1]);
            int delta = Integer.parseInt(niz[2]);

            if(table.get(id) != null) {
                table.get(id).setElo(delta);
                System.out.println("upd je uspesno izvrsen");
            }
            else
                System.out.println("Nije dobar zahtev");
        }
        else
            System.out.println("Nije dobar zahtev");



    }
}

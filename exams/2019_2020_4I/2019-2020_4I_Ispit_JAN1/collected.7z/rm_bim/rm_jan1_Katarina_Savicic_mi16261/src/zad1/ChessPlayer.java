package zad1;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;

    public ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    public void setElo(int delta) {
        this.elo += delta;
    }

    @Override
    public String toString() {
        // naziv: elo
        String data="";
        data.concat(naziv);
        data.concat(": ");
        data.concat(String.valueOf(elo));

        return data;
    }
}

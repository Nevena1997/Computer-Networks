package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Scanner;

final class FibClient {

    public static int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");


        try (DatagramSocket klijent = new DatagramSocket())
        {

            int  broj;
            Scanner sc = new Scanner(System.in);
            byte [] podaci = new byte[4];
            broj = sc.nextInt();

            if(broj>0) {

                DatagramPacket snd = new DatagramPacket(podaci, 4);
                snd.setData(new byte[]{Byte.parseByte(String.valueOf(broj))});
                //System.out.println(new byte[]{Byte.parseByte(String.valueOf(broj))});
                klijent.send(snd);
            }

            byte[] fib = new byte[8];
            DatagramPacket rec = new DatagramPacket(fib, 8);
            klijent.receive(rec);

            long fibBroj = Long.parseLong(String.valueOf(rec.getData()));
            System.out.println(fibBroj);

            sc.close();

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

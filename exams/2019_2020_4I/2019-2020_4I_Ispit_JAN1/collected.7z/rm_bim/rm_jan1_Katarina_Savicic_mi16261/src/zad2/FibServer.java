package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Arrays;

final class FibServer {

    public static int PORT = 12345;

    public static void main(String[] args) {

        System.out.println("Hello from FibServer!");


        try (DatagramSocket server = new DatagramSocket(PORT))
        {

            byte [] podaci = new byte[4];
            DatagramPacket rec= new DatagramPacket(podaci, 4);
            server.receive(rec);
            if(rec.getData()!=null)
                System.out.println("Stigao datagram!");

            int n = Integer.parseInt(String.valueOf(rec.getData()));
            long prvi=0;
            long drugi=1;
            long treci;

            Long[] fibBrojevi=new Long[80];
            for(int i =0; i<80; i++) {
                treci = prvi + drugi;
                prvi = drugi;
                drugi = treci;
                fibBrojevi[i] = treci;
            }

            for(int i =-0; i<n; i++)
            {
                byte [] fib = new byte [8];
                DatagramPacket snd = new DatagramPacket(fib, 8, rec.getAddress(), rec.getPort());
                snd.setData(new byte[]{Byte.parseByte(String.valueOf(fibBrojevi[i]))});
                server.send(snd);
            }



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

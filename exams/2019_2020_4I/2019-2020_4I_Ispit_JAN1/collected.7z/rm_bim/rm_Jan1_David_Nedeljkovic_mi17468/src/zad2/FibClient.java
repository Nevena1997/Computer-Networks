package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

import static zad2.FibServer.*;

final class FibClient {
    public static void main(String[] args) throws UnknownHostException {
        System.out.println("Hello from FibClient!");

        InetAddress addr = InetAddress.getByName("localhost");

        try(DatagramSocket db = new DatagramSocket();
            Scanner sc = new Scanner(System.in)) {

            System.out.println("Unesi pozitivan ceo broj:");
            int broj = sc.nextInt();
            if (broj > 80) {
                System.out.println("Nevalidan unos.");
                System.exit(-1);
            }
            String brojStr = Integer.toString(broj);

            DatagramPacket request = new DatagramPacket(
                    brojStr.getBytes(),brojStr.length(), addr, NUM_PORT);

            db.send(request);

            for (int i = 0; i < broj ; i++) {
                DatagramPacket response = new DatagramPacket(new byte[8], 8);
                db.receive(response);

                byte[] paket = response.getData();
                ByteBuffer buf = ByteBuffer.wrap(paket);
                System.out.println(buf.getLong());
            }


        }catch (SocketException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

}

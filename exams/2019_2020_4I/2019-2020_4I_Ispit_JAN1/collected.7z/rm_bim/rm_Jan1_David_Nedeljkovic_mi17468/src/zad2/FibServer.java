package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;


final class FibServer {
    public static final int NUM_PORT = 12345;

    public static void main(String[] args)
    {
        System.out.println("Hello from FibServer!");

        try(DatagramSocket server = new DatagramSocket(NUM_PORT)) {
            DatagramPacket request = new DatagramPacket(new byte[4], 4);

            server.receive(request);
            if (request.getData() != null) {
                System.out.println("Stigao datagram.");
            }
            String broj = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
            int number = Integer.valueOf(broj);
            // 7
            // 0 1 1 2 3 5 8

            LinkedList<Integer> lista = new LinkedList<>();
            lista.add(0);
            lista.add(1);
            for (int i = 2; i < number; i++) {
                int noviBroj = lista.get(i-1) + lista.get(i-2);
                lista.add(i, noviBroj);
            }

            for (int i = 0; i < lista.size(); i++) {
                String numStr = Integer.toString(lista.get(i));
                ByteBuffer buff = ByteBuffer.allocate(8);
                buff.put(numStr.getBytes());
                byte[] numByte = buff.array();
                DatagramPacket response = new DatagramPacket(numByte,numByte.length,request.getAddress(),request.getPort());
                server.send(response);
            }

        }catch (SocketException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

final class ChessDbServer {

    public static final int NUM_PORT = 1996;

    public static void main(String[] args)
    {

        try(ServerSocket server = new ServerSocket(NUM_PORT)) {
            System.out.println("Server pokrenut...");

            while (true) {
                try{
                    Socket client = server.accept();
                    new ClientThread(client).start();

                }catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Hello from ChessDbServer!");
    }
}

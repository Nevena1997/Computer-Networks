package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args)
    {

        try(Socket client = new Socket("localhost", ChessDbServer.NUM_PORT)) {

            Scanner sc = new Scanner(System.in);
            BufferedWriter buffWrite = new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream(), StandardCharsets.UTF_8
                    )
            );
            BufferedReader buffRead = new BufferedReader(
                    new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8)
            );

            while (true) {
                String zahtev = sc.nextLine();
                if(zahtev.equalsIgnoreCase("bay")) {
                    break;
                }
                buffWrite.write(zahtev);
                buffWrite.newLine();
                buffWrite.flush();

                System.out.println(buffRead.readLine());
            }

            buffWrite.close();
            buffRead.close();
            sc.close();

        }catch (UnknownHostException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Hello from ChessDbClient!");
    }
}

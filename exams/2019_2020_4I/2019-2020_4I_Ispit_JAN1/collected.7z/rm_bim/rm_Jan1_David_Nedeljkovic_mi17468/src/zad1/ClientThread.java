package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

final class ClientThread extends Thread {

    private Socket client;

    public ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try(BufferedReader buffRead = new BufferedReader(
                new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8)
        );
            BufferedWriter buffWrite = new BufferedWriter(
                    new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8)
            )) {

            String linija;
            while ((linija = buffRead.readLine()) != null) {
                buffWrite.write("Uspeno je primljen zahtev.");
                buffWrite.newLine();
                buffWrite.flush();
            }

        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    // User thread for the ChessDbServer
}

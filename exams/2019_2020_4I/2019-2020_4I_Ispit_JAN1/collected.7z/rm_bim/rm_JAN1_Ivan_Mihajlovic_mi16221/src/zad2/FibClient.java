package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

import static java.lang.System.in;

final class FibClient {
    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");
        InetAddress host = InetAddress.getLoopbackAddress();
        try(DatagramSocket socket = new DatagramSocket()) {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            String number = in.readLine();


            byte[] buff =  number.getBytes();
            int broj = Integer.valueOf(number);
            if (broj <= 0 || broj >80){
              System.err.println("Neispavan unos");
            System.exit(1);
            }

            DatagramPacket send =  new DatagramPacket(buff, buff.length, host, FibServer.DEFAULT_PORT);
            socket.send(send);

            for (int i=0; i<broj; i++) {
                DatagramPacket receive = new DatagramPacket(new byte[8], 8);
                socket.receive(receive);
                ByteBuffer buf = ByteBuffer.wrap(receive.getData());
                long x = buf.getLong();
                System.out.println(x);

            }
            in.close();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

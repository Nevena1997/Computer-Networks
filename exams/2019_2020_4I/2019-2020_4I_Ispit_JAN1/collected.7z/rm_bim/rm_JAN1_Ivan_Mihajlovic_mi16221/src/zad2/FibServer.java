package zad2;

import javax.xml.crypto.Data;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

final class FibServer {
    public static final int DEFAULT_PORT = 12345;
    public static void main(String[] args) {

        System.out.println("Hello from FibServer!");
        long[] fibonacijev = new long[80];
        fibonacijev[0] = 1;
        fibonacijev[1] = 1;
        for (int i=2; i<80; i++){
            fibonacijev[i] = fibonacijev[i-1] + fibonacijev[i-2];
        }

        try(DatagramSocket server = new DatagramSocket(DEFAULT_PORT)){
            while (true) {
                DatagramPacket request = new DatagramPacket(new byte[4], 4);
                server.receive(request);
                if (request.getData() != null) {
                    System.out.println("Stigao datagram!");
                }

                String number = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);

                int broj = Integer.valueOf(number);

                for (int i=0;i<broj; i++) {
                    ByteBuffer buf = ByteBuffer.allocate(8);
                    buf.putLong(fibonacijev[i]);
                    //String fib = String.valueOf(fibonacijev[i]);
                    //byte[] buff1 = new byte[8];
                   // byte[] buff = fib.getBytes();

                    DatagramPacket response = new DatagramPacket(buf.array(), buf.array().length, request.getAddress(), request.getPort());
                    server.send(response);

                }

            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;

final class ChessDbServer {
    public static final int DEFAULT_PORT = 1996;
    public static void main(String[] args) {

        System.out.println("Hello from ChessDbServer!");

        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)) {
            server.accept();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.Socket;

final class ChessDbClient {
    public static void main(String[] args) {
        String host = "localhost";
        System.out.println("Hello from ChessDbClient!");
        try (Socket client = new Socket(host, ChessDbServer.DEFAULT_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(System.in))){
            String line;
            while((line = in.readLine()) != null){
                if (line.trim().equalsIgnoreCase("bye")){
                    break;
                }
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                out.write(line);
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

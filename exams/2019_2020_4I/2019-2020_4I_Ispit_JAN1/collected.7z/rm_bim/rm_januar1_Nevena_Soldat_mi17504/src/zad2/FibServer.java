package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

final class FibServer {
    public static final int PORT = 12345;

    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket(PORT))
        {
            while(true)
            {
                DatagramPacket buf = new DatagramPacket(new byte[4], 4);
                socket.receive(buf);
                String received = new String(buf.getData(), 0, buf.getLength());
                if(received != null)
                {
                    System.out.println("Stigao datagram!");
                }

                Integer n = Integer.valueOf(received);
                int[] fibArray = fibonnaci(n);

                for(int i = 0; i < n; i++)
                {
                    Integer num = fibArray[i];
                    byte[] bytes = num.toString().getBytes();

                    DatagramPacket send = new DatagramPacket(bytes, bytes.length ,buf.getAddress(), buf.getPort());
                    socket.send(send);
                }

            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }


    }

    public static int[] fibonnaci(int n)
    {
        int[] array = new int[n];
        array[0] = 0;
        array[1] = 1;
        for(int i = 2; i < n; i++)
            array[i] = array[i-1] + array[i-2];
        return array;
    }

}

package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

final class FibClient {

    public static void main(String[] args) throws IOException {

            InetAddress addr = InetAddress.getLocalHost();

            Scanner sc = new Scanner(System.in);
            Integer number = sc.nextInt();
            if(number > 80)
            {
                System.err.println("Nedopustiva vrednost broja.");
                System.exit(1);
            }

            byte[] buf;
            buf = number.toString().getBytes();
            try(DatagramSocket client = new DatagramSocket())
            {

                DatagramPacket request = new DatagramPacket(buf, buf.length, addr, FibServer.PORT);
                client.send(request);
                for(int i = 0; i < number; i++)
                {
                    byte[] rec = new byte[8];
                    DatagramPacket receive = new DatagramPacket(rec, rec.length);
                    client.receive(receive);
                    String received = new String(receive.getData(), 0, receive.getLength());
                    System.out.println(received);

                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            finally {
                sc.close();
            }




    }
}

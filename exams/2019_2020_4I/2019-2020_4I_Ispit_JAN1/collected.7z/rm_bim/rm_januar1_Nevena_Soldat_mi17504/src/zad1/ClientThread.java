package zad1;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
}

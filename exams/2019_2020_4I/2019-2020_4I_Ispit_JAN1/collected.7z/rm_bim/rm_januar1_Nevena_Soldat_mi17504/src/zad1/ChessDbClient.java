package zad1;

import java.io.IOException;
import java.net.Socket;

final class ChessDbClient {
    public static void main(String[] args) {
        try (Socket sock = new Socket("localhost", 1996)){
            while(true)
            {

            }

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

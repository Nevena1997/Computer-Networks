package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");
        String host = "localhost";
        int port = 1996;
        try(Socket client = new Socket(host, port); Scanner sc = new Scanner(System.in);
            PrintWriter out =new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))){
            String line;


            while(true){
                line = sc.nextLine().trim();


                out.write(line);
                out.println();
                out.flush();

                if(line.equalsIgnoreCase("bye")){
                    break;
                }

                String result;
                result = in.readLine();
                if(result != null)
                    System.out.println(result);

            }

        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

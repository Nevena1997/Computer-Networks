package zad1;

import java.io.*;
import java.net.Socket;
import java.text.ParseException;
import java.util.LinkedList;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    private Socket socket;
    private LinkedList<ChessPlayer> players;

    ClientThread(Socket socket,  LinkedList<ChessPlayer>  players){
        this.socket = socket;
        this.players = players;
    }
    @Override
    public void run(){
        PrintWriter out = null;
        BufferedReader in = null;

        try{
            out = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line;
            while(true){
                line = in.readLine();
                if(line.equals("bye")){
                    break;
                }
                String result = "";
                if(line.startsWith("ins")){
                    result = insertPlayer(line);
                }else if(line.startsWith("sel")){
                    result = selPlayer(line);
                }else if(line.startsWith("upd")){
                    result = updPlayer(line);
                }else{
                    result = "Ne znam sta treba da pise ako je netacno";
                }

                out.println(result);
                out.flush();
            }
            /*socket.close();
            in.close();
            out.close();*/
        }catch (IOException ex){
            ex.printStackTrace();
        }finally {
            if(in != null){
                try{
                    in.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            if(out != null){
                out.close();
            }

            if(socket != null){
                try{
                    socket.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    }

    private String updPlayer(String line) {
        String afterUpd = line.substring(line.indexOf(' ')).trim();
        String iD = afterUpd.substring(0, afterUpd.indexOf(' ')).trim();
        String delt = afterUpd.substring(afterUpd.indexOf(' ')).trim();
        int id = Integer.parseInt(iD)-1;
        int delta = Integer.parseInt(delt);
        synchronized (players){
            ChessPlayer player = players.get(id);
            int elo = player.getElo();
            if(elo+delta < 0){
                player.setElo(1300);
            }else {
                player.setElo(elo + delta);
            }
        }
        return "upd je uspesno izvrsen";
    }

    private String selPlayer(String line) {
        String iD = line.substring(line.indexOf(' ')).trim();
        int id = Integer.parseInt(iD) - 1;

        String result="";
        synchronized (players){
            ChessPlayer player = players.get(id);
            result = player.toString();

        }
        return result;
    }

    private String insertPlayer(String line) {
        String naziv = line.substring(line.indexOf(' '));
        synchronized (players){
            int broj = players.size();
            ChessPlayer player = new ChessPlayer(broj, naziv, 1300);
            players.add(broj, player);

        }
        return "ins je uspesno izvrsen";
    }
}

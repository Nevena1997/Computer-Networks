package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.SynchronousQueue;


final class ChessDbServer {
    public static void main(String[] args) {
        //Tabela ima kolone:id (int),naziv (String)i elo (int)
        System.out.println("Hello from ChessDbServer!");
       // SynchronousQueue<ChessPlayer> players = new SynchronousQueue<>();
        //players.
        //LinkedBlockingQueue<ChessPlayer> players = new LinkedBlockingQueue<>();

        LinkedList<ChessPlayer> players = new LinkedList<ChessPlayer>();

        try(ServerSocket server = new ServerSocket(1996)){
            while(true){
                try {
                    Socket client = server.accept();
                    System.out.println("Primljen klijent " + client.getLocalAddress());
                    new ClientThread(client, players).start();

                }catch (IOException e){
                    e.printStackTrace();
                }
                /*
                Provera komunikacije izmedju servera i klijenta
                Socket client = server.accept();
                try{
                    PrintWriter out = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    String line;
                    while( (line=in.readLine()) != null){
                        System.out.println(line);
                    }

                }catch (IOException e){
                    e.printStackTrace();
                }*/
            }
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

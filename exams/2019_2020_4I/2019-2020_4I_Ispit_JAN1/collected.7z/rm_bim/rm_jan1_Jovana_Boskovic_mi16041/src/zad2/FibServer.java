package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

final class FibServer {
    public static void main(String[] args) {
        System.out.println("Hello from FibServer!");
        ArrayList fib = new ArrayList(80);
        for(int i=0; i<80; i++)
            fib.add(0);
        try(DatagramSocket server = new DatagramSocket(12345)){
            byte[] buffer = new byte[4];
            DatagramPacket receive= new DatagramPacket(buffer, buffer.length);
            while(true) {
                server.receive(receive);
                String line = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
                int n = Integer.parseInt(line);
                System.out.println("Stigao datagram");

                ByteBuffer buf = ByteBuffer.allocate(8);
                DatagramPacket send = new DatagramPacket(buf.array(), 8, receive.getAddress(), receive.getPort());
                int first = 1;
                int second = 1;
                int tmp;
                int count=0;
                while (count!=n) {
                    buf.putInt(first);
                    buf.flip();
                    tmp = second;
                    second = first + second;
                    first = tmp;
                    count++;
                    server.send(send);
                    buf.clear();
                }
            }

        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

package zad2;

import com.sun.jdi.ByteType;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {

        System.out.println("Hello from FibClient!");
        InetAddress host = InetAddress.getLoopbackAddress();
        int port = 12345;
        try(DatagramSocket client = new DatagramSocket(); Scanner sc = new Scanner(System.in)){
            int num = sc.nextInt();
            String number = Integer.toString(num);
            DatagramPacket send = new DatagramPacket(number.getBytes(), number.getBytes().length, host, port );
            client.send(send);

            ByteBuffer buf = ByteBuffer.allocate(8);
            DatagramPacket receive = new DatagramPacket(buf.array(), buf.array().length);
            buf.clear();
            while(num>0){
                client.receive(receive);
                buf.flip();
                num--;
                String line = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
                System.out.println(line);
                buf.clear();
            }

        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

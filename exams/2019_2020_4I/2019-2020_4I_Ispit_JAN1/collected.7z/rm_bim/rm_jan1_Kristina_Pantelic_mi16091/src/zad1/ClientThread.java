package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

final class ClientThread extends Thread {
    private Socket soket;
    private ChessDbServer server;
    public static Map<Integer, ChessPlayer> mapa = new HashMap<>();
    public ClientThread(Socket client, ChessDbServer chessDbServer, Map<Integer, ChessPlayer> mapa) {
        this.soket = client;
        this.server = chessDbServer;
        this.mapa = mapa;
    }
    // User thread for the ChessDbServer

    @Override
    public void run() {
            try(BufferedReader fromUser = new BufferedReader(new InputStreamReader(this.soket.getInputStream()));
                PrintWriter toUser = new PrintWriter(this.soket.getOutputStream(), true)) {
                while(true) {
                    String receive = fromUser.readLine();
                    if (receive == null)
                        break;
                    String[] rastavi = receive.split(" ");
                    if (rastavi[0].equalsIgnoreCase("sel") && rastavi.length == 2) {
                        int id = Integer.parseInt(rastavi[1]);
                        synchronized (this.mapa) {
                            if (mapa.containsKey(id)) {
                                toUser.println(mapa.get(id).toString());
                            } else {
                                toUser.println("ne postoji takav klijent");
                            }
                        }
                    } else if (rastavi[0].equalsIgnoreCase("ins")) {
                        int pos = receive.indexOf(" ");
                        String naziv = receive.substring(pos+1);
                        synchronized (this.mapa){
                            int global_br = this.mapa.size() + 1;
                            ChessPlayer novi = new ChessPlayer(naziv, global_br, 1300);
                            mapa.put(global_br, novi);
                            toUser.println("ins je uspesno izvrsen");
                        }
                    } else if (rastavi[0].equalsIgnoreCase("upd") && rastavi.length == 3) {
                        int id = Integer.parseInt(rastavi[1]);
                        int deltae = Integer.parseInt(rastavi[2]);
                        synchronized (this.mapa) {
                            ChessPlayer player = mapa.get(id);
                            int elo = player.getElo();
                            player.setElo(deltae + elo);
                            mapa.replace(id, player);
                            toUser.println("upd je uspesno izvrsen");
                        }
                    } else {
                        toUser.println("neispravna operacija");
                    }
                }
            } catch (IOException e) {
                try {
                    this.soket.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                e.printStackTrace();
            }
        }
}

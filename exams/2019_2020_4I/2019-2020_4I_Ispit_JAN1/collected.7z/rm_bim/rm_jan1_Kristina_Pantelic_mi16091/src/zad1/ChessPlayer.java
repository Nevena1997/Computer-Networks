package zad1;

final class ChessPlayer {
    // id
    // naziv
    // elo
    int id;
    String naziv;
    int elo;

    public ChessPlayer(String naziv, int id, int i) {
        this.naziv = naziv;
        this.elo = i;
        this.id = id;

    }
    public void setElo(int elo) {
        this.elo = elo;
    }

    public int getElo() {
        return elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return naziv + ": " + elo;
    }


}

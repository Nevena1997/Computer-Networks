package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.Scanner;

final class FibClient {
    private int port;
    private String host;
    private InetAddress address;
    public FibClient(int i) {
        this.port = i;
        this.host = "localhost";
        try {
            this.address = InetAddress.getByName(this.host);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        //System.out.println("Hello from FibClient!");
        FibClient client = new FibClient(12345);
        client.execute();

    }

    private void execute() {

        try(DatagramSocket client = new DatagramSocket()) {
            try(Scanner sc = new Scanner(System.in)) {
                while(sc.hasNextInt()){
                    int in = sc.nextInt();
                    if (in < 0 || in > 80)
                        continue;
                    //byte[] buf = Integer.toString(in).getBytes();
                    ByteBuffer buf = ByteBuffer.allocate(4);
                    buf.putInt(in);
                    //System.err.println(buf.array().length);
                    byte[] buf2 = new byte[8];
                    DatagramPacket toSend = new DatagramPacket(buf.array(), buf.array().length, this.address, this.port);
                    client.send(toSend);

                    for (int i =0;i<in;i++) {
                        DatagramPacket toReceive = new DatagramPacket(buf2, buf2.length);
                        client.receive(toReceive);
                        long n = ByteBuffer.wrap(buf2).getLong();
                        //String broj = new String(toReceive.getData(), 0, toReceive.getLength());
                        System.out.println(n);
                    }

                }

            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

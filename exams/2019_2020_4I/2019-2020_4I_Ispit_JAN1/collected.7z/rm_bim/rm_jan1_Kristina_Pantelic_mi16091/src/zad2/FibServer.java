package zad2;

import com.sun.jdi.IntegerValue;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

final class FibServer {
    private long [] lista = new long[81];
    private int port;

    public FibServer(int i) {
        this.port = i;
    }

    public static void main(String[] args) {
        //System.out.println("Hello from FibServer!");
        FibServer server = new FibServer(12345);

        server.execute();
    }

    private void execute() {
        this.izracunaj();

        try(DatagramSocket server = new DatagramSocket(this.port)){

            while(true){
                byte[] buf = new byte[4];
                DatagramPacket fromClient = new DatagramPacket(buf, buf.length);
                server.receive(fromClient);

                int n = ByteBuffer.wrap(fromClient.getData()).getInt();

                if (n < 0 || n > 80){
                    continue;
                }
                //System.out.println("Stigao datagram!");

                for (int i=0;i<n;i++){
                    //byte[] buf2 = Long.toString(this.lista[i]).getBytes();
                    ByteBuffer buf3 = ByteBuffer.allocate(8);
                    buf3.putLong(this.lista[i]);
                    System.err.println(buf3.array().length);
                    DatagramPacket toClient = new DatagramPacket(buf3.array(), buf3.array().length, fromClient.getAddress(), fromClient.getPort());
                    server.send(toClient);
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void izracunaj(){
        this.lista[0] = 0l;
        this.lista[1] = 1l;
        for (int i=2; i<=80;i++){
            this.lista[i] = this.lista[i-1] + this.lista[i-2];
        }
    }
}

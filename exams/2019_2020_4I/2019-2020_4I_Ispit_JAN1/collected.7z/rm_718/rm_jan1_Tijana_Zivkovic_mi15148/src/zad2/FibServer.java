package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

final class FibServer {

    public static final int PORT = 12345;
    public int n;

    public static void main(String[] args) {

        try( DatagramSocket server = new DatagramSocket(PORT)) {

            while(true) {
                byte[] buffer = new byte[4];
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                server.receive(request);

                if (buffer != null) {
                    System.out.println("Stigao datagram!");
                }

                //TODO
                int n = 5;

                int[] fib = new int[n];
                fib = fibonaci(n);
                for(int num : fib) {
                    buffer[0] = (byte)num;
                    DatagramPacket response = new DatagramPacket(buffer, buffer.length, request.getAddress(), request.getPort());
                    server.send(response);
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static int[] fibonaci(int n) {
        int[] array = new int[n];
        int first = 0;
        array[0] = first;
        int second = 1;
        array[1] = second;
        int prev1 = first;
        int prev2 = second;
        for(int i = 2; i < n; i++){
            array[i] = prev1 + prev2;
            prev1 = prev2;
            prev2 = array[i];
        }

        return array;
    }
}































package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class FibClient {


    public static void main(String[] args) {

        try(DatagramSocket client = new DatagramSocket()) {

            InetAddress address = InetAddress.getByName("localhost");
            byte[] buffer = new byte[4];
            //TODO
            Scanner sc = new Scanner(System.in);
            byte b = sc.nextByte();
            buffer[1] = b;

            DatagramPacket request = new DatagramPacket(buffer, buffer.length, address, FibServer.PORT);
            client.send(request);

            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            client.receive(response);
            System.out.println(new String(response.getData(), StandardCharsets.UTF_8));


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}



























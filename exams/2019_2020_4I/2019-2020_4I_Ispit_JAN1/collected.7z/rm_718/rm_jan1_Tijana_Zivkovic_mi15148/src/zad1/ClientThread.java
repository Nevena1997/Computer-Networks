package zad1;

import java.util.Scanner;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    private String zahtev;

    public ClientThread(String zahtev) {
        this.zahtev = zahtev;
    }


    @Override
    public void run() {

        if (zahtev.substring(0, zahtev.indexOf(" ")).equalsIgnoreCase("ins")) {
            ChessDbServer.sahisti.add(new ChessPlayer(ChessDbServer.sahisti.size() + 1, zahtev.substring(zahtev.indexOf(" ") + 1, zahtev.indexOf(0)), 1300));

            System.out.println("ins je uspesno izvrsen");
        } else if (zahtev.substring(0, zahtev.indexOf(" ")).equalsIgnoreCase("sel")) {
            for (ChessPlayer cp : ChessDbServer.sahisti) {
                Scanner sc = new Scanner(zahtev);
                sc.next();
                int id = sc.nextInt();
                if (cp.id == id) {
                    System.out.println(cp);
                }
            }
        } else if (zahtev.substring(0, zahtev.indexOf(" ")).equalsIgnoreCase("upd")) {

            for (ChessPlayer cp : ChessDbServer.sahisti) {
                Scanner sc = new Scanner(zahtev);
                sc.next();
                int id = sc.nextInt();
                int deltae = sc.nextInt();
                cp.elo = cp.elo + deltae;
                System.out.println("upd je uspesno izvrsen");
            }
        } else {
            System.out.println("Komanda nije dobra");
        }
    }
}

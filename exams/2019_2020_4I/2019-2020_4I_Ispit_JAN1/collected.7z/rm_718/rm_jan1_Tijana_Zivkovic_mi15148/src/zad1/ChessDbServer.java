package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentLinkedQueue;

final class ChessDbServer {

    public static ConcurrentLinkedQueue<ChessPlayer> sahisti = new ConcurrentLinkedQueue<>();

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(1996)) {


            while(true) {

                Socket client = server.accept();
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
                String zahtev = in.readLine();
                System.out.println(zahtev);

                new ClientThread(zahtev).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

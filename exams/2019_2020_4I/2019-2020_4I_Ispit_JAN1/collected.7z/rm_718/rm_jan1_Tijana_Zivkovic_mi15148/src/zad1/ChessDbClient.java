package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        try(Socket client  = new Socket("localhost", 1996)){

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
            Scanner sc = new Scanner(System.in);
            while (true) {
                String zahtev = sc.nextLine();
                out.write(zahtev);

                if(zahtev.equalsIgnoreCase("bye")){
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

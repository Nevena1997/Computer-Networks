package zad1;

final class ChessPlayer {
    // id
    public int id;
    // naziv
    public String naziv;
    // elo
    public int elo;

    ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return this.naziv + ": " + this.elo;
    }
}

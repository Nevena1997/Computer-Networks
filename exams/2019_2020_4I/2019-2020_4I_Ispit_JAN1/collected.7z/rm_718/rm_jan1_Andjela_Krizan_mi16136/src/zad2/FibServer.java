package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.concurrent.ForkJoinPool;

final class FibServer {

    String hostname = "localhost";
    public static final int port = 12345;

    public static int[] niz;

    public static int getNizOdI(int i) {
        return niz[i];
    }

    public FibServer() {
        this.niz[0] = 0;
        this.niz[1] = 1;
    }

    public static void main(String[] args) {

        System.out.println("Hello from FibServer!");
       // niz[0] = 0;
       // niz[1] = 1;


        try {
            DatagramSocket server = new DatagramSocket(port);

            while(true){

                //ByteBuffer buffer = ByteBuffer.allocate(4);
                byte[] buffer  = new byte[4];
                DatagramPacket primljenBrojN = new DatagramPacket(buffer, buffer.length);
                server.receive(primljenBrojN);

                System.out.println("Stigao datagram!");


                //SERVER SALJE 8Bajta
                //U REQUEST-u mi se nalazi broj N
                String niska = new String(buffer);
                int n = Integer.parseInt(niska);

                //TREBA DA SALJEM 8B, a buffer ima 4B

                for(int j=0;j<n;j++){
                    if(j>1){
                        niz[j] = niz[j-1] + niz[j-2];
                    }
                    byte[] buffZaSlanje  = new byte[8];

                    String pomocnaNiska = String.valueOf(niz[j]);//IZ INT-a U STRING

                    buffZaSlanje = pomocnaNiska.getBytes();//IZ STRINGA U BAJTOVE

                    DatagramPacket fibonacijevOdJ = new DatagramPacket(buffZaSlanje,buffZaSlanje.length, primljenBrojN.getAddress(), primljenBrojN.getPort());
                    server.send(fibonacijevOdJ);
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

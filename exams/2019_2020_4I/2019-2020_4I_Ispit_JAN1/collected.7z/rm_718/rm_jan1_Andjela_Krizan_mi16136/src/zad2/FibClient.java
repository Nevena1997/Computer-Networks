package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class FibClient {

    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");

        try {
            //InetAddress addr = InetAddress.getLoopbackAddress();
            //InetSocketAddress addr = new InetSocketAddress(/*"localhost",*/ FibServer.port);
            InetSocketAddress addr = new InetSocketAddress(/*"localhost",*/ FibServer.port);
            DatagramSocket client = new DatagramSocket(FibServer.port);


            //PRETPOSTAVLJAM DA JE UNET INT OD 4 BAJTA

            System.out.println("Uneti jedan pozitivan ceo broj: ");

            Scanner sc = new Scanner(System.in);

            //int je 4bajta
            String sadrzajString = sc.nextLine();
            byte[] sadrzajUbajtovima = sadrzajString.getBytes();


            DatagramPacket datagramKojiSaljem = new DatagramPacket(sadrzajUbajtovima, sadrzajUbajtovima.length,FibServer.port, addr);
            client.send(datagramKojiSaljem);

            //POSLALI SMO N, SAD PRIMAMO N BROJEVA:

            int n = Integer.parseInt(sadrzajString);

            for(int i=0;i<n;i++){
                byte[] buffPrimljeno  = new byte[8];
                DatagramPacket fibonacijevPrimljeno = new DatagramPacket(buffPrimljeno, buffPrimljeno.length);
                client.receive(fibonacijevPrimljeno);

                //PRIMILI SMO U BAJTOVIMA
                String primljenoString = new String(buffPrimljeno);//IZ BAJTOVA U NISKU
                int primljeniInt = Integer.parseInt(primljenoString);//IZ NISKE U INT
                System.out.println("Primnjen je broj: " + primljeniInt);
            }


        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}

package zad1;

final class ChessPlayer {
    int id=0;
    String naziv;
    int elo;

    public ChessPlayer(String naziv, int elo) {
        this.id++;//kad se pozove konstruktor, pravi se novi igrac i povezava se id
        this.naziv = naziv;
        this.elo = elo;
    }

    public int getId() {
        return id;
    }

    public String getNaziv() {
        return naziv;
    }

    public int getElo() {
        return elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }
}

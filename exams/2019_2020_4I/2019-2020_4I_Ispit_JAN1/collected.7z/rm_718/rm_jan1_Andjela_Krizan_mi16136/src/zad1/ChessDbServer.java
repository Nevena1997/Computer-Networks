package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.time.chrono.IsoEra;
import java.util.HashSet;
import java.util.Set;

final class ChessDbServer {

    int port = 1996;
    int id;
    String naziv;
    int elo;

    public static ServerSocket server;

    public ChessDbServer(int id, String naziv, int elo,int port) throws IOException {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
        this.server = new ServerSocket(port);
    }

    public static void main(String[] args) {

        System.out.println("Hello from ChessDbServer!");



        while(true){
            try {
                Socket client = server.accept();

                new ClientThread(client).start();

                System.out.println("Pristigao klijent:"+client);


            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }
}

package zad1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    static final int port = 1996;
    //private static Writer out;
    Socket client;
    public static BufferedWriter out;


    public ChessDbClient(int port) throws IOException {
        this.client = new Socket("localhost", port);
        this.out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
    }


    public static void main(String[] args) {

        System.out.println("Hello from ChessDbClient!");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Unesite zahtev: ");
            String zahtev;


            while(sc.hasNext()) {

                zahtev = sc.nextLine();

                out.write(zahtev, 0, zahtev.length());

            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}

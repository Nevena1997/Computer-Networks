package zad1;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer

    Socket client;

    public ClientThread(Socket client) {
        this.client=client;
    }

    @Override
    public void run(){

        Set<ChessPlayer> igraci = new HashSet<>();

        Map<Integer, String> mapaIgraca = new HashMap<>();//mapa: id, naziv

         try(BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(this.client.getOutputStream()))
         ){
            String zahtev;
            //while((zahtev=in.readLine())!=null){
            while(true){
                zahtev = in.readLine();

                if (zahtev.startsWith("sel")) {//sel id
                    String kljuc = zahtev.substring(4);
                    int klucInt = Integer.parseInt(kljuc);

                    if(mapaIgraca.containsKey(klucInt)){
                        //ispisi naziv i elo ko sadrzi kljucint
                        //out.println();
                    }

                } else if (zahtev.startsWith("ins")) {//ins naziv
                    //KAKO ID da mi se povecava
                    String naziv = zahtev.substring(4);
                    int elo = Integer.parseInt(zahtev.substring(4+naziv.length()));
                    mapaIgraca.put(0, naziv);
                    ChessPlayer player = new ChessPlayer(naziv, elo);
                    igraci.add(player);
                } else if (zahtev.startsWith("upd")) {//upd id elo

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}

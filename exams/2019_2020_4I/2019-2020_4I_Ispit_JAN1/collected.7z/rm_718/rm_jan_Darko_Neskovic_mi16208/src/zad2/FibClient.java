package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) throws UnknownHostException {


        Scanner sc = new Scanner(System.in);


        InetAddress addr = InetAddress.getByName("localhost");

        try (DatagramSocket client = new DatagramSocket()) {


            ByteBuffer buffer = ByteBuffer.allocate(4);
            byte[] data = new byte[4];
            int num = sc.nextInt();
            buffer.putInt(num);

            if (num > 80 || num < 0){
                System.err.println("greska!");
                System.exit(1);
            }
            data = buffer.array();
            buffer.clear();

            DatagramPacket msg = new DatagramPacket(data, data.length, addr, FibServer.PORT);
            client.send(msg);
            byte[] nextFib = new byte[8];
            for(int i = 0; i < num; i++){
                DatagramPacket response = new DatagramPacket(nextFib, nextFib.length, addr, FibServer.PORT);
                client.receive(response);

                buffer.put(response.getData());
                buffer.flip();
                System.out.println(buffer.getInt());
                buffer.clear();
            }





        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

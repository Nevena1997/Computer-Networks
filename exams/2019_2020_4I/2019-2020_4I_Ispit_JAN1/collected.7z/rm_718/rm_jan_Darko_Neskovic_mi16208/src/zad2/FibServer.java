package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;

final class FibServer {

    public static int PORT = 12345;

    public static void main(String[] args) {



        try (DatagramSocket server = new DatagramSocket(PORT)){

            byte[] data = new byte[4];
            ByteBuffer buffer = ByteBuffer.allocate(8);

            while (true){
                DatagramPacket msg = new DatagramPacket(data, data.length);
                server.receive(msg);
                System.out.println("Stigao datagram!");



                buffer.put(msg.getData());
                int num = buffer.getInt();
                buffer.clear();

                int i1 = 1;
                int i2 = 2;

                byte[] nextFib = new byte[8];
                for(int i = 0; i < num; i++){

                    buffer.clear();
                    buffer.putInt(i1 + i2);
                    buffer.flip();

                    nextFib = buffer.array();

                    DatagramPacket response = new DatagramPacket(nextFib, nextFib.length, msg.getAddress(), FibServer.PORT);
                    server.send(response);

                    buffer.put(response.getData());
                    System.out.println(buffer.getInt());
                    buffer.clear();
                }


            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

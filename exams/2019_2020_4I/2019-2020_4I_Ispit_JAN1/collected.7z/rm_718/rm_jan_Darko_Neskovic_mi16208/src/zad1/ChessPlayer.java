package zad1;

final class ChessPlayer {
    int id;
    String naziv;
    int elo;

    public ChessPlayer(int id, String naziv) {
        this.id = id;
        this.naziv = naziv;
        this.elo = 1300;
    }

    @Override
    public String toString() {
        return naziv + ": " + elo;
    }

    public void update(int param) {
        this.elo += param;
        if(this.elo < 1300)
            this.elo = 1300;
    }
}

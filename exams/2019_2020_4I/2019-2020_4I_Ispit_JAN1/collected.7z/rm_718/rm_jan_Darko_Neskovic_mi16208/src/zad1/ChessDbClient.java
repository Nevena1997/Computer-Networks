package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", 1996)){

            Scanner sc = new Scanner(System.in);
            String request = "";
            String response = "";
            BufferedWriter out = new BufferedWriter (new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

            while(true){
                request = sc.next();

                //Ne uspevam da posaljem request..
                out.write(request);
                out.newLine();


                if (request.equalsIgnoreCase("bye"))
                    break;

                response = in.readLine();
                System.out.println(response);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}


package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

final class ClientThread extends Thread {

    ServerSocket server = null;
    Socket client = null;
    PrintWriter cout;
    BufferedReader cin;
    PrintWriter sout;
    BufferedReader sin;

    ClientThread(ServerSocket server, Socket client) {
        this.server = server;
        this.client = client;

        try {
            this.cout = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
            this.cin = new BufferedReader(new InputStreamReader(client.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void run() {
        System.out.println("Uspesno povezan klijent.");
        try {


            //Uopste mi ne cita ovo ovde... TODO
            String request = cin.readLine();

            System.out.println(request);
            if (request == null)
                System.exit(1);


            var params = request.split(" ");
//            System.out.println("!! " + request.substring(params[0].length())); //test

            if(params[0].equalsIgnoreCase("ins")){
                ChessDbServer.br_sahista++;
                ChessDbServer.sahisti.add(new ChessPlayer(ChessDbServer.br_sahista,
                        request.substring(params[0].length())));

                cout.println("ins uspesno izvrsen");
                cout.flush();
            }else if(params[0].equalsIgnoreCase("sel")){
                cout.println(ChessDbServer.sahisti.get(1));
                cout.flush();
            }else if(params[0].equalsIgnoreCase("upd")){
                ChessDbServer.sahisti.get(1).update(10);
                cout.println("upd uspesno izvrsen");
                cout.flush();
            } else{
                cout.println("Nepoznata naredba!");
                cout.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // User thread for the ChessDbServer
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;

final class ChessDbServer {

    public static int PORT = 1996;
    public static List<ChessPlayer> sahisti;
    public static int br_sahista = 0;

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(PORT)) {
            while(true){
                Socket client = server.accept();
                new Thread(new ClientThread(server, client)).start();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

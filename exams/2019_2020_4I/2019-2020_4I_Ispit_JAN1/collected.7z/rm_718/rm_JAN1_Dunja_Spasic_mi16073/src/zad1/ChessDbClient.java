package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost",1996);
            System.out.println("Connected to server.");

            OutputStreamWriter out = new OutputStreamWriter(socket.getOutputStream());
            Scanner sc = new Scanner(System.in);
            String s = "";
            while (sc.hasNext())
            {
                s = sc.nextLine();
                if (s.subSequence(0,3).equals("sel".toCharArray() ) || s.subSequence(0,3).equals("ins".toCharArray() )|| s.subSequence(0,3).equals("upd".toCharArray() ))
                {
                    System.out.println("Nije dobro zadata naredba."+s.subSequence(0,3));
                    continue;
                }
                out.write(s);
                out.flush();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

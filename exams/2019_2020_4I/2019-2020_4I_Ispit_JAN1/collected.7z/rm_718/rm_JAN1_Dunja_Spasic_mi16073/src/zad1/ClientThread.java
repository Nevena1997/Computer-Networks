package zad1;

import java.io.*;
import java.lang.management.PlatformLoggingMXBean;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    Socket client;
    List<ChessPlayer>players;

    public ClientThread(Socket socket, List<ChessPlayer> players1) {
        client = socket;
        players = players1;
    }

    @Override
    public void run() {
        try {
            InputStreamReader in = new InputStreamReader(client.getInputStream());
            Scanner sc = new Scanner(client.getInputStream());
            OutputStreamWriter out = new OutputStreamWriter(client.getOutputStream());

            do {
                if (!sc.hasNext())
                    break;
                String s = sc.nextLine();

                if (s.subSequence(0,3) == "sel")
                {
                    s = (String) s.subSequence(3,s.length());
                    int id = Integer.parseInt(s);

                    for (ChessPlayer player : players)
                    {
                        if (id == player.getId()) {
                            out.write(player.toString());
                            out.flush();
                        }
                    }
                }
                else if (s.subSequence(0,3) == "ins")
                {
                    s = (String) s.subSequence(3,s.length());
                    int i=0;
                    for (ChessPlayer player : players)
                    {
                        if (s.equals(player.getNaziv()) && player.getElo() == 1300)
                        {
                            break;
                        }
                        i++;
                    }
                    if (i == players.size())
                    {
                        players.add(new ChessPlayer(s,1300));
                        out.write("ins je uspesno izvrsen.");
                        out.flush();
                    }

                }
                else if (s.subSequence(0,3) == "upd")
                {
                    s = (String) s.subSequence(3,s.length());
                    s = (String)s.subSequence(3,s.length());
                    String[] update =  s.split(" ");

                    int id = Integer.parseInt(update[0]);
                    int deltae = Integer.parseInt(update[1]);


                    for (ChessPlayer player : players)
                    {
                        if (id == player.getId()) {

                            player.setElo(deltae);
                            out.write("Upd je ispesno izvrsen.");
                            out.flush();
                            break;
                        }
                    }
                }
                else break;


            } while (!sc.equals("bye"));

            System.out.println("Obradjen klijent.");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

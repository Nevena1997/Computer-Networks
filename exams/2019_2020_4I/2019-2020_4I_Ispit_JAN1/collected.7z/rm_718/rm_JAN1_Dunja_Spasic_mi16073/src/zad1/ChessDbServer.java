package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

final class ChessDbServer {
    static List<ChessPlayer> players = new LinkedList<>();

    public static void main(String[] args) {

        try {
            ServerSocket server = new ServerSocket(1996);
            while (true)
            {
                Socket client = server.accept();
                ClientThread user = new ClientThread(client,players);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Hello from ChessDbServer!");
    }

}

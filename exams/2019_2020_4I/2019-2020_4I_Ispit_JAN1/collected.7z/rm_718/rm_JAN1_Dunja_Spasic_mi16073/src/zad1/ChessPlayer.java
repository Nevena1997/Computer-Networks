package zad1;

final class ChessPlayer {
    int id;
    String naziv;
    int elo;

    public ChessPlayer(String naziv, int elo){
        naziv = naziv;
        elo = elo;
    }

    @Override
    public String toString() {
        return naziv+": "+elo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getElo() {
        return elo;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }
}

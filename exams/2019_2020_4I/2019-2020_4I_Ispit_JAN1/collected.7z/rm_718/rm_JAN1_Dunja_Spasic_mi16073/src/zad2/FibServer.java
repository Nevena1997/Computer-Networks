package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;

final class FibServer {
    public static void main(String[] args) {


        System.out.println("Hello from FibServer!");
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

final class FibClient {
    public static void main(String[] args) {
        try(DatagramSocket ds = new DatagramSocket(12345);) {
            ds.setSoTimeout(5000);
            //DatagramPacket dp = ds.connect("");
            //BufferedReader buff = new BufferedReader();
        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Hello from FibClient!");
    }
}

package zad2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Unesite pozitivan broj n: ");
        int n = in.nextInt();

        in.close();
        try (DatagramSocket client = new DatagramSocket()){
            InetAddress address = InetAddress.getByName("localhost");
            int port = 12345;




            byte[] buff = String.valueOf(n).getBytes();

            DatagramPacket request = new DatagramPacket(buff, buff.length, address, port);
            client.send(request);



            for(int i = 0; i < n; i++){
                DatagramPacket response = new DatagramPacket(new byte[8], 8);
                client.receive(response);

                String value = new String(response.getData(),
                        0,
                        response.getLength(),
                        StandardCharsets.UTF_8);

                System.out.println(value);

                //DatagramPacket newNum = new DatagramPacket(value.getBytes(), value.getBytes().length, address, port);
                //client.send(newNum);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.math.BigInteger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

final class FibServer {
    public static void main(String[] args) {
        int port = 12345;

        long[] fibNums = makeFibonacis();

        try(DatagramSocket socket = new DatagramSocket(port)){
            byte[] buffer = new byte[8];
            while(true){
                try{
                    DatagramPacket request = new DatagramPacket(new byte[4], 4);
                    socket.receive(request);

                    String value = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
                    System.out.println("Stigao datagram!");

                    int intValue = Integer.parseInt(value);

                    //int index = Arrays.binarySearch(fibNums, intValue);

                    for(int i = 0; i < intValue; i++){
                        byte[] response = String.valueOf(fibNums[i]).getBytes();

                        DatagramPacket send = new DatagramPacket(response, response.length,
                                request.getAddress(), request.getPort());
                        socket.send(send);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

    private static long[] makeFibonacis() {
        long[] nums = new long[81];
        nums[0] = 0;
        nums[1] = 1;

        for(int i = 2; i < 81; i++){
            nums[i] = nums[i-1] + nums[i-2];
        }

        return nums;
    }
}

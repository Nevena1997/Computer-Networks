package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

final class ChessDbServer {

    public static Map<Integer, ChessPlayer> users = new HashMap<>();

    public static void main(String[] args) {

        System.out.println("Hello from ChessDbServer!");
        try(ServerSocket server = new ServerSocket(1996)) {
            while(true){
                try{
                    Socket client = server.accept();
                    ClientThread newClient = new ClientThread(client);
                    newClient.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

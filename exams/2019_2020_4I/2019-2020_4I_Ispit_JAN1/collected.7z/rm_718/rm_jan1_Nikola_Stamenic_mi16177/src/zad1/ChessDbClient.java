package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        System.out.println("Hello from ChessDbClient!");
        Scanner scIn = null;


        try(Socket client = new Socket("localhost", 1996)){
            scIn = new Scanner(System.in);
            String line;

            PrintWriter out = new PrintWriter(client.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(new BufferedInputStream( client.getInputStream())));
            do{
                line = scIn.nextLine();
                out.println(line);
                String lineFromServer = in.readLine();
                System.out.println(lineFromServer);
            }while(!line.equalsIgnoreCase("bye"));

        } catch (UnknownHostException e) {
            if(scIn != null)
                scIn.close();

            e.printStackTrace();
        } catch (IOException e) {
            if(scIn != null)
                scIn.close();

            e.printStackTrace();
        }
    }
}

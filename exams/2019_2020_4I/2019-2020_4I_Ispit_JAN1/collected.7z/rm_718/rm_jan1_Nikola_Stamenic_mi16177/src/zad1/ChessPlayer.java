package zad1;

final class ChessPlayer {
    int id;
    String naziv;
    int elo;

    public ChessPlayer(int id, String naziv, int elo){
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    synchronized void update(int delta){
        this.elo += delta;
    }

    @Override
    public String toString() {
        // naziv: elo
        return new String(naziv + ": " + elo);
    }
}

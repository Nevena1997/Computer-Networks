package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.stream.Collectors;

final class ClientThread extends Thread {

    BufferedReader in;
    PrintWriter out;

    public ClientThread(Socket client) throws IOException {
        in = new BufferedReader(new InputStreamReader(new BufferedInputStream(client.getInputStream())));
        out = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));
    }
    // User thread for the ChessDbServer


    @Override
    public void run() {
        String line = null;
        while(true){
            try {
                line = in.readLine();


                String[] tokens = line.split(" ");
                //System.out.println(line);

                if(tokens[0].equalsIgnoreCase("sel")){

                    int id = Integer.parseInt(tokens[1]);
                    if(ChessDbServer.users.containsKey(id)){
                        out.println(ChessDbServer.users.get(id).toString());
                        out.flush();
                    }
                    else{
                        out.println("Nema kandidata sa trazenim id-em");
                        out.flush();
                    }
                }
                else if(tokens[0].equalsIgnoreCase("ins")){
                    var players = ChessDbServer.users.keySet().stream().collect(Collectors.toList());
                    int id = 0;
                    for(var i : players){
                        if(i > id){
                            id = i;
                        }
                    }
                    id += 1;

                    StringBuilder build = new StringBuilder();

                    for(int i = 1; i < tokens.length; i++){
                        build.append(tokens[i] + " ");
                    }

                    if(insertPlayer(build.toString(), id)){
                        out.println("ins je uspesno izvrsen");
                        out.flush();
                    }
                }
                else if(tokens[0].equalsIgnoreCase("upd")){
                    int id = Integer.parseInt(tokens[1]);
                    int delta = Integer.parseInt(tokens[2]);
                    if(ChessDbServer.users.containsKey(id)){
                        ChessDbServer.users.get(id).update(delta);
                        out.println("upd je uspesno izvrsen");
                        out.flush();
                    }
                }
                else if(line.equalsIgnoreCase("bye")){
                    break;
                }
                else{
                    out.println("Nepostojeca komanda");
                    out.flush();
                }

            } catch (IOException e) {
                e.printStackTrace();
                try {
                    out.close();
                    in.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }

        try {
            out.close();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    synchronized boolean insertPlayer(String naziv, int id){
        if(ChessDbServer.users.containsKey(id))
            return false;

        ChessDbServer.users.put(id, new ChessPlayer(id, naziv, 1300));
        return true;
    }
}

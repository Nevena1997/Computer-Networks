package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {


        int port = 12345;
        String hostname = "localhost";

        System.out.println("Unesite n:");
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        input.close();

        if(n <= 0 || n > 80){
            System.out.println("Nije poslat broj izmedju 0 i 80.");
            return;
        }

        try(DatagramSocket socket = new DatagramSocket()) {


            InetAddress addr = InetAddress.getByName(hostname);
            byte[] sendBytes = ByteBuffer.allocate(4).putInt(n).array();

            DatagramPacket send = new DatagramPacket(sendBytes, sendBytes.length, addr, port);
            socket.send(send);

            for(int i = 0; i < n; i++){
                byte[] receiveBytes = new byte[8];
                DatagramPacket receive = new DatagramPacket(receiveBytes, receiveBytes.length);
                socket.receive(receive);
                System.out.println(ByteBuffer.wrap(receive.getData()).getLong());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

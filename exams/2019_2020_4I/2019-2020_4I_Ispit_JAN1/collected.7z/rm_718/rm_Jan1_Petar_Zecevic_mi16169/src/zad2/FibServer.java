package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

final class FibServer {
    public static void main(String[] args) {

        int port = 12345;

        List<Long> fibList = new ArrayList<>();
        long fib1 = 1;
        long fib2 = 1;
        long fib;
        fibList.add(fib1);
        fibList.add(fib2);
        for(int i = 0; i < 78; i++){
            fib = fib1 + fib2;
            fibList.add(fib);
            fib1 = fib2;
            fib2 = fib;
        }

        try(DatagramSocket server = new DatagramSocket(port)) {

            while(true) {

                byte[] receiveBytes = new byte[4];
                DatagramPacket receive = new DatagramPacket(receiveBytes, receiveBytes.length);
                server.receive(receive);

                System.out.println("Stigao datagram!");

                int n = ByteBuffer.wrap(receive.getData()).getInt();

                InetAddress clientAddr = receive.getAddress();
                int clientPort = receive.getPort();


                for (int i = 0; i < n; i++) {

                    byte[] sendBytes = ByteBuffer.allocate(8).putLong(fibList.get(i)).array();
                    DatagramPacket send = new DatagramPacket(sendBytes, sendBytes.length, clientAddr, clientPort);
                    server.send(send);

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

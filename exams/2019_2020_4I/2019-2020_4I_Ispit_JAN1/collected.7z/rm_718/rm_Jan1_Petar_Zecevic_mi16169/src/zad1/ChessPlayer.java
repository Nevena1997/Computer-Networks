package zad1;

final class ChessPlayer {

    private String naziv;
    private int elo;

    public ChessPlayer (String naziv){
        this.naziv = naziv;
        this.elo = 1300;
    }


    public String getNaziv() {
        return naziv;
    }

    public int getElo() {
        return elo;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }

    @Override
    public String toString() {
        return naziv + ": " + elo;
    }
}

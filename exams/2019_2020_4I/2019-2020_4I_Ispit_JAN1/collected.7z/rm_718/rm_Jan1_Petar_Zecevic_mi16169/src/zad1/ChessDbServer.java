package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

final class ChessDbServer {

    public static List<ChessPlayer> listOfPlayers = Collections.synchronizedList(new LinkedList<>());

    public static void main(String[] args) {

        int port = 1996;

        try(ServerSocket server = new ServerSocket(port)) {

            while(true){

                Socket client = server.accept();
                new ClientThread(client).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

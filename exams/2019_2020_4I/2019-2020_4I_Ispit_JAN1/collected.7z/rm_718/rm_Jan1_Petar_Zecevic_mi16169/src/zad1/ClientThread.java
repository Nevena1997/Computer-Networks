package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

final class ClientThread extends Thread {

    private Socket client;

    public ClientThread(Socket client){
        this.client = client;
    }

    @Override
    public void run() {

        try(Scanner reader = new Scanner(new BufferedReader(new InputStreamReader(this.client.getInputStream())));
            PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream())))) {


            while(true) {

                if (!reader.hasNextLine()){
                    client.close();
                    break;
                }
                String command = reader.nextLine();
                if (command.trim().equalsIgnoreCase("bye")) {
                    client.close();
                    break;
                } else if (command.startsWith("sel")) {

                    String[] splitted = command.split(" ");
                    int id;
                    try {
                        id = Integer.parseInt(splitted[1]) - 1;
                    } catch(ArrayIndexOutOfBoundsException | NumberFormatException a){
                        writer.println("Nije poslat broj posle sel");
                        writer.flush();
                        continue;
                    }
                    synchronized (this) {

                        if (id < 0 || id >= ChessDbServer.listOfPlayers.size()){
                            writer.println("Igrac sa indeksom " + (id+1) + " ne postoji.");
                            writer.flush();
                        }
                        else {
                            writer.println(ChessDbServer.listOfPlayers.get(id));
                            writer.flush();
                        }

                    }

                } else if (command.startsWith("ins")) {

                    String naziv;
                    try {
                        naziv = command.substring(4);
                    } catch(StringIndexOutOfBoundsException b){
                        writer.println("Nije poslat naziv nakon ins");
                        writer.flush();
                        continue;
                    }
                    ChessPlayer chessPlayer = new ChessPlayer(naziv);
                    synchronized (this) {
                        ChessDbServer.listOfPlayers.add(chessPlayer);
                        writer.println("ins je uspesno izvrsen");
                        writer.flush();
                    }


                } else if (command.startsWith("upd")) {

                    String[] splitted = command.split(" ");
                    int id;
                    int deltae;
                    try {
                        id = Integer.parseInt(splitted[1]) - 1;
                        deltae = Integer.parseInt(splitted[2]);
                    } catch(ArrayIndexOutOfBoundsException | NumberFormatException c){

                        writer.println("Nisu poslati ili id ili deltae nakon upd");
                        writer.flush();
                        continue;

                    }

                    synchronized (this) {
                        if (id < 0 || id >= ChessDbServer.listOfPlayers.size()) {
                            writer.println("Igrac sa indeksom " + (id+1) + " ne postoji.");
                            writer.flush();
                        } else {
                            ChessPlayer chessPlayer = ChessDbServer.listOfPlayers.get(id);
                            chessPlayer.setElo(chessPlayer.getElo() + deltae);
                            if (chessPlayer.getElo() < 1300) {
                                chessPlayer.setElo(1300);
                            }

                            writer.println("upd je uspesno izvrsen");
                            writer.flush();
                        }
                    }

                } else {
                    writer.println("Nepostojeca komanda.");
                    writer.flush();
                }
            }




        } catch (IOException e) {
            try {
                client.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }


    }
}

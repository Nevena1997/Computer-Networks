package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


final class FibServer {

    public static final int PORT = 12345;
    public static List<Integer> fibList = new ArrayList<Integer>();

    public static void main(String[] args) {


        try (DatagramSocket server = new DatagramSocket(PORT)) {

            byte[] buf = new byte[4];


            DatagramPacket request = new DatagramPacket(buf, buf.length);

            server.receive(request);
            System.out.println("Stigao datagram!");

            String num = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
            int n = Integer.parseInt(num);


            getFibList(n);

            for (int el : fibList) {
                byte[] b = new byte[8];
                b = String.valueOf(el).getBytes(); //ocigledno ne znam odakle se poziva ova metoda
                DatagramPacket response = new DatagramPacket(b, b.length);
                server.send(response);
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void getFibList(int n) {

        for (int i = 0; i < n; i++) {
            fibList.add(nFib(i));
        }


    }

    static int nFib(int n) {

        if (n == 0)
            return 0;
        else if (n == 1)
            return 1;
        else
            return nFib(n - 1) + nFib(n - 2);
        //return fibList.get(n-1) + fibList.get(n-2); //mozda je ovako moglo neko kesiranje ali nece
    }

}

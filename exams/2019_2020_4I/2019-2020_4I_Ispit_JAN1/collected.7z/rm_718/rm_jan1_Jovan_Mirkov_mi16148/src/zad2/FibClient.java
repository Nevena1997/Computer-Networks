package zad2;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {


        try (DatagramSocket client = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            byte[] buf = new byte[4];
            //int n = sc.nextInt();
            String n = sc.nextLine();

            buf = n.getBytes();


            DatagramPacket request = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), FibServer.PORT);

            client.send(request);

            byte[] buf8= new byte[8];
            for (int i = 0; i < Integer.parseInt(n); i++) {

                DatagramPacket response = new DatagramPacket(buf8, buf8.length);
                client.receive(response);
                System.out.println(new String(response.getData(),0,response.getLength(), StandardCharsets.UTF_8));
            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

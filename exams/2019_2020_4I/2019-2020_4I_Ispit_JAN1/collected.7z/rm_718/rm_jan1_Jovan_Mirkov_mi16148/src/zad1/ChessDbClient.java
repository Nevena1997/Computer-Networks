package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {


        try (Socket socket = new Socket("localhost", 1996);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             Scanner sc = new Scanner(System.in)) {


            while (true) {

                String line = sc.nextLine();

                if (line.equalsIgnoreCase("bye")) {
                    break;
                }

                String[] parts = line.split(" ",2);

                if(!parts[0].equalsIgnoreCase("sel")|| !parts[0].equalsIgnoreCase("ins") || !parts[0].equalsIgnoreCase("upd") )
                {
                    System.err.println("Fatal error: Bad request");
                    break;
                }
                out.write(line);

            }


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

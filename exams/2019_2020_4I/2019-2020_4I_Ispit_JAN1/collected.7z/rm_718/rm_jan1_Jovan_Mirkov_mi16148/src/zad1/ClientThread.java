package zad1;

import java.io.*;
import java.net.Socket;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer

    private Socket client = null;


    public ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));

            String line = in.readLine();
            while (true) {


                if (line.equalsIgnoreCase("bye")) {
                    break;
                }


                String[] parts = line.split(" ", 2);


                //moglo je u funkcije sve ali zurim...
                if (parts[0].equalsIgnoreCase("ins")) {
                    synchronized (ChessDbServer.playerList) {
                        ChessDbServer.playerList.add(new ChessPlayer(parts[1], 1300));
                        out.write("ins je uspesno izvrsen");
                    }
                }

                if (parts[0].equalsIgnoreCase("sel")) {

                    synchronized (ChessDbServer.playerList) {
                        ChessDbServer.playerList.stream()
                                .filter(p -> p.getId() == Integer.parseInt(parts[1]))
                                .forEach(p -> System.out.println(p));
                    }
                    out.write("sel je uspesno izvrsen");
                }

                if (parts[0].equalsIgnoreCase("upd")) {


                    String[] partsOfParts = line.split(" ", 2);

                    synchronized (ChessDbServer.playerList) {
                        ChessDbServer.playerList.stream()
                                .filter(p -> p.getId() == Integer.parseInt(partsOfParts[1]))
                                .forEach(p -> p.setElo(Integer.parseInt(partsOfParts[2])));
                    }

                    out.write("upd je uspesno izvrsen");
                }


            }
            out.close();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

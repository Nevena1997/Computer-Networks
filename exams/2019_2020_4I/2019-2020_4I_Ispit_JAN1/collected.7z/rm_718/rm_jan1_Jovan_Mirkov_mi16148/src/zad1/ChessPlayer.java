package zad1;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;
    public static int idSeed = 1;

    public ChessPlayer(String naziv, int elo) {
        this.id = idSeed++;
        this.naziv = naziv;
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return  naziv + ": "+ elo;
    }

    public int getId() {
        return id;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }
}

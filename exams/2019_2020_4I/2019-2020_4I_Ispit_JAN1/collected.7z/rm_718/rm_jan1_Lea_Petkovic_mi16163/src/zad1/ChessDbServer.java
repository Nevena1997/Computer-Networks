package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

final class ChessDbServer {
    public static final int PORT = 1996;
    private static Map<Integer, ChessPlayer> players = new HashMap<>();

    public static void addPlayer(Integer id, ChessPlayer player) {
        players.put(id, player);
    }

    public static Map<Integer, ChessPlayer> getPlayers() {
        return players;
    }

    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");

        try (ServerSocket server = new ServerSocket(PORT)) {

            while (true) {
                Socket client = server.accept();

                ClientThread user = new ClientThread(client);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

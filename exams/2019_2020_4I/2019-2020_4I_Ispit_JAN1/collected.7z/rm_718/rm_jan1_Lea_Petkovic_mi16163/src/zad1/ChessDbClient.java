package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {
        //System.out.println("Hello from ChessDbClient!");
        String host = "localhost";
        int port = 1996;

        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(
                     new InputStreamReader(socket.getInputStream())
             );
             BufferedWriter out = new BufferedWriter(
                     new OutputStreamWriter(socket.getOutputStream())
             )) {

            Scanner stdin = new Scanner(System.in);
            System.err.println("Unesite zahteve: ");

            while (stdin.hasNext()) {
                String text = stdin.nextLine();

                if (text.equalsIgnoreCase("bye")) {
                    break;
                }
                out.write(text);
                out.newLine();
                out.flush();

                String line = in.readLine();
                if (line != null) {
                    System.out.println(line);
                }
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

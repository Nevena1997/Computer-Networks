package zad1;

final class ChessPlayer {
    private int id;
    private String naziv;
    private int elo;

    ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    public synchronized int getElo() {
        return this.elo;
    }

    public String getNaziv() {
        return this.naziv;
    }

    public synchronized void setElo(int elo) {
        this.elo = elo;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        // naziv: elo
        return getNaziv() + ": " + getElo();
    }
}

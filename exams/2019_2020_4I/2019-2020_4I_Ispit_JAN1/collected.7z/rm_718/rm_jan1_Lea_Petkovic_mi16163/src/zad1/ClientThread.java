package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    private Socket client;

    ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(client.getInputStream())
            );
             BufferedWriter out = new BufferedWriter(
                     new OutputStreamWriter(client.getOutputStream())
             )
        ) {
            String request;

            while ((request = in.readLine()) != null) {
                if(request.toLowerCase().startsWith("sel ")) {

                    String[] str = request.trim().split(" ");
                    Integer id = Integer.parseInt(str[1]);

                    if (!ChessDbServer.getPlayers().containsKey(id)) {
                        out.write("ne postoji dati id");
                        out.newLine();
                        out.flush();
                        continue;
                    }

                    ChessPlayer player = ChessDbServer.getPlayers().get(id);
                    String toSend = player.toString();

                    out.write(toSend);
                    out.newLine();
                    out.flush();


                } else if (request.toLowerCase().startsWith("ins ")) {

                    String[] str = request.trim().split(" ");
                    Integer id;
                    String naziv = str[1];
                    for (int i = 0; ; i++) {
                        boolean hasId = ChessDbServer.getPlayers().containsKey(i);
                        if (!hasId) {
                            id = i;
                            ChessDbServer.addPlayer(id, new ChessPlayer(id, naziv, 1300));

                            out.write("ins je uspesno izvrsen");
                            out.newLine();
                            out.flush();
                            break;
                        }

                    }
                } else if (request.toLowerCase().startsWith("upd ")) {
                    String[] str = request.trim().split(" ");

                    Integer id = Integer.parseInt(str[1]);
                    Integer deltae = Integer.parseInt(str[2]);
                    ChessPlayer player = ChessDbServer.getPlayers().get(id);
                    int elo = player.getElo();
                    player.setElo(elo + deltae);

                    out.write("upd je uspesno izvrsen");
                    out.newLine();
                    out.flush();

                } else {
                    out.write("naredba nije validna");
                    out.newLine();
                    out.flush();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

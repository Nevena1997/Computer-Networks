package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

final class FibServer {
    public static int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("Hello from FibServer!");

        int[] fibArr = new int[80];
        for (int i = 0; i < 80; i++) {
            if (i == 0 || i == 1) {
                fibArr[i] = 1;
            } else {
                fibArr[i] = fibArr[i-1] + fibArr[i-2];
            }
        }

        try (DatagramSocket server = new DatagramSocket(PORT)) {
            ByteBuffer buffer = ByteBuffer.allocate(4);

            while (true) {
                DatagramPacket request = new DatagramPacket(buffer.array(), buffer.array().length);
                server.receive(request);

                System.out.println("Stigao datagram!");
                int n = buffer.getInt();
                //System.out.println(n);

                ByteBuffer sent = ByteBuffer.allocate(8);
                for (int i = 0; i < n; i++) {
                    sent.putInt(fibArr[i]);
                    DatagramPacket response = new DatagramPacket(sent.array(), sent.array().length,
                            request.getAddress(), request.getPort());
                    server.send(response);

                    sent.clear();
                }
                buffer.flip();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        System.out.println("Hello from FibClient!");

        try (DatagramSocket client = new DatagramSocket()) {

            Scanner sc = new Scanner(System.in);
            System.err.println("Unesite jedan ceo pozitivan broj: ");
            int num = sc.nextInt();
            if (num <= 0 || num > 80) {
                System.err.println("Neispravan broj. Unesite pozitivan");
                num = sc.nextInt();
            }

            InetAddress host = InetAddress.getLocalHost();
            ByteBuffer buffer = ByteBuffer.allocate(4);
            buffer.putInt(num);

            DatagramPacket request = new DatagramPacket(buffer.array(), buffer.array().length, host, FibServer.PORT);
            client.send(request);

            ByteBuffer received = ByteBuffer.allocate(8);
            while (num != 0) {
                DatagramPacket response = new DatagramPacket(received.array(), received.array().length);
                client.receive(response);

                System.out.println(received.getInt());
                received.flip();
                num--;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

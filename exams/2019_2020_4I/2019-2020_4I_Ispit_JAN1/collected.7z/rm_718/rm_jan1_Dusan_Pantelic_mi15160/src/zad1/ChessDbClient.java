package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

final class ChessDbClient {

    private static String HOST = "localhost";
    private static int PORT = 1996;

    public static void main(String[] args) {

        try (Socket socket = new Socket(HOST, PORT);
             BufferedReader userIn = new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
             );
             BufferedReader serverIn = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()
                     )
             );
             BufferedWriter serverOut = new BufferedWriter(
                     new OutputStreamWriter(
                             socket.getOutputStream()
                     )
             )
        ) {

            while (true) {

                String request = userIn.readLine();

                serverOut.write(request);
                serverOut.newLine();
                serverOut.flush();

                if (request.equalsIgnoreCase("bye")) {
                    break;
                }

                String response = serverIn.readLine();
                System.out.println(response);

            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

final class ChessDbServer {

    private static int PORT = 1996;
    private static ArrayList<ChessPlayer> chessDb = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket socket = new ServerSocket(PORT);

        ) {
            while (true) {
                Socket client = socket.accept();

                ClientThread clientThread = new ClientThread(client, chessDb);
                clientThread.start();
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

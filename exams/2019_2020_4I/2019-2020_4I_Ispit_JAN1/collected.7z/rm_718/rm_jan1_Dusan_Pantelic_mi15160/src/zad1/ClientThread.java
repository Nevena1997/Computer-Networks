package zad1;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;


final class ClientThread extends Thread {

    private Socket client = null;
    private ArrayList<ChessPlayer> chessDb;

    public ClientThread(Socket client, ArrayList<ChessPlayer> chessDb) {
        this.client = client;
        this.chessDb = chessDb;
    }

    @Override
    public void run() {

        try ( BufferedReader clientIn = new BufferedReader(
                new InputStreamReader(
                        client.getInputStream()
                )
        );
        BufferedWriter clientOut = new BufferedWriter(
              new OutputStreamWriter(
                      client.getOutputStream()
              )
        )) {

            while (true) {
                String request = clientIn.readLine();

                if (request.equalsIgnoreCase("bye")) {
                    try {
                        this.client.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    return;
                }

                String response = this.handleRequest(request);
                clientOut.write(response);
                clientOut.newLine();
                clientOut.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String handleRequest(String request) {

        if (request.indexOf(' ') == -1) {
            return "Nepoznata komanda";
        }

        String command = request.substring(0, request.indexOf(' '));
        String data = request.substring(request.indexOf(' ') + 1);

        if (command.equalsIgnoreCase("ins")) {
            this.insertPlayer(data);
            return "ins je uspesno izvrsen";
        }

        if (command.equalsIgnoreCase("upd")) {
            String[] parsedData =  data.split(" ");
            String id = parsedData[0];
            String delta = parsedData[1];
            this.updatePlayer(Integer.parseInt(id), Integer.parseInt(delta));
            return "upd je uspesno izvrsen";
        }

        if (command.equalsIgnoreCase("sel")) {
            return this.selectPlayer(Integer.parseInt(data));
        }


        return "Nepoznata komanda";
    }

    private synchronized void insertPlayer(String name) {

        chessDb.add(new ChessPlayer(chessDb.size()+1, name, 1300));
    }

    private synchronized String selectPlayer(int id) {
        return chessDb.toArray()[id-1].toString();
    }

    private synchronized void updatePlayer(int id, int delta) {

        ChessPlayer cp = (ChessPlayer) chessDb.toArray()[id-1];
        cp.updateElo(delta);
    }


}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

final class FibServer {

    private static final int PORT = 12345;
    private static final int BUF_SIZE = 4;

    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(PORT)) {

            while (true) {
                try {
                    DatagramPacket request = new DatagramPacket(new byte[BUF_SIZE], BUF_SIZE);

                    server.receive(request);
                    System.out.println("Stigao datagram");

                    System.out.println(new String(request.getData()));

                    int num = 3;
                    int fst = 0;
                    int snd = 1;

                    for (int i = 0; i < num; i++) {
                        byte[] buf = new byte[BUF_SIZE];
                        buf = "1234".getBytes();
                        DatagramPacket response = new DatagramPacket(buf, buf.length, request.getAddress(), request.getPort());
                        server.send(response);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
}

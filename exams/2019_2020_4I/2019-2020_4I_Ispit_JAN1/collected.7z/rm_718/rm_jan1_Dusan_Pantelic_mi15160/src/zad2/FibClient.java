package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class FibClient {

    private static final int PORT = 12345;
    private static final String HOST = "localhost";
    private static final int BUF_SIZE = 4;

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket()) {

            socket.setSoTimeout(5000);

            InetAddress host = InetAddress.getByName(HOST);

            Scanner sc = new Scanner(System.in);
            int num = sc.nextInt();

            byte[] buf = new byte[BUF_SIZE];

            buf = Integer.toString(num).getBytes();

            DatagramPacket request = new DatagramPacket(buf, buf.length, host, PORT);
            socket.send(request);

            for (int i = 0; i < num; i++) {
                DatagramPacket response = new DatagramPacket(new byte[BUF_SIZE], BUF_SIZE);
                socket.receive(response);
                System.out.println(new String(response.getData()));
            }

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

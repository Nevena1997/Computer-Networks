package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {

        System.err.println("Hello from The other siiiidddeeeee, i must have called a thousand timeeessss");

        try(DatagramSocket ds = new DatagramSocket()){

            Scanner sc = new Scanner(System.in);

            int n = sc.nextInt();

            sc.close();

            byte[] buf = ByteBuffer.allocate(4).putInt(n).array();

            DatagramPacket send = new DatagramPacket(buf, 4, InetAddress.getLoopbackAddress(), 12345);
            ds.send(send);

            for (int i = 0; i < n; i++) {

                DatagramPacket receive = new DatagramPacket(new byte[8], 8);
                ds.receive(receive);

                System.out.println(ByteBuffer.wrap(receive.getData()).getLong());

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

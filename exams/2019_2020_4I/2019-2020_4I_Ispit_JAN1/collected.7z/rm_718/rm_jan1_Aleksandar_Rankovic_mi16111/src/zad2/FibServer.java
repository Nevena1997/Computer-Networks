package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;

final class FibServer {

    //okej... ali rekurzivno je citljivije :D
    public static long fib(long n){
        if(n == 0)
            return 0;
        if(n == 1)
            return 1;

        long prvi = 0;
        long drugi = 1;
        long trenutni = 0;
        for (int i = 2; i <= n; i++) {
            trenutni = prvi + drugi;
            prvi = drugi;
            drugi = trenutni;

        }

        return trenutni;
    }

    public static void main(String[] args) {
        System.err.println("Hello from me running out of bad jokes to write!");

        int port = 12345;

        List<Long> fibonacijevi = new LinkedList<Long>();

        for (long i = 0; i < 80; i++) {
            fibonacijevi.add(fib(i));
        }

        try(DatagramSocket ds = new DatagramSocket(port)){

            while(true){

                DatagramPacket receive = new DatagramPacket(new byte[4], 4);
                ds.receive(receive);
                System.out.println("stigao datagram!");

                int n = ByteBuffer.wrap(receive.getData()).getInt();
                System.out.println(n);

                for (int i = 0; i < n; i++) {

                    byte[] buf = ByteBuffer.allocate(8).putLong(fibonacijevi.get(i)).array();
                    DatagramPacket send = new DatagramPacket(buf, 8, receive.getAddress(), receive.getPort());
                    ds.send(send);
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

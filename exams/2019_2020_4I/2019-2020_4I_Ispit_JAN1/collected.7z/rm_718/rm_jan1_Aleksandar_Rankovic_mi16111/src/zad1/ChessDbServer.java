package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

final class ChessDbServer {

    private int port;
    private Map<Integer, ChessPlayer> tabela = new HashMap<Integer, ChessPlayer>();


    ChessDbServer(int port){
        this.port = port;
    }

    public static void main(String[] args) {
        System.err.println("Hello from a guy that is wondering: where are my NIO questions - years of academy training wasted!");

        int port = 1996;

        ChessDbServer server = new ChessDbServer(port);
        server.execute();

    }

    private void execute(){
        try(ServerSocket server = new ServerSocket(port))
        {
            while(true){

                Socket client = server.accept();

                ClientThread clientThread = new ClientThread(client, this);
                clientThread.start();


            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized String getChessPlayer(int id) {
        if(this.tabela.containsKey(id))
            return this.tabela.get(id).toString();
        else
            return "nazalost zeljeni igrac ne postoji";
    }

    public synchronized void addChessPlayer(String word) {

        ChessPlayer chad = new ChessPlayer(word, 1300);
        int id = chad.getId();
        this.tabela.put(id, chad);
        //System.out.println(tabela.get(id).toString());
    }

    public synchronized void updateChesPlayer(int id, int delta) {


        if(this.tabela.containsKey(id))
            this.tabela.get(id).updateElo(delta);
        else
            System.out.println("pa gde ces update na praznu kolonu....");
    }
}

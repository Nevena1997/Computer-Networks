package zad1;

final class ChessPlayer {

    static int count = 1;
    // id
    int id;
    // naziv
    String naziv;
    // elo
    int elo;

    ChessPlayer(String naziv, int elo){
        this.id = count;
        this.naziv = naziv;
        this.elo = elo;
        count++;
    }

    public int getId() {
        return id;
    }

    public void updateElo(int delta){
        if(this.elo + delta < 1300)
            this.elo = 1300;
        else
            this.elo = this.elo + delta;
    }

    @Override
    public String toString() {
        // naziv: elo
        return naziv + ": " + elo;
    }
}

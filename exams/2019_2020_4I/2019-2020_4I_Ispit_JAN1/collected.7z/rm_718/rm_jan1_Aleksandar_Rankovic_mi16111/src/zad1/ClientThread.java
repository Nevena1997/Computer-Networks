package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

final class ClientThread extends Thread {

    private Socket client;
    private ChessDbServer server;
    private BufferedReader fromClient;
    private PrintWriter toClient;

    public ClientThread(Socket client, ChessDbServer server){
        this.client = client;
        this.server = server;

        try {
            fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
            toClient = new PrintWriter(client.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {


        try {
            while(true) {

                String command;

                command = fromClient.readLine();

                String[] words = command.split(" ");

                if(words[0].equalsIgnoreCase("sel")){
                    System.out.println("> " + command);

                    int id = Integer.parseInt(words[1]);

                    String chessyBoi = this.server.getChessPlayer(id);
                    System.out.println(chessyBoi);

                    toClient.println(chessyBoi);


                }else if(words[0].equalsIgnoreCase("ins")){

                    System.out.println("> " + command);

                    String naziv = command.substring(command.indexOf(' '));
                    this.server.addChessPlayer(naziv);
                    System.out.println("ins je uspesno izvrsen");
                    toClient.println("ins je uspesno izvrsen");

                }else if(words[0].equalsIgnoreCase("upd")){

                    System.out.println("> " + command);

                    int id = Integer.parseInt(words[1]);
                    int delta = Integer.parseInt(words[2]);
                    this.server.updateChesPlayer(id, delta);
                    System.out.println("upd je uspesno izvrsen");
                    toClient.println("upd je uspesno izvrsen");

                }else if(words[0].equalsIgnoreCase("bye")){
                    System.out.println("> " + command);
                    break;
                }else{
                    toClient.println("nista nije uspesno izvrseno");
                    continue;
                }


            }

            fromClient.close();
            toClient.close();
            client.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) {

        System.err.println("Hello from a guy that's gonna fail RS!");
        int port = 1996;
        String host = "localhost";

        try(Socket s = new Socket(host, port);
            Scanner sc = new Scanner(System.in);
            PrintWriter toServer = new PrintWriter(s.getOutputStream(), true);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(s.getInputStream()))){
/*
            Socket s = new Socket(host, port);
            Scanner sc = new Scanner(System.in);
            PrintWriter toServer = new PrintWriter(s.getOutputStream(), true);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(s.getInputStream()));*/


            String command;
            String response;
            while(true){

                command = sc.nextLine();

                toServer.println(command);

                response = fromServer.readLine();

                if(command.equalsIgnoreCase("bye"))
                    break;

                System.out.println(response);


            }
/*
            toServer.close();
            fromServer.close();
            s.close();
            sc.close();*/

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

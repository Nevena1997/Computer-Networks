package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) {
        try(DatagramSocket socket = new DatagramSocket()) {
            Scanner sc = new Scanner(System.in);
            System.out.printf("Unesite broj n: ");
            int n = sc.nextInt();
            byte[] buf = Integer.toString(n).getBytes();
            InetAddress address = InetAddress.getByName("localhost");
            DatagramPacket request = new DatagramPacket(buf, buf.length, address, 12345);
            socket.send(request);
            int i = 0;
            while(i < n){
                DatagramPacket response = new DatagramPacket(buf, buf.length);
                socket.receive(response);
                String line = new String(response.getData(), 0, response.getLength());
                System.out.println(line);
                i++;
            }
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

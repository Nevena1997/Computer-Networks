package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

final class FibServer {
    private static Integer[] niz = new Integer[80];
    private static boolean[] isCounted = new boolean[80];
    public static void main(String[] args) {
        try(DatagramSocket socket = new DatagramSocket(12345)) {
            while(true){
                byte[] buf = new byte[4];
                DatagramPacket request = new DatagramPacket(buf, buf.length);
                socket.receive(request);
                String text = new String(request.getData(), 0, request.getLength());
                int n = Integer.parseInt(text);
                System.out.println("Stigao datagram!");
                int i = 0;
                while(i < n){
                    int num;
                    if(!isCounted[i]) {
                        num = Fibonaci(i);
                        isCounted[i] = true;
                        niz[i] = num;
                    }
                    else {
                        num = niz[i];
                    }
                    byte[] bufToSend = Integer.toString(num).getBytes();
                    DatagramPacket response = new DatagramPacket(bufToSend, bufToSend.length, request.getAddress(), request.getPort());
                    socket.send(response);
                    i++;
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int Fibonaci(int n){
        if(n == 0) {
            niz[0] = 0;
            return 0;
        }
        if(n == 1) {
            niz[1] = 1;
            return 1;
        }
        return Fibonaci(n-1) + Fibonaci(n-2);
    }

}

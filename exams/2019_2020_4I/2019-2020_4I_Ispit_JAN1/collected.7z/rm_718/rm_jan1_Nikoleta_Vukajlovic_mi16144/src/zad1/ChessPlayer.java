package zad1;

final class ChessPlayer {
    private int IT = 1;
    private int id;
    private String naziv;
    private int elo;

    ChessPlayer(String naziv, int elo){
        this.naziv = naziv;
        this.elo = elo;
        this.id = IT++;
    }

    public int getId() {
        return id;
    }

    public int getElo() {
        return elo;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }

    @Override
    public String toString() {
        // naziv: elo
        return naziv + ": " + elo;
    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Map;

final class ClientThread extends Thread {
    private Socket client;
    private Map<Integer, ChessPlayer> playerMap;

    ClientThread(Map<Integer, ChessPlayer> playerMap, Socket client){
        this.playerMap = playerMap;
        this.client = client;
    }

    @Override
    public void run() {
        try(
            BufferedReader fromUser = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter toUser = new PrintWriter(new OutputStreamWriter(this.client.getOutputStream()))){

            String line;
            while(true){
                line = fromUser.readLine();
                String first = line.substring(0, line.indexOf(' '));
                if(first.equals("sel")){
                    Integer id = Integer.parseInt(line.substring(line.indexOf(' ')+1));
                    ChessPlayer player = playerMap.get(id);
                    String response = player.toString();
                    toUser.println(response);
                }
                if(first.equals("ins")) {
                    String name = line.substring(line.indexOf(' ')+1);
                    ChessPlayer player = new ChessPlayer(name, 1300);
                    playerMap.put(player.getId(), player);
                    toUser.println("ins je uspesno izvrsen");
                }
                else if(first.equals("upd")){
                    String secondPart = line.substring(line.indexOf(' ')+1);
                    int id = Integer.parseInt(secondPart.substring(0, ' '));
                    int deltae = Integer.parseInt(secondPart.substring(secondPart.indexOf(' ')+1));
                    ChessPlayer player = playerMap.get(id);
                    int elo = player.getElo() + deltae;
                    player.setElo(elo);
                    toUser.println("upd je uspesno izvrsen");
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

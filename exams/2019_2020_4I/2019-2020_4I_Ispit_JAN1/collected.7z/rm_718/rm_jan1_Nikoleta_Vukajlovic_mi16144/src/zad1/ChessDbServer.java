package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

final class ChessDbServer {

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(1996)) {
            Map<Integer, ChessPlayer> playerMap = new HashMap<>();
            while(true){
                Socket client = server.accept();
                new ClientThread(playerMap, client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

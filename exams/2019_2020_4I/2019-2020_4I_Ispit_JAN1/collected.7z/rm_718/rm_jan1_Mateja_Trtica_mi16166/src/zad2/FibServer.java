package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;

final class FibServer {
    static final int DEFAULT_PORT = 12345;
    int f0 = 0;
    int f1 = 1;
    DatagramSocket server;


    public static void main(String[] args) {
        FibServer srv = new FibServer();
        srv.execute();
        System.out.println("Hello from FibServer!");
    }
    void execute(){

        try {
            server = new DatagramSocket(DEFAULT_PORT);

            while(true){

                byte[] buffer = new byte[4];
                DatagramPacket req = new DatagramPacket(buffer,buffer.length);
                server.receive(req);
                if(req != null){
                    System.out.println("Stigao Datagram!");
                }

                String result = new String(req.getData(),0,req.getLength());
                int n = Integer.parseInt(result);
               int[] fibonaci = new int[n];
               fibonaci[0] = f0;
               fibonaci[1] = f1;
               int brojac = 2;
               while(brojac!=n){
                   fibonaci[brojac] = fibonaci[brojac-1] + fibonaci[brojac-2];
                   brojac++;
               }
               for(int i = 0;i < n ;i++){
                    byte[] buff = String.valueOf(fibonaci[i]).getBytes();
                    DatagramPacket sendFib = new DatagramPacket(buff,buff.length,req.getAddress(),req.getPort());
                    server.send(sendFib);
               }
            }

        } catch (SocketException e) {
            e.printStackTrace();
            server.close();

        } catch (IOException e) {
            e.printStackTrace();
            server.close();
        }


    }

}

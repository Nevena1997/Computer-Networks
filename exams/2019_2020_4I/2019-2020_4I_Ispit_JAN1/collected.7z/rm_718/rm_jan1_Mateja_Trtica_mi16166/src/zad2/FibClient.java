package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class FibClient {
    DatagramSocket socket;
    public static void main(String[] args) {
        FibClient clt = new FibClient();
        clt.execute();
        System.out.println("Hello from FibClient!");
    }
    void execute(){
        Scanner sc = new Scanner(System.in);
        byte[] buffer = sc.nextLine().getBytes();
        try {
           socket = new DatagramSocket();
            DatagramPacket req = new DatagramPacket(buffer,buffer.length,
                    InetAddress.getByName("localhost"),FibServer.DEFAULT_PORT);

            socket.send(req);
            byte[] buff = new byte[8];
            DatagramPacket response = new DatagramPacket(buff,buff.length);
            do{
                socket.receive(response);
                String msg = new String(response.getData(),0,response.getLength());
                System.out.println(msg);
            }while(response!=null);


        } catch (UnknownHostException e) {
            e.printStackTrace();
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
            socket.close();
        }

    }
}

package zad1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    Socket socket;
    public static void main(String[] args) {

        ChessDbClient client = new ChessDbClient();
        client.execute();
        System.out.println("Hello from ChessDbClient!");
    }
    private void execute(){

        try {
            socket = new Socket("localhost",ChessDbServer.DEFAULT_PORT);
            PrintWriter printer = new PrintWriter(socket.getOutputStream(), true);
            Scanner sc = new Scanner(System.in);
            String msg;
            do{
                msg = sc.nextLine();
                printer.println(msg);

            }while(!msg.equals("bye"));


        } catch (IOException e) {
//            socket.close();
            e.printStackTrace();
        }


    }
}

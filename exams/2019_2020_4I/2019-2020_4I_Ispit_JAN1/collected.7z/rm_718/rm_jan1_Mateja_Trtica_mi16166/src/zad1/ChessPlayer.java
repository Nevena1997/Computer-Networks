package zad1;

final class ChessPlayer {
    int id;// id
    String naziv;   // naziv
    int elo;// elo

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getElo() {
        return elo;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }

    ChessPlayer(int id, String naziv){
        this.id = id;
        this.naziv = naziv;
        this.elo = 1300;
    }
    @Override
    public String toString() {
        // naziv: elo
        return naziv+ ": " + elo;
    }
}

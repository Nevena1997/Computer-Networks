package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

final class ChessDbServer {

    static final int DEFAULT_PORT = 1996;
    Set<ClientThread> users;
    public static void main(String[] args) {
        ChessDbServer server = new ChessDbServer();
        server.execute();
        System.out.println("Hello from ChessDbServer!");
    }
    void execute(){

        try(ServerSocket srv = new ServerSocket(DEFAULT_PORT)){
            users = new HashSet<>();
            while(true) {
                Socket socketClt = srv.accept();
                ClientThread clt = new ClientThread(socketClt);
                clt.start();
                this.users.add(clt);
            }

        }catch(IOException e1){
            e1.printStackTrace();
        }

    }
}

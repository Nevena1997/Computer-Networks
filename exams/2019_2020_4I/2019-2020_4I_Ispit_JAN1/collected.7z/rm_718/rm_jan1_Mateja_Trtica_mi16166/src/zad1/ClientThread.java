package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

final class ClientThread extends Thread {
    // User thread for the ChessDbServer
    String op;
    String naziv;
    Socket client;
    static Set<ChessPlayer> sahisti = new HashSet<>();
    static AtomicInteger brojac = new AtomicInteger(1);
    ClientThread(Socket client){
        this.client = client;
    }
    @Override
    public void run() {
            try {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(client.getInputStream()));

                String msg;
                while ((msg = reader.readLine()) != null) {
                    if (msg.equals("bye")) {
                        break;
                    }
                    int i = msg.indexOf(" ");
                    op = msg.substring(0, i);
                    naziv = msg.substring(i + 1);
                    if (op.equals("ins")) {
                        synchronized (sahisti) {
                            ChessPlayer sahista = new ChessPlayer(brojac.intValue(), naziv);
                            sahisti.add(sahista);
                        }
                        brojac.getAndIncrement();
                    } else if (op.equals("sel")) {
                        int id_trazen = Integer.parseInt(naziv);
                        Iterator<ChessPlayer> it = sahisti.iterator();
                        while (it.hasNext()) {
                            ChessPlayer chessPlayer = it.next();
                            if (chessPlayer.id == id_trazen)
                                System.out.println(chessPlayer);
                        }

                    } else if (op.equals("upd")) {
                        synchronized (sahisti){
                        int indeks = naziv.indexOf(" ");
                        int id_trazen = Integer.parseInt(naziv.substring(0, indeks));
                        int vrednost = Integer.parseInt(naziv.substring(indeks + 1));
                        Iterator<ChessPlayer> it = sahisti.iterator();
                        while (it.hasNext()) {
                            ChessPlayer chessPlayer = it.next();
                            if (chessPlayer.id == id_trazen) {
                                int new_value = chessPlayer.getElo() + vrednost;
                                if (new_value < 1300)
                                    new_value = 1300;
                                chessPlayer.setElo(new_value);
                            }
                        }
                    }

                    }
                    System.out.println(op + " je uspesno izvrsen");
                }

            } catch (IOException e) {
                e.printStackTrace();
                try {
                    client.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
}

package zad2;

final class FibServer {
    public static void main(String[] args) {
        System.out.println("Hello from FibServer!");
    }
}

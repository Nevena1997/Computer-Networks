package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class ChessDbServer {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbServer!");

        ChessDbServer server = new ChessDbServer();
        server.runServer();
    }


    public static final int DEFAULT_PORT = 1996;
    private ArrayList<ChessPlayer> igraci = new ArrayList<>(50);

    ServerSocket serverSocket;


    private ChessDbServer() {
        try {
            serverSocket = new ServerSocket(DEFAULT_PORT);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed starting server");
        }
    }

    public void runServer() {

        igraci.add(new ChessPlayer(0, 1300, "Stefan"));

        ExecutorService pool = Executors.newFixedThreadPool(50);
        while(true) {
            try {
                Socket clientConnection = serverSocket.accept();
                pool.submit(new ClientHandlerThread(clientConnection));
            }
            catch (IOException e) {
                e.printStackTrace();
                System.err.println("Cant accept client");
            }

        }

    }


    final class ClientHandlerThread implements Runnable {
        // User thread for the ChessDbServer

        private Socket connection;

        ClientHandlerThread(Socket connection) {
            this.connection = connection;
        }

        public void run() {
            try(
                BufferedReader client_input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                BufferedWriter client_output = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
            ) {
                while (true) {
                    System.out.println("Loop entered");

                    String user_message =  client_input.readLine();
                   // if(user_message.trim().equalsIgnoreCase("bye")) break;

                    System.out.println("Msg recived: " + user_message);
/*
                    client_output.write("Test response");

*/



                   /* Pattern pattern = Pattern.compile("(sel|ins|upd) (([0-9]+)([a-zA-Z]+ [a-zA-Z]*))");
                    Matcher m = pattern.matcher(user_message);
                */
                }

            }
            catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

}

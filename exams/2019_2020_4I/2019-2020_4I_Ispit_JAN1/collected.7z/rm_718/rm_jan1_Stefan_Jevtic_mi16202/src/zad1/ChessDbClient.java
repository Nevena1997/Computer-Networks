package zad1;


import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Comparator;
import java.util.Scanner;
import java.util.regex.Pattern;

final class ChessDbClient  {
    public static void main(String[] args) {
        System.out.println("Hello from ChessDbClient!");
        try {
            ChessDbClient client1 = new ChessDbClient(InetAddress.getLocalHost(), ChessDbServer.DEFAULT_PORT);
            client1.startClient();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Socket serverConnection;

    public ChessDbClient(Socket serverConnection) {
        this.serverConnection = serverConnection;
    }

    public ChessDbClient(InetAddress host, int port) {
        try {
            this.serverConnection = new Socket(host, port);
        }
        catch (IOException e) {
            e.printStackTrace();
            System.err.println("Connectig to server failed");
        }
    }


    public void startClient () {
        try(BufferedWriter server_output_stream = new BufferedWriter(new OutputStreamWriter(serverConnection.getOutputStream()))) {
            int i = 0;
            while(true) {
                server_output_stream.write("teststs");
                server_output_stream.flush();
            }



        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}

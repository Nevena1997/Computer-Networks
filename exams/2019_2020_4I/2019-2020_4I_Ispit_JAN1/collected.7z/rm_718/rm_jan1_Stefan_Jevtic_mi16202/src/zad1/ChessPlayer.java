package zad1;

final class ChessPlayer {
    // id
    // naziv
    // elo

    private final int id;
    private int elo;
    private final String naziv;

    @Override
    public String toString() {
        // naziv: elo
        return super.toString();
    }


    public ChessPlayer(int id, int elo, String naziv) {
        this.id = id;
        this.elo = elo;
        this.naziv = naziv;
    }

    int changeElo(int eloChange) {
       return this.elo += eloChange;
    }


    int getElo() {
        return this.elo;
    }
    String getNaziv() {
        return this.naziv;
    }





}


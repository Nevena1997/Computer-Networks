package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

final class FibServer {

    public static final int PORT = 12345;

    public static void main(String[] args) throws IOException {

        DatagramSocket server = new DatagramSocket(PORT);

        while(true){
            byte[] data = new byte[4];
            DatagramPacket reciever = new DatagramPacket(data,data.length);
            server.receive(reciever);

            System.out.println("Stigao datagram!");

            int n = data[0];

            long[] fib = Fibonaci(n);

            byte[] data1 = new byte[8];

            for(int i = 0;i < n;i++){
                data1[0] = (byte)fib[i];
                DatagramPacket sender = new DatagramPacket(data1,data1.length,reciever.getAddress(),reciever.getPort());
                server.send(sender);
            }

        }

    }

    public static long[] Fibonaci(int n){

        long[] a = new long[n];

        a[0] = 1;
        a[1] = 1;

        for(int i=2;i<n;i++){
            a[i]= a[i-1] + a[i-2];
        }

        return a;
    }
}



package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

final class FibClient {
    public static void main(String[] args) throws IOException {
        InetAddress addr = InetAddress.getLocalHost();


        DatagramSocket client = new DatagramSocket();

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();


        byte[] data = new byte[4];

        data[0] = (byte) n;


        DatagramPacket sender = new DatagramPacket(data, data.length,addr,FibServer.PORT);
        client.send(sender);

        byte[] data1 = new byte[8];

        while(true){
            DatagramPacket reciever = new DatagramPacket(data1,data1.length);
            client.receive(reciever);
            int a = data1[0];
            System.out.println(a);

        }


    }
}

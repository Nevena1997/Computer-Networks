package zad1;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

final class ClientThread extends Thread {

    private BufferedReader br ;
    private BufferedWriter bw;
    public ArrayList<ChessPlayer> igraci;

    public ClientThread(Socket s) throws IOException {
       this.br = new BufferedReader(new InputStreamReader(s.getInputStream()));
       this.bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
       this.igraci = new ArrayList<>();

    }

    public void run(){
        try {
            while (true) {

                String com = br.readLine();

                Scanner sc = new Scanner(com);

                String com1 = sc.next();

                if(com1.trim().equalsIgnoreCase("ins")){
                    String  naziv = sc.nextLine();
                    this.igraci.add(new ChessPlayer(this.igraci.size() + 1,naziv,1300));
                    bw.write("Ins je uspesno izvrsen");
                    bw.newLine();
                    bw.flush();
                }

                if(com1.trim().equalsIgnoreCase("sel")){
                    int id1 = sc.nextInt();
                    for(ChessPlayer igrac:this.igraci){
                        if(igrac.id == id1 ){
                            bw.write(igrac.toString());
                            bw.newLine();
                            bw.flush();
                        }
                    }

                }

                if(com1.trim().equalsIgnoreCase("upd")) {
                    int id1 = sc.nextInt();
                    int elo = sc.nextInt();

                    for(ChessPlayer igrac: this.igraci){
                        if(igrac.id == id1){
                            igrac.elo += elo;
                            if(igrac.elo < 1300){
                                igrac.elo = 1300;
                            }
                        }
                    }

                    bw.write("upd je uspesno izvrsen");
                    bw.newLine();
                    bw.flush();
                }

                if(com1.trim().equalsIgnoreCase("bye")){
                    bw.write("bye");
                    bw.newLine();
                    bw.flush();
                    break;
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}

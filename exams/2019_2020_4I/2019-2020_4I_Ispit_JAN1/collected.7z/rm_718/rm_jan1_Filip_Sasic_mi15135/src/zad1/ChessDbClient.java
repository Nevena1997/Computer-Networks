package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

final class ChessDbClient {
    public static void main(String[] args) throws IOException {

        Socket client = new Socket("localhost",ChessDbServer.PORT);

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));

        Scanner sc = new Scanner(System.in);
        String com = "";

        while(!com.trim().equalsIgnoreCase("bye")){

           com =  sc.nextLine();

//            if (!(com.equalsIgnoreCase("sel") || com.equalsIgnoreCase("ins") || com.equalsIgnoreCase("upd"))) {
//                System.out.println("Pogresna komanda !");
//                break;
//            }
//
           bw.write(com);
           bw.newLine();
           bw.flush();
           String response  = br.readLine();
           System.out.println(response);

        }
    }
}

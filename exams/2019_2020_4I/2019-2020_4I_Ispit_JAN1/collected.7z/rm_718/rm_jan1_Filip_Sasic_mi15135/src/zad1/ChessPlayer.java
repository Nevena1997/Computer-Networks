package zad1;

final class ChessPlayer {
    public int id;
    public String naziv;
    public int elo;

    public ChessPlayer(int id, String naziv, int elo) {
        this.id = id;
        this.naziv = naziv;
        this.elo = elo;
    }

    @Override
    public String toString() {
        return naziv + ": " + this.elo;
    }
}

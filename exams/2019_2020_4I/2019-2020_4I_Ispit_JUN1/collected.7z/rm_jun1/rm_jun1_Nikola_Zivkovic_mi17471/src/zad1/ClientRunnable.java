package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientRunnable implements Runnable{

    ForumServer server;
    Socket client;
    BufferedReader in;

    public ClientRunnable(ForumServer forumServer, Socket client) throws IOException {

        this.server = forumServer;
        this.client = client;
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));

    }

    @Override
    public void run() {

        try {
                String line = this.in.readLine();
                //System.err.println("Linija");
                //System.err.println(line);

               if(line.equalsIgnoreCase("list"))
                   this.server.list();
               else if(line.startsWith("reply")){

               }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

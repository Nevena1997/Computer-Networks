package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

class ForumClient {
    public static void main(String[] args) {

        System.out.println("Hello from ForumClient!");

        ForumClient client = new ForumClient();
        client.execute();
    }

    private void execute() {

        try (Socket socket = new Socket("localhost", 7337)) {
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream()));


            ClientWriteThread w = new ClientWriteThread(this, out);
            w.start();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

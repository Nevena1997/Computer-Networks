package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


class ForumServer {

    private Map<Integer, Map<String, ArrayList<String>>> topics;

    ForumServer(){
        this.topics = new HashMap<>();
    }

    public static void main(String[] args) {

        ForumServer server = new ForumServer();
        server.execute();


    }

    private void execute() {

        System.out.println("Hello from ForumServer!");

        try(ServerSocket serverSocket = new ServerSocket(7337)){

            while (true){

                Socket client = serverSocket.accept();
                System.out.printf("Client accepted.");

                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

                new Thread(new ClientRunnable(this, client)).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map<Integer, Map<String, ArrayList<String>>> getTopics() {
        return topics;
    }

    public void setTopics(Map<Integer, Map<String, ArrayList<String>>> topics){
        this.topics = topics;
    }

    public void list() {
        System.out.println(topics);
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
public class ClientWriteThread extends Thread{

    BufferedWriter out;
    ForumClient client;

    public ClientWriteThread(ForumClient socket, BufferedWriter out) {
        this.client = socket;
        this.out = out;
    }

    @Override
    public void run() {
        String line;
        BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            try {
                if (!((line = sc.readLine()) != null)) break;

                this.out.write(line);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

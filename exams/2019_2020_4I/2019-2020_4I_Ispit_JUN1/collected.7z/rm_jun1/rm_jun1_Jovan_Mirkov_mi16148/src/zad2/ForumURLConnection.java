package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */


    private int port;
    private Socket sock;

    ForumURLConnection(URL u) {
        super(u);
    }

    @Override
    public synchronized void connect() throws IOException {
        this.port = url.getPort();
        if (this.port < 0 || this.port > 65535)
            this.port = 7337;

        this.sock = new Socket(url.getHost(), this.port);

        this.connected = true;

        BufferedReader in = new BufferedReader(new InputStreamReader(this.getInputStream()));

        String upit = url.getQuery();


        //...


    }

    public synchronized InputStream getInputSteam() throws IOException {

        if (!connected)
            return null;


        return sock.getInputStream();


    }

}

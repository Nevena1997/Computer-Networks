package zad2;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {


        try (Scanner sc = new Scanner(System.in)) {

            System.out.println("URL: \n");
            String line = sc.nextLine();


            try {
                URL url = new URL(null, line, new Handler());



            //...


            } catch (MalformedURLException e) {
                e.printStackTrace();
            }


        }


    }
}

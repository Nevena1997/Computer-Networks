package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

class ForumServer {


    public static void main(String[] args) {


        try (ServerSocket ss = new ServerSocket(7337)) {


            while (true) {

                Socket client = ss.accept();
                System.err.println("klijent primljen");
                ClientThread clientThread = new ClientThread(client);
                clientThread.start();

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}



package zad1;

import java.io.*;
import java.net.Socket;
import java.util.*;

public class ClientThread extends Thread {


    static List<Tema> teme = new LinkedList();

    private Socket client = null;

    public ClientThread(Socket client) {
        this.client = client;
    }


    void list(BufferedWriter out) throws IOException {

        for (Tema tema : teme) {
            out.write(tema.getId() + ": " + tema.getTitle() + "\n\r");
            out.flush();
            for (String odgovor : tema.getOdgovori()) {
                out.write("-" + odgovor + "\n"); //ne radi
                out.flush();
            }


        }

    }

    synchronized void reply(int id, String content) {
        //uzasno resenje ali gotovo sad kad sam se zapetljao
        for (Tema tema : teme) {
            if (tema.getId() == id) {
                tema.getOdgovori().add(content);
            }
        }

    }

    synchronized void post(String title, String content) {
        teme.add(new Tema(title, content));

    }


    @Override
    public void run() {

        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        ) {

            String line;
            while ((line = in.readLine()) != null) {

                if (line.equals("list")) {
                    this.list(out);
                }
                if (line.startsWith("reply")) {
                    String[] delovi = line.split(" ");

                    if (delovi.length != 3) {
                        out.write("nevalidan format\n");
                        out.flush();
                    }

                    this.reply(Integer.parseInt(delovi[1]), delovi[2]);
                    out.write("reply je uspesno izvrsen\n");
                    out.flush();

                }
                if (line.startsWith("post")) {
                    String[] delovi = line.split(" ");

                    if (delovi.length != 3) {
                        out.write("nevalidan format\n");
                        out.flush();
                    }

                    this.post(delovi[1], delovi[2]);




                    out.write("post je uspesno izvrsen\n");
                    out.flush();

                }


            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}






package zad1;

import java.util.LinkedList;
import java.util.List;

public class Tema {


    public static int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public List<String> getOdgovori() {
        return odgovori;
    }

    private static int id = 1;
    private String title;
    private List<String> odgovori = new LinkedList<>();

    public Tema(String title, String prvi) {
        this.id = id++;
        this.title = title;
        this.odgovori.add(prvi);
    }
}

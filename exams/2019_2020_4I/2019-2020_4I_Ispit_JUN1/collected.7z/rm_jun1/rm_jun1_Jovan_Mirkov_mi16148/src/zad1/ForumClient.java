package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {

        System.out.println("Hello from ForumClient!");

        try (
                Socket sock = new Socket("localhost", 7337);



        ) {

            try(Scanner sc = new Scanner(System.in);
                BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));) {
                while (true) {
                    String line = sc.nextLine();

                    if(line.equalsIgnoreCase("bye")){
                        break;
                    }

                    //mozda nije najsigurnija provera sa startsWith ali je nabrza :D
                    if(line.startsWith("list") || line.startsWith("reply") || line.startsWith("post")){


                        out.write(line);
                        out.write("\r");
                        out.write("\n");
                        out.flush();

                    }
                    else{
                        System.err.println("Nevalidan format");
                    }


                    String response = in.readLine();
                    //greska, ispisuje se samo prva linija kod list,
                    // moze se resiti kontinuiranim string builderom dok ne dodje do null nextLine
                    System.out.println(response);

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {

        try(Socket sock = new Socket("localhost", ForumServer.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));){

            while(true){
                String req = sc.nextLine();

                String[] line = req.split(" ");

                if( (line.length == 1 && (line[0].equals("list") || line[0].equals("bye"))) ||
                        ( line.length >= 3 &&
                          ((line[0].equals("reply") ) || //&& line[2].matches("[1-9][0-9]*")) ||
                            line[0].equals("post"))
                        )
                ){
                    //System.out.println("Command recognized.");
                    out.write(req + "\n");
                    out.flush();


                    String response;
                    while((response = in.readLine()) != null){
                        System.out.println(response);
                    }

                    if(req.equals("bye")){
                        break;
                    }
                } else {
                    System.out.println("nevalidan format");
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.util.ArrayList;
import java.util.List;

public class ForumThread {
    private int id;
    private String title;
    private String firstPost;
    private List<String> replies = new ArrayList<String>();

    public ForumThread(int id, String title, String firstPost){
        this.id = id;
        this.title = title;
        this.firstPost = firstPost;
    }

    public synchronized void addReply(String reply){
        replies.add(reply);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(id + ": " + title + "\n");
        sb.append("# " + firstPost + "\n");
        for(String reply : replies){
            sb.append("- " + reply + "\n");
        }

        return sb.toString();
    }
}

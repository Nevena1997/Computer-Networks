package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

class ForumServer {
    public static final int PORT = 7337;
    private static HashMap<Integer,ForumThread> list = new HashMap<Integer, ForumThread>();
    private static int idCounter = 1;

    public static void main(String[] args) {
        
        System.out.println("Hello from ForumServer!");

        ForumServer server = new ForumServer();
        server.execute();
    }

    public void execute(){
        try (ServerSocket server = new ServerSocket(PORT);) {
            while(true){
                Socket client = server.accept();
                System.out.println("Client accepted.");

                new UserThread(this, client, list).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void post(String title, String content){
        list.put(idCounter, new ForumThread(idCounter, title, content));
        idCounter++;
    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;

public class UserThread extends Thread{

    private final Socket client;
    private final ForumServer server;
    private HashMap<Integer, ForumThread> list;

    public UserThread(ForumServer server, Socket client, HashMap<Integer,ForumThread> list){
        this.list = list;
        this.server = server;
        this.client = client;
    }

    @Override
    public void run(){

        try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));){


            /* Napomena: string se splituje tkd je naslov uvek jedna rec,
               a prvi post sve ostalo jer nisam videla format na vreme */

            String req;
            while((req = in.readLine()) != null) {
                String[] line = req.split(" ");
                if(line[0].trim().equals("list")){
                    StringBuilder sb = new StringBuilder();
                    for(Integer key :list.keySet()) {
                        sb.append(list.get(key).toString());
                    }
                    out.write(sb.toString());
                    out.flush();
                } else if(line[0].trim().equals("reply")){
                    if(list.containsKey(Integer.parseInt(line[1]))) {
                        list.get(Integer.parseInt(line[1])).addReply(getLineAfterWord(2, line));
                        out.write("reply je uspesno izvrsen\r\n");
                        out.flush();
                    } else{
                        out.write("nevalidan id teme\r\n");
                        out.flush();
                    }
                } else if(line[0].trim().equals("post")){
                    server.post(line[1].trim(), getLineAfterWord(2, line));
                    out.write("post je uspesno izvrsen\r\n");
                    out.flush();
                } else if(line[0].trim().equals("bye")){
                    break;
                }

                System.out.println(req);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String getLineAfterWord(int index, String[] line){
        StringBuilder sb = new StringBuilder();
        for(int i=index; i<line.length; i++){
            sb.append(line[i]).append(" ");
        }
        return sb.toString();
    }

}

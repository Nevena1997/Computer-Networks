package zad2;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        if(!connected){
            //TODO
            URLConnection u = url.openConnection();
        }
    }
}

package zad1;

import java.io.*;
import java.net.Socket;

public class UserThread extends Thread{
    private Socket client;
    private ForumServer server;

    UserThread(Socket client, ForumServer server) {
        this.client = client;
        this.server = server;
    }

    @Override
    public void run() {
        try (BufferedReader fromUser = new BufferedReader(
                    new InputStreamReader(this.client.getInputStream()));
             BufferedWriter toUser = new BufferedWriter(
                     new OutputStreamWriter(this.client.getOutputStream())
             )
        ) {
            while (true){

                // Primamo ulaz od usera
                String userMsg = fromUser.readLine();
                if (userMsg == null) {
                    break;
                }

                // Parsiramo ga
                String request = userMsg;


                if(request.equals("reply")){
                    // TODO: obradi reply
                        // da li je sledeci token id
                        // da li je sledeci token "String"
                        // ako jeste
                            // => dodaj odgovor na temu odredjenu sa id
                } else if (request.equals("post")) {
                    // TODO: obradi post
                } else if (request.equals("list")) {
                    // TODO: obradi list
                    this.server.listThemes();
                } else if (request.equals("bye")) {
                    // TODO: obradi bye
                } else {
                    // TODO: obradi nevalidan ulaz
                }

                // saljemo korisniku odgovor
                toUser.write("[Server]: " + userMsg);
                toUser.newLine();
                toUser.flush();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

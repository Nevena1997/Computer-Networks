package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.regex.Pattern;

class ForumClient {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", ForumServer.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedWriter toServer = new BufferedWriter(
                     new OutputStreamWriter(client.getOutputStream())
            );
             BufferedReader fromServer = new BufferedReader(
                     new InputStreamReader(client.getInputStream())
             )
        ) {

            System.out.println("Connected to the server");

            // Citamo poruku sa stdin koju korisnik zeli da posalje serveru
            String userMsg = null;

            while (true) {

                userMsg = sc.nextLine();

                toServer.write(userMsg);
                toServer.newLine();
                toServer.flush();

                // Primamo od servera odgovor na zahtev

                System.out.println(fromServer.readLine());

            }



        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Hello from ForumClient!");

    }

    private static boolean isValid(String userMsg) {

        if (isList(userMsg) || isReply(userMsg) || isPost(userMsg))
            return true;
        else
            return false;
    }

    private static boolean isPost(String userMsg) {
        return false;
    }

    private static boolean isReply(String userMsg) {
        return false;
    }

    private static boolean isList(String userMsg) {
        if (userMsg.equals("list"))
            return true;
        else
            return false;
    }
}

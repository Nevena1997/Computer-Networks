package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.util.*;

class ForumServer {
    public static final int PORT = 7337;

    private int port;
    private List<ForumTeme> teme = new LinkedList<>();

    ForumServer(int port) {
        this.port = port;
    }

    public static void main(String[] args) {
        ForumServer forumServer = new ForumServer(PORT);
        forumServer.execute();
    }

    private void execute() {
        try (ServerSocket server = new ServerSocket(PORT)
        ) {

            while (true) {
                Socket client = server.accept();
                System.out.println("New client accepted");

                UserThread user = new UserThread(client, this);
                user.start();
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void listThemes() {
        this.teme.stream()
                .forEach(u -> u.toString());
    }
    public void addTheme(String title) {

    }
}

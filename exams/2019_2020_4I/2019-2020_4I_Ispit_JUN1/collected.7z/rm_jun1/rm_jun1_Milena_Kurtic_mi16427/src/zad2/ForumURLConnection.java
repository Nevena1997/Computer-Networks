package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    public static final int DEFAULT_PORT = 7337;
    private Socket connection;

    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if (!this.connected){
            this.connect();
        }
        return this.connection.getInputStream();
    }

    @Override
    public void connect() throws IOException {
        if(!this.connected){
            Scanner sc = new Scanner(System.in);
            String line;
            while ((line = sc.nextLine()) != null){
                //sa ulaza uzimam host i port
                int i = line.lastIndexOf('/');
                int i2 = line.lastIndexOf(':');

                String host = line.substring(i + 1, i2);
                String port = line.substring(i2+2, line.indexOf('?'));
                connection = new Socket(host, Integer.valueOf(port));
                PrintWriter out = new PrintWriter(connection.getOutputStream());
                out.println(line);
               //
                this.connected = true;
            }







        }


    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException{

        URL u = new URL(null, "forum://localhost", new Handler());
        var conn = u.openConnection();
        try(BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))){
            String line;
            while ((line = in.readLine()) != null){
                System.out.println(line);
            }
        }catch (IOException e){
            e.printStackTrace();
        }


        //System.out.println("Hello from protocol test method!");
    }
}

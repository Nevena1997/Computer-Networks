package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

class ForumServer {

    public static final int DEFAULT_PORT = 7337;

    private int port;
    private Set<UserThread> users = new HashSet<>();
    private HashMap<Integer, String> mapa = new HashMap<>();


    ForumServer(int port){
        this.port = port;
    }

    public static void main(String[] args) {
        //System.out.println("Hello from ForumServer!");
        ForumServer server = new ForumServer(DEFAULT_PORT);

        server.execute();

    }

    public void execute(){
        try (ServerSocket serverSocket =  new ServerSocket(this.port)){
            System.err.println("Server je spreman da primi klijente");

            while (true) {
                Socket client = serverSocket.accept();
                System.err.println("Registrovan je klijent");
                UserThread user = new UserThread(client, this);
                this.users.add(user);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void broadcast(String message, UserThread except){
        this.users.stream().filter(u -> u != except).forEach(u -> u.sendMessage(message));
    }

    public  void remove(UserThread user){
        this.users.remove(user);

    }
    public HashMap<Integer, String> getMapa() {
        return mapa;
    }

    public void staviVrednostUMapu(Integer i, String s){
        this.mapa.put(i, s);
    }
}

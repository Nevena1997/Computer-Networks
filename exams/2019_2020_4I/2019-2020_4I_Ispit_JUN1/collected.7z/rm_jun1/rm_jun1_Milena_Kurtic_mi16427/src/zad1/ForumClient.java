package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

class ForumClient {
    private int port;
    private PrintWriter toServer;
    private BufferedReader fromServer;

    public static void main(String[] args) {
        ForumClient client = new ForumClient(ForumServer.DEFAULT_PORT);
        //System.out.println("Hello from ForumClient!");
        client.execute();
    }
    ForumClient(int port){
        this.port = port;

    }
    public void execute(){
        try(Socket client = new Socket("localhost", this.port)) {
            toServer = new PrintWriter(client.getOutputStream(), true);
            fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
            String line;
            String poruka;
            int nevalidanFormat = 0;
            while (true){
                line = sc.readLine();
                if (line == null){
                    continue;
                }


                int ind1 = line.indexOf(' ');
                if (ind1 < 0 && line.length() > 0){
                    if (line.trim().equalsIgnoreCase("list")){
                        System.out.println("printing...");
                        // u ovom slucaju prosla je list naredba
                        toServer.println(line);
                    }else {

                        nevalidanFormat = nevalidanFormat + 1;
                    }
                }else {
                    String naredba = line.substring(0, ind1);
                    if(naredba.equalsIgnoreCase("list")){

                        nevalidanFormat = nevalidanFormat + 1;
                    }
                    if(!naredba.trim().equalsIgnoreCase("replay") || !naredba.trim().equalsIgnoreCase("post")){

                        nevalidanFormat = nevalidanFormat + 1;
                    }

                    String ostatak = line.substring(ind1 + 1, line.length());
                    int ind2 = ostatak.indexOf(' ');

                    if (ind2 < 0 && ostatak.length() > 0){
                        // ovde imamo naredbu i jedan arg sto nije dobar format
                        nevalidanFormat = nevalidanFormat + 1;
                    }
                    String arg1 = ostatak.substring(0, ind2);
                    String arg2 = ostatak.substring(ind2, ostatak.length());
                    System.out.println(naredba);
                    System.out.println(arg1);
                    System.out.println(arg2);
                    if (nevalidanFormat > 0){
                        System.out.println("Nevalidan format");
                    }else{

                        toServer.println(line);
                    }

                }


                if (line.equalsIgnoreCase("bye")){
                    break;
                }
                toServer.println(line);
                poruka = fromServer.readLine();
                //System.out.println(poruka);
            }
            toServer.close();
            fromServer.close();
            //client.close();

        }catch (IOException e){
            e.printStackTrace();
        }


    }

}

package zad1;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


public class UserThread extends Thread {
    private Socket sock;
    private ForumServer server;
    private PrintWriter toClient;
    private BufferedReader fromClient;



    UserThread(Socket sock, ForumServer server){
        this.sock = sock;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            toClient = new PrintWriter(sock.getOutputStream(), true);
            fromClient = new BufferedReader(new InputStreamReader(this.sock.getInputStream()));
            String clientMessage ;
            //System.out.println(clientMessage);
            while (true) {
                clientMessage = fromClient.readLine();
                System.out.println("Ovde je nesto radjeno");
                toClient.println("Poruka za klijenta");
                if (clientMessage.equalsIgnoreCase("bye")){
                    break;
                }

            }
            toClient.close();
            fromClient.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String message){
        if(message != null) {
            toClient.println(message);
        }
    }
}

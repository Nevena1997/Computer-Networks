package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {

    private Socket connection = null;
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port = url.getPort();
            String host = url.getHost();
            connection = new Socket(host, port);
            if(connection == null)
                System.out.println("Neuspela konekcija");

            String req = url.toString();
            String q = req.substring(req.indexOf('=')+1);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));

                bw.write(q);
                bw.newLine();
                bw.flush();

        }
        this.connected = true;
        System.out.println("Konekcija je uspela");
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected)
            this.connect();
        return connection.getInputStream();
    }

    @Override
    public String getContentType() {
        return "text/plain";
    }
}

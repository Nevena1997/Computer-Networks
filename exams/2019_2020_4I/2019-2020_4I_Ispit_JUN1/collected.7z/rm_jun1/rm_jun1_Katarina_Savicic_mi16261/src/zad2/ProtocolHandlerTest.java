package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        System.out.println("Hello from protocol test method!");

        try {
            URL url = new URL(null, "forum://localhost:7337?q=list", new Handler());

            URLConnection conn = url.openConnection();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line = null;
            while((line = br.readLine())!=null)
                System.out.println(line);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

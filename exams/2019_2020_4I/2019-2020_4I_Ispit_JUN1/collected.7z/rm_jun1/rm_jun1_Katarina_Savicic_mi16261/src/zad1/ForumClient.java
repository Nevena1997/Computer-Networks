package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {
        System.out.println("Hello from ForumClient!");

        try(Socket client = new Socket("localhost", ForumServer.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

            String line  = null;
            while(sc.hasNext()) {

                int id ;
                String con = null;
                String t = null;

                line = sc.nextLine();
                String[] niz = line.split(" ");

                if(line.equalsIgnoreCase("bye")) {
                    break;
                }
                if ((niz[0].equalsIgnoreCase("list"))) {
                    bw.write(line);
                    bw.newLine();
                    bw.flush();
                }
                else if (niz[0].equalsIgnoreCase("reply")){
                    if(niz.length==3) {
                        bw.write(line);
                        bw.newLine();
                        bw.flush();
                    } else
                        System.err.println("Unos nije korektan");
                }
                else if(niz[0].equalsIgnoreCase("post"))
                {
                    if(niz.length==3) {
                        bw.write(line);
                        bw.newLine();
                        bw.flush();
                    } else
                        System.err.println("Unos nije korektan");
                }
                else
                    System.err.println("Unos nije korektan");

                String resp = null;
                while((resp=br.readLine())!=null)
                    System.out.println(resp);
            }



        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

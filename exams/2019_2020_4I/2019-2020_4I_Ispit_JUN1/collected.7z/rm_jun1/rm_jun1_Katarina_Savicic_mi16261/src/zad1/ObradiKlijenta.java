package zad1;

import java.io.*;
import java.net.Socket;

public class ObradiKlijenta extends Thread {

    private Socket client;

    public ObradiKlijenta(Socket klijent) {
        this.client = klijent;
    }

    @Override
    public void run() {

        try(BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            String line = null;
            while((line = br.readLine())!=null)
            {
                String [] niz = line.split(" ");
                if ((niz[0].equalsIgnoreCase("list"))) {
                    bw.write("list zahtev je prihvacen");
                    bw.newLine();
                    bw.flush();
                }
                else if (niz[0].equalsIgnoreCase("reply")){
                    if(niz.length==3) {
                        String con = line.substring(niz[0].length()+niz[1].length()+2);
                        int id = Integer.parseInt(niz[1]);

                        bw.write("reply zahtev je prihvacen");
                        bw.newLine();
                        bw.flush();
                    }else
                    {
                        bw.write("Zahtev nije prihvacen");
                        bw.newLine();
                        bw.flush();
                    }
                }
                else if(niz[0].equalsIgnoreCase("post"))
                {
                    if(niz.length==3) {
                        String con = line.substring(niz[0].length()+niz[1].length()+2);
                        String title = niz[1];
                        bw.write("post zahtev je prihvacen");
                        bw.newLine();
                        bw.flush();
                    }else
                    {
                        bw.write("Zahtev nije prihvacen");
                        bw.newLine();
                        bw.flush();
                    }
                }
                else
                {
                    bw.write("Zahtev nije prihvacen");
                    bw.newLine();
                    bw.flush();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

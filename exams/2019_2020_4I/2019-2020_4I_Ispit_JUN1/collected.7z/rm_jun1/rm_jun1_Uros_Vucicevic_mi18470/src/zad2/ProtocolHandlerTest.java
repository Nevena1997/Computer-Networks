package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)){

            String in = sc.nextLine().trim();

            URL u = new URL(null,in, new Handler());


            URLConnection connection = u.openConnection();

            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));


            while((in =br.readLine())!=null){
                System.out.println(in);
            }

        } catch (MalformedURLException e) {
            System.err.println("nevalidan format");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Neuspela konekcija.");
            System.exit(1);
        }


        //System.out.println("Hello from protocol test method!");
    }
}

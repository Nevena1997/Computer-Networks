package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    private Socket client;

    ForumURLConnection(URL url) {
        super(url);
    }


    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if(this.connected)
            return this.client.getInputStream();
        return null;
    }

    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port = url.getPort();
            if (port<1 || port>65536)
                port = url.getDefaultPort();

            client = new Socket(url.getHost(),port);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
            bw.write("list");
            bw.newLine();
            bw.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(this.client.getInputStream()));



            this.connected = true;


        }
    }
}

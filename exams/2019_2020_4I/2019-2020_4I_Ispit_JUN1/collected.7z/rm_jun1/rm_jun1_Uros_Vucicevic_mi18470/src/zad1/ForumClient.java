package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {


        try (Socket client = new Socket(InetAddress.getLoopbackAddress(), ForumServer.PORT);
        Scanner sc = new Scanner(System.in)) {

            while(true) {
                String first = sc.nextLine();

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));

                if (first.startsWith("list")) {

                    writer.write("list");
                    writer.newLine();
                    writer.flush();

                    String s;

                    while((s=reader.readLine())!=null)
                        System.out.println(s);

                } else if (first.startsWith("reply")) {

                    String[] tokens = first.split(" ");
                    try {
                        int id = Integer.parseInt(tokens[1]);
                        String content = first.substring(6 + tokens[1].length());

                        writer.write("replay");
                        writer.newLine();
                        writer.write(id);
                        writer.newLine();
                        writer.write(content);
                        writer.newLine();

                        System.out.println("reply je uspesno izvrsen");
                    }
                    catch (Exception e){
                        System.err.println("nevalidan format");
                    }

                } else if (first.startsWith("post")) {

                    try {
                        int fiq = first.indexOf('"', 0);
                        int sq = first.indexOf('"', fiq+1);
                        int tq = first.indexOf('"', sq+1);
                        int ftq = first.indexOf('"', tq+1);

                        String title = first.substring(fiq+1,sq);
                        String content = first.substring(tq+1,ftq);

                        writer.write("post");
                        writer.newLine();
                        writer.write(title);
                        writer.newLine();
                        writer.write(content);
                        writer.newLine();
                        writer.flush();

                        System.out.println("post je uspesno izvrsen");

                    }
                    catch (Exception e) {
                        System.err.println("nevalidan format");
                    }



                } else if(first.startsWith("bye")){
                    break;
                }else {
                    System.out.println("nevalidan format");
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

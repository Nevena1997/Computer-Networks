package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Iterator;

public class DoSomething extends Thread {

    private Socket client;

    public DoSomething(Socket client) {
        this.client = client;
    }

    @Override
    public synchronized void run() {

        while(true){
            try (BufferedReader br = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
                 BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));){


                String in;

                while((in=br.readLine())!=null){
                    if (in.startsWith("list")){

                        if(ForumServer.mapa.size()>0) {

                            Iterator it = ForumServer.mapa.keySet().iterator();
                            //Integer[] a = (Integer[]) ForumServer.mapa.keySet().toArray();
                            int begin = 1;
                            while (it.hasNext()) {
                                //Integer i = Integer.valueOf(a[begin++]);
                                String[] tokens = ForumServer.mapa.get(begin).split("\n");
                                String s = begin + ": " + tokens[0] + "\n";
                                bw.write(s);
                                bw.flush();
                                for (int j = 1; j < tokens.length; j++){
                                    bw.write("\t" + tokens[j] + "\n");
                                    bw.flush();
                                }

                                begin++;
                                it.next();
                            }
                        }
                        else{
                            bw.newLine();
                            bw.flush();
                        }
                    }else if(in.startsWith("reply")){
                        int id = Integer.parseInt(br.readLine().trim());
                        String content = br.readLine().trim();

                        if(ForumServer.mapa.containsKey(id)) {
                            String s = ForumServer.mapa.get(id);
                            s+= '\n' + "- " + content;
                            ForumServer.mapa.put(id,s);
                        }


                    }else if(in.startsWith("post")){
                        String title = br.readLine().trim();
                        String content = br.readLine().trim();

                        String s = title + '\n' + '#' + content;
                        ForumServer.mapa.put(ForumServer.index++,s);
                    }
                }



            } catch (IOException e) {
                System.exit(1);
            }
        }

    }
}

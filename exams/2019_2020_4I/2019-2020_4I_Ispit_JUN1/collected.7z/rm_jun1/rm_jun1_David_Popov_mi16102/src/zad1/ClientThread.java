package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread extends Thread {
    private Socket client;
    private ForumServer server;
    private PrintWriter toClient;
    private BufferedReader fromClient;

    public ClientThread(Socket client, ForumServer server) {
        this.client = client;
        this.server = server;

        try {
            this.toClient = new PrintWriter(this.client.getOutputStream(), true);
            this.fromClient = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        try {
            String line;
            do {
                line = fromClient.readLine();
                if(line == null || line.trim().equalsIgnoreCase("bye"))
                    break;

                String[] args = line.split(" ");
                String command = line.indexOf(' ') != -1 ? line.substring(0, line.indexOf(' ')) : line.trim();
                System.out.println(command);
                if(command.equalsIgnoreCase("list")) {
                    if(args.length > 1) {
                        toClient.println("nevalidan format!");
                        toClient.println("-1");
                    } else {

                        Post[] arrPosts = server.getPosts();
                        String strPosts = this.formatPostList(arrPosts);

                        toClient.printf("%s", strPosts);
                        toClient.println("-1");
                    }

                } else if(command.equalsIgnoreCase("reply")) {
                    String argsReply = line.substring(line.indexOf(' ')+1);
                    String[] argsReplyList = argsReply.split(" \"");
                    String idPostStr = argsReplyList[0];
                    int idPost = Integer.parseInt(argsReplyList[0].trim());
                    String content = argsReplyList[1];
                    if(idPostStr.equals("" ) || content.equals("")) {
                        toClient.println("nevalidan format!");
                        toClient.println("-1");
                    } else {
                        server.addContentToPost(idPost, content);
                        toClient.println("reply je uspesno izvrsen!");
                        toClient.println("-1");
                    }
                } else if(command.equalsIgnoreCase("post")) {
                    String argsPost = line.substring(line.indexOf(' ')+1);
                    String[] argsPostList = argsPost.split("\" \"");
                    String title = argsPostList[0].replace('"', ' ');
                    String content = argsPostList[1].replace('"', ' ');
                    if(title.equals("") || content.equals("")) {
                        toClient.println("nevalidan format!");
                        toClient.println("-1");
                    } else {
                        server.addPost(title, content);
                        toClient.println("post je uspesno izvrsen");
                        toClient.println("-1");

                    }
                } else {
                    toClient.println("nevalidan format!");
                    toClient.println("-1");
                }

            } while (!line.trim().equalsIgnoreCase("bye"));

            toClient.close();
            fromClient.close();
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String formatPostList(Post[] posts) {
        String formated = "";

        for(Post p: posts) {
            formated += p.getId() + ": " + p.getTitle() + "\n" + p.getContent() + "\n";
        }

        return formated;
    }
}

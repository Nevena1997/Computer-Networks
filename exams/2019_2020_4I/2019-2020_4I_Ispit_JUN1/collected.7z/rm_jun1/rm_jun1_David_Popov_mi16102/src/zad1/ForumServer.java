package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Post {
    private int id;
    private String title;
    private String content;

    public Post(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}

class ForumServer {

    public final static int PORT = 7337;

    public static void main(String[] args) {
        ForumServer server = new ForumServer(PORT);
        server.execute();
        System.out.println("Hello from ForumServer!");
    }

    Map<Integer, Post> posts = new HashMap();
    private int port;
    private int idPost = 1;
    public ForumServer(int port) {
        this.port = port;
    }

    public synchronized Post[] getPosts() {
        return posts.values().toArray(Post[]::new);
    }

    public synchronized void addPost(String title, String content) {
        Post p = new Post(idPost, title, "# " + content);
        posts.put(idPost, p);
        idPost++;
    }

    public synchronized void addContentToPost(int postId, String content) {
        Post p = posts.get(postId);
        p.setContent(p.getContent() + "\n" + "- " + content);
    }

    private void execute() {
        try (ServerSocket serverSocket = new ServerSocket(this.port)) {
            System.out.println("Forum server runnin on: "+ this.port);

            while (true) {
                Socket client = serverSocket.accept();
                ClientThread ct = new ClientThread(client, this);
                ct.start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

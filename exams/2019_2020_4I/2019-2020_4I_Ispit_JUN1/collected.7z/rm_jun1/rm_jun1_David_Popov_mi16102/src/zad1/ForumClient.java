package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {
        ForumClient cf = new ForumClient(ForumServer.PORT, "localhost");
        cf.execute();
        System.out.println("Hello from ForumClient!");
    }

    public ForumClient(int port, String host) {
        this.port = port;
        this.host = host;
    }

    private int port;
    private String host;
    private void execute() {

        try {
            Socket socket = new Socket(this.host, this.port);
            Scanner sc = new Scanner(System.in);
            PrintWriter toServer = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line;
            do {

                line = sc.nextLine();
                if(line == null)
                    break;

                toServer.println(line);

                String serverOutput = fromServer.readLine();
                if(serverOutput == null)
                    break;
                while (!serverOutput.trim().equalsIgnoreCase("-1")) {
                    System.out.println(serverOutput);
                    serverOutput = fromServer.readLine();
                }
            }while (!line.trim().equalsIgnoreCase("bye"));
            sc.close();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

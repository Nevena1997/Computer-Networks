package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    private Socket connection = null;

    @Override
    public InputStream getInputStream() throws IOException {
        if(this.connection == null) {
            System.out.println("NULL JE");
            return null;
        }
        return this.connection.getInputStream();
    }

    @Override
    public void connect() throws IOException {
        if(!this.connected) {
            int port = this.url.getPort();
            if(port < 0 || port > 65535) {
                port = 7337;
            }
            this.connection = new Socket(this.url.getHost(), port);
            this.connected = true;
            PrintWriter toServer = new PrintWriter(this.connection.getOutputStream(), true);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(this.connection.getInputStream()));
            String q = this.url.getQuery();
            if(q != null) {
                int i = q.indexOf("post");
                int j = q.indexOf("reply");

                if (i != -1) {
                    String query = "post ";
                    query += "\"" + q.substring(q.indexOf("post") + 10, q.indexOf("content")) + "\" ";
                    query += "\"" + q.substring(q.indexOf("content") + 8) + "\"";

                    toServer.println(query);
                    fromServer.readLine();
                    fromServer.readLine();
                } else if (j != -1) {
                    String query = "reply ";
                    query += q.substring(q.indexOf("reply") + 8, q.indexOf("content")) + " ";
                    query += "\"" + q.substring(q.indexOf("content") + 8) + "\"";

                    toServer.println(query);
                    fromServer.readLine();
                    fromServer.readLine();
                }
            }
            toServer.println("list");



        }
    }


}

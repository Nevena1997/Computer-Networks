package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    public static final int DEFAULT_PORT = 7337;
    private Socket connection=null;
    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected){
            connect();
           return connection.getInputStream();
        }
        return connection.getInputStream();


    }

    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port = this.url.getPort();
            String host = this.url.getHost();
            if(port<=0 || port> 65535){
                port=DEFAULT_PORT;
            }
            connection = new Socket(host, port);
            this.connected=true;
        }
    }
}

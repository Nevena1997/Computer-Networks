package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException {

        System.out.println("Hello from protocol test method!");
        String line;
        Scanner sc = new Scanner(System.in);
        while(sc.hasNextLine()){
            line = sc.nextLine();
            URL url = new URL(null, line, new Handler());
            String query = url.getQuery();
            System.out.println(query);
            String[] niz = query.split("posttitle=");
            String[] niz2 = niz[1].split("content=");
            String title=niz2[0];
            String content=niz2[1];
            for(String n: niz2){
                System.out.println(n);
            }
            //forum://localhost:7337?q=posttitle=Zdravocontent=Paziti+na+specijalne+karaktere
            URLConnection conn = url.openConnection();
            String od;
            try(BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))){
                 while(true){

                        if((od=reader.readLine())!=null)
                            System.out.println(od);
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }


    }
}

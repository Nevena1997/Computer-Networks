package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {

    private int port;
    private String host;

    public ForumClient(int port, String host) {
        this.port = port;
        this.host = host;
    }

    public static void main(String[] args) {
        System.out.println("Hello from ForumClient!");
        ForumClient client= new ForumClient(7337, "localhost");
        client.execute();

    }

    void execute(){

        try(Socket s = new Socket(this.host, this.port);
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            Scanner sc = new Scanner(System.in);
        ){
            String line;
            String odgovor;
            System.out.println("prikacio se klijent");
           while(sc.hasNextLine()){
               line=sc.nextLine();
               if(line.equalsIgnoreCase("bye"))
                   break;
               String[] niz = line.split(" ");

               if(niz.length==2 || niz.length>3){
                   System.out.println("Nevalidan format");
                   continue;
               }
               if(niz[0].equalsIgnoreCase("reply")){
                   try{
                       int broj = Integer.parseInt(niz[1]);
                   }catch(Exception e){
                       System.out.println("nevalidan format ");
                   }
                   out.println(line);
                   odgovor=in.readLine();
                   System.out.println(odgovor);
               }else if(niz[0].equalsIgnoreCase("list")){
                   out.println(line);
                   while((odgovor= in.readLine())!=null){
                       System.out.println(odgovor);
                   }
               }else if(niz[0].equalsIgnoreCase("post")){
                   out.println(line);
                   odgovor=in.readLine();
                   System.out.println(odgovor);
               }


           }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

class ForumServer {

    private int port;
    private Set<UserThread> users = new HashSet<>();
    private Set<Tema> teme = new HashSet<>();

    public ForumServer(int port) {
        this.port = port;
    }

    public static void main(String[] args) {

        System.out.println("Hello from ForumServer!");
        ForumServer server = new ForumServer(7337);
        server.execute();
    }

    private void execute() {

        try(ServerSocket server = new ServerSocket(this.port)){
            System.out.println("povezao se server");
            while(true){

                try {
                    Socket client = server.accept();
                    UserThread u = new UserThread(this, client);
                    users.add(u);
                    u.start();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addTema(Tema t){
        teme.add(t);
    }
    public String izlistaj(){
        StringBuilder sb = new StringBuilder();
        for(Tema t: this.teme){
            sb.append(t);
        }
        return sb.toString();
    }
    public boolean dodajPoId(int id, String content){
        boolean ind = false;
        for(Tema t: this.teme){

            if(t.getId()==id) {
                ind=true;
                synchronized (t) {
                    t.addContents(content);
                }
            }

        }
        return ind;

    }
}

package zad1;

import java.util.ArrayList;
import java.util.List;

public class Tema {

    private int id;
    public static int max=0;
    private List<String> contents=new ArrayList<>();
    private String title;

    public Tema(String title, String content) {
        this.id=max;
        this.contents.add(content);
        this.title = title;
        max++;
    }

    public int getId() {
        return id;
    }

    public void addContents(String content) {
        this.contents.add(content);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(""+id+": "+this.title+"\n");

        int i=0;
        for(String s: this.contents){
            if(i==0){
                sb.append("# "+this.contents.get(0)+"\n");
                i++;
            }else {
                sb.append("- " + s+"\n");
            }
        }
        sb.append("\n");
        return sb.toString();
    }
}

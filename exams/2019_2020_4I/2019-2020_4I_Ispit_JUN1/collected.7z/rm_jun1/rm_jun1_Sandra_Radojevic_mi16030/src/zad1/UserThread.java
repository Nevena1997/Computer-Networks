package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class UserThread extends Thread {

    private ForumServer server;
    private Socket client;

    public UserThread(ForumServer server, Socket client) {
        this.server = server;
        this.client = client;
    }

    @Override
    public void run() {
        //System.out.println("evo me ovde");
        try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        PrintWriter out = new PrintWriter(client.getOutputStream(), true)){
            String zahtev;
            while(true){
                zahtev = in.readLine();
                System.out.println(zahtev);
                String[] niz=zahtev.split(" ");
                if(niz[0].equalsIgnoreCase("post")){
                    String title = niz[1];
                    String content = niz[2];
                    Tema t = new Tema(title, content);
                    server.addTema(t);
                    out.println("post je uspesno izvrsen");

                }else if(niz[0].equalsIgnoreCase("list")){
                    String izlistano = server.izlistaj();
                    out.println(izlistano);

                }else if(niz[0].equalsIgnoreCase("reply")){
                    int id = Integer.parseInt(niz[1]);
                    String content = niz[2];
                    boolean ind = server.dodajPoId(id, content);
                    if(ind) {
                        out.println("reply je uspesno izvrsen");
                    }else{
                        out.println("nevalidan id teme");
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

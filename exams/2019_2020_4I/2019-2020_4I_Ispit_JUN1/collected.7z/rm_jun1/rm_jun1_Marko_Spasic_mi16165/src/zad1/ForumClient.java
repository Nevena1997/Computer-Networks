package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLOutput;
import java.util.Scanner;

class ForumClient {

     private static boolean isValidCommand(String command) {
         if (command.equals("list") || command.startsWith("post|") || command.startsWith("reply|")) {
             return true;
         } else {
             return false;
         }
     }
    public static void main(String[] args) {
        String host = "localhost";
        int port = ForumServer.DEFAULT_PORT;
        try (Socket socket = new Socket(host, port);
             Scanner scan = new Scanner(System.in);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

            String command;
            while ((command = scan.nextLine()) != null) {
                if (!isValidCommand(command)) {
                    System.out.println("Ne postoji ta komanda");
                    continue;
                }
                writer.write(command);
                writer.newLine();
                writer.flush();

                String response;
                while ((response = reader.readLine()) != null) {
                    if (response.equals(ForumServer.END_OF_INPUT))
                        break;
                    System.out.println(response);
                }

                if (command.equals("bye"))
                    break;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

class ForumServer implements AutoCloseable {

    public static final int DEFAULT_PORT = 7337;
    public static final String END_OF_INPUT = "######";

    private ServerSocket socket;
    private AtomicInteger idCounter = new AtomicInteger(0);
    private ConcurrentHashMap<Integer, ForumThread> threads = new ConcurrentHashMap<Integer, ForumThread>();

    public synchronized boolean addReplay(int id, String reply) {
        if (this.threads.containsKey(id)) {
            this.threads.get(id).addReplay(reply);
            return true;
        } else {
            return false;
        }
    }

    public synchronized boolean post(String title, String content) {
        int id = idCounter.addAndGet(1);
        ForumThread newThread = new ForumThread(id, title, content);
        threads.put(id, newThread);
        return true;
    }


    public synchronized List<ForumThread> list() {
        List<ForumThread> result = new ArrayList<>();
        for (ForumThread forumThread : threads.values()) {
            result.add(forumThread.copy());
        }
        return result;
    }

    public ForumServer(int port) throws IOException {
        this.socket = new ServerSocket(port);
    }

    private void start() {
        while (true) {
            try {
                Socket client = socket.accept();
                System.out.println("Client accepted!");
                new Thread(new ClientHandler(client, this)).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {

        try(ForumServer server = new ForumServer(DEFAULT_PORT)) {
            server.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws Exception {
        if (socket != null)
            this.socket.close();
    }
}

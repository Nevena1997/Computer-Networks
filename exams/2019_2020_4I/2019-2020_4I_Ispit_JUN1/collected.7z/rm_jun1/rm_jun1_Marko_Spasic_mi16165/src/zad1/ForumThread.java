package zad1;

import java.util.ArrayList;
import java.util.List;

public class ForumThread {
    private int id;
    private String title;
    private String content;
    private List<String> replies;

    public ForumThread(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.replies = new ArrayList<>();
    }

    public void addReplay(String reply) {
        replies.add(reply);
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public List<String> getReplies() {
        return replies;
    }

    public ForumThread copy() {
        ForumThread result = new ForumThread(this.id, this.title, this.content);
        result.replies = new ArrayList<>(this.replies);
        return result;
    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ClientHandler implements Runnable {
    private ForumServer server;
    private Socket client;

    public ClientHandler(Socket client, ForumServer forumServer) {
        this.client = client;
        this.server = forumServer;
    }

    private void oneLineResponse(String response, BufferedWriter writer) throws IOException {
        writer.write(response);
        writer.newLine();
        writer.write(ForumServer.END_OF_INPUT);
        writer.newLine();
        writer.flush();
    }

    private String formatListOfForumThreads(List<ForumThread> threads) {
        StringBuilder builder = new StringBuilder();
        for (ForumThread thread : threads) {
            builder.append(thread.getId());
            builder.append(": ");
            builder.append(thread.getTitle());
            builder.append("\n");
            builder.append("\t# ");
            builder.append(thread.getContent());
            builder.append("\n");
            for (String reply : thread.getReplies()) {
                builder.append("\t - ");
                builder.append(reply);
                builder.append("\n");
            }
        }
        return builder.toString();
    }

    @Override
    public void run() {

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            String command;
            while ((command = reader.readLine()) != null) {
                if (command.equals("list")) {
                    List<ForumThread> threads = server.list();
                    String response = formatListOfForumThreads(threads);
                    writer.write(response);
                    writer.newLine();
                    writer.write(ForumServer.END_OF_INPUT);
                    writer.newLine();
                    writer.flush();

                } else if (command.startsWith("post|")) {

                    String tokens[] = command.split("[|]", 3);
                    if (tokens.length != 3) {
                        oneLineResponse("nevalidan format", writer);
                        continue;
                    }
                    System.out.println(Arrays.asList(tokens));
                    if (server.post(tokens[1], tokens[2])) {
                        oneLineResponse("post je uspesno izvrsen", writer);
                    } else {
                        oneLineResponse("post je bio neuspesan", writer);
                    }
                } else if (command.startsWith("reply|")) {
                    String tokens[] = command.split("[|]", 3);
                    if (tokens.length != 3) {
                        oneLineResponse("nevalidan format", writer);
                        continue;
                    }

                    try {
                        int id = Integer.parseInt(tokens[1]);
                        if (server.addReplay(id, tokens[2])) {
                            oneLineResponse("reply uspesno izvrsen", writer);
                        } else {
                            oneLineResponse("nevalidan id teme", writer);
                        }
                    } catch (NumberFormatException e) {
                        oneLineResponse("nevalidan format", writer);
                    }
                } else {
                    oneLineResponse("nepoznata komanda",writer);
                }

            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        System.out.println("Client disconnected!");
    }
}

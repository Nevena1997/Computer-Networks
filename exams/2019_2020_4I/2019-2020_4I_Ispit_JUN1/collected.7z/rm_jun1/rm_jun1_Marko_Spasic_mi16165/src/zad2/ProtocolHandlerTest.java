package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {
        try (Scanner scan = new Scanner(System.in)){
            String urlLine;
            while ((urlLine = scan.nextLine()) != null) {
                URL url = new URL(null, urlLine, new Handler());
                var conn = url.openConnection();
               try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String response;

                    while ((response = reader.readLine()) != null) {
                        //if (response.equals("######")) {
                        //    break;
                        //}
                        System.out.println(response);
                    }
                } catch (Exception e) {
                    System.out.println("Neuspela konekcija.");
                }
            }
        } catch (IOException e) {
            System.out.println("Neuspela konekcija.");
        }

    }
}

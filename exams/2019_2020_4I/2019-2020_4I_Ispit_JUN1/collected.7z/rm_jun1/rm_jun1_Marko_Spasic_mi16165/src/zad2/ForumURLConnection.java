package zad2;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    private Socket socket;
    public static final int DEFAULT_PORT = 7337;

    private void sendPost(String query[]) {

    }

    private void sendReply(String query[]) {

    }

    private void sendList(String query[]) {

    }

    private void sendRequest(String query, BufferedWriter writer) throws IOException {

        String parts[] = query.split("&", 3);
        if (!parts[0].startsWith("q=")) {
            writer.write("Bogus invalid command");
            writer.newLine();
            writer.flush();
        }

        String whichCommand = parts[0].split("=")[1];



        if (whichCommand.equals("list")) {
            writer.write("list");
            writer.newLine();
            writer.flush();
        } else if (whichCommand.equals("post")) {
            String title = parts[1].split("=",2)[1];
            String content = parts[2].split("=",2)[1];
            StringBuilder command = new StringBuilder();
            command.append("post|");
            command.append(URLDecoder.decode(title, StandardCharsets.UTF_8));
            command.append("|");
            command.append(URLDecoder.decode(content, StandardCharsets.UTF_8));
            writer.write(command.toString());
            writer.newLine();
            writer.flush();
        } else if (whichCommand.equals("reply")) {
            String id = parts[1].split("=",2)[1];
            String reply = parts[2].split("=", 2)[1];
            StringBuilder command = new StringBuilder();
            command.append("reply|");
            command.append(URLDecoder.decode(id, StandardCharsets.UTF_8));
            command.append("|");
            command.append(URLDecoder.decode(reply, StandardCharsets.UTF_8));
            writer.write(command.toString());
            writer.newLine();
            writer.flush();
        } else {
            writer.write("Bogus invalid command");
            writer.newLine();
            writer.flush();
        }
    }
    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if (!connected) {
            try {
                connect();
            } catch (IOException e) {
                return null;
            }

            if (!connected)
                return null;
        }

        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
             BufferedReader reader = new BufferedReader( new InputStreamReader(this.socket.getInputStream()))) {

            String query = url.getQuery();
            StringBuilder responseBuilder = new StringBuilder();
            String responseLine;
            if (query != null && !query.isEmpty()) {
                sendRequest(query, writer);
                while ((responseLine = reader.readLine()) != null) {
                    if (responseLine.equals("######"))
                        break;
                    responseBuilder.append(responseLine);
                    responseBuilder.append("\n");
                }
            }

            writer.write("list");
            writer.newLine();
            writer.flush();

            while ((responseLine = reader.readLine()) != null) {
                if (responseLine.equals("######"))
                    break;
                responseBuilder.append(responseLine);
                responseBuilder.append("\n");
            }

            ByteArrayInputStream result = new ByteArrayInputStream(responseBuilder.toString().getBytes());
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    @Override
    public synchronized void connect() throws IOException {
        if (!connected) {
            int port = url.getPort();
            if (port < 0) {
                port = DEFAULT_PORT;
            }

            if (port != DEFAULT_PORT || !url.getProtocol().equals("forum")) {
                return;
            }
            this.socket = new Socket(url.getHost(), port);
            this.connected = true;
        }
    }


}

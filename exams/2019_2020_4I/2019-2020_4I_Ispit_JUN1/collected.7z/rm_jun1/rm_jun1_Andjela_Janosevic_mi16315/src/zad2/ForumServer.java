package zad2;


import zad1.ForumClientHandler;
import zad1.ForumTema;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ForumServer {

    public static final int PORT = 7337;
    public static Map<Integer, ForumTema> teme = new HashMap<>();

    public static void main(String[] args) {
        //System.out.println("Hello from ForumServer!");

        //server za testiranje

        try(ServerSocket server = new ServerSocket(PORT)) {

            while(true){

                Socket client = server.accept();

                //System.err.println("Klijent prihvacen!"); //PITAJ ZA OVOOOO!!!!!

            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}

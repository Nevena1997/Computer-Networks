package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    public Socket client;


    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        // TODO
        if(!this.connected){
            int port = url.getPort();
            String host = url.getHost();

            if(port <= 0 || port > 65535){
                port = 7337;
            }

            try {
                this.client = new Socket(host, port);
            }catch (IOException e){
                System.out.println("neuspela konekcija");;
            }
            //System.err.println(url.getQuery());

            this.connected = true;
        }

    }
    @Override
    public InputStream getInputStream() throws IOException {
        if(!this.connected)
            this.connect();

        if(!this.connected)
            return null;

        return this.client.getInputStream();
    }

    @Override
    public String getContentType() {
        return "text/plain";
    }
}

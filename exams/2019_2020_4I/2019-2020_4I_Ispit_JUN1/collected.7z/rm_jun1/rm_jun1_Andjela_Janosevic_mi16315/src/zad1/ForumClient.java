package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {
        //System.out.println("Hello from ForumClient!");

        try(Socket socket = new Socket("localhost",ForumServer.PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

            Scanner sc = new Scanner(System.in);

            String line;
            while(true){
                line = sc.nextLine().trim();

                //System.err.println(line);

                if(line.equals("bye"))
                    break;

                if(!line.equals("list") || !line.startsWith("reply") || !line.startsWith("post"))
                    break;


                out.write(line);
                out.newLine();
                out.flush();



                String response = in.readLine();
                System.out.println(response);
            }

        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}

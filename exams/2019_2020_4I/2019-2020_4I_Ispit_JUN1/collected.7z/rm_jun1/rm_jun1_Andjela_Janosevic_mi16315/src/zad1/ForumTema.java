package zad1;

import java.util.ArrayList;
import java.util.List;

public class ForumTema {

    public int id;
    public List<String> content;
    public String title;

    public ForumTema(int id, String title, List<String> content){
        this.id = id;
        this.title = title;
        this.content = new ArrayList<>();
    }

    public int getId() {
        return this.id;
    }

    public List<String> getContent() {
        return this.content;
    }

    public String getTitle() {
        return this.title;
    }

    public void addContent(String msg){
        this.content.add(msg);
    }

    public String ListToString(){

        String teme = null;
        for (String s : content){
            teme = teme + "- " + s + "\n";
        }

        return teme;
    }
}

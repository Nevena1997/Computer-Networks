package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ForumServer {

    public static final int PORT = 7337;
    public static Map<Integer,ForumTema> teme = new HashMap<>();

    public static void main(String[] args) {
       // System.out.println("Hello from ForumServer!");

        try(ServerSocket server = new ServerSocket(PORT)) {

            while(true){

                Socket client = server.accept();

               // System.err.println("Klijent prihvacen!"); //PITAJ ZA OVOOOO!!!!!

                new Thread(new ForumClientHandler(client)).start();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }

    static Map<Integer,ForumTema> IzlistajTeme(){
        //vrati teme
        return teme;
    }

    static boolean  DodajOdgovor(int id, String content){
        //dodaj odgovor sa sadrzajem content temi sa id = id
        if(teme.containsKey(id)){
            ForumTema t = teme.get(id);
            t.addContent(content);
            return true;
        }
        else return false;
    }

    static boolean DodajNovuTemu(String title, String content){

        int new_id = teme.size() + 1;
        List<String> lista_contenta = new ArrayList<>();
        lista_contenta.add(content);
        ForumTema t = new ForumTema(new_id, title ,lista_contenta);

        teme.put(new_id,t);

        return true;
    }
}

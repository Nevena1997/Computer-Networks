package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class ForumClientHandler extends Thread {

    public Socket client;

    public ForumClientHandler(Socket client){
        this.client = client;
    }

    @Override
    public void run() {

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            while(true){

                String zahtev = in.readLine();
                //System.err.println(zahtev);

                if(zahtev.equals("bye"))
                    break;

                if(zahtev.equals("list")){
                    Map<Integer, ForumTema> teme = ForumServer.IzlistajTeme();

                    String response = "spisak tema";

                    /*for(int i = 1; i <= teme.size(); i++){
                        int id_teme = i;
                        ForumTema t = teme.get(i);
                        String con = t.ListToString();
                        response = response + id_teme + ": " + t.getTitle() + "\n" + con;
                    }*/

                    out.write(response);
                    out.newLine();
                    out.flush();
                }
                else if(zahtev.startsWith("reply")){
                    zahtev = zahtev.trim();
                    String id_str = zahtev.substring(zahtev.indexOf(" ") + 1, zahtev.lastIndexOf(" "));
                    String content = zahtev.substring(zahtev.lastIndexOf(" ") + 1);
                    int id = Integer.parseInt(id_str);

                    boolean uspesno = ForumServer.DodajOdgovor(id,content);

                    if(uspesno){
                        out.write("reply je uspesno izvrsen");
                        out.newLine();
                        out.flush();
                    }
                    else{
                        out.write("nevalidan id teme");
                        out.newLine();
                        out.flush();
                    }
                }
                else if(zahtev.startsWith("post")){
                    zahtev = zahtev.trim();
                    try {
                        String title = zahtev.substring(zahtev.indexOf(" ") + 1, zahtev.lastIndexOf(" "));
                        String content = zahtev.substring(zahtev.lastIndexOf(" ") + 1);
                        boolean uspesno = ForumServer.DodajNovuTemu(title, content);

                        if (uspesno) {
                            out.write("post je uspesno izvrsen");
                            out.newLine();
                            out.flush();
                        }

                    } catch (Exception e) {
                        out.write("nevalidan format");
                        out.newLine();
                        out.flush();
                    }
                }

                else break;

            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

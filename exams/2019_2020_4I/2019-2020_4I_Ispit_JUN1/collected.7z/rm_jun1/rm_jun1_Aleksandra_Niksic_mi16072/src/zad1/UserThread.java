package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class UserThread extends Thread {
    private Socket client;
    private ServerSocket server;
    private String zahtev;
    private PrintWriter out;
    private static Map<Integer, String> teme;
    private int brojacTema;

    public UserThread(Socket client, ServerSocket server, String zahtev ) {
        this.client = client;
        this.server = server;
        this.zahtev = zahtev;
        try{
            out = new PrintWriter(client.getOutputStream());
        }catch (IOException e){
            e.printStackTrace();
        }
        this.teme = new HashMap<>();
    }

    @Override
    public void run() {

        brojacTema = 1;

        int id;
        String content_reply = null;

        String title = null;
        String content_post = null;

        if(zahtev.length() == 4 && zahtev.equalsIgnoreCase("list")){
            //System.out.println("stampam listu tema");
            this.list(teme);
        }else if(zahtev.substring(0, zahtev.indexOf(' ')).equalsIgnoreCase("reply")){
            System.out.println("reply je uspesno izvrsen");
            id = 1;//kako procitati string
            this.reply(teme, id, content_reply);
        }else if(zahtev.substring(0, zahtev.indexOf(' ')).equalsIgnoreCase("post")){
            System.out.println("post je uspesno izvrsen");
            brojacTema++;
            title = zahtev.substring(zahtev.indexOf(' '), zahtev.lastIndexOf(' '));
            content_post = zahtev.substring(zahtev.lastIndexOf(' '));
            this.post(teme, title, content_post);
        }else {
            System.err.println("nevalidan unos");
        }
    }

    private void list(Map<Integer, String> teme) {
        for(String tema : teme.values())
            out.println(tema);
    }

    private synchronized void post(Map<Integer, String> teme, String title, String content_post) {
        String tema = title+content_post;
        teme.put(brojacTema, tema);
    }

    private synchronized void reply(Map<Integer, String> teme, int id, String content_reply) {
        String temaSaOdgovorom = teme.get(id) + content_reply;
        teme.put(id, temaSaOdgovorom);
    }
}

package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ForumServer {
    private static Map<Integer, String> teme;

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(7337)){
            while (true){
                Socket client = server.accept();
                //System.out.printf("Prihvacen klijent");
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String zahtev = in.readLine();

                new UserThread(client, server, zahtev).start();
            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

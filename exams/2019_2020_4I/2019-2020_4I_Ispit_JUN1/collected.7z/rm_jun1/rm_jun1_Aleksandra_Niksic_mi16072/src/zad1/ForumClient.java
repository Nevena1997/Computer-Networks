package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

class ForumClient {

    public static void main(String[] args) {
        String zahtev;

        try (Socket client = new Socket("localhost", 7337);
             Scanner scanner = new Scanner(System.in);
             PrintWriter out = new PrintWriter(client.getOutputStream(), true)) {

            while (true){
                zahtev = scanner.nextLine();
                if(!zahtev.equalsIgnoreCase("bye")){
                    out.println(zahtev);
                    //System.out.printf("Saljem serveru");
                }
            }


        }catch (IOException e){
            e.printStackTrace();
        }


    }
}

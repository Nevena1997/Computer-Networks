package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    private Socket client;

    @Override
    public String getContentType() {
        return "text/plain";
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(connected){
            return this.client.getInputStream();
        }else {
            return null;
        }
    }

    @Override
    public void connect() throws IOException {
        if(!connected) {
            int port = url.getPort();
            String host = url.getHost();
            String file = url.getFile();

            if (port <= 0 || port > 65353)
                port = 7337;

            try {
                this.client = new Socket(host, port);

                String upit = "list";
                BufferedWriter kaServeru = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                kaServeru.write(upit);
                kaServeru.newLine();
                kaServeru.flush();

                String upit1 = url.getFile();
                upit1 = upit1.substring(upit1.indexOf('='));
                kaServeru.write(upit1);
                kaServeru.newLine();
                kaServeru.flush();

                BufferedReader odServera = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String odgovor = odServera.readLine();

                System.out.println(odgovor);

            } catch (IOException e) {
                e.printStackTrace();
            }
            connected = true;
        }

    }
}

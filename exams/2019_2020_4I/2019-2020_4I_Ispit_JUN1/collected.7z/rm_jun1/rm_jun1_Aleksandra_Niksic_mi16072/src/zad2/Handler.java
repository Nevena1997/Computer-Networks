package zad2;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

class Handler extends URLStreamHandler {

    @Override
    protected int getDefaultPort() {
        return 7337;
    }

    @Override
    protected synchronized URLConnection openConnection(URL u) throws IOException {
        return new ForumURLConnection(u);
    }
}

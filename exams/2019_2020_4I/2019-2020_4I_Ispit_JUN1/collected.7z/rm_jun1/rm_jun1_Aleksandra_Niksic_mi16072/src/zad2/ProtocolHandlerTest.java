package zad2;

import java.io.*;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
//"forum://localhost:7337?q=posttitle=Zdravocontent=Paziti+na+specijalne+karaktere"
class ProtocolHandlerTest {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            String urlSaUlaza = scanner.nextLine();

            URL url = new URL(null, urlSaUlaza, new Handler());
            URLConnection conn = url.openConnection();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String upit = in.readLine();

            String file = url.getFile();
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
            out.write(file);
            out.newLine();
            out.flush();

            scanner.close();
            in.close();
            out.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) throws MalformedURLException {
        String longUrl = "forum://localhost:7337?q=posttitle=Zdravo&content=Paziti+na+specijalne+karaktere";
        //String longUrl = "forum://localhost?q=post";
        //Scanner userInput = new Scanner(System.in);
        //longUrl = userInput.nextLine().trim();
        URL url = new URL(null, longUrl, new Handler());
        BufferedReader reader = null;
        try {
            URLConnection connection = url.openConnection();
            reader = new BufferedReader(
                new InputStreamReader(
                    connection.getInputStream()
                )
            );
            System.out.println(reader.readLine());
        } catch (IOException e) {
            System.out.println("nevalidan format.");
        } finally {
            if(reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

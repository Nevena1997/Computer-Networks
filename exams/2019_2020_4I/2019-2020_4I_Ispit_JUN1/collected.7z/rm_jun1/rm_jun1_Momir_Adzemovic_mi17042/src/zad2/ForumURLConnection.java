package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    public static final int DEFAULT_PORT = 7337;

    ForumURLConnection(URL url) {
        super(url);
    }

    private Socket socket = null;
    private ByteArrayInputStream stream = null;

    public synchronized InputStream getInputStream() throws IOException {
        if(!this.connected) {
            connect();
        }
        return this.stream;
    }

    @Override
    public synchronized void connect() throws IOException {
        if(!this.connected) {
            int port = url.getPort();
            if(port < 1 || port > 65535) {
                port = url.getDefaultPort();
            }
            String hostName = url.getHost();
            this.socket = new Socket(hostName, port);
            BufferedWriter toServer = new BufferedWriter(
                new OutputStreamWriter(
                    socket.getOutputStream()
                )
            );
            BufferedReader fromServer = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );
            try {
                String request = url.getFile();
                String optionPostTitle = request.substring(0, 13);
                if (!optionPostTitle.equalsIgnoreCase("?q=posttitle=")) {
                    throw new IOException("Invalid request: Invalid query!");
                }
                String[] afterPostTitle = request.substring(13).split("&");
                if (afterPostTitle.length != 2) {
                    throw new IOException("Invalid request: Missing elements!");
                }
                String title = "\"" + afterPostTitle[0] + "\"";
                String optionContent = afterPostTitle[1].substring(0, 8);
                if (!optionContent.equalsIgnoreCase("content=")) {
                    throw new IOException("Invalid request: Invalid query");
                }
                String content = "\"" + afterPostTitle[1].substring(8).replace('+', ' ') + "\"";

                String postRequest = "post " + title + " " + content;

                System.out.println(postRequest);

                toServer.write(postRequest);
                toServer.newLine();
                toServer.flush();

                String response = fromServer.readLine();

                toServer.write("bye");
                toServer.newLine();
                toServer.flush();

                this.stream = new ByteArrayInputStream(response.getBytes());
            } catch (IndexOutOfBoundsException e) {
                throw new IOException("Invalid request: Invalid query");
            }

            this.connected = true;
        }
    }
}

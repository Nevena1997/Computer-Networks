package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;


class ForumServer {
    public static boolean LOG = false;
    public static final AtomicInteger nextInteger = new AtomicInteger(0);

    public static void main(String[] args) {
        (new ForumServer()).start();
    }

    private void start() {
        int port = 7337;
        Map<Integer, ForumPost> posts = new TreeMap<>();
        ReentrantLock lock = new ReentrantLock();

        try (ServerSocket server = new ServerSocket(port)) {

            log("Listening on port " + LOG);

            while(true) {
                log("Waiting for client...");
                Socket client = server.accept();
                log("Accepted new client!");
                (new Thread(new ForumClientHandlerRunnable(client, posts, lock))).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void log(String msg) {
        if(LOG) {
            System.out.println("[Server]: " + msg);
        }
    }
}

package zad1;

import java.io.*;
import java.net.Socket;

class ForumClient {
    private static boolean LOG = false;

    public static void main(String[] args) {
        // #FIXME: Nakon sto se unese list, potreban je dodatni newline za reply i post zahtev
        int port = 7337;
        try(
            Socket client = new Socket("localhost", port);
            BufferedReader fromServer = new BufferedReader(
                new InputStreamReader(
                    client.getInputStream()
                )
            );
            BufferedWriter toServer = new BufferedWriter(
                new OutputStreamWriter(
                    client.getOutputStream()
                )
            );
            BufferedReader userInput = new BufferedReader(
                new InputStreamReader(
                    System.in
                )
            )
        ) {
            log("Connected to server!");
            while(true) {
                log("Reading request...");
                String request = userInput.readLine();
                log("Sending request...");
                send(toServer, request);
                if(request.trim().equalsIgnoreCase("bye")) {
                    log("Closing connection with server!");
                    break;
                }
                log("Waiting for response...");
                if(request.trim().equalsIgnoreCase("list")) {
                    String line;
                    while(true) {
                        line = fromServer.readLine();
                        if(line == null || line.equalsIgnoreCase("END")) {
                            break;
                        }
                        System.out.println(line);
                    }
                    continue;
                }
                String response = fromServer.readLine();
                log("Received response!");
                System.out.println(response);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void send(BufferedWriter toServer, String request) throws IOException {
        toServer.write(request);
        toServer.newLine();
        toServer.flush();
    }

    public static void log(String msg) {
        if(LOG) {
            System.out.println("[Client]: " + msg);
        }
    }
}

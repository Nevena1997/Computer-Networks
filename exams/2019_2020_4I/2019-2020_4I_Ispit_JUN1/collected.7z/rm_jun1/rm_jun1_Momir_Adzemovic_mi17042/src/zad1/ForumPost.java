package zad1;

import java.util.ArrayList;
import java.util.List;

public class ForumPost {
    private final String title;
    private final String content;
    private final List<String> comments;
    private final int id;

    public ForumPost(String title, String content, int id) {
        this.title = title;
        this.content = content;
        this.comments = new ArrayList<>();
        this.id = id;
    }

    public void addNewComment(String comment) {
        this.comments.add(comment);
    }

    public String content() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.title);
        sb.append(System.lineSeparator());
        sb.append("  # ");
        sb.append(content);
        sb.append(System.lineSeparator());
        for(String comment: comments) {
            sb.append("  - ");
            sb.append(comment);
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }

    public int getId() {
        return id;
    }
}

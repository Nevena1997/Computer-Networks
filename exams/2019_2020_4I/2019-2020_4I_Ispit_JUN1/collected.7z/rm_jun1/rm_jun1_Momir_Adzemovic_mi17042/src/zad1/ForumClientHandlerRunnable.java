package zad1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

public class ForumClientHandlerRunnable implements Runnable {
    private final Scanner fromClient;
    private final BufferedWriter toClient;
    private final Map<Integer, ForumPost> posts;
    private final ReentrantLock lock;
    private final Socket client;

    public ForumClientHandlerRunnable(Socket client, Map<Integer, ForumPost> posts, ReentrantLock lock) throws IOException {
        this.fromClient = new Scanner(
            client.getInputStream()
        );
        this.toClient = new BufferedWriter(
            new OutputStreamWriter(
                client.getOutputStream()
            )
        );
        this.posts = posts;
        this.lock = lock;
        this.client = client;
    }

    @Override
    public void run() {
        try {
            while(true) {
                String option;
                try {
                    option = fromClient.next();
                } catch (NoSuchElementException e) {
                    continue;
                }
                if(option == null) {
                    break;
                }
                if(option.equalsIgnoreCase("list")) {
                    fromClient.nextLine();
                    StringBuilder sb = new StringBuilder();
                    this.lock.lock();
                    for(ForumPost post: this.posts.values()) {
                        sb.append(post.getId()).append(": ");
                        sb.append(post.content());
                    }
                    this.lock.unlock();
                    sb.append("END").append(System.lineSeparator());
                    String response = sb.toString();
                    send(toClient, response);
                }
                else if(option.equalsIgnoreCase("reply")) {
                    clientLog("Received reply request option!");
                    int index = fromClient.nextInt();
                    clientLog("Received index ~ " + index);
                    String content = fromClient.nextLine().replaceAll("\"", "");
                    clientLog("Checking if requested post exists...");
                    this.lock.lock();
                    if(posts.containsKey(index)) {
                        posts.get(index).addNewComment(content);
                        send(toClient, "reply je uspesno izvrsen");
                    }
                    else {
                        send(toClient, "nevalidan format");
                    }
                    this.lock.unlock();
                }
                else if(option.equalsIgnoreCase("post")) {
                    String[] requestItems = fromClient.nextLine().split("\"");
                    if(requestItems.length != 4) {
                        send(toClient, "nevalidan format");
                    }
                    String title = requestItems[1];
                    String content = requestItems[3];
                    int newIndex = ForumServer.nextInteger.addAndGet(1);
                    this.lock.lock();
                    posts.put(newIndex, new ForumPost(title, content, newIndex));
                    this.lock.unlock();
                    send(toClient, "post je uspesno izvrsen");
                }
                else if(option.equalsIgnoreCase("bye")) {
                    fromClient.nextLine();
                    break;
                }
                else {
                    send(toClient, "nevalidan format");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.lock.unlock();
            } catch (Exception e) {
                // ignore
            }
        }
    }

    private void send(BufferedWriter toClient, String response) throws IOException {
        toClient.write(response);
        toClient.newLine();
        toClient.flush();
    }

    private void clientLog(String msg) {
        if(ForumServer.LOG) {
            System.out.println("[" + this.client.getRemoteSocketAddress() + "]: " + msg);
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

class ProtocolHandlerTest {
    public static void main(String[] args) {

        try {
            Scanner in = new Scanner(System.in);
            String spec = in.nextLine();

            URL url = new URL(null, spec, new Handler());
            URLConnection conn = url.openConnection();

            try(BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream())))
            {

            }


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    Socket socket;

    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public void connect() throws IOException {
        //TODO

        if(!this.connected)
        {
            int port = url.getPort();
            String host = url.getHost();

            if(port < 0 || port > 65535)
                port = 7337;

            this.socket = new Socket(host, port);
            String poruka = url.getFile();
            if(poruka != null && poruka != "")
            {
                System.err.println(poruka);
            }
        }

        this.connect();
    }

    @Override
    public InputStream getInputStream() throws IOException {
        if(this.connected)
            return this.socket.getInputStream();
        else
            return null;
    }
}

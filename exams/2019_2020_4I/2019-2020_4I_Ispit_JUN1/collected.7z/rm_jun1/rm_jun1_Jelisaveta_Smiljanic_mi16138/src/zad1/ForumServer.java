package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


class ForumServer {

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(7337)){

            while(true)
            {
                try{
                    Socket klijent = server.accept();
                    UserThread user = new UserThread(klijent, server);
                    user.start();


                }catch (IOException e){
                    e.printStackTrace();
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.Map;

public class UserThread extends Thread{

    public Socket klijent;
    public ServerSocket server;
    public Map<String, String> odgovori = new HashMap<String, String>();
    public Map<String, String> teme = new HashMap<String, String>();


    public UserThread(Socket klijent, ServerSocket server) {
        this.klijent = klijent;
        this.server = server;
    }

    @Override
    public void run() {

        try{

            BufferedReader in = new BufferedReader(new InputStreamReader(this.klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.klijent.getOutputStream()));

            //Bas sam se upetljala, nisam mogla da ispratim vise sta sam kako podelila :( hahaha
            String primljeni_zahtev = "";
            if((primljeni_zahtev = in.readLine().trim()) != null) {

                if (primljeni_zahtev.equalsIgnoreCase("list")) {
                    for(String s: teme.keySet()) {
                        out.write(s);
                        out.newLine();

                    }
                        out.write("\r\n\r\n");
                        out.flush();


                } else {
                    String[] zahtev_izdeljen = primljeni_zahtev.split("\"");
                    // ako dobijemo samo dve niske to moze da bude reply reply 100 "test"
                    //reply 100 "
                    if(zahtev_izdeljen.length == 2){
                        String[] komandaId = zahtev_izdeljen[0].split(" ");
                        if(komandaId.length != 2){
                            out.write("nevalidan format");
                            out.write("\r\n\r\n");
                            out.flush();
                        }else{
                            odgovori.put(komandaId[1], zahtev_izdeljen[1]);
                            out.write("reply je uspesno izvrsen");
                            out.write("\r\n\r\n");
                            out.flush();
                        }
                    }
                    //inace gledamo da li je post
                    //post "yzsf" "fsfsd"
                    else if(zahtev_izdeljen.length == 4)
                    {
                        teme.put(zahtev_izdeljen[1], zahtev_izdeljen[3]);
                        out.write("reply je uspesno izvrsen");
                        out.write("\r\n\r\n");
                        out.flush();
                    }else{
                        out.write("nevalidan format");
                        out.write("\r\n\r\n");
                        out.flush();
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

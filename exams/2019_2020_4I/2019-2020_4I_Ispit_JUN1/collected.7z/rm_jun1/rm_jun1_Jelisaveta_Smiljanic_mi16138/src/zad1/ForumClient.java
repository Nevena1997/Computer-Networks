package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {

        try (Socket klijent = new Socket("localhost", 7337);
             Scanner sc = new Scanner(System.in);
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
             BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()))){

            String zahtev = "";
            while(sc.hasNextLine()) {
                zahtev = sc.nextLine().trim();
                if(zahtev.equalsIgnoreCase("bye"))
                {
                    System.err.println("Uneo si bye, dovidjenja");
                    System.exit(1);
                }
                else {
                    out.write(zahtev);
                    out.newLine();
                    out.flush();
                }
            }

            //Klijent prima odgovor - bog zna sta sam uradila
            String odgovor = in.readLine();
            while(odgovor != "\r\n\r\n")
                System.out.println(odgovor);


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {

    private PrintWriter out;
    private BufferedReader in;
    private int port;

    public ForumClient(int port){
        this.port = port;
    }

    public static void main(String[] args) {


        ForumClient forumClient = new ForumClient(ForumServer.SERVER_PORT);

        try(Socket client = new Socket("localhost", ForumServer.SERVER_PORT)) {
            forumClient.out = new PrintWriter(client.getOutputStream(), true);
            forumClient.in = new BufferedReader(new InputStreamReader(client.getInputStream()));

            Scanner sc = new Scanner(System.in);
            String line;
            while (true){
                line = sc.nextLine();

                forumClient.out.println(line);

                if(line.trim().split(" ")[0].equalsIgnoreCase("list")){
                    String fromServer = null;
                    int id = 0;
                    while (true) {

                        fromServer = forumClient.in.readLine();
                        if(fromServer.equalsIgnoreCase("done"))
                            break;
                        id++;
                        String[] toWriteOut = fromServer.split("--");

                        for (int i = 0; i < toWriteOut.length; i++) {
                            if (i == 0) {
                                System.out.println(id + ": " + toWriteOut[0]);
                            }
                            if (i == 1)
                                System.out.println("# " + toWriteOut[i]);
                            else if (i > 1) {
                                System.out.println("- " + toWriteOut[i]);
                            }
                        }
                        System.out.println();
                    }
                }

                if(line.trim().equalsIgnoreCase("bye") || line == null)
                    break;
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

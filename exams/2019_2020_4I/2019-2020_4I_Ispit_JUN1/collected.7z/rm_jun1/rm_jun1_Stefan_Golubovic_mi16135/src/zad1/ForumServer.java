package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

class ForumServer {

    public static final int SERVER_PORT = 7337;
    public static int idOfTheme = 1;
    private int port;
    Map<Integer, String> themes = new ConcurrentHashMap<>();

    public ForumServer(int port) {
        this.port = port;
    }

    public static void main(String[] args) {
        ForumServer server = new ForumServer(SERVER_PORT);
        server.execute();
    }

    private void execute() {

        try (ServerSocket serverSocket = new ServerSocket(this.port)) {

            while (true) {

                Socket client = serverSocket.accept();
                System.err.println("Client accepted...");

                UserThread user = new UserThread(client, this);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

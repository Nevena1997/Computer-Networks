package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {

    public static int DEFAULT_PORT = 7337;

    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    private Socket connection = null;
    ForumURLConnection(URL url) {
        super(url);
    }

    @Override
    public synchronized InputStream getInputStream() throws IOException {
        if(!this.connected)
            this.connect();
        return this.connected ? this.connection.getInputStream() : null;
    }



    @Override
    public synchronized void connect() throws IOException {
        if(!this.connected){
            int port = this.url.getPort();
            if(port <= 0 || port > 65535){
                port = DEFAULT_PORT;
            }

            this.connection = new Socket("localhost", port);
            PrintWriter out = new PrintWriter(this.connection.getOutputStream(), true);

            String query = url.getQuery();
            System.out.println(query);
            this.connected = true;

        }
    }
}

package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    public static int defaultPort=7337;
    private Socket connection=null;
    ForumURLConnection(URL url) {
        super(url);
    }
    public synchronized InputStream getInputStream(){
        try{
            if(!this.connected){
                this.connect();
            }
            return this.connection.getInputStream();
        } catch(IOException e){
            return null;
        }
    }
    @Override
    public void connect() throws IOException {
        if(!this.connected){
            int port=url.getPort();
            if(port<0 || port>65536){
                port=defaultPort;
            }
            this.connection=new Socket(url.getHost(),port);
            this.connected=true;
            BufferedWriter toServer=new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
            //String[] tokens=url.toString().split(new String('?'));
            String input="list";
            toServer.write(input);
            toServer.newLine();
            toServer.flush();
        }
    }
}

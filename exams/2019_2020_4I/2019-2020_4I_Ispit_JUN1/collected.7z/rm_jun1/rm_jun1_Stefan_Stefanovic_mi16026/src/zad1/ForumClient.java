package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {
        try {
            Socket socket=new Socket("localhost",7337);
            PrintWriter toServer=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader fromServer=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner sc=new Scanner(System.in);
            String input="";
            String output="";
            while(true){
                input=sc.nextLine();
                String[] tokens = input.split(" ");
                switch(tokens[0]){
                    case "list":
                        if(tokens.length==1){
                            toServer.println(input);
                            toServer.flush();
                            String temp=fromServer.readLine().replace('\"','\n');
                            System.out.println(temp);
                        }
                        else {
                            System.out.println("nevalidan format");
                        }
                        break;
                    case "reply":
                        if(tokens.length>=3) {
                            try {
                                Integer temp = Integer.parseInt(tokens[1]);
                            } catch (NumberFormatException e) {
                                System.out.println("nevalidan format");
                                break;
                            }
                            toServer.println(input);
                            toServer.flush();
                            System.out.println(fromServer.readLine().replace('\"','\n'));
                        }
                        else{
                            System.out.println("nevalidan format");
                        }
                        break;
                    case "post":
                        if(tokens.length>=3){
                            toServer.println(input);
                            toServer.flush();
                            System.out.println(fromServer.readLine().replace('\"','\n'));
                        }
                        else{
                            System.out.println("nevalidan format");
                        }
                        break;
                    case "bye":
                        if(tokens.length==1){
                            toServer.close();
                            fromServer.close();
                            System.exit(0);
                        }
                        else{
                            System.out.println("nevalidan format");
                        }
                        break;
                    default:
                        System.out.println("nevalidan format");
                }
            }
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        System.out.println("Hello from ForumServer!");
    }
}

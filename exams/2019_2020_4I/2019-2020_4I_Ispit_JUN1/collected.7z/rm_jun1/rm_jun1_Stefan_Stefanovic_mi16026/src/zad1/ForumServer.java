package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.CharBuffer;
import java.util.*;
import java.util.concurrent.SynchronousQueue;
class Lista{
    public static List<String> posts=new ArrayList<String>();
}
class ForumServer {
    static Lista lista=new Lista();
    public static List<String> posts=new ArrayList<String>();

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket=new ServerSocket(7337);
            while(true){
                Socket client=serverSocket.accept();
                new UserThread(client,lista).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class UserThread extends Thread{
    Socket client;
    List<String> posts;
    UserThread(Socket cclient,Lista pposts){
        client=cclient;
        posts=pposts.posts;
    }
    public void run() {
        try {
            PrintWriter toClient = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
            while(true) {
                String input = fromClient.readLine();
                if(input==null) continue;
                String[] tokens = input.split(" ");
                String output = "";
                switch (tokens[0]) {
                    case "list":
                        for (int i = 0; i < posts.size(); i++) {
                            output += (i + 1) + ": " + posts.get(i);
                        }
                        output=output.replace('\n','\"');
                        break;
                    case "reply":
                        if(Integer.parseInt(tokens[1])> posts.size()){
                            output="nevalidan id teme";
                            break;
                        }
                        String temp = posts.get(Integer.parseInt(tokens[1])-1);
                        temp=temp + "- " + tokens[2].replaceAll("\"","")+ "\n";
                        posts.set(Integer.parseInt(tokens[1])-1,temp);
                        output += "reply je uspesno izvrsen";
                        break;
                    case "post":
                        String newpost;
                        String[] tokens2 = input.split("\"");
                        newpost = "# " + tokens2[1] + "\n- " + tokens2[3] + "\n";
                        posts.add(newpost);
                        output += "post je uspesno izvrsen";
                        break;
                }
                toClient.println(output);
                toClient.flush();
            }
        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
package zad1;

import javax.print.attribute.standard.PresentationDirection;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {
        try(Socket client = new Socket("localhost", 7337);
            Scanner sc = new Scanner(System.in);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))){
            ArrayList<String> valid_commands = new ArrayList<>();
            valid_commands.add("bye");
            valid_commands.add("list");
            valid_commands.add("post");
            valid_commands.add("reply");
            while(true){
                String command = sc.nextLine();
                String[] command_tokens = command.split(" ");
                if(!valid_commands.contains(command_tokens[0])){
                    System.out.println("ne validan format");
                    continue;
                }
                if(command_tokens[0].equals("bye")){
                    out.write(command);
                    out.newLine();
                    out.flush();
                    break;
                }

                if(command_tokens[0].equals("list")){
                    if(command_tokens.length != 1){
                        System.out.println("ne validan format");
                        continue;
                    }
                }

                if(command_tokens[0].equals("post")){
                    if(command_tokens.length < 3){
                        System.out.println("ne validan format");
                        continue;
                    }
                }
                if(command_tokens[0].equals("reply")){
                    if(command_tokens.length < 3){
                        System.out.println("ne validan format");
                        continue;
                    }
                }
                out.write(command);
                out.newLine();
                out.flush();

                if(command_tokens[0].equals("list")){
                        String response;
                        while(!(response=in.readLine()).equals("*")) {
                            System.out.println(response);
                        }


                }else
                {
                    String response;
                    response = in.readLine();
                    System.out.println(response);
                }




            }



        }catch (Exception e){
            e.printStackTrace();
        }




    }
}

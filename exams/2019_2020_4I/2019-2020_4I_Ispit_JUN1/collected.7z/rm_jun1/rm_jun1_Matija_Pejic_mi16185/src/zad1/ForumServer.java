package zad1;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class ForumServer {
    public static Map<Integer, ArrayList<String>> teme = new HashMap();
    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(7337)){
            while(true){
                Socket client = server.accept();
                System.out.println("Klijent uspesno primljen!");
                new Thread(new Runnable(client)).start();
            }




        }catch (Exception e){
            e.printStackTrace();
        }





        System.out.println("Hello from ForumServer!");
    }
}

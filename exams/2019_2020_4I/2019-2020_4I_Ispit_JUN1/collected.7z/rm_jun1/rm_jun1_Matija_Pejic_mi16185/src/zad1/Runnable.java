package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

public class Runnable implements java.lang.Runnable {
    public static Socket client;
    Runnable(Socket client){
        this.client = client;
    }

    public static String[] parse_input(String in){
        String tokens = in.replace(" ","");
        String[] parsed = tokens.split("\"");
        return parsed;

    }
    @Override
    public void run() {
            try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {
                int next_item_id = 1;
                while (true){
                    String received_line = in.readLine();
                    if(received_line.equals("bye"))
                        break;
                    out.write(received_line.split(" ")[0] + " je uspesno izvrsen!");
                    out.newLine();
                    out.flush();
                    String[] command_tokens = received_line.split(" ");
                    if(command_tokens[0].equals("list")){
                        for(int key:ForumServer.teme.keySet()){
                            int i = 0;
                            out.write(key + ":");
                            for(String token:ForumServer.teme.get(key)){
                                if(token.equals("") || token.equals(" "))
                                    continue;
                                if(i == 0){
                                    out.write(token);
                                    out.newLine();
                                    i =1;
                                }else {
                                    out.write("    -" + token);
                                    out.newLine();
                                }
                            }


                        }
                        out.write("*");
                        out.newLine();
                        out.flush();


                    }

                    if(command_tokens[0].equals("post")){
                        String[] to_input = parse_input(received_line);
                        int i;
                        ArrayList to_add = new ArrayList();
                        for(i = 1; i < to_input.length ; i++){
                            to_add.add(to_input[i]);
                        }
                        ForumServer.teme.put(next_item_id,to_add);
                        next_item_id++;

                    }

                    if(command_tokens[0].equals("reply")){
                        if(ForumServer.teme.containsKey(new Integer(command_tokens[1]))){
                            ArrayList current = ForumServer.teme.get(new Integer(command_tokens[1]));
                            current.add(command_tokens[2].replace("\"",""));
                            ForumServer.teme.replace(new Integer(command_tokens[1]),current);


                        }else {
                            System.out.println("Invalid key!");
                            continue;
                        }


                    }




            }


            }catch (Exception e){
                e.printStackTrace();
            }
    }
}

package zad2;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

class ProtocolHandlerTest {
    public static void main(String[] args) throws IOException {

        System.out.println("Hello from protocol test method!");

        URL u = new URL(null,"forum://localhost", new Handler());

        URLConnection con = u.openConnection();
        BufferedInputStream in = new BufferedInputStream(con.getInputStream());
//        System.out.println(in.read());
    }
}
package zad2;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */

    private Socket soket;

    ForumURLConnection(URL url) {
        super(url);
    }

    public InputStream getInputStream() throws IOException {
        if(!this.connected)
            return null;

        return null;
//       return this.soket.getInputStream();
    }

    @Override
    public synchronized  void connect() throws IOException {
        if(!this.connected){
            int port = this.url.getPort();
            if(port == -1){
                port = Handler.getPort();
            }
            this.soket = new Socket(this.url.getHost(), port);
            this.connected = true;
        }
        URLEncoder.encode("q", StandardCharsets.UTF_8);

    }
}

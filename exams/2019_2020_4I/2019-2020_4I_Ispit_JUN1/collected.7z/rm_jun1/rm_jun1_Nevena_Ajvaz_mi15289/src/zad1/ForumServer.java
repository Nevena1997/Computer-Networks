package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

class ForumServer {
    public static void main(String[] args) {

        System.out.println("Hello from ForumServer!");
        try(ServerSocket server = new ServerSocket(7337)){

            while(true){
                Socket klijent = server.accept();

                new Thread(new ServeClientRunnable(klijent)).start();


            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

public class Forum {

    private String title;
    private String content;
    private int id =0;

    public Forum(String title, String content){
        this.title = title;
        this.content = content;
        this.id++;
    }


    public int getId() {
        return this.id;
    }

    public void dodaj(String contentForAdding) {
        this.content = this.content + contentForAdding;
    }
}

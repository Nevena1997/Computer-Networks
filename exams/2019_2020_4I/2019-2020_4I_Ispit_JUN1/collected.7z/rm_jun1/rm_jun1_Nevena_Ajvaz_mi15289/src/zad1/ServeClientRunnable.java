package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.List;
import java.util.Set;

public class ServeClientRunnable implements Runnable{

    private Socket klijent;
    public List<Forum> klijenti;

    public ServeClientRunnable(Socket klijent) {
        this.klijent = klijent;
    }

    @Override
    public void run() {
        try {
            while(true){
                BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
                String zahtev = in.readLine();

                obradiZahtev(zahtev);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private synchronized void obradiZahtev(String zahtev) {

        if(zahtev.startsWith("list")){
            for(Forum f: klijenti){
                System.out.println(f);
            }
        }
        if(zahtev.startsWith("reply")){
            String[] reci = zahtev.split(" ");
            int id = Integer.parseInt(reci[1]);
            String content = reci[2];

            for(Forum f:klijenti){
                if (f.getId() == id){
                    f.dodaj(content);
                    System.out.println("reply je uspeno izvrsen");
                }
            }
        }
        if(zahtev.startsWith("post")){
            int startindexOfQuote1 = zahtev.indexOf('"')+1;
            int endindexQuote1 = zahtev.indexOf('"', startindexOfQuote1+1)-1;

            int startindexOfQuote2 = zahtev.indexOf('"', endindexQuote1+1)+1;
            int endindexQuote2 = zahtev.indexOf('"', startindexOfQuote2)-1;

            String title = zahtev.substring(startindexOfQuote1, endindexQuote1).trim();
            String content = zahtev.substring(startindexOfQuote2, endindexQuote2).trim();

            klijenti.add(new Forum(title, content));
            System.out.println("post je uspeno izvrsen");

        }
    }
}

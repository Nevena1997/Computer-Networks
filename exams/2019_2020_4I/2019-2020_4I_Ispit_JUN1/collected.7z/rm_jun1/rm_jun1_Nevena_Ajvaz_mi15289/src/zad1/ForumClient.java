package zad1;

import java.io.*;
import java.net.Socket;

class ForumClient {
    public static void main(String[] args) {
        System.out.println("Hello from ForumClient!");

        try(Socket klijent = new Socket("localhost", 7337)){


            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            String linija;
            while(true){
                linija = in.readLine();
                if(linija.trim().equalsIgnoreCase("bye"))
                    break;
//                if(isValid(linija)){
                out.write(linija);
                out.newLine();
                out.flush();
//                }

            }

            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static boolean isValid(String linija) {
        String[] reci = linija.split(" ");

        for(int i=0; i<reci.length; i++) {

            if (!reci[i].contains("list")){
                return false;
            }
            if (!reci[i].contains("post")){
                return false;
            }
            if (!reci[i].contains("reply")){
                return false;
            }

        }
        return true;
    }
}

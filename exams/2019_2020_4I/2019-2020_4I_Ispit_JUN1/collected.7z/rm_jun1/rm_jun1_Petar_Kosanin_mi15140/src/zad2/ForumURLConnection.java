package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

class ForumURLConnection extends URLConnection {
    /**
     * Constructs a URL connection to the specified URL. A connection to
     * the object referenced by the URL is not created.
     *
     * @param url the specified URL.
     */
    ForumURLConnection(URL url) {
        super(url);
    }

    private Socket socket;

    @Override
    public void connect() throws IOException {

        int port = this.url.getPort();
        String host = this.url.getHost();

        if (port < 0 || port > 65355)
        {
            //System.out.println("Nevalidan port, koristim default");
            port = 7337;
        }

        if (!this.connected) {
            this.socket = new Socket(host, port);

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));

            String query = this.url.getQuery();
            if (query == null || query.equalsIgnoreCase(""))
            {
                out.write("list");
                out.newLine();
                out.flush();
            } else {
                System.out.println(query);
                out.write(query.substring(2));
                out.newLine();
                out.flush();
            }



        }

        this.connected = true;

    }

    @Override
    public InputStream getInputStream() throws IOException {
        if (!this.connected)
            this.connect();

        return this.socket.getInputStream();
    }
}

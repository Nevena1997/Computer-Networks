package zad1;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.util.*;

class ForumServer {

    public Set<String> validCommands;
    public Map<Integer, ArrayList<String>> themes;
    public int currentID;


    public ForumServer() {
        this.validCommands = new HashSet<>();

        this.validCommands.add("list");
        this.validCommands.add("reply");
        this.validCommands.add("post");

        themes = new HashMap<>();

        this.currentID = 0;
    }

    public static void main(String[] args) {

        ForumServer server = new ForumServer();
        server.execute();
    }

    private void execute() {

        try (ServerSocket server = new ServerSocket(7337)) {

            while (true) {
                Socket client = server.accept();
                new UserThread(client, this).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handlePost(String[] tokens) {
        var theme = new ArrayList<String>();
        theme.add(tokens[1]);
        theme.add(tokens[2]);

        this.themes.put(currentID, theme);
        currentID += 1;

    }

    public String printTheme(ArrayList<String> theme)
    {
        StringBuilder response = new StringBuilder();
        response.append("# " + theme.get(0) + ' ');
        for (int i = 1; i < theme.size(); i++) {
            response.append("- " + theme.get(i) + ' ');
        }

        return response.toString();
    }

    public ArrayList<String> handleList()
    {
        ArrayList<String> themesStr = new ArrayList<>();
        themes.values().forEach(val -> themesStr.add(printTheme(val)));
        return themesStr;
    }

    public void handleReply(String[] tokens) {
        int id = Integer.parseInt(tokens[1]);
        String content = tokens[2];
        if (this.themes.containsKey(id))
        {
            // TODO fix strukturu podataka
            var theme = this.themes.get(id);
            theme.add(content);
            this.themes.put(id, theme);
        }
    }


}

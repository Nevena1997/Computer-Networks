package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

class ForumClient {
    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", 7337);
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
             Scanner userInput = new Scanner(System.in)) {

            String request = null;
            do
            {
                System.out.println("unesi zahtev:");
                request = userInput.nextLine();


                out.write(request);
                out.newLine();
                out.flush();

                String response = in.readLine();
                if (response == null)
                    break;

                System.out.println(response);



            } while (!request.equalsIgnoreCase("bye"));



        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

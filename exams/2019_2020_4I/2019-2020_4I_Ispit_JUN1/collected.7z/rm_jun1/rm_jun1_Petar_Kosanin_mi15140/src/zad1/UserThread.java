package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class UserThread extends Thread {

    private Socket client;
    private ForumServer forumServer;

    public UserThread(Socket client, ForumServer forumServer) {
        this.client = client;
        this.forumServer = forumServer;
    }

    @Override
    public void run() {
        System.out.println("prihvatio sam klijenta");
        try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))){


            while (true) {

                String request = in.readLine();

                if(request == null || request.equalsIgnoreCase("bye"))
                    break;


                var tokens = request.split(" ");



                if (tokens[0].equalsIgnoreCase("post")) {
                    if (tokens.length  == 3) {
                        forumServer.handlePost(tokens);
                        out.write("post uspesno izvrsen");
                    }
                    else
                        out.write("nevalidan format");


                } else if (tokens[0].equalsIgnoreCase("reply")) {
                    forumServer.handleReply(tokens);
                    out.write("reply uspesno izvrsen");


                } else if (tokens[0].equalsIgnoreCase("list")) {
                    var themes = forumServer.handleList();

                    themes.forEach(theme -> {
                        try {
                            out.write(theme);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });

                } else {
                    out.write("nevalidan format");
                }

                out.newLine();
                out.flush();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }





}

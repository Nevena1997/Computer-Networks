package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Zad1Main {

    public static int brRegFajlova = 0;
    public static int brLinija = 0;
    public static List<Thread> tids;

    //synchronize fja
    public synchronized static void add(){
        Zad1Main.brLinija += 1;
    }

    public static void main(String[] args) {
        Zad1Main.tids = new ArrayList<>();
//          ja sam prebacio test u lokalno okruzenje projekta pa sam koristio rel putanju
//        moze i /home/ispit/Desktop/tests
        System.err.println("*************");
        System.err.println("Nisam stavio abs putanju za test dir, prebacio sam ga u direktorijum" +
                " projekta , pa sam koristio relativnu putanju do njega, on se i dalje nalazi na /home/ispit/Desktop/tests" +
                " a ja sam ga dodatno prekopirao , da mi olaksa rad");
        System.err.println("Zamenom path =  /home/ispit/Desktop/tests  program radi isto");
        System.err.println("Prvo ispisujem sve url-ove pa broj fajlova, jer koristim rekurzivnu fju obilaska," +
                " Ivan je rekao da je to uredu i da nije problem :)");
        System.err.println("*************");
//        String path = "/home/ispit/Desktop/tests";
        String path = "tests";

        walk(Paths.get(path));
        System.out.println("Files:" + Zad1Main.brRegFajlova);

//        Thread join
        int size = Zad1Main.tids.size();
        for(int i = 0;i < size;i++){
            try {
//                System.out.println(Zad1Main.tids);
//                System.out.println(Zad1Main.tids.size());
                Thread t = Zad1Main.tids.remove(0);
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Result:" + Zad1Main.brLinija);
    }

    public static void walk(Path path){
        try(DirectoryStream<Path> ps = Files.newDirectoryStream(path)){
            for(Path p : ps){
                if(Files.isDirectory(p)){
                    walk(p);
                }else{
                    Zad1Main.brRegFajlova += 1;
                    String pth = p.toString();
                    int index = 0;
                    index = pth.lastIndexOf(".");
                    if(index != -1){
                        String ext = pth.substring(index);
                        if(ext.equalsIgnoreCase(".c")){
                            URL url = new URL("file://" + p.toAbsolutePath().toString());
//                            URL u = new URL("file",null,p.toAbsolutePath().toString()); umesto null moze localhost
                            System.out.println("url:" + url.toString());
                            FileProcessorRunnable run = new FileProcessorRunnable(url);
                            Thread t  = new Thread(run);
                            Zad1Main.tids.add(t);
                            t.start();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandler implements Runnable {

    private Socket client;

    public ClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try {
            Scanner in = new Scanner(new InputStreamReader(this.client.getInputStream()));
            PrintWriter out = new PrintWriter(this.client.getOutputStream(),true);
            String putanja = null;
            if(in.hasNextLine()){
                putanja = in.nextLine();
            }
            System.out.println(putanja);
//            isto kao i u 1. zadatku koristimo sam rel putanju do tests direktorijuma,
//            program bi isto radio da sam umesto putanjaDoTests = Paths.get("tests").toAbsolutePath();
//            stavio i putanjaDoTests = Paths.get("/home/ispit/Desktop/tests").toAbsolutePath();
            Path putanjaDoTests = Paths.get("/home/ispit/Desktop/tests").toAbsolutePath();
            String absPutanja  = putanjaDoTests.toString() + "/" + putanja;

            try(Scanner citacFajla = new Scanner(new InputStreamReader(new FileInputStream(absPutanja)))){
                out.println("Validna putanja");
                Double suma = 0.0;
                Double tmp = 0.0;
                while(citacFajla.hasNext()){
                    try {
                       tmp = Double.parseDouble(citacFajla.next());
                    }catch (NumberFormatException e){
                        continue;
                    }
                    suma += tmp;
                }
                if(suma == 0.0){
                    out.println("Fajl ne sadrzi realne brojeve");
                }else{
                    out.println(suma.toString());
                }
            }catch (IOException e){
                out.println("Ne validna putanja");
            }

//            zatvaramo resurse i klijentski soket
            in.close();
            out.close();
            this.client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

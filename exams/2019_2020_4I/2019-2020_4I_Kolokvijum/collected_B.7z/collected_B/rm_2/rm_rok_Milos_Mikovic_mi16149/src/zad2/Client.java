package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {


        try {
            Scanner sc = new Scanner(System.in);
            Socket sock = new Socket("localhost",Server.DEFAULT_PORT);
            System.out.print("Ulaz:");
            String ulaz = sc.nextLine();

            PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
            Scanner in = new Scanner(new InputStreamReader(sock.getInputStream()));
            out.println(ulaz);


            String validnaNe = null;
            if(in.hasNextLine()){
                validnaNe = in.nextLine();
            }
            System.out.println(validnaNe);

            String rezultat = null;
            if(in.hasNextLine()){
                rezultat = in.nextLine();
                System.out.println(rezultat);
            }


//            zatvaramo resurse
            sc.close();
            sock.close();
            in.close();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

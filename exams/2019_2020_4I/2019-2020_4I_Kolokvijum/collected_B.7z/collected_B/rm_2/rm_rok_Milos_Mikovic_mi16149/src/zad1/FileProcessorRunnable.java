package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class FileProcessorRunnable implements Runnable {

    private URL url;


    public FileProcessorRunnable(URL url) {
        this.url = url;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(this.url.openStream(), StandardCharsets.US_ASCII));
            String line;
            while((line = in.readLine()) != null){
//                poziv synhronize fje iz Zad1Main
                Zad1Main.add();
            }
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

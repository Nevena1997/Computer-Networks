package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Server {

    public static final int DEFAULT_PORT = 31415;

    public static void main(String[] args) {



        try(ServerSocket server = new ServerSocket(Server.DEFAULT_PORT)){
            System.err.println("Listening on port:" + Server.DEFAULT_PORT);
            System.err.println("******************************");
            System.err.println("Isto kao i u 1. zadatku koristimo sam rel putanju do tests direktorijuma,\n" +
                    "program bi isto radio da sam umesto putanjaDoTests = Paths.get(\"tests\").toAbsolutePath();\n" +
                    "stavio i putanjaDoTests = Paths.get(\"/home/ispit/Desktop/tests\").toAbsolutePath();");
            System.err.println("******************************");
            while(true){
                Socket client = server.accept();
                new Thread(new ClientHandler(client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

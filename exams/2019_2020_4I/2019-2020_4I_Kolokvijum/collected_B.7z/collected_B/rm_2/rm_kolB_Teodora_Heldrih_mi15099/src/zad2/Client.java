package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 31415);
         BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
         BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
         BufferedReader sin = new BufferedReader(new InputStreamReader(System.in))) {
            String path = sin.readLine();

            out.write(path);
            out.newLine();
            out.flush();

            String ind = in.readLine();
            System.out.println(ind);

            String zbir = in.readLine();
            System.out.println(zbir);

        } catch(UnknownHostException ex) {
            System.err.println("Nepoznat host");
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    }
}

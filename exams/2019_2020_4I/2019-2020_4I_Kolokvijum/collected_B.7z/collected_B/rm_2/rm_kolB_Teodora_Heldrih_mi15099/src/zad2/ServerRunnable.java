package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.net.URLStreamHandler;

public class ServerRunnable implements Runnable {
    Socket _client;

    ServerRunnable(Socket client) {
        this._client = client;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(_client.getInputStream()));
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(_client.getOutputStream()))) {
            String path = in.readLine();

            System.out.println(path);

            try (BufferedReader file_in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/" + path)))) {
                out.write("Validna putanja");
                out.newLine();
                out.flush();

                String line;
                String line_split[];
                double num = 0;
                while((line = file_in.readLine()) != null) {
                    line_split = line.split(" ");
                    for(String l : line_split) {

                    }
                }

                out.write(Double.toString(num));
                out.newLine();
                out.flush();

            } catch(IOException ex) {
                out.write("File not valid");
                out.newLine();
                out.flush();
            }
        } catch(IOException ex) {
            ex.printStackTrace();
        }


    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandlerRunnable implements Runnable {
    private static Socket client;


    ClientHandlerRunnable(Socket client){
        this.client = client;
    }


    @Override
    public void run(){
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))
        ){
           // System.out.println("Thread id: " + Thread.currentThread().getId());
            String path = in.readLine();
            String base = "/home/ispit/Desktop/tests";
            StringBuffer buf = new StringBuffer(base);
            buf.append("/" + path);
            try{
                Scanner sc = new Scanner(new FileInputStream(buf.toString()));
                out.write("Path is good!\n");
                Double sum = 0.0;
                while(sc.hasNextDouble()){
                    sum += sc.nextDouble();
                }

                String number = sum.toString();
                out.write(number);
                out.newLine();
                out.flush();

            }
            catch (FileNotFoundException e){
                out.write("File is not found. Bad address.");
                System.err.println("File is not found.");
            }
            System.out.println("Path: " + buf.toString());
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.locks.Lock;

public class FileRunnable implements Runnable {
    private URL filepath;
    private Lock lock;
    private static int numOfLines;

    FileRunnable(URL urlString, int numOfLines) {
        this.filepath = urlString;
        this.numOfLines = numOfLines;
    }

    @Override
    public void run() {
        //System.out.println("THread inside a thread: " + Thread.currentThread().getId());
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filepath.toString()),
                StandardCharsets.US_ASCII))
        ) {

            int number = 0;
            while(in.readLine() != null){
                number++;
            }

            System.out.println("Number of lines: " + number);

            try{
                lock.lock();
                this.numOfLines += number;
            }
            finally {
                lock.unlock();
            }

        } catch (IOException e) {
                e.printStackTrace();
        }

    }
}

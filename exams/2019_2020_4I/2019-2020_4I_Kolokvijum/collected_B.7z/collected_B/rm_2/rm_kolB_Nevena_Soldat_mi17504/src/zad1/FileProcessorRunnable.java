package zad1;

import java.net.MalformedURLException;
import java.net.URL;

public class FileProcessorRunnable implements Runnable {
    private static String filePath;
    private static int numOfLines;

    FileProcessorRunnable(String filepath){
        this.filePath = filepath;
        this.numOfLines = 0;
    }

    @Override
    public void run() {
        //System.out.println("Thread id: " + Thread.currentThread().getId());
        String fileExt = filePath.substring(filePath.lastIndexOf('.'));
        if(fileExt == "c"){
            try {
                String stringUrl = "FILE://" + filePath;
                URL u = new URL(stringUrl);
                System.out.println(u.toString());

                new Thread(new FileRunnable(u, numOfLines)).start();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }
}

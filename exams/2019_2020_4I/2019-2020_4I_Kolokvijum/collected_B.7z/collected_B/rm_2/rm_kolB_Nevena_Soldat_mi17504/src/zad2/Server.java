package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server{
    public static final int DEFAULT_PORT = 31415;
    private static Socket client;

    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");

        while(true) {
            try (ServerSocket server = new ServerSocket(DEFAULT_PORT)
            ) {
                client = server.accept();

                new Thread(new ClientHandlerRunnable(client)).start();


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}

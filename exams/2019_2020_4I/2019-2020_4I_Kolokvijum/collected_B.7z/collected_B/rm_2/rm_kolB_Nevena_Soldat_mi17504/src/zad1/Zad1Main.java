package zad1;

public class Zad1Main {
    private static String filepath = "/home/ispit/Desktop/tests/dir/dir1/smile.c";

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        Thread t = new Thread(new FileProcessorRunnable(filepath));
        t.start();

        System.out.println("Srecno!");
    }
}

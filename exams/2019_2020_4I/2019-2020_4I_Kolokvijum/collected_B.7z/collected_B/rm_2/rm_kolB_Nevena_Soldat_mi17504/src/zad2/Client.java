package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static String hostname = "localhost";


    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");

        try(Socket sock = new Socket(hostname, Server.DEFAULT_PORT);
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter netOutput = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
            BufferedReader netInput = new BufferedReader(new InputStreamReader(sock.getInputStream()))
        ){
            System.out.println("Unesite relativnu putanju: ");
            String line = input.readLine();

            netOutput.write(line);
            netOutput.newLine();
            netOutput.flush();

            String lineFromServer = netInput.readLine();
            System.out.println(lineFromServer);

            String line1 = netInput.readLine();
            if(line1 == null){
                System.out.println("Fajl ne sadrzi realne brojeve.");
            }
            else{
                System.out.println(line1);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {

    public static final Path end= Paths.get("");
    private BlockingQueue<Path> queue;
    private Path dir;

    public void run() {
        try{
            obilazak(this.dir);
            this.queue.put(end);
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
    }
    //II nacin
    private void obilazak(Path dir) throws InterruptedException{
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)){
            for(Path p: ds) {
                if(Files.isDirectory(p))
                    obilazak(p);
                else
                    this.queue.put(p);
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import static java.net.InetAddress.getLocalHost;

public class Client {
    public static void main(String[] args) {

        try (Socket sock = new Socket(getLocalHost(),31415)) {
            OutputStream out = new BufferedOutputStream(sock.getOutputStream());
            InputStream in = new BufferedInputStream(sock.getInputStream());

        } catch (UnknownHostException e) {
            System.err.println("Hostname");;
        } catch (IOException e) {
            System.err.println("Problem - konekcija");;
        }

        try (ServerSocket server = new ServerSocket(31415)){
            Socket klijent = server.accept();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

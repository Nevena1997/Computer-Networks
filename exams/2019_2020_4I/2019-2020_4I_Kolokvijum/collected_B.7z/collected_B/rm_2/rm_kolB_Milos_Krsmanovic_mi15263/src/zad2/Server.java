package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class Server {
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(31415)){
            while(true) {
                Socket client = server.accept();
            }
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

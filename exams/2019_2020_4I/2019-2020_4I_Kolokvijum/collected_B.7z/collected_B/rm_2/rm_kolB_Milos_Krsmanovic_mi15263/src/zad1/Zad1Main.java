package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {

    public static final Path end= Paths.get("");
    private BlockingQueue<Path> queue;
    private Path dir;

    public static void main(String[] args) {
        Path dir = Paths.get("/home/ispit/Desktop/tests");
        //obilazak(dir);


}

    private void obilazak(Path dir) {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)){
            for(Path p: ds) {
                if(Files.isDirectory(p))
                    obilazak(p);
                else
                    this.queue.put(p);
            }
        } catch (IOException | InterruptedException e){
            e.printStackTrace();
        }
    }
    }

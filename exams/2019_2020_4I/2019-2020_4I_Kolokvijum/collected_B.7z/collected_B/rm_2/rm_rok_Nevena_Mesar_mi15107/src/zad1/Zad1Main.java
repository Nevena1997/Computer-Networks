package zad1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {

    public static void rekurzivanObilazak(File dir){
        synchronized (fajlovi){
            if(dir.isDirectory()){
                File[] listaFajlova = dir.listFiles();
                if(listaFajlova != null) {
                    for(File d: listaFajlova){
                        rekurzivanObilazak(d);
                    }
                }
            }
            else if(dir.isFile()){
                // nisam sigurna da li i atomicne promenljive moraju da budu unutar nekog bloka
                brRegularnihFajlova.incrementAndGet();
                if(dir.getName().endsWith(".c")) {
                    fajlovi.add(kreirajURL(new File(dir.getAbsolutePath())));
                }
            }
        }
    }

    private static URL kreirajURL(File f){
        URL url = null;
        try {
            url = new URL("FILE","",f.getAbsolutePath().toString());
        } catch (MalformedURLException e) {
            System.out.println("URL nije validan:" + e.getLocalizedMessage());
        }
        return url;
    }

    private static Collection fajlovi;
    private static AtomicInteger brRegularnihFajlova;
    public static AtomicInteger brLinija;

    public static void main(String[] args) {

        File direktorijum = new File("tests");
        if(!direktorijum.exists()){
            System.out.println("Nije pronadjen test fajl u odnosu na projekat!\nPotrebno promeniti u kodu.");
        }
        fajlovi = Collections.synchronizedCollection(new ArrayList<URL>());
        // inicijalno je 0
        brRegularnihFajlova = new AtomicInteger();
        brLinija = new AtomicInteger();

        rekurzivanObilazak(direktorijum);

        System.out.println("files:\t\t" + brRegularnihFajlova.toString());

        // Ispis fajlova koje je nasao i pokretanje niti
        synchronized (fajlovi){

            Iterator iter = fajlovi.iterator();

            for (Iterator<URL> it = iter; it.hasNext(); ) {
                URL f = it.next();
                FileProcessorThread t = new FileProcessorThread(f);
                t.start();
                System.out.println("url:\t\t"+f.toString());
            }
        }
        // TODO: popraviti FileProcessorThread, postaviti na ascii kodnu stranu
        System.out.println("result:\t\t"+brLinija);

//        System.out.println("Srecno!");
    }
}

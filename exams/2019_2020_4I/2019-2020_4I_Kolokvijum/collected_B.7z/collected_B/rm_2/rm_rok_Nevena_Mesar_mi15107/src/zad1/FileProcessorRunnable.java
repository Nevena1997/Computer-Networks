package zad1;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;

public class FileProcessorRunnable implements Runnable {

    private URL fileUrl;

    public FileProcessorRunnable(URL fileURL){
        this.fileUrl = fileURL;
    }

    @Override
    public void run() {
/*
        try {
            URLConnection urlConn = this.fileUrl.openConnection();
        } catch (IOException e) {
            System.out.println("Greska prilikom otvaranja konekcije: nit="+this.inde);
        }


        BufferedInputStream inStream = new BufferedInputStream(

        )*/
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int DEFAULT_PORT = 31415;

    public static void main(String[] args) {
//        System.out.println("Srecno od strane servera!");
        ServerSocket socket;
        try {
            socket = new ServerSocket(DEFAULT_PORT);
            while(true){
                ServerNit nit = new ServerNit(socket.accept());
                nit.start();
            }
        } catch (IOException e){
            System.out.println("Doslo je do greske: " + e.getLocalizedMessage());
        }
    }
}

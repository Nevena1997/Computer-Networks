package zad2;

import java.net.Socket;

public class ServerNit extends Thread {

    private Socket client;

    public ServerNit(Socket client){
        this.client = client;
    }

    @Override
    public void run() {

        // Todo: preuzimanje stvari od klijenta i njegova obrada.

    }

}

package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

public class FileProcessorThread extends Thread {

    private URL fileUrl;

    public FileProcessorThread(URL fileURL){
        this.fileUrl = fileURL;
    }

    @Override
    public void run() {
        URLConnection urlConn = null;
        BufferedInputStream inStream = null;
        try {
            urlConn = this.fileUrl.openConnection();

            inStream = new BufferedInputStream(
                    urlConn.getInputStream()
            );
            int procitano;
            while((procitano = inStream.read()) != -1){
                // treba li da se kastuje u byte pa da se proveri da li je negativno pa da se konvertuje???
                if(procitano=='\n'){
                    Zad1Main.brLinija.incrementAndGet();
                }
            }

        } catch (IOException e) {
            System.out.println("Greska prilikom otvaranja konekcije: NitId="+this.getId());
            System.out.println("\t:"+e.getLocalizedMessage());
        }finally {
            if(inStream!=null){
                try{
                    inStream.close();
                } catch (IOException e){
                    System.out.println("Neuspelo zatvaranje stream-a: NitId="+this.getId());
                    System.out.println("\t:"+e.getLocalizedMessage());
                }
            }
        }

    }
}

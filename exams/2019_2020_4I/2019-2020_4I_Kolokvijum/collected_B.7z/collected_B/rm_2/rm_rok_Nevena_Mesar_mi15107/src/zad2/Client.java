package zad2;

import java.io.IOException;
import java.net.Socket;

public class Client {
    public static void main(String[] args) {
//        System.out.println("Srecno od strane klijenta!");
        Socket client = new Socket();
        try {
            client.close();
        } catch (IOException e) {
            System.out.println("Neuspelo zatvaranje soketa klijenta: "+ e.getLocalizedMessage());
        }
    }
}

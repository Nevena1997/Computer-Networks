package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        //System.out.println("Srecno od strane klijenta!");

            try (Socket socket = new Socket("localhost", 31415)) {

                BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
                String path = stdin.readLine();

                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

                // saljemo putanju
                if (path != null) {
                    out.write(path);
                    out.newLine();
                    out.flush();
                }

                // citamo da li je validna linija
                String indikator  = in.readLine();
                if (indikator != null)
                    System.out.println(indikator); //da li je putanja validna ili ne

                String line;
                line = in.readLine();
                if (line != null)
                    System.out.println(line);

                stdin.close();
                in.close();
                out.close();
            } catch (UnknownHostException e) {
                System.err.println("Unknown host");
            } catch (FileNotFoundException e) {
                System.out.println("Nije validna putanja");
            } catch (IOException e) {
                System.err.println("client socket failed");
            }

    }
}

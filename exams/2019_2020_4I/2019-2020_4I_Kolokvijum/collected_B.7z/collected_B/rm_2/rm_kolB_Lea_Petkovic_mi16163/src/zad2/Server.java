package zad2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws FileNotFoundException {

        //System.out.println("Srecno od strane servera!");

        try(ServerSocket server = new ServerSocket(31415)) {

            while (true) {
                Socket client = server.accept();
                new Thread(new UserThread(client)).start();

            }

        } catch (IOException e) {
            System.err.println("Server Socket failed");
        }
    }
}

package zad1;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class FileWalker {

    public static int numOfFiles = 0;
    public int count = 0;

    public void walk(DirectoryStream<Path> dirs) throws IOException {
        for (Path p : dirs) {
            File f = new File(String.valueOf(p));
            if (f.isDirectory()) {
                DirectoryStream<Path> dir = Files.newDirectoryStream(p);
                this.walk(dir);
            } else if (f.isFile()) {
                numOfFiles += 1;
                String pathStr = p.toString();

                // fajl sa ekstenzijom .c
                if (pathStr.toString().contains(".c")) {

                    String url = "FILE:///home/ispit/Desktop/" + pathStr;        // odgovarajuci url

                    System.out.println("url: " + url);
                    URL u = new URL(url);

                    Thread t = new Thread(new FileProcessorRunnable(u, this));
                    t.start();
                    try {
                        // cekanje na niti radi ispravnog broja linija
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        }
    }

    public void setCount(int i) {
        this.count = i;
    }
}
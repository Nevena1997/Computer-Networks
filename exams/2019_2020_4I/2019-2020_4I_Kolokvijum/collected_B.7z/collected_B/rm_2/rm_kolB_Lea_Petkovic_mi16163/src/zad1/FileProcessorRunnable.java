package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {
    private URL url;
    FileWalker obj;


    public FileProcessorRunnable(URL u, FileWalker fw) {
        this.url = u;
        this.obj = fw;
    }

    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII))) {
            String line;
            int c = 0;
            while ((line = in.readLine()) != null)
                c += 1;

            this.obj.setCount(this.obj.count + c);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

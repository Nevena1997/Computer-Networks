package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Zad1Main {

    public static void main(String[] args) {

        String dirStr = "tests";
        Path dir = Paths.get(dirStr);

        DirectoryStream<Path> dirs = null;
        try {
            dirs = Files.newDirectoryStream(dir);

            FileWalker fw = new FileWalker();
            fw.walk(dirs);

            System.out.println("files: " + fw.numOfFiles);
            System.out.println(fw.count);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

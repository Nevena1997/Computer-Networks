package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class UserThread implements Runnable {
    Socket client;

    public UserThread(Socket sock) {
        this.client = sock;
    }

    @Override
    public void run() {

        try(BufferedReader in =
                    new BufferedReader(new InputStreamReader(this.client.getInputStream()));
            BufferedWriter out =
                    new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))) {

            // primamo  putanju
            String line = in.readLine();
            System.out.println(line);

            // otvaramo fajl na datoj putanji
            Scanner file = new Scanner(new FileInputStream(line));
            //System.out.println(file);
            if (file == null) {
                out.write("Nije validna putanja.");

            } else {

                out.write("Validna putanja");
                out.newLine();
                out.flush();
                double suma = 0.0;
                while (file.hasNext()) {

                    if (file.hasNextDouble()) {
                        suma += file.nextDouble();
                    }
                    else{
                        file.next();
                        continue;
                    }
                }
                if (suma > 0.0)
                    out.write("" + suma);
                out.flush();
            }



        } catch (FileNotFoundException e) {
            System.out.println("Nije validna putanja");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

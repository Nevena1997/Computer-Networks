package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Client {

    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");
        //koristimo automatsko zatvaranje resursa,  mogli su svi resursi da se stave u try()
        //konektujemo se na server
        try(Socket sock = new Socket(Server.HOST,Server.PORT);
            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()))){
            Path putanja;
            putanja = Paths.get(userIn.readLine());
            //saljemo serevru putanju
            toServer.write(putanja.toString());
            toServer.flush();
            //citamo od servera odgovor da li je validna putanja
            int valid = fromServer.read();
            if (valid==0)
                System.out.println("Nevalidna putanja");
            else {
                //putanja je validna ispisi rezuyltat
                System.out.println("Validna putanja");
                //pisemo rezultat
                String rez = fromServer.readLine();
                Double r = Double.valueOf(rez);
                if (r==0)
                    System.out.println("Fajl ne sadrzi realne brojeve");
                else
                    System.out.println(r);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

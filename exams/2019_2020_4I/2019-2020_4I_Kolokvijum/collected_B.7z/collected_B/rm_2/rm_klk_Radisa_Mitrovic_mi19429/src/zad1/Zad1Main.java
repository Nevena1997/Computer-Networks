package zad1;

public class Zad1Main {
    static int brojac = 0;
    static int brojRegularnih=0;
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        String putanja = "tests";//pocetni direktorijum
        new Thread(new FileProcessorRunnable(putanja)).start();
        System.out.println("Srecno!");

    }
}

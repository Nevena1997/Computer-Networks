package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    static final String HOST="localhost";
    static final int PORT=31415;
    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");


        try(ServerSocket server = new ServerSocket(PORT)){
            while (true){
                Socket client = server.accept();
                //kreiramo nit koja obradjuje klijenta, ne sme sa automatskim zatv resursa
                new Thread(new ClientHandler(client)).start();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

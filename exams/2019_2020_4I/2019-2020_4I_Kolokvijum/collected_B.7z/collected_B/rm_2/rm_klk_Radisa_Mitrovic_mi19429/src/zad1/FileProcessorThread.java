package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class FileProcessorThread extends Thread {
    private URL url;
    private Inkrement brojac;
    public FileProcessorThread(URL url,Inkrement brojac) {
        this.url=url;
        this.brojac=brojac;
    }

    @Override
    public void run() {
        // otvara bafersiani tok i cita sadrzaj fajla encoding je aci
        try {
            URLConnection connection = url.openConnection();
            String encode = "ASCII";
            BufferedReader ulaz = new BufferedReader(new InputStreamReader(connection.getInputStream(),encode));
            //brojimo linije u datom fajlu, i pazimo na sinhronizaciju
            String line = ulaz.readLine();
            while (line!=null){
                //uvecavamo broj linija u .c fajlovima
                brojac.uvecaj();

            }
            //zatvaramo ulaz
            ulaz.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

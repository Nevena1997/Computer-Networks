package zad1;

public class Inkrement {
    private int sum;

    public Inkrement(int sum) {
        this.sum = sum;
    }

    public int getSum() {
        return sum;
    }
    public synchronized  void uvecaj(){
        //koristimo synchronized
        this.sum++;
    }
}

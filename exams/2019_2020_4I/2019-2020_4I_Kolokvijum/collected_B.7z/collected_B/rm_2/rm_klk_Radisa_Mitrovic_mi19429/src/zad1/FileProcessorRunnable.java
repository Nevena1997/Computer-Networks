package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import static java.nio.file.Files.*;

public class FileProcessorRunnable implements Runnable {
    Path putanja;
    Inkrement brojac;//pomocna klasa za sinhronizaciju
    public FileProcessorRunnable(String putanja) {
        this.putanja= Paths.get(putanja);
        this.brojac=new Inkrement(0);
    }


    @Override
    public void run() {
        // nit obilazi direktorim i broji regularne fajlove
        System.out.println("Files:" + regular(putanja));//
        //stampamo ukupan broj linija, koristimo pomocni meotod
        walker(putanja);
        //stampamo broj linija u c fajlovima
        System.out.println("result: "+brojac.getSum());

    }
    private int regular(Path putanja) {
        DirectoryStream<Path> putanje = null;
        try {
            putanje = newDirectoryStream(putanja);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Path p : putanje) {
            if (isDirectory(p))
                regular(p);//obidji rekurzivno
            else {
                //inace brojimo regularne
                if (isRegularFile(p))
                    Zad1Main.brojRegularnih++;
            }
        }
        //vracamo broj regularnih fajlova
        return Zad1Main.brojRegularnih;
    }

    private void walker(Path putanja) {
        //metod koji kreira niti za .c fajlove, kojima prosledjuje URL objekat
        try {
            DirectoryStream<Path> putanje = newDirectoryStream(putanja);
            for (Path p:putanje){
                if (isDirectory(p))
                    walker(p);//nastavi rekurzivno
                else {
                    //za svaki .c kreiramo novi url objekat i dodeljumo ga posebnoj niti
                    if (p.endsWith(".c")){
                        URL url = new URL("FILE://"+p.toAbsolutePath());
                        System.out.println("Odgovarajuci URl:"+url.toExternalForm());
                        System.out.println("Putanja:"+p);
                        //kreiramo nit za  ovaj url,brojac mi je pomocni obj za sinhronizaciju
                        new Thread(new FileProcessorThread(url,brojac)).start();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandler implements Runnable {
    private Socket  socks;
    public ClientHandler(Socket client) {
        this.socks=client;
    }
    //nit koja obradjuje klijenta


    @Override
    public void run() {
    //server prvo stampa dobijenu putanju, sve moze u try()
        try(BufferedReader fromClient= new BufferedReader(new InputStreamReader(socks.getInputStream()));
            BufferedWriter toClient = new BufferedWriter(new OutputStreamWriter(socks.getOutputStream()))){
            //prvo citamo i proveravamo putanju od clienta
            String putanja = fromClient.readLine();
            //stampamo putanju
            System.out.println(putanja);
            Path path = Paths.get(putanja);
            //provera validnosti putanje
            if(nevallidna(path)) {
                //saljemo znak da je putanja nevalidna  i prekidamo program
                toClient.write(0);
                toClient.flush();
                System.exit(1);
            }
            //saljemo signal da je validna
            toClient.write(1);
            toClient.flush();
            //otvaramo fajl i sabiramo realne brojeve, korisitmo scanner
            Scanner file = new Scanner(path);
            Double suma=0.0;
            while (file.hasNextDouble())
                suma+=file.nextDouble();
            //konverturjmo u string pa saljemo odg  klinetu, da li ce toString konv bas u "17.456", zato sam uzeo valueOf ?
            toClient.write(String.valueOf(suma));
            toClient.flush();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                //zatvaramo soket
                this.socks.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean nevallidna(Path putanja) {
        //kako proveriti da je putanja validna
        if (Files.exists(putanja))
            return false;
        else
            return true;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");
        Client client = new Client(Server.PORT);
        client.execute();
    }

    public int port;
//    Socket socket;

    public Client(int port) {
        this.port = port;
    }

    private void execute() {

        try {
            Socket socket = new Socket("localhost", this.port);
            BufferedWriter fromHere = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader toHere = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            System.out.println("Unesi relativnu putanju fajla( u odnosu na tests): ");
            Scanner sc= new Scanner(System.in);
            String poruka = sc.nextLine();
            fromHere.write(poruka);
            fromHere.flush();


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

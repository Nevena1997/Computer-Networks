package zad2;


import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class UserThread extends Thread{

    private BufferedReader fromUser;
    private BufferedWriter toUser;
    Socket user;

    public UserThread(Socket user) throws IOException {
        this.user = user;
        this.fromUser = new BufferedReader(new InputStreamReader(user.getInputStream()));
        this.toUser = new BufferedWriter(new OutputStreamWriter(user.getOutputStream()));
    }

    @Override
    public void run() {


        try {
            String poruka = fromUser.readLine();
            System.out.println(poruka);


            String putanja = "/home/ispit/Desktop/tests/" + poruka;
            File f = new File(putanja);
            if (f.exists()) {
                toUser.write("Dobra putanja");
                toUser.flush();
            } else {
                toUser.write("Losa putanja");
                toUser.flush();
            }

            try {
                Scanner sc = new Scanner(new FileInputStream(putanja));
                double suma = 0.0;
                int ind = 0;
                while (sc.hasNext()) {
                    if (sc.hasNextDouble()) {
                        suma += sc.nextDouble();
                        ind += 1;
                    } else
                        sc.next();
                }

                String result;

                if (ind == 0)
                    result = "Fajl ne sadrzi realne brojeve";
                else
                    result = ("Suma je: " + suma);

                System.out.println(result);

            }catch (FileNotFoundException e){
                System.err.println("Nepostojeci fajl");
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
//

//
//            } catch (Exception e) {
//                System.out.println("Fajl ne sadrzi realne brojeve");
//            }
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
}
package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

public class Server {

    public static final int PORT = 31415;

    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");
        Server server = new Server(PORT);
        server.execute();
    }

    private int port;
    Set<UserThread> users;

    public Server(int port) {
        this.port = port;
        this.users = new HashSet<>();
    }

    private void execute() {
        try(ServerSocket server = new ServerSocket(port)){

            while(true){
                Socket socket = server.accept();
                UserThread user = new UserThread(socket);

                users.add(user);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

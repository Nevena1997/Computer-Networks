package zad1;

import java.nio.file.*;
import java.util.List;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        System.out.println("Srecno!");
    }
}

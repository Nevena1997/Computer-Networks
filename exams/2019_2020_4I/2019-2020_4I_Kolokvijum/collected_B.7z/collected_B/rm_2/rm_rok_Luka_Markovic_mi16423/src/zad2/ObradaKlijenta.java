package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ObradaKlijenta implements Runnable {

    private Socket klijent;

    public ObradaKlijenta(Socket klijent) {
        this.klijent=klijent;
    }

    @Override
    public void run() {
        System.err.println("obradjujem klijenta");
        try(BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            //PrintWriter pout = new PrintWriter(new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream())), false);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));) {
            String ime_fajla = in.readLine();
            System.out.println(ime_fajla);
            double suma=0;

            try (Scanner sc = new Scanner(new FileInputStream(ime_fajla))) {
                while(sc.hasNext()){
                    String linija = sc.next();
                    float d = isDouble(linija);

                    suma=d+suma;

                }
            }catch (IOException e) {
                out.write("putanja nije validna");
                out.newLine();
                out.flush();
                e.printStackTrace();
            }


            out.write("putanja je validna");
            out.newLine();
            out.flush();



            //pout.print(suma);
            //pout.println();
            //pout.flush();









        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                this.klijent.close();
                System.err.println("ovaj klijent je zavrsen");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private float isDouble(String linija) {
        return 0;
    }
}

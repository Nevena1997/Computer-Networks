package zad1;

import java.nio.file.Path;

public class FileProcessorRunnable implements Runnable {
    @Override
    public void run() {

    }
}

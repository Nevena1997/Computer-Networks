package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        System.err.println("pravimo server");
        try(ServerSocket server = new ServerSocket(31415);){
            System.err.println("pokrenut server");
            while(true) {
                System.err.println("cekam klijente...");
                Socket klijent= server.accept();

                System.err.println("prihvacen klijent, pravim nit");
                new Thread(new ObradaKlijenta(klijent)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

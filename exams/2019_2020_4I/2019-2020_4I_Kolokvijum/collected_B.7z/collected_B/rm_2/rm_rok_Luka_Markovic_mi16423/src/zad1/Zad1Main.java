package zad1;

public class Zad1Main {
    public static void main(String[] args) {

        new Thread(new FileProcessorRunnable()).start();
    }
}

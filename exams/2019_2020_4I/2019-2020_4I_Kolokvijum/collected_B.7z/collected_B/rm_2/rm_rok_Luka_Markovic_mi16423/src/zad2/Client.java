package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try{
            Socket klijent = new Socket("localhost", 31415);
            System.err.println("povezan na server");
            Scanner sc = new Scanner(System.in);
            BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            String ime_fajla= sc.nextLine();


            //./../tests/dir2/2.test
            out.write(ime_fajla);
            out.newLine();
            out.flush();

            System.out.println(in.readLine());
            //System.out.println(in.readLine());


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {


        try (ServerSocket server = new ServerSocket(31415)) {
            System.err.println("Server is up.");

            while (true) {

                Socket client = server.accept();
                System.err.println("New client accepted.");

                new Thread(new CheckPathRunnable(client)).start();

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

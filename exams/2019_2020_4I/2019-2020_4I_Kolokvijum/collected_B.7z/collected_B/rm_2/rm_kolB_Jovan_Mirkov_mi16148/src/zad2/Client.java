package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {

        String host = "localhost";

        try(Socket client = new Socket(host,31415);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner sc = new Scanner(System.in);
            ) {
                while (true) {
                    String path = sc.nextLine();

                    out.write(path);
                    String ind = in.readLine();
                    System.out.println(ind);
                    String sum = in.readLine();
                    System.out.println(sum);

                }



        }
        catch (UnknownHostException ex){
            System.err.println("Host error.");
        }
        catch (IOException ex){
            System.err.println("I/O error.");
        }
        catch (Exception e){
            e.printStackTrace();
        }








    }
}

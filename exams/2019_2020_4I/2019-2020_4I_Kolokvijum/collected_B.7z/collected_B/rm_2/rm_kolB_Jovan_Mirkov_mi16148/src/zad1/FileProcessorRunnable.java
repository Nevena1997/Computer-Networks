package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorRunnable implements Runnable {

    private URL url;
    public AtomicInteger atom;

    FileProcessorRunnable(URL url) {
        this.url = url;
    }

    @Override
    public void run() {

        try {
            URLConnection uc = url.openConnection();

            try (BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.US_ASCII));) {

                String line;

                atom = new AtomicInteger();

                while ((line = in.readLine()) != null) {

                    atom.set(atom.addAndGet(1));

                }

                System.out.println("result: "+ atom);

            } catch (IOException e) {
                e.printStackTrace();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

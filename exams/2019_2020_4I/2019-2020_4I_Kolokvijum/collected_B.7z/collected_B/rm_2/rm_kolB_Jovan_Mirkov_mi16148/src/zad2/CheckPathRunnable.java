package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class CheckPathRunnable implements Runnable {

    private Socket client;

    CheckPathRunnable(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));


            String path = in.readLine();
            System.out.println(path);

            //ideja je bila da nam exception u funkciji kaze da li je ispravna putanja ali izgleda da ne znam to da uradim.
            //Boolean ind = testPath(path);

            //vestacki kazemo da jeste zbog testiranja da bi proradilo
            Boolean ind = true;


            if (ind) {
                out.write("jeste");

                Scanner sc = new Scanner("../tests/"+ path);

                long sum = 0;

                while (sc.hasNext()) {

                    if (sc.hasNextLong()) {
                        sum += sc.nextLong();
                    } else {
                        continue;
                    }
                }

                if (sum == 0) {
                    out.write("Fajl ne sadrzi realne brojeve");
                } else {
                    out.write(Long.toString(sum));
                }
                sc.close();
            } else {
                out.write("nije");
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
/*
    private Boolean testPath(String path){
        try(Scanner sc = new Scanner(path)){
            return true;
        }
        catch (IOException e){
            return false;
        }

*/

}





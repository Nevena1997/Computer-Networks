package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;




public class Zad1Main {
    public static void main(String[] args) throws IOException {



        String dir = "../tests/dir/dir1/dir11";
        int count = 0;




        //nazalost nije rekurzivno, dir preusmeren na ...../dir11 zbog testiranja
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(dir))) {
            for (Path entry : stream) {

               /*
                if(Files.isDirectory(entry)){
                    goDeeper(entry,result);  //
                }
                */

                result.add(entry);
                count++;
            }
        } catch (DirectoryIteratorException ex) {
            ex.printStackTrace();
        }

        System.out.println("files:\t" + count);
        Boolean ispis = false;

        List<URL> urls = new ArrayList<>();
        for (Path p : result) {
            p = p.toAbsolutePath();
            String temp = p.toString();

            if(ispis) {
                System.out.println("files:\t");
                ispis = false;
            }
            if (temp.contains(".c")) {
                URL u = new URL("FILE:///" + temp);

                urls.add(u);
                System.out.println(u);
                System.out.println();

            }

        }


        for(URL url: urls){
            new Thread(new FileProcessorRunnable(url)).start();
        }

    }

    /*
    private static void goDeeper(Path temp,  List<Path> res) {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(temp))) {
            for (Path entry : stream) {
                if(Files.isDirectory(entry)){
                    goDeeper(entry, res);
                }

                res.add(entry);
                count++; //ovo bi bio neki globalni onda... kad bi radio metod...
            }
        } catch (DirectoryIteratorException ex) {
            ex.printStackTrace();
        }

     */



    }


package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerThread implements Runnable{
    private Socket clientConnection;
    private String basePath = "/home/ispit/Desktop/tests/";

    public void setClientConnection(Socket clientConnection) {
        this.clientConnection = clientConnection;
    }

    @Override
    public void run() {
        try {
            InputStream fromClient = new BufferedInputStream(clientConnection.getInputStream());
            OutputStream toClient = new BufferedOutputStream(clientConnection.getOutputStream());

            Writer wr = new BufferedWriter(new OutputStreamWriter(toClient));

            Scanner fcsc = new Scanner(fromClient);
            String receivedPath = fcsc.nextLine();
            String fullPath = this.basePath + receivedPath;
            System.out.println(receivedPath);

            try (InputStream file = new BufferedInputStream(new FileInputStream(fullPath))) {

                Scanner rnsc = new Scanner(file);
                double sum = 0;
                wr.write("Validna putanja\n");
                if(!rnsc.hasNextDouble()){
                    wr.write("Fajl ne sadrzi realne brojeve\n");
                    wr.close();
                    fromClient.close();
                    clientConnection.close();
                    return;
                }

                while(rnsc.hasNextDouble()){
                    sum+=rnsc.nextDouble();
                }
                wr.write((""+sum+'\n'));
                wr.close();
                fromClient.close();
                clientConnection.close();
            } catch (FileNotFoundException e) {
                wr.write("Nevalidna putanja\n");
                wr.close();
                fromClient.close();
                clientConnection.close();
            }
        }
        catch (IOException e){

        }
    }
}

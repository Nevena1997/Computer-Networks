package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 31415;

        try(Socket soc = new Socket(hostname, port)) {
            Scanner sisc = new Scanner(System.in);
            String pathToFile = sisc.nextLine();
            InputStream fromServer = new BufferedInputStream(soc.getInputStream());
            OutputStream toServer = new BufferedOutputStream(soc.getOutputStream());
            Writer wr = new OutputStreamWriter(toServer);
            wr.write(pathToFile+'\n');
            wr.flush();

            Scanner serverScanner = new Scanner(fromServer);
            while(serverScanner.hasNextLine())
                System.out.println(serverScanner.nextLine());
        }
        catch (Exception e){}



    }
}

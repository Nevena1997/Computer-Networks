package zad1;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Zad1Main {
    public static void main(String[] args) {

        String rootPath = "/home/ispit/Desktop/tests";
        Path dir = FileSystems.getDefault().getPath(rootPath);

        List<Path> result = new ArrayList<>();
        Stack<DirectoryStream<Path>>  dirs = new Stack<>();
        DirectoryStream<Path> root;
        try{
            root = Files.newDirectoryStream(dir);
            dirs.push(root);
        }
        catch(Exception e){}
        while(!dirs.isEmpty()){
            DirectoryStream<Path> current = dirs.pop();
            try {
                for (Path entry : current) {
                    File a = new File(entry.toString());
                    if(a.isDirectory()){
                        root = Files.newDirectoryStream(entry);
                        dirs.push(root);
                    }
                    if(a.isFile())
                        result.add(entry);
                }
            } catch (DirectoryIteratorException | IOException ex) {}
        }

        System.out.println(result.size());
        List<URL> cs = new LinkedList<>();
        for(Path entry: result){
            if(entry.toString().endsWith(".c")){
                //cs.add(new URL("file", entry));
                //System.out.println(".c");
            }
        }
    }

}

package zad2;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {
        int port = 31415;
        while(true) {
            try (ServerSocket ss = new ServerSocket(port)) {
                Socket s = ss.accept();
                ServerThread thread = new ServerThread();
                thread.setClientConnection(s);
                new Thread(thread).start();

            } catch (IOException e) {
            }
        }

    }
}

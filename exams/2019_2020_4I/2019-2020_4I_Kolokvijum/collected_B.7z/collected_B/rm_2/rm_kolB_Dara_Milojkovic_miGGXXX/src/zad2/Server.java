package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {

        System.out.println("Srecno od strane servera!");
        try{
            ServerSocket server=new ServerSocket(31415);
            while(true){
                Socket klijent=server.accept();
                new Thread(new Obradjivac(klijent)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class Obradjivac implements Runnable {
        private Socket klijent;
        public Obradjivac(Socket klijent) {
            this.klijent=klijent;
        }
        public  void run(){
            try{
                BufferedReader br=new BufferedReader(new InputStreamReader(this.klijent.getInputStream(), StandardCharsets.UTF_8));
                PrintWriter  pw=new PrintWriter(this.klijent.getOutputStream(),true);


                    String linija=br.readLine();
                    File fajl=new File("/home/ispit/Desktop/tests/"+linija);
                    if(!fajl.exists()){
                        pw.println("ne postoji fajl");
                    }else {
                        System.out.println(linija);
                        pw.println("Validna putanja");
                        Scanner sc=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(linija),StandardCharsets.UTF_8)));
                        String ucitano;
                        double zbir=0;

                        while(sc.hasNext()){
                            ucitano=sc.next();
                            if(ucitano.matches("[-]?[0-9]+(\\.[0-9]+)?")){
                                zbir+=Double.parseDouble(ucitano);
                            }
                        }
                        if(zbir!=0) {
                            pw.println(zbir);
                        }else{
                            pw.println("Fajl ne sadrzi realne brojeve");
                        }
                    }

            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                try{
                    this.klijent.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

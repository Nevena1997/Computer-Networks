package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    public static void main(String[] args)
    {

        System.out.println("Srecno od strane klijenta!");
        try{
            Socket sock=new Socket("localhost",31415);

            new Thread(new KlijentKojiCita(sock)).start();
            new Thread(new KlijentKojiPise(sock)).start();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class KlijentKojiCita implements Runnable {
        private Socket klijent;
        public KlijentKojiCita(Socket sock) {
                this.klijent=sock;

        }

        @Override
        public void run() {
            try {
                BufferedReader br=new BufferedReader(new InputStreamReader(this.klijent.getInputStream(), StandardCharsets.UTF_8));
                String ucitano=br.readLine();
                System.out.println(ucitano);
                if(!ucitano.equals("Fajl ne sadrzi realne brojeve") || !ucitano.equals("ne postoji fajl")){
                    System.out.println(br.readLine());
                }else{
                    System.out.println(ucitano);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private static class KlijentKojiPise implements Runnable {
        private Socket klijent;
        public KlijentKojiPise(Socket sock) {
            this.klijent=sock;


        }

        @Override
        public void run() {
            try{
                Scanner sc=new Scanner(System.in);
                PrintWriter  pw=new PrintWriter(this.klijent.getOutputStream(),true);

            String linija=sc.nextLine();
            pw.println(linija);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

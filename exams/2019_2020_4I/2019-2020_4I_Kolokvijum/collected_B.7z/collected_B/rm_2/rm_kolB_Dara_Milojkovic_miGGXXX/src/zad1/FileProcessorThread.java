package zad1;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorThread extends Thread {
    private DirectoryStream<Path> dirs;
    private List<Path> lista=new ArrayList<>();

    private BlockingQueue<URL> lista_c=new ArrayBlockingQueue<>(10);
    private AtomicInteger broj_linija;

    FileProcessorThread(String direktorijum){
        try {
            dirs = Files.newDirectoryStream(Paths.get(direktorijum));
            this.broj_linija=new AtomicInteger(0);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
           this.pretrazi(dirs);
            System.out.println("files: "+lista.size());

            lista_c.stream().forEach(l-> System.out.println("url: "+l.toString()));
            lista_c.stream().forEach(l->new Thread(new FileProcessorRunnable(l,broj_linija)).start());

            System.out.println(broj_linija);


    }

    private void pretrazi(DirectoryStream<Path> direktorijum) {

        try {
            for (var d : direktorijum) {
                if (Files.isDirectory(d)) {
                    this.pretrazi(Files.newDirectoryStream(d));
                } else {
                    lista.add(d);
                    if(d.toString().endsWith(".c")) {
                        StringBuilder putanja = new StringBuilder("file:///");
                        putanja.append(d.toString());
                        lista_c.add(new URL(putanja.toString()));
                    }
                }
            }
        }catch (IOException E){

        }

    }

}

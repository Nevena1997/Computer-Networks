package zad2;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class MyThread extends Thread {
    private Socket s;

    public MyThread(Socket s){
        this.s=s;
    }

    @Override
    public void run() {


        try(BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8))) {

            File p=new File("../tests");
//            System.out.println(p.getAbsolutePath());
//            System.out.println(p.isDirectory());
//            while(true) {

            String putanja=in.readLine();
            System.out.println(putanja);

            putanja=p.getAbsolutePath()+File.separator+putanja;
            File p1=new File(putanja);

//            System.out.println(p1.getAbsolutePath());
//            Pattern r=".*?(([0-9]*\.[0-9]*)|([1-9]+\.*[0-9]*";
            Pattern pattern=Pattern.compile("(([0-9]*[.][0-9]*)|([1-9]+[.]*[0-9]*))");
//

            double zbir=0;

            if(p1.exists()){
                if(p1.isFile()){
                    out.write("validna putanja");
                    out.newLine();
                    out.flush();
//                    BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(p1)));
//                    System.out.println(br.lines());

//                    System.out.println(br.read());
                    try(Scanner file=new Scanner(new InputStreamReader(new FileInputStream(p1)))) {
//                        System.out.println(file.next());

//                      while(file.hasNext()) {

//                          String line=file.next();
//                          System.out.println(line);




//                          LinkedList<> matches=file.findAll(pattern)
//                          System.out.println(file.findAll("(([0-9]*.[0-9]*)|([1-9]+.*[0-9]*))"));
//                          System.out.println(file.next(pattern));
//                          System.out.println(file.findInLine(pattern));
//                          System.out.println("\n");
//                          if (file.hasNextDouble()) {
//                              System.out.println(file.nextDouble());
//                          }else{
//                              file.next();
//                          }
//                      }
//                        double broj;
//                        zbir=zbir+broj;
//                        out.write(zbir);
//                        out.newLine();
//                        out.flush();
                    }
                }else{
                    out.write("nevalidna putanja nije fajl");
                    out.newLine();
                    out.flush();
                }
            }else{
                out.write("nevalidna putanja");
                out.newLine();
                out.flush();
            }

//            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                this.s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

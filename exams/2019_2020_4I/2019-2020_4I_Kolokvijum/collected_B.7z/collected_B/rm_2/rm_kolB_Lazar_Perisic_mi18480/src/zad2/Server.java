package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {


    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");


        try(ServerSocket sc=new ServerSocket(31415)) {
            while(true) {
                Socket client = sc.accept();

                new MyThread(client).run();
            }

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class Client {
    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");


        try(Socket s=new Socket("localhost",31415);
            BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
            BufferedReader inc=new BufferedReader(new InputStreamReader(System.in))) {
//            while(true) {


            String putanja=inc.readLine().trim();
//            File p=new File("../tests");
//            System.out.println(p.exists());
//            putanja=p.getAbsolutePath()+File.separator+putanja;
//            System.out.println(putanja);
//            File p1=new File(putanja);
//            System.out.println(p.getAbsolutePath());
//            System.out.println(p1.getAbsolutePath());
//            System.out.println(p1.exists());

            out.write(putanja);
            out.newLine();
            out.flush();

            System.out.println(in.readLine());
//            System.out.println("zbir je "+in.readLine());

//            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

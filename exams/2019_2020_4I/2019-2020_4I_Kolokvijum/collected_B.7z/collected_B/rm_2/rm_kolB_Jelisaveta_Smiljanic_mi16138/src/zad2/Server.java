package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.*;
import java.util.function.Consumer;

public abstract class Server implements DirectoryStream{

    public static final int port = 31415;

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(port)){

            while(true){
                Socket client = server.accept();

                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

                String absPath;
                absPath = in.readLine();

                System.out.println("Primljena putanja: " + absPath);
                //DirectoryStream stream = Files.newDirectoryStream(Paths.get("Desktop/tests"));

                String path = "src/zad2/tests";

                Path dir = Paths.get(path);
                Boolean isValid = false;
                try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
                    for (Path entry: stream) {

                        if(entry.toString().equals(absPath))
                            isValid = true;
                    }
                } catch(NotDirectoryException e){
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                }

                if(isValid) {
                    System.out.println("Putanja je validna");
                }
                else System.out.println("Putanja je nevalidna");

                //out.newLine();
                //out.flush();

                Thread user = new UserRunnable(client, absPath);
                user.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.SynchronousQueue;

public class FileProcessorThread extends Thread {
    private Queue paths = new SynchronousQueue();

    public FileProcessorThread(String path) {
        this.paths.add(path);
    }


    @Override
    public void run() {
        int br = 0;
        while(!paths.isEmpty()) {
            Path dir = Paths.get((String) paths.poll());


            try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
                for (Path entry : stream) {
                    if (Files.isDirectory(entry)) {
                        paths.add(entry.toString());
                    } else {
                        try (FileInputStream in = new FileInputStream(String.valueOf(entry));
                        ) {
                            br++;
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Files: "+ br);

    }
}


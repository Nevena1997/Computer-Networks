package zad2;

import java.net.Socket;

public class UserRunnable extends Thread{

    private Socket sock;
    private String path;

    public UserRunnable(Socket sock, String path)
    {
        this.sock = sock;
        this.path = path;
    }

    @Override
    public void run() {

    }
}

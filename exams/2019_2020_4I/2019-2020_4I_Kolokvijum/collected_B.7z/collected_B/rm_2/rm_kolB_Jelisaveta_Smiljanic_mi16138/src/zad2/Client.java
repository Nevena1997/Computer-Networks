package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try(Socket sock = new Socket("localhost",Server.port))
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("Unesite relativnu putanju: ");
            String path = sc.nextLine();

            PrintWriter out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            out.write(path);
            out.flush();

            //try{

            //String serverReply;
                //if((serverReply = in.readLine()) != null);
                //out.write(serverReply);

            //}catch (IOException e)
            //{
              //  e.printStackTrace();
            //}


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.*;
import java.nio.file.*;

public class Zad1Main {
    public static void main(String[] args) throws IOException {

        // Implementirati logiku u jednoj od FileProcessor klasa

        //Nisam umela drugacije da dodjem do direktorijuma test
        //Pa sam ga prebacila u zad1 da bih proverila da li radi :)
        String path = "src/zad1/tests";
        Thread user = new FileProcessorThread(path);
        user.start();
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        try (Socket sock = new Socket("localhost", 31415);
             BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
             BufferedReader networkIn = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()))
        ){
            String path = userIn.readLine();

            networkOut.write(path);
            networkOut.newLine();
            networkOut.flush();

            int ind = networkIn.read();
            if(ind == 1) System.out.println("Nije validna putanja");
            else System.out.println("Validna putanja");

            float suma = networkIn.read();
            if(suma > 0.0)
                System.out.println(networkIn.readLine());
            else
                System.out.println("Fajl ne sadrzi realne brojeve");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

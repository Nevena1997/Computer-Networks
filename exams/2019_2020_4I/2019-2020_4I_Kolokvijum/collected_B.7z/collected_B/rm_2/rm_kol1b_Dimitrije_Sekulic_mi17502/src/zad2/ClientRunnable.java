package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientRunnable implements Runnable {
    private Socket client;

    public ClientRunnable(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
        BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            String path = networkIn.readLine();
            int ind = 0;
            System.out.println(path);
            float suma = 0;
            try (Scanner fin = new Scanner(new FileInputStream(path))) {
                while (fin.hasNext()) {
                    if(fin.hasNextFloat()) {
                        float n = fin.nextFloat();
                        suma += n;
                    }
                    else
                        fin.next();
                }
            } catch (FileNotFoundException ex) {
                ind = 1;
            }
            networkOut.write(ind);
            networkOut.newLine();
            networkOut.append("" + suma);
            networkOut.newLine();
            networkOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class BLQUeue implements Runnable {
    private BlockingQueue<Path> queue;
    private Path path;

    public BLQUeue(BlockingQueue<Path> queue, Path path) {
        this.path = path;
        this.queue = queue;
    }

    @Override
    public void run() {
        walk(path);
    }

    private void walk(Path p) {
        try {
            if(p == Paths.get(""))
                return;
            if (p.toFile().isFile()) {
                if (p.endsWith(".c"))
                    queue.put(p);
            }
            if(p.toFile().isDirectory()) {
                String[] paths = p.toFile().list();
                for(String pi : paths) {
                    walk(Paths.get(pi));
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

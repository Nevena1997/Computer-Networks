package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(31415)) {
            while (true) {
                Socket client = server.accept();

                new Thread(new ClientRunnable(client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

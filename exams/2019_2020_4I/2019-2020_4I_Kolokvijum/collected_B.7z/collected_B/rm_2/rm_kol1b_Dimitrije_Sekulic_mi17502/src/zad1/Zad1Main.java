package zad1;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static void main(String[] args) {
        Path path = Paths.get("/home/ispit/Desktop/tests");

        BlockingQueue<Path> queue = new ArrayBlockingQueue<>(250);
        new Thread(new BLQUeue(queue, path)).start();
        System.out.println(queue.size());
//        try {
//            String name = "file://" + queue.take().toString();
//            URL u = new URL(name);
//        } catch (MalformedURLException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }
}

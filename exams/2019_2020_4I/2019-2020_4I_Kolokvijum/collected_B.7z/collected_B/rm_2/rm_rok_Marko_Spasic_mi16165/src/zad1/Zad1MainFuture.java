package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

/*
    Implementacija preko FutureTask
    Jedna dodatna klasa FileProcessorCallable
    Task se startuje cim se naidje na fajl
    Future se pokupi u main-u
 */

public class Zad1MainFuture {

    private static int regularFileCount = 0;
    private static List<Future<Long>> results = new LinkedList<>();
    private static List<URL> cFiles = new ArrayList<>();

    public static void main(String[] args) {
        walk(Paths.get("../tests"));

        System.out.printf("files:\t%d\n", regularFileCount);

        for(URL p : cFiles) {
            System.out.printf("url:\t%s\n", p.toString());
        }

        long totalCount = 0;
        for(Future<Long> lineCount : results) {
            try {
                totalCount += lineCount.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }

        System.out.println(totalCount);
    }
    static void walk(Path root) {
        try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(root)){
            for(Path path : dirStream) {
                if(Files.isRegularFile(path)) {
                    regularFileCount += 1;
                }
                if(path.toRealPath().toString().endsWith(".c")) {
                    URL url = new URL("file", "localhost", path.toRealPath().toString());
                    FutureTask<Long> task = new FutureTask<>(new FileProcessorCallable(url));
                    results.add(task);

                    // pusti thread. Pokupi rezultat u main-u.
                    new Thread(task).start();
                    cFiles.add(url);
                } else if(Files.isDirectory(path)) {
                    walk(path);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

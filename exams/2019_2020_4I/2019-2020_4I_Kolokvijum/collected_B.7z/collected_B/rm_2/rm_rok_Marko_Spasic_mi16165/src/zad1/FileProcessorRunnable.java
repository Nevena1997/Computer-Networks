package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class FileProcessorRunnable implements Runnable {
    private URL url;
    private AtomicLong counter;
    public FileProcessorRunnable(URL url, AtomicLong counter) {
        this.url = url;
        this.counter = counter;
    }

    @Override
    public void run() {
        try(BufferedReader reader = new BufferedReader(
                new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII)
        )) {
            long count = reader.lines().count();
            //System.out.println(count);
            this.counter.addAndGet(count);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

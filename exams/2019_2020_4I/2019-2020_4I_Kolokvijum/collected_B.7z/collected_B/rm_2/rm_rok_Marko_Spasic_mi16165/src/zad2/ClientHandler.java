package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandler implements Runnable {
    private Socket socket;
    private String rootPath = "../tests";
    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try(BufferedReader fromClient = new BufferedReader(
                new InputStreamReader(this.socket.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter toClient = new BufferedWriter(
                    new OutputStreamWriter(this.socket.getOutputStream(), StandardCharsets.UTF_8)
            )) {
            String relativePath = fromClient.readLine();
            System.out.println(relativePath);
            Path path = Paths.get(rootPath, relativePath);
            if(Files.exists(path) && Files.isRegularFile(path)) {
                toClient.write("Validna putanja");
                toClient.newLine();
                toClient.flush();
                try(FileInputStream stream = new FileInputStream(path.toString())) {
                    toClient.write(processFile(stream));
                    toClient.newLine();
                    toClient.flush();
                }
            } else {
                toClient.write("Nevalidna putanja");
                toClient.newLine();
                toClient.flush();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    static String processFile(FileInputStream stream) {
        try(Scanner fileScan = new Scanner(stream)) {
            boolean foundADouble = false;
            double sum = 0.0;
            while(fileScan.hasNext()) {
                String word = fileScan.next();
                try {
                    double value = Double.parseDouble(word);
                    foundADouble = true;
                    sum += value;
                } catch(NumberFormatException e) {
                    // ignore if it's not a double
                }
            }
            if(foundADouble) {
                return String.valueOf(sum);
            } else {
                return new String("Fajl ne sadrzi realne brojeve");
            }
        }
    }
}

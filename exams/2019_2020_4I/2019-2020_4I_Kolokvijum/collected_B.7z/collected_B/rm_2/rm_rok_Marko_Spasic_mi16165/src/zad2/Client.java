package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try(Socket socket = new Socket("localhost",Server.PORT);
            BufferedWriter toServer = new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8)
            );
            BufferedReader fromServer = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)
            );
            Scanner stdIn = new Scanner(System.in)) {

                String pathOnTheServer = stdIn.next();
                toServer.write(pathOnTheServer);
                toServer.newLine();
                toServer.flush();
                String validPathResponse = fromServer.readLine();
                System.out.println(validPathResponse);
                if(validPathResponse.startsWith("Validna")) {
                    String result = fromServer.readLine();
                    System.out.println(result);
                }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

Zad1Main:
--preko Thread i join. Tredovi se startuju tek kada se obidje ceo dir

Zad1MainFuture
--preko FutureTask. Cim se naidje na fajl startuje se thread i cuva se Future koji se posle pokupi u main-u
  kada je potrebno ispisati rezultat.

Testirao sam i oba daju tacan rezultat.
Ostavicu oba kao sto ste mi rekli.
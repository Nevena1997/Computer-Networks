package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class Zad1Main {
    private static int regularFileCount = 0;
    private static AtomicLong counter = new AtomicLong(0);
    private static List<URL> cFiles = new ArrayList<>();

    public static void main(String[] args) {
        walk(Paths.get("../tests"));
        Thread threads[] = new Thread[cFiles.size()];

        for(int i = 0; i < threads.length; ++i) {
            threads[i] = new Thread(new FileProcessorRunnable(cFiles.get(i), counter));
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.printf("files:\t%d\n", regularFileCount);
        for(URL p : cFiles) {
            System.out.printf("url:\t%s\n", p.toString());
        }
        System.out.println(counter.get());
    }

    static void walk(Path root) {
        try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(root)){
            for(Path path : dirStream) {
                if(Files.isRegularFile(path)) {
                    regularFileCount += 1;
                }
                if(path.toRealPath().toString().endsWith(".c")) {
                    URL url = new URL("file", "localhost", path.toRealPath().toString());
                    cFiles.add(url);
                } else if(Files.isDirectory(path)) {
                    walk(path);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

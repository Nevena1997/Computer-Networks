package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicLong;

public class FileProcessorCallable implements Callable<Long> {
    private URL url;

    public FileProcessorCallable(URL url) {
        this.url = url;
    }

    @Override
    public Long call() throws Exception {
        try(BufferedReader reader = new BufferedReader(
                new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII)
        )) {
            long count = reader.lines().count();
            //System.out.println(count);
            return count;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0L;
    }
}

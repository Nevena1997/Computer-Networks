package zad1;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;
import java.util.function.Consumer;
import java.util.logging.StreamHandler;
import java.util.stream.Stream;

public class Zad1Main {

    static int countFiles = 0;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        try {
            String s = "/home/ispit/Desktop/test";
            Path p = Paths.get("/home/ispit/Desktop/test");

            /*
            *  Ako imate dusu, zamenite tastaturu na BIM 05 racunaru
            * */

            walk(p);
            System.out.println("Files: " + countFiles);




        } catch(Exception e) {
            e.printStackTrace();
        }


    }

    private static void walk(Path p) {
        try {

            if (Files.isRegularFile(p))
                countFiles++;
            else if (Files.isDirectory(p)) {
                Stream<Path> str = Files.walk(p);
                Path[] niz = (Path[]) str.toArray();

                for(Path a: niz) {
                    walk(a);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

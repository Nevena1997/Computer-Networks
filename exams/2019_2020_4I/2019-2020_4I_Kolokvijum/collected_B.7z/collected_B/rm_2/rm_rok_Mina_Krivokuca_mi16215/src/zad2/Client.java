package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class Client {
    public static void main(String[] args) {

        try (Socket cli = new Socket("localhost", Server.DEFAULT_PORT);
             BufferedReader netIn = new BufferedReader(
                                    new InputStreamReader(
                                            cli.getInputStream(), StandardCharsets.UTF_8));
             BufferedWriter netOut = new BufferedWriter(new OutputStreamWriter(
                cli.getOutputStream(), StandardCharsets.UTF_8));
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in)))
        {

            String line = userInput.readLine();

            netOut.write(line);
            netOut.newLine();
            netOut.flush();

            String received;

            while(true) {

                received = netIn.readLine();
                if(received != null)
                    System.out.println(received);

            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}

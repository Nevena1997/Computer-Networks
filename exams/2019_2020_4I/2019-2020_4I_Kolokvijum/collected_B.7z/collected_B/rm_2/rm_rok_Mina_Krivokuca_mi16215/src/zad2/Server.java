package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Server {

    static final int DEFAULT_PORT = 31415;

    public static void main(String[] args) {

        try (ServerSocket srv = new ServerSocket(DEFAULT_PORT)) {

            Socket cli = srv.accept();

            BufferedReader netIn = new BufferedReader(new InputStreamReader(
                            cli.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter netOut = new BufferedWriter(new OutputStreamWriter(
                    cli.getOutputStream(), StandardCharsets.UTF_8));

            String line;

            while((line = netIn.readLine()) != null) {

                line = "/home/ispit/Desktop/tests/" + line;
                System.out.println(line);

                try (BufferedReader file = new BufferedReader(new InputStreamReader(new FileInputStream(line), StandardCharsets.UTF_8))) {
                    netOut.write("Putanja jeste validna.");
                    netOut.newLine();
                    netOut.flush();

                    Scanner sc = new Scanner(file);

                    Double d = 0.0;
                    Double tmp;
                    int itmp;
                    String t;


                    while(sc.hasNext()) {
                        t = sc.next();

                        if(t.matches("[0-9]+")) {
                            itmp = Integer.parseInt(t);
                            d += itmp;
                        }
                        else if(t.matches("[0-9]+\\.[0-9]+")) {
                            tmp = Double.parseDouble(t);
                            d += tmp;
                        }

                    }


                    if(d == 0.0) {
                        netOut.write("Fajl ne sadrzi realne brojeve.");
                        netOut.newLine();
                        netOut.flush();
                    }
                    else {
                        netOut.write(d.toString());
                        netOut.newLine();
                        netOut.flush();
                    }


                    sc.close();
                } catch (IOException e) {
                    netOut.write("Putanja nije validna.");
                    netOut.newLine();
                    netOut.flush();
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

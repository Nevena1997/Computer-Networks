package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class UserThread implements Runnable{

    private Socket soket;
    private Server server;
    public UserThread(Socket soket, Server server) {
        this.server = server;
        this.soket = soket;
    }

    @Override
    public void run() {

        try {
            BufferedReader fromUser = new BufferedReader(new InputStreamReader(this.soket.getInputStream()));
            PrintWriter toUser = new PrintWriter(this.soket.getOutputStream(), true);
            String stringPutanja = fromUser.readLine();
            System.out.println(stringPutanja);

            Path putanja = Paths.get("/home/ispit/Desktop/tests/" + stringPutanja);
            int indikator;
            if (Files.exists(putanja)){
                indikator = 0;
                toUser.println(indikator);
            }else{
                indikator = 1;
                toUser.println(indikator);
                return;
            }

            Scanner sc = new Scanner(new BufferedInputStream(new FileInputStream(putanja.toString())));
            double realni = 0;
            while(sc.hasNext()){
                if (sc.hasNextDouble())
                    realni += sc.nextDouble();
                else{
                    sc.next();
                }
            }

            toUser.println(realni);

            fromUser.close();
            toUser.close();
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                this.soket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}

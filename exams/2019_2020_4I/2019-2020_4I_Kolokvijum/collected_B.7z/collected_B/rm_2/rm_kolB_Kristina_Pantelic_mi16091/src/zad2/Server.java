package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    private int port;
    public Server(int i) {
        this.port = i;
    }

    public static void main(String[] args) {
        Server server = new Server(31415);
        server.execute();
        //System.out.println("Srecno od strane servera!");
    }

    private void execute() {
        try(ServerSocket server = new ServerSocket(this.port)){

            while(true){

                Socket soket = server.accept();
                UserThread u = new UserThread(soket, this);
                new Thread(u).start();

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

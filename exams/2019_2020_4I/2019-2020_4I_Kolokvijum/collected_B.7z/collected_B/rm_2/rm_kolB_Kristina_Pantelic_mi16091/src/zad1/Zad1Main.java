package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class Zad1Main {
    public static int deljeni_brojac = 0;
    private static List<Thread> niti = new ArrayList<>();
    private static List<String> c_putanje = new ArrayList<>();
    public static void main(String[] args) {

        Path putanja = Paths.get("/home/ispit/Desktop/tests/");
        int br_regularnih = regularni(putanja);
        System.out.println("files:\t" + br_regularnih);

        for (String url_putanja: c_putanje){
            System.out.println("url:\t" + url_putanja);
        }

        for (Thread t: niti){
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("result:\t" + Zad1Main.deljeni_brojac);

        //System.out.println("Srecno!");
    }

    private static int regularni(Path koren) {
        int suma = 0;
        try(DirectoryStream<Path> ds = Files.newDirectoryStream(koren)){
            for (Path path : ds){
                String putanja = path.toString();
                int pocetak;
                if ((pocetak = putanja.lastIndexOf('.') ) != -1){
                    String fajl = putanja.substring(pocetak + 1);
                    if (fajl.equals("c")){
                        String url_putanja = "FILE://" + putanja;
                        c_putanje.add(url_putanja);
                        URL u = new URL(url_putanja);
                        Thread nit = new Thread(new FileProcessorRunnable(u));
                        niti.add(nit);
                        nit.start();
                    }
                }
                if (Files.isRegularFile(path)){
                    suma += 1;
                }
                if (Files.isDirectory(path)){
                    suma += regularni(path);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return suma;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    private String host;
    private int port;

    public Client(String localhost, int i) {
        this.host = localhost;
        this.port = i;
    }

    public static void main(String[] args) {

        Client client = new Client("localhost", 31415);
        client.execute();

        //System.out.println("Srecno od strane klijenta!");
    }

    private void execute() {
        try{
            Socket soket = new Socket(this.host, this.port);
            String ulaz;
            Scanner sc = new Scanner(System.in);
            ulaz = sc.next();
            sc.close();

            //pisemServeru
            PrintWriter out = new PrintWriter(soket.getOutputStream(), true);
            out.println(ulaz.trim()); //poslala sam fajl serveru

            int indikator;
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(soket.getInputStream()));
            indikator = Integer.parseInt(fromServer.readLine());
            if (indikator == 1){
                System.out.println("Nije validna putanja");
                System.exit(0);
            }
            else{
                System.out.println("Validna putanja");
            }

            String citaj = fromServer.readLine().trim();
            Double realni = Double.parseDouble(citaj);
            if (realni == 0.0){
                System.out.println("Fajl ne sadrzi realne brojeve");
            }
            else{
                System.out.println(realni);
            }

            out.close();
            fromServer.close();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

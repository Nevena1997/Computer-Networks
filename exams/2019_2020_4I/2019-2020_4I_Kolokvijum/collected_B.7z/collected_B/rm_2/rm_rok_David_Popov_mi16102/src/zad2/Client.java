package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost",  31415);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));



            System.out.println("Unesite putanju do fajla");
            Scanner sc = new Scanner(System.in);
            String path1 = sc.next().trim();
//            String path = "/home/ispit/Desktop/tests/" + path1;

            out.write(path1);
            out.newLine();
            out.flush();

            System.out.println(in.readLine());
            String resDouble = in.readLine();
            if(resDouble != null)
                System.out.println(resDouble);
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

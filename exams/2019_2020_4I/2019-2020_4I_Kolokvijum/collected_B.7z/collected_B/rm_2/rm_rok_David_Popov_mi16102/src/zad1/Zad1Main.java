package zad1;

import javax.naming.spi.DirectoryManager;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

public class Zad1Main {

    public static void main(String[] args) {

        String path = "/home/ispit/Desktop/tests";
        DirReader dr  = new DirReader(path);
        dr.execute();

    }

}

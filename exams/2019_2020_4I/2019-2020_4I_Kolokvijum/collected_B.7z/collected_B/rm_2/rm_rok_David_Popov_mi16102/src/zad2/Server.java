package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;

public class Server {
    public static void main(String[] args) {
        int PORT = 31415;
        Server s = new Server(PORT);
        s.execute();
    }

    private int port;
//    private List<UserThread> users = new LinkedList<>();

    private Server(int port) {
        this.port = port;
    }

    private void execute() {
        try(ServerSocket serverSocket = new ServerSocket(this.port)) {

            while (true) {
                Socket socket = serverSocket.accept();
//                System.out.println("User connected!");

                UserThread user = new UserThread(socket,this);
//                users.add(user);
                user.start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

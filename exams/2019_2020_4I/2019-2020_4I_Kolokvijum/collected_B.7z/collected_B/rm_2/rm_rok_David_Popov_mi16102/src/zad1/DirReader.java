package zad1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

class DirReader {
    private List<String> allCPaths = new LinkedList<>();
    private int numberOfLines = 0;
    private int numberOfFile = 0;
    private final List<FileProcessorThread> threads = Collections.synchronizedList(new LinkedList<>());
    private String path;

    DirReader(String path) {
        this.path = path;
    }

    void execute() {

        walk(this.path);

        System.out.println("Files:   " + numberOfFile);

        List<URL> urls = new LinkedList<>();
        for(String f : allCPaths){
            try {
                urls.add(new URL("file://" + f));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }

        for(URL url : urls){
            System.out.println("url:     " + url.getProtocol().toUpperCase() + "://" + url.getPath());
        }


        for(int i=0; i<urls.size(); i++){
            this.threads.add(new FileProcessorThread(urls.get(i), this));
            this.threads.get(i).start();
        }

        for (FileProcessorThread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Result:  " + this.numberOfLines);

    }

    private void walk(String path) {
        File f = new File(path);
        if(f.isDirectory()){
            for(int i = 0; i < Objects.requireNonNull(f.list()).length; i++){
                walk(path + '/' + Objects.requireNonNull(f.list())[i]);
            }
        } else if(f.isFile()) {
            this.numberOfFile++;
            String extension = path.substring(path.lastIndexOf('.')+1);
            if(extension.charAt(0) == 'c' && extension.length() == 1){
                this.allCPaths.add(path);
            }
        }
    }

    void addNum(int x) {
        synchronized (this.threads) {
            this.numberOfLines += x;
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {
    private URL url;
    private DirReader dr;

    FileProcessorThread(URL url, DirReader dr) {
        this.url = url;
        this.dr = dr;
    }

    @Override
    public void run() {
        try {
            URLConnection uc = this.url.openConnection();

            BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.US_ASCII));
            String line;
            int br = 0;
            while ((line = in.readLine()) != null) {
                br++;
            }

            dr.addNum(br);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import javax.xml.stream.events.Characters;
import java.io.*;
import java.net.Socket;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class UserThread extends Thread {
    private Server server;
    private Socket socket;

    public UserThread(Socket socket, Server server) {
        this.server = server;
        this.socket = socket;
    }

    @Override
    public void run() {
        try {

            BufferedReader in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
            String path = in.readLine();
            System.out.println(path);
            path = "/home/ispit/Desktop/tests/" + path;



            BufferedReader file = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
            out.write("Validna putanja!");
            out.newLine();
            out.flush();

            String res = this.sumDouble(file);
            out.write(res);
            out.newLine();
            out.flush();


        } catch (FileNotFoundException e) {

            try {
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
                out.write("Putanja nije validan!");
                out.newLine();
                out.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String sumDouble(BufferedReader file) {
        String line = null;
        double sum = 0;
        try{

            while((line = file.readLine()) != null){
                Scanner scLine = new Scanner(line);
                while(scLine.hasNext()){
                    String word = scLine.next().trim();
                    boolean isFloat = true;

                    for(int i=0; i<word.length(); i++){
                        if(!Character.isDigit(word.charAt(i)) && word.charAt(i) != '.'){
                            isFloat = false;
                        }
                    }

                    if(isFloat){
                        sum += Double.parseDouble(word);
                    }
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(sum != 0)
            return Double.toString(sum);
        else
            return "Fajl ne sadrzi realne brojeve";
    }
}

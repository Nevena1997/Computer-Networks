package zad1;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        System.out.println("Srecno!");
    }
}

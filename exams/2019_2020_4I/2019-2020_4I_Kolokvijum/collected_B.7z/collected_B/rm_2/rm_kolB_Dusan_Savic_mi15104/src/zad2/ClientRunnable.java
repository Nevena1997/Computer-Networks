package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientRunnable implements Runnable {
    private Socket client;
    private float sum;
    private Scanner sc;

    public ClientRunnable(Socket client,float sum,Scanner sc) {
        this.client = client;
        this.sum = sum;
        this.sc = sc;
    }

    public Socket getClient() {
        return client;
    }

    public void setClient(Socket client) {
        this.client = client;
    }

    public float getSum() {
        return sum;
    }

    public void setSum(float sum) {
        this.sum = sum;
    }

    @Override
    public void run() {


            String rec;
            while(this.sc.hasNext()) {
                rec = this.sc.next();
                System.out.println(rec);
                float broj;
                try {
                    broj = Float.parseFloat(rec);
                    this.sum += broj;
                }catch (NumberFormatException e){}


            }
        }
    }


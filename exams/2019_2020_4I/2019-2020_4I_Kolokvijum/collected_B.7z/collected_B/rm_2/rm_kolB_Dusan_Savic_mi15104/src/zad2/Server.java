package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class Server {
    static final int DEFAULT_PORT = 31415;
    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");

        try(ServerSocket serverSocket = new ServerSocket(DEFAULT_PORT)) {
            Socket client;

            while(true){
                try{

                client = serverSocket.accept();
                Scanner sc = new Scanner(System.in);
                ClientRunnable cr = new ClientRunnable(client,0,sc);
                new Thread(cr).start();

                float sum  = cr.getSum();
                byte[] buf = new byte[512];
                int bytesRead = 0;
                    System.out.println(sum);
                //try(BufferedWriter BOUT = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
                  //  BOUT.write(buf,0,bytesRead);

                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        }catch(IOException e) {
            e.printStackTrace();
        }
    }
}

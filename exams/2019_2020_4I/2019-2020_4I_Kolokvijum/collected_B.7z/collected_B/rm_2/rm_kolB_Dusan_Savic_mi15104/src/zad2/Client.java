package zad2;

import java.io.*;
import java.net.Socket;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;

public class Client {
    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");
        String host = "localhost";
        try {
            Socket client = new Socket(host,Server.DEFAULT_PORT);
            try (BufferedReader BIN = new BufferedReader(new InputStreamReader(System.in))) {
                char[] buf= new char[512];
                int bytesRead = 0;
                while(-1!=(bytesRead = BIN.read(buf))){
                    try(BufferedWriter BOUT = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
                        BOUT.write(buf,0,bytesRead);

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
            }catch (IOException e){
                e.printStackTrace();
            }
            try (BufferedReader BIN = new BufferedReader(new InputStreamReader(client.getInputStream()))){
                char[] buf= new char[512];
                int bytesRead = 0;
                while(-1!=(bytesRead = BIN.read(buf))){
                    try(BufferedWriter BOUT = new BufferedWriter(new OutputStreamWriter(System.out))){
                        BOUT.write(buf,0,bytesRead);

                    }catch(IOException e){
                        e.printStackTrace();
                    }
                }
            }
            catch (IOException e){
                e.printStackTrace();
            }
            System.out.println();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}

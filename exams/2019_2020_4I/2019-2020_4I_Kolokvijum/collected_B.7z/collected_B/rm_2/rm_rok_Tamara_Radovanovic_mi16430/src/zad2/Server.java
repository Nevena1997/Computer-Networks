package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        System.out.println("Srecno od strane servera!");

        try(ServerSocket server = new ServerSocket(31415)){
            while(true){
                Socket klijent = server.accept();

                new Thread(new FileProcessorRunnable(klijent)).start();

                //BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
                //String poruka = in.readLine();
                //System.out.println(poruka);
            }
        }





    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public Client() throws IOException {
    }

    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");

        try(Socket sock = new Socket("localhost", 31415);
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
        ){

            Scanner sc = new Scanner(System.in);

            String poruka = sc.nextLine();

            out.write(poruka);
            out.newLine();
            out.flush();

            System.out.println(in.readLine());


        } catch (UnknownHostException e) {
            System.err.println("Nije uspostavljena veza sa serverom");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Nije uspostavljena veza sa serverom");
            e.printStackTrace();
        }



    }



}

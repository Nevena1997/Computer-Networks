package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class FileProcessorRunnable implements Runnable {

    private  Socket klijent;
    public FileProcessorRunnable(Socket klijent2) {
        klijent = klijent2;
    }

    @Override
    public void run() {

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
            String poruka;
            poruka = in.readLine();

            //System.out.println("pokrenuta nit");
            System.out.println(poruka);

            try {
                Scanner sc = new Scanner(new FileInputStream("tests/" + poruka));

                float zbir = 0;
                int i = 0 ;
                while(sc.hasNext()) {
                    if(sc.hasNextFloat()){
                        zbir += sc.nextFloat();
                        i++;
                    }
                    else {
                        sc.next();
                    }
                }

                if(i == 0 ){
                    out.write("nema realnih brojeva");
                    out.newLine();
                    out.flush();
                }
                else {
                    Float Zbir = zbir;
                    out.write(Zbir.toString());
                    out.newLine();
                    out.flush();
                }
            } catch (FileNotFoundException e) {
                //e.printStackTrace();
                out.write("Nevalidna putanja");
                out.newLine();
                out.flush();
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                klijent.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

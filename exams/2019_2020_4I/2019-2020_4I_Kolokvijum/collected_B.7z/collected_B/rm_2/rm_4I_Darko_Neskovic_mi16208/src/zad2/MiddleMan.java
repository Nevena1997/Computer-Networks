package zad2;

import java.io.*;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MiddleMan implements Runnable {

    private ServerSocket server;
    private Socket client;
    private String path;



    public MiddleMan(ServerSocket serverSocket, Socket clientSocket) {
        this.server = serverSocket;
        this.client = clientSocket;
    }

    @Override
    public void run() {
        try {

            BufferedReader Cin = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter Cout = new PrintWriter(new OutputStreamWriter(client.getOutputStream()), true);

            String putanja = Cin.readLine();
            putanja = "file:///home/ispit/Desktop/tests/" + putanja;
            try {
                URL url = new URL(putanja);
                File f = new File(url.getPath());
                Scanner sc = new Scanner(f);
                System.out.println("Ispravna je putanja!");
                Cout.println("T");
                Cout.flush();
                //Ovde racunamo sada zbir.
                float zbir = 0;
                Float num;
                while (sc.hasNextFloat()) {
                    try {
                        num = sc.nextFloat();
                        zbir += num;
                    } catch (InputMismatchException e) {
                        //nista
                    }
                }

                if(zbir == 0) {
                    Cout.println("Fajl ne sadrzi realne brojeve.");
                    Cout.flush();
                }else{
                    Cout.println(zbir);
                    Cout.flush();
                }
                sc.close();
                Cin.close();
                Cout.close();
            }catch(MalformedURLException | FileNotFoundException e){
                System.out.println("Nije ispravna putanja!");
                Cout.println("F");
                Cout.flush();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

;
public class Client {

    public static void main(String[] args) {
        Socket socket;
        try {
            socket = new Socket("localhost", 31415);
            PrintWriter cout = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader cin = new BufferedReader(new InputStreamReader(socket.getInputStream()));


            Scanner sc = new Scanner(System.in);
            String putanja = sc.nextLine();
            cout.println(putanja);
            cout.flush();

            String line = cin.readLine();

            if (line.equalsIgnoreCase("T")) {
                //Cekamo zbir float-ova unutar fajla
                String num = cin.readLine();
                System.out.println(num);
            }

            //Inace ne radimo nista.
            sc.close();
            cin.close();
            cout.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

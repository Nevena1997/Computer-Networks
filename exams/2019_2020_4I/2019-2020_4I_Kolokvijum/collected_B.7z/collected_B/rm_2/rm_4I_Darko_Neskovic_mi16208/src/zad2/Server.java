package zad2;

import java.io.*;
import java.net.*;

public class Server {


    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(31415)) {
            while(true){
                Socket clientSocket = serverSocket.accept();
                new Thread(new MiddleMan(serverSocket, clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
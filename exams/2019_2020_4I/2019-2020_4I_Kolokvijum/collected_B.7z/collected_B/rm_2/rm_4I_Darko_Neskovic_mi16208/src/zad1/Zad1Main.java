package zad1;

import java.io.File;
import java.nio.file.DirectoryStream;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float num;
        num = sc.nextFloat();
        System.out.println(num);

    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {

        try (Socket socket = new Socket(Server.HOSTNAME, Server.PORT);
             BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter toServer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in))
        ) {
            String filePath = fromUser.readLine();
            toServer.write(filePath);
            toServer.newLine();
            toServer.flush();
            String resultIsValidPath = fromServer.readLine();
            System.out.println(resultIsValidPath);
            if (resultIsValidPath.equalsIgnoreCase("Validna putanja")) {
                String resultSumOfReal = fromServer.readLine();
                System.out.println(resultSumOfReal);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

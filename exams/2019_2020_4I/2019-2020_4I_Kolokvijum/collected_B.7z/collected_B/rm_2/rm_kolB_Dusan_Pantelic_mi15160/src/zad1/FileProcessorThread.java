package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;

public class FileProcessorThread extends Thread {

    private URL url;
    private BlockingQueue<Integer> linesCountQueue;

    public FileProcessorThread(URL url, BlockingQueue<Integer> linesCountQueue) {
        this.url = url;
        this.linesCountQueue = linesCountQueue;
    }

    @Override
    public void run() {
        try (BufferedReader fileIn = new BufferedReader(
                new InputStreamReader(this.url.openStream(), StandardCharsets.US_ASCII)
        )) {
            int lineCount = 0;
            while (fileIn.readLine() != null)
                lineCount++;
            linesCountQueue.put(lineCount);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

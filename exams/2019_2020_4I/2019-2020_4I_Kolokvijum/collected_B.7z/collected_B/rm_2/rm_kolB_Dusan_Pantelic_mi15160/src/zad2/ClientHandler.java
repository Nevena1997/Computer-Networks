package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandler extends Thread {

    private Socket client;

    public ClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
             BufferedWriter toClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))
        ) {
            // String rootDir = "/home/ispit/Desktop/tests/";
            String rootDir = "";
            Path filePath = Paths.get(rootDir + fromClient.readLine());
            System.out.println(filePath.toString());
            if (Files.isRegularFile(filePath)) {
                toClient.write("Validna putanja");
                toClient.newLine();
                toClient.flush();

                Scanner sc = new Scanner(new FileInputStream(filePath.toString()));
                float realSum = 0;
                float realCnt = 0;
                while (sc.hasNext()) {
                    if (sc.hasNextFloat()) {
                        float realNum = sc.nextFloat();
                        realSum += realNum;
                        realCnt++;
                    } else {
                        sc.next();
                    }

                }
                sc.close();

                if (realCnt > 0) {
                    toClient.write(Float.toString(realSum));
                    toClient.newLine();
                    toClient.flush();
                } else {
                    toClient.write("Fajl ne sadrzi realne brojeve");
                    toClient.newLine();
                    toClient.flush();
                }
            } else {
                toClient.write("Putanja nije validna");
                toClient.newLine();
                toClient.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

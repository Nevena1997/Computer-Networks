package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Zad1Main {

    private static int filesCount = 0;
    private static List<URL> urls = new ArrayList<>();
    private static BlockingQueue<Integer> linesCountQueue = new LinkedBlockingQueue<>();

    public static void main(String[] args) {

        Path rootDir = Paths.get("/home/ispit/Desktop/tests");
        walk(rootDir);
        System.out.println("files: " + filesCount);
        for (URL url: urls) {
            System.out.println("url: FILE://" + url.getPath());
        }
        int result = 0;
        for (int r: linesCountQueue) {
            result += r;
        }
        System.out.println("result: " + result);
    }

    private static void walk(Path dir) {
        try (DirectoryStream<Path> dirStream = Files.newDirectoryStream(dir)){
            for (Path p: dirStream) {
                if (Files.isDirectory(p))
                    walk(p);
                else if (Files.isRegularFile(p)){
                    filesCount++;
                    if (p.getFileName().toString().endsWith(".c")) {
                        URL url = new URL("FILE://" + p.toAbsolutePath().toString());
                        urls.add(url);
                        FileProcessorThread fileProcessorThread = new FileProcessorThread(url, linesCountQueue);
                        fileProcessorThread.start();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

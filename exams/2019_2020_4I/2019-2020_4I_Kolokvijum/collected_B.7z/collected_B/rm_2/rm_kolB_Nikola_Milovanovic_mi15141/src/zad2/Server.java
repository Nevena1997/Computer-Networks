package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    private static int PORT = 31415;
    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(PORT);

        ){
            while(true){
                Socket client =  server.accept();
                Thread n = new Thread(new ClientRunnable(new Client()));
                n.start();
                try(BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                ){

                    Scanner sc = new Scanner(in);
                    String fin = sc.nextLine();
                    System.out.println(fin);

                    try(Scanner fileIn = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fin))))){
                        out.write(1);
                        long rezultat = 0;
                        while(fileIn.hasNextLong()){
                            rezultat += fileIn.nextLong();
                        }
                        String s = new String(String.valueOf(rezultat));
                        out.write(s);
                    } catch (Exception e){
                        out.write(0);
                        e.printStackTrace();
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        System.out.println("Srecno od strane servera!");
    }
}

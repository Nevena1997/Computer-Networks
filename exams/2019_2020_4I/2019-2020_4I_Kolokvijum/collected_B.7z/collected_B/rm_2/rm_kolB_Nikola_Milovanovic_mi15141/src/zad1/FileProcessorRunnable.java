package zad1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {
    public URL url;
    public static int ukupneLinije = 0;

    public FileProcessorRunnable(URL url){
        this.url = url;

    }

    @Override
    public void run() {
        int linije = 0;
        try(BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII));
            Scanner sc = new Scanner(in);
        ){

            while(sc.hasNextLine()){
                linije++;
                sc.nextLine();
            }
            count(linije);


        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static synchronized void count(int linije){
        ukupneLinije += linije;
    }
}

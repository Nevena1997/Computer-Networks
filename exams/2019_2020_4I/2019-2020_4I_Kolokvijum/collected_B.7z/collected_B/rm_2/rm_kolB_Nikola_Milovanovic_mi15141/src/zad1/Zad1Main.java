package zad1;

import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Zad1Main {
    public static void main(String[] args) throws MalformedURLException {

        String startDir = "../../../tests";
        Path p = Paths.get(startDir);

        //...

        for(int i = 0; i < 100; i++){ //za svaki fajl
            if(startDir.endsWith(".c")) {
                try {

                    URL url = new URL(startDir);
                    System.out.println(url);
                    new Thread(new FileProcessorRunnable(url)).start();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
        FileProcessorRunnable a = new FileProcessorRunnable(new URL(startDir));
        System.out.println(a.ukupneLinije);





        System.out.println("Srecno!");
    }
}

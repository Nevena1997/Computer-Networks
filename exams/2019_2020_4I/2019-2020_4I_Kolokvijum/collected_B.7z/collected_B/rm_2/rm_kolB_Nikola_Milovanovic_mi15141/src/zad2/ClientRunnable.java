package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientRunnable implements Runnable{
    Client client;


    public ClientRunnable(Client client) throws IOException {
        this.client = client;
        System.out.println("???");


    }
    @Override
    public void run() {


    }
}

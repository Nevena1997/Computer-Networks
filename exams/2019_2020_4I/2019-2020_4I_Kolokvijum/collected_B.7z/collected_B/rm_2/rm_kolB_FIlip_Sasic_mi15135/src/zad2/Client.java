package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args){
        try {
            Scanner sc = new Scanner(System.in);

            //System.out.println("Unesite ime datoteke");
            String path = sc.nextLine();

            Socket s = new Socket("localhost", Server.PORT);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));

            bw.write(path);
            bw.newLine();
            bw.flush();

            System.out.println(br.readLine());
            System.out.println(br.readLine());

            sc.close();
            s.close();
            bw.close();
            br.close();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }


    }
}

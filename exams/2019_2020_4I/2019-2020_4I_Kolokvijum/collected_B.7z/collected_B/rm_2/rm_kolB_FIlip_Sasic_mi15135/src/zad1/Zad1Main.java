package zad1;

import java.util.ArrayList;

public class Zad1Main {
    public static void main(String[] args) {

        //Napomena: programu prosedjujem moje c fajlove i radim tek od 4-te stavke
        ArrayList<String> paths = new ArrayList<>();
        paths.add("1.c");
        paths.add("2.c");
        paths.add("3.c");

        Counter count = new Counter(paths);

        for(int i = 0;i<paths.size();i++){
            FileProcessorRunnable fpr = new FileProcessorRunnable(count,i);
            Thread t = new Thread(fpr);
            t.start();
        }




    }
}

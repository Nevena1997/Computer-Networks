package zad1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Counter {

    public int global_number_of_lines = 0;
    private int increments = 0;

    private ArrayList<String> paths;

    public Counter(ArrayList<String> paths) {
        this.paths = paths;
    }

    public synchronized void count (int i)  {
        try {
            Scanner sc = new Scanner(new File(paths.get(i)));
            while (sc.hasNext()) {
                sc.nextLine();
                global_number_of_lines++;

            }
            increments++;
            if (increments == paths.size()) {
                System.out.println(global_number_of_lines);
            }


        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }
}

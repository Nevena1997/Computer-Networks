package zad1;

import java.io.FileNotFoundException;
import java.util.concurrent.ThreadLocalRandom;

public class FileProcessorRunnable implements Runnable {

    private static final int MAX_TIME = 2;

    private Counter c;
    private int i;

    public FileProcessorRunnable(Counter c, int i) {
        this.c = c;
        this.i = i;
    }

    @Override
    public void run() {

        try {

            ThreadLocalRandom r = ThreadLocalRandom.current();
            c.count(this.i);
            Thread.sleep(r.nextLong(MAX_TIME));

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

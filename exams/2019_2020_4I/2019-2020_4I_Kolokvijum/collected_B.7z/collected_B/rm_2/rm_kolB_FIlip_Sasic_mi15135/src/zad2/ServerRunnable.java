package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ServerRunnable implements Runnable {
    private Socket cs;

    public ServerRunnable(Socket cs) {
        this.cs = cs;
    }


    @Override
    public void run() {
        try {
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(cs.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(cs.getInputStream()));


            String r_path = br.readLine();
            String path = "/home/ispit/Desktop/tests/" + r_path;
            System.out.println(path);
            Scanner sc;
            try {
                sc = new Scanner(new File(path));
                bw.write("Validna putanja");
                bw.newLine();
                bw.flush();

                if (!sc.hasNextDouble()){
                    bw.write("Fajl ne  sadrzi  realne  brojeve");
                    bw.newLine();
                    bw.flush();
                }else{
                    Double sum = 0.0;
                    boolean cont = true;
                    while(cont){
                        if(sc.hasNextDouble()){
                            sum += sc.nextDouble();
                        }else if(sc.hasNext()){
                            sc.next();
                        }else{
                            cont = false;
                        }

                    }


                    bw.write(String.valueOf(sum));
                    bw.newLine();
                    bw.flush();

                }
                bw.close();
                br.close();
                sc.close();

            }catch (FileNotFoundException e){
                bw.write("Ne validna putanja");
                bw.newLine();
                bw.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}



                                char rahc
                                   [ ]
                                    =
                                  "\n/"
                                    ,
                                redivider
                                   [ ]
                                    =
                       "Able was I ere I saw elbA"
                                    ,
                                    *
                             deliver,reviled
                                    =
                                   1+1
                                    ,
                               niam ; main
                                   ( )
                                  {/*\}
                                   \*/
                                 int tni
                                    =
                                   0x0
                                    ,
                             rahctup,putchar
                                   ( )
                           ,LACEDx0 = 0xDECAL,
                                rof ; for
                             (;(int) (tni);)
                               (int) (tni)
                          = reviled ; deliver =
                                redivider
                                    ;
for ((int)(tni)++,++reviled;reviled* *deliver;deliver++,++(int)(tni)) rof
                                    =
                             (int) -1- (tni)
                          ;reviled--;--deliver;
                             (tni)  =  (int)
                          - 0xDECAL + LACEDx0 -
                                rof ; for
       (reviled--,(int)--(tni);(int) (tni);(int)--(tni),--deliver)
                            rahctup = putchar
                           (reviled* *deliver)
                                    ;
                            rahctup * putchar
                            ((char) * (rahc))
                                    ;
                                   /*\
                                  {\*/}
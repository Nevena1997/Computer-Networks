package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandlerRunnable implements Runnable{

    private Socket client;

    public ClientHandlerRunnable(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        String linija;
        String putanja;
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream(), StandardCharsets.UTF_8))){

            while((linija=in.readLine())!=null){
                putanja ="./tests"+linija.substring(1);
                System.out.println(putanja);
                try{

                    Scanner br = new Scanner(new FileReader(putanja));

                    out.write("true");
                    out.newLine();

                    double suma = skeniraj(br);
                    if(suma == Double.MAX_VALUE){
                        out.write("Fajl ne sadrzi realne brojeve");
                    }else{
                        out.write(Double.toString(suma));
                    }
                    out.newLine();
                    out.flush();


                } catch (Exception e) {
                    out.write("false");
                    out.newLine();
                    out.flush();
                    e.printStackTrace();
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally{
            try {
                client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private double skeniraj(Scanner br){
        double sum =0;
        try{
            while(br.hasNextDouble()){
                sum+=br.nextDouble();
            }
        } catch (Exception e) {
            return Double.MAX_VALUE;
        }

        return sum;
    }
}

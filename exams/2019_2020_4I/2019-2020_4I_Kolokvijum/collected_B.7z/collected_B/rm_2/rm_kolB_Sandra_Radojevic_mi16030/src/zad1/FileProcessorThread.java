package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorThread extends Thread {
    private URL url;
    private AtomicInteger broj;

    public FileProcessorThread(URL url, AtomicInteger broj) {
        this.url = url;
        this.broj=broj;
    }

    @Override
    public void run() {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII))) {
            while(br.readLine()!=null){
                broj.incrementAndGet();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorRunnable implements Runnable {

    Path baseDir;
    Path EOP= Paths.get("");
    AtomicInteger broj_linija=new AtomicInteger(0);

    public FileProcessorRunnable(Path baseDir) {
        this.baseDir = baseDir;
    }

    @Override
    public void run() {
        walk(baseDir);
    }

    public void walk(Path dir){

        DirectoryStream ds= null;
        try {
            ds = Files.newDirectoryStream(dir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Iterator it= ds.iterator();
        while(it.hasNext()) {
            Object pom = it.next();
            if (Files.isDirectory(dir))
                walk(dir);
            else if (Files.isRegularFile(dir) && it.toString().substring(it.toString().length()-2).equals(".c")){
                URL u = null;
                try {
                    u = new URL("FILE://"+it);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                System.out.println(u.toString());
                new FileProcessorThread(u, broj_linija).start();
                System.out.println(dir);
            }
        }
    }
}

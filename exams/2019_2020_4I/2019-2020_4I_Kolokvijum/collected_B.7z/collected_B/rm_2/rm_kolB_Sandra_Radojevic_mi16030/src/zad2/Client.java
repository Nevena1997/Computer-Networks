package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        String hostname="localhost";
        String putanja;
        try(Socket client = new Socket(hostname, Server.DEFAULT_PORT);
            BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
            BufferedReader in=new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8))){

            while(true){

                putanja =sc.readLine();
                out.write(putanja);
                out.newLine();
                out.flush();

                String indikator = in.readLine();
                if(indikator.equals("true")){
                    System.out.println("Validna putanja");
                }
                String suma = in.readLine();
                System.out.println(suma);

            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Srecno od strane klijenta!");
    }
}

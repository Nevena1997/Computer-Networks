package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int DEFAULT_PORT = 31415;
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){

            System.out.println("Cekam klijente");
            while(true){
                Socket client = server.accept();

                new Thread(new ClientHandlerRunnable(client)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Srecno od strane servera!");
    }
}

package zad1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        String base= "/home/ispit/Desktop/tests/";


        try {
            DirectoryStream ds= Files.newDirectoryStream(Paths.get(base));
            Iterator it= ds.iterator();
            AtomicInteger broj_linija=new AtomicInteger(0);
            while(it.hasNext()){
                Object pom =it.next();
                System.out.println(pom);
                if(it.toString().substring(it.toString().length()-2).equals(".c")){
                    URL u = new URL("FILE://"+it);
                    System.out.println(u.toString());
                    new FileProcessorThread(u, broj_linija).start();
                }

            }
            System.out.println(ds);
        } catch (IOException e) {
            e.printStackTrace();
        }
       // System.out.println("Srecno!");
    }
}

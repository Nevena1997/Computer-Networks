package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.Buffer;
import java.util.LinkedList;
import java.util.List;

public class Server {
    public static int DEFAUL_PORT = 31415;
    public static void main(String[] args) {
        try(ServerSocket serv = new ServerSocket(DEFAUL_PORT)){
            List<Thread> listT = new LinkedList<>();
            while(true){
                try{
                    Socket client = serv.accept();
                    Thread t = new Thread(new UserThread(client));
                    t.start();
                    listT.add(t);
                }catch (IOException e) {
                    e.printStackTrace();
                    continue;
                }

            }

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}

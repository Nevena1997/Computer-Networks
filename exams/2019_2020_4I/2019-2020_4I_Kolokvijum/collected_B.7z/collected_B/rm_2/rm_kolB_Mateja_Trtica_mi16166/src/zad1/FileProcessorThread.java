package zad1;

import javax.xml.stream.events.EndDocument;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorThread extends Thread {
    private URL url;
    public static AtomicInteger brojac = new AtomicInteger(0);
    public FileProcessorThread(URL url) {
        this.url = url;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(url.getFile()), StandardCharsets.US_ASCII));
            while(in.readLine()!=null){
                brojac.getAndIncrement();
            }
            in.close();

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class UserThread implements Runnable {
    private Socket client;

    public UserThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            String dodatak = in.readLine();
            System.out.println(dodatak);
            String putanja = "/home/ispit/Desktop/tests/" +dodatak;
            File f = new File(putanja) ;
            Scanner sc = new Scanner(f);
            double zbir = 0;
            int brojac =0;
            while(sc.hasNext()){
                if(sc.hasNextDouble()){
                    zbir = zbir + sc.nextDouble();
                    brojac++;
                }else if(sc.hasNextInt()) {
                    brojac++;
                    zbir = zbir + sc.nextInt();
                }else {
                     sc.next();}
            }

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            if(brojac != 0)
                out.write("t"+zbir);
            else
                out.write("tFajl ne sadrzi realne brojeve!");
            out.newLine();
            out.flush();
            out.close();
            in.close();

        } catch (FileNotFoundException e) {
            BufferedWriter out = null;
            try {
                out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                out.write("f");
                out.newLine();
                out.flush();

            } catch (IOException e1) {
                e1.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

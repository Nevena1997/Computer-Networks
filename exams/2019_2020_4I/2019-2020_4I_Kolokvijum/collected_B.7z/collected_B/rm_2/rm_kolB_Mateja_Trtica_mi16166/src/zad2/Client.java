package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try {
            Socket client = new Socket("localhost",Server.DEFAUL_PORT);
            try {
                Scanner in = new Scanner(System.in);

                String putanja = in.next();

                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                out.write(putanja);
                out.newLine();
                out.flush();

               BufferedReader povratak = new BufferedReader(new InputStreamReader(client.getInputStream()));
               String odgovor = povratak.readLine();
               String validan = odgovor.substring(0,1);
               String zbir = odgovor.substring(1);

                if(validan.equals("t"))
                    System.out.println("Validna putanja");
                else if (validan.equals("f"))
                    System.out.println("Nije validna putanja");
                System.out.println(zbir);
                out.close();
                povratak.close();

            } catch (IOException e) {
                e.printStackTrace();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

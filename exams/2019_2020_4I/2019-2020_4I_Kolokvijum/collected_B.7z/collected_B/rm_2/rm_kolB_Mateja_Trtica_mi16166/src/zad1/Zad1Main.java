package zad1;

import javax.naming.directory.DirContext;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

public class Zad1Main {
    public static void main(String[] args) {

        String[] putanje = {"/home/ispit/Desktop/tests/urls.txt",
                "/home/ispit/Desktop/tests/dir/1.txt",
                "/home/ispit/Desktop/tests/dir/gaben.webp",
        "/home/ispit/Desktop/tests/dir/dir1/2.txt","/home/ispit/Desktop/tests/dir/dir1/3.txt","/home/ispit/Desktop/tests/dir/dir1/smile.c",
        "/home/ispit/Desktop/tests/dir/dir1/smile.out","/home/ispit/Desktop/tests/dir/dir1/dir11/4.txt","/home/ispit/Desktop/tests/dir/dir1/dir11/5.a.txt",
        "/home/ispit/Desktop/tests/dir/dir1/dir11/palindrome.c","/home/ispit/Desktop/tests/dir/dir2/dir21/pi.c","/home/ispit/Desktop/tests/dir/dir2/dir21/pi",
        "/home/ispit/Desktop/tests/dir/dir2/dir22/5.txt","/home/ispit/Desktop/tests/dir/dir2/dir22/dont_readme.ntxt","/home/ispit/Desktop/tests/dir/dir2/dir22/dir221/w.txt",
        "/home/ispit/Desktop/tests/dir/dir2/dir22/dir221/a.txt.so","/home/ispit/Desktop/tests/dir/dir3/stallman.jpg" ,"/home/ispit/Desktop/tests/dir2/1.test",
        "/home/ispit/Desktop/tests/dir2/2.test","/home/ispit/Desktop/tests/dir2/3.test"};
        System.out.println(putanje.length);
        for(int i = 0; i < putanje.length;i++){
            try {
                String putanja = putanje[i];
                URL url;
                int indeks = putanja.lastIndexOf(".");
                if(indeks > 0){
                     String ekst = putanja.substring(indeks);
                     List<Thread> tLIst = new LinkedList<>();
                     if(ekst.equals(".c")) {
                         url = new URL("FILE","localhost",8080,putanja);
                         Thread t = new FileProcessorThread(url);
                         t.start();
                         tLIst.add(t);
                         System.out.println(url.getProtocol()+"://" +url.getPath());
                     }
                     for(int j = 0; j < tLIst.size();j++)
                         tLIst.get(j).join();
                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        System.out.println(FileProcessorThread.brojac.get());

    }
}

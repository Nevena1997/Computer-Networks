package zad1;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.net.URLStreamHandler;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        File fajl = new File("");
        String[] arr =new String[3];
        arr[0] = "/home/ispit/Desktop/1.txt";
        arr[1] = "/home/ispit/Desktop/1.txt";
        arr[2] = "/home/ispit/Desktop/1.txt"; //URL-ovi
        try{
            BufferedInputStream[] ins = new BufferedInputStream[arr.length];

            for (int i = 0; i < arr.length; i++)
            {
                ins[i] = new BufferedInputStream(new FileInputStream(arr[i]));
            }

            for (int i = 0; i < ins.length;i++)
            {
                FileProcessorRunnable nit = new FileProcessorRunnable(ins.toString());
            }

            System.out.println("Result: "+FileProcessorRunnable.zajBrojac);
            for (BufferedInputStream in1 : ins)
                in1.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try{
            Socket klijent = new Socket();

            SocketAddress port = new InetSocketAddress(31415);
            klijent.connect(port,20);

            Scanner sc = new Scanner(System.in);
             klijent.bind(port);
             System.out.println("/home/ispit/Desktop/"+sc.nextLine());
            File fajl = new File("/home/ispit/Desktop/"+sc.nextLine());
            if (fajl == null)
                System.out.println("Nije validna putanja do fajla.");
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }
}

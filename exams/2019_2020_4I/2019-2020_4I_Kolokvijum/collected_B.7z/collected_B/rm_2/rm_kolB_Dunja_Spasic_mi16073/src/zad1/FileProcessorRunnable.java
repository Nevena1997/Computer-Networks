package zad1;

import java.util.Scanner;

public class FileProcessorRunnable implements Runnable {
    private String sadrzaj;
    public static Integer zajBrojac = 0;
    private int brojac = 0;

    public  FileProcessorRunnable(String sadrzaj)
    {
        this.sadrzaj = sadrzaj;
    }
    @Override
    public void run() {
        Scanner sc = new Scanner(sadrzaj);
        while(sc.hasNextLine())
            brojac++;

        synchronized (zajBrojac += brojac){
            try{
                this.wait();
            }
            catch (InterruptedException ie)
            {
                System.out.println("Prekinuta je nit.");
                ie.printStackTrace();
            }
        }
        this.notifyAll();
    }
}

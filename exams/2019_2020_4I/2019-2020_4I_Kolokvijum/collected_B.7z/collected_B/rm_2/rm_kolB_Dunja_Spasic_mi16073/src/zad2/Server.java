package zad2;

import java.io.IOException;
import java.net.ServerSocket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(31415);
            server.accept();

            server.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }
}

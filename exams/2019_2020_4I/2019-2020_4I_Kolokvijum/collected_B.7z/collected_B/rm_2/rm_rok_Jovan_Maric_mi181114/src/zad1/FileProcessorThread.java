package zad1;

import java.io.*;
import java.net.URL;
import java.nio.Buffer;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorThread extends Thread {
    private Lock lock ;
    private Condition cons;
    private URL url ;
    private  int numberOfLines=0;

    public  FileProcessorThread(URL url){
        this.url =url;
        this.lock= new ReentrantLock();
    }
    @Override
    public void run() {
        this.lock.lock();
        try{
                Scanner sc =new Scanner(new BufferedReader(new FileReader(url.getFile())));
                while(sc.hasNextLine()){
                    sc.nextLine();
                    this.numberOfLines = this.numberOfLines +1 ;

                }
        }
        catch (FileNotFoundException e){

        }
        finally {
            lock.unlock();
        }
    }

    public int getNumberOfLine() {
        return this.numberOfLines;
    }
}

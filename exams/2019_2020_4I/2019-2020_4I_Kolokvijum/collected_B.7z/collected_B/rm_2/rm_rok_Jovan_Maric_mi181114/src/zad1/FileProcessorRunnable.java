package zad1;

import javax.print.DocFlavor;
import java.lang.reflect.Array;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

import static java.nio.file.Files.*;

public class FileProcessorRunnable implements Runnable {

    private static final Path end  = Path.of("");
    private final BlockingQueue<Path> que ;
    private int brojReg ;
    private Path dir;
    private ArrayList<URL> urls = new ArrayList<URL>();

    public FileProcessorRunnable(BlockingQueue<Path> que, Path dir){
        this.dir= dir;
        this.que= que;
        this.brojReg = 0;
    }
    @Override
    public void run() {
            search(dir);
            que.add(end);
    }

    public void search(Path dir){
        try(var  x = newDirectoryStream(dir)) {
            var i = x.iterator();
                while(i.hasNext()){
                    var fileOrDir = i.next();
                    if(isDirectory(fileOrDir)){
                        search(fileOrDir);
                    }
                    else{
                        if(isRegularFile(fileOrDir)){
                            brojReg ++;
                            var file = fileOrDir.getFileName();
                            if(file.toString().endsWith(".c")){
                                var a = new URL("file","local",dir.toAbsolutePath().toString()+"/"+file.toString());
                                urls.add(a);
                                que.add(Path.of(dir.toAbsolutePath().toString()+"/"+file.toString()));
                            }
                        }
                    }
                }
        }
        catch (Exception e){

        }
    }
    public int getBrojReg(){
        return this.brojReg;
    }
    public void listUrl() {
        for (var url:urls) {
            System.out.println(url);
        }
    }

    public ArrayList<URL> getUrls() {
        return urls;
    }
}

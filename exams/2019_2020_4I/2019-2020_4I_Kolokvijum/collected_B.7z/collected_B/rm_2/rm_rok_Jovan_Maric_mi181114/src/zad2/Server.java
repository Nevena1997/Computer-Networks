package zad2;

public class Server {
    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");
    }
}

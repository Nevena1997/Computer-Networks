package zad1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static void main(String[] args) {
        try {
            BlockingQueue<Path> que = new ArrayBlockingQueue<Path>(50);

            FileProcessorRunnable x = new FileProcessorRunnable(que,Path.of("/home/ispit/Desktop/tests"));

            Thread th = new Thread(x);
            th.start();

            th.join();
            System.out.println("Files: "+x.getBrojReg());
            x.listUrl();

            ArrayList<Thread> threads = new ArrayList<Thread>();
            ArrayList<FileProcessorThread> citaci = new ArrayList<FileProcessorThread>();
            int i = 0;
            for (var url : x.getUrls()){
                citaci.add(new FileProcessorThread(url));
                threads.add(new Thread(citaci.get(i)));
                i++;
            }
            for(var t : threads){
                t.start();
            }
            for(var t : threads){
                t.join();
            }
            int num = 0;
            for(var c : citaci){
                num = num + c.getNumberOfLine();
            }
            System.out.println(num);
        }
        catch (InterruptedException e){
            System.out.print(e.getStackTrace());
        }
    }
}

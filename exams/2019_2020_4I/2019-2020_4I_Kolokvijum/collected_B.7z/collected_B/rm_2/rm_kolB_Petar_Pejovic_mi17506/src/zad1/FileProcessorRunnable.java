package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {

    private URL u;

    public FileProcessorRunnable(URL u) {
        this.u = u;
    }

    @Override
    public void run() {
        try {
            URLConnection con = u.openConnection();
            BufferedReader buf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line;
            int broj = 0;
            while ((line = buf.readLine()) != null)
                broj++;



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

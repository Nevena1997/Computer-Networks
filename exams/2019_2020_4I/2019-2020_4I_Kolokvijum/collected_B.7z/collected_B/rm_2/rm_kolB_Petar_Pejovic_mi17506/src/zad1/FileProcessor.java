package zad1;

import java.net.URL;
import java.util.concurrent.BlockingQueue;

public class FileProcessor {

    private BlockingQueue<URL> urls;
    private int N;

    public FileProcessor(BlockingQueue<URL> urls){
        this.urls = urls;
    }

    public synchronized void func() throws InterruptedException {
        while (true){
            URL u = urls.take();
            if(u == null)
                break;

            new Thread(new FileProcessorRunnable(u)).start();
        }
    }

    public void sumN(int n) {
        this.N = this.N + n;
    }

    public int getN() {
        return N;
    }

    public BlockingQueue<URL> getUrls() {
        return urls;
    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static void main(String[] args) throws FileNotFoundException {

        try{

            DirectoryStream<Path> files = Files.newDirectoryStream(Paths.get("/home/ispit/Desktop/rm_kolB_Petar_Pejovic_mi17506/src/a"));
            BlockingQueue<URL> paths = null;
            int i=0;
            int c =0;
            for(Path p : files){
                if(Files.isRegularFile(p)){
                    i++;
                    String s = p.toString().trim();
                    System.out.println(s);
                    s = s.substring(s.lastIndexOf('/')+1);
                    s = s.substring(s.lastIndexOf('.')+1);
                    if( s.equals("c") ){
                        c++;

                        URL url = new URL("FILE:///home/ispit/Desktop/" + p.toString());
                        System.out.println(url);
                        paths.put(url);
                    }
                }
            }

            System.out.println(i);

            FileProcessor fp = new FileProcessor(paths);


        } catch(IOException | InterruptedException e){
                e.printStackTrace();
        }
    }
}

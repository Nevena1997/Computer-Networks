package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ClientRunnable implements Runnable{

    Socket socket;

    public ClientRunnable(Socket client){
        this.socket = client;
    }

    @Override
    public void run() {

        try(
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8));
                ){

            String file = in.readLine();
            System.out.println(file);
            BufferedReader inFile = null;
            try {
                inFile = new BufferedReader(
                        new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            }catch (IOException e) {
                out.write("Putanja nije validna");
                out.newLine();
                out.flush();
            }

            boolean imaBrojeva = false;
            float sum = 0;
            int broj;

            while ((broj = inFile.read()) != -1){
                if(Character.isDigit(broj)){
                    sum += (float) broj;
                    imaBrojeva = true;
                }
            }

            /*while ((line = inFile.readLine()) != null){

                String[] niz = line.split(" ");
                for(String n : niz){
                    n = n.trim();
                    sum += n;
                    if () {

                    }


                }
            }*/

            out.write("Validna putanja");
            out.newLine();

            if(imaBrojeva){
                out.write(String.valueOf(sum));
                out.newLine();
                out.flush();
            }
            else{
                out.write("Fajl ne sadrzi realne brojeve");
                out.newLine();
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class Client {
    public static void main(String[] args) {

        try(
                Socket socket = new Socket("localhost",31412);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8));
                BufferedReader inUser = new BufferedReader(
                        new InputStreamReader(System.in));
                ) {

            String path = inUser.readLine();
            out.write(path);
            out.newLine();
            out.flush();

            String line;
            while ((line = in.readLine()) != null)
                System.out.println(line);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

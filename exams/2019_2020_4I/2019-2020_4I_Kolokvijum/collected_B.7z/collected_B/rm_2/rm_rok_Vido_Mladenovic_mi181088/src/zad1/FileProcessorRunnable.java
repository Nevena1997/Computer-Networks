package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {

    URLConnection uc;
    private boolean printRes;

    FileProcessorRunnable (URLConnection uc, boolean printRes) {
        this.uc = uc;
        this.printRes = printRes;
    }

    @Override
    public synchronized void run() {
        if (printRes) {
            while (Zad1Main.numOfActiveThreads > 0) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            System.out.println("result: " + Zad1Main.globalNumberOfLines);
        } else {

            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(this.uc.getInputStream(), StandardCharsets.US_ASCII)
            )) {
                while (in.readLine() != null) {
                    Zad1Main.globalNumberOfLines++;
                }

                Zad1Main.numOfActiveThreads--;

                this.notifyAll();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

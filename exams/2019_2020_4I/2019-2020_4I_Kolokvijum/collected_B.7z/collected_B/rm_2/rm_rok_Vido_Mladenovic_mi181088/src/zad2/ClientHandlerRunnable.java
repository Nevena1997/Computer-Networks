package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientHandlerRunnable implements Runnable {

    Socket client;
    ClientHandlerRunnable (Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (
                BufferedReader networkIn = new BufferedReader(
                        new InputStreamReader(this.client.getInputStream(), StandardCharsets.US_ASCII)
                );
                BufferedWriter networkOut = new BufferedWriter(
                        new OutputStreamWriter(this.client.getOutputStream(), StandardCharsets.US_ASCII)
                )
        ) {
            String relativePath = networkIn.readLine();
            System.out.println(relativePath);

            if (Files.exists(Paths.get("/home/ispit/Desktop/tests/" + relativePath))) {
                networkOut.write("Validna putanja");
                networkOut.newLine();

                Scanner sc = new Scanner( new FileInputStream("/home/ispit/Desktop/tests/" + relativePath));

                Double sum = 0.0;
                boolean containsRealNumbers = false;

                while (sc.hasNext()) {
                    if (sc.hasNextDouble()) {
                        containsRealNumbers = true;
                        Double num = sc.nextDouble();
                        sum += num;
                    } else {
                        sc.next();
                    }
                }
                if (!containsRealNumbers) {
                    networkOut.write("Fajl ne sadrzi realne brojeve");
                } else {
                    networkOut.write(String.valueOf(sum));
                }

                networkOut.newLine();
            } else {
                networkOut.write("Nevalidna putanja");
                networkOut.newLine();
            }
            networkOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

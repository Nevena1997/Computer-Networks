package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static int PORT = 31415;
    public static void main(String[] args) {
        try (ServerSocket s = new ServerSocket(31415)) {
            Socket client = s.accept();

            new Thread(new ClientHandlerRunnable(client)).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

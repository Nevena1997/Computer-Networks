package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (
                Socket s = new Socket("localhost", Server.PORT);
                Scanner in = new Scanner(System.in);
                BufferedWriter networkOut = new BufferedWriter(
                        new OutputStreamWriter(s.getOutputStream(), StandardCharsets.US_ASCII)
                );
                BufferedReader networkIn = new BufferedReader(
                        new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII)
                );
        ) {
            String relativePath = in.nextLine();

            networkOut.write(relativePath, 0, relativePath.length());
            networkOut.newLine();
            networkOut.flush();

            String line;
            while ((line = networkIn.readLine()) != null) {
                System.out.println(line);
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

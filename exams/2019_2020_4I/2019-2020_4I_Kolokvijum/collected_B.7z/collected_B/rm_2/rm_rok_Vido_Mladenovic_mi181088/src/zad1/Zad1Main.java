package zad1;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Zad1Main {
    public static int numOgRegFiles = 0;

    public static int globalNumberOfLines = 0;
    public static int numOfActiveThreads = 0;

    public static void main(String[] args) {

        Path root = Paths.get("/home/ispit/Desktop/tests");

        try {
            walk(root, false);
            System.out.println("files: " + numOgRegFiles);

            numOgRegFiles = 0;
            walk(root, true);

            new Thread(new FileProcessorRunnable(null, true)).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void walk(Path dir, boolean createUrl) throws IOException {
        DirectoryStream<Path> files = Files.newDirectoryStream(dir);

        for (Path file : files) {
            if (Files.isRegularFile(file)) {
                numOgRegFiles++;
                if (file.getFileName().toString().endsWith(".c")) {
                    if (createUrl) {
                        URL u = new URL("FILE://" + file);
                        System.out.println("url: " + "FILE://" + file);
                        URLConnection uc = u.openConnection();
                        new Thread(new FileProcessorRunnable(uc, false)).start();
                    } else {
                        numOfActiveThreads++;
                    }
                }
            } else if (Files.isDirectory(file)) {
                walk(file, createUrl);
            }
        }
    }
}

package zad2;

import javax.swing.plaf.IconUIResource;
import java.io.*;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Client {
    private String ime;
    private int port;
    private BufferedReader odServera;
    private PrintWriter kaServeru;

    public BufferedReader getOdServera() {
        return odServera;
    }

    public PrintWriter getKaServeru() {
        return kaServeru;
    }

    public Client(String ime, int port) {
        this.ime = this.getIme();
        this.port = port;
    }

    private String getIme() {
        System.out.println("Unesite vase ime: ");
        try (Scanner sc = new Scanner(System.in)){
            String ime = sc.nextLine();
        }
        return  ime;
    }

    public static void main(String[] args) throws IOException {
        Client klijent = new Client("localhost", 31425);
        klijent.execute();
}

    private void execute() throws IOException {
        try {
            Socket socket = new Socket(this.ime, Server.PORT);
        }catch (Exception e){
            e.printStackTrace();
        }

        try (Socket socket = new Socket(this.ime, Server.PORT);
             PrintWriter pw = new PrintWriter(socket.getOutputStream())
                ){
            String imeFajla = "";
            System.out.println("Unesite ime fajla: ");
            pw.write(imeFajla);
            pw.flush();
        }catch (IOException e) {
            e.printStackTrace();
        }

    }


}

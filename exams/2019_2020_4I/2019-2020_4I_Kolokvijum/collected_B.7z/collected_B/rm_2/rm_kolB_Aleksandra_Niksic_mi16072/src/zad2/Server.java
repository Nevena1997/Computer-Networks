package zad2;

import java.io.*;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class Server {
    public static final int PORT = 31415;
    private int port;
    private BufferedReader odKlijenta;
    private PrintWriter kaKlijentu;

    public BufferedReader getOdKlijenta() {
        return odKlijenta;
    }

    public PrintWriter getKaKlijentu() {
        return kaKlijentu;
    }

    public boolean isIndikator() {
        return indikator;
    }

    public ArrayList getTredovi() {
        return tredovi;
    }

    private boolean indikator = false;

    private ArrayList tredovi = new ArrayList<>();

    public Server(int port) {
        this.port = port;
    }

    public static void main(String[] args) {
        //System.out.println("Srecno od strane servera!");
        Server server = new Server(PORT);
        server.execute();
    }

    private void execute() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server slusa na portu: " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Konektovao se klijent.");

                odKlijenta = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                kaKlijentu = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));

                Thread t = new Threads(socket);
                tredovi.add(t);
                t.start();
                //kad zavrsi
                tredovi.remove(t);
                odKlijenta.close();
                kaKlijentu.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private double zbir (double niz[]){
        float suma = 0;
        for (double x : niz){
            suma += x;
        }
        return suma;
    }
}

package zad2;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Threads extends Thread {
    private Socket socket;
    private Server server;

    public Threads(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        String fajl =  server.getOdKlijenta().toString();
        try(Scanner sc = new Scanner(fajl)){
            String linija = sc.nextLine();
            ArrayList niz = new ArrayList<>();
        }
    }
}

package zad1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Zad1Main {
    private static int NUM_OF_THREADS = 10;

    public static void main(String[] args) {
        // Implementirati logiku u jednoj od FileProcessor klasa

        try {
            Path path = Paths.get("Desktop/test").toAbsolutePath();


            for (int i = 0; i < NUM_OF_THREADS; i++){
                new Thread(new FileProcessorRunnable(path)).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

       // System.out.println("Srecno!");
    }
}

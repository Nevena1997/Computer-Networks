package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String hostname = "localhost";

        try (Socket sock = new Socket(hostname, Server.DEFAULT_PORT);
             BufferedReader in = new BufferedReader(
                     new InputStreamReader(sock.getInputStream()));
             BufferedWriter out = new BufferedWriter(
                     new OutputStreamWriter(sock.getOutputStream()));
             BufferedReader clientIn = new BufferedReader(
                     new InputStreamReader(System.in))
        ){
            while (true){
                String path = clientIn.readLine();
                if(path == null)
                    break;

                out.write(path);
                out.newLine();
                out.flush();

                System.out.println(in.readLine());

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

      //  System.out.println("Srecno od strane klijenta!");
    }
}

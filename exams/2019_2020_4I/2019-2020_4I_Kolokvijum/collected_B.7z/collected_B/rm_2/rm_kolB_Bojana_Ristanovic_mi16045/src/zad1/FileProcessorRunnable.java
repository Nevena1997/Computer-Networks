package zad1;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import static java.nio.file.Files.isDirectory;

public class FileProcessorRunnable implements Runnable {
    private Path path;

    public FileProcessorRunnable(Path path) {
        this.path = path;
    }

    @Override
    public void run() {
        if (Files.isDirectory(this.path)){
            new FileProcessorRunnable(this.path);
        }
    }
}

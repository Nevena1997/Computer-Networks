package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server {
    public static final int DEFAULT_PORT = 31415;

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){
            System.out.println("Connected to port: " + DEFAULT_PORT);

           while (true){
                System.err.println("Listening for clients...");

                Socket client = server.accept();
                Thread t = new Thread(new HolderRunnable(client));
                t.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

       // System.out.println("Srecno od strane servera!");
    }

    public static class HolderRunnable implements Runnable {

        private Socket client;
        private BufferedReader in;
        private PrintStream out;

        public HolderRunnable(Socket client) {
            this.client = client;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
               // out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
                out = new PrintStream(client.getOutputStream());

                String path = in.readLine();
                System.out.println(Paths.get(path));

                Path path1 = Paths.get(path).toAbsolutePath();

               while (path != null) {
                   if (path1.isAbsolute()) {
                       //out.write("Validna putanja");
                       //out.newLine();
                       out.println("Validna putanja");

                       // Indikator da li ima brojeva u fajlu
                       boolean ind = false;
                       double sum = 0;
                       try {
                           Scanner file = new Scanner(path1);
                           while (file.hasNext()){
                               if(file.hasNextDouble()){
                                   ind = true;
                                   sum += file.nextDouble();
                               }
                           }

                           file.close();

                       } catch (IOException e) {
                           e.printStackTrace();
                       }

                       if (ind == false){
                           //out.write("Fajl ne sadrzi realne brojeve");
                           out.println("Fajl ne sadrzi realne brojeve");
                           out.flush();
                       } else {
                           out.print(sum);
                           out.flush();
                       }

                   } else {
                      // out.write("Putanja nije valdina");
                      // out.newLine();
                       out.println("Putanja nije validna");
                       out.flush();
                   }
               }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

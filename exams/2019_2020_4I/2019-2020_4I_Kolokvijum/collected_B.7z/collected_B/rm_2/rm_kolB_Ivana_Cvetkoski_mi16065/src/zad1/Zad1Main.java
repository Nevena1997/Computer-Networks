package zad1;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Zad1Main {

    public static int br=0;
    public static int brojLinija=0;


    public static void main(String[] args) {

        Path dir = Paths.get("/home/ispit/Desktop/tests");
        walk(dir);

        System.out.println("files: " + br);
        System.out.println("result: " + brojLinija);
    }

    private static void walk(Path dir){

        try{
            DirectoryStream<Path> stream = Files.newDirectoryStream(dir);
            for(Path p: stream){
                if(Files.isDirectory(p)) {
                    walk(p);
                }else{
                    if(Files.isRegularFile(p))
                        br++;

                    String linija = p.toString();
                    boolean eks = linija.endsWith(".c");
                    if(eks){
                        try {
                            String file = "FILE://";
                            String cela = file.concat(linija);
                            URL u = new URL(cela);
                            System.out.println(cela);
                            new Thread(new FileProcessorRunnable(u, brojLinija)).start();

                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

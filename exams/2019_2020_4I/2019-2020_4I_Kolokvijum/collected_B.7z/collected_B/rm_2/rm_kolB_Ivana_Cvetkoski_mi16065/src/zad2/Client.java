package zad2;


import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try {
            Scanner sc = new Scanner(System.in);
            Socket klijent = new Socket("localhost", 31415);
            BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            String fajl = sc.nextLine();
            out.write(fajl);
            out.newLine();
            out.flush();

            String val = in.readLine();
            System.out.println(val);

            if(val.equals("Validna putanja")){

                String linija = in.readLine();

                if(linija.equals("Fajl ne sadrzi realne brojeve")){
                    System.out.println(linija);
                }else {
                    System.out.println(linija);
                }
            }


            in.close();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

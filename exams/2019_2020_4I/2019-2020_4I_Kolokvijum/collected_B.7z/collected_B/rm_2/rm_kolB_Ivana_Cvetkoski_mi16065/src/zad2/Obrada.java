package zad2;

import java.io.*;
import java.net.Socket;

public class Obrada implements Runnable {

    Socket k;
    public Obrada(Socket k){
        this.k=k;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(k.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(k.getOutputStream()));

            String fajl = in.readLine();
            System.out.println(fajl);

            BufferedReader rf = new BufferedReader(new InputStreamReader(new FileInputStream(fajl)));

            out.write("Validna putanja");
            out.newLine();
            out.flush();


            String line;
            Double zbir=0.0;
            boolean ima = false;
            while((line=rf.readLine())!=null){
                String reci[] = line.split(" ");
                for(int i=0; i<reci.length; i++){

                    try{
                        Double k = Double.parseDouble(reci[i]);
                        zbir+=k;
                        ima=true;
                    }catch (NumberFormatException e) {
                        ;
                    }catch (NullPointerException ex){
                        ;
                    }
                }
            }

            if(ima) {
                out.write(String.valueOf(zbir));
                System.out.println(String.valueOf(zbir));
                out.newLine();
                out.flush();
            }else{
                out.write("Fajl ne sadrzi realne brojeve");
                out.newLine();
                out.flush();
            }

            in.close();
            out.close();

        } catch (FileNotFoundException e) {
            BufferedWriter out = null;
            try {
                out = new BufferedWriter(new OutputStreamWriter(k.getOutputStream()));

                out.write("Nevalidna putanja");
                out.newLine();
                out.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

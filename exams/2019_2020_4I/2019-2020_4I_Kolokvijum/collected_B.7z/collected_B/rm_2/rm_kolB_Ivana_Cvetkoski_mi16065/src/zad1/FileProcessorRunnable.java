package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {

    URL u;
    int brojLinija;

    public FileProcessorRunnable(URL u, int brojLinija){
        this.u=u;
        this.brojLinija=brojLinija;
    }

    @Override
    public void run() {
        brojac();
    }

    public synchronized void brojac(){
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(this.u.openStream(), StandardCharsets.US_ASCII));
            String line;

            while((line=in.readLine())!=null){
                this.brojLinija++;
            }
           // System.out.println("thread " + this.brojLinija);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try {
            Socket client = new Socket("localhost", Server.PORT);
            BufferedReader fromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter toServer = new PrintWriter(new OutputStreamWriter(client.getOutputStream()),true);
//            System.err.println("Connected to server");

            Scanner sc = new Scanner(System.in);
//            System.out.println("Enter path");
            toServer.println(sc.next());

            String answer = fromServer.readLine();
            if(answer.equalsIgnoreCase("valid")){
                System.out.println("Validna putanja");
            }
            else{
                System.out.println("Nije validna putanja");
                return;
            }

            double sum = Double.parseDouble(fromServer.readLine());
            if(sum != 0) {
                System.out.println(sum);
            }
            else{
                System.out.println("Fajl ne sadrzi realne brojeve");
            }

            fromServer.close();
            toServer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

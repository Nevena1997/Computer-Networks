package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class FileProcessorThread extends Thread {

    private BlockingQueue<Path> queue;

    public FileProcessorThread(BlockingQueue<Path> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {

        try {
            boolean finished = false;
            while(!finished) {
                Path p = this.queue.take();

                if (p.equals(Zad1Main.END_OF_SEARCH)) {
                    finished = true;

                    queue.put(Zad1Main.END_OF_SEARCH);
                }
                else{
                    handleFile(p);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void handleFile(Path p) {
//        System.out.println("Thread " + Thread.currentThread().getId());
//        System.out.println("File: " + p);

        if(isCfile(p)){
            String path = p.toString();
            File f = new File(path);
            try {
                URL url = f.toURI().toURL();
                System.out.println(url.getProtocol().toUpperCase() +":"+ Paths.get(path).toAbsolutePath());

                BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

                String line;
                while ((line = reader.readLine()) != null) {
                    Zad1Main.countLines();
                }
                reader.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isCfile(Path p) {
        String path = p.toString();
        if(path.substring(path.lastIndexOf('.') + 1).equalsIgnoreCase("c")){
            return true;
        }
        return false;
    }
}

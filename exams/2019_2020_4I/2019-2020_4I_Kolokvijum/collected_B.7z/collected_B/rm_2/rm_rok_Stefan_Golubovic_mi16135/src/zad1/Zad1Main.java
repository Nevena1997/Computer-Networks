package zad1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    private static int NUM_OF_THREADS = 10;
    public static int numOfFiles;
    public static Path END_OF_SEARCH = Paths.get("");
    private static int numOfLines;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        Path dir = Paths.get("/home/ispit/Desktop/tests");

        LinkedList<FileProcessorThread> listOfThreads = new LinkedList<>();
        BlockingQueue<Path> queue = new ArrayBlockingQueue<>(NUM_OF_THREADS);

        Thread tw = new Thread(new FileProcessorRunnable(queue, dir));
        tw.start();

        for(int i = 0; i < NUM_OF_THREADS ; i++) {
            FileProcessorThread fpt = new FileProcessorThread(queue);
            listOfThreads.add(fpt);
            fpt.start();
        }

        for(FileProcessorThread t : listOfThreads){
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("files: " + numOfFiles);
        System.out.println("Result: " + numOfLines);
    }

    public static synchronized void countLines() {
        numOfLines++;
    }


}

package zad1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {

    private  BlockingQueue<Path> queue;
    private Path dir;

    public FileProcessorRunnable(BlockingQueue<Path> queue, Path dir) {
        this.dir = dir;
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            this.walk(this.dir);

            queue.put(Zad1Main.END_OF_SEARCH);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void walk(Path dir) {

        try {
            DirectoryStream<Path> ds = Files.newDirectoryStream(dir);

            for(Path p : ds ) {
//                System.out.println(p);
                if(Files.isDirectory(p)){
                    walk(p);
                }
                else{
                    Zad1Main.numOfFiles = Zad1Main.numOfFiles + 1;
                    queue.put(p);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

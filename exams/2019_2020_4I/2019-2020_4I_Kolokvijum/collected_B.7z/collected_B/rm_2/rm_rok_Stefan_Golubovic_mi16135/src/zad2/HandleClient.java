package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class HandleClient extends Thread{

    private Socket client;
    private BufferedReader fromClient;
    private PrintWriter toClient;

    public HandleClient(Socket client) {
        this.client = client;
        try {
            fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
            toClient = new PrintWriter(new OutputStreamWriter(client.getOutputStream()),true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        try {
            String path = fromClient.readLine();
            String pathToPrint = path;
            Path absPath = Paths.get("/home/ispit/Desktop/tests/" + path);
            path = absPath.toString();
            if (Files.exists(absPath)){
                System.out.println(pathToPrint);
                toClient.println("valid");
            }
            else{
                toClient.println("not valid");
                return;
            }
            Scanner fileScanner = new Scanner(new File(path));

            double sum = 0;
            double tmp;
            String inputValue;
            while (fileScanner.hasNext()) {
                inputValue = fileScanner.next();
                try {
                    tmp = Double.parseDouble(inputValue);
                    sum += tmp;
                }
                catch (NumberFormatException e3){

                }
            }
            toClient.println(sum);


        } catch (IOException e) {
            toClient.println("not valid");
            System.err.println("There is no such file...");
        }
        catch (NullPointerException e1) {
            toClient.println("not valid");
            System.out.println("No such file...");
        }
        finally {
            try {
                client.close();
                toClient.close();
                fromClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

package zad2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost",31415);
            Scanner sc=new Scanner(System.in);
            Scanner in=new Scanner(new BufferedInputStream(socket.getInputStream()));
            PrintWriter out=new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
            while(true){
                System.out.println("Unesite putanju fajla");
                String ime=sc.nextLine();
                out.println(ime);
                out.flush();
                String s=in.nextLine();
                System.out.println(s);
                if(!s.equalsIgnoreCase("Nije validna putanja"))System.out.println(in.nextLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

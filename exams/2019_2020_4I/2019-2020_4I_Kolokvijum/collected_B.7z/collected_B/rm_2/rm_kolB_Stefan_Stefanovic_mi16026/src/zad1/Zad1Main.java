package zad1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    static File file;
    static int broj_fajlova=0;
    public static final BlockingQueue<Integer> a=new ArrayBlockingQueue<Integer>(10000);
    public static int broj_c_fajlova=0;
    public static void main(String[] args) {
        file=new File("../tests");
        citaj_dir(file);
        System.out.println(broj_fajlova);
        while(a.size()<broj_c_fajlova);
        int ukupno_linija=0;
        while(!a.isEmpty()){
            ukupno_linija+=a.remove();
        }
        System.out.println(ukupno_linija);
    }
    public static void citaj_dir(File dir){
        File[] content=dir.listFiles();
        for(int i=0;i<content.length;i++){
            if(content[i].isDirectory()){
                citaj_dir(content[i]);
            }
            else if(content[i].isFile()){
                broj_fajlova++;
                String ime=content[i].getName();
                if(ime.substring(ime.length()-2).equalsIgnoreCase(".c")){
                    try{
                        broj_c_fajlova++;
                        URL url=new URL("file://"+content[i].getAbsolutePath());
                        System.out.println("file://"+content[i].getAbsolutePath());
                        new FileProcessorThread(url).start();
                    }
                    catch (MalformedURLException e){
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}

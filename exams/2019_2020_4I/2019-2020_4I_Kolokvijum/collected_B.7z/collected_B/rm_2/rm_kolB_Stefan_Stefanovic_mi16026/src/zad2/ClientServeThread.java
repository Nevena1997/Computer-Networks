package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientServeThread extends Thread {
    public Socket socket;
    Scanner in;
    PrintWriter out;
    public ClientServeThread(Socket socket){
        this.socket=socket;
    }
    public void run(){
        try {
            in = new Scanner(new BufferedInputStream(socket.getInputStream()));
            out=new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
            radi();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void radi(){
        while(true){
            String s=in.next();
            System.out.println(s);
            Scanner sc;
            try{
                sc=new Scanner(new FileInputStream("../tests/"+s));
                out.println("Validna putanja");
                float suma=0,temp;
                boolean postoji=false;
                while(sc.hasNext()){
                    s=sc.next();
                    try{
                        temp=Float.parseFloat(s);
                    } catch (NumberFormatException e){
                        continue;
                    }
                    postoji=true;
                    suma+=temp;
                }
                if(postoji==false){
                    out.println("Fajl ne sadrzi realne brojeve");
                }
                else{
                    out.println(suma);
                }
            } catch(Exception e){
                out.println("Nije validna putanja");
            } finally {
                out.flush();
            }
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket server=new ServerSocket(31415);
            while(true){
                Socket client=server.accept();
                new ClientServeThread(client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Srecno od strane servera!");
    }
}

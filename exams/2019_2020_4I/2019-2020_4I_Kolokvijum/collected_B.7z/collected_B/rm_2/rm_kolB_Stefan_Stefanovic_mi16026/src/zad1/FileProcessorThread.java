package zad1;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {
    public URL url;
    public int lin=0;
    public FileProcessorThread(URL url){
        this.url=url;
    }
    @Override
    public void run() {
        try {
            BufferedReader in=new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII));
            String s;
            while((s=in.readLine())!=null){
                lin++;
            }
            in.close();
            synchronized (Zad1Main.a){
                Zad1Main.a.put(lin);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

public class Zad1Main {
    public static void main(String[] args) {

        System.out.println("Srecno!");
    }
}

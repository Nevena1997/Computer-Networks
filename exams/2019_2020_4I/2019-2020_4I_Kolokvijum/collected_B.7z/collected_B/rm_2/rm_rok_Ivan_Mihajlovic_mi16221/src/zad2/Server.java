package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");
        try(ServerSocket server = new ServerSocket(31415)) {
            System.out.println("Waiting for client...");
            while(true){
                Socket client = server.accept();
                System.out.println("Client accepted");
                Thread t = new Thread(new ServerRunnable(client));
                t.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

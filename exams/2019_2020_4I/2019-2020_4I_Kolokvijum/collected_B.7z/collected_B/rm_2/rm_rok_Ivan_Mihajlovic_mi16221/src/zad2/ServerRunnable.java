package zad2;

import java.io.*;
import java.net.Socket;

public class ServerRunnable implements Runnable {
    private Socket client;
    public double zbir = 0;
    public ServerRunnable(Socket client) {
        this.client = client;
    }

    @Override
    public void run(){
        try(BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

            String primljenaPutanjaFajla = in.readLine();
            System.out.println(primljenaPutanjaFajla);
            String putanjaFajla = "/home/ispit/Desktop/tests/" + primljenaPutanjaFajla.trim();
            File fajlic = new File(putanjaFajla);
            if (fajlic == null) {
                out.write("nevalidno");
                out.newLine();
                out.flush();
                return;
            }

            while(true) {

               BufferedReader prolaz_kroz_fajl = new BufferedReader(new InputStreamReader(new FileInputStream(putanjaFajla)));
               String line;

               while ((line = prolaz_kroz_fajl.readLine()) != null) {
                   String[] tokeni = line.split(" ");
                   for (String token : tokeni) {
                       if (token.trim().contains(".")) {
                           zbir += Double.parseDouble(token);

                       }

                   }

               }
                out.write(String.valueOf(zbir));
                out.newLine();
                out.flush();
           }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                this.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");
        try(Socket client = new Socket("localhost",31415);
            BufferedReader line_in= new BufferedReader(new InputStreamReader(System.in));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))) {

            String relativna_putanja = line_in.readLine();
            String line;
            out.write(relativna_putanja);
            out.newLine();
            out.flush();

            String konacno = in.readLine();
            if(!konacno.toLowerCase().equals("nevalidno"))
                System.out.println("Validna putanja");
            else {
                System.out.println("Nevalidna putanja");
                return;
            }

            double zbir = Double.parseDouble(konacno);
            if (zbir != 0)
                System.out.println(konacno);
            else
                System.out.println("Nema realnih brojeva u u fajlu");

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

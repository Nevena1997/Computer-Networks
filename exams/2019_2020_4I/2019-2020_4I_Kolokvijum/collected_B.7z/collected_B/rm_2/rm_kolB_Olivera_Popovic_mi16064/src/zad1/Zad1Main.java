package zad1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Zad1Main {
    private static int counter = 0;
    private static List<URL> urls = Collections.synchronizedList(new LinkedList<>());
    private int num_of_lines = 0;

    public static void main(String[] args) {
        Path dir = Paths.get(new File("tests").getAbsolutePath());

        walk(dir);
        System.out.println("files: " + counter);
        urls.forEach(System.out::println);

        Zad1Main z = new Zad1Main();
        FileProcessorThread[] threads = new FileProcessorThread[urls.size()];
        for (int i = 0; i < urls.size(); i++) {
            threads[i] = new FileProcessorThread(i, urls, z);
            threads[i].start();

            try {
                threads[i].join();
            } catch (InterruptedException e) {
                System.out.println("Nit prekinuta.");
            }
        }

        System.out.println(z.num_of_lines);
    }

    private static void walk(Path p) {
        if (Files.isDirectory(p)) {
            File[] files = p.toFile().listFiles();

            if (files != null)
                Arrays.stream(files).map(File::toPath).forEach(Zad1Main::walk);
        }
        else if (Files.isRegularFile(p)) {
                counter++;
        }

        String path = p.toString();
        String e = path.substring(path.lastIndexOf('.') + 1);
        if (e.equals("c")) {
            try {
                urls.add(new URL("FILE", "", p.toFile().getAbsolutePath()));
            } catch (MalformedURLException ex) {
                System.out.println("Greska.");
            }
        }
    }

    void addToCounter(int k) {
        num_of_lines += k;
    }
}

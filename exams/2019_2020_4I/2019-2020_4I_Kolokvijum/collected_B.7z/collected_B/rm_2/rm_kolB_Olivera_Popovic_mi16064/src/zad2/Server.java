package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    final static int PORT = 31415;

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(PORT)) {

            //noinspection InfiniteLoopStatement
            while (true) {
                Socket client = server.accept();

                new ClientThread(client).start();
            }

        } catch (IOException e) {
            System.out.println("Greska na serveru.");
        }
    }
}

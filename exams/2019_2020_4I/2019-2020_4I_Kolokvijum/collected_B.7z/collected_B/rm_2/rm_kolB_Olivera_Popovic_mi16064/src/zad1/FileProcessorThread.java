package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

public class FileProcessorThread extends Thread {
    private int index;
    private List<URL> urls;
    private final Zad1Main z;
    private int lineCounter = 0;

    FileProcessorThread(int index, List<URL> u, Zad1Main z) {
        this.index = index;
        this.urls = u;
        this.z = z;
    }

    @Override
    public void run() {
        try (Scanner in = new Scanner(
                            new BufferedReader(
                                new InputStreamReader(urls.get(index).openStream(), StandardCharsets.US_ASCII)))){

            while (in.hasNextLine()) {
                lineCounter++;
                in.nextLine();
            }

            synchronized (z) {
                z.addToCounter(lineCounter);
            }
        } catch (IOException e) {
            System.out.println("Greska pri otvaranju " + index + " fajla.");
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    private final static String add_to_path = new File("tests").getAbsolutePath();

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", Server.PORT)) {

            try (Scanner sc = new Scanner(System.in);
                 BufferedWriter out = new BufferedWriter(
                                        new OutputStreamWriter(socket.getOutputStream()));
                 BufferedReader in = new BufferedReader(
                                        new InputStreamReader(socket.getInputStream()))) {

                String relative_path = sc.next();

                out.write(add_to_path + "/" + relative_path);
                out.newLine();
                out.flush();

                String valid = in.readLine();
                if (valid.equalsIgnoreCase("false")) {
                    System.out.println("Putanja nije validna");
                    return;
                }
                else
                    System.out.println("Validna putanja");

                String zbir = in.readLine();
                String br = in.readLine();

                if (Integer.parseInt(br) == 0)
                    System.out.println("Fajl ne sadrzi realne brojeve");
                else
                    System.out.println(zbir);
            }

        } catch (UnknownHostException e) {
            System.out.println("Nepoznat server.");
        } catch (IOException e) {
            System.out.println("Greska na klijentu.");
        }

    }
}

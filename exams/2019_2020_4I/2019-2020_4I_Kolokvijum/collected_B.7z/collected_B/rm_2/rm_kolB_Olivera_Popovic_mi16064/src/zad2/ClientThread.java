package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientThread extends Thread {
    private Socket client;

    ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(
                                    new InputStreamReader(client.getInputStream()));
             BufferedWriter out = new BufferedWriter(
                                    new OutputStreamWriter(client.getOutputStream()))) {

            String rel_path = in.readLine();
            System.out.println(rel_path);

            if (rel_path == null)
                return;

            if (isValid(rel_path)) {
                out.write("true");
                out.newLine();
                out.flush();
            }
            else {
                out.write("false");
                out.newLine();
                out.flush();
                return;
            }

            try (Scanner sc = new Scanner(
                    new BufferedInputStream(new FileInputStream(rel_path)))) {

                float zbir = 0;
                int br = 0;
                String num;

                while (sc.hasNext()) {
                    num = sc.next().trim();

                    if (num.chars().allMatch(x -> Character.isDigit(x) || x == '.')) {
                        zbir += Float.parseFloat(num);
                        br++;
                    }
                }

                out.write(Float.toString(zbir));
                out.newLine();

                out.write(Integer.toString(br));
                out.newLine();
                out.flush();
            }

        } catch (IOException e) {
            System.out.println("Greska pri obradjivanju klijenta.");
        }
    }

    private static boolean isValid(String rel_path) {
        //noinspection EmptyTryBlock
        try (FileInputStream in = new FileInputStream(rel_path)) {

        } catch (IOException e) {
            return false;
        }

        return true;
    }
}

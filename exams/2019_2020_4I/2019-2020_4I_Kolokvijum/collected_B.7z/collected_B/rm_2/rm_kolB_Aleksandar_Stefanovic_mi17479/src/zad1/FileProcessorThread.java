package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {

    private final URL url;

    FileProcessorThread(URL url) {
        this.url = url;
    }

    @Override
    public void run() {
        try (var stream = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII))) {
            incrementLineNumber(stream.lines().count());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static long lineNumber = 0;

    private static synchronized void incrementLineNumber(long lines) {
        lineNumber += lines;
    }

    static long getLineNumber() {
        return lineNumber;
    }
}

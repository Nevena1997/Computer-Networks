package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws IOException {

            ServerSocket serverSocket = new ServerSocket(31415);

            //noinspection InfiniteLoopStatement
            while (true) {
                var clientSocket = serverSocket.accept();
                new WorkerThread(clientSocket).start();
            }
    }

    private static class WorkerThread extends Thread {

        private final Socket socket;

        private WorkerThread(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            super.run();

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

                var relativePath = reader.readLine();
                System.out.println(relativePath);

                var testPath = Paths.get(new URI("file:///home/ispit/Desktop/tests/"));

                var finalPath = testPath.resolve(relativePath);

                var file = finalPath.toFile();
                writer.write(file.exists() ? "Validna putanja" : "Nevalidna putanja");
                writer.write("\n");

                if (!file.exists()) {
                    return;
                }

                Scanner scanner = new Scanner(file);

                boolean foundAnyDouble = false;
                double sum = 0.0;
                while (scanner.hasNext()) {
                    var rawString = scanner.next();

                    try {
                        sum += Double.parseDouble(rawString);
                        foundAnyDouble = true;
                    } catch (Exception ignored) {}
                }

                writer.write(foundAnyDouble ? String.valueOf(sum) : "Fajl ne sadrzi realne brojeve");
                writer.flush();

            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }

        }
    }


}

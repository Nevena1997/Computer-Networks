package zad1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class Zad1Main {

    public static void main(String[] args) throws URISyntaxException, InterruptedException, MalformedURLException {

        var file = new File(new URI("file:///home/ispit/Desktop/tests/"));

        List<URL> urls = traverse(file);

        System.out.println("files:\t\t" + urls.size());

        List<URL> cURLs = urls.stream().filter(it -> it.toString().endsWith(".c")).collect(Collectors.toList());

        cURLs.forEach(url -> System.out.println("url:\t\t" + url));

        List<Thread> threads = cURLs.stream().map(FileProcessorThread::new).collect(Collectors.toList());
        threads.forEach(Thread::start);

        // Wait for all threads to finish work
        for (Thread waitedThread : threads) { // I wish I could use ::forEach, but ::join throws an Exception
            waitedThread.join();
        }

        System.out.println("result:\t\t" + FileProcessorThread.getLineNumber());
    }

    private static List<URL> traverse(File file) throws MalformedURLException {

        List<URL> result = new ArrayList<>();

        Queue<File> queue = new ArrayDeque<>();
        queue.add(file);

        while (!queue.isEmpty()) {
            var f = queue.poll();

            if (f != null) {
                if (f.isDirectory()) {
                    File[] files = f.listFiles();
                    if (files != null) {
                        queue.addAll(Arrays.asList(files));
                    }
                } else {
                    result.add(f.toURI().toURL());
                }
            }
        }

        return result;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", 31415);
             OutputStreamWriter writer = new OutputStreamWriter(new BufferedOutputStream(socket.getOutputStream()));
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            var scanner = new Scanner(System.in);

            var path = scanner.next();

            writer.write(path);
            writer.write("\n");
            writer.flush();

            System.out.println(reader.readLine());
            System.out.println(reader.readLine());


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

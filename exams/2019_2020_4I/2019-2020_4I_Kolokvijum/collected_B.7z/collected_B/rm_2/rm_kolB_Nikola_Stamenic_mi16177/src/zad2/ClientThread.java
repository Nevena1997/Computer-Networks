package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Paths;
import java.util.Scanner;

public class ClientThread extends Thread {

    private Socket socket;
    private String pathTest = "/home/ispit/Desktop/tests/";


    public ClientThread(Socket client) {
        this.socket = client;
    }

    public void run(){
        try{
            BufferedReader bufIn = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            PrintWriter bufOut = new PrintWriter(new BufferedOutputStream(this.socket.getOutputStream()), true);

            String path = bufIn.readLine();
            System.out.println(path);
            String fullPath = this.pathTest + path;
            //System.out.println(fullPath);
            try(BufferedReader fileIn = new BufferedReader(
                    new InputStreamReader(new FileInputStream(fullPath)))){
                bufOut.println("Validna putanja");
                bufOut.flush();

                boolean indicator = false;
                String in;
                Double sum = 0.0;

                while((in = fileIn.readLine()) != null){
                    String tokens[] = in.split(" ");

                    for(String token : tokens){
                        try{
                            Double tokVal = Double.parseDouble(token);
                            sum += tokVal;
                            if(!indicator)
                                indicator = true;
                        } catch (NumberFormatException e) {
                        }
                    }

                }

                if(indicator){
                    bufOut.println(sum);
                    bufOut.flush();
                }
                else{
                    bufOut.println("Fajl ne sadrzi realne brojeve");
                    bufOut.flush();
                }

            }catch (IOException e){
                bufOut.println("Nevalidna putanja");
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}



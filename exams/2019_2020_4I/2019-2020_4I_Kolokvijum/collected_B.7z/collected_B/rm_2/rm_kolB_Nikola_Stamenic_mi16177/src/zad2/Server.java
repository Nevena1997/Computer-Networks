package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static int PORT = 31415;


    public static void main(String[] args) {

        //System.out.println("Srecno od strane servera!");

        Server server = new Server(PORT);
        server.exec();
    }

    private int port;


    public Server(int port) {
        this.port = port;
    }


    private void exec() {
        try(ServerSocket socket = new ServerSocket(this.port)) {
            while(true){
                try{
                    Socket client = socket.accept();

                    ClientThread cThread = new ClientThread(client);
                    cThread.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

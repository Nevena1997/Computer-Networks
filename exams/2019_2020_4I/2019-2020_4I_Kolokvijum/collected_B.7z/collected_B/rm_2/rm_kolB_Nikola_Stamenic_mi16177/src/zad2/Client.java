package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

    public static void main(String[] args) {
        //System.out.println("Srecno od strane klijenta!");

        Client client = new Client("localhost", Server.PORT);
        client.execute();
    }

    private String host;
    private int port;

    public Client(String localhost, int port) {
        this.host = localhost;
        this.port = port;
    }

    private void execute() {
        try{
            Socket sock = new Socket(this.host, this.port);

            BufferedReader bufIn = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader sockIn = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            PrintWriter bufOut = new PrintWriter(new BufferedOutputStream(sock.getOutputStream()), true);

            String path = bufIn.readLine();

            bufOut.println(path);

            String validPath = sockIn.readLine();
            System.out.println(validPath);

            if (validPath.equalsIgnoreCase("Validna putanja")){
                String value = sockIn.readLine();
                System.out.println(value);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;

public class FileProcessorThread extends Thread {
    private URL url;

    public FileProcessorThread(Path t) {
        try {
            this.url = new URL("FILE://"+t.toString());
            System.out.println("url: " + url.getProtocol().toUpperCase() + "://" + url.getPath());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        int localSum = 0;
        URLConnection uc = null;
        try {
            uc = url.openConnection();

            BufferedReader bufIn = new BufferedReader(new InputStreamReader(uc.getInputStream()));

            String in;

            while((in = bufIn.readLine()) != null){
                localSum++;
            }

            Zad1Main.up(localSum);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

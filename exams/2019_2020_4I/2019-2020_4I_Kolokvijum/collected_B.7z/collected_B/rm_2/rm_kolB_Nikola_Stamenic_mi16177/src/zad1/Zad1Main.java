package zad1;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Zad1Main {
    public static void main(String[] args) {

        Path path = Paths.get("/home/ispit/Desktop/tests/");
        execute(path);
        //System.out.println("Srecno!");
    }

    private static int sum = 0;

    public static void execute(Path dir) {
        //sum = 0;

        try(Stream<Path> files = Files.walk(dir, Integer.MAX_VALUE)){
            System.out.println("Files: " + files.filter(Files::isRegularFile).count());
        } catch (IOException e) {
            e.printStackTrace();
        }

        try(Stream<Path> files = Files.walk(dir, Integer.MAX_VALUE)){
            List<FileProcessorThread> cFiles =
                    files.filter(Zad1Main::isC).map(t -> new FileProcessorThread(t)).collect(Collectors.toList());

            cFiles.forEach(t -> t.start());

            cFiles.forEach(t -> {
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("result: " + sum);
    }

    static boolean isC(Path path){
        String p = path.toString();

        int index = p.lastIndexOf(".");
        if(index < 0 || index >= p.length())
            return false;

        return p.substring(index).equalsIgnoreCase(".c");
    }

    synchronized public static void up(int upper){
        sum += upper;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        // System.out.println("Srecno od strane klijenta!");

        try (Socket sock = new Socket("localhost", 31415)) {
            Scanner userIn = new Scanner(System.in);
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(sock.getOutputStream())
            );
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(sock.getInputStream())
            );

            String route = userIn.next();
            out.write(route);
            out.newLine();
            out.flush();

            while (true) {
                String msg = in.readLine();
                if (msg == null)
                    break;
                System.out.println(msg);
            }

            in.close();
            out.close();
            userIn.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {
        // System.out.println("Srecno od strane servera!");

        try (ServerSocket server = new ServerSocket(31415)) {
            while (true) {
                Socket client = server.accept();
                // System.out.println("korisnik se uspesno povezao");

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(client.getInputStream())
                );
                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(client.getOutputStream())
                );

                String route = in.readLine();
                System.out.println(route);

                try (BufferedReader fileReader = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream("/home/ispit/Desktop/tests/" + route)
                        )
                )) {
                    out.write("Validna putanja");
                    out.newLine();
                    out.flush();

                    int flag = 0;
                    double suma = 0;
                    Scanner sc = new Scanner(fileReader);

                    while (sc.hasNext()) {
                        if (sc.hasNextDouble()) {
                            flag = 1;   // fajl moze da sadrzi npr samo `0.0`
                            double broj = sc.nextDouble();
                            suma += broj;
                        }
                        else {
                            sc.next();
                        }
                    }
                    sc.close();

                    if (flag == 0) {
                        out.write("Fajl ne sadrzi realne brojeve");
                        out.newLine();
                        out.flush();
                    }
                    else {
                        out.write("" + suma);
                        out.newLine();
                        out.flush();
                    }

                } catch (FileNotFoundException e) {

                    out.write("Nevalidna putanja");
                    out.newLine();
                    out.flush();

                    e.printStackTrace();
                } finally {
                    in.close();
                    out.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

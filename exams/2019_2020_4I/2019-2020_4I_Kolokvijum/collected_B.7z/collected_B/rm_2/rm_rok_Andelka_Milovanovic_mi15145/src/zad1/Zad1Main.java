package zad1;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {

    public static int NUM_OF_REGULAR = 0;
    public static int QUEUE_CAPACITY = 10;
    public static Integer NUM_OF_LINES = 0;

    public static void main(String[] args) {
        // Implementirati logiku u jednoj od FileProcessor klasa

        BlockingQueue<Path> files = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
        Path filePath = Paths.get("/home/ispit/Desktop/tests");
        walk(filePath, files);

        System.out.println("files:  " + NUM_OF_REGULAR);

        List<URL> urls = new ArrayList<URL>();
        List<Thread> threads = new ArrayList<Thread>();

        for (Path file : files){
            try {
                String fileProtocolPath = "FILE://" + file.toString();
                URL u = new URL(fileProtocolPath);
                urls.add(u);
                System.out.println("url:    " + fileProtocolPath);
                Thread t = new Thread(new FileProcessorRunnable(urls.get(urls.size()-1)));
                threads.add(t);
                t.start();

            } catch (MalformedURLException e) {
                e.printStackTrace();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // da sacekamo svi da izvrte, da bi se brojac uvecao
        for(Thread t : threads){
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("result: " + NUM_OF_LINES);
    }

    private static void walk(Path filePath, BlockingQueue<Path> files) {

        try (DirectoryStream<Path> ds = Files.newDirectoryStream(filePath)){
            for(Path p : ds) {
                if (Files.isDirectory(p)){
                    walk(p, files);
                }
                else {
                    if(Files.isRegularFile(p)){
                        NUM_OF_REGULAR += 1;
                    }
                    int indexOfLastDot = p.toString().lastIndexOf(".");
                    String extension = p.toString().substring(indexOfLastDot+1);
                    if(extension.equals("c")){
                        files.add(p);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

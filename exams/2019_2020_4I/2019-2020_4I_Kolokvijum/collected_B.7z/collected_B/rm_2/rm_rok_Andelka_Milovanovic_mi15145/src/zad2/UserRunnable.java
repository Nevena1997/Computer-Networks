package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;


// ovde moram zatvoriti socket i buffere
public class UserRunnable implements Runnable {

    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;

    public UserRunnable(Socket socket) throws IOException {
        this.socket = socket;
        this.in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));
        this.out = new BufferedWriter(
                new OutputStreamWriter(socket.getOutputStream()));
    }

    @Override
    public void run() {
        String line;
        String filePathString;
        Path filePath;
        try {
            if( (line = this.in.readLine()) != null){
                System.out.println(line);
                filePathString = "/home/ispit/Desktop/tests/" + line;
                filePath = Paths.get(filePathString);
                isValid(filePath);
                process(filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                this.in.close();
                this.out.close();
                System.out.println("Zatvaram soket...");
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void process(Path filePath) {
        try (Scanner sc = new Scanner(
                new BufferedReader(new FileReader(String.valueOf(filePath))))){
            float sum = 0;
            while(sc.hasNext()){
                float num;
                if ( sc.hasNextFloat()) {
                    sum += sc.nextFloat();
                }
                else {
                    sc.next();
                }
            }
//            System.out.println("Suma: " + sum);
            String sumString = "";
            if (sum == 0.0) {
                sumString += "Fajl ne sadrzi realne brojeve";
            }
            else {
                sumString += sum;
            }

            this.out.write(sumString);
            this.out.newLine();
            this.out.flush();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void isValid(Path filePath) {
        if(!Files.notExists(filePath)){
            String message = "Validna putanja";
            try {
                this.out.write(message);
                this.out.newLine();
                this.out.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

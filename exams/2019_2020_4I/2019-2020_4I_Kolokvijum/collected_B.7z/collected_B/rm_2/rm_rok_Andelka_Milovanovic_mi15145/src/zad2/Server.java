package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int DEFAULT_PORT = 31415;

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){
//            System.err.println("Server startovan na portu: " + DEFAULT_PORT);
            while (true) {
                Socket socket = server.accept();
//                System.err.println("Novi klijent se povezao...");
                new Thread(new UserRunnable(socket)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//        System.out.println("Srecno od strane servera!");
//        System.out.println("Hvala od strane Andje :)");
}

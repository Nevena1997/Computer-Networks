package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {

    private URL u;
    private BufferedReader reader;

    public FileProcessorRunnable(URL u) throws IOException {
        this.u = u;
        this.reader = new BufferedReader(new InputStreamReader(
                u.openStream(),
                StandardCharsets.US_ASCII));
    }

    @Override
    public void run() {
        processing();
    }

    private synchronized void processing() {

        //int ln = 0;
        try {
            while ((this.reader.readLine()) != null) {
                // u principu verovatno ne mora I OVO u synchronized blok, posto je ceo
                // processing synchronized metod, ali za svaki slucaj neka ide
                synchronized (Zad1Main.NUM_OF_LINES) {
                    Zad1Main.NUM_OF_LINES += 1;
                    //ln++;
                }
            }
            this.reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.println("Linije : " + ln + " u " + Thread.currentThread().getName());
    }
}

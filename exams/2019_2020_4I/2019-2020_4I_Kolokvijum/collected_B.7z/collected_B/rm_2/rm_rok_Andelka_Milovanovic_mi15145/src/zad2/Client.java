package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", Server.DEFAULT_PORT);
             BufferedWriter writer = new BufferedWriter(
                     new OutputStreamWriter(client.getOutputStream()));
             Scanner sc = new Scanner(System.in);
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(client.getInputStream()));
             ) {

//            System.err.println("Klijent se nakacio na server na portu: " + Server.DEFAULT_PORT);
            String putanja = sc.nextLine();
            writer.write(putanja);
            writer.newLine();
            writer.flush();

            String isValid;
            if( (isValid = reader.readLine()) != null){
                System.out.println(isValid);
            }

            String sum;
            if( (sum = reader.readLine()) != null) {
                System.out.print(sum);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

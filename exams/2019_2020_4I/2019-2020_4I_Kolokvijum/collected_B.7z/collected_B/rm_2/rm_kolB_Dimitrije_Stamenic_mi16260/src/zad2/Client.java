package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        String host = "localhost";
        int port = 31415;

        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite putanju do fajla: ");
        String putanja = sc.nextLine();

        try (Socket s = new Socket(host, port)) {

            try (BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(s.getOutputStream())
                );
                 Scanner in = new Scanner(
                    new BufferedReader(
                            new InputStreamReader(s.getInputStream())
                    )
            )
            ){
                // slanje primljene putanje serveru
                  out.write(putanja);
                  out.newLine();
                  out.flush();

                // prijem poruke od servera
                while (in.hasNextLine()){
                    System.out.println(in.nextLine());
                }

            } catch (IOException e ) {
                e.printStackTrace();
            }

        } catch (IOException e) {

            e.printStackTrace();
        }

        }
}

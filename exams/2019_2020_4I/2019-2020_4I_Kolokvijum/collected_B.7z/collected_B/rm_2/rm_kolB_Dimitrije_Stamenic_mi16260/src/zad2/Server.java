package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {

        int port = 31415;

        try(ServerSocket server = new ServerSocket(port)) {

            while (true) {
                Socket client = server.accept();
//                System.out.println("Client accepted");

                try (Scanner in = new Scanner(
                        new BufferedReader(
                                new InputStreamReader(client.getInputStream())
                        )
                    );
                     BufferedWriter out = new BufferedWriter(
                             new OutputStreamWriter(client.getOutputStream())
                     )
                ) {

                    String homeDir = "/home/ispit/Desktop/tests/";
                    String putanja =  homeDir + in.nextLine().trim();
                    System.out.println(putanja);

                    try (Scanner sc = new Scanner(new FileInputStream(putanja))) {

                        // obrada dobijenog fajla
                        out.write("Validna putanja");
                        out.newLine();

                        double zbir = 0.0;
                        String z = "";
                        while (sc.hasNext()){
                            if (sc.hasNextDouble()) {
                                double tmp = sc.nextDouble();
                                zbir += tmp;
                            } else {
                                sc.next();
                            }
                        }
                        if (zbir == 0.0)
                            out.write("Fajl ne sadrzi realne brojeve");
                        else
                            z += zbir;
                            out.write(z);

                    } catch (FileNotFoundException fnf) {
                            out.write("Nevalidna putanja");
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

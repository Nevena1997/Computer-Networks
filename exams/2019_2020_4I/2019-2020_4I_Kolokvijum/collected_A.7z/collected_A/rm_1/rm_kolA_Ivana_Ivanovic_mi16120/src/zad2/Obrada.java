package zad2;

import java.io.*;
import java.net.Socket;

public class Obrada implements Runnable {
    Socket k;

    public Obrada(Socket k) {
        this.k=k;
    }

    @Override
    public void run() {
        try ( BufferedReader in=new BufferedReader(new InputStreamReader(this.k.getInputStream()));
        ){
            String putanja=in.readLine();
            double x=Double.parseDouble(in.readLine());
            double eps=Double.parseDouble(in.readLine());
            BufferedReader inn;
            BufferedWriter out = null;
            try{
                inn=new BufferedReader(new InputStreamReader(new FileInputStream(putanja)));
                out=new BufferedWriter(new OutputStreamWriter(k.getOutputStream()));
                String l;
                out.write("da");
                out.newLine();
                out.flush();
                int brojac=0;
                while((l=inn.readLine())!=null){
                    String[] reci=l.split(" ");

                    for (int i=0;i<reci.length;i++){
                        if(reci[i].chars().anyMatch(c->Character.isAlphabetic(c)))
                            continue;
                        double br=Double.parseDouble(reci[i]);
                        if(br>=(x-eps) && br<=x+eps)
                            brojac++;
                    }

                }
                String rec=String.valueOf(brojac);
                out.write(rec);
                out.newLine();
                out.flush();
                System.out.println(putanja);

            }catch (FileNotFoundException e){
                out=new BufferedWriter(new OutputStreamWriter(k.getOutputStream()));
                out.write("ne");
                out.newLine();
                out.flush();

            }
            finally {
                in.close();
                out.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {
    String path;
    char a;
    int brojac;
    public FileProcessorRunnable(String l,String a) {
        this.path=l;
        this.a=a.charAt(0);
    }

    @Override
    public void run() {
        //while (true) {
            prebroj(this.brojac);
        //}
    }
    public synchronized void prebroj(int brojac){
        BufferedReader in;
        try {
            URL u=new URL(this.path);
            in=new BufferedReader(new InputStreamReader(u.openStream(), StandardCharsets.UTF_8));
            String l;
            while ((l=in.readLine())!=null){
                char[] slova=l.toCharArray();
                for (int i=0;i<slova.length;i++){
                    if(slova[i]==this.a)
                        this.brojac++;
                }

            }
            System.out.println(brojac);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Fajl ne postoji!");

        }
    }
}

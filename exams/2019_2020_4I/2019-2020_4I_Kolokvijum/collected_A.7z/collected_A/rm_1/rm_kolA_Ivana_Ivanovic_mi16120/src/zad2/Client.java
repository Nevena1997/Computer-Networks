package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (Socket s=new Socket("localhost",Server.port);
             BufferedWriter out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
             BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream()));
             ){

            Scanner sc=new Scanner(System.in);
            String putanja=sc.next();
            String x=sc.next();

            String eps=sc.next();
            sc.close();
            out.write(putanja);
            out.newLine();
            out.flush();
            out.write((x));
            out.newLine();
            out.flush();
            out.write(eps);
            out.newLine();
            out.flush();

            String ind=in.readLine();
            if(ind.equalsIgnoreCase("da")){
                System.out.println("Validna putanja");
                int br=Integer.parseInt(in.readLine());
                if(br==0)
                    System.out.println("Fajl ne sadrzi realne brojeve");
                else
                    System.out.println(br);
            }
            else
                System.out.println("Nije validna putanja");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

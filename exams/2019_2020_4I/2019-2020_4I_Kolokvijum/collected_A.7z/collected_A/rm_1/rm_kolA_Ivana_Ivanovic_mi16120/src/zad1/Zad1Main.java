package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        BufferedReader in= null;
        try {
            in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")));
            String l;
            int br=0;
            Scanner sc=new Scanner(System.in);
            String a=sc.next();

            while((l=in.readLine())!=null){

                try {
                    URL u=new URL(l);
                    br++;
                    if (l.contains(".") && (l.substring(0,4).equals("file") || l.substring(0,4).equals("file")) &&
                            l.substring(l.lastIndexOf("."),l.length()).equals(".txt"))
                        {
                            new Thread(new FileProcessorRunnable(l,a)).start();
                        }

                }catch (MalformedURLException e){
                    continue;
                }

            }
            System.out.println(br);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

public class Zad1Main {
    public static void main(String[] args) {
    // Implementirati logiku u jednoj od FileProcessor klasa

    try {
        Scanner input = new Scanner(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"));
        Scanner sc = new Scanner(System.in);
        char character = sc.next().toCharArray()[0];
        sc.close();

        List<Integer> list = Collections.synchronizedList(new LinkedList<>());
        int ln;
        String fileNotFound = "";

        for(ln=0;input.hasNextLine();ln++){
            String line = input.nextLine();
            try {
                URL u = new URL(line);
                if(u.getProtocol().equalsIgnoreCase("file") && u.getPath().substring(u.getPath().lastIndexOf('.')+1).equals("txt")){
                    new Thread(new FileProcessorRunnable(u,character,list)).start();
                }
            } catch(MalformedURLException e){
                continue;
            } catch (IOException e) {
                fileNotFound = line;
                continue;
            }
        }
        System.out.println("lines:" + ln);
        System.out.println("not found: " + fileNotFound);

        int result = 0;
        for(int el: list){
            result += el;
        }
        System.out.println("result: " + result);

    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }


        //System.out.println("Srecno!");
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    static final int SERVER_PORT = 27182;

    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");
        Server server = new Server(SERVER_PORT);
        server.execute();
    }

    private int port;
    Server(int port){
        this.port = port;
    }

    void execute() {
        try {
            ServerSocket server = new ServerSocket(this.port);
            while(true){
                Socket client = server.accept();
                //System.out.println("Klijent povezan");
                new Thread(new UserThread(client)).start(); //obrada svakog klijenta
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

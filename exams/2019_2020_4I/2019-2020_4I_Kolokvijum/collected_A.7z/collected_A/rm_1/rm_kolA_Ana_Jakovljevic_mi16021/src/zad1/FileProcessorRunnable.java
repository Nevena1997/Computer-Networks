package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorRunnable implements Runnable {
    private char character;
    private int globalCount;
    private BufferedReader in;
    private List<Integer> list;

    FileProcessorRunnable(URL u,char c, List<Integer> list) throws IOException {
        this.character = c;
        this.globalCount = globalCount;
        this.in = new BufferedReader(new InputStreamReader(u.openStream(), StandardCharsets.UTF_8));
        this.list = list;
    }

    @Override
    public void run() {
        try {
            String line;
            int count = 0;

            while(true) {
                if ((line = in.readLine()) == null){
                    break;
                }
                count += line.chars()
                            .filter(c -> Character.toLowerCase(c) == Character.toLowerCase(this.character))
                            .count();
            }

            synchronized (this.list){
                this.list.add(count);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

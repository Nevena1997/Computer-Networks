package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class UserThread implements Runnable {

    private Socket user;
    UserThread(Socket user){
        this.user = user;
    }

    @Override
    public void run() {
        try {
            //BufferedReader in = new BufferedReader(
                    //new InputStreamReader(user.getInputStream());
               Scanner in = new Scanner(user.getInputStream());

               Path path = Paths.get(" ");
               float x;
               float eps;

               // System.out.println("prima se");
               path = Paths.get(in.next());
               x = in.nextFloat();
               eps = in.nextFloat();
               in.close();

               BufferedOutputStream out = new BufferedOutputStream((user.getOutputStream()));
               PrintWriter pw = new PrintWriter(new BufferedOutputStream(out), true);

               int count = 0;
               Scanner file = new Scanner(path);
               while (file.hasNextFloat()) {
                   float num = file.nextFloat();
                   if (num < x + eps && num < x - eps)
                       count++;
               }

               pw.printf("%f", count);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

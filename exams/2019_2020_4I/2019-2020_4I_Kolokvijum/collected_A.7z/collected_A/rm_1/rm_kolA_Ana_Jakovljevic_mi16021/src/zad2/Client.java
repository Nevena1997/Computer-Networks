package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.Buffer;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");

        Client user = new Client("localhost", Server.SERVER_PORT);
        user.execute();
    }

    private String hostname;
    private int port;

    Client(String hostname, int port){
        this.hostname = hostname;
        this.port = port;
    }

    void execute(){
        try {
            Socket client = new Socket(this.hostname, this.port);
            Scanner sc = new Scanner(System.in);

            BufferedOutputStream out = new BufferedOutputStream((client.getOutputStream()));
            PrintWriter pw = new PrintWriter(new BufferedOutputStream(out),true);

            String filepath = sc.next();
            float x = sc.nextFloat();
            float eps = sc.nextFloat();
            pw.printf("%s%f%f", "/home/ispit/Desktop/tests" + filepath, x ,eps);

            //Scanner in = new Scanner(client.getInputStream());
            //System.out.println(in.next());
            //System.out.println(in.next());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        System.err.println("Srecno od strane klijenta!");
        System.err.println("Hvala od strane klijenta!");

        String hostname = "localhost";

        try(Socket s = new Socket(hostname, Server.PORT)){
            System.err.println("Klijent se konektovao na server");

            Scanner sc = new Scanner(System.in);
            String putanja = sc.nextLine();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();
            sc.close();

            PrintWriter toServer = new PrintWriter(s.getOutputStream(), true);
                toServer.println(putanja + " " + x + " " + eps);


            BufferedReader fromServer = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line = fromServer.readLine();
            System.out.println(line);
            String line2 = fromServer.readLine();

            System.out.println(line2);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

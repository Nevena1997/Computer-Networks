package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ClientThreadRunnable implements Runnable {

    private Socket sock;

    public ClientThreadRunnable(Socket client) {
        this.sock = client;
    }

    @Override
    public void run() {
        try(BufferedReader fromClient = new BufferedReader(new InputStreamReader(this.sock.getInputStream()))){

            String line = fromClient.readLine();
            System.out.println(line);
            String[] words = line.split(" ");
            String fajl = words[0];
            Double x = Double.parseDouble(words[1]);
            Double eps = Double.parseDouble(words[2]);

            System.out.println(fajl);
            try(BufferedWriter toClient = new BufferedWriter(new OutputStreamWriter(this.sock.getOutputStream()))) {

                if (Files.exists(Paths.get(fajl))) {
                    toClient.write("Validna putanja");
                    toClient.newLine();
                    toClient.flush();
                } else {
                    toClient.write("Nevalidna putanja");
                    toClient.newLine();
                    toClient.flush();
                }
                int count = 0;
                try (BufferedReader fromFile = new BufferedReader(new InputStreamReader(new FileInputStream(fajl)))) {
                    String line2;
                    while ((line2 = fromFile.readLine()) != null) {
                        String[] nums = line2.split("\\s");
                        for (String n : nums) {
                            if (n.matches("[0-9]+\\.[0-9]+")) {
                                Double number = Double.parseDouble(n);
                                if (number > (x - eps) && number < (x + eps)) {
                                    count += 1;
                                }
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (count == 0) {
                    toClient.write("Fajl ne sadrzi realne brojeve");
                    toClient.newLine();
                    toClient.flush();
                } else {
                    toClient.write("" + count);
                    toClient.newLine();
                    toClient.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }




        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

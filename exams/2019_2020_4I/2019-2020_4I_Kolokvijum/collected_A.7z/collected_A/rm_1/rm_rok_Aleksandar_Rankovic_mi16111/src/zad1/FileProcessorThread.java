package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class FileProcessorThread extends Thread {

    private URL u;
    private String target;
    public int count;

    FileProcessorThread(URL u, String target){
        this.u = u;
        this.target = target;
    }
    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.u.openStream()))){
            String line;
            while((line = in.readLine()) != null){
                String[] chars = line.split("");
                for(String c : chars){
                    if(c.equals(target)){
                        count++;
                    }
                }
            }


        } catch (IOException e) {
            System.out.println("file was sadly not found");
        }
    }

    public int getCount() {
        return count;
    }
}

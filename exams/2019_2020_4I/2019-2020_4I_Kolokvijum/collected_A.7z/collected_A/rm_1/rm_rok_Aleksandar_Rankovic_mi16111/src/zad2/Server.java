package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int PORT = 27182;
    public static void main(String[] args) {

        System.err.println("Srecno od strane servera!");
        System.err.println("hvala od strane servera!");

        try(ServerSocket s = new ServerSocket(PORT)){

            while(true){
                Socket client = s.accept();

                new Thread(new ClientThreadRunnable(client)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

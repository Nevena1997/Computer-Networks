package zad1;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        System.err.println("Srecno!");
        System.err.println("hvala!");
        System.err.println();

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))){

            Scanner sc = new Scanner(System.in);
            System.out.print("ulaz: ");
            String target = sc.next();
            sc.close();

            Integer sum = 0;

            List<FileProcessorThread> lista = new ArrayList<>();

            String line;
            int numOfLines = 0;
            while((line = in.readLine()) != null){
                numOfLines += 1;
                if(line.matches("[a-z]+://.*")){
                    if(line.contains("ssh"))
                        continue;

                    URL u = new URL(line);

                    if(u.getProtocol().equals("file")) {

                        String[] words = line.split("/");
                        int n = words.length;
                        if (words[n - 1].matches("[a-zA-Z0-9]+\\.txt")) {
                            FileProcessorThread t = new FileProcessorThread(u, target);
                            t.start();
                            lista.add(t);
                        }
                    }
                }
            }
            for(FileProcessorThread t : lista){
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            for(FileProcessorThread t : lista){
                sum += t.getCount();
            }
            System.out.println("lines: " + numOfLines);
            System.out.println("result: " + sum);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

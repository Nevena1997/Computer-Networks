package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static int result = 0;
    public  boolean b = false;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        //System.out.println("Srecno!");
        Scanner sc = new Scanner(System.in);
        System.out.println("Unesitre karakter: ");
        char a = sc.next().charAt(0);

        try(BufferedReader bin = new BufferedReader(new InputStreamReader(
                new FileInputStream("/home/ispit/Desktop/tests/urls.txt"),
                StandardCharsets.UTF_8)))
        {
            String url;
            String[] urls = new String[512];
            int i = 0;
            int j = 0;
            URL[] urls1 = new URL[512];
            while((url = bin.readLine()) != null){
                urls[i] = url;
                i++;

                URL url1 = null;
                try {
                    url1 = new URL(url);
                } catch (MalformedURLException e) {
                    continue;
                }
                urls1[j] = url1;
                j++;
            }

            System.out.println("lines:\t" +  i);

            for(URL u: urls1){
                try {
                    String protocol = u.getProtocol();
                    if(protocol.equals("file")){
                        String path = u.getPath();
                        path = path.substring(path.lastIndexOf('/') + 1);
                        String ext = path.substring(path.lastIndexOf('.' ));
                        if(ext.equals(".txt")) {
                            try {
                                new Thread(new FileProcessorRunnable(u.getPath(), a)).start();
                            }catch (Exception e) {
                                System.out.println("not found: " + u.getPath());
                            }
                        }
                    }
                }catch (Exception e){
                    continue;
                }
            }

            System.out.println("resut: " + result);
            bin.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

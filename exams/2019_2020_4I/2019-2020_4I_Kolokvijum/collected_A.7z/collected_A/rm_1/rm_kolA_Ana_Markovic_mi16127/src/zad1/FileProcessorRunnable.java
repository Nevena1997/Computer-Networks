package zad1;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {
    private BufferedReader file;
    private char a;


    public FileProcessorRunnable(String path, char a) throws Exception {
        try {
            this.file = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(
                                    path),
                            StandardCharsets.UTF_8)
            );
            this.a = a;
        } catch (FileNotFoundException e) {
            Thread.yield();
            throw new Exception("Fajl ne postoji");
        }
    }

    @Override
    public void run() {
        countResult();
    }

    private synchronized void countResult() {
        String line;
        try {
            while((line = file.readLine()) != null){
                for (int i=0; i< line.length(); i++){
                    if(line.charAt(i) == a){
                            try {
                                this.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            Zad1Main.result++;
                            System.out.println(Zad1Main.result);
                            this.notifyAll();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

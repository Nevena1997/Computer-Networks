package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args)
    {
        //System.out.println("Srecno od strane klijenta!");
        String hostname = "localhost";
        try {
            Socket client = new Socket(hostname, Server.PORT);

            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedReader inS = new BufferedReader(new InputStreamReader(System.in));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

            String path = inS.readLine();
            out.write(path.trim() + " ");
            double x = Double.parseDouble(inS.readLine().trim());
            out.write(String.valueOf(x) + " ");
            double eps = Double.parseDouble(inS.readLine().trim());
            out.write(String.valueOf(eps) + " ");
            out.flush();

            String valid = in.readLine();
            String res = in.readLine();
            res = res.trim();
            int result = Integer.parseInt(res);
            System.out.println(valid.trim());
            if(result == 0)
                System.out.println("Fajl ne sadrzi realne brojeve.");
            else
                System.out.println(result);

            out.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

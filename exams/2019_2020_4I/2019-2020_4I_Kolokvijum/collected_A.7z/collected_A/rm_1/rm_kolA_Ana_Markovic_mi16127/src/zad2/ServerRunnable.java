package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ServerRunnable implements Runnable {
    private Socket s;

    public ServerRunnable(Socket client) {
        this.s = client;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            Scanner sc = new Scanner(in);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));

            String path = sc.next();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();

            double xl = x - eps;
            double xd = x + eps;

            BufferedReader file = null;
            try {
                file = new BufferedReader(new InputStreamReader(s.getInputStream()));
            } catch (IOException e) {
                out.write("Nije validan");
                out.write("\n");
                out.write('0');
            }
            Scanner sc1 = new Scanner(file);
            String word;
            int res = 0;
            while ((word = sc1.next()) != null){
                if(word.chars().allMatch(Character::isDigit)){
                    double num = Double.parseDouble(word);
                    if(num < xd && num > xl)
                        res++;
                }
            }
            out.write("Validna putanja");
            out.write("\n");
            out.write(res);

            out.flush();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

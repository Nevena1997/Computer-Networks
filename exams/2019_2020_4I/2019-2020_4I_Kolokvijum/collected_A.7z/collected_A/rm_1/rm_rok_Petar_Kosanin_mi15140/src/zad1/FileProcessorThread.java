package zad1;

import javax.sound.midi.SysexMessage;
import javax.swing.plaf.synth.SynthTextAreaUI;
import java.io.*;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorThread extends Thread {

    private URL url;
    private Lock lock;
    private char c;
    private Condition cond;

    FileProcessorThread(URL url, char c)
    {
        this.url = url;
        this.c = c;
    }

    private int countOccurences(char[] buffer)
    {
        int occs = 0;
        for(char c : buffer)
        {
            if (this.c == c)
                occs++;
        }

        return occs;
    }

    @Override
    public void run() {

        this.lock = new ReentrantLock();
        cond = lock.newCondition();
        this.lock.lock();

        char[] buffer = new char[512];
        int bytesRead = 0;

        try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {

            int totalOccs = 0;
            while ((bytesRead = in.read(buffer, 0, 512)) != -1) {
                totalOccs += countOccurences(buffer);
            }
            System.out.println("result: " + totalOccs + " " + url.getPath());

            //lock.notifyAll();

        } catch (IOException e) {
            System.out.println("FILE NOT FOUND " + url.getPath());
            //e.printStackTrace();
        } finally {
            this.lock.unlock();
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.*;


public class Zad1Main {
    public static void main(String[] args) {


        // Implementirati logiku u jednoj od FileProcessor klasa
        // TODO prebaciti u blockingque
        ArrayList<URL> urls = new ArrayList<>();
        int numLines = 0;

        Scanner userInput = new Scanner(System.in);
        System.out.println("Unesite Karakter");
        //char c = (char) userInput.nextInt();
        char c = 'a';
        userInput.close();

        try (BufferedReader in = new BufferedReader(new FileReader("/home/ispit/Desktop/tests/urls.txt")))
        {
            String currLine = null;
            while((currLine = in.readLine()) != null)
            {
                try {
                    URI uri = new URI(currLine);
                    if (uri.isAbsolute()) {
                        try {
                            URL url = uri.toURL();
                            urls.add(url);
                        } catch (MalformedURLException e) {
                            System.out.println("BAD PROTOCOL");
                        }
                    }
                } catch (URISyntaxException e) {
                    System.out.println("BAD FORMAT");
                    //e.printStackTrace();
                }
                numLines++;
            }

            System.out.println("lines " + numLines);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        for(URL url : urls)
        {
            if (url.getProtocol().equals("FILE") &&
                url.getPath().endsWith(".txt"))
            {
                Thread t = new FileProcessorThread(url, c);
                t.start();

            }

        }
    }
}

package zad2;

import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    static String host = "localhost";
    public static void main(String[] args) {
        try (Socket socket = new Socket(host, Server.DEFAULT_PORT);
             BufferedReader netInput = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()
                     )
             );
             PrintWriter netOutput = new PrintWriter(
                     new OutputStreamWriter(
                             socket.getOutputStream()
                     )
             )) {

            netOutput.println("dir2/1.test 3.5 0.01");
            netOutput.println();
            netOutput.flush();

            String response = netInput.readLine();
            System.out.println(response);

            response = netInput.readLine();
            System.out.println(response);


        }catch (ConnectException e){
            e.printStackTrace();
        }catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        int numOfLines = 0;
        char controlChar;
        int result = 0;


        try (BufferedReader initInput = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream("/home/ispit/Desktop/tests/urls.txt")
                )
        );
             Scanner sc = new Scanner(System.in)) {
            System.out.print("ulaz: ");
            controlChar = sc.next().trim().charAt(0);

            String tmpLine;
            while ((tmpLine = initInput.readLine()) != null) {
                numOfLines++;
                try {


                    URL tmpUrl = new URL(tmpLine);
                    boolean isFileProtocol = tmpUrl.getProtocol().equalsIgnoreCase("file");
                    boolean isTxtFile = tmpUrl.getFile().substring(tmpUrl.getFile().lastIndexOf('.') + 1).equalsIgnoreCase("txt");
                    if (isFileProtocol && isTxtFile) {
                        FileProcessorRunnable fp = new FileProcessorRunnable(tmpUrl, controlChar);
                        new Thread(fp).start();
                        result = fp.result();


                    }
                } catch (MalformedURLException ex) {
                    continue;
                }

            }

            System.out.println("lines: " + numOfLines);
            System.out.println("result: " + result);


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

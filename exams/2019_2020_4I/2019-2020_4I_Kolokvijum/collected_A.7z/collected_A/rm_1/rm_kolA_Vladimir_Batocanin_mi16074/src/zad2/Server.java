package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.InvalidPathException;

public class Server {
    static int DEFAULT_PORT = 7182;

    public static void main(String[] args) {


        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)) {
            while (true) {
                Socket socket = server.accept();
                BufferedReader netInput = new BufferedReader(
                        new InputStreamReader(
                                socket.getInputStream()
                        )
                );
                PrintWriter netOutput = new PrintWriter(
                        new OutputStreamWriter(
                                socket.getOutputStream()
                        )
                );
                String clientInput = netInput.readLine().trim();

                String fileBase = "/home/ispit/Desktop/tests/";
                String clientPath = clientInput.substring(0, clientInput.indexOf(" "));
                double x = Double.parseDouble(clientInput.substring(clientInput.indexOf(" ") + 1, clientInput.lastIndexOf(" ")));
                double eps = Double.parseDouble(clientInput.substring(clientInput.lastIndexOf(" ") + 1));
               try{
                   File fileTest = new File(fileBase.concat(clientPath));
                   netOutput.write("Validna putanja");
                   netOutput.write("\n");

               }catch(InvalidPathException e){
                   netOutput.write("Nije validna putanja");
                   netOutput.write("\n");

               }
                netOutput.flush();
                System.out.println(clientPath);

                new Thread(new ClientHandler(socket,fileBase.concat(clientPath),x,eps)).start();
            }

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

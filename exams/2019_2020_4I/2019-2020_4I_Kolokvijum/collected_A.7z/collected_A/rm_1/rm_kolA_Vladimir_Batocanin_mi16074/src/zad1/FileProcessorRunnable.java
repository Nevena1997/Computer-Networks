package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class FileProcessorRunnable implements Runnable {

    private URL url;
    private char c;
    private static int brojac = 0;
    private Lock lck = new ReentrantLock();

    public FileProcessorRunnable(URL url, char c) {
        this.url = url;
        this.c = c;
    }

    @Override
    public void run() {
        try (BufferedReader input = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(url.getFile()), StandardCharsets.UTF_8
                )
        )) {
            String tmpLine;
            while ((tmpLine = input.readLine()) != null) {
                //System.out.println(tmpLine);
                int tmpNum = tmpLine.chars().filter(c -> c == this.c).toArray().length;
                lck.lock();
                brojac += tmpNum;
                lck.unlock();
            }

        } catch (FileNotFoundException e) {
            System.err.println("not found: " + url.getFile());
            return;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public int result() {
        return brojac;
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientHandler implements Runnable {

    private Socket socket;
    private String path;
    private double x;
    private double eps;
    private PrintWriter output;
    private BufferedReader input;

    public ClientHandler(Socket socket, String path,double x, double eps) throws IOException {
        this.socket = socket;
        this.path = path;
        this.x = x;
        this.eps = eps;

        this.input = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(path)
                )
        );
        this.output = new PrintWriter(
                new OutputStreamWriter(
                        socket.getOutputStream()
                )
        );


    }


    @Override
    public void run() {
        //TODO CLOSE SOCKET TY
        try {
            int totalnum=0;
            String line;
            while ((line = this.input.readLine()) != null) {
                if(line.chars().filter(Character::isDigit).toArray().length==0){
                    continue;
                }
                int index=0;
                String tmpLine;
                while(index<line.length()) {
                    tmpLine = line.substring(index);
                    totalnum += processNextDouble(tmpLine);
                }

            }
            this.output.println(totalnum);
            this.output.println();
            this.output.flush();
            if(totalnum==0){
                this.output.println("Fajl ne sadrzi realne brojeve");
                this.output.println();
                this.output.flush();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }


        try {
            this.socket.close();
            this.input.close();
            this.output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int processNextDouble(String line) {
        Pattern p = Pattern.compile("[1234567890]*.[1234567890]*");
        Matcher m = p.matcher(line);
        int tmpCounter=0;
        while(m.find())
        {
            double tmpDouble;
            tmpDouble = Double.parseDouble(m.group());
            if(tmpDouble>this.x-this.eps ||tmpDouble<this.x+this.eps){
                tmpCounter++;
            }
        }
        return tmpCounter;
    }
}

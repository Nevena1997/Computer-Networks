package zad2;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    private static BufferedReader fromServer;
    private static BufferedWriter toServer;
    private static Scanner sc;

    public static void main(String[] args) {

        try {
            Socket socket = new Socket("localhost", 31415);

            toServer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            sc = new Scanner(System.in);
            String path = sc.next();

            toServer.write(path);
            toServer.newLine();
            toServer.flush();

            String serverMsg = fromServer.readLine();
            System.out.println(serverMsg);
            if(serverMsg.equals("Validna putanja")) {
                String sum = fromServer.readLine();
                System.out.println(sum);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(toServer != null) {
                try {
                    toServer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(fromServer != null) {
                try {
                    fromServer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(sc != null) {
                sc.close();
            }
        }

    }
}

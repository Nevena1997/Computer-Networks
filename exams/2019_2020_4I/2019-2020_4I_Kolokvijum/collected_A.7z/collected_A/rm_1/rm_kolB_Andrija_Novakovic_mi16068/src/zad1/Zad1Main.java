package zad1;

import javax.naming.spi.DirectoryManager;
import javax.xml.xpath.XPath;
import java.io.IOException;
import java.net.URL;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class Zad1Main {

    private int cnt;
    private List<URL> urls;

    private Zad1Main() {
        this.cnt = 0;
        urls = new LinkedList<>();
    }

    public int getCnt() {
        return cnt;
    }

    public void walk(String path) throws IOException {
        for(Path tmpFile : Files.newDirectoryStream(Paths.get(path))) {
            if(Files.isRegularFile(tmpFile)) {
               cnt++;
               int index = tmpFile.toString().lastIndexOf('.');
               String ext = tmpFile.toString().substring(index+1);
               if(ext.equals("c")) {
                   URL url = new URL("file", "localhost", 8080, tmpFile.toString());
                   urls.add(url);
               }
            }
            if(Files.isDirectory(tmpFile)) {
                walk(tmpFile.toString());
            }

        }

    }

    public void printUrls() {
        urls.forEach(System.out::println);
    }

    public void countLines() {

        FileProcessorThread []threads = new FileProcessorThread[urls.size()];
        for(int i=0;i<urls.size();i++) {
            threads[i] = new FileProcessorThread(urls.get(i));
            threads[i].start();
        }

        for(int i=0;i<urls.size();i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        int numOfLines = 0;
        for(int i=0;i<urls.size();i++) {
            numOfLines += threads[i].getNumOfLines();
        }

        System.out.println("result: " + numOfLines);

    }

//    Files.newDirectoryStream()
    public static void main(String[] args) {

        Zad1Main z = new Zad1Main();
        try {
            z.walk("/home/ispit/Desktop/tests");
            System.out.println(z.getCnt());
//          z.printUrls();
            z.countLines();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

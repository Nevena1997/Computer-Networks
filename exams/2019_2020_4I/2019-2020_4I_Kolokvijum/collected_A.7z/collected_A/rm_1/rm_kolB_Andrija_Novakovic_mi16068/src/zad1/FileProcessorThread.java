package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {

    private int numOfLines;
    private URL url;
    private BufferedReader in;

    public FileProcessorThread(URL url) {
        this.url = url;
    }

    public int getNumOfLines() {
        return numOfLines;
    }

    @Override
    public void run() {

        try {
            System.out.println("url: " + url);
            in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.US_ASCII));

            while(true) {
                String line = in.readLine();
                if(line == null) {
                    break;
                }
                numOfLines++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

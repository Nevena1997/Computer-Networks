package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {


    public void execute() {

        try(ServerSocket serverSocket = new ServerSocket(31415)) {

            //noinspection InfiniteLoopStatement
            while(true) {

                Socket client = serverSocket.accept();

                UserThread t = new UserThread(client);
                t.start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        Server s = new Server();
        s.execute();
    }
}

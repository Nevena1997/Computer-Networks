package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class UserThread extends Thread {

    private Socket socket;
    private BufferedWriter toUser;
    private BufferedReader fromUser;

    public UserThread(Socket s) throws IOException {
        this.socket = s;

        toUser = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        fromUser = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    public void run() {

        try {
            String path = fromUser.readLine();
            System.out.println(path);
            Double d = handleFile(path);
            if(d != null) {
                toUser.write(d.toString());
                toUser.flush();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(toUser != null) {
                try {
                    toUser.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(fromUser != null) {
                try {
                    fromUser.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

    }

    public Double handleFile(String path) throws IOException {
        Scanner sc = null;
        try {
            String basePath = "/home/ispit/Desktop/tests/";
            String absolutePath = basePath + path;
            sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(absolutePath))));
            toUser.write("Validna putanja");
            toUser.newLine();
            toUser.flush();
            int ind = 0;
            double sum = 0;
            while(sc.hasNext()) {

                if(sc.hasNextDouble()) {
                    ind = 1;
                    double tmp = sc.nextDouble();
                    sum += tmp;
                }
                else if(sc.hasNextInt()) {
                    ind = 1;
                    int tmp = sc.nextInt();
                    sum += tmp;
                }
                else {
                    sc.next();
                }

            }

            sc.close();

            if(ind == 1) {
                return sum;
            }
            toUser.write("Nema doublova");
            toUser.flush();
            return null;

        } catch (FileNotFoundException e) {
            toUser.write("Fajl ne postoji");
            toUser.flush();
            return null;
        }
        finally {
            if(sc != null)
                sc.close();
        }
    }

}

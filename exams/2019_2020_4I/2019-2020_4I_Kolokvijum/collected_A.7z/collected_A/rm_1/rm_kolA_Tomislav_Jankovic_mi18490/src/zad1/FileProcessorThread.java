package zad1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicLong;

public class FileProcessorThread extends Thread {
    private String filePath;
    private char controlChar;
    public static AtomicLong counter = new AtomicLong(0l);


    public FileProcessorThread(String filePath, char controlChar){
        this.filePath = filePath;
        this.controlChar = controlChar;
    }

    public String getFilePath() {
        return filePath;
    }

    public char getControlChar() {
        return controlChar;
    }

    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(this.filePath), StandardCharsets.UTF_8))){
            //System.out.println("Ispisujemo " + this.filePath);
            String line;

            //AtomicLong count = new AtomicLong(0);
            while ((line = in.readLine()) != null) {
                //System.out.println(line);
                if(line.chars().anyMatch(c -> c == controlChar)){
                    counter.set(counter.get() + line.chars().filter(c -> c == controlChar).toArray().length);
                }
            }
            //System.out.println(count.get());


        }
        catch (FileNotFoundException e) {
            System.err.println("not found " + this.filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

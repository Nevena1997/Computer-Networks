package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;


public class Client {
    public static void main(String[] args) {
        try(Socket client = new Socket("localhost", Server.SERVER_DEFAULT_PORT)) {
            //System.out.println("Pokrenut je klijent!");
            //System.out.println("Ucitavamo podatke!");


            try(Scanner sc = new Scanner(System.in);
                BufferedWriter out = new BufferedWriter(
                                        new OutputStreamWriter(
                                                client.getOutputStream()));
                BufferedReader in = new BufferedReader(
                                        new InputStreamReader(client.getInputStream()))){
                while(sc.hasNext()){
                    String line = sc.next();
                    out.write(line);
                }



            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Srecno od strane klijenta!");
    }
}

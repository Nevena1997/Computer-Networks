package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Server {
    public final static int SERVER_DEFAULT_PORT = 27182;

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(SERVER_DEFAULT_PORT)) {
            //System.out.println("Pokrenut je server!");

            try(var client = server.accept();
                Scanner in = new Scanner(client.getInputStream());
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
                //System.out.println("Citamo sa servera!");
                String pathtoFile = in.next();
                float x = in.nextFloat();
                float y = in.nextFloat();

                System.out.println(pathtoFile + " " + x + " " + y);


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println("Srecno od strane servera!");
    }
}

package zad1;

import javax.tools.StandardJavaFileManager;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;


public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))){

            char controlChar;
            Scanner sc = new Scanner(System.in);
            //System.out.println("Unesite karakter: ");
            controlChar = sc.next().toCharArray()[0];
            sc.close();
            //System.out.println("Uneli ste " + controlChar);


            long lineNumber = 0;
            String line;
            while((line = in.readLine()) != null) {
                lineNumber++;
                URL url;
                try{
                    url = new URL(line);

                }
                catch (MalformedURLException e){
                    //System.out.println("Link bad!");
                    continue;
                }
                //System.out.println(line);

                //System.out.println(url.getProtocol() + " " + url.getPath());
                String protocol = url.getProtocol();
                String filePath = url.getPath();
                if(protocol.equalsIgnoreCase("file") &&
                        (filePath.substring(filePath.lastIndexOf('.') + 1)).equalsIgnoreCase("txt")){
                    //System.out.println("Jeste validan, kreiramo nit: " + protocol + " " + filePath);
                  new FileProcessorThread(filePath, controlChar).start();

                }

            }
            System.out.printf("lines: %5d\n", lineNumber);
            System.out.println("result: " + FileProcessorThread.counter.get());


        } catch (FileNotFoundException e) {
            System.err.println("File not found!");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {
    private static String filePath = "/home/ispit/Desktop/tests/urls.txt";
    private static List<FileProcessorThread> listOfThreads = new LinkedList<>();
    protected static Integer counter = 0;
    public static String key;
    public static void main(String[] args) {
        int numOfLines = 0;
        Scanner stdin = new Scanner(System.in);
        String key = stdin.next();
        stdin.close();
        try (Scanner sc = new Scanner(new File(filePath))) {
            while (sc.hasNextLine()) {
                try {
                    URL url = new URL(sc.nextLine());
                    if (url.getProtocol().equalsIgnoreCase("file") && url.getFile().endsWith(".txt")) {
                        FileProcessorThread t = new FileProcessorThread(url, key);
                        listOfThreads.add(t);
                        t.start();
                    }
                } catch (MalformedURLException e) {

                }
                numOfLines++;
            }

            System.out.println("lines: " + numOfLines);
            for (FileProcessorThread t: listOfThreads)
                t.join();

            System.out.println("Result:" + counter);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }
}

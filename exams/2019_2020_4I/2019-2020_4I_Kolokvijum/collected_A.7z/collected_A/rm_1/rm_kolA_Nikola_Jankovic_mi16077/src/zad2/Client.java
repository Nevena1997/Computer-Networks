package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", Server.DEFAULT_PORT);
            try (PrintStream toServer = new PrintStream(socket.getOutputStream(), true, StandardCharsets.UTF_8);
                 Scanner sc = new Scanner(System.in);
                 BufferedReader fromServer =
                         new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {
                System.out.println("Input:");
                toServer.println(sc.next());
                toServer.println(sc.nextDouble());
                toServer.println(sc.nextDouble());

                System.out.println(fromServer.readLine());
                System.out.println(fromServer.readLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static int DEFAULT_PORT = 27182;
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(Server.DEFAULT_PORT);
            while (true) {
                Socket client = server.accept();
                new ClientHandler(client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import java.util.Arrays;
import java.util.Scanner;

import static zad1.Zad1Main.counter;
import static zad1.Zad1Main.key;

public class FileProcessorThread extends Thread {
    private InputStreamReader urlStream;
    private String key;
    public FileProcessorThread(URL url, String key) {
        try {
            this.urlStream = new InputStreamReader(new BufferedInputStream(url.openStream()), StandardCharsets.UTF_8);
            this.key = key;
        } catch (IOException e) {
            System.err.println("not found: " + url.getFile());
        }
    }

    @Override
    public void run() {
        int b;
        if (this.urlStream == null) {
            return;
        }
        int localCounter = 0;

        try (Scanner sc = new Scanner(urlStream)) {
            while (sc.hasNext()) {

                String line = sc.next();
                for (int i = 0; i < line.length(); i++) {
                    if (key.equals(String.valueOf(line.charAt(i)))) {
                        localCounter++;
                    }
                }


            }
            System.out.println(localCounter);
        }

        synchronized (Zad1Main.counter) {
            Zad1Main.counter += localCounter;
        }
    }
}

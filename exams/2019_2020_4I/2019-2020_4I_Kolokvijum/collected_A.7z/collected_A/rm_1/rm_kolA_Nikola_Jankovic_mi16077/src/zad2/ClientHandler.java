package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ClientHandler extends Thread{
    private BufferedReader fromClient;
    private PrintWriter toClient;
    public ClientHandler(Socket client) {
        try {
            this.fromClient = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            this.toClient = new PrintWriter(client.getOutputStream(), true, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            String filePath = this.fromClient.readLine();
            System.out.println(filePath);
            try (Scanner in = new Scanner(new File(filePath))) {
                this.toClient.println("Okej je putanja.");
                Double x = Double.parseDouble(this.fromClient.readLine());
                Double eps = Double.parseDouble(this.fromClient.readLine());
                boolean contains = false;
                int counter = 0;
                while (in.hasNext()) {
                    if (in.hasNextDouble()) {
                        contains = true;
                        double num = in.nextDouble();
                        if (x - eps <= num && num <= x + eps)
                            counter++;
                    } else in.next();
                }

                if (contains)
                    this.toClient.println(counter);
                else
                    this.toClient.println("Fajl ne sadrzi realne brojeve.");


            }
        } catch (IOException e) {
            this.toClient.println("Nije regularna putanja do fajla.");
        } finally {
            this.toClient.close();
            try {
                this.fromClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

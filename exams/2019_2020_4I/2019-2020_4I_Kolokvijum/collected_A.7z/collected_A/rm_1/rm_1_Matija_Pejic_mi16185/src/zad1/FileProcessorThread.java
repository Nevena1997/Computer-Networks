package zad1;

public class FileProcessorThread extends Thread {

    @Override
    public void run() {

    }
}

package zad2;

import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(27182)){
            while(true){
            Socket client = server.accept();
            new Thread(new ClientRunnable(client)).start();
            }
        }catch(Exception e){
            e.printStackTrace();

        }




    }
}

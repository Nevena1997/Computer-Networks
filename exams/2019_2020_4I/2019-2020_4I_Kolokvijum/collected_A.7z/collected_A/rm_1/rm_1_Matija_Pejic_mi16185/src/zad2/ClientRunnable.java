package zad2;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

class ClientRunnable implements Runnable {
    private Socket client;
    ClientRunnable(Socket client){
        this.client=client;
    }


    @Override
    public void run() {
            try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))
            ){
                String path = in.readLine();
                String s_x = in.readLine();
                String s_eps = in.readLine();

                Double x = new Double(s_x);
                Double eps = new Double(s_eps);



                System.out.println(path);

                double upperBound = x+eps;
                double lowerBound = x-eps;
                int nums = 0;
                boolean has_nums = false;

               try(BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream(path)))){
                   out.write("Validna putanja");
                   out.newLine();
                   out.flush();

                   String line ;
                   while((line = fin.readLine()) != null){
                       String[] tokens = line.split(" ");
                       for(String token : tokens){
                           char[] c = token.toCharArray();
                           if(c.length ==0 || !Character.isDigit(c[0])){
                               continue;
                           }
                           has_nums = true;
                           Double b = new Double(String.valueOf(c));
                           if(b.doubleValue() > lowerBound && b.doubleValue() < upperBound){
                               nums ++;
                           }
                       }

                   }
                    if(has_nums) {
                        out.write(nums+"");
                       // System.out.println(nums);
                        out.newLine();
                        out.flush();
                    }else
                    {
                        out.write("Fajl ne sadrzi realne brojeve!");
                        out.newLine();
                        out.flush();
                    }

               }
               catch (Exception e){
                    out.write("Nevalidna putanja");
                    out.newLine();
                    out.flush();
               }





            }catch (Exception e){
                e.printStackTrace();
            }
    }
}

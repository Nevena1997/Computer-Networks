package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FileProcessorRunnable implements Runnable {
    String path;
    String find;
    FileProcessorRunnable(String path,String find){
        this.path=path;
        this.find=find;
    }
    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path),StandardCharsets.UTF_8))){
            ArrayList<String> all_lines = new ArrayList<>();
            String line;
            while((line=in.readLine())!=null){
                if(line.contains(find)){
                    Zad1Main.char_count++;
                }
                all_lines.add(line);
            }

        }catch (Exception e){
            System.out.println("not found:  "+path);
            return;
        }
    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class Zad1Main {
    public static int char_count = 0;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String find = sc.next();
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))){
            int num_of_lines = 0;
            String line ;
            ArrayList<URL> lista_url = new ArrayList<>();
            while((line = in.readLine())!= null){
                URL url;


                if((url = new URL(line)) != null){
                    lista_url.add(url);
                    if(url.getProtocol().toLowerCase().equals("file")){
                        new Thread(new FileProcessorRunnable(url.getPath(),find)).start();
                    }
                }


                num_of_lines++;
            }

            System.out.println("lines: "+num_of_lines);
            System.out.println(char_count);



        }catch (MalformedURLException e){
            System.out.println("MalformedURL");

        }catch (FileNotFoundException e){
            System.out.println("File not found!");
            return;
        }catch (IOException e){
            System.out.println("IOException");
            return;
        }

    }
}

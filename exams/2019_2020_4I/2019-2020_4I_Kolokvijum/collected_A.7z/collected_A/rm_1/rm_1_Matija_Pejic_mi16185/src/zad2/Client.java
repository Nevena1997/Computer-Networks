package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try(Socket client = new Socket("localhost",27182);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
            ){
            String path = sc.next();
            Double x = sc.nextDouble();
            Double eps = sc.nextDouble();

            out.write(path);
            out.newLine();
            out.write(x.toString());
            out.newLine();
            out.write(eps.toString());
            out.newLine();
            out.flush();

            String msg = in.readLine();
            System.out.println(msg);

            String nums = in.readLine();
            System.out.println(nums);

        }catch (Exception e){
            e.printStackTrace();
        }



    }
}

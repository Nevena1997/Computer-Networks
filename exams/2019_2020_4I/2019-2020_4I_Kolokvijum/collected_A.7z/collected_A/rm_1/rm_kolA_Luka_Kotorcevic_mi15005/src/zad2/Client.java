package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try(Socket client = new Socket("localhost",27182)){
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            Scanner client_input = new Scanner(client.getInputStream());

            Scanner sc = new Scanner(System.in);
            String relative_path = sc.next();
            float x = sc.nextFloat();
            float eps = sc.nextFloat();
            sc.close();

            String send = relative_path + "\n" + x + "\n" + eps;
            bw.write(send,0,send.length());
            bw.newLine();
            bw.flush();

            while(true){
                if(client_input.hasNext()){
                    System.out.println((client_input.nextLine()));
                    break;
                }
            }
            bw.close();
            client_input.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {

        }
    }
}

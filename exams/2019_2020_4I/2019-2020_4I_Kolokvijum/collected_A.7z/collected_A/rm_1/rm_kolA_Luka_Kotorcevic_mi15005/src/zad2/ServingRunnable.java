package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class ServingRunnable implements Runnable {

    Server server;
    Socket client;

    public ServingRunnable(Server server, Socket client) {
        this.server = server;
        this.client = client;
    }

    @Override
    public void run() {
        try(BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){

        while(true){
            try(Scanner sc = new Scanner(client.getInputStream())){
                String path = sc.next();
                float x = sc.nextFloat();
                float eps = sc.nextFloat();
                server.msg(path);
                Path p = Path.of(path);
                if(Files.exists(p)){
                    bw.write("Validna putanja");
                    bw.newLine();
                    bw.flush();
                }else{
                    bw.write("Nije validna putanja");
                    bw.newLine();
                    bw.flush();
                }
                break;
            } catch (IOException e) {
                //e.printStackTrace();
            }
         }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {
    Server s = new Server();

       try(ServerSocket server = new ServerSocket(27182)){
           while(true){
               Socket client = server.accept();

               Thread t = new Thread(new ServingRunnable(s,client));
               t.start();
           }
       } catch (IOException e) {
           e.printStackTrace();
       }

    }

    public void msg(String msg){
        System.out.println(msg);
    }
}

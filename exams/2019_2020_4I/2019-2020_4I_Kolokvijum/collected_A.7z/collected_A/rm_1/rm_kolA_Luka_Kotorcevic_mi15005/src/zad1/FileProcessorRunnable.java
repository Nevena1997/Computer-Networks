package zad1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.locks.Lock;

public class FileProcessorRunnable implements Runnable {
    String path;
    char c;
    Lock lock;

    public FileProcessorRunnable(String path, char c, Lock lock) {
        this.path = path;
        this.c = c;
        this.lock = lock;
    }

    @Override
    public void run() {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path), StandardCharsets.UTF_8))){
            int bytesRead;
            char[] buff = new char[512];
            int local_count=0;
            while((bytesRead = br.read(buff)) != -1 ){
                for(char d : buff){
                    if(d == this.c)
                        local_count++;
                }
                this.lock.lock();
                Zad1Main.total_count = Zad1Main.total_count + local_count;
                this.lock.unlock();
            }
        } catch (FileNotFoundException e) {
            System.out.println("not found: " + path);
            //e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

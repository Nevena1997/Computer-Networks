package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Zad1Main {

    public static int total_count = 0;

    public static void main(String[] args) {
        ArrayList<String> words = new ArrayList<>();
        ArrayList<URL> urls = new ArrayList<>();

        int ln = 0;

        Scanner input = new Scanner(System.in);
        char c = input.next().charAt(0);
        input.close();

        Lock lock = new ReentrantLock();

        try(Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"))))) {
            while(sc.hasNextLine()){
                ln++;
                words.add(sc.nextLine());
            }
            System.out.println("lines:      "+ln);
            System.out.println();

            for(String p : words){
                try{
                   urls.add(new URL(p));
                }catch (MalformedURLException e){
                }
            }

           for(URL u : urls){
                String protocol = u.getProtocol();
                if(protocol.equalsIgnoreCase("file")){
                    if(u.getPath().endsWith(".txt")){
                        Thread t = new Thread(new FileProcessorRunnable(u.getPath(),c,lock));
                        t.start();
                    }
                }
           }

            System.out.println("result:     "+total_count);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

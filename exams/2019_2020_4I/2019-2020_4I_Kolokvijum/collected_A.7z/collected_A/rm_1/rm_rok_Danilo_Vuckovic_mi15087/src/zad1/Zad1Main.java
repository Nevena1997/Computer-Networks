package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.*;
import java.nio.charset.StandardCharsets;

import static java.nio.charset.StandardCharsets.*;

public class Zad1Main {


    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        String ime = "urls.txt";
        System.out.println("Srecno!");
        FileProcessorRunnable fileProcessorRunnable = new FileProcessorRunnable(ime);
        System.out.println(ime);

    }
}

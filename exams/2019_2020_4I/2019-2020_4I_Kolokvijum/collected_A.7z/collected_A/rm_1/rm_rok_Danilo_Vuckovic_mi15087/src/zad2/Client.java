package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class Client {

    public static void main(String[] args) {
        System.out.println("Srecno od strane klijenta!");
        String hostname = "localhost";
        System.err.println(hostname);
        try (Socket client = new Socket(hostname, 27182);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in))
        ){
            System.err.println(hostname);
            while (true) {

                String line = userIn.readLine();
                if (userIn.readLine().equalsIgnoreCase("exit"))
                    break;
                String putanja = line;
                System.out.println(putanja);
                String[] putanja1 = line.split(" ");
                //System.out.println(putanja1[1]);

                //double x = userIn.read();
                //System.out.println(x);
                //double eps = line.charAt(4);
                //System.out.println(eps);
                if (line.trim().equalsIgnoreCase("exit")) {
                    out.write(line);
                    out.newLine();
                    out.flush();
                }
                System.out.println(in);
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

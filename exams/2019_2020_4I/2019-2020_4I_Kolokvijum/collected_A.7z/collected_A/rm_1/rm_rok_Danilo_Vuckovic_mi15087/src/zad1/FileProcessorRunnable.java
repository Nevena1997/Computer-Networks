package zad1;

import java.net.MalformedURLException;
import java.util.ConcurrentModificationException;
import java.io.*;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.InflaterInputStream;


public class FileProcessorRunnable implements Runnable {
    private static String keyword;

    public FileProcessorRunnable(String keyword) {
        this.keyword = keyword;
    }




    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out))
         ){
            Thread t1 = new Thread();
            t1.start();
            String line;
            char a = (char) in.read();
            while ((line = in.readLine()) != null) {
                URL u = new URL(line);
                //URL u1 = new URL("file:///home/ispit/Desktop/tests/404/t.txt");
                //URL u2 = new URL("ftp://mi15123@alas.matf.bg.ac.rs:22/1.txt");
                //URL u3 = new URL("file:///home/ispit/Desktop/tests/1.txt#t");
                //URL u4 = new URL("http://www.matf.bg.ac.rs:8080");
                //URL u5 = new URL("FILE:///home/ispit/Desktop/tests/gaben.webp");
                System.out.println(u);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

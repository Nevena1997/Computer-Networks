package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    private final static int DEFAULT_PORT = 27182;

    public static void main(String[] args) {
        System.out.println("Srecno od strane servera!");

        System.err.println(DEFAULT_PORT);
        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){
            System.err.println(DEFAULT_PORT);
            while (true) {
                System.err.println("listening...");

                Socket client = server.accept();
                System.err.println("acceptd");

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.err.printf("[%2d]", Thread.currentThread().getId());

    }
}

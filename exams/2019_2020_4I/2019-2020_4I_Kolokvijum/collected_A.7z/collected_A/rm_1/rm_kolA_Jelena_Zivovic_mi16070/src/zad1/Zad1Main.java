package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        //System.out.println("Srecno!");

        String inputFileName = "tests/urls.txt";

       // System.out.println("Unesite jedan karakter:");
        Scanner sc = new Scanner(System.in);
        String chString = sc.next();
        char character = chString.toCharArray()[0];
        sc.close();


        int numberOfCharacters = 0;

        try (BufferedReader input = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(inputFileName),
                        StandardCharsets.UTF_8
                )
        )
        ) {
            String line;
            int numberOfLines = 0;

            while ((line = input.readLine()) != null) {
                if (line.length() == 0) {
                    continue;
                }

                if (isValidURL(line.trim())) {
                    numberOfLines++;
                    URL url = new URL(line.trim());

                    String protocol = url.getProtocol();
                    String fileName = url.getFile();
                    int lastIndexSlash = fileName.lastIndexOf("/");
                    String ext  = "";
                    if (lastIndexSlash != -1) {
                        int lastIndexDot = fileName.substring(lastIndexSlash).lastIndexOf(".");
                        if (lastIndexDot != -1) {
                            ext = fileName.substring(lastIndexSlash).substring(lastIndexDot);
                        }
                        else {
                            continue;
                        }
                    }
                    else {
                        continue;
                    }

                    if (protocol.equals("file") && ext.equals(".txt")) {

                        URL url1 = new URL(line.trim());

                        FileProcessorRunnable c = new FileProcessorRunnable(url, character);
                        Thread t = new Thread(c);
                        t.start();
                        t.join();
                        numberOfCharacters += c.getNumberOfCharactes();
                    }
                }
            }

            System.out.println("lines: " + numberOfLines);
            System.out.println("result: " + numberOfCharacters);
        } catch (FileNotFoundException e) {
            System.err.println("not found");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public static boolean isValidURL(String urlString) {

        try {
            new URL(urlString);
            return true;
        } catch (MalformedURLException e) {
            return false;
        }

    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ClientHandlerRunnable implements Runnable {

    private Socket client;

    public ClientHandlerRunnable(Socket d) {
        this.client = d;
    }

    public void run() {

        try(BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        this.client.getInputStream()
                )
        ); BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(
                        this.client.getOutputStream()
                )
        )
        ) {

            String line;
            int counter = 0;
            while ((line = in.readLine()) != null) {
                String[] parts = line.split(" ");
                String pathString = parts[0];
                double x = Double.parseDouble(parts[1]);
                double eps = Double.parseDouble(parts[2]);
                System.out.println(pathString);
                pathString = "tests/" + pathString;

                if (!isPathValid(pathString)) {
                    out.write("Putanja nije validna.");
                    out.newLine();
                    out.flush();
                }
                else {
                    out.write("Validna putanja");
                    out.newLine();
                    out.flush();

                    try (BufferedReader input = new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(pathString)
                            )
                    )) {
                        String s;

                        while ((s = input.readLine()) != null) {
                            String[] str = s.split(" ");

                            for (String string : str) {

                                if (isValidDouble(string.trim())) {
                                    double b = Double.parseDouble(string.trim());
                                    if ((b > x-eps) && (b < x+eps))
                                        counter++;
                                }



                            }

                        }
                        if (counter == 0) {
                            out.write("Fajl ne sadrzi realne brojeve");
                            out.newLine();
                            out.flush();
                        }
                        else {
                            out.write(String.valueOf(counter));
                            out.newLine();
                            out.flush();
                        }
                    }

                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private boolean isValidDouble(String part) {

        try {
            double x = Double.parseDouble(part);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }

    private boolean isPathValid (String p) {
        try {
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(p)
                    )
            );
            return true;
        } catch (FileNotFoundException e) {
            return false;
        }
    }

}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class FileProcessorRunnable implements Runnable {

    private URL url;
    private char character;
    private int numberOfCharactes = 0;

    public FileProcessorRunnable(URL u, char c) {
        this.url = u;
        this.character = c;

    }

    @Override
    public synchronized void run() {

        try (BufferedReader input = new BufferedReader(
                new InputStreamReader(
                        this.url.openStream()
                        )
        )) {
            String line;
            int counter = 0;
            while ((line = input.readLine()) != null) {
                char[] array = line.toCharArray();

                for (int i = 0; i < array.length; i++) {
                    if (array[i] == this.character) {
                        counter++;
                    }
                }
            }

            this.numberOfCharactes = counter;


        } catch (IOException e) {
            System.out.println("not found: " + this.url.getPath());
        }


    }

    public synchronized int getNumberOfCharactes() {
        return this.numberOfCharactes;
    }
}

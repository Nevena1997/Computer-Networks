package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        //System.out.println("Srecno od strane klijenta!");

        try (Socket client = new Socket("localhost", Server.DEFAULT_PORT)) {

            //System.err.println("connected");

            Scanner sc = new Scanner(System.in);
            String pathString = sc.next();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();

            try (BufferedWriter networkOut = new BufferedWriter(
                    new OutputStreamWriter(
                            client.getOutputStream()
                    )
            ); BufferedReader networkIn = new BufferedReader(
                    new InputStreamReader(
                            client.getInputStream()
                    )
            )
            ) {
                String toSend = pathString + " " + String.valueOf(x) + " " + String.valueOf(eps);
                networkOut.write(toSend);
                networkOut.newLine();
                networkOut.flush();

                String line = networkIn.readLine();
                System.out.println(line);
                if (!line.trim().equals("Putanja nije validna.")) {
                    line = networkIn.readLine();
                    System.out.println(line);
                }


            }




        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

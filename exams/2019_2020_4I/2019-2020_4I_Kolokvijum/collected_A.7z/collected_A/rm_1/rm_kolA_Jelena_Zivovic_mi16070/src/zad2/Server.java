package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.file.FileSystem;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Server {

    public static final int DEFAULT_PORT = 27182;

    public static void main(String[] args) {

        //System.out.println("Srecno od strane servera!");

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)) {

            //System.err.println("server bound.");

            while (true) {
              //  System.err.println("listening for clients:");
                Socket client = server.accept();
                    //System.err.println("Server accepted.");

                    ClientHandlerRunnable c = new ClientHandlerRunnable(client);
                    Thread t = new Thread(c);
                    t.start();




            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



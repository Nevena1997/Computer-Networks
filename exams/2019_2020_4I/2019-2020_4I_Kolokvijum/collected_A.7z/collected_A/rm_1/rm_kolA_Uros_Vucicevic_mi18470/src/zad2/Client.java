package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {


    public static void main(String[] args) {

        try {


            Scanner sc = new Scanner(System.in);
            String putanja = sc.next();
            String x = sc.next();
            String eps = sc.next();
            sc.close();

            Socket client = new Socket("localhost", 27182);

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            out.write(putanja);
            out.newLine();
            out.write(x);
            out.newLine();
            out.write(eps);
            out.newLine();
            out.flush();


           BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

            System.out.println(in.readLine());
            int br = Integer.parseInt(in.readLine().trim());

            if(br==0)
                System.out.println("Fajl ne sadrzi realne brojeve");
            else
                System.out.println(br);

            out.close();
            in.close();
    }
        catch(UnknownHostException e){
            System.err.println("Nepostojeci host");
            System.exit(1);
        }
        catch(IOException i){
            i.printStackTrace();
        }

        //System.out.println("Srecno od strane klijenta!");
    }
}

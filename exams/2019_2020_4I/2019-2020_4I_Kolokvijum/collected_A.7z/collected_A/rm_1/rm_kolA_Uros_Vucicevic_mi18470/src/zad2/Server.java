package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {

        try {

            ServerSocket ssock = new ServerSocket(27182);
            Socket client;

            while(true) {
                client = ssock.accept();
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String putanja = in.readLine();
                System.out.println(putanja);
                double x = Double.parseDouble(in.readLine().trim());
                double eps = Double.parseDouble(in.readLine().trim());

                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

                try {
                    BufferedReader fileIn = new BufferedReader(new InputStreamReader(new FileInputStream("../tests/"+putanja)));

                    String linija;
                    int br =0;
                    while((linija=fileIn.readLine())!=null){
                        String[] tokeni = linija.split(" ");
                        for(int i=0;i<tokeni.length;i++){
                            if(tokeni[i].matches("(-)?[0-9]+(.[0-9]+)?")){
                                double broj = Double.parseDouble(tokeni[i]);
                                if (broj> x-eps && broj < x+eps)
                                    br++;
                            }
                        }

                    }
                    out.write("Validna putanja");
                    out.newLine();
                    out.write(br);
                    out.newLine();
                    out.flush();
                }
                catch (FileNotFoundException f) {
                    out.write("Putanja nije validna");
                    out.newLine();
                    out.flush();
                }
            }
        }
        catch (IOException e) {
            System.err.println("Greska");
            System.exit(1);
        }

        //System.out.println("Srecno od strane servera!");
    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        Scanner sc = new Scanner(System.in);
        String c = sc.nextLine();
        System.out.println(c.charAt(0));
        sc.close();


        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(new FileInputStream("../tests/urls.txt")));
            int lines = 0;
            String linija;
            while((linija=in.readLine())!=null) {
                URL url = new URL(linija);
                lines++;
                if(url.getProtocol()=="file"){

                }
            }
            System.out.println(lines);

        } catch (FileNotFoundException e) {
            System.err.println("Fajl ne postoji");
            System.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //System.out.println("Srecno!");

    }
}

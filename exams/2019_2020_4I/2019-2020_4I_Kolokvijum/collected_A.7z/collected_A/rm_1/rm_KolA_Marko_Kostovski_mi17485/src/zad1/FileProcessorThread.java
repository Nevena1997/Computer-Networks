package zad1;

import javax.management.monitor.Monitor;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

public class FileProcessorThread extends Thread {
    private URL u;
    private char c;
    ConcurrentLinkedQueue<Long> q;

    public FileProcessorThread(URL u, char c, ConcurrentLinkedQueue<Long> q){
        this.u = u;
        this.c = c;
        this.q = q;
    }

    @Override
    public void run() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        try {
            URLConnection uc = u.openConnection();
            try {
                Scanner sc = new Scanner(
                        new BufferedReader(
                                new InputStreamReader(
                                        uc.getInputStream(),
                                        StandardCharsets.UTF_8
                                )
                        )
                );
                long counted = 0;
                while (sc.hasNext()){
                    counted += sc.next().chars().filter(ch -> ch == this.c).count();
                }
                q.add(counted);
                System.out.println("result = " + counted);

            } catch (FileNotFoundException f) {
                System.out.println("not found: " + u.getFile());
            }
        }
        catch (IOException ie) {
            ie.printStackTrace();
        }
    }
}

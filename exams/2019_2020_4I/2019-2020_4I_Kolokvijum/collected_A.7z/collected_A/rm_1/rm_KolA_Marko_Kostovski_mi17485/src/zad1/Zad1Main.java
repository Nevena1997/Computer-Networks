package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

public class Zad1Main {
    public static void main(String[] args) {

        String filepath = "/home/ispit/Desktop/tests/urls.txt";
        ConcurrentLinkedQueue<Long> q = new ConcurrentLinkedQueue<Long>();
        Scanner in = null;
        char c;

        try {
            Scanner sc = new Scanner(System.in);
            c = sc.next().charAt(0);

            in = new Scanner(
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(filepath),
                                    StandardCharsets.UTF_8)
                    )
            );

            ArrayList<FileProcessorThread> threads = new ArrayList<FileProcessorThread>();
            Integer numOfLines = 0;
            while (in.hasNextLine()) {
                numOfLines++;
                String line = in.nextLine();
                try {
                    URL u = new URL(line);
                    if (u.getProtocol().equals("file") && u.getFile().indexOf(".txt") == u.getFile().length()-4){
                        threads.add(new FileProcessorThread(u, c, q));
                    }
                } catch (MalformedURLException m) {
                    continue;
                }
            }
            for (FileProcessorThread ft : threads){
                Thread t = new Thread(ft);
                t.start();
            }
            System.out.println("lines: " + numOfLines);

            sc.close();
        } catch (FileNotFoundException fe) {
            fe.printStackTrace();
        } finally {
            if  (in != null) {
                in.close();
            }
        }
    }
}

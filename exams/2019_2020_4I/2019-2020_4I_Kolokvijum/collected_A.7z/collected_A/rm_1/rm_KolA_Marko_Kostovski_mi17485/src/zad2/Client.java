package zad2;

import java.net.Socket;

public class Client {
    public static void main(String[] args) {

        System.out.println("Srecno od strane klijenta!");
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        char c;
        Scanner sc = new Scanner(System.in);
        c = sc.next().charAt(0);
        sc.close();
                                                                                                                            //urls1.txt
        try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"))))
        {
            int broj_url = 0;
            String surl;
            int broj_pojavljivanja = 0;
            List<String> lista_url = new LinkedList<>();
            while((surl = br.readLine()) != null)
            {
                broj_url++;
                lista_url.add(surl);
            }
            System.out.println("lines: " + broj_url);

            List<FileProcessorThread> lista_niti = new LinkedList<>();
            for (int i = 0; i < broj_url; i++)
            {
                try
                {
                    surl = lista_url.get(i);
                    URL url = new URL (surl);

                    if(url.getProtocol().equalsIgnoreCase("file") && surl.endsWith(".txt"))
                    {
                        FileProcessorThread fpt = new FileProcessorThread(url, c);
                        lista_niti.add(fpt);
                        fpt.start();
                    }
                }
                catch(MalformedURLException m)
                {
                    continue;
                }
            }
            for(int i = 0; i < lista_niti.size(); i++)
            {
                try
                {
                    FileProcessorThread fpt = lista_niti.get(i);
                    fpt.join();
                    // TODO: Sinhronizovati ovo dole
                    synchronized (fpt)
                    {
                        broj_pojavljivanja += fpt.getBroj();
                    }
                }
                catch(InterruptedException ie) {}
            }
            System.out.println("result: " + broj_pojavljivanja);

        }
        catch(IOException e)
        {
            System.err.println("Main");
        }

        System.out.println("Srecno!");
    }
}

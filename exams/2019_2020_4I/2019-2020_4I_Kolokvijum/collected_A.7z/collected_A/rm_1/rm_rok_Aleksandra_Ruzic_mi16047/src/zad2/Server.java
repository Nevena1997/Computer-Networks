package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {

        try(ServerSocket sc = new ServerSocket(27182))
        {
            while(true)
            {
                Socket s = sc.accept();
                new ClientThread(s).start();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        System.out.println("Srecno od strane servera!");
    }
}

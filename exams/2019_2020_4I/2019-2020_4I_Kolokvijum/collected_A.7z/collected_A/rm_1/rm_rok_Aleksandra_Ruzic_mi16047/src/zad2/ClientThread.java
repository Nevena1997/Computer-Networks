package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Path;
import java.util.Scanner;

public class ClientThread extends Thread
{
    private Socket socket;
    private String putanja;
    private float x;
    private float eps;

    public ClientThread(Socket socket)
    {
        this.socket = socket;
    }

    @Override
    public void run()
    {
        try(BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream())))
        {
            putanja = "/home/ispit/Desktop/tests/" + br.readLine();
            //System.out.println(putanja);
            x = Float.parseFloat(br.readLine());
           // System.out.println(x);
            eps = Float.parseFloat(br.readLine());
            //System.out.println(eps);

            try(Scanner sc = new Scanner(Path.of(putanja)))
            {
                bw.write("Validna putanja");
                bw.newLine();
                bw.flush();

                Integer resenje = 0;
                boolean realni = false;
                float broj;
                while(sc.hasNextFloat())
                {
                    realni = true;
                    broj = sc.nextFloat();
                    if(broj > x - eps && broj < x + eps)
                    {
                        resenje++;
                    }
                }

                if (!realni)
                {
                    bw.write("Fajl ne sadrzi realne brojeve");
                    bw.newLine();
                    bw.flush();
                }
                else
                {
                    bw.write(resenje.toString());
                    bw.newLine();
                    bw.flush();
                }
            }
            catch (IOException e)
            {
                bw.write("Nevalidna putanja");
                bw.newLine();
                bw.flush();
            }
        }
        catch(IOException e)
        {

        }
        finally {
            try
            {
                socket.close();
            } catch (IOException e1) { }
        }
    }
}

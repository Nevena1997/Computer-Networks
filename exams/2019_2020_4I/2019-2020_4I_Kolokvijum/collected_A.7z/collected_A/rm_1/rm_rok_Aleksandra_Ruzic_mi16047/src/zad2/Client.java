package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try(Socket s = new Socket("localhost", 27182);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream())))
        {
            Scanner sc = new Scanner(System.in);
            String putanja, x, eps;
            putanja = sc.next();
            x = sc.next();
            eps = sc.next();

            bw.write(putanja);
            bw.newLine();

            bw.write(x);
            bw.newLine();

            bw.write(eps);
            bw.newLine();

            bw.flush();

            String validna = br.readLine();
            System.out.println(validna);
            if(validna.equalsIgnoreCase("Validna putanja"))
            {
                String resenje = br.readLine();
                System.out.println(resenje);
            }
        }
        catch(IOException e)
        {

        }
        System.out.println("Srecno od strane klijenta!");
    }
}

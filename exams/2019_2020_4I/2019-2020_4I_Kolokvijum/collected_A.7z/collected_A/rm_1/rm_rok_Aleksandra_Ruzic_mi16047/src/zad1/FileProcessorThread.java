package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {

    private URL url;
    private char c;
    private int broj;

    public FileProcessorThread(URL url, char c)
    {
        this.url = url;
        this.c = c;
        this.broj = 0;
    }

    @Override
    public void run()
    {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8)))
        {
            int a;
            while((a = br.read()) != -1)
            {
                if((char)a == c)
                {
                    broj++;
                }
            }
        }
        catch(IOException e)
        {
            System.out.println("not found: " + url.toString());
        }
    }

    public int getBroj()
    {
        return broj;
    }
}

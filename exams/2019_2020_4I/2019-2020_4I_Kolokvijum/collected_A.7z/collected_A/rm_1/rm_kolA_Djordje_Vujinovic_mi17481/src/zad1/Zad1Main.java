package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static int brojac = 0;
    public static void main(String[] args) {

//        try {
//            URL url = new URL("file:///home/ispit/Desktop/tests/dir1/3.txt");
//            System.out.println(url.getPath());
//        } catch (MalformedURLException e) {
//            System.err.println("Not a valid url");
//        }


        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")));

            Scanner sc =  new Scanner(System.in);
            String kar = sc.next();
            sc.close();

            String line;
            int l = 0;
            while((line = in.readLine()) != null) {
                l++;
                try {
                    URL url = new URL(line);
                    if (url.getProtocol().equalsIgnoreCase("file") && url.getFile().endsWith(".txt")) {
                        FileProcessorRunnable file = new FileProcessorRunnable(url.getPath(), kar.charAt(0));

                        new Thread(file).start();
                    }
                } catch (MalformedURLException e) {
                    System.err.println("Wrong address");
                }

            }
            System.out.println("lines: " + l);
            System.out.println("result: " + brojac);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




    }
}

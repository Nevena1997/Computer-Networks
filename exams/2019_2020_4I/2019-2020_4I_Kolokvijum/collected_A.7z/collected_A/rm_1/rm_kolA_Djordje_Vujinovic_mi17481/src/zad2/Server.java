package zad2;

import org.w3c.dom.ls.LSOutput;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int DEFAULT_PORT = 27182;

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)) {
            try (Socket client = server.accept();
                 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                 BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
            ) {
                SearchFileRunnable file = new SearchFileRunnable(in.readLine(), client);
                new Thread(file).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

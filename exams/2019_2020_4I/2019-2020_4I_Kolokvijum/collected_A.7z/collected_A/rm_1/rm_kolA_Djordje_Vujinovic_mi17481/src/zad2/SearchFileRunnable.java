package zad2;

import java.io.*;
import java.net.Socket;

public class SearchFileRunnable implements Runnable {
    String line;
    Socket socket;

    public SearchFileRunnable(String readLine, Socket client) {
        this.line = readLine;
        this.socket = client;
    }

    @Override
    public void run() {
        String[] args = this.line.split(" ");
        System.out.println(args[0]);
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/" + args[0])));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()))) {

        } catch (FileNotFoundException e) {
            System.err.println("Putanja nije validna");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

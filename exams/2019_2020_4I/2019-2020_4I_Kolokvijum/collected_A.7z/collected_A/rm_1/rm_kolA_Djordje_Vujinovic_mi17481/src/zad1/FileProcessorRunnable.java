package zad1;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {
    String path;
    char c;

    public FileProcessorRunnable(String path, char c) {
        this.path = path;
        this.c = c;
    }

    @Override
    synchronized public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.path), StandardCharsets.UTF_8))) {
            String line;
            while((line = in.readLine()) != null) {
                // verovatno najgluplji nacin da se ovako nesto uradi, ali stao mi mozak
                for(int i = 0; i < line.length(); i++) {
                    if(line.charAt(i) == this.c)
                        Zad1Main.brojac++;
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("not  found: " + this.path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

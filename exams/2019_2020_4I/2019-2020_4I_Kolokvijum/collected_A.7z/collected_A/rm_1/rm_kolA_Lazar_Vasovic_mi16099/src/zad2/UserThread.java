package zad2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class UserThread extends Thread {
    Socket sock;

    public UserThread(Socket sock) {
        this.sock = sock;
    }

    @Override
    public void run(){
        try(var sc = new Scanner(this.sock.getInputStream());
            var pw = new PrintWriter(this.sock.getOutputStream(), true)){
            String put = sc.nextLine();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();

            System.out.println(put);

            var pput = Paths.get("home", "ispit", "Desktop", "tests", put);

            if (!Files.isRegularFile(pput)){
                pw.println(false);
            } else {
                pw.println(true);

                int broj = 0;
                var scc = new Scanner(pput);
                while (scc.hasNext()){
                    String test = scc.next().strip();

                    try {
                        double br = Double.valueOf(test);
                        if (br > eps-x && br < x+eps)
                            broj++;
                    } catch (Throwable e){

                    }
                }
                pw.println(broj);
            }

        } catch (IOException e){
            e.printStackTrace();
        } finally {
            try {
                this.sock.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

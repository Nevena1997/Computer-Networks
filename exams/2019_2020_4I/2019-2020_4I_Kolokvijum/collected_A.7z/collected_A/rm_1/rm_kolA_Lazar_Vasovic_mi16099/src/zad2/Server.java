package zad2;

import java.io.IOException;
import java.net.ServerSocket;

public class Server {
    public static void main(String[] args){
        try (var server = new ServerSocket(27182)){
            while (true){
                var sock = server.accept();

                new UserThread(sock).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicLong;

public class Zad1Main {
    public static void main(String[] args) {
        char kar = ' '; /* nista od ch :( */
        try (Scanner sc = new Scanner(System.in)){
            kar = sc.next().charAt(0);
        } catch (Throwable e){
            e.printStackTrace();
            System.exit(1);
        }

        int broj = 1;
        try (var br = new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(
                                            "/home/ispit/Desktop/tests/urls.txt"),
                                    StandardCharsets.UTF_8
                                                 )
                                        )
            )
        {
            while (br.readLine() != null){
                broj++;
            }
            System.out.println(String.format("lines:     %d", broj));
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        var niti = new Thread[broj];
        var ind = 0;
        var brojac = new AtomicLong();
        try (var br = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(
                                "/home/ispit/Desktop/tests/urls.txt"),
                        StandardCharsets.UTF_8
                )
                                        )
        )
        {
            String linija;
            while ((linija = br.readLine()) != null){
                try {
                    linija = linija.strip();
                    URL put = new URL(linija);
                    if (put.getProtocol().equalsIgnoreCase("file") && linija.endsWith(".txt")){
                        niti[ind] = new FileProcessorThread(put, brojac, kar);
                        niti[ind++].start();
                    }
                } catch (MalformedURLException ignored) {}
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        for (int i = 0; i < ind; i++){
            try {
                niti[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(String.format("result:    %d", brojac.get()));
    }
}

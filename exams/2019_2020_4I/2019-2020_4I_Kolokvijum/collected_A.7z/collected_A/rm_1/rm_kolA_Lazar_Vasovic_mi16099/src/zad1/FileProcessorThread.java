package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicLong;

public class FileProcessorThread extends Thread {
    private URL put;
    private AtomicLong brojac;
    private char kar;

    public FileProcessorThread(URL put, AtomicLong brojac, char kar){
        this.put = put;
        this.brojac = brojac;
        this.kar = kar;
    }

    @Override
    public void run() {
        long broj = 0;
        try (var br = new BufferedReader(
                new InputStreamReader(
                        put.openConnection().getInputStream(),
                        StandardCharsets.UTF_8
                )
        )
        ) {
            String linija;
            while ((linija = br.readLine()) != null){
                broj += linija.chars().filter(e -> e == kar).count();
            }
            brojac.addAndGet(broj);
        } catch (IOException e) {
            System.out.println(String.format("not found: %s", put.getPath()));
        }
    }
}

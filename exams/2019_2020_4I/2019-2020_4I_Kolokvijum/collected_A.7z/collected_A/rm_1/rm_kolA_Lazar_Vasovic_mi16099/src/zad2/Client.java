package zad2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try(var sock = new Socket("localhost", 27182);
            var pw = new PrintWriter(sock.getOutputStream(), true);
            var sc = new Scanner(sock.getInputStream())) {
            String put = "";
            double x = 0.0;
            double eps = 0.0;

            try (var scc = new Scanner(System.in)) {
                put = scc.next();
                x = scc.nextDouble();
                eps = scc.nextDouble();
            } catch (Throwable e) {
                e.printStackTrace();
                System.exit(1);
            }

            pw.println(put);
            pw.println(x);
            pw.println(eps);

            var ima = sc.nextBoolean();
            if (ima){
                System.out.println("Validna putanja");
                var broj = sc.nextInt();
                if (broj == 0){
                    System.out.println("Fajl ne sadrzi realne brojeve");
                } else {
                    System.out.println(broj);
                }
            } else {
                System.out.println("Nije validna putanja");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

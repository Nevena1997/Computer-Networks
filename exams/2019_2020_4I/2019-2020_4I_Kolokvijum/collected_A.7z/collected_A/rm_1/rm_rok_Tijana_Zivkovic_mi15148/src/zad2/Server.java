package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(27182)){

            while(true) {
                Socket client = server.accept();
                Thread client_thread = new NitZaKlijenta(client);

                client_thread.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {

    public static BlockingQueue<Integer> broj_karaktera;
    public static int broj_linija = 0;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        try (BufferedReader in = new BufferedReader(new InputStreamReader(
                new FileInputStream("/home/ispit/Desktop/rm_rok_Ime_Prezime_miGGXXX/src/zad1/urls.txt")))) {

            Scanner sc = new Scanner(System.in);
            char c = sc.next().charAt(0);

            broj_karaktera.add(0);


            String linija;
            while ((linija = in.readLine()) != null) {
                broj_linija++;
                System.out.println(linija);

                try {
                    URL url = new URL(linija);
                    String protocol = url.getProtocol();
                    String ext = linija.substring(linija.lastIndexOf('.'));
                    if (protocol.toUpperCase().equals("FILE") && ext.equals(".txt")) {

                        Thread tred = new Thread(new FileProcessorRunnable(url, c));
                        tred.start();


                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }

            sc.close();
        } catch(IOException e) {
        e.printStackTrace();
        }


        System.out.println("Lines: " + broj_linija);
        System.out.println("Result: " + broj_karaktera.poll());
    }
}

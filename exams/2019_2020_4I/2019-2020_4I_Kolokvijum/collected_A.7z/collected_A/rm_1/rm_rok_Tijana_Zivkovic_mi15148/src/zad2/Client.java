package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try(Socket client_socket = new Socket("localhost", 27182)) {

            Scanner sc = new Scanner(System.in);
            String putanja = sc.next();
            String x = sc.next();
            String eps = sc.next();

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client_socket.getOutputStream()));
            out.write(putanja);
            out.newLine();
            out.write(x);
            out.write(eps);
            out.flush();


        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Srecno od strane klijenta!");
    }
}

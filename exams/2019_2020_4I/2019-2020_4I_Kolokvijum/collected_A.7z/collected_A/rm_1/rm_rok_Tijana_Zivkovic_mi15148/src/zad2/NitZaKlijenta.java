package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.file.Path;
import java.util.Scanner;

public class NitZaKlijenta extends Thread{

    Socket client;
    String putanja;
    double x;
    double eps;

    public NitZaKlijenta(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
         try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

             this.putanja = in.readLine();
             this.x = (double)(in.read());
             this.eps = (double) (in.read());

             System.out.println(putanja);
         } catch (IOException e) {
             e.printStackTrace();
         }
    }
}

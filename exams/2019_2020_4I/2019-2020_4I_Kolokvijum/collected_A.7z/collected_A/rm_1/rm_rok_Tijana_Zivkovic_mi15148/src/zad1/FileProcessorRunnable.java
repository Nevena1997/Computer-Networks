package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {

    public static BlockingQueue<Integer> broj_karaktera;
    private URL url;
    private char c;

    public FileProcessorRunnable(URL url, char c) {
        this.url = url;
        this.c = c;
    }

    @Override
    public void run() {

        try {
            URLConnection conn = url.openConnection();
            Scanner in = new Scanner(new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)));

            while(in.hasNext()) {
                if(in.next().equals(c)) {
                    int trenutni_broj = broj_karaktera.remove()+1;
                    broj_karaktera.add(trenutni_broj);
                }
            }


            in.close();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

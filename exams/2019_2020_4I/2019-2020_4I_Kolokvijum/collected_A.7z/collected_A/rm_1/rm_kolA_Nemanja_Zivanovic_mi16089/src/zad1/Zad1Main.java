package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.System.exit;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        Scanner sc = new Scanner(System.in);
        char slovo = sc.next().charAt(0);
        int brLin = 0;
        List<Thread> lista = new ArrayList<>();
        String linija;
        String putanja = "/home/ispit/Desktop/tests/urls.txt";
        try(Scanner scanner = new Scanner(new BufferedInputStream(new FileInputStream(putanja)))){

            while(scanner.hasNextLine()){
                linija = scanner.nextLine();
                brLin++;
                try {
                    URL url = new URL(linija);
                    if(url.getProtocol().equalsIgnoreCase("file")){
                        int indeks = url.toString().lastIndexOf(".");
                        if(indeks!=-1) {
                            if(url.toString().substring(indeks).equals(".txt")){
                                var nit =  new Thread(new FileProcessorRunnable(url, slovo));
                                lista.add(nit);
                                nit.start();
                            }

                        }
                    }
                }
                catch (MalformedURLException exception) {
                    continue;
                }
            }

        }
        catch (IOException ex){

            System.err.println("not found: " + putanja);

        }
        for(var nit : lista){
            try{
                nit.join();
            }
            catch (InterruptedException exception){
                exit(1);
            }
        }
        System.out.println("lines: " + brLin);
        System.out.println("result: " + FileProcessorRunnable.brojPojavljivanja);
    }
}

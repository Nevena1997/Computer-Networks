package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import static java.lang.System.exit;

public class Server {
    public static void main(String[] args) {
        var port = 27182;
        try(ServerSocket server = new ServerSocket(port)){
            while(true){
                Socket soket = server.accept();
                new Thread(new ClientHandler(soket)).start();
            }

        }
        catch(IOException ex){
            exit(1);
        }
    }
}

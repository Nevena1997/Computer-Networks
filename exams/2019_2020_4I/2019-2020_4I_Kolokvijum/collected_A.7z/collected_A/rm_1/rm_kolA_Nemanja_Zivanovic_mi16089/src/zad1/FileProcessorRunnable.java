package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;


public class FileProcessorRunnable implements Runnable {

    URL putanja;
    char slovo;
    public static int brojPojavljivanja = 0;
    FileProcessorRunnable(URL putanja, char slovo){
        this.putanja = putanja;
        this.slovo = slovo;
    }

    @Override
    public void run() {
        int brojKaraktera = 0;
        String linija;
        try(BufferedReader bf = new BufferedReader(new InputStreamReader(putanja.openStream(), StandardCharsets.UTF_8))){
            while((linija = bf.readLine())!=null) {
                brojKaraktera += linija.chars().filter(value -> value == slovo).count();
            }
            synchronized (this){
                brojPojavljivanja += brojKaraktera;
            }
        }
        catch (IOException exception){
            System.err.println("not found: " + putanja.toString());
        }

    }
}

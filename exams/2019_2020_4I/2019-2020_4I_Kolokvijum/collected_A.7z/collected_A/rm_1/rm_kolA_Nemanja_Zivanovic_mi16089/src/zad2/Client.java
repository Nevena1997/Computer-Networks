package zad2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;

import static java.lang.System.exit;

public class Client {
    public static void main(String[] args) {

        var port = 27182;
        Scanner sc = new Scanner(System.in);

        try(Socket soket = new Socket("localhost", port);
            PrintWriter pw = new PrintWriter(new BufferedOutputStream(soket.getOutputStream()), true);
            Scanner scanner = new Scanner(new BufferedInputStream(soket.getInputStream()))) {

            String test = sc.next();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();

            pw.println(test);
            pw.println(x);
            pw.println(eps);

            try{
                System.out.println(scanner.nextLine());
                System.out.println(scanner.nextLine());
            }
           catch(NoSuchElementException e){
                exit(1);
           }
        }
        catch(IOException ex){
            exit(1);
        }
    }
}

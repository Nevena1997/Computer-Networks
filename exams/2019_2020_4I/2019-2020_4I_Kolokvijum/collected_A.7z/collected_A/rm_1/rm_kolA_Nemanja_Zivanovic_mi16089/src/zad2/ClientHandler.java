package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

import static java.lang.System.exit;

public class ClientHandler implements Runnable {

    Socket soket;
    ClientHandler(Socket soket){
        this.soket = soket;
    }

    @Override
    public void run() {

        int brojevauOkolini = 0;
        try(Scanner sc = new Scanner(new BufferedInputStream(soket.getInputStream()));
            PrintWriter pw = new PrintWriter(new BufferedOutputStream(soket.getOutputStream()))){

            String putanja = sc.next();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();
            System.out.println(putanja);
            try(FileInputStream fin = new FileInputStream(putanja)){
                pw.println("Validna putanja");
                Scanner pom = new Scanner(new BufferedInputStream(fin));
                while(pom.hasNext()){
                    if(pom.hasNextDouble()){
                        double broj = pom.nextDouble();
                        if(Double.compare(x, broj) < eps)
                            brojevauOkolini++;
                    }
                    else pom.next();

                }
                pw.println(brojevauOkolini!=0 ? brojevauOkolini : "Fajl ne sadrzi realne brojeve");
            }
            catch (FileNotFoundException exception){
                pw.println("Nevalidna putanja");
            }



        }
        catch (IOException exception){
            exit(1);
        }
        finally {
            try{
                soket.close();
            }
            catch (IOException ex){
                exit(1);
            }
        }
    }
}

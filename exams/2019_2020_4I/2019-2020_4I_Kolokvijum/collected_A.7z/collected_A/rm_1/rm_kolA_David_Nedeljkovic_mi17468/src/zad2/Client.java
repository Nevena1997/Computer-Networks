package zad2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Unesite putanju do fajla i dva realna broja: ");

        String path = sc.next();
        float num1 = sc.nextFloat();
        float num2 = sc.nextFloat();

        try {

            Socket klijent = new Socket("localhost",Server.PORT);
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(klijent.getOutputStream()),true);

            pw.println(path);
            pw.println(num1);
            pw.println(num2);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

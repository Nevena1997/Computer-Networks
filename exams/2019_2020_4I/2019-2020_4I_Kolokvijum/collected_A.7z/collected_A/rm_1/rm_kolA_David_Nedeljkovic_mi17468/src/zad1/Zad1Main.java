package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.StandardSocketOptions;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) throws IOException {

        // Implementirati logiku u jednoj od FileProcessor klasa

        BufferedReader buffRead = new BufferedReader(new InputStreamReader(new FileInputStream("urls.txt")));
        Scanner sc = new Scanner(System.in);
        System.out.println("Ucitajte jedan karakter:");
        char c = sc.next().charAt(0);

        String linija;
        int brLinija = 0;
        while ((linija = buffRead.readLine()) != null){
            URL url;
            try {
                url = new URL(linija);
                brLinija++;
                if (url.getProtocol().equalsIgnoreCase("file") ) {
                    int ind = linija.lastIndexOf("/") + 1;
                    String imeFajla = linija.substring(ind);
                    if(imeFajla.matches("[0-9].txt")){
                        new FileProcessorThread(url, c).start();
                    }
                }

            } catch (MalformedURLException e) {
                System.err.println("Nevalidan url.");
            }

        }
        System.out.println("lines: " + brLinija);
    }
}
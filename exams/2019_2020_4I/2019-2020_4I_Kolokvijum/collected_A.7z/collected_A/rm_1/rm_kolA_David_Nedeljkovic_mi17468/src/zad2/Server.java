package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static final int PORT = 27182;

    public static void main(String[] args) {

        try {
            ServerSocket server = new ServerSocket(PORT);
            System.out.println("Server pokrenut: ");

            while(true) {

                try {
                    Socket klijent = server.accept();
                    new ClientThread(klijent).start();


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

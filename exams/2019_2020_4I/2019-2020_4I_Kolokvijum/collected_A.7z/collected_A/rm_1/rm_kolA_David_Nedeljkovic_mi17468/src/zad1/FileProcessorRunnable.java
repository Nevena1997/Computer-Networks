package zad1;

public class FileProcessorRunnable implements Runnable {
    @Override
    public void run() {
    }
}

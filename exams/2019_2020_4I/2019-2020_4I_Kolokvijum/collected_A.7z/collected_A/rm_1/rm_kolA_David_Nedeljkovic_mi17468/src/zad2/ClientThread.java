package zad2;

import java.io.*;
import java.net.Socket;

public class ClientThread extends  Thread{

    private Socket klijent;
    private BufferedReader br;
    private PrintWriter pw;


    public ClientThread(Socket klijent) {
        this.klijent = klijent;
    }

    @Override
    public void run() {

        try {
            br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            pw = new PrintWriter(new OutputStreamWriter(klijent.getOutputStream()), true);
            String linija;

            String[] niz = new String[3];
            for (int i=0; i < niz.length; i++) {
                niz[i] = br.readLine();
                System.out.println(niz[i]);
            }

            /*
                File f = new File("tests/" + linija);
                String pathAbs = f.getAbsolutePath();
            */

            if(true) { // ako postoji putanja salji indikator 1 inace 0
                pw.println(1);
                //FileInputStream fi = new FileInputStream(""); otvaramo fajl i citamo iz njega
            }
            else {
               pw.println(0);
            }


        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
                pw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {

    private URL url;
    private BufferedReader br;
    private char c;

    public FileProcessorThread(URL url, char c) {
        this.url = url;
        this.c = c;
    }

    @Override
    public void run() {
        try {
            URLConnection u = url.openConnection();
            br = new BufferedReader(new InputStreamReader(u.getInputStream(), StandardCharsets.UTF_8));
            String text;
            int brojKaraktera = 0;
            while ((text = br.readLine()) != null) {
               for (int i =0; i < text.length(); i++) {
                   if(text.charAt(i) == c) {
                       brojKaraktera++;
                   }
               }
            }
            System.out.println("Broj karaktera c je : " + brojKaraktera);
            br.close();

        } catch (IOException e) {
            System.err.println("File ne postojji.");
        }
    }
}

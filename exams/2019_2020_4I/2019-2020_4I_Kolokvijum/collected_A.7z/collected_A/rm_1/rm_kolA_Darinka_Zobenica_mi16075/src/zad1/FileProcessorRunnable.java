package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileProcessorRunnable implements Runnable {

    //List<URL> filePaths = Collections.synchronizedList(new LinkedList<>());
    String c;

    public FileProcessorRunnable(String c){
        this.c = c;
    }

    @Override
    public void run() {
        String fullPath = "/home/ispit/Desktop/tests/urls.txt";
        int lineCounter = 0;
        try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(fullPath), StandardCharsets.UTF_8))) {
            String line;
            //TODO Fix regex
            //Pattern urlPattern = Pattern.compile("^[a-zA-Z0-9]+:[/]{2}[/]*[a-zA-Z0-9.//@]+(:/d+.*)?$");

            int threadCount = 0;

            while((line = buffReader.readLine())!=null){
                lineCounter++;
                //Matcher matcher = urlPattern.matcher(line);
                //if(matcher.find()){
                    //valid url
                    //System.out.println(line);
                    URL url;
                    try{
                        url = new URL(line);
                        //System.out.println(url.getProtocol());
                        if(url.getProtocol().toLowerCase().equals("file") && url.getPath().endsWith(".txt")){
                            new FileProcessorThread(c, url, this).start();
                            threadCount++;
                        }
                    }
                    catch (MalformedURLException e){
                         //System.out.println("MalformedURLException: " + line);
                    }

                //}

                Thread.yield();
            }

            System.out.println("lines: " + lineCounter);

            while(FileProcessorThread.threadCount > 0){
                Thread.yield();
            }

            synchronized (FileProcessorThread.notFound){
                for(String name : FileProcessorThread.notFound){
                    System.out.println("not found: " + name);
                }
            }

            System.out.println("result: " + FileProcessorThread.count);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
    public List<URL> getFilePaths() {
        return filePaths;
    }*/
}

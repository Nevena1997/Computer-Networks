package zad1;

import java.nio.file.Paths;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String c = sc.next();
        while(c.length() > 1){
            System.err.println("Program prima samo jedan karakter");
            c = sc.next();
        }

        // Implementirati logiku u jednoj od FileProcessor klasa
        new Thread(new FileProcessorRunnable(c)).start();

        sc.close();

    }
}

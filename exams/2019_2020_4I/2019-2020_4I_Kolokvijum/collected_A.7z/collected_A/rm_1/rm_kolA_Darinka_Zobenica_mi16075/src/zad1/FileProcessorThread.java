package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;

public class FileProcessorThread extends Thread {
    static{
        count = 0;
        threadCount = 0;
    }

    String c;
    URL url;
    FileProcessorRunnable fp;
    static Integer count;
    static Integer threadCount;
    static List<String> notFound = Collections.synchronizedList(new LinkedList<>());


    public FileProcessorThread(String c, URL url, FileProcessorRunnable fp){
        this.c = c;
        this.url = url;
        this.fp = fp;

        synchronized (threadCount) {
            threadCount++;
        }
    }

    @Override
    public void run() {
        try {
            URLConnection conn = url.openConnection();
            try(BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                int counter = 0;
                while ((line = reader.readLine()) != null) {
                    while (line.contains(c)) {
                        counter++;
                        int index = line.indexOf(c);
                        if (line.length() > index - 1)
                            line = line.substring(index + 1);
                        else break;
                    }
                }

                synchronized (count) {
                    count += counter;
                }
            }

        } catch (IOException e) {
            notFound.add(url.getPath());
        } finally {
            synchronized (threadCount){
                threadCount--;
            }
        }


    }
}

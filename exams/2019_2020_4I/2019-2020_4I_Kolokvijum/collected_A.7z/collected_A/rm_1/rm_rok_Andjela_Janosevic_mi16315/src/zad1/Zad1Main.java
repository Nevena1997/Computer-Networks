package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {
        int line = 0;
        String keyword;

        Scanner sc= new Scanner(System.in);
        keyword = sc.next();

        try(BufferedReader in = new BufferedReader(
                new InputStreamReader(new
                        FileInputStream("/home/ispit/Desktop/tests/urls.txt")));

            BufferedReader in2 = new BufferedReader(
                    new InputStreamReader(new
                            FileInputStream("/home/ispit/Desktop/tests/urls.txt")))
        )
        {
            System.out.println("lines: " + in2.lines().count());
            in2.close();
            String url_string;
            while((url_string = in.readLine()) != null){

                if(!ValidUrl(url_string))
                    continue;

                URL u = new URL(url_string);
                String protocol = u.getProtocol();

                if(protocol.equals("file")){
                    if(u.getFile().endsWith(".txt")){
                        new Thread(new FileProcessorRunnable(u,u.getFile(),keyword)).start();
                    }
                }
            }

            System.out.println("result:  "+FileProcessorRunnable.brojac);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean ValidUrl(String url){
        if(url.startsWith("http") || url.startsWith("file")
                || url.startsWith("ftp") || url.startsWith("FILE"))
            return true;
        return false;
    }

}

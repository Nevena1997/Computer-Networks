package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        String hostname = "localhost";
        try(Socket s = new Socket(hostname,Server.DEFAULT_PORT)){

            try(BufferedWriter out  = new BufferedWriter(
                    new OutputStreamWriter(s.getOutputStream()));
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(s.getInputStream()));
                Scanner sc = new Scanner(System.in);
            ){
                String path = sc.next();
                Double x = sc.nextDouble();
                Double eps = sc.nextDouble();

                out.write(path);
                //out.newLine();
               // out.write(x);
                //out.newLine();
                //out.write(eps);
                out.newLine();
                out.flush();

                System.out.println(in.readLine());

            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

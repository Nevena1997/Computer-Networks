package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class FileProcessorRunnable implements Runnable {

    String filePath;
    URL url;
    String keyword;
    public  static int brojac =0;

    public FileProcessorRunnable(URL url,String filePath,String keyword) {
        this.filePath = filePath;
        this.url = url;
        this.keyword=keyword;
    }

    @Override
    public void run() {

        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(this.filePath), StandardCharsets.UTF_8))
        ){

           String line;
           while((line = in.readLine()) != null) {
               if (line.contains(this.keyword))
                   brojac++;
           }
        }

        catch (FileNotFoundException e) {
            System.out.println("not found: " + this.filePath);
            //e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Server {

    public static int DEFAULT_PORT =27182;
    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(DEFAULT_PORT)){

            while(true){

                Socket client  = server.accept();

                try (BufferedWriter out  = new BufferedWriter(
                        new OutputStreamWriter(client.getOutputStream()));
                     BufferedReader in = new BufferedReader(
                             new InputStreamReader(client.getInputStream()));
                     PrintStream sys = new PrintStream(System.out);
                ){
                    String path = in.readLine();
                    sys.println(path);


                    if(!Files.exists(Paths.get(path))){
                        out.write("Nevalidna putanja");
                    }
                    else{
                        out.write("Validna putanja");

                    }
                    out.newLine();
                    out.flush();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.net.URL;

public class FileProcessorThread extends Thread {


    @Override
    public void run() {
        // TODO
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static final int DEFAULT_PORT = 27182;

    public static void main(String[] args) {
       // System.out.println("Srecno od strane servera!");
        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){
           // System.err.println("Napravljen server; cekamo klijenta");
            while (true){
               // System.err.println("Prihvatili smo klijenta");
                Socket client = server.accept();

                new Thread(new ClientHandleRunnable(client)).start();
            }

        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

public class FileProcessorRunnable implements Runnable {
    URL url;
    public FileProcessorRunnable(URL url){
        this.url = url;
    }
    @Override
    public void run() {
        // TODO
        try {
            URLConnection con = this.url.openConnection();
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

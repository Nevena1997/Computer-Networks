package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandleRunnable implements Runnable {
    Socket client;

    public ClientHandleRunnable(Socket client){
        this.client = client;
    }


    @Override
    public void run() {

        try(BufferedReader in  = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()))

        ){

            String putanja;
            String xstr;
            String epsstr;
            putanja = in.readLine();
            xstr = in.readLine();
            epsstr = in.readLine();

            System.out.println(putanja);
            //System.out.println(xstr);
           // System.out.println(epsstr);
            int br_real = 0;
            try (Scanner sc = new Scanner(new InputStreamReader(new FileInputStream(putanja)))){
                //System.err.println("citam...");

                while (sc.hasNext()){
                    //System.err.println("citam liniju");
                    if(sc.hasNextFloat()) {
                        float broj = sc.nextFloat();
                        br_real +=1;
                    }
                    if (sc.hasNext()){
                        sc.next();
                    }else{
                        break;
                    }

                    //Ovde se proverava da li broj pripada okolini datog broja
                }
                //Server salje broj floatova u falu
                //System.out.println(br_real);
                out.write(br_real + "");
                out.newLine();
                out.flush();
            }catch (IOException e){
                out.write("Nemafajla");
                out.newLine();
                out.flush();
                e.printStackTrace();
            }


        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

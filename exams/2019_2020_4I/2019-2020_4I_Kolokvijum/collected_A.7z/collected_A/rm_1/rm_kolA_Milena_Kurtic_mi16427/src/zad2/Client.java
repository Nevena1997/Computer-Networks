package zad2;
///home/ispit/Desktop/rm_kolA_Milena_Kurtic_mi16427/src/zad2/1.test
import java.io.*;
import java.net.Socket;
import java.util.Scanner;
///home/ispit/Desktop/rm_kolA_Milena_Kurtic_mi16427/src/zad2/1.test
public class Client {
    public static void main(String[] args) {
       // System.out.println("Srecno od strane klijenta!");

        try (Socket client = new Socket("localhost", Server.DEFAULT_PORT);){

            try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                Scanner sc = new Scanner(System.in)
            ){
                System.out.print("ulaz:   ");
                String line = sc.nextLine();
                int indeks = line.indexOf(" ");
                String putanja = line.substring(0, indeks);

                int indeks2 = line.indexOf(" ", indeks+1);
                String xstr = line.substring(indeks+1, indeks2);

                String epsstr = line.substring(indeks2+1);

                //System.out.println(putanja);
                //System.out.println(xstr);
                //System.out.println(epsstr);

                //float x = Float.valueOf(ostatak.trim());


               // BufferedWriter out = new BufferedWriter(new OutputStreamWriter());

                out.write(putanja);
                out.newLine();
                out.flush();
                out.write(xstr);
                out.newLine();
                out.flush();
                out.write(epsstr);
                out.newLine();
                out.flush();



                //System.out.println("Poruka od servera:");
                String poruka = in.readLine();
                if(!poruka.trim().equalsIgnoreCase("Nemafajla")){
                    if (poruka.trim().equalsIgnoreCase("0")){
                        System.out.println("Fajl ne sadrzi realne brojeve");
                    }else {
                        System.out.println(poruka);
                    }
                }




            }



        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

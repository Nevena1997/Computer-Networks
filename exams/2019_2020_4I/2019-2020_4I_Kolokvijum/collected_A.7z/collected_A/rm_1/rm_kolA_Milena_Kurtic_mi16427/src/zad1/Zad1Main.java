package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;


public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

       // System.out.println("Srecno!");

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))){
            String line;
            int brLinija = 0;
            while ((line = in.readLine()) != null){
                //System.out.println(in.readLine());
                brLinija += 1;
                try {
                    URL u = new URL(line);

                    String protokol = u.getProtocol();
                    //System.out.println(u.getProtocol());
                    String fajl0 = u.getFile();
                    //System.out.println(u.getFile());
                    int indeks = fajl0.lastIndexOf('.');
                    if(indeks != -1){
                        //System.out.println(indeks);
                        String file = fajl0.substring(indeks + 1);
                        //System.out.println(file);
                        if(file.trim().equals(".txt") || protokol.trim().equalsIgnoreCase("FILE")){
                            Thread t = new Thread(new FileProcessorRunnable(u));
                        }
                    }





                }catch (MalformedURLException e){
                    continue;
                }


            }
            System.out.println("lines:    " + brLinija);

        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

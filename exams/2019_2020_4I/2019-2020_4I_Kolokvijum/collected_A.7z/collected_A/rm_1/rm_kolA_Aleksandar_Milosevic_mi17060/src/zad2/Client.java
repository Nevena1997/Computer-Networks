package zad2;

import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

           try {
               Socket klijent = new Socket(Server.hostname, 27182);
               Scanner sc = new Scanner(System.in);
               String dir = sc.next();
               Double x = sc.nextDouble();
               Double eps = sc.nextDouble();


           }
        catch(IOException e){
            e.printStackTrace();
        }



    }

}

package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;



public class Zad1Main {
    private static int brojac=0;
    public static int num=0;
    private static int brojacLinija=0;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        Scanner ulaz = new Scanner(System.in);
        System.out.println("ulaz: ");
        String s = ulaz.next();
        char c = s.charAt(0);
        System.out.println(c);
        prebrojLinije(c);
        System.out.println("lines: " + brojac);
        System.out.println("result: "+ num);
    }


public static void prebrojLinije(char c){
    try{
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")));
        String s;
        while ((s = reader.readLine())!=null){
            brojac++;
            try{
                URL u = new URL(s);
               if (u.getProtocol().equals("file") && u.getFile().contains(".txt")){
                   FileProcessorThread fpt = new FileProcessorThread(u, c);
                   fpt.start();
                }
                }
            catch(MalformedURLException e){
                     continue;
                }

        }
    }
        catch(IOException e) {
            e.printStackTrace();
        }
    }
}

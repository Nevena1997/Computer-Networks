package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

public class Server {

    public static String hostname = "localhost";
    public static void main(String[] args) {
        try{
            ServerSocket server = new ServerSocket(27182);
            System.out.println(server.getLocalSocketAddress());
            server.accept();
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
}

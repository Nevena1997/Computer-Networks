package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.Buffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class FileProcessorThread extends Thread {

    private URL u;
    private static int ukupanBrojac=0;
    private int brojac;
    private char c;

    public FileProcessorThread(URL u, char c) {
        this.u = u;
        this.c = c;
    }

    @Override
    public void run() {
        try{
        BufferedReader buf = new BufferedReader(new InputStreamReader(new FileInputStream(u.getFile()), StandardCharsets.UTF_8));
        String x;
        while((x = buf.readLine())!=null){
            brojac+=slova(x,c);
        }
            Zad1Main.num += brojac;
        return;
    }catch(IOException e){
            System.out.println("Not found: " + u.getFile());
            return;
        }

    }

    private static int slova(String s, char c){
        int number = 0;
        for (int i = 0; i < s.length(); i++) {
                if (s.charAt(i)==c){
                    number++;
                }
        }
        return number;
    }

    public static int getUkupanBrojac() {
        return ukupanBrojac;
    }
}

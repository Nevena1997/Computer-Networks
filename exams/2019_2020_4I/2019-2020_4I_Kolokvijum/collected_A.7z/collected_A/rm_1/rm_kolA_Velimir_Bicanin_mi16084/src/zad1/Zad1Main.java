package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {

    public static int kar = 0;

    public static void main(String[] args) {

        int br_url = 0;
        int br_karaktera = 0;

        Scanner sin = new Scanner(System.in);
        char c = sin.next().charAt(0);

        try (Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("../tests/urls.txt"))))) {

            String urlString;
            while (sc.hasNextLine()) {
                urlString = sc.nextLine();
                br_url++;

                if (isURL(urlString)) {
                    try {
                        URL url = new URL(urlString);
                        int index = urlString.lastIndexOf(".");
                        if (index == -1)
                            continue;

                        String txt = urlString.substring(index);
                        if (txt == null || !(txt.equals("txt")))
                            continue;

                        if (url.getProtocol().toLowerCase().equals("file")) {
                            new FileProcessorThread(url, c).start();
                        }

                    } catch (MalformedURLException e) {

                    }
                }

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }

        } catch (FileNotFoundException e) {
            System.out.println("Fajl ne postoji.");
            e.printStackTrace();
        }

        System.out.println("lines:\t" + br_url);
        System.out.println("result: " + br_karaktera);

    }

    private static boolean isURL(String url) {

        int index1 = url.indexOf(":");
        if (index1 == -1)
            return false;

        String protocol = url.substring(0, index1);
        if (!(protocol.toLowerCase().equals("http") || protocol.toLowerCase().equals("file") || protocol.toLowerCase().equals("ftp") || protocol.toLowerCase().equals("https") || protocol.toLowerCase().equals("ssh"))) {
            return false;
        }
        /*
        int index2;
        if (protocol.toLowerCase().equals("file")) {
            if ((url.charAt(index1+1) ==  '/' && url.charAt(index1+2) ==  '/' && url.charAt(index1+3) ==  '/')) {
                return false;
            }
            index2 = index1+3;
        } else {
            if ((url.charAt(index1+1) ==  '/' && url.charAt(index1+2) ==  '/')) {
                return false;
            }
            index2 = index1+2;
            String ip;
            int index3 = url.indexOf(':', index2);
            if (index3 != -1) {
                ip = url.substring(index2, index3);
                if (ip.length() == 0) {
                    return false;
                }
            } else {
                return true;
            }
        }*/

        return true;
    }
}

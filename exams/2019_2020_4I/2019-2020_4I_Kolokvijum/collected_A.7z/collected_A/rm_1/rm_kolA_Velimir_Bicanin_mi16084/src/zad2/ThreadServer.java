package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ThreadServer implements Runnable {

    private Socket client;

    public ThreadServer(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try (Scanner in = new Scanner(new BufferedReader(new InputStreamReader(this.client.getInputStream())));
             PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream())))) {

            String putanja = in.next();
            double x = in.nextDouble();
            double eps = in.nextDouble();

            System.out.println(putanja);
            System.out.println(x);
            System.out.println(eps);

            int rez = 0;
            try (Scanner fileIn = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja), StandardCharsets.UTF_8)))) {

                out.println(1);
                out.flush();
                double broj;
                boolean done = false;
                while (!done) {
                    if (fileIn.hasNextDouble()) {
                        broj = fileIn.nextDouble();
                        System.out.println(broj);
                        if (broj > x - eps && broj < x + eps)
                            rez++;
                    } else if (fileIn.hasNext()) {
                        String s = fileIn.next();
                        continue;
                    } else {
                        done = true;
                    }

                }
            } catch (FileNotFoundException e) {
                out.println(0);
                out.flush();
            }

            out.print(rez);
            out.flush();

        } catch (IOException e) {
            System.out.println("Veza zatvorena");
        }

    }
}

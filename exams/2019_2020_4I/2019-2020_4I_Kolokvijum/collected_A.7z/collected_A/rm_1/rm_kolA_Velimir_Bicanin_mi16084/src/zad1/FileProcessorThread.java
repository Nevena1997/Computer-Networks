package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class FileProcessorThread extends Thread {

    private URL url;
    private char c;

    public FileProcessorThread(URL url, char c) {
        this.url = url;
        this.c = c;
    }

    @Override
    public void run() {

        try (Scanner in = new Scanner(new BufferedReader(new InputStreamReader(this.url.openStream(), StandardCharsets.UTF_8)))) {

            int br_u_fajlu = 0;
            while (in.hasNext()) {
                String rec = in.next();
                //System.out.println(rec);
                br_u_fajlu += prebroj(rec);
            }

            uvecaj(br_u_fajlu);

        } catch (IOException e) {
            System.out.println("not found: " + this.url.getPath());
        }
    }

    private int prebroj(String s) {
        int num = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == this.c)
                num += 1;
        }
        return num;
    }

    private synchronized void uvecaj(int n) {
        Zad1Main.kar += n;
    }

}

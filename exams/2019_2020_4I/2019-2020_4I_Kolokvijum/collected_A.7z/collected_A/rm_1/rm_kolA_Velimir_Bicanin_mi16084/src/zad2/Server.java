package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {

    public static final int PORT_SERVER = 27128;

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(PORT_SERVER)) {
            while (true) {
                Socket client = server.accept();

                new Thread(new ThreadServer(client)).start();
            }
        } catch (IOException e) {
            System.out.println("Server nije napravljen.");
            e.printStackTrace();
        }


    }
}

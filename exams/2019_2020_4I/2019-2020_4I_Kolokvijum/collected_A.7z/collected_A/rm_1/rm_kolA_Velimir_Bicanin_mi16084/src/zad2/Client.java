package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try {

            Scanner sc = new Scanner(System.in);
            String putanja = sc.next();
            double x = sc.nextDouble();
            double eps = sc.nextDouble();

            Socket socket = new Socket("localhost", Server.PORT_SERVER);

            try (PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())));
                Scanner in = new Scanner(new BufferedReader(new InputStreamReader(socket.getInputStream())))) {

                out.println(putanja);
                out.println(x);
                out.println(eps);
                out.flush();

                int indikator = in.nextInt();

                if (indikator == 1) {
                    System.out.println("Validna putanja");
                    int rez = in.nextInt();
                    if (rez == 0) {
                        System.out.println("Fajl ne sadrzi realne brojeve");
                    } else {
                        System.out.println(rez);
                    }
                } else {
                    System.out.println("Nevelidna putanja.");
                }


            }

            socket.close();

        } catch (IOException e) {
            System.out.println("Veza nije uspostavljena.");
            e.printStackTrace();
        }
    }
}

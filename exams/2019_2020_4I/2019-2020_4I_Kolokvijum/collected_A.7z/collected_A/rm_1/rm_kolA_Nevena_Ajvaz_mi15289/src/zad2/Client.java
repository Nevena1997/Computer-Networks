package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {


        try {
            Socket soc = new Socket("localhost", Server.PORT);

            Scanner sc = new Scanner(System.in);



            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(soc.getOutputStream()));
            // Saljem serveru

            while(sc.hasNextLine()) {
                String putanja = sc.nextLine();
                bw.write(putanja);
                bw.newLine();
                bw.flush();

                float x = sc.nextFloat();
                bw.write((int) x);
                bw.newLine();
                bw.flush();

                float eps = sc.nextFloat();
                bw.write((int) eps);
                bw.newLine();
                bw.flush();
            }

            // Citam od servera

            BufferedReader br = new BufferedReader(new InputStreamReader(soc.getInputStream()));

            sc.close();
            br.close();
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Srecno od strane klijenta!");
    }
}

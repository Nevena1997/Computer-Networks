package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ObradiKlijentaRunnable implements Runnable {

    private Socket klijent;

    ObradiKlijentaRunnable(Socket klijent) {
        this.klijent = klijent;
    }


    @Override
    public void run() {

        int fleg = 0;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            OutputStream o = new BufferedOutputStream(System.out);

            Scanner sc = new Scanner(new InputStreamReader(new FileInputStream(br.readLine())));

            fleg = 1;

            // Pisi klijentu
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            // fajl
            int b0 = br.read();
            o.write(b0);
            o.flush();

            // x
            int x = br.read();
            o.write(x);
            o.flush();

            // eps
            int eps = br.read();
            o.write(eps);
            o.flush();

            int brojac = 0;
            if((vaziUslov(x, eps))){
                brojac++;
            }

            sc.close();
            br.close();
            o.close();

        } catch (IOException e) {
            System.err.println("Fajl ne postoji");
            fleg = 0;
            e.printStackTrace();
        }
    }

    private boolean vaziUslov(int b, int b1) {
        return true;

        //        if(x - eps) <= x <= (x+eps)){
//            return true;
//        }
//        return false;
    }
}

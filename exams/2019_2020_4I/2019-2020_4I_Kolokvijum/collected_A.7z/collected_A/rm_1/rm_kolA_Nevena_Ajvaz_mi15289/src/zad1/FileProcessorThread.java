package zad1;

public class FileProcessorThread extends Thread {
    public FileProcessorThread(FileProcessorRunnable fileProcessorRunnable) {
    }

    @Override
    public void run() {
        // TODO
    }
}

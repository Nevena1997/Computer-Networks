package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        System.out.println("Unesite karakter:");
        Scanner s = new Scanner(System.in);

        String c = s.next();
        //char c = (char) s.nextInt();

        try {
            Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"))));
            int linije = 0;
            String linija;
            while (sc.hasNextLine()){
                linije++;

                linija = sc.nextLine();
                if(validanURL(linija)){
                    URL u = new URL(linija);
                    String protokol = u.getProtocol();
                    if(protokol.equals("file")){
                        if(linija.endsWith("txt")){
                            new FileProcessorThread(new FileProcessorRunnable(u, c)).start();
                        }
                    }
                }
            }

            System.out.println(linije);
            sc.close();
        } catch (FileNotFoundException | MalformedURLException e) {
            System.err.println("Fajl ne postoji");
            e.printStackTrace();
        }
        // Implementirati logiku u jednoj od FileProcessor klasa

        s.close();
        System.out.println("Srecno!");
    }

    private static boolean validanURL(String linija) {
        if (!linija.contains(":")){
            return false;
        }
        return true;
    }
}

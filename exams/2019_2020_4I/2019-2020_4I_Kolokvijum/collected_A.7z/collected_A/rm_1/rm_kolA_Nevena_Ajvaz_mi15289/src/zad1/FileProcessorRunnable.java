package zad1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class FileProcessorRunnable implements Runnable {
    private URL u;
    private String c;

    public FileProcessorRunnable(URL u, String c) {
        this.u = u;
        this.c = c;
    }

    @Override
    public void run() {
        try {
            int brojac = 0;
            URLConnection uc = u.openConnection();
            Scanner sc = new Scanner(new BufferedInputStream(uc.getInputStream()), StandardCharsets.UTF_8);

            String linija;
            while (sc.hasNextLine()){
                linija = sc.nextLine();
                if(linija.indexOf(c) != -1){
                    brojac++;
                }
            }
            System.out.println(brojac);
            sc.close();
        } catch (IOException e) {
            System.err.println("Fajl nije postojeci!");
            e.printStackTrace();
        }

        // TODO
    }
}

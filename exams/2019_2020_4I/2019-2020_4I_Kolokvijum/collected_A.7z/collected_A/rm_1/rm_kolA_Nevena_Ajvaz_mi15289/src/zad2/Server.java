package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.chrono.IsoEra;

public class Server {

    public static final int PORT = 27182;

    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(PORT)){

            while(true){

                Socket klijent = server.accept();
                System.err.println("Primio sam kijanta!");


                new Thread(new ObradiKlijentaRunnable(klijent)).start();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("Srecno od strane servera!");
    }
}

package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Zad1Main {

    public static void main(String[] args) {

        final List<URL> urls = Collections.synchronizedList(new LinkedList<>());
        int num_of_lines = 0;
        final int NUM_OF_THR = 6;
        String c;
        try(Scanner sc = new Scanner(System.in)) {
            c = sc.next();
            if (c.length() != 1)
                throw new IllegalCallerException("Nedozvoljena operacija");

            for (int i = 0; i< NUM_OF_THR; i++) {
                new Thread(new FileProcessorRunnable(urls, c)).start();
            }
        }catch (IllegalCallerException e)
        {
            e.printStackTrace();
        }
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(
                "/home/ispit/Desktop/tests/urls.txt"), StandardCharsets.UTF_8))){
            for(String line = in.readLine(); line != null; line = in.readLine()){
                num_of_lines++;
                if(isURL(line)) {
                    URL url = new URL(line);

                    while (urls.size() > NUM_OF_THR) {
                        Thread.sleep((long) (1000.0 / NUM_OF_THR));
                    }
                    synchronized (urls) {
                        urls.add(0, url);
                        urls.notifyAll();
                    }
                    Thread.yield();
                }
            }
            synchronized (urls){
                urls.notifyAll();
            }
            Thread.yield();
            System.out.println(num_of_lines);

        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }

        System.out.println("Srecno!");
    }

    private static boolean isURL(String line) {
        int index = line.indexOf(':');
        if(index == -1)
            return false;
        String tmp = line.substring(0,index);
        return tmp.contains("http") || tmp.contains("file") || tmp.contains("FILE") || tmp.contains("ssh") || tmp.contains("ftp");
    }
}

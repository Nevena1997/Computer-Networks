package zad1;

import java.io.*;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

public class FileProcessorRunnable implements Runnable {

    private final List<URL> urls;
    private String c;

    FileProcessorRunnable(List<URL> urls, String c) {
        this.urls = urls;
        this.c = c;
    }

    @Override
    public void run() {
        for (URL url = this.fetchNextOne(); url != null ; url=this.fetchNextOne()){
            if(url.getProtocol().equals("file")){
                String str = url.getFile();
                int index = str.lastIndexOf('.');
                String tmp = str.substring(index);
                if(tmp.equals("txt")){
                    try(Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(str))))){
                        int brojac = 0;
                        while (sc.hasNext()){
                            String s = sc.next();
                            if(s.equals(c))
                                brojac++;
                        }
                        System.out.println(brojac);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private URL fetchNextOne() {
        if(this.urls.size()==0) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        synchronized (this.urls){
            return this.urls.remove(0);
        }

    }

}

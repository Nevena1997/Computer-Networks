package zad2;

import java.io.*;
import java.net.Socket;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyThread extends Thread{

    private Socket sock;
    private Scanner in;
    private PrintWriter pw;

    public MyThread(Socket sock){
        this.sock = sock;
        try{
            in = new Scanner(new BufferedReader(new InputStreamReader(sock.getInputStream())));
            pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(sock.getOutputStream())), true);

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        String direktorijum = "/home/ispit/Desktop/tests/";
        /*System.out.println("bla");
        System.err.println(in.nextLine());
        String putanja = in.next();
        System.out.println(putanja);
        double x = in.nextDouble();
        double eps = in.nextDouble();
        System.out.println(putanja);*/
        //System.out.println("bla");
        String linija = in.nextLine();
        //System.out.println(linija);
        Scanner s = new Scanner(linija);
        String putanja = s.next();
        System.out.println(putanja);
        double x = s.nextDouble();
        double eps = s.nextDouble();
        s.close();
        //System.out.println(x + " " + eps);
        String apsolutna_putanja = direktorijum + putanja;

        System.out.println(direktorijum + putanja);
        try(Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(apsolutna_putanja))))){
            pw.print(true);
            pw.print('\n');
            pw.flush();
            int broj_realnih_brojeva = 0;
            while(sc.hasNext()){
                try{
                    double d = sc.nextDouble();
                    if (d > x - eps && d < x + eps){
                        broj_realnih_brojeva++;
                    }
                }catch(InputMismatchException e){
                    sc.next();

                }
            }

            pw.print(broj_realnih_brojeva);

        }catch(IOException e){
            pw.print(false);
            pw.print('\n');
            pw.flush();
        }

    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        String hostname = "localhost";


        try(Socket sock = new Socket(hostname, Server.port);
            Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(sock.getInputStream())));
            PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(sock.getOutputStream())), true);
            Scanner ulaz = new Scanner(System.in)){

            /*String putanja = ulaz.next();
            double x = ulaz.nextDouble();
            double eps = ulaz.nextDouble();

            System.out.println(putanja);
            System.out.println(x);
            System.out.println(eps);

            //dir2./1.test 3.5 0.01
            pw.print(putanja);
            pw.flush();
            pw.print(x);
            pw.flush();
            pw.print(eps);
            pw.flush();*/

            String linija = ulaz.nextLine();
            pw.write(linija);
            pw.write('\n');
            pw.flush();

            //System.out.println("ovde");

            if(sc.nextBoolean()){
                System.out.println("Validna putanja.");
            }else{
                System.out.println("Nevalidna putanja.");
            }

            int broj_realnih_brojeva = sc.nextInt();
            if (broj_realnih_brojeva == 0){

            }


        }catch (IOException e){
            e.printStackTrace();
        }


        System.out.println("Srecno od strane klijenta!");
    }
}

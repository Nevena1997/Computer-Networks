package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {

    public static int port = 27182;

    public static void main(String[] args)
    {
        try(ServerSocket server = new ServerSocket(port)){

            while(true){

                Socket sock = server.accept();
                new MyThread(sock).start();

            }

        }catch(IOException e){
            e.printStackTrace();
        }

        System.out.println("Srecno od strane servera!");
    }
}

package zad1;

import zad2.MyThread;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {

    public static AtomicInteger zbir = new AtomicInteger(0);



    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        String ime_fajla = "/home/ispit/Desktop/tests/urls.txt";
        try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(ime_fajla)))){

            System.out.println("Unesite karakter :");
            Scanner sc = new Scanner(System.in);

            char c = sc.next().charAt(0);

            sc.close();

            int broj_linija = 0;
            int broj_url = 0;
            int broj_validnih = 0;
            String linija;
            URL u;
            while((linija = br.readLine()) != null){
                broj_linija++;
                try{
                    u = new URL(linija);
                    broj_url++;
                    if (u.getProtocol().equalsIgnoreCase("FILE") && u.getFile().endsWith(".txt")){
                        broj_validnih++;
                        //System.out.println(linija);
                        new FileProcessorThread(u, c).start();

                    }
                } catch(MalformedURLException e){
                    continue;
                }
            }


            Thread.sleep(5000);
            System.out.println("lines: " + broj_linija);
            System.out.println("result: " + zbir.get());

        }catch(IOException | InterruptedException e){
            e.printStackTrace();
        }

        System.out.println("Srecno!");
    }
}

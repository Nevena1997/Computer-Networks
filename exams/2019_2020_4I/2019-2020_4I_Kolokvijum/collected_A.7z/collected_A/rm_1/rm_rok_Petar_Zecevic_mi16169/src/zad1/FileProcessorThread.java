package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {

    private URL u;
    private char c;
    private int brojac;

    public FileProcessorThread(URL u, char c){
        this.u = u;
        this.c = c;
        this.brojac = 0;
    }

    @Override
    public void run() {
        try(InputStreamReader isr = (new InputStreamReader(u.openStream(), StandardCharsets.UTF_8))){

            int b;
            char karakter;
            while((b = isr.read()) != -1){
                karakter = (char)b;
                if(Character.toString(karakter).equals(Character.toString(c))){
                    brojac++;
                }
            }

            Zad1Main.zbir.getAndAdd(brojac);

        }catch(IOException e){
            System.out.println("not found: " + u.getFile());
        }
    }
}

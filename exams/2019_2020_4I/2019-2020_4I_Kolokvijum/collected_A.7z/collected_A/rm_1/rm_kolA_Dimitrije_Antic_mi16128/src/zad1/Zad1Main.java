package zad1;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {

    public static boolean shouldProcess(URL url) {
        if (url.getProtocol().equals("file")) {
            int idx = url.getFile().lastIndexOf(".");
            if (idx != -1 && url.getFile().substring(idx).equals(".txt"))
                return true;
        }

        return false;
    }


    public static void main(String[] args) {
        int lines = 0;

        List<URL> urls = new LinkedList<>();

        List<FileProcessorThread> threads = new LinkedList<>();

        AtomicInteger counter = new AtomicInteger(0);

        // Get users input
        Scanner stdin = new Scanner(System.in);

        char search = stdin.next().charAt(0);

        stdin.close();

        try (Scanner sc = new Scanner(
                new BufferedInputStream(new FileInputStream(new File("/home/ispit/Desktop/tests/urls.txt"))), StandardCharsets.UTF_8
        )) {
            while (sc.hasNextLine()) {
                String path = sc.nextLine();
                lines++;

                try {
                    URL u = new URL(path);

                    if (shouldProcess(u)) {
                        urls.add(u);
                    }
                } catch (MalformedURLException e) {
                    //TODO something
//                    System.err.println(path + " isnt a valid URL.");
                }
            }

            System.out.println("Lines:\t\t" + lines);
        } catch (FileNotFoundException e) {
            System.err.println("FileNotFoundException in main.");
        }

        // Starting workers
        for (URL u : urls) {
            FileProcessorThread t = new FileProcessorThread(u, search, counter);
            t.start();
            threads.add(t);
        }

        // Waiting workers to finish
        for (FileProcessorThread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                System.err.println("One of the workers has been interrupted.");
            }
        }

        System.out.println("result:\t\t" + counter);
    }
}

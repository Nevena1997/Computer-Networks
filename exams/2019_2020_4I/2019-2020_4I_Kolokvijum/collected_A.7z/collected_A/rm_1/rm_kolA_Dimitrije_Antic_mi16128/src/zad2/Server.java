package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static int DUMMY_PORT = 27182;

    public static void main(String[] args) {
        try {
            ServerSocket socket = new ServerSocket(DUMMY_PORT);

            System.err.println("Listening on port: " + DUMMY_PORT);

            while (true) {
                Socket clientSock = socket.accept();

                System.err.println("Accepted client.");

                new Worker(clientSock).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

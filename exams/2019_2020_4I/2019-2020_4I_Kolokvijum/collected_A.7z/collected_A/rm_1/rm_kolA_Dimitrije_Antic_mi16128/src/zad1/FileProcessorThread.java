package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class FileProcessorThread extends Thread {
    private URL url;
    private char searchChar;
    private AtomicInteger counter;

    public FileProcessorThread(URL url, char searchChar, AtomicInteger counter) {
        this.url = url;
        this.searchChar = searchChar;
        this.counter = counter;
    }

    @Override
    public void run() {

        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        this.url.openStream(), StandardCharsets.UTF_8)
        )) {
            String line;
            while ((line = in.readLine()) != null) {
                char[] charArr = line.toCharArray();

                for (char c : charArr) {
                    if (c == searchChar) {
                        this.counter.getAndAdd(1);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("not found:\t" + url.getFile());
        } catch (IOException e1) {
            System.err.println("IOexception in thread " + Thread.currentThread().getId());
        }
    }
}

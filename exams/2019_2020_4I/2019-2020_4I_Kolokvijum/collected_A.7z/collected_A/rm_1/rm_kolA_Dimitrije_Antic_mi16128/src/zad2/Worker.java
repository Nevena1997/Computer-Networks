package zad2;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class Worker extends Thread {
    private Socket socket;

    public Worker(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader clientInt = new BufferedReader(
                new InputStreamReader(new BufferedInputStream(socket.getInputStream()))
        );
         PrintWriter clientOut = new PrintWriter(
                 new OutputStreamWriter(socket.getOutputStream()), true
        )) {
            String msg = clientInt.readLine();
            String[] tokens = msg.split(" ");

            // Should use Paths.get
            String path = "/home/ispit/Desktop/tests/" + tokens[0];
            double x = Double.parseDouble(tokens[1]);
            double eps = Double.parseDouble(tokens[2]);

            System.out.println(path);

            try (BufferedReader fin = new BufferedReader(
                    new InputStreamReader(
                            new File(path).toURI().toURL().openStream(), StandardCharsets.UTF_8)
            )) {
                clientOut.println("valid_path");

                String line;
                int cnt = 0;
                boolean hasDouble = false;

                while ((line = fin.readLine()) != null) {
                    String[] ltokens = line.split(" ");

                    for (String token : ltokens) {
                        try {
                            double d = Double.parseDouble(token);

                            if (d >= x - eps && d <= x + eps) {
                                cnt++;
                                hasDouble = true;
                            }
                        } catch (NumberFormatException ne) {
                            // TODO something
                            continue;
                        }
                    }
                }

                if (!hasDouble) {
                    clientOut.println("Fajl ne sadrzi realne brojeve.");
                } else {
                    clientOut.println(cnt);
                }

            } catch (FileNotFoundException e1) {
                clientOut.println("not_valid_path");
            }
        } catch (IOException e) {
            System.err.println("IOException in worker " + Thread.currentThread().getId());
        } catch (NullPointerException e1) {
            System.err.println("Some resource is disposed before it should be, or client is gone.");
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        PrintWriter serverOut = null;
        BufferedReader serverIn = null;

        try (Scanner stdin = new Scanner(System.in)) {
            Socket socket = new Socket("localhost", Server.DUMMY_PORT);

            serverOut = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream()), true
            );

            serverIn = new BufferedReader(
                    new InputStreamReader(new BufferedInputStream(socket.getInputStream()))
            );

            String path = stdin.next();
            double x = stdin.nextDouble();
            double eps = stdin.nextDouble();

            String msg = path + " " + x + " " + eps+"\n";

            serverOut.println(msg);

            // Get valid_path indicator
            String response = serverIn.readLine();

            if (response.equals("not_valid_path")) {
                System.out.println("Putanja nije validna");
            } else if (response.equals("valid_path")) {
                System.out.println("Putanja je validna");

                response = serverIn.readLine();

                System.out.println(response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            serverOut.close();
            try {
                serverIn.close();
            } catch (IOException e) {
//                e.printStackTrace();
            }
        }
    }
}

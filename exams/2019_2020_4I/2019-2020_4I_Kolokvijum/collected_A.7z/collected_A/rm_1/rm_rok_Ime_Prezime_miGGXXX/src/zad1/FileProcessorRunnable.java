package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class FileProcessorRunnable implements Runnable {
    private  URL u;
    private AtomicInteger broj;
    private  Lock lock;
    FileProcessorRunnable(URL url, AtomicInteger broj_linija){
        u=url;
        broj=broj_linija;

    }
    @Override
    synchronized public void run () {
        // TODO
        try(BufferedReader br=new BufferedReader(new InputStreamReader(u.openStream(), StandardCharsets.US_ASCII))){
            int broj_linija=0;
            String linija;
            while((linija=br.readLine())!=null){
                broj_linija++;
            }
            broj.addAndGet(broj_linija);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

package zad1;

import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        System.out.println("Srecno!");

        new Thread(new FileProcessorThread("/home/ispit/Desktop/tests")).start();

    }
}

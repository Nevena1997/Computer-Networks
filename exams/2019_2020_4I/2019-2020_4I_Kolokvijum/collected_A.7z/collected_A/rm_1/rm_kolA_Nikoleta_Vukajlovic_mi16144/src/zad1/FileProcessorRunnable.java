package zad1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class FileProcessorRunnable implements Runnable {
    private URL u;
    private FileProcessorThread fpt;

    FileProcessorRunnable(URL u, FileProcessorThread ftp){
        this.u = u;
        this.fpt = ftp;
    }

    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(this.u.openStream(), StandardCharsets.UTF_8))) {
            String line;
            int num = 0;
            while((line = in.readLine())!= null){
                for(int i = 0; i < line.length(); i++){
                    if(line.charAt(i) == this.fpt.getChar().charAt(0))
                        num++;
                }
            }
            this.fpt.setNum(num);
        } catch (FileNotFoundException e){
            System.out.println("File not found " + u.getFile());
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}

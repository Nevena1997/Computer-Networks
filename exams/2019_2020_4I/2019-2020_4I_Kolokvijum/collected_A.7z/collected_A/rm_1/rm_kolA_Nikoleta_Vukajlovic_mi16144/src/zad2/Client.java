package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        try(Socket socket = new Socket("localhost", Server.DEFAULT_SERVER);
            BufferedReader networkIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter networkOut = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
        ){
            String line = userIn.readLine();
            networkOut.write(line);
            networkOut.newLine();
            networkOut.flush();

            String response1 = networkIn.readLine().trim();
            if(response1.trim().equalsIgnoreCase("Nije validna putanja"))
                System.out.println(response1);
            else {
                System.out.println(response1);
                String response2 = networkIn.readLine().trim();
                int broj = Integer.parseInt(response2);
                if (broj != 0)
                    System.out.println(broj);
                else
                    System.out.println("Fajl ne sadrzi realne brojeve");
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import javax.xml.stream.events.Characters;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandler extends Thread{
    private Socket socket;

    ClientHandler(Socket socket){
        this.socket = socket;
    }

    public void run(){
        try(BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))
        ) {
            String line = in.readLine();
            String[] tokeni = line.split(" ");
            String putanja = tokeni[0];
            double x = Double.parseDouble(tokeni[1]);
            double eps = Double.parseDouble(tokeni[2]);
            System.out.println(putanja);
            try {
                Scanner fileIn = new Scanner(new FileInputStream(putanja));

                int num = 0;
                double x1 = x - eps;
                double x2 = x + eps;
                double broj;
                while(fileIn.hasNextDouble()){
                    broj = fileIn.nextDouble();
                    if (broj > x1 && broj < x2)
                        num++;
                }
                out.write("Validna putanja\n" + num);
                out.newLine();
                out.flush();
                fileIn.close();
            }
            catch (FileNotFoundException e){
                out.write("Nije validna putanja");
                out.newLine();
                out.flush();
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

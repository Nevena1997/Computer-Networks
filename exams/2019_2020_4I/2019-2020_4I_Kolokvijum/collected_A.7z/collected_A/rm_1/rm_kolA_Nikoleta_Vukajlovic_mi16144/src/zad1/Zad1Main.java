package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Zad1Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite karakter: ");
        String c = sc.next();
        if(c.length() != 1)
            System.out.println("Niste uneli jedan karakter");
        sc.close();

        int num = 0;
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))) {
            String line;
            while((line = in.readLine())!= null){
                    num++;
            }
            System.out.println("lines: " + num);
        } catch (
                FileNotFoundException e) {
            e.printStackTrace();
        } catch (
                IOException e) {
            e.printStackTrace();
        }

        int numOfCharacters = 0;
        FileProcessorThread fp = new FileProcessorThread(c, numOfCharacters);
        fp.start();

    }

    public static boolean isValidUrl(String line){
        if(!line.startsWith("htttp://") && !line.startsWith("file://") && !line.startsWith("ftp://"))
            return true;
        else
            return false;
    }
}

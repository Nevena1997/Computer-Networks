package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorThread extends Thread {
    private String c;
    private int num;
    private Lock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();

    FileProcessorThread(String c, int num){
        this.c = c;
        this.num = num;
    }

    @Override
    public void run() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))) {
            String line;
            while((line = in.readLine())!= null){
                URL u = new URL(line.trim());
                String protocol = u.getProtocol();
                int indexOf = line.lastIndexOf('.');
                if(indexOf == -1)
                    continue;
                String extension = line.substring(indexOf+1);
                if(protocol.equalsIgnoreCase("file") && extension.equalsIgnoreCase("txt")){
                    new FileProcessorRunnable(u, this);
                }
            }
            System.out.println("lines: " + num);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e){
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getChar(){
        return this.c;
    }

    public void setNum(int num){
        this.lock.lock();
        this.num += num;
        this.lock.unlock();
    }

    public int getNum(){
        return this.num;
    }
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static final int DEFAULT_SERVER = 27182;

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(DEFAULT_SERVER)) {
            while(true){
                Socket client = server.accept();
                new ClientHandler(client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

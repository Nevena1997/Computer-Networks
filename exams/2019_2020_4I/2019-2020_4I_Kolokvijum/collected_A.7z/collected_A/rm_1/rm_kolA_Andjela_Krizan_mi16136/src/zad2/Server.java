package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

public class Server {

    public static final int PORT=27182;

    public static void main(String[] args) {
        //System.out.println("Srecno od strane servera!");
        try(ServerSocket server=new ServerSocket(PORT)){

            while(true){
                Socket client=server.accept();

                Thread t=new Thread(new NitiZaDrugiZadatak(client));
                t.start();

            }


        } catch (IOException e) {

            e.printStackTrace();
        }


    }
}

package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

public class NitiZaDrugiZadatak implements Runnable {


    private final Socket client;

    public NitiZaDrugiZadatak(Socket client) {
        this.client=client;
    }

    @Override
    public void run() {
        try{
            BufferedReader in= new BufferedReader(new InputStreamReader(client.getInputStream()));

            String putanja = in.readLine();
            String x=in.readLine();
            String eps=in.readLine();

            System.out.println("izlaz server: " + putanja);

            in.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

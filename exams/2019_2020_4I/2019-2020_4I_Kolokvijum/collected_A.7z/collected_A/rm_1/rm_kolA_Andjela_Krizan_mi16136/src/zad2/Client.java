package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;


public class Client {

    public static void main(String[] args) {//throws IOException {
        //System.out.println("Srecno od strane klijenta!");


        try (Socket sock=new Socket("localhost", Server.PORT)){

            BufferedWriter out= new BufferedWriter(
                    new OutputStreamWriter(sock.getOutputStream()));

            Scanner sc=new Scanner(System.in);

            String relativna_putanja=sc.nextLine();
            //System.out.println(relativna_putanja);
            out.write(relativna_putanja);
            out.newLine();

            String x=sc.nextLine();
            out.write(x);
            out.newLine();

            String  eps=sc.nextLine();
            out.write(eps);
            out.newLine();

            //out.write("/home/ispit/Desktop/tests/"+relativna_putanja);
            sc.close();
            out.close();

            System.out.println("Validna putanja");

        } catch (IOException e) {
            e.printStackTrace();

        }


    }

}

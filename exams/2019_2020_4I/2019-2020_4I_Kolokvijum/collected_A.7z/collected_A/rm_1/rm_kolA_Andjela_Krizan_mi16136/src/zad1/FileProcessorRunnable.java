package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {

    private String putanja_do_fajla;
    private URL url;
    private char kar;

    private static int brojac=0;


    public FileProcessorRunnable(String putanja_do_fajla, URL url, char kar) {
        this.putanja_do_fajla=putanja_do_fajla;
        this.url=url;
        this.kar=kar;
    }

    public static int getBrojac() {
        return brojac;
    }


    @Override
    public void run() {

        try {

            URLConnection konekcija=url.openConnection();

            BufferedReader in= new BufferedReader(
                  new InputStreamReader((konekcija.getInputStream()), StandardCharsets.UTF_8));

            String linija;

            while((linija=in.readLine())!=null){
                brojac++;
            }


        }catch(FileNotFoundException e) {
            System.err.println("not found: " + putanja_do_fajla);
            //this.notify();
        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        String fajl="/home/ispit/Desktop/tests/urls.txt";

        Scanner sc=new Scanner(System.in);
        String karakter=sc.next();
        char kar=karakter.charAt(0);

        try(BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(fajl)));
        ) {
            String linija;
            int broj_linija=0;
            while((linija=in.readLine())!=null){
                broj_linija++;
                try{
                    URL url=new URL(linija);

                    String protokol=url.getProtocol();
                    if(protokol.equalsIgnoreCase("FILE")){
                        int posl_ind_tacke=linija.lastIndexOf(".");
                        //System.out.println(posl_ind_tacke);
                        if(posl_ind_tacke > 0) {
                            String ekstenzija = linija.substring(posl_ind_tacke + 1);
                            if(ekstenzija.equals("txt")) {
                                //System.out.println(ekstenzija);

                                String putanja_do_fajla = linija.substring(7);
                                //System.out.println(putanja_do_fajla);


                                Thread t = new Thread(new FileProcessorRunnable(putanja_do_fajla,url,kar));
                                t.start();

                            }
                        }
                    }
                } catch (MalformedURLException e) {
                    //e.printStackTrace();
                    continue;
                }
            }

            System.out.println("lines: " + broj_linija);

            System.out.println("result: " + FileProcessorRunnable.getBrojac());

            sc.close();
            in.close();

        } catch (FileNotFoundException e) {
            sc.close();
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Srecno!");
    }
}

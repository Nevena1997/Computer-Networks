package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Zad1Main {

    public final int num = 0;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        /*
        Za svaki validni URL proveriti protokol koji se koristi.  Ukoliko je protokol FILE i ukoliko putanja vodi
        dotekstualnog fajla (ekstenzija.txt), kreirati zasebnu nit koja  ́ce otvoriti baferisani ulazni tok do tog
        fajlaputem  URL  klase  i  proˇcitati  sadrˇzaj  fajla  (detalji  obrade  su  u  narednoj  stavci).
        Kodnu  stranu  prilikomuˇcitavanja postaviti na UTF-8.  Ukoliko fajl na datoj putanji ne postoji, ispisati
        poruku i ugasiti nit.   (5p)
         */
        try {
            FileInputStream fin = new FileInputStream("/home/ispit/Desktop/tests/urls.txt");
            BufferedReader in =  new BufferedReader(new InputStreamReader(fin));

            int linesNum = 0;
            String line = null;
            while((line = in.readLine()) != null){
                linesNum++;
                if(line.startsWith("file") ||
                        line.startsWith("FILE") ||
                        line.startsWith("http") ||
                        line.startsWith("ftp")) {
                    URL url = new URL(line);

                    if (url.getProtocol().equals("file") && line.endsWith(".txt")) {

                        Scanner sc = new Scanner(System.in);
                        char c = (char) sc.nextByte();

                        FileProcessorThread fpt = new FileProcessorThread(url, c);

                        FileProcessorRunnable fpr = new FileProcessorRunnable(fpt);
                        Thread t = new Thread(fpr);
                        t.start();
                    }
                }

            }
            System.out.println(linesNum);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Srecno!");
    }
}

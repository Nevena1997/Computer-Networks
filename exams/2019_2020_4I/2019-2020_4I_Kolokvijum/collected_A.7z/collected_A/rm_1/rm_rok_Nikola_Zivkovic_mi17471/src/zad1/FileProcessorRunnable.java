package zad1;

import java.net.URL;

public class FileProcessorRunnable implements Runnable {

    FileProcessorThread fpt;

    public FileProcessorRunnable(FileProcessorThread fpt) {
        this.fpt = fpt;
    }

    @Override
    public void run() {
        // TODO
        while(true){
            this.fpt.search();
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorThread{

    private final URL url;
    private char c;
    private Lock lock;

    public int num;

    public FileProcessorThread(URL url, char c) {

        this.url = url;
        this.c = c;
        this.lock = new ReentrantLock();
    }

    public void search() {

        this.lock.lock();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(this.url.openStream()))) {

            int b;
            while((b = br.read()) != -1) {
                if (b == this.c) {
                    num++;
                }
            }

        } catch (Exception e) {
            this.lock.unlock();
            this.lock.notifyAll();

        } finally {
            this.lock.unlock();
            this.lock.notifyAll();
        }
    }

}

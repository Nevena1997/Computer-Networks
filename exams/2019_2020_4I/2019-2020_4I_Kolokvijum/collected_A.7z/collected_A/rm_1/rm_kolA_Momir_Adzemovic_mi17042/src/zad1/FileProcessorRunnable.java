package zad1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.ReentrantLock;

public class FileProcessorRunnable implements Runnable {
    private final int id;
    private URL url;
    private BlockingQueue<Integer> results;
    private char keychar;

    public FileProcessorRunnable(URL url, BlockingQueue<Integer> results, char keychar, int id) {
        this.url = url;
        this.results = results;
        this.keychar = keychar;
        this.id = id;
    }

    @Override
    public void run() {
        int threadResult = 0;

        try {
            URLConnection uc = url.openConnection();

            try (BufferedReader input = new BufferedReader(
                    new InputStreamReader(
                        uc.getInputStream(), StandardCharsets.UTF_8
                    )
            )) {
                String line;
                while ((line = input.readLine()) != null) {
                    for(char c: line.toCharArray()) {
                        if(c == keychar) {
                            threadResult++;
                        }
                    }
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error: File " + this.url.toString() + " does not exist, result for this file is 0!");
            return;
        } catch (IOException e) {
            System.out.println("Error: Something went wrong (Unknown host, ...) " + this.url.toString() + ", result for this file is 0!");
            return;
        }

        System.out.println("Thread[" + this.id + "] (" + this.url + ") result: " + threadResult);
        try {
            results.put(threadResult);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

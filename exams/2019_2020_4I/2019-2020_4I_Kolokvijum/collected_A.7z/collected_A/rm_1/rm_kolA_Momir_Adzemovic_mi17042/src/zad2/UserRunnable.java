package zad2;

import java.io.*;
import java.net.Socket;

public class UserRunnable implements Runnable{
    private Socket client;

    public UserRunnable(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (BufferedReader fromClient = new BufferedReader(
                new InputStreamReader(
                        this.client.getInputStream()
                )
        );
             BufferedWriter toClient = new BufferedWriter(
                     new OutputStreamWriter(
                             this.client.getOutputStream()
                     )
             )
        ) {

            String filePath;
            filePath = fromClient.readLine();
            String strX = fromClient.readLine();
            String strEps = fromClient.readLine();

            System.out.println("Client filePath: " + filePath);
            System.out.println("Client x: " + strX);
            System.out.println("Client eps: " + strEps);

            float x = Float.parseFloat(strX);
            float eps = Float.parseFloat(strEps);

            try (BufferedReader input = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(Server.pathPrefix + filePath)
                    )
            )) {
                send(toClient, "Oui");

                int result = 0;
                String line;
                boolean hasFloat = false;

                while ((line = input.readLine()) != null) {
                    String[] words = line.split("\\s+");
                    for(String word: words) {
                        if(isFloat(word)) {
                            if(word.length() == 0)
                                continue;
                            hasFloat = true;
                            float val = Float.parseFloat(word);
                            if(val > x-eps && val < x+eps) {
                                result++;
                            }
                        }
                    }
                }

                send(toClient, (hasFloat) ? "Found Float" : "No Floats");
                send(toClient, "" + result);

            } catch (FileNotFoundException e) {
                send(toClient, "Non");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean isFloat(String word) {
        for(char c: word.toCharArray()) {
            if(Character.isAlphabetic(c))
                return false;
        }
        return true;
    }

    private static void send(BufferedWriter toClient, String content) throws IOException {
        toClient.write(content);
        toClient.newLine();
        toClient.flush();
    }
}

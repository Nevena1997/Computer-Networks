package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", Server.PORT);

            try (BufferedReader fromServer = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );
                 BufferedWriter toServer = new BufferedWriter(
                         new OutputStreamWriter(
                                 socket.getOutputStream()
                         )
                 );

                 Scanner input = new Scanner(
                         System.in
                 )
            ) {

                System.out.println("Input filepath, x, and eps: ");
                String filePath = input.next();
                String x = input.next();
                String eps = input.next();

                send(toServer, filePath);
                send(toServer, x);
                send(toServer, eps);

                String response = fromServer.readLine();
                System.out.println("Server: " + response);

                if(response.equalsIgnoreCase("Oui")) {
                    String hasFloat = fromServer.readLine();
                    String result = fromServer.readLine();

                    if(hasFloat.equalsIgnoreCase("No Floats")) {
                        System.out.println("Server: File does not contain float numbers!");
                    } else {
                        System.out.println("Server: " + result);
                    }
                }
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void send(BufferedWriter toServer, String content) throws IOException {
        toServer.write(content);
        toServer.newLine();
        toServer.flush();
    }
}

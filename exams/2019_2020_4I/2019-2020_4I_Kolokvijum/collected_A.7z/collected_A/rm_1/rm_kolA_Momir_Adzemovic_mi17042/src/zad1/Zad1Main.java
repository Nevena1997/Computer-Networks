package zad1;

import javax.swing.plaf.TableHeaderUI;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static void main(String[] args) {
        Scanner  sc = new Scanner(System.in);
        System.out.print("Input character: ");
        char keychar = sc.next().charAt(0);
        String inputFile = "src/zad1/urls.txt";

        try (BufferedReader input = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(inputFile)
                )
        )) {

            List<URL> urls = new ArrayList<>();

            String line;
            while((line = input.readLine()) != null) {
                if(validUrl(line) && isFileAndTxt(new URL(line)))
                    urls.add(new URL(line));
            }

            Thread[] threads = new Thread[urls.size()];
            BlockingQueue<Integer> results = new ArrayBlockingQueue<>(urls.size());

            int id = 0;
            for(URL url: urls) {
                threads[id] = new Thread(new FileProcessorRunnable(url, results, keychar, id));
                threads[id].start();
                id++;
            }

            try {
                for (int i = 0; i < threads.length; i++) {
                    threads[i].join();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                int result = 0;
                while (!results.isEmpty()) {
                    Integer r = results.take();
                    result += r;
                }
                System.out.println();
                System.out.println("Search Result: " + result);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        sc.close();
    }

    private static boolean isFileAndTxt(URL url) {
        boolean a = url.getProtocol().equalsIgnoreCase("file");
        String file = url.getFile();
        boolean b = file.endsWith(".txt");
        return a && b;
    }

    private static boolean validUrl(String strUrl) {
        try {
            URL url = new URL(strUrl);
        } catch (MalformedURLException e) {
            return false;
        }
        return true;
    }
}

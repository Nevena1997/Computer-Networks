package zad1;

import java.io.*;
import java.net.URL;
import java.util.Scanner;

public class Zad1Main {

    public static int broj_pojavljivanja=0;

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa


        try (
            BufferedReader in = new BufferedReader( new InputStreamReader( new FileInputStream( "/home/ispit/Desktop/tests/urls.txt")));
            PrintWriter out =new PrintWriter( new BufferedWriter(new OutputStreamWriter( System.out)))){

            Scanner sc = new Scanner(System.in);
            String karakter = sc.next();
            sc.close();


            String linija = null;
            int br_linija=0;
            while((linija=in.readLine())!=null){
                if(linija.matches("[az]://[azAZ]+")) {
                    URL url = new URL(linija);

                    if (url.getProtocol().equals("FILE")) {
                        if (url.getPath().contains("ekstenzija.txt")) {

                            new Thread(new FileProcessorRunnable(url, karakter)).start();

                        }
                    }
                }

                br_linija++;
            }

            out.println("lines: "+br_linija);
            out.flush();


            out.println("result: "+broj_pojavljivanja);
            out.flush();

            in.close();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Srecno!");
    }
}

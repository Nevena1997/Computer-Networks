package zad1;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static java.nio.charset.StandardCharsets.*;

public class FileProcessorRunnable implements Runnable {

    private URL url;
    private int broj_pojavljivanja=0;
    private String karakter;

    public FileProcessorRunnable(URL url, String karakter) {
        this.url = url;
        this.karakter = karakter;
    }


    @Override
    public void run() {
        // TODO

        try(BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(url.getPath()), UTF_8))){
            String linija;
            while((linija=input.readLine())!=null){

                for(int i = 0; i<linija.length(); i++){

                    char c = linija.charAt(i);
                    if(karakter.equals(c)){
                        broj_pojavljivanja++;
                    }
                }
            }
            Zad1Main.broj_pojavljivanja+=this.broj_pojavljivanja;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("not found: " +url.getPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

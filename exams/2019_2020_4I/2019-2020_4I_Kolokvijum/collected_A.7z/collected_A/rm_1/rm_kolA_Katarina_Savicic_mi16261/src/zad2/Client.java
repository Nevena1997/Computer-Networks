package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        String path;
        float x, eps;
        Scanner sc = new Scanner(System.in);
        path=sc.nextLine();
        x=sc.nextFloat();
        eps=sc.nextFloat();
        sc.close();

        try (Socket client = new Socket("localhost", 27182);
             PrintWriter out = new PrintWriter( new BufferedWriter(new OutputStreamWriter(client.getOutputStream())))){

            out.println(path);
            out.println(x);
            out.println(eps);
            out.flush();


            try (BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))) {

                in.readLine();
                float number = in.read();
                if(number == 0)
                    System.out.println("Fajl ne sadrzi realne brojeve");
                else
                    System.out.println(number);

            }

        } catch (IOException e) {
            e.printStackTrace();

        }


        //System.out.println("Srecno od strane klijenta!");
    }
}

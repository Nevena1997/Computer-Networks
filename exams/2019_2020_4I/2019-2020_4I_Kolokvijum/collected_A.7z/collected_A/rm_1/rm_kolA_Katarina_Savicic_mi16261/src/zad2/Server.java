package zad2;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) {

        try(ServerSocket server = new ServerSocket(27182)){

            while(true){

                Socket client = server.accept();
                Scanner in = new Scanner(new BufferedInputStream(client.getInputStream()));
                PrintWriter out = new PrintWriter( new BufferedOutputStream(client.getOutputStream()));

                String path = in.nextLine();
                float x = in.nextFloat();
                float eps = in. nextFloat();

                System.out.println(path);

                float xl = x-eps;
                float xr = x+eps;


                try(Scanner sc = new Scanner(new InputStreamReader(new FileInputStream(path)))) {
                    out.println("Validna putanja");

                    int n=0;

                    while(sc.hasNext()){
                        float number = sc.nextFloat();
                        if(number >= xl && number <= xr)
                            n++;
                    }

                    sc.close();
                    out.println(n);
                }catch(FileNotFoundException e){
                    out.print("Putanja nije validna");
                }

                in.close();
                out.close();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Srecno od strane servera!");
    }
}

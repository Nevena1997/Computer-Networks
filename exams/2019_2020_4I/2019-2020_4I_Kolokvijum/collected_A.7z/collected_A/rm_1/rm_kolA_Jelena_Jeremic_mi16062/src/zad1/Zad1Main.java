package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.net.URL;
import java.net.URLConnection;

public class Zad1Main {
    private static boolean match(String url)
    {
        try
        {
            URL u = new URL(url);
            return  true;
        }
        catch (MalformedURLException me)
        {
            return false;
        }
    }
    private static int prebroj(String naziv)
    {
        try
        {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(naziv), StandardCharsets.UTF_8));
            String linija;
            int i = 0;
            while ((linija = br.readLine())!=null)
            {
                i++;
            }
            return i;
        }
        catch (FileNotFoundException e)
        {
            System.err.println("No file!");
            return 0;
        }
        catch (IOException ie)
        {
            System.err.println("IO Exception!");
            return 0;
        }
    }
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        Scanner sc = new Scanner(System.in);
        String character = sc.next();

        System.out.printf("Lines: %d\n", prebroj("urls.txt"));

        try(Scanner sc1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("urls.txt"), StandardCharsets.UTF_8))))
        {
            URL u;
            String url, protocol, file_name, u_file;
            //int i = 0;
            while (sc1.hasNext())
            {
                //i++;
                //System.out.println(sc1.next());
                url = sc1.next();
                if(match(url))
                {
                    u = new URL(url);
                    //System.out.println(url);
                    protocol = u.getProtocol();
                    if(protocol.equals("file")&&(u.getFile().endsWith(".txt")))
                    {
                        new Thread(new FileProcessorRunnable(u, character)).start();
                    }
                    //System.out.println(protocol);
                }

            }
            //System.out.printf("Lines: %d\n", i);
        }
        catch (FileNotFoundException fnfe)
        {
            System.err.println("File not found!");
        }
        catch (MalformedURLException me)
        {
            System.err.println("Malformed exception!");
        }

        //System.out.println(character);
        //System.out.println("Srecno!");
    }
}

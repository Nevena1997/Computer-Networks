package zad1;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorRunnable implements Runnable {
    private URL u;
    private String c;

    public FileProcessorRunnable(URL u, String c)
    {
        this.u = u;
        this.c = c;
    }

    @Override
    public void run() {
        String naziv;
        try
        {
            naziv = u.getFile();
            URLConnection uc = u.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8));
            String linija;
            int i = 0;
            while ((linija = in.readLine())!=null)
            {
                if(linija.contains(c))
                {
                    i++;
                }
            }
            System.out.println("result: " + i);

        }
        catch (IOException e)
        {
            System.err.printf("not found: %s\n", u.getFile());
        }
    }
}

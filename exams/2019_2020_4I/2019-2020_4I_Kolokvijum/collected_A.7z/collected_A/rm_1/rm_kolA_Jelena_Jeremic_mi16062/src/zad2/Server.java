package zad2;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static final int PORT = 27182;
    public static void main(String[] args) {

        try(ServerSocket ss = new ServerSocket(PORT)) {
            while(true)
            {
                Socket client = ss.accept();

                new Thread(new Handler(client)).start();;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        //System.out.println("Srecno od strane servera!");
    }

    private static class Handler implements Runnable {
        private Socket client;

        public Handler(Socket client)
        {
            this.client = client;
        }

        public void run()
        {

        }
    }
}

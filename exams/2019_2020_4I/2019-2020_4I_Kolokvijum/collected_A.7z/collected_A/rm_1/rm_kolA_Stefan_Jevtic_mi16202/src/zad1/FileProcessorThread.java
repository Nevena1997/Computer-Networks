package zad1;

import com.sun.source.tree.SynchronizedTree;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileProcessorThread extends Thread {


    public LinkedBlockingQueue<URL> urlQueue;
    private String needle;
    private static int totalCharNum = 0;



    public FileProcessorThread(LinkedBlockingQueue<URL> urlArray, String needle) {
        this.urlQueue = urlArray;
        this.needle = needle.trim();
    }



    @Override
    public void run() {
        URL u = urlQueue.poll();
        String filePath = u.getPath();

        int charInFile = countCharInFile(filePath, needle);
        addToTotalRes(charInFile);
        // TODO

        return;
    }


    public int countCharInFile(String filePath, String needle){
        //if(!isTxtFile(filePath)) return 0;

        int charNumInFile = 0;
        Pattern pattern = Pattern.compile(needle);
        try(BufferedReader bf = new BufferedReader(new FileReader(filePath))) {
            for(String line = bf.readLine(); line != null; line = bf.readLine()) {
                Matcher m = pattern.matcher(line);
                while(m.find()){
                    charNumInFile++;
                }
            }
        }
        catch (Exception e) {
            //e.printStackTrace();
            System.out.println("No file path");
            currentThread().interrupt();
            return 0;
        }
       // System.out.println(filePath);

        return charNumInFile;
    }

    public synchronized void addToTotalRes(int localCount) {
        totalCharNum += localCount;
    }

    private boolean isTxtFile(String filePath) {
        return Pattern.matches(".[.]txt", filePath);
    }

    public static int getTotalCharNum(){
        return totalCharNum;
    }
}

package zad1;

import com.sun.source.tree.SynchronizedTree;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.SynchronousQueue;




public class Zad1Main {

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        String needle = "";
        try(Scanner sc = new Scanner(System.in)) {
            if(sc.hasNext()){
                needle = sc.next();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        LinkedBlockingQueue<URL> urlQueue = extractURLsFromFile();
       for(URL u : urlQueue) {
            Thread t = new Thread(new FileProcessorThread(urlQueue, needle));
            t.start();
        }


        System.out.println(FileProcessorThread.getTotalCharNum());



    }

    public static LinkedBlockingQueue<URL> extractURLsFromFile(){



        LinkedBlockingQueue<URL> urlQueue = new LinkedBlockingQueue<>(30);
        try(
                BufferedReader bf = new BufferedReader(new FileReader("/home/ispit/Desktop/tests/urls.txt"))
        ) {
            int lineNum = 0;
            for(String line = bf.readLine(); line != null; line = bf.readLine()) {
                lineNum++;
                try {
                    URL u = new URL(line);
                    urlQueue.add(u);
                }
                catch (MalformedURLException e) {
                    //Skip line if url not valid
                }

            }

            System.out.println(lineNum);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return urlQueue;
    }

}


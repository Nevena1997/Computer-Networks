package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ServeClient implements Runnable {

    Socket client;

    public ServeClient(Socket client) {
        this.client = client;
    }
    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter writer = new PrintWriter(new BufferedOutputStream(client.getOutputStream()));

            Scanner sc = new Scanner(reader);
            String filename = sc.next();
            float x = sc.nextFloat();
            float eps = sc.nextFloat();

            String indikator = "validna";
            writer.write(indikator);
            writer.flush();

            float left = x - eps;
            float right = x + eps;

            int count = 0;
            sc = new Scanner(new FileInputStream(filename));
            while (sc.hasNextFloat()) {
                float number = sc.nextFloat();
                if (number >= left && number <= right) count++;
            }
            writer.write(count);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

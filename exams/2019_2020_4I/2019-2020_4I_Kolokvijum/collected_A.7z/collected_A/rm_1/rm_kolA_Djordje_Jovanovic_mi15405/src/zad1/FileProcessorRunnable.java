package zad1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class FileProcessorRunnable implements Runnable {

    String filename;
    URL url;
    char key;
    BlockingQueue queue;

    public FileProcessorRunnable(URL url, char key, BlockingQueue<Integer> queue) {
        this.url = url;
        this.filename = url.getFile();
        this.key = key;
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            URLConnection connection = url.openConnection();
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null) {
                int end = line.length();
                int start = 0;
                while (start < end) {
                    int index = line.indexOf(key, start);
                    if (index == -1) break;
                    count++;
                    start = index + 1;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

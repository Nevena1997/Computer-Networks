package zad1;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {

    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa
        Scanner sc = new Scanner(System.in);
        char keyChar = sc.next().charAt(0);
        sc.close();

        try(BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream("~/Desktop/tests/urls.txt")))) {

            List<String> lines = new ArrayList<>();
            int lineCount = 0;
            String line;

            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            System.out.println(lines.size());

            List<URL> urls = new ArrayList<>();
            for (String urlText : lines) {
                URL url = new URL(urlText);
                urls.add(url);
            }

            BlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(lines.size());
            for (URL u : urls) {
                String protocol = u.getProtocol();
                if (protocol.equalsIgnoreCase("file")) {
                    if (u.getFile().endsWith(".txt")) {
                        FileProcessorRunnable processor = new FileProcessorRunnable(u, keyChar, queue);
                        Thread t = new Thread(processor);
                        t.start();
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (Socket client = new Socket("localhost", 27182)) {
            PrintWriter writer = new PrintWriter(
                    new BufferedOutputStream(client.getOutputStream()));
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));

            Scanner sc = new Scanner(System.in);
            String filepath = sc.next();
            float x = sc.nextFloat();
            float eps = sc.nextFloat();

            writer.println(filepath);
            writer.println(x);
            writer.println(eps);
            writer.flush();

            sc = new Scanner(reader);
            String indikator = sc.nextLine();
            float count = sc.nextFloat();

            if (count == 0) {
                System.out.println("Fajl ne sadrzi realne brojeve");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

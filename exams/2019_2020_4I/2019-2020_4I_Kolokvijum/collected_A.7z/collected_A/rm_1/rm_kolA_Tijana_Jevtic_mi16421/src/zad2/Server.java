package zad2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {

        try {
            ServerSocket sc = new ServerSocket(27182);
            while (true) {
                Socket client = sc.accept();
                new ClientThread(client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Zad1Main {
    public static void main(String[] args) throws MalformedURLException {
        Scanner sc = new Scanner(System.in);
        char character = 0;
        if (sc.hasNext()) {
            character = sc.nextLine().trim().charAt(0);
        }

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt"), StandardCharsets.UTF_8))
        ) {
            String line;
            int linesNum = 0;
            while ((line = in.readLine()) != null) {
                linesNum++;
                try {
                    URL url = new URL(line);
                    int len = url.getPath().split("/").length;
                    String file = url.getPath().split("/")[len-1];

                    if (file.matches("[a-zA-Z0-9]+[.]txt$") && url.getProtocol().contains("file")) {
                        new FileProcessorThread(url, character).start();
                    }
                } catch (MalformedURLException e) {
                }
            }
            int count = 0;
            System.out.println("lines: " + linesNum);
            System.out.println("result: " + count);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ClientThread extends Thread {
    private Socket client;

    ClientThread(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        try (InputStreamReader in = new InputStreamReader(this.client.getInputStream())) {
            String file = "dir2/test";
            double x = 3.5;
            double eps = 0.01;

            try (OutputStreamWriter out = new OutputStreamWriter(this.client.getOutputStream())) {

            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

public class FileProcessorThread extends Thread {
    private char character;
    private URL url;

    public FileProcessorThread(URL url, char character) {
        this.url = url;
        this.character = character;
    }

    @Override
    public void run() {
        int count = 0;
        try {
            URLConnection uc = this.url.openConnection();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = in.readLine()) != null) {
                    count += line.chars().filter((p) -> p != this.character).count();
                }

            } catch (IOException e) {
                System.out.println("not found: " + this.url.getPath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

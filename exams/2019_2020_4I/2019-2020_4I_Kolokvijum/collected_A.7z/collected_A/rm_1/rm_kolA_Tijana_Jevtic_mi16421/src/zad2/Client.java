package zad2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private String file;
    private double x;
    private double eps;

    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            String file = null;
            double x = 0;
            double eps = 0;
            if (sc.hasNextLine()) {
                file = sc.nextLine().trim();
            }
            if (sc.hasNextDouble()) {
                x = sc.nextDouble();
            }
            if (sc.hasNextDouble()) {
                eps = sc.nextDouble();
            }

            Socket s = new Socket("localhost", 27182);
            InputStreamReader in = new InputStreamReader(s.getInputStream());
            OutputStreamWriter out = new OutputStreamWriter(s.getOutputStream());
            out.write(file);
            out.flush();
            out.write(String.valueOf(x));
            out.flush();
            out.write(String.valueOf(eps));
            out.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

public class Zad1Main {

    public static Long result = 0L;
    public static void main(String[] args){

        // Implementirati logiku u jednoj od FileProcessor klasa
        String character;
        try(Scanner sc= new Scanner(System.in)) {
            character = sc.next();
            if(character.length()!=1) {
                return;
            }
        }
        List<URL> urls_all = new ArrayList<>();
        try(Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("../tests/urls.txt"))))){
            int num_lines=0;
            while(in.hasNextLine()) {
                String line = in.nextLine().trim();
                num_lines++;
                try{
                    URL url = new URL(line);
                    urls_all.add(url);
                }catch (MalformedURLException e) {
                    continue;
                }

            }
            System.out.println("Lines: " + num_lines);
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        List<Thread> threads = new ArrayList<>();
        List<URL> urls = Collections.synchronizedList(new LinkedList<URL>());

        for(int i=0; i<urls_all.size(); i++) {
            if(urls_all.get(i).getProtocol().startsWith("file") && urls_all.get(i).getFile().endsWith(".txt")) {
                urls.add(urls_all.get(i));
                Thread thread = new Thread(new FileProcessorRunnable(urls, character));
                threads.add(thread);
                thread.start();
            }
        }

        try {
            for (int i = 0; i < threads.size(); i++) {
                threads.get(i).join();
            }
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        System.out.println("result: " + result);




    }


}


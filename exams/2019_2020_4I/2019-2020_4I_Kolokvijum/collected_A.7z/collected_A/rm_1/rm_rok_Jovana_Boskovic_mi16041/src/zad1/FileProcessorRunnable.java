package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;


public class FileProcessorRunnable implements Runnable {
    private List<URL> urls;
    private String character;


    public FileProcessorRunnable(List<URL> urls, String character){
        this.urls = urls;
        this.character = character;
    }
    public void run() {
            while(urls.size()>0){
                URL url = urls.remove(0);
                try {
                    URLConnection uc = url.openConnection();
                    Scanner r =new Scanner(new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8)));
                    long count=0;

                    while(r.hasNextLine()){
                        String line= r.nextLine();
                        count += line.chars().filter(x->x==this.character.charAt(0)).count();
                    }

                    synchronized (Zad1Main.result){
                        Zad1Main.result+=count;
                    }


                }catch (IOException e){
                    System.out.println("Not found: " + url.getFile());
                    continue;
                }
            }

    }



}

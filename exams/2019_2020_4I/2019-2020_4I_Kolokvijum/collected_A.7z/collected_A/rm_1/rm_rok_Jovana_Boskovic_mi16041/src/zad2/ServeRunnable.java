package zad2;

import java.io.*;
import java.net.Socket;
import java.text.ParseException;
import java.util.Scanner;

public class ServeRunnable implements Runnable {
    private Socket client;

    public ServeRunnable(Socket client){
        this.client=client;
    }

    @Override
    public void run() {
        try{
            Scanner r = new Scanner(new BufferedReader(new InputStreamReader(this.client.getInputStream())));
            String path = r.nextLine().trim();
            String x1 = r.nextLine().trim();
            String eps1 = r.nextLine().trim();

            float x = Float.parseFloat(x1);
            float eps = Float.parseFloat(eps1);
            BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(this.client.getOutputStream()));
            System.out.println(path);
            try(Scanner read = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(path))))) {
                 int count=0;
                 while(read.hasNext()){
                     String token = read.next();
                     try{
                         Float num = Float.parseFloat(token);
                         if(num < (x+eps) && num > (x-eps)){
                            count++;
                         }
                     }catch (NumberFormatException e){
                         continue;
                     }
                 }

                 wr.write(count);
                 wr.newLine();
                 wr.flush();
            }catch (FileNotFoundException e){
                wr.write("0");
                wr.newLine();
                wr.flush();

            }

        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

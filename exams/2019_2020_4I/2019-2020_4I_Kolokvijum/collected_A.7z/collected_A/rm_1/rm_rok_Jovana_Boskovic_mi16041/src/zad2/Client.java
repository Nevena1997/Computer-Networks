package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {

        try(Socket client = new Socket("localhost", Server.DEFAULT_PORT); Scanner sc = new Scanner(System.in)){
            String line = sc.nextLine().trim();
            String[] tokens = line.split(" ");
            String path = tokens[0];
            String x = tokens[1];
            String eps = tokens[2];


            BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            wr.write(path);
            wr.newLine();
            wr.write(x);
            wr.newLine();
            wr.write(eps);

            Scanner r = new Scanner(new BufferedReader(new InputStreamReader(client.getInputStream())));
            String response = r.nextLine().trim();
            if(response!="0"){
                System.out.println("Validna putanja");
                response = r.nextLine();
                System.out.println(response);
            }else{
                System.out.println("Nevalidna putanja");
            }
        }catch (UnknownHostException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

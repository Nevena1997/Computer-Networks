package zad1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;

public class FileProcessorThread extends Thread {

    public static int broji_pojavljivanja_slova = 0;


    private int brojac;
    private String putanja;
    private String line;
    private char c;

    public FileProcessorThread(String putanja, int brojac, char c) {
        this.putanja = putanja;
        this.brojac =brojac;
        this.c = c;
    }



    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.putanja)));
           BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out))) {
            while ((line = in.readLine())!= null){

                try{
                    URL u = new URL(line);
                    String protokol = u.getProtocol();
                    if (protokol.equalsIgnoreCase("file")) {
                        if (line.contains(".")){
                            if (line.substring(line.lastIndexOf(".")).equalsIgnoreCase(".txt")) {
                                try {
                                    FileInputStream f = new FileInputStream(line);
                                    new Thread(new FileProcessorRunnable(line, c)).start();
                                } catch (FileNotFoundException e) {
                                    System.out.println("not found: " + line);
                                }
                            }
                        }
                    }

                }catch(MalformedURLException e){
                    continue;
                }

                brojac+=1;
            }

            out.write("lines: " + brojac);
            out.newLine();
            out.write("result: " + broji_pojavljivanja_slova);
            out.newLine();
            out.flush();

        } catch (FileNotFoundException e) {
           e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // TODO
    }
}

package zad1;

import java.io.*;

public class FileProcessorRunnable implements Runnable {

    private String putanja;
    private char c;
    private String linija;

    public FileProcessorRunnable(String line, char c) {
        this.putanja = line;
        this.c = c;
    }

    @Override
    public void run() {

        pojavljivanja();

        // TODO
    }

    private synchronized void pojavljivanja() {
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.putanja)))){

            while ((linija = in.readLine())!= null){
                String[] slova = linija.split("");
                for (String slovo : slova) {
                    if (slovo.equals("" + this.c)) {
                        FileProcessorThread.broji_pojavljivanja_slova += 1;
                    }

                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Zad1Main {

    public static  final String putanja = "/home/ispit/Desktop/tests/urls.txt";
    public static void main(String[] args) {

        // Implementirati logiku u jednoj od FileProcessor klasa

        char c;
        Scanner in = new Scanner(System.in);
        String line = in.next();
        c = line.charAt(0);
        int brojac = 0;
        new FileProcessorThread(putanja, brojac, c).start();

    }
}

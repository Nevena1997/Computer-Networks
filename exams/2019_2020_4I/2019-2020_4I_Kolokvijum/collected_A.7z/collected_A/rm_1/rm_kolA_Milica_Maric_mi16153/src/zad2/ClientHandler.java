package zad2;

import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {

    private Socket client;

    public ClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try(BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out));
            BufferedWriter outClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));){

                String line = in.readLine();
                String[] podaci = line.split(" ");


                String putanja = podaci[0];
                double x = Double.parseDouble(podaci[1]);
                double eps = Double.parseDouble(podaci[2]);

                try(BufferedReader fajl = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)))){
                    String linija;
                    while ((linija =fajl.readLine()) != null){
                        String[] karakteri = linija.split("");
                        for(String karakter : karakteri){
                            try{
                                double broj = Double.parseDouble(karakter);
                                if (x - broj < eps || x+broj < eps){
                                    outClient.write(broj + "");
                                }
                            }catch(Exception e){
                                continue;
                            }
                        }
                    }

                    outClient.write("1");
                }catch(FileNotFoundException e){
                    outClient.write("0");
                }

                out.write(putanja);
                out.flush();



        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

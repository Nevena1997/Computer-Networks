package zad2;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client{
    public static void main(String[] args) {

        try(Socket client = new Socket("localhost", Server.DEFAULT_PORT)) {
            try(BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()))){
                String line = in.readLine();
                String[] podaci = line.split(" ");

                String putanja = podaci[0];
                double x = Double.parseDouble(podaci[1]);
                double eps = Double.parseDouble(podaci[2]);

                out.write(putanja);
                out.write(" ");
                out.write(x + " ");
                out.write(eps + "\n");
                out.flush();

            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

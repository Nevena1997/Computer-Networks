package zad2;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class Server {
    public static int redni_broj = 0;
    public static int port = 12121;
    public static void main(String[] args) {

        try (DatagramSocket server = new DatagramSocket(port);
             Scanner sc = new Scanner(System.in);
        ) {
            String putanja = sc.nextLine();

            while (true) {

                byte[] upit_bytes = new byte[1024];
                DatagramPacket inicijalni = new DatagramPacket(upit_bytes, upit_bytes.length, InetAddress.getByName("localhost"), Server.port);
                server.receive(inicijalni);
                String upit = new String(upit_bytes, 0, inicijalni.getLength());
                String[] upit_niz = upit.split( " ");
                String naziv = upit_niz[0];
                int broj1 = Integer.parseInt(upit_niz[1]);
                int broj2 = Integer.parseInt(upit_niz[2]);
                redni_broj++;
                String poruka = "";
                int brojac_linija =0;
                byte[] poruka_bytes;


                if (broj1 < broj2) {
                    Scanner fajl = new Scanner(new File(naziv));
                    while (fajl.hasNextLine()){
                        if(brojac_linija>broj1){
                            poruka += fajl.nextLine();
                        }
                        brojac_linija++;
                    }
                    poruka_bytes = poruka.getBytes();
                   // poruka_bytes = "Genericka poruka od servera dok ne pocne da radi nesto pametno".getBytes();
                }
                else {
                    poruka_bytes = "Lose granica".getBytes();
                }

                DatagramPacket za_slanje = new DatagramPacket(poruka_bytes, poruka_bytes.length, inicijalni.getAddress(), inicijalni.getPort());
                server.send(za_slanje);

                String cela_adresa = inicijalni.getAddress().toString();
                System.out.println(redni_broj);
                System.out.println(cela_adresa.substring(cela_adresa.indexOf('/') + 1));
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

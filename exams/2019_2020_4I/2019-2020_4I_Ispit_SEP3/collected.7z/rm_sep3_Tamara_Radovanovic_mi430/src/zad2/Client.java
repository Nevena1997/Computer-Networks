package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc = new Scanner(System.in);
        ) {

            String fajl = sc.next();
            int linija1 = sc.nextInt();
            int linija2 = sc.nextInt();

            String upit = fajl +" "+linija1+" "+linija2;
            byte[] upit_bytes = upit.getBytes();

            DatagramPacket inicijalni = new DatagramPacket(upit_bytes, upit_bytes.length, InetAddress.getByName("localhost"), Server.port);
            klijent.send(inicijalni);

            byte[] poruka_bytes = new byte[1024];
            DatagramPacket za_prijem = new DatagramPacket(poruka_bytes, poruka_bytes.length);
            klijent.receive(za_prijem);
            String poruka = new String(poruka_bytes, 0 , za_prijem.getLength());

            System.out.println(poruka);

        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

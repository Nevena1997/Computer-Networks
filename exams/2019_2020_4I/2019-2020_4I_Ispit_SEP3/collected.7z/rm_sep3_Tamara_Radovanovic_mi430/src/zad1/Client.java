package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        try (Socket klijent = new Socket("localhost", Server.port);
            BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
             BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
             Scanner sc = new Scanner(System.in);
        ) {
            String ime = sc.nextLine();
            bw.write(ime);
            bw.newLine();
            bw.flush();
            //ceka se odg

            String odgovor;

            while ((odgovor = br.readLine())!=null){
                System.out.println(odgovor);
            }


//            odgovor = br.readLine();
//            System.out.println(odgovor);
//
//            odgovor = br.readLine();
//            System.out.println(odgovor);


        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

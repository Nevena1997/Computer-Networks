package zad1;

import java.net.Socket;

public class Takmicar {
    public String ime;
    public Socket socket;

    public Takmicar(String ime, Socket soket) {
        this.ime = ime;
        this.socket = soket;
    }
}

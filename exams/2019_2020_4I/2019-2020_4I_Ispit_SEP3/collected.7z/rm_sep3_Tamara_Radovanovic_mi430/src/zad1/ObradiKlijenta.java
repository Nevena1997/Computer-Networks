package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ObradiKlijenta extends Thread {
    private Socket klijent;
    private Server server;

    public ObradiKlijenta(Socket klijent, Server server) {
        this.klijent = klijent;
        this.server = server;
    }

    @Override
    public void run() {

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));

            String ime = br.readLine();

            server.dodajTakmicara(ime,klijent);
            bw.write(ime);
            bw.newLine();
            bw.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Server {
    public static int port = 12321;
    public static List<Takmicar> takmicari = new ArrayList<>();
    public static void main(String[] args) {
        Server s = new Server();
        s.execute();

    }

    //kad stigne 6. takmicar posalje poruku za pocetak kviza na prvih 5 a poslenjem null
    //Klijentima stizu pitanja jedno za drugim bez cekanja




    private void execute() {
        try (ServerSocket server = new ServerSocket(port);) {
            while (takmicari.size() < 2){
                Socket klijent = server.accept();
                new ObradiKlijenta(klijent, this).start();


            }

            System.out.println("prihvaceno je 5 takmicara");

            for (Takmicar t : takmicari){
                System.out.println(t.ime);
                Socket s = t.socket;
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
                bw.write("Kviz pocinje sada! Srecno");
                bw.newLine();
                bw.flush();
            }



            Scanner fajl = new Scanner(new File("MaterijaliZaKviz.txt"));
            while (fajl.hasNextLine()){
                String pitanje = fajl.nextLine();
                String odgovori = fajl.nextLine() + " " + fajl.nextLine()+ " " + fajl.nextLine()+ " " + fajl.nextLine();
                for (Takmicar t : takmicari){
                    Socket s = t.socket;
                    new Posalji(s, pitanje+" "+odgovori).start();
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void dodajTakmicara(String ime, Socket soket) {
        //System.out.println("dodat");
        takmicari.add(new Takmicar(ime, soket));
    }
}

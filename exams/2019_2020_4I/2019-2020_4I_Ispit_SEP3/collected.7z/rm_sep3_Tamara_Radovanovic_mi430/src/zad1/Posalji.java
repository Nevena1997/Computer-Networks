package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Posalji extends Thread {
    private Socket klijent;
    private String poruka;

    public Posalji(Socket klijent,String poruka) {
        this.klijent = klijent;
        this.poruka = poruka;
    }


    @Override
    public void run() {

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));


            bw.write(poruka);
            bw.newLine();
            bw.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
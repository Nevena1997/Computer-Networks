package zad1;

import java.io.*;
import java.net.Socket;

public class ObradiKlijenta extends Thread{

    private Socket klijent;
    private Server server;
    private BufferedWriter bw;
    private BufferedReader br;
    private float poeni=0;


    public ObradiKlijenta(Socket klijent, Server server) {
        this.klijent= klijent;
        this.server=server;
        try {
            bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
            br  = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void run() {
        try {
            String poruka;

            while (true){
                if(server.igra_zavrsena){
                    break;
                }
                if(server.isIgra_pocela()){
                    for(Pitanja_i_odgovori p : server.pitanjaIOdgovoris){
                        posalji(p.getPitanje());
                        poruka = br.readLine();
                    }

                }
            }


            server.izbrisi(this);
            klijent.close();
            br.close();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void posalji(String poruka) {
        try {
            bw.write(poruka);
            bw.newLine();
            bw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

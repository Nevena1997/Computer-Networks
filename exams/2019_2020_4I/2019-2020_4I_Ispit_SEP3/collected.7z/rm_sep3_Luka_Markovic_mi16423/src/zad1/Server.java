package zad1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class Server {
    public boolean isIgra_pocela() {
        return igra_pocela;
    }

    public boolean igra_zavrsena=false;
    public static int port = 12321;
    private boolean igra_pocela =false;
    private int broj_igraca=0;
    private String ime_fajla;
    private List<ObradiKlijenta> listaUcesnika = new ArrayList<>();
    public List<Pitanja_i_odgovori> pitanjaIOdgovoris = new ArrayList<>();

    public static void main(String[] args) {
        Server s = new Server();
        s.pokreni();
    }

    private void pokreni() {
        try(ServerSocket server = new ServerSocket(port);
            Scanner sc = new Scanner(System.in);
        ){
            System.err.println("Server osluskuje");

            ime_fajla=sc.nextLine();
            obradi_fajl();
            while (true){
                if(broj_igraca==2){
                    if(!igra_pocela) {
                        System.err.println("Igra poceinje");
                        posaljiSvima("Kviz pocinje sad. Srecno");
                        igra_pocela = true;


                    }
                }else {
                    System.err.println("Server ceka " + (2 - broj_igraca) + " klijenata");
                    Socket klijent = server.accept();
                    ObradiKlijenta klijentNit = new ObradiKlijenta(klijent, this);
                    listaUcesnika.add(klijentNit);
                    broj_igraca++;
                    klijentNit.start();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void izbrisi(ObradiKlijenta klijent) {
        listaUcesnika.remove(klijent);
    }

    private void obradi_fajl() {
        try (Scanner iz_fajla = new Scanner(new File(ime_fajla));){
            String pitanje;
            String odgovor;
            String tacan_odgovor=null;
            Pitanja_i_odgovori novo;
            while(iz_fajla.hasNext()){
                pitanje = iz_fajla.nextLine();
                for (int i = 0; i <4; i++){
                    odgovor = iz_fajla.nextLine();
                    if(odgovor.contains("*")){
                        tacan_odgovor = odgovor.substring(0,1);
                        pitanje+=" "+odgovor.substring(0,odgovor.indexOf("*"));
                    }else{
                        pitanje+=" "+odgovor;
                    }

                }
                novo= new Pitanja_i_odgovori(pitanje,tacan_odgovor);
                pitanjaIOdgovoris.add(novo);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void posaljiSvima(String poruka) {
        for (ObradiKlijenta o : listaUcesnika){
            o.posalji(poruka);
        }
    }

}

package zad1;

public class Pitanja_i_odgovori {
    private String pitanje;
    private String odgovor;

    public Pitanja_i_odgovori(String pitanje, String odgovor) {
        this.pitanje=pitanje;
        this.odgovor=odgovor;
    }

    public String getPitanje() {
        return pitanje;
    }

    public String getOdgovor() {
        return odgovor;
    }
}

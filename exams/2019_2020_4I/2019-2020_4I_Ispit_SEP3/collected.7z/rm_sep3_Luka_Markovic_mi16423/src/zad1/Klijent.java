package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Klijent {

    public static void main(String[] args) {

        try(Socket klijent = new Socket("localhost", Server.port);
            Scanner sc = new Scanner(System.in);
            BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
        ){
            String ime_klijenta = sc.nextLine();
            bw.write(ime_klijenta);
            bw.newLine();
            bw.flush();


            String poruka = null;
            poruka = br.readLine();
            System.out.println(poruka);
            String odgovor;
            while ((poruka=br.readLine())!=null){
                System.out.println(poruka);
                if(poruka.substring(0,4).equalsIgnoreCase("Kviz")){
                    break;
                }
                odgovor = sc.nextLine();
                bw.write(odgovor);
                bw.newLine();
                bw.flush();
            }




        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

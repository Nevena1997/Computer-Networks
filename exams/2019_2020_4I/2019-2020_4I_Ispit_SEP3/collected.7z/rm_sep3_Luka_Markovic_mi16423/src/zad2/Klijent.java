package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Klijent {

    public static void main(String[] args) {
        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc = new Scanner(System.in);
        ) {

            String ime_fajla = sc.next();
            int x = sc.nextInt();
            int y = sc.nextInt();
            String poruka = ime_fajla + " " + x + " " + y;
            byte[] poruka_za_slanje = poruka.getBytes();

            DatagramPacket paket_za_slanje = new DatagramPacket(poruka_za_slanje, poruka_za_slanje.length, InetAddress.getByName("localhost"), Server.port);
            klijent.send(paket_za_slanje);


            byte[] primljnea_poruka = new byte[1024];
            DatagramPacket primljen_paket = new DatagramPacket(primljnea_poruka, 1024);
            klijent.receive(primljen_paket);

            String odgovor = new String(primljnea_poruka, 0, primljen_paket.getLength());
            System.out.println(odgovor);



        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

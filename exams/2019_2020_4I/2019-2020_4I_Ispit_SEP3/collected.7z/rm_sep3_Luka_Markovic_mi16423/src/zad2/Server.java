package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

public class Server {

    public static int port =12121;
    public static void main(String[] args) {
        try (DatagramSocket server = new DatagramSocket(port);
             Scanner sc = new Scanner(System.in);

        ){
            String ime_fajla = sc.nextLine();
            int i=0;
            while (true){
                byte[] primljena_poruka = new byte[1024];
                DatagramPacket primljeni_paket = new DatagramPacket(primljena_poruka, 1024);
                server.receive(primljeni_paket);
                i++;
                System.out.println(i);
                System.out.println(primljeni_paket.getAddress());

                String odgovor = new String(primljena_poruka, 0, primljeni_paket.getLength());


                String poruka = "Za sad saljemo ovo";
                byte[] poruka_za_slanje = poruka.getBytes();
                DatagramPacket paket_za_slanje = new DatagramPacket(poruka_za_slanje, poruka_za_slanje.length, primljeni_paket.getAddress(),primljeni_paket.getPort());
                server.send(paket_za_slanje);
            }



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    private static DatagramSocket client;

    public static void main(String[] args) {

        try(
            Scanner scanner = new Scanner(System.in)) {

            client = new DatagramSocket();

            System.out.println("Unesite naziv fajla i dva broja: ");
            String text = scanner.nextLine();

            byte[] forSend = text.getBytes();
            InetAddress address = InetAddress.getByName("localhost");
            DatagramPacket send = new DatagramPacket(forSend, forSend.length, address, UDPServer.DEFAULT_PORT);
            client.send(send);


            DatagramPacket receive = new DatagramPacket(new byte[1024], 1024);
            client.receive(receive);

            String result = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
            System.out.println(result);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            client.close();
        }

    }

}

package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPServer {

    public static final int DEFAULT_PORT = 12121;
    private static DatagramSocket server;

    public static void main(String[] args) {

        try(
            Scanner scanner = new Scanner(System.in)) {

            server = new DatagramSocket(DEFAULT_PORT);
            System.err.println("Server je pokrenut...");

            System.out.println("Unesite naziv foldera: ");
            String imeFoldera = scanner.next();
            int brojac = 1;
            int brojLinijaFajla = 0;

            while (true) {

                DatagramPacket receive = new DatagramPacket(new byte[128], 128);
                server.receive(receive);
                System.out.println("Redni broj datagrama: " + brojac + " " + receive.getAddress());
                brojac++;

                String pristigliSadrzaj = new String(receive.getData(), 0, receive.getLength(), StandardCharsets.UTF_8);
                String[] tmp = pristigliSadrzaj.split(" ");
                String nazivFajla = tmp[0];
                int broj1 = Integer.parseInt(tmp[1]);
                int broj2 = Integer.parseInt(tmp[2]);

                String path  = "/home/ispit/Desktop/rm_sep3_David_Nedeljkovic_mi17468/" + imeFoldera + "/" + nazivFajla;
                BufferedReader bin = new BufferedReader(new InputStreamReader(new FileInputStream(path), StandardCharsets.UTF_8));

                String linija;
                StringBuffer buffer = new StringBuffer();
                while ((linija = bin.readLine()) != null) {
                    ++brojLinijaFajla;
                    if(brojLinijaFajla >= broj1 && brojLinijaFajla <= broj2) {
                        buffer.append(linija);
                        buffer.append("\n");
                    }
                }

                byte[] bufferForSend = buffer.toString().getBytes();
                DatagramPacket forSend = new DatagramPacket(bufferForSend, bufferForSend.length, receive.getAddress(), receive.getPort());
                server.send(forSend);

            }

        } catch (IOException e) {
            System.err.println("Fajl ne postoji.");
        } finally {
            server.close();
        }

    }
}

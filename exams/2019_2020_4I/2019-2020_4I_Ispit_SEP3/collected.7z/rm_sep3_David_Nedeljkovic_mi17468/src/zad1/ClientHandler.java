package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ClientHandler implements Runnable {

    private Socket client;

    public ClientHandler(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {

        try {
            BufferedReader bin = new BufferedReader(new InputStreamReader(this.client.getInputStream(), StandardCharsets.UTF_8));
            String linija;
            while ((linija = bin.readLine()) != null) {
                System.out.println(linija);
            }

            BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));

            if(KvizServer.brojKlijenata == 5) {
                bout.write("Kviz pocinje sada. Srecno!");
                bout.newLine();
                bout.flush();
            }



        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

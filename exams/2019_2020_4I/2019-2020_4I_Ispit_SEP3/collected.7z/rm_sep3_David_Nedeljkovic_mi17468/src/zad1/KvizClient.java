package zad1;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class KvizClient {

    private static Socket client;
    private static Scanner scanner;

    public static void main(String[] args) {

        try {
            client = new Socket("localhost", KvizServer.DEFAULT_PORT);
            scanner = new Scanner(System.in);

            System.out.println("Unesite Vase ime: ");
            String imeKlijenta = scanner.nextLine();

            try(BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
                BufferedReader bin = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8))) {
                bout.write(imeKlijenta);
                bout.newLine();
                bout.flush();

                System.out.println(bin.readLine());
            }




        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

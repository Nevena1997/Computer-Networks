package zad1;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class KvizServer {

    public static final int DEFAULT_PORT = 12321;
    public static int brojKlijenata = 0;

    public static void main(String[] args) {

        System.err.println("Server je pokrenut...");

        try(Scanner scanner = new Scanner(System.in)) {

            ServerSocket server = new ServerSocket(DEFAULT_PORT);

            System.out.println("Unesite ime fajla sa pitanjima za kviz: " );
            String imeFajla = scanner.next();

            String putanja = "/home/ispit/Desktop/rm_sep3_David_Nedeljkovic_mi17468/" + imeFajla;
            FileInputStream fin = new FileInputStream(putanja);

            while (true) {

                Socket client = server.accept();
                brojKlijenata++;
                Thread t = new Thread(new ClientHandler(client));
                t.start();

            }

        } catch (IOException e) {
           System.out.println("Fajl ne postoji.");
        }

    }
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ContestantThread extends Thread{
    private Server server;
    private String name;
    private BufferedReader fromClient;
    private PrintWriter toClient;

    public ContestantThread(String name, Socket client, Server server) {
        try {
            this.fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.toClient = new PrintWriter(client.getOutputStream(), true);
            this.name = name;
            this.server = server;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        toClient.println("Quiz starts now, good luck!");

        String question;
        Scanner sc = null;
        try {
            sc = new Scanner(this.server.getQuestions());

            while(sc.hasNextLine()){

                question = sc.nextLine();
                String a = sc.nextLine();
                String b = sc.nextLine();
                String c = sc.nextLine();
                String d = sc.nextLine();

                toClient.println(question);
                toClient.println(a);
                toClient.println(b);
                toClient.println(c);
                toClient.println(d);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    private final String host;
    private final int port;

    public Client(String localhost, int port) {
        
        this.host = localhost;
        this.port = port;
    }

    public static void main(String[] args) {
        Client client = new Client("localhost", 12321);
        client.execute();
    }

    private void execute() {

        try {
            Socket socket = new Socket(host, port);

            Scanner sc = new Scanner(System.in);
            System.out.println("Your name?");
            String name = sc.next();

            PrintWriter toServer = new PrintWriter(socket.getOutputStream(), true);
            toServer.println(name);

            BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String msg = fromServer.readLine();

            System.out.println(msg);
            new ClientWriteThread(socket).start();
            new ClientReadThread(socket).start();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

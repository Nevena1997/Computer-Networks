package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientWriteThread extends Thread{
    private PrintWriter toServer;

    public ClientWriteThread(Socket socket) {

        try {
            this.toServer = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {



    }
}

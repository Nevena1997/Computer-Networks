package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientReadThread extends Thread{
    private BufferedReader fromServer;

    public ClientReadThread(Socket socket) {
        try {
            this.fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

        try {
            String msg = fromServer.readLine();
            System.out.println(msg);

            String line;
            while ((line = fromServer.readLine()) != null){
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

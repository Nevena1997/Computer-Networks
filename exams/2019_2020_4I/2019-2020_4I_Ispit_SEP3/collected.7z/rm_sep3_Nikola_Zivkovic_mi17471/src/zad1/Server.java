package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Server {
    private final int port;
    private File questions;
    private ArrayList<ContestantThread> contestants;


    public Server(int port) {
        this.port = port;
        contestants = new ArrayList<>();
    }

    public static void main(String[] args) {
        Server server = new Server(12321);
        server.execute();
    }

    private void execute() {

        //Scanner sc = new Scanner(System.in);
        String fName = "MaterijaliZaKviz.txt";/*sc.next()*/;

        this.questions = new File(fName);

        try(ServerSocket serverSocket = new ServerSocket(port)){

            System.out.println("Server started @ port " + port);

            while (true){
                Socket client = serverSocket.accept();
                System.out.println("Client connected!");

                BufferedReader fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
                String name = fromClient.readLine();


                ContestantThread contestant = new ContestantThread(name, client, this);
                contestants.add(contestant);
                contestant.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<ContestantThread> getContestants() {
        return contestants;
    }

    public File getQuestions() {
        return questions;
    }
}

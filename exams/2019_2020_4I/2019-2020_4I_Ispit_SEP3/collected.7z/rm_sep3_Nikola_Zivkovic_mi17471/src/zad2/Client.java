package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        InetAddress addr;

            try {
                addr = InetAddress.getLocalHost();

                DatagramSocket socket = new DatagramSocket();

                Scanner sc = new Scanner(System.in);
                String fName = sc.next();
                String num1 = sc.next();
                String num2 = sc.next();

                byte[] buf = (fName + " " + num1 + " " +num2 + " ").getBytes();

                DatagramPacket request = new DatagramPacket(buf, buf.length, addr, 12121);
                socket.send(request);

                DatagramPacket response = new DatagramPacket(buf, buf.length);
                socket.receive(response);
                String data = new String(response.getData(), StandardCharsets.US_ASCII);

                System.out.println(data);

                sc.close();
            } catch (UnknownHostException | SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

    }
}

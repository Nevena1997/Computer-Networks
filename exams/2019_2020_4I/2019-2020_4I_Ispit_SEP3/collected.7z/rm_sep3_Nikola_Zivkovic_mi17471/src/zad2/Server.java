package zad2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Server extends Thread{

    private final int port;
    private String folder;

    public Server(int port) {
        this.port = port;
    }

    public static void main(String[] args) {

        Server server = new Server(12121);
        server.start();

    }

    @Override
    public void run() {

        Scanner sc = new Scanner(System.in);
        this.folder = sc.next();
        
        try(DatagramSocket server = new DatagramSocket(this.port)){

            System.out.println("Server running @ " + 12121);

            int num = 0;

            while (true){

                byte[] buf = new byte[256];

                DatagramPacket request = new DatagramPacket(buf, buf.length);
                server.receive(request);
                num++;
                System.out.println(num + ": " + request.getAddress().toString());


                String msg = new String(request.getData(), StandardCharsets.US_ASCII);
                String fName = msg.split(" ", 3)[0];
                int num1 = Integer.parseInt(msg.split(" ", 3)[1]);
                int num2 = Integer.parseInt(msg.split(" ", 4)[2]);

                File f = new File((this.folder + "/" + fName).trim());
                int lineNum = 0;
                String text = " ";

                Scanner sc1 = new Scanner(f);
                while (sc1.hasNextLine()){

                    //System.out.println(sc1.nextLine());
                    lineNum++;
                    if(lineNum >= num1 && lineNum <= num2) {
                        text += sc1.nextLine();
                        text += "\n";
                    }
                }

                System.out.println(text);
                buf = text.getBytes();
                DatagramPacket response = new DatagramPacket(buf, buf.length);
                server.send(response);
            }

        } catch (SocketException | FileNotFoundException e) {
            sc.close();
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package p02_swing;

import java.io.IOException;
import java.io.Reader;

import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public abstract class ParserGetter extends HTMLEditorKit.Parser {

	public void getParser() {
		//;
	}
}

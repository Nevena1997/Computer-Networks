package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner ulaz = new Scanner(System.in);
		String file = ulaz.next();
		ulaz.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(
					new BufferedReader(
							new InputStreamReader(
									new FileInputStream(file), "UTF-8")));
			out = new BufferedWriter(
					new OutputStreamWriter(
							new FileOutputStream("emails.txt"), "UTF-8"));

			while(in.hasNext()){
				String mejl = in.next();
				System.out.println(mejl);

				if(Validan(mejl)){
					out.write(mejl);
					out.newLine();

					//System.out.println(mejl);
				}
			}

		}
		catch (FileNotFoundException e) {
			System.out.println("Fajl ne postoji.");
		}
		catch(UnsupportedEncodingException e){
			System.out.println("Nije podrzano enkodiranje.");
		}
		catch (IOException e) {
			System.out.println("Neuspelo pisanje u izlazni fajl.");
		}
		finally{
			if(in != null)
				in.close();

			if(out != null){
				try {
					out.flush();
					out.close();
				}
				catch (IOException e) {
					System.out.println("Neuspelo zatvaranje izlaznog bafera.");
				}
			}
		}
	}

	private static boolean Validan(String mejl) {

		int manki = mejl.indexOf('@');

		if(mejl == "")
			return false;


		if(manki == -1)
			return false;

		if(mejl.substring(0, manki).length() < 5)
			return false;

		int tacka = mejl.lastIndexOf('.');

		if(tacka == -1)
			return false;

		if(mejl.substring(tacka, mejl.length()-1) == "")
			return false;

		for(int i = 0; i<manki; i++)
			if(!Character.isAlphabetic(mejl.charAt(i)) && !Character.isDigit(mejl.charAt(i)))
				return false;

		/*for(int i = manki; i<tacka; i++)
			if(!Character.isAlphabetic(mejl.charAt(i)) && !Character.isDigit(mejl.charAt(i)))
				return false;*/

		return true;
	}

}

package drugi;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) {
		Scanner ulaz = new Scanner(System.in);
		Scanner in = null;

		BlockingQueue<Path> queue = new ArrayBlockingQueue<>(100);

		System.out.println("Uneti fajl:");
		String fajl = ulaz.next();

		System.out.println("Niti:");
		int niti = ulaz.nextInt();

		System.out.println("Karakter:");
		String k = ulaz.next();

		try {
			in = new Scanner(new BufferedReader(
					new InputStreamReader(new FileInputStream(fajl))));


			while(in.hasNextLine()){
				String putDoFajla = in.nextLine();
				System.out.println(putDoFajla);

				queue.add(Paths.get(putDoFajla));
			}


			for(int i = 0; i<niti; i++)
				new Thread(new Potraga(queue, k)).start();


		}
		// nije htelo da mi radi kada sam stavio gore catch da ne izadje tokom rada
		// znam da treba da stoji u sred programa da bi nastavio dalje rad
		catch (FileNotFoundException e) {
			//System.out.println("Nije pronadjen fajl.");
		}
		finally{
			if(in != null)
				in.close();
		}
		ulaz.close();


	}

}

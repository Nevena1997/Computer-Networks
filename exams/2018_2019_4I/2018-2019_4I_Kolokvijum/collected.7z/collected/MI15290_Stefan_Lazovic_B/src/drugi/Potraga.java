package drugi;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Potraga implements Runnable{

	private BlockingQueue<Path> queue;
	private String k;
	private int brojac;

	public Potraga(BlockingQueue<Path> queue, String k){
		this.queue = queue;
		this.k = k;
		brojac = 0;
	}

	public int getBrojac() {
		return brojac;
	}

	@Override
	public void run() {
		try {
			Path p;


			//while(!queue.isEmpty()){}
			// nije htelo da mi radi lepo tako da svaka uzima dok moze,
			// kao da su se preplitale iako je sinhronizovano uzimanje iz reda
			synchronized (queue) { // sinhronizovano skidanje putanje sa reda
				p = queue.take();
				System.out.println();
			}

			Scanner zaFajl = new Scanner(p);
			while(zaFajl.hasNext()){

				String rec = zaFajl.next();

				if(rec.contains(k))
					brojac++;

			}

			zaFajl.close();


			System.out.printf("<%d>: %s : %d \n", Thread.currentThread().getId(), p.toString(), brojac);


			} catch (InterruptedException | IOException e) {
				// isto kao i za catch u mainu, ako ga premestim gde treba u sred programa da ga ne prekine, ne radi lepo
				//e.printStackTrace();
			}

	}

}

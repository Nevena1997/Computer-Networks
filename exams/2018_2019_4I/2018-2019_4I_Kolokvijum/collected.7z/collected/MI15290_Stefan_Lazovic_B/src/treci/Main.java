package treci;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String putanja = sc.nextLine();
		Scanner in = null;

		URL ulazni = null;
		try {//file protokol
			ulazni = new URL("file:" + putanja);
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(ulazni.openStream())));//otvaramo preko fajl protokola
			while(in.hasNextLine()){
				String linija = in.nextLine();
				//System.out.println(linija);

				int count = 0; // koliko dvotacki ima - znacemo verziju adrese
				for(int i = 0; i<linija.length();i++)
					if(linija.charAt(i) == ':')
						count++;

				String[] tokeni = linija.split(":");
				//System.out.println(count);

				//System.out.println(linija.substring(linija.lastIndexOf('.'), linija.length()));

				if(linija.substring(linija.lastIndexOf('.'), linija.length()).equalsIgnoreCase(".txt")){
					if(count == 3){
						//dodajemo dvotacku u url jer smo splitovali po njoj
						String datumVreme = tokeni[0];
						String ip = tokeni[1];
						String url = tokeni[2] + ":" + tokeni[3];

						URL u = new URL(url);

						//String []DMY = datumVreme.split(".");
						//Date danas = new Date(count);

						//Date uzeto = new Date(Integer.getInteger(DMY[0]), Integer.getInteger(DMY[1]), Integer.getInteger(DMY[2]));

						//if(danas - uzeto < 24*60*60*1000)
						System.out.printf("v%d:%s:%s\n", 4, u.getProtocol(), u.getPath());

					}

					else if(count == 4){
						//dodajemo dvotacku i u ipv6 adresu
						String datumVreme = tokeni[0];
						String ip = tokeni[1] + ":" + tokeni[2];
						String url = tokeni[3] + ":" + tokeni[4];

						URL u = new URL(url);

						//String []DMY = datumVreme.split(".");
						//Date danas = new Date(count);

						//Date uzeto = new Date(Integer.getInteger(DMY[0]), Integer.getInteger(DMY[1]), Integer.getInteger(DMY[2]));

						//if(danas - uzeto < 24*60*60*1000)
						// - jer date moze da vraca milisekunde u longu, a ovo je bas jednako jednom danu
						// ali nisam nikako uspeo da ga nateram da radi lepo

						System.out.printf("v%d:%s:%s\n", 6, u.getProtocol(), u.getPath());

					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally{
			if (in != null)
				in.close();
		}
		sc.close();

	}

}

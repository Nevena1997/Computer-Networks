package treciZadatak;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class TreciZadatak
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
//		Fajl se zove log.txt
		sc.close();

		Scanner in = null;
		try
		{
			Path path = Paths.get(file);
			URL u = new URL("file:///"+ path.toAbsolutePath());
			in = new Scanner(new BufferedReader(new InputStreamReader((u.openStream()), "UTF-8")));
			String word = null;
			while(in.hasNext())
			{
				word = in.next();
				if(word.contains(".txt") && word.substring(word.indexOf("[") + 1, word.indexOf("]")).equals("23.11.2018"))
				{
//					Lenjo proveravanje za datum, ispisuje samo one zahteve ciji je datum datum kolokvijuma.
					System.out.println(word);
				}
			}

		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
				in.close();
		}
	}

}

package drugiZadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Scanner;

public class DrugiZadatak
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String ulaz = sc.nextLine();
		int n = sc.nextInt();
		String k = sc.next();

		sc.close();

		Scanner in = null;
		ArrayList<String> files = new ArrayList<String>();
		try
		{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(ulaz), "UTF-8")));
			String word = null;
			while(in.hasNext())
			{
				word = in.next();
				files.add(word);
			}

			for (String string : files)
			{
				System.out.println(string);
			}

		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			in.close();
		}

		for(String string : files)
		{
			Pretraga p = new Pretraga(string, k);
			Thread t = new Thread(p);
			p.run();
		}


	}

}

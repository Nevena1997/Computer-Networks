package drugiZadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Pretraga implements Runnable
{
	String file;
	String k;

	public Pretraga(String file, String k)
	{
		this.file = file;
		this.k = k;
	}

	@Override
	public void run()
	{
		Scanner in = null;
		try
		{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(this.file), "UTF-8")));
			String word = null;
			int brojac = 0;
			while(in.hasNext())
			{
				word = in.next();
				if(word.contains(this.k))
				{
					brojac += 1;
				}
			}
			wait();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		finally
		{
			in.close();
		}
	}

}

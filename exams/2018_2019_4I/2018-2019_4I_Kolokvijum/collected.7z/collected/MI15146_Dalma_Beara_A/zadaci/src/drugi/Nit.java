package zadaci;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Nit {

	private int n = 10;
	private String lookup = null;
	private String[] files = null;

	Lock lock = new ReentrantLock();
	Condition cond = lock.newCondition();

	public Nit(int n, String lookup, String[] files) {
		this.n = n;
		this.lookup = lookup;
		this.files = files;
	}

	public void process()
	{
		int i = 0;
		lock.lock();
		try {
			for (i=0; i<n; i++)
			{
				Thread t = new Thread(this.files[i]);
				t.start();

				if (files[i].contains(this.lookup))
				{
					System.out.println("<" + i + ">:<" + this.files[i] + ">:<hehe>");
				}
				Thread.sleep(5);

				t.notifyAll();
			}
			lock.unlock();
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

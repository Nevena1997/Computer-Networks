package zadaci;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class NitiTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String putanja = sc.next();
		sc.close();

		InputStreamReader in = null;

		try {
			in = new InputStreamReader(new FileInputStream(putanja));
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		char[][] putanje = null;
		char[] buf = null;
		try {
			int i = 0;
			for(i=0; in.read(buf) != -1; i++)
				putanje[i] = buf;
			Nit niti = new Nit(10, "slon", (String[])putanje);
		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}
}

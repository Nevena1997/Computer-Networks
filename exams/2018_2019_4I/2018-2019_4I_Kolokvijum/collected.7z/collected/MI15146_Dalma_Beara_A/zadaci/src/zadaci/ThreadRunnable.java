package zadaci;

public class ThreadRunnable implements Runnable {

	private final int MAX_DELAY = 5;
	private String file;
	private Nit nit;

	public ThreadRunnable(Nit nit, String file) {
		this.file = file;
		this.nit = nit;
	}

	@Override
	public void run(){
		try {
			nit.process();
			this.wait((int)Math.random()*MAX_DELAY);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

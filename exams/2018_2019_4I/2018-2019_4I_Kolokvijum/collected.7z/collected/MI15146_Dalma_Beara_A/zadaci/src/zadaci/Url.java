package zadaci;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Url {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String regFajl = sc.next();
		sc.close();

		URL u = null;
		URLConnection x = null;

		try {
			u = new URL(regFajl);
			x = u.openConnection();

			String read = null;
			//recimo da smo procitali sadrzaj i upisali ga u string read

			//ovo radi samo za ipv4 ali eto
			String [] pieces = read.split(":");
			if (pieces[2].equals("ftp") || pieces[2].equals("sftp"))
			{
				String addressType = version(pieces[1]);
				System.out.println(addressType + ":" + pieces[2] + ":" + pieces[2]);
			}

		}
		catch(MalformedURLException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}

	//pretpostavili smo da je data ispravna ipv4 ili ipv6 adresa
	private static String version(String address)
	{
		if(address.contains(":"))
			return "v6";
		else
			return "v4";
	}

}

package zadaci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class KopiranjeFajla {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		sc.close();
		
		BufferedReader in = null; 
		BufferedWriter out = null; 
		char[] s = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
			try {
				while (in.read(s) != -1)
				{
					if (isDate(s))
					{
						out.write(s);
						out.newLine();
						out.flush();
					}
				}
			}
			catch (IOException e)
			{
				System.err.println(e);
			}
		}
		catch (FileNotFoundException e) {
			System.err.println("Datoteka nije pronadjena");
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		finally {
			if(in != null)
				try {
					in.close();
				}
				catch (IOException e) {
					e.printStackTrace();
				}
			if(out != null)
				try {
					out.close();
				}
				catch (IOException e) {
					e.printStackTrace();
				}
		}
		
	}
	
	// Znam da je ovaj nacin provere katastrofalan, nazalost ne znam kako se koristi regex u Javi.
	private static boolean isDate(char[] s)
	{
		//da je duzina niske 10
		if (s.length != 10)
			return false;
		//da su crtice na pravim mestima
		if ((int)s[2] != '-' && (int)s[5] != '-')
			return false;
		//da je prvi broj u danu 0, 1, 2, ili 3
		if ((int)s[0] != 0 && (int)s[0] != 1 && (int)s[0] != 2 && (int)s[0] != 3)
			return false;
		//da ako je 3, drugi broj moze biti samo 0 ili 1
		if ((int)s[0] == 3)
		{
			if ((int)s[1] != 0 && (int)s[1] != 1)
				return false;
		}
		//da je prvi broj u mesecu 0 ili 1
		if((int)s[3] != 0 && (int)s[3] != 1)
			return false;
		//da ako je 1, drugi broj moze biti samo 0, 1 ili 2
		if((int)s[3] == 1)
		{
			if((int)s[4] != 0 && (int)s[4] != 1 && (int)s[4] != 2)
				return false;
		}
		//da je godina veca od 2000 (>=)
		if((int) s[6] != 2 || (int)s[7] != 0)
			return false;
		
		//ako nista nije puklo, sve je ok
		return true;
	}

}

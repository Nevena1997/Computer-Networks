import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Searcher {

	private String fName;
	private Lock lock;
	private Condition fileDoesNotExist;

	public Searcher(String elementAt) {
		// TODO Auto-generated constructor stub
		this.fName = elementAt;
		this.lock = new ReentrantLock();
		this.fileDoesNotExist = lock.newCondition();
	}

	public void searchFor(String keyWord) {
		// TODO Auto-generated method stub

		this.lock.lock();
		try {
			Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fName))));

			int lineNum = 0;
			while(in.hasNextLine()){
				String line = in.nextLine();
				if(line.contains(keyWord)){
					System.out.println(Thread.currentThread() + ":" + fName + ":" + lineNum);
				}
			}

			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			fileDoesNotExist.signal();
		}

	}
}

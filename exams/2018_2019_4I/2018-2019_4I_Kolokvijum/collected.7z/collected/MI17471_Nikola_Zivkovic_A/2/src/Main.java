import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Unesite putanju");
		Scanner sc = new Scanner(System.in);
		String fName = sc.next();

		try {
			Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fName))));

			Vector<String> v = new Vector<String>();

			while(in.hasNext()){
				//System.out.println(in.next());
				v.add(in.next());
			}

			System.out.println("Unesite kljucnu rec");
			String keyWord = sc.next();
			System.out.println("Unesite broj niti");
			int n = sc.nextInt();

			/*
			 * n = 10
			 * 0: 0, 3, 6, 9
			 * 1: 1, 4, 7, 10
			 * 2: 2, 5, 8
			 * */

			for(int i = 0; i < n; i++){
				//SearcherRunnable s = new SearcherRunnable(v, (v.capacity()+i)%n, keyWord);

				for(int j = 0; i < v.capacity(); j++){
					SearcherRunnable s = new SearcherRunnable(v, j%n, keyWord);
					Thread t = new Thread(s);
					t.start();
				}
			}

			sc.close();
			in.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

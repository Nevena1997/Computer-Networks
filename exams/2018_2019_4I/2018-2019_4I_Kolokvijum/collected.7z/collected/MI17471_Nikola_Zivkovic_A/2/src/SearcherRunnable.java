import java.util.Vector;

public class SearcherRunnable implements Runnable{

	private Vector<String> v;
	private int pos;
	private String keyWord;

	public SearcherRunnable(Vector<String> v, int pos, String keyWord) {
		// TODO Auto-generated constructor stub
		this.setV(v);
		this.setPos(pos);
		this.setKeyWord(keyWord);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Searcher s = new Searcher(v.elementAt(pos));
			s.searchFor(keyWord);

	}


	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public Vector<String> getV() {
		return v;
	}

	public void setV(Vector<String> v) {
		this.v = v;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

}

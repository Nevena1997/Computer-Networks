import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class date {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String fName = sc.next();
		sc.close();

		try {
			Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fName))));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt")));

			while(in.hasNext()){
				String word = in.next();

				if(word.matches("[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]")){

					int days = Integer.parseInt(word.substring(0, 2).toString());
					int months = Integer.parseInt(word.substring(3, 5).toString());
					//int years = Integer.parseInt(word.substring(6).toString());

					if(days < 32 && months < 13){ //years > 2000
						out.write(word);
						out.newLine();
					}
				}
			}

			System.out.println("done");

			in.close();
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

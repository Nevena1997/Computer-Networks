package zadatak2;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;



public class ThreadFile {

	public static void main(String[] args) {

		try {
		Scanner sc = new Scanner(System.in);
		BlockingQueue<Path> red = new ArrayBlockingQueue<>(100);

		String put = sc.nextLine().trim();
		Scanner sf = new Scanner(new FileInputStream(put));
		while (sf.hasNextLine()) {
			String p = sf.nextLine();
			System.out.println(p);
			red.put((Path)Paths.get(p));
			}
		System.out.println("Unesite rec:");
		String rec = sc.next();
		System.out.println("Unestie broj niti:");
		int brojNiti = sc.nextInt();

		for (int i = 0; i < brojNiti; i++) {
			FileRunnable fr = new FileRunnable(red, rec);
			Thread t = new Thread(fr);
			t.start();
		}

		sf.close();
		sc.close();
		} catch (InterruptedException e) {
				e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}


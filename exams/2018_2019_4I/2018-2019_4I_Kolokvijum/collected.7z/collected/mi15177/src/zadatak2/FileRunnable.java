package zadatak2;

import java.nio.file.Path;
import java.util.concurrent.BlockingQueue;

public class FileRunnable implements Runnable {

	private BlockingQueue<Path> red;
	private String rec;

	public FileRunnable( BlockingQueue<Path> red, String rec) {
		this.red = red;
		this.rec = rec;
	}

	int n = red.size();

	@Override
	public void run() {


	}

	public boolean postojiRec() {
		return false;

	}

}

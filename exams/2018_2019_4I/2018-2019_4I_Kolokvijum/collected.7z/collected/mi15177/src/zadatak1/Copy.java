package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Copy {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		String in_file = sc.next();
		InputStreamReader in = null;
		OutputStreamWriter out = null;
		try {
			in = new InputStreamReader(new FileInputStream(in_file), "UTF-8");
			out = new OutputStreamWriter(new FileOutputStream("timestamp.txt"), "UTF-8");

			BufferedReader r = new BufferedReader(in);
			BufferedWriter w = new BufferedWriter(out);

			String line;
			while ((line = r.readLine()) != null) {
				if (line.length() > 0) {
					for (String word : line.split(" ")) {
						if (isValidDate(word)) {
							w.write(word);
							w.newLine();
						}
					}
				}
			}
			w.flush();

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (UnsupportedEncodingException e) {
			System.out.println("UTF-8 not supported");
		} catch (IOException e) {
			System.out.println("IOException");
		}

		finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
	}

	public static boolean isValidDate(String word) {
		if (word.length() != 10)
			return false;
		if (Integer.parseInt(word.substring(0, 2)) > 31 ||
			Integer.parseInt(word.substring(3, 5)) > 12 ||
			Integer.parseInt(word.substring(6, 10)) <= 2000) {
			return false;
		}
		 if (word.charAt(2) != '-' || word.charAt(5) != '-') {
			 return false;
		 }

		 return true;
	}


}















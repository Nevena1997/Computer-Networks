package zadatak3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;

public class UrlRead {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		String fajl = sc.nextLine().trim();
		InputStreamReader in = null;

		try {
			URL u = new URL("file:" + fajl);

			in = new InputStreamReader(u.openStream());
			BufferedReader r = new BufferedReader(in);
			String line;
			while ((line = r.readLine()) != null) {
				if (isFtpOrFstp(line)) {
					printFormat(line);
				}
			}


		sc.close();
		in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			sc.close();
			if (in != null)
				in.close();
		}

	}

	public static boolean isFtpOrFstp(String line) {
		int i = line.lastIndexOf(':');
		if (line.substring(i-3 ,i).equals("ftp") ||
			line.substring(i-4 ,i).equals("sftp")) {
			return true;
		}
		return false;
	}

	public static void printFormat (String line) {
		try {
			// Trazim pretposlednju dvotacku
			int prva = 0;
			int druga = 0;
			int brDvotacki = 0;
			for (int i = 0; i < line.length(); i++) {
				if (line.charAt(i) == ':') {
					brDvotacki++;
					prva = druga;
					druga = i;
				}
			}
			URL url = new URL(line.substring(prva+1));

			if (brDvotacki <= 3)
				System.out.println("v4:" + url.getProtocol() + ":" + url.getFile());
			else
				System.out.println("v6:" + url.getProtocol() + ":" + url.getFile());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

}

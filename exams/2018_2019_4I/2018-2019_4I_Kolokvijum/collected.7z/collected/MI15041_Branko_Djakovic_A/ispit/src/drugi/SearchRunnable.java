package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;


public class SearchRunnable implements Runnable{
	private static final int MAX_DELAY = 5;
	private List<String> entries;
	private String keyword;

	public SearchRunnable(List<String> entries, String keyword){
		this.entries = entries;
		this.keyword = keyword;
	}

	@Override
	public void run() {
		while(true){
			String file = null;
			Scanner in = null;
			synchronized (this.entries) {
				if(this.entries.isEmpty())
					break;
				file = this.entries.remove(0);
			}

			try {
				in = new Scanner(new InputStreamReader(new FileInputStream(file)));
				for(int ln = 1; ; ln++){
					if(!in.hasNextLine())
						break;
					String linija = in.nextLine();
					if(linija.contains(keyword)){
						System.out.printf("%d:%s:%d\n", Thread.currentThread().getId(), file, ln);
					}
					Thread.sleep((long)(Math.random()*MAX_DELAY));

				}

			} catch (FileNotFoundException e) {
				continue;
			} catch (InterruptedException e) {
				e.printStackTrace();
			} finally{
				if(in != null)
					in.close();
			}
		}
	}
}

package drugi;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ulazni fajl: ");
		String input = sc.next();

		Scanner in = null;
		BufferedWriter out = null;

		List<String> entries = Collections.synchronizedList(new LinkedList<String>());
		try {
			in = new Scanner(new InputStreamReader(new FileInputStream(input)));
			out = new BufferedWriter(new OutputStreamWriter(System.out));

			while(in.hasNextLine()){
				String file = in.nextLine().trim();
				entries.add(file);
			}

			System.out.println("Unesite kljucnu rec: ");
			String keyword = sc.next();
			System.out.println("Unesite broj niti: ");
			int n = sc.nextInt();

			for(int i = 0; i < n; i++){
				SearchRunnable search = new SearchRunnable(entries, keyword);
				Thread t = new Thread(search);
				t.start();
			}

			Thread.sleep(5000);


		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally{
			try {
				if (in != null)
					sc.close();
				if (out != null) {
					out.flush();
					out.close();
				}
				sc.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}
	}

}

package treci;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla:");
		String input = sc.next();
		Scanner in = null;
		try {
			URL url = new URL("FILE", "localhost", input);
			in = new Scanner(url.openStream());

			while(in.hasNextLine()){
				String line = in.nextLine().trim();

				int i = line.indexOf(']');
				String rest = line.substring(i+1).trim();

				int j = rest.indexOf("://");
				String adress = rest.substring(1,j);

				i = adress.lastIndexOf(':');
				adress = adress.substring(0, i);

				String protocol = rest.substring(i+2, j);
				rest = rest.substring(i+2);


				if(!protocol.equals("ftp") && !protocol.equals("sftp"))
					continue;

				int version = 0;
				if(adress.contains(":"))
					version = 6;
				else
					version = 4;

				URL x = new URL(rest);
				System.out.printf("v%d:%s:%s\n", version, x.getProtocol(), x.getPath());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			if(in != null)
				in.close();
			sc.close();
		}
	}

}

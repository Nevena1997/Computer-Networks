package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Copy {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla: ");
		String input = sc.next();
		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input),"UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(in.hasNext()){
				String token = in.next().trim();
				if(token.matches("((0[1-9])|([12][0-9])|(3[01]))-((0[1-9])|1[0-2])-(200[1-9]|20[1-9][0-9]|2[1-9][0-9][0-9]|[3-9][0-9]{3})")){
					out.write(token);
					out.newLine();
				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null)
					in.close();
				if (out != null) {
					out.flush();
					out.close();
				}
				sc.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}
	}

}

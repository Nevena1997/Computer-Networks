package treci_zadatak;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Log {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do fajla: ");
		String log = sc.next();
		// podrazumevala sam da se file unosi kao file://...

		Scanner in = null;
		try {
			URL url = new URL(log);
			in = new Scanner(new InputStreamReader(url.openStream()));
			while(in.hasNextLine()) {
				String line = in.nextLine();
				if(line.endsWith(".txt")) {
					try {
						write(line);
					} catch (MalformedURLException e) {
						e.printStackTrace();
					}
				}
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if(in != null) {
			in.close();
		}

		sc.close();
	}

	private static void write(String line) throws MalformedURLException {
		int i = line.lastIndexOf(":");
		int last = line.substring(0, i).lastIndexOf(":");
		String url = line.substring(last+1);
		String ip = line.substring(line.indexOf(":")+1, last);

		int version;
		if(ip.contains(":"))
			version = 6;
		else
			version = 4;

		URL Url = new URL(url);

		StringBuffer sb = new StringBuffer();
		sb.append("v").append(version).append(":").append(Url.getProtocol()).append(":").append(Url.getPath());
		System.out.println(sb.toString());
	}
}

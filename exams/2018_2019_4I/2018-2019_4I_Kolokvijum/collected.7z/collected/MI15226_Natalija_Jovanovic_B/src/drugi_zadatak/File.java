package drugi_zadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class File implements Runnable {
	private BlockingQueue<String> paths;
	private String fileName;

	public File(BlockingQueue<String> paths, String fileName) {
		this.paths = paths;
		this.fileName = fileName;
	}

	@Override
	public void run() {

			putFilesInQueue();

	}

	private void putFilesInQueue() {
		Scanner sc;
		try {
			sc = new Scanner(new InputStreamReader(new FileInputStream(this.fileName)));
			while(sc.hasNext()) {
				String file = sc.next();
				this.paths.add(file);
				System.out.println(file);
			}
			this.paths.add("");

			this.paths.notifyAll();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}


	}

}

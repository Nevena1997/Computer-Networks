package drugi_zadatak;

import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String fileName = sc.next();
		System.out.println("Unesite broj tredova n:");
		int n = sc.nextInt();
		System.out.println("Unesite karakter k:");
		char k = sc.next().charAt(0);

		int MAX = 1000;
		BlockingQueue<String> paths = new ArrayBlockingQueue<>(MAX);

		new Thread(new File(paths, fileName)).start();

		for(int i = 0; i < n; i++) {
			new Thread(new Counter(paths, k)).start();
		}

		sc.close();
	}

}

package drugi_zadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.BlockingQueue;

public class Counter implements Runnable {
	private BlockingQueue<String> paths;
	private char c;
	private boolean isFinished = false;

	public Counter(BlockingQueue<String> paths, char c) {
		this.paths = paths;
		this.c = c;
	}

	@Override
	public void run() {
		while(true) {
			try {
				if(isFinished)
					return;

				while(paths.isEmpty()) {
					this.paths.wait();
				}

				String file = paths.take();
				if(file == "") {
					isFinished = true;
					paths.put("");
				}

				int n = countCharacters(file, this.c);
				System.out.println("Broj karaktera u fajlu " + file + " je " + n);
			} catch(Exception e) {
				e.printStackTrace();;
			}
		}

	}

	private int countCharacters(String file, char c) {
		InputStreamReader in = null;
		int numOfChars = 0;
		try {
			in = new InputStreamReader(new FileInputStream(file));

			char[] buff = new char[256];
			while(in.read(buff) != -1) {
				// nije implementirana fja
				numOfChars++;
			}
			System.out.println(numOfChars);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			if(in != null)
				in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return numOfChars;
	}

}

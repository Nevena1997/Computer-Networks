package mi18461_Nikola_Kovacevic_B;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Scanner;

public class DrugiSearcher implements Runnable {

	private LinkedList<Path> paths;
	private char k;

	public DrugiSearcher(LinkedList<Path> paths, char k){
		this.paths = paths;
		this.k = k;
	}

	@Override
	public void run() {
		Path path = null;

		while(true){

			synchronized(paths){

				if(paths.isEmpty())
					break;
				else
					path = paths.pop();

				paths.notifyAll();
			}

			if(path != null)
				Search(path);
		}

		Thread.yield();
	}

	public void Search(Path path){
		InputStreamReader reader = null;

		try {
			int counter = 0;
			reader = new InputStreamReader(new FileInputStream(path.toString()));
			int slovo;

			while((slovo = reader.read()) != -1){
				if(slovo == k)
					counter++;
			}

			System.out.println(Thread.currentThread().getId()+":"+path.toString()+":"+counter);
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(reader != null)
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}

package mi18461_Nikola_Kovacevic_B;

import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Date;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.*;

public class Treci {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju/ime fajla");
		String fajl = sc.nextLine();
		sc.close();

		Path path = FileSystems.getDefault().getPath(fajl).toAbsolutePath();

		fajl = "FILE:/" + path.toString();

		URL url;
		try {
			url = new URL(fajl);

			sc = new Scanner(new BufferedReader(new InputStreamReader(
					url.openStream())));

			//Print celog fajla
			while(sc.hasNextLine()){
				String line = sc.nextLine();

				if(hasTxtFile(line)){
				//	if(lastDay(line)){
					String formatiran = FormatLogLine(line);
					System.out.println(formatiran);
				}
			}

			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(sc != null)
				sc.close();
		}

	}

	private static boolean lastDay(String line) {

		String[] dateStr = line.substring(1, line.indexOf(']')).split(".");
		Date date = null;
		//Nisam proveravoa da li je datum u ispravnom formatu

		date = Date.valueOf(dateStr[2]+"."+dateStr[1]+"."+dateStr[0]);
		System.out.println(dateStr);
		Date dateNow = new Date(System.currentTimeMillis());

		if(date != null)
			if(dateNow.getDay() - date.getDay() > 1)
				return false;

		return true;
	}

	private static String FormatLogLine(String line) {
		String[] parts = line.split(":");
		String ipVersion = "";

		//Ukoliko je treci split duzine 4, znamo da je to deo ipv6
		if(parts[3].length() == 4)
			ipVersion = "v6:";
		else
			ipVersion ="v4:";

		//Uzimamo od pozadi ostatak
		String protocol = parts[parts.length - 2] + ":";
		String file = parts[parts.length - 1].substring(parts[parts.length - 1].lastIndexOf('/'));

		return ipVersion + protocol +"/courses/rm" + file;
	}

	private static boolean hasTxtFile(String line) {

		if(!line.endsWith(".txt"))
			return false;

		return true;
	}

}

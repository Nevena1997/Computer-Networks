package mi18461_Nikola_Kovacevic_B;

import java.awt.List;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;

public class Drugi {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do fajla sa putanjama, n i k");
		String putanja = sc.nextLine();
		int n = sc.nextInt();
		char k = sc.next().charAt(0);

		sc.close();

		try{
			sc = new Scanner(new FileInputStream(putanja));
			LinkedList<Path> list = new LinkedList<Path>();

			//Ispis fajla
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				Path path = FileSystems.getDefault().getPath(line).toAbsolutePath();
				list.add(path);

				System.out.println(line);
			}

			//Threads
			for(int i = 0; i < n; i++){
				Thread thread = new Thread(new DrugiSearcher(list, k));
				thread.run();
			}

			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(sc != null)
				sc.close();
		}

	}

}

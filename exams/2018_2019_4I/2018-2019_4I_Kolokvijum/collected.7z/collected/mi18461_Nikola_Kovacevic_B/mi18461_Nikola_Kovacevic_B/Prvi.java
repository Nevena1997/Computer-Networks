package mi18461_Nikola_Kovacevic_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla");
		String file = sc.nextLine();
		sc.close();

		Scanner sr = null;
		BufferedWriter bw = null;

		try {
			sr = new Scanner(new BufferedReader(
					new InputStreamReader(new FileInputStream(file), "UTF-8")));

			bw = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			String adress ="";
			while(sr.hasNext()){
				adress = sr.next();

				if(isMailAdress(adress)){
					bw.write(adress);
					bw.newLine();
				}
			}

			bw.flush();
			sr.close();
			bw.close();
		} catch (FileNotFoundException e) {

			System.out.println("File not found ");
		} catch (UnsupportedEncodingException e) {

			System.out.println("Encoding not supported");
		} catch (IOException e) {

			System.out.println("I/O exception");
		}finally{

			if (sr != null)
				sr.close();

			if(bw != null){
				try {
					//bw.flush();
					bw.close();
				} catch (IOException e) {
					System.out.println("Flush exception in try/catch");
				}
			}
		}
	}


	private static boolean isMailAdress(String adress) {
		int a = adress.indexOf('@');
		int a2 = adress.lastIndexOf('@');

		if(a != a2)
			return false;

		if(a == -1)
			return false;

		int dot = adress.lastIndexOf('.');

		//Ako je tacka odmah iza @, nevalidna adresa (valjda?)
		if(dot == -1 || dot - 1 == a || dot < a)
			return false;

		return true;
	}

}
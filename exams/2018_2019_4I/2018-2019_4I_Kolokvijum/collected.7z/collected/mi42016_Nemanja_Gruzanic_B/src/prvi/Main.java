package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.next();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			Scanner sc1 = new Scanner(in);

			while(sc1.hasNext()){
				String rec = sc1.next();
				if((rec.indexOf(".") != -1) && (rec.indexOf("@") != -1)){
					String prviDeo = rec.substring(0, rec.indexOf("@"));
					String drugiDeo = rec.substring(rec.indexOf("@")+1, rec.indexOf("."));
					String treciDeo = rec.substring(rec.indexOf(".")+1);
					if(prviDeo.matches("[a-z0-9]+") && drugiDeo.matches("[a-z0-9]+") && treciDeo.matches("[a-z0-9]+")){
						out.write(rec + " ");
						out.write("\n");
					}
				}
			}
			out.close();
			sc1.close();
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println("nepodrzan encoding");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("Nije pronadjen fajl");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("desio se IOException");
			e.printStackTrace();
		}
		sc.close();
	}

}

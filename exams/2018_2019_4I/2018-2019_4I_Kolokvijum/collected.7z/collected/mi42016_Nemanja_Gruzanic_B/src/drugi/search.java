package drugi;

import java.util.concurrent.locks.Lock;

public class search implements Runnable {

	private String lokacija;
	private Character c;
	private Lock lock;

//	Public search(String Lokacija, Character c){
//
	//	this.lokacija = lokacija;
		//this.c = c;
	//}

	@Override
	public void run() {


	}

}

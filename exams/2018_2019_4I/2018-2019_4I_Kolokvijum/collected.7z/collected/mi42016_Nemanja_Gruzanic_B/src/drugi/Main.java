package drugi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));

			String key = sc.next();
			int n = sc.nextInt();
			String c = sc.next();

			Scanner sc1 = new Scanner(in);
			while(sc1.hasNextLine())
				System.out.println(sc1.nextLine());




			sc1.close();
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println("los encoding");
		} catch (FileNotFoundException e) {
			System.out.println("fajl ne postoji");
		} catch (IOException e) {
			System.out.println("neuspelo zatvaranje stream-a");
		}

		sc.close();

	}

}

package treci;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Paths;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ulaz = sc.nextLine();
		try {
			URL u = new URL("file:///" + Paths.get(ulaz).toAbsolutePath().toString());
	//		URL u = new URL("file:///C:/Users/nalog/Desktop/mi42016_Nemanja_Gruzanic_B/" + ulaz);
			URLConnection uc = u.openConnection();
			InputStream in = uc.getInputStream();
			Scanner sc1 = new Scanner(in);

			String putanjaDoResursa;
			String protocol;
			int ipv;


			while(sc1.hasNext()){
				String linija = sc1.next();
				String ext = linija.substring(linija.lastIndexOf("."));
				if(ext.equals(".txt")){
					String pom = linija.substring(linija.indexOf(":")+1, linija.lastIndexOf(":"));
					String[] pom1 = pom.split(":");
					if(pom1.length == 2)
						ipv = 4;
					else
						ipv = 6;
					protocol = pom1[pom1.length-1];
					putanjaDoResursa = linija.substring(linija.lastIndexOf("/"));

					System.out.println("v"+ ipv + ":" + protocol + ":" + putanjaDoResursa );
				}
			}

			sc1.close();
		} catch ( IOException e) {
			e.printStackTrace();
		}
		sc.close();

	}

}

package drugi;

import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Search implements Runnable {
	BlockingQueue<Path> q;
	String keyword;



	public Search(BlockingQueue<Path> q, String keyword) {
		this.q = q;
		this.keyword = keyword;
	}


	@Override
	public void run() {
		boolean done = false;
		try {
			while(!done){
				Path path = q.take();
				if(path.equals(TreeWalker.DUMMY)){
					done = true;
					q.put(path);
				}
				search(path);
			}
		} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}


	private void search(Path path) {
		try(Scanner sc = new Scanner(path)){
			int ln = 0;
			while(sc.hasNextLine()){
				ln++;
				String line = sc.nextLine();
				if(line.contains(keyword))
					System.out.println(path.getFileName() + ":" + ln);
			}
			sc.close();
		}catch (Exception e) {
			e.printStackTrace();
		}

	}



}

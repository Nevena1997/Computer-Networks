package drugi;

import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime tekstualnog fajla: ");
		String ime_fajla = sc.next();
		System.out.println("Broj n: ");
		int n = sc.nextInt();
		System.out.println("Kljucna rec: ");
		String rec = sc.next();
		BlockingQueue<Path> red = new ArrayBlockingQueue<>(n);

		//Path p = Paths.get(ime_fajla);
		TreeWalker tw = new TreeWalker(red, ime_fajla);
		Thread t = new Thread(tw);
		t.start();

		for(int i=0; i<n; i++){
			Search s = new Search(red, rec);
			Thread tr = new Thread(s);
			tr.start();
		}

		sc.close();
	}

}

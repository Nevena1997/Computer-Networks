package prvi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Unesite ime tekstualnog fajla: ");
		Scanner sc = new Scanner(System.in);
		String ime = sc.next();
		sc.close();

		try {
			Scanner in = null;
			in = new Scanner(new FileInputStream(ime), "UTF-8");
			//BufferedReader in = new BufferedReader(	new InputStreamReader(new FileInputStream(ime), "UTF-8"));
			BufferedWriter out = null;
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
			//Scanner i = new Scanner(new InputStreamReader , "UFT-8");

			String datum;
			while(in.hasNext()){
				datum = in.next();
				if(validan(datum)){
					out.write(datum);
					out.write('\n');
					out.flush();
				}
			}
			if(in != null)
				in.close();
			if(out != null)
				out.close();


		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}


	}

	private static boolean validan(String datum) {
		if(datum.length() != 10)
			return false;
		char[] niz = datum.toCharArray();
		if(!Character.isDigit(niz[0]) |
		   !Character.isDigit(niz[1]) |
		   !Character.isDigit(niz[3]) |
		   !Character.isDigit(niz[4]) |
		   !Character.isDigit(niz[6]) |
		   !Character.isDigit(niz[7]) |
		   !Character.isDigit(niz[8])
		   )
			return false;
		if(niz[2] != '-' | niz[5] != '-')
			return false;

		int br1 = new Integer(Character.toString(niz[0]));
		int br2 = new Integer(Character.toString(niz[1]));
		if(br1*10+br2 > 31)
			return false;
		br1 = new Integer(Character.toString(niz[6]));
		br2 = new Integer(Character.toString(niz[7]));
		int br3 = new Integer(Character.toString(niz[8]));
		int br4 = new Integer(Character.toString(niz[9]));
		if(br1*1000+br2*100+br3*10+br4 < 2000)
			return false;

		//int br = new Integer(niz.toString().substring(0, 1));
		//System.out.println(br);
		//if(br > 31)
			//return false;
		return true;
	}


}

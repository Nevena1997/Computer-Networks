package drugi;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class TreeWalker implements Runnable{
	public static Path DUMMY = Paths.get("");
	private BlockingQueue<Path> red;
	String poc_fajl;
 	public TreeWalker(BlockingQueue<Path> red, String ime_fajla) {
 		this.red = red;
 		this.poc_fajl = ime_fajla;
	}
	@Override
	public void run() {
		try {
			walk( Paths.get(this.poc_fajl));
			red.put(DUMMY);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	private void walk(Path fajl) throws InterruptedException {
		try {
			DirectoryStream<Path> files = Files.newDirectoryStream(fajl);
			for(Path putanja : files){
				if( Files.isDirectory(putanja))
					walk(putanja);
				else{
					red.put(putanja);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

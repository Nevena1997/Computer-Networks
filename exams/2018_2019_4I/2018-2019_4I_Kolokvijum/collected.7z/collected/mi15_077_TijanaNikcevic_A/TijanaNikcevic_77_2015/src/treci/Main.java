package treci;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try{
			Scanner sc = null;
			sc = new Scanner(System.in);
			System.out.println("Ime regularnog fajla: ");
			String reg_fajl = sc.next();
			//URL u = new URL(reg_fajl);
			//URLConnection uc = u.openConnection();
			Scanner in = null;
			in = new Scanner( new FileReader(reg_fajl));

			while(in.hasNextLine()){
				String line = in.nextLine();
				String pom = line.substring(line.indexOf(':')).substring(line.indexOf(':'));
				URL u_pom = new URL(pom);
				//if(u_pom.getHost().equals())
				URLConnection uc = u_pom.openConnection();
				Inet4Address a4;
				Inet6Address a6;

				if(pom.contains("ftp") | pom.contains("sftp"))
					System.out.println(line);

			}
			sc.close();
			in.close();
		}catch (MalformedURLException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}

package zadatak3;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class urlReader {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		String path = in.nextLine();
		InputStreamReader fileInput = null;

		try {
			URL file = new URL("file://" + path);
			fileInput = new InputStreamReader(file.openStream());
			int c;
			while((c = fileInput.read()) != -1)
			{
				System.out.write(c);
			}
			System.out.println();

		}
		catch (MalformedURLException e)
		{

		}
		catch (IOException e)
		{

		}
		finally
		{
			in.close();
			try {
				fileInput.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}

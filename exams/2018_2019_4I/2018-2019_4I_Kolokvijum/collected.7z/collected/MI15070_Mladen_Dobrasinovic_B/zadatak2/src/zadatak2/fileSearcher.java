package zadatak2;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.concurrent.BlockingQueue;

public class fileSearcher implements Runnable {

	int k;
	BlockingQueue<String> list;

	fileSearcher (int k, BlockingQueue<String> list)
	{
		this.k = k;
		this.list = list;
	}

	@Override
	public void run() {
		String filename;
		try {
			while(true)
			{
				synchronized (list)
				{
					if(list.isEmpty())
						break;

					filename = list.take();
				}

				searchFile(filename);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
		}
	}

	private void searchFile(String filename)
	{

		try {
			InputStream in = new FileInputStream(filename);

			int c;
			int count = 0;

			while((c = in.read()) != -1)
			{
				if(c == k)
					count++;
			}

			in.close();
			System.out.println(Thread.currentThread().getId() + ":" + filename + ":" + count);
		}
		catch (Exception e) {
			// ovaj izuzetak ne prosledjujemo, izuzetak je u vezi datoteka
		}
	}

}

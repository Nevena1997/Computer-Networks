package zadatak2;

import java.io.FileInputStream;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Lock;

public class characterSearch {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Scanner din = null;

		try
		{
			String dirname = in.nextLine();
			din = new Scanner(new FileInputStream(dirname));

			BlockingQueue<String> list = new ArrayBlockingQueue<String>(100000);

			while(din.hasNext())
			{
				String next = din.next();
				System.out.println(next);
				list.add(next);
			}

			int n = in.nextInt();
			String kString = in.next();

			int k = kString.codePointAt(0);

			Thread[] threads = new Thread[n];
			for(int i = 0; i < n; i++)
			{
				threads[i] = new Thread(new fileSearcher(k, list));
				threads[i].start();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}

package zadatak1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.Scanner;

public class FileCopy {

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		Scanner sin = null;
		Writer sout = null;

		try
		{
			String filename = in.nextLine();

			sin = new Scanner(new BufferedInputStream(new FileInputStream(filename)), "UTF-8");
			sout = new PrintWriter(new BufferedOutputStream(new FileOutputStream("emails.txt")));

			while(sin.hasNext())
			{
				String text = sin.next();
				if(text.matches("[a-z0-9]+@[0-9a-z]+\\.[0-9a-z]+"))
					sout.write(text + "\n");
			}

		}
		catch(IOException e)
		{
			System.err.println("Greska u ulazu/izlazu.");
			e.printStackTrace();
		}
		finally
		{
			in.close();
			if(sin != null)
				sin.close();
			try {
				if(sout != null)
					sout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

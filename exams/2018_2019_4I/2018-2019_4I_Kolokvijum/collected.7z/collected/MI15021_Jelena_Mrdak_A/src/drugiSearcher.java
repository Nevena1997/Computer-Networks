import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class drugiSearcher implements Runnable {
	
	private BlockingQueue<Path> queue;
	private String keyword;
	
	public drugiSearcher(BlockingQueue<Path> queue, String keyword) {
		this.queue = queue;
		this.keyword = keyword;
	}

	@Override
	public void run() {
		boolean done = false;
		
		try {
			while (!done) {
				Path p = queue.take();
				if (p.equals(drugiTraveler.DUMMY)) {
					queue.put(p);
					done = true;
				}
				else {
					find(p);
					Thread.sleep((long) (Math.random()*100));
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void find(Path p) {
		Scanner sc = null;
		try {
			sc = new Scanner(p);
			int line = 0;
			while (sc.hasNextLine()) {
				line++;
				String s =sc.nextLine();
				if (s.contains(keyword)) {
					Scanner sc2 = new Scanner(s);
					while (sc2.hasNext()) {
						if (sc2.next().equals(keyword)) {
							System.out.println(Thread.currentThread().getId()+":"+p.toString()+":"+Integer.toString(line));
						}
					}
					sc2.close();	
				}
			}
		} catch (IOException e) {
			// file not found but ignore it
		} finally {
			if (sc != null)
				sc.close();
		}
	}
	
}

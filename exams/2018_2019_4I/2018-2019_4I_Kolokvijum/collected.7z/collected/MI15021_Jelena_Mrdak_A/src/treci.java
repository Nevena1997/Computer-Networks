import java.awt.FocusTraversalPolicy;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class treci {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Path p = Paths.get(sc.next());
		sc.close();

		Scanner sc2 = null;
		try {
			sc2 = new Scanner(p.getFileName());
			while (sc2.hasNextLine()) {
				String s = sc2.nextLine();

				String s2 = s.substring(0,s.lastIndexOf(':'));
				String s3 = s.substring(s.lastIndexOf(':'));
				String urlStr = s2.substring(s2.lastIndexOf(':')+1)+s3;
				String s4 = s2.substring(0,s2.lastIndexOf(':'));
				String ip = s4.substring(s4.indexOf(':')+1);


				URL url = new URL(urlStr);
				String protocol = url.getProtocol();
				InetAddress addr = InetAddress.getByName(ip);
				byte[] x = addr.getAddress();


				if (protocol.toLowerCase().equals("ftp") || protocol.toLowerCase().equals("sftp")) {
					if (x.length == 4) {
						System.out.println("v4:"+protocol+url.getFile());
					} else if (x.length == 16) {
						System.out.println("v6:"+protocol+url.getFile());
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (sc2 != null)
				sc2.close();
		}
	}

}

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class drugiTraveler implements Runnable {
	public static final Path DUMMY = Paths.get("");
	private Path path;
	private BlockingQueue<Path> queue;
	
	public drugiTraveler(Path path, BlockingQueue<Path> queue) {
		this.path = path;
		this.queue = queue;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
		
			Scanner sc = new Scanner(path);
			while (sc.hasNextLine()) {
				String s = sc.nextLine();
				Path p = Paths.get(s);
				queue.put(p);
			}
			
			queue.put(DUMMY);
			sc.close();
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

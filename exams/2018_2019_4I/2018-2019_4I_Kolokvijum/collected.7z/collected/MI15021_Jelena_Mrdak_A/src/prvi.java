import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class prvi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();
		sc.close();
		
		Scanner in = null;
		BufferedWriter out = null;
		
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
			
			while (in.hasNext()) {
				String s = in.next();
				if (s.matches("(0[1-9]|1[0-9]|2[0-9]|30|31)-(0[1-9]|1[0-2])-2[0-9][0-9][0-9]")) {
					out.write(s);
					out.newLine();
				}
			}
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("file not found");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("input/output error");
			e.printStackTrace();
		} finally {
			if (in != null)
				in.close();
			
			if (out != null) {
				try {
					out.flush();
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		

	}

}

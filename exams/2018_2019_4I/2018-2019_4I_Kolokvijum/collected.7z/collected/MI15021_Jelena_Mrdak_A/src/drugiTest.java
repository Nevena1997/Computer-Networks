import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class drugiTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Path s = Paths.get(sc.next());
		
		BlockingQueue<Path> queue = new LinkedBlockingQueue<>();
		drugiTraveler traveler = new drugiTraveler(s, queue);
		new Thread(traveler).start();
		Thread.sleep(100);
	
		String keyword = sc.next();		
		int n = sc.nextInt();
		sc.close();
		
		for (int i=0; i<n; i++) {
			new Thread(new drugiSearcher(queue, keyword)).start();
		}
		
		
	}

}

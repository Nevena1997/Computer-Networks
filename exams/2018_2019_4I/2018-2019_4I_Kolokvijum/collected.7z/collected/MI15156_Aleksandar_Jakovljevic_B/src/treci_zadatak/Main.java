package treci_zadatak;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BufferedReader in = null;
		try {
			URL url = new URL(sc.next());
			sc.close();
			in = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
			String line;
			while((line = in.readLine()) != null){
				if (line.contains(".txt")){
					String[] info = line.split(":");
					String datum = info[0].substring(1, info[0].length()-1);
					String[] datum_split = datum.split("\\."); // Ne radi? :/
					String s = new Date(System.currentTimeMillis()).toString();

					char[] dan = datum_split[0].toCharArray();
					dan[1]++;
					String novi_datum = Character.toString(dan[0])+ Character.toString(dan[1]) + "." + datum_split[1] +"."+ datum_split[2];
					if (!novi_datum.equals(s))
						continue;
					String ipAddress = info[1];
					String protocol = info[2];
					String path = info[3].substring(info[3].lastIndexOf('/'));
					int version = getVersion(ipAddress);
					System.out.println("v"+version+":"+protocol+":"+path);
				}
			}

		}
		catch (Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sc.close();
		}


	}

	private static int getVersion(String ipAddress) {
		if ( ipAddress.contains("."))
			return 4;
		else if ( ipAddress.contains(":"))
			return 6;
		else{
			System.err.println("Faulty ip adress");
			return -1;
		}
	}
}

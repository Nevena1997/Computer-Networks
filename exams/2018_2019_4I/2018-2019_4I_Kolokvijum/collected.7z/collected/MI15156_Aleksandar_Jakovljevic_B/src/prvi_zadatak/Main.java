package prvi_zadatak;

import java.io.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = null;
		BufferedReader in = null;
		BufferedWriter out = null;;
		try {
		sc = new Scanner(System.in);
		in = new BufferedReader(new InputStreamReader(new FileInputStream(sc.next()), "UTF-8"));
		out =new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

		String s;
		while((s = in.readLine()) != null){
			String[] emails = s.split(" ");
			for(String email : emails){
				if ( email.matches("[a-zA-Z0-9.]+[@][a-zA-Z0-9]+(.[a-zA-Z0-9]+)+")){
					System.out.println("Hi!");
					out.write(email);
					out.newLine();
				}
			}
		}

		sc.close();
		in.close();
		out.close();
		}
		catch (IOException e){

		}
		finally {
			sc.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.err.println("IO Greska" + e);
			}
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.err.println("IO Greska" + e);
			}
		}
	}

}

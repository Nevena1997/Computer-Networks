 package drugi_zadatak;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static final int QUEUE_SIZE = 100;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Scanner sc1 = null;;
		try {
			sc1 = new Scanner(new File(sc.nextLine()));
			int n = sc.nextInt();
			char k = sc.next().charAt(0);
			sc.close();
			String line;
			BlockingQueue<Path> fileQueue = new ArrayBlockingQueue<Path>(QUEUE_SIZE);
			while(sc1.hasNextLine()){
				line = sc1.nextLine();
				Path p = Paths.get(line);
				fileQueue.add(p);
				//System.out.println(p);
			}
			fileQueue.add(Paths.get(""));
			sc1.close();
			FileWalker fw = new FileWalker(fileQueue, k);
			for(int i = 0; i < n; i++){
				new Thread(new SearchRunnable(fw)).start();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("continue...\n");
		}
		finally {
			sc1.close();
			sc.close();
		}
		sc1.close();


	}

}

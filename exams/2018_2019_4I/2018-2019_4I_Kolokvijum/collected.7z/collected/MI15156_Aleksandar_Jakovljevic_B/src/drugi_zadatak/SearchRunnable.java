package drugi_zadatak;

import java.nio.file.Path;

public class SearchRunnable implements Runnable{
	FileWalker fw;
	public SearchRunnable(FileWalker fw) {
		this.fw = fw;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void run() {
		boolean done = false;
		while(!done){
			try {
				// Moralo je ovako, nije registrovalo.
				Path p = fw.fileQueue.take();
				if ( p.toString().length() == 0) {
					done = true;
					fw.fileQueue.add(p);
				}
				else {
					this.fw.search(p);
				}
			Thread.sleep((int)Math.random()*5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

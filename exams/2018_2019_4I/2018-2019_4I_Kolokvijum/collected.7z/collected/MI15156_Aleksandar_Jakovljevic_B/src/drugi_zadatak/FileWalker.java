package drugi_zadatak;

import java.io.File;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class FileWalker {
	BlockingQueue<Path> fileQueue;
	char k;
	public FileWalker(BlockingQueue<Path> fileQueue, char k) {
		this.fileQueue = fileQueue;
		this.k = k;
	}

	public synchronized  void search(Path p) throws InterruptedException{
		while(this.fileQueue.isEmpty()){
			this.wait();
		}
		Scanner fileScanner = null;
		try {
			try {
				fileScanner = new Scanner(new File(p.toString()));
			}
			catch (Exception e){
				System.err.println("No file, or DUMMY continue...\n");
			}
			int counter = 0;
			while(fileScanner.hasNextLine()){
				char[] line = fileScanner.nextLine().toCharArray();
				for(char c : line){
					if ( c == k) {
						counter++;
					}
				}
			}
			System.out.println("<"+Thread.currentThread().getId() +">:<"+ p.toString()+">:<"+counter+">");
		} catch (Exception e) {

		}

		this.notifyAll();
	}
}

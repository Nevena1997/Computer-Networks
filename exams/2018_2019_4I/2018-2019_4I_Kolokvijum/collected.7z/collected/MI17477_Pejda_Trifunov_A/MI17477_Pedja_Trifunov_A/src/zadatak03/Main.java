package zadatak03;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;


public class Main {
	public static void main(String[] args){

		String fileName = "";

		Scanner in = new Scanner(System.in);
		System.out.print("Unseite ime fajla: ");
		fileName = in.next();
		in.close();


		Path p = Paths.get("./src/zadatak03", fileName);
		Scanner logFile = null;

		try {
			logFile = new Scanner(new URL("file:///" + p.toAbsolutePath()).openStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Fajl ne postoji");
			System.exit(1);
		}

		String[] fileds = null;
		String format = "v%d:%s:%s";
		int ipVersion = 4;
		String protocol = "ftp";
		String filePath = "";

		while(logFile.hasNextLine()){
			fileds = logFile.nextLine().split(":");

			protocol = fileds[fileds.length - 2];
			if(!protocol.equals("ftp") && !protocol.equals("sftp")){
				continue;
			}
			ipVersion = (fileds.length == 4) ? 4 : 6;
			filePath = getFilePath(fileds[fileds.length-1]);
			System.out.println(String.format(format, ipVersion, protocol, filePath));
		}

		logFile.close();
	}

	private static String getFilePath(String s){
		StringBuilder sb = new StringBuilder();
		String[] tmp = s.split("/");
		for(int i = 3; i < tmp.length; ++i){
			sb.append(tmp[i]);
			if(i +1 != tmp.length){
				sb.append("/");
			}

		}

		return sb.toString();
	}
}

package zadatak02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		String fileName = "";
		String needle = "";
		int nThreads = 0;


		Scanner sc = new Scanner(System.in);

		System.out.print("Unesite ulazni fajl: ");
		fileName = sc.next();
		System.out.print("Unesite kljucnu rec: ");
		needle = sc.next();
		System.out.print("Unesite broj niti: ");
		nThreads = sc.nextInt();

		sc.close();

		Scanner fileSc = null;
		try {
			fileSc = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			System.err.println("Fajl sa putajnama ne postoji");
			System.exit(1);

		}

		ArrayList<String> paths = new ArrayList<>();
		String path = "";

		System.out.println("Pronadjene putanje su:");
		while(fileSc.hasNext()){
			path = fileSc.next();
			paths.add(path);
			System.out.println(path);
		}

		fileSc.close();

		Thread[] t = new Thread[nThreads];

		for(int i = 0; i < nThreads; ++i)
		{
			t[i] = new Thread(new SearchRun(i, paths, needle));
			t[i].start();
		}

		for(int i = 0; i< nThreads; ++i)
		{
			try {
				t[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}




















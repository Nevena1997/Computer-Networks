package zadatak02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;



public class SearchRun implements Runnable{

	private ArrayList<String> paths;
	private String needle;
	private String format;
	private int id;

	public SearchRun(int id, ArrayList<String> paths, String needle) {
		this.paths = paths;
		this.needle = needle;
		this.id = id;
		this.format = "%d:%s:%d";
	}

	@Override
	public void run() {

		String path = "";
		Scanner sc = null;
		String line = null;
		int lineCount = 0;

		while(true){
			synchronized (paths) {
				if(paths.isEmpty())
				{
					break;
				}

				path = paths.get(0);
				paths.remove(0);
			}

			try {
				 sc = new Scanner(new File(path));
			} catch (FileNotFoundException e) {

				continue;
			}

			while(sc.hasNextLine()){
				line = sc.nextLine();
				++lineCount;
				if(line.contains(needle))
				{
					System.out.println(String.format(format, id, path, lineCount));
				}

			}

			lineCount = 0;
			line = null;
			sc.close();
			sc = null;
			/* small files give other threads a chance :)
			 * try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
*/		}
	}
}

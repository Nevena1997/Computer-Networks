package zadatak01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
	public static void main(String[] args){
		String fileName = "";
		Scanner sc = new Scanner(System.in);

		System.out.print("Unesite ime fajla: ");
		fileName = sc.next();

		sc.close();

		BufferedReader r = null;
		BufferedWriter w = null;
		try {
			r = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
			w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/zadatak01/timestamps.txt"), "UTF-8"));
		} catch (UnsupportedEncodingException e) {

			System.err.println("Nije pordrzan enkoding za otvaranja fajla");
			System.exit(1);
		} catch (FileNotFoundException e) {
			System.err.println("Fajl nije pronadjen");
			System.exit(1);
		}

		String line = null;
		String[] words = null;
		Pattern regex = Pattern.compile("^(\\d{2}-\\d{2}-\\d{4})[.,!?]*\\s*$");

		try {
			while((line = r.readLine()) != null){
				words = line.split(" ");

				for(String word : words){
					Matcher m = regex.matcher(word);
					if(m.find()){
						w.write(m.group(1));
						w.newLine();
					}
				}
			}
		} catch (IOException e) {
			System.err.println("Greska prilikom citanja ili pisanja u fajl");
			try {
				r.close();
				w.close();
			} catch (IOException e1) {
				System.err.println("Greksa prilikom zatvaranja resursa");
			}

			System.exit(1);
		}

		try {
			r.close();
			w.close();
		} catch (IOException e) {
			System.err.println("Greska prilikom zatvaranja fajl");
			System.exit(1);
		}
	}
}

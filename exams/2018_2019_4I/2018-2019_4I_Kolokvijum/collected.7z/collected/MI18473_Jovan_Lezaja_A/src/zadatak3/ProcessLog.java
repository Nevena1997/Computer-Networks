package zadatak3;

public class ProcessLog implements Runnable {

	private PooledWeblog weblog;

	public ProcessLog(PooledWeblog weblog) {
		this.weblog = weblog;
	}

	@Override
	public void run() {

		String entry = null;

		if (weblog.entries.size() == 0) {
			if (weblog.isFinished()) {
				return;
			}
			try {
				weblog.entries.wait();
			} catch (InterruptedException e) {

			}

			entry = weblog.entries.remove(weblog.entries.size() - 1);
		}

		if (entry == null)
			return;

		String substr = entry.substring(0, entry.lastIndexOf(":"));
		String protocol = substr.substring(substr.lastIndexOf(":"));
		if (protocol.equals("ftp") || protocol.equals("sftp")) {
			weblog.log(entry);
		}

		this.notifyAll();
	}
}

package zadatak3;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class PooledWeblog {

	private BufferedReader in;
	private BufferedWriter out;
	private boolean finished = false;
	public List<String> entries = Collections.synchronizedList(new LinkedList<String>());
	private int numOfThreads;

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String filename = sc.nextLine();
		sc.close();

		BufferedInputStream in = null;
		try {
			URL url = new URL("file://" + filename);
			in = new BufferedInputStream(url.openStream());

			int c;
			while((c = in.read()) != -1) {
				System.out.println((char) c);
			}
			in.close();

			PooledWeblog weblog = new PooledWeblog(url.openStream(), System.out, 10);
			for (int i = 0; i < 10; i++) {
				Thread t = new Thread(new ProcessLog(weblog));
				t.start();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public PooledWeblog(InputStream in, PrintStream out, int numOfThreads) {
		this.in = new BufferedReader(new InputStreamReader(in));
		this.out = new BufferedWriter(new OutputStreamWriter(out));
		this.numOfThreads = numOfThreads;
	}

	public void read() {
		String entry;

		if (entries.size() > this.numOfThreads) {
			try {
				this.wait((long) 1000 / numOfThreads);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		synchronized (entries) {
			try {
				entry = in.readLine();
				entries.add(entry);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		finished = true;
		this.notifyAll();

		Thread.yield();
	}

	public boolean isFinished() {
		return finished;
	}

	public void log(String line) {
		int first = line.indexOf(":");
		int second = line.substring(first).indexOf(":");

		String ip = line.substring(first, second);
		int ipv = 4;
		if (ip.contains(":")) {
			ipv = 6;
		}

		String url = line.substring(second);
		String protocol = url.substring(0, url.indexOf(":"));

		String path = url.substring(url.lastIndexOf("/"));
		try {
			out.write("v"+ipv+":"+protocol+":"+path);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

package zadatak2;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class FileTreeWalker {

	private List<String> paths = Collections.synchronizedList(new LinkedList<String>());
	private String word;

	public FileTreeWalker(List<String> paths, String word) {
		this.paths = paths;
		this.word = word;
	}

	public synchronized void walk() {

	}

}

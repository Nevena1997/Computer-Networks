package zadatak2;


public class WalkerRunnable implements Runnable {

	private FileTreeWalker ftw;

	public WalkerRunnable(FileTreeWalker ftw) {
		this.ftw = ftw;
	}

	@Override
	public void run() {
	}

}

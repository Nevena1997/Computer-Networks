package zadatak2;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);

		List<String> list = Collections.synchronizedList(new LinkedList<String>());

		while (sc.hasNextLine()) {
			list.add(sc.next());
		}

		System.out.println(list.toString());

		if (!sc.hasNext()) {
			System.out.println("Molim vas unesite kljucnu rec...");
		}
		String keyword = sc.next();

		if (!sc.hasNext()) {
			System.out.println("Molim vas unesite broj niti...");
		}
		int n = sc.nextInt();

		sc.close();

		FileTreeWalker ftw = new FileTreeWalker(list, keyword);

		for (int i = 0; i < n; i++) {
			Thread t = new Thread(new WalkerRunnable(ftw));
			t.start();
		}
	}
}

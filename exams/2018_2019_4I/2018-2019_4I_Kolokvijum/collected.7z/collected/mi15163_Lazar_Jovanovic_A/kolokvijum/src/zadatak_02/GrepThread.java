package zadatak_02;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class GrepThread extends Thread {

	private ConcurrentLinkedQueue<String> queue;
	private String key;

	public GrepThread(ConcurrentLinkedQueue<String> queue, String key) {
		this.queue = queue;
		this.key = key;
	}

	@Override
	public void run() {
		String path;
		while ((path = queue.poll()) != null) {
			try {
				Scanner in = new Scanner(
								new InputStreamReader(
									new BufferedInputStream(
										new FileInputStream(path))));
				int lineCounter = 0;
				while (in.hasNextLine()) {
					lineCounter++;

					String line = in.nextLine();
					if (line.contains(key)) {
						System.out.println(Thread.currentThread() + ":" + path + ":" + lineCounter);
					}
				}

				in.close();
			} catch (FileNotFoundException e) {
				System.out.println("File not found: " + path);
			} catch (Exception e) {
				System.out.println("FATAL ERROR");
			}
		}
	}
}

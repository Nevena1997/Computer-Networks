package zadatak_02;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Grep {

	public static void main(String[] args) {
		System.out.println("Putanja do tekstualnog fajla: ");

		Scanner sc = new Scanner(System.in);
		String pathToFile = sc.next();

		System.out.println("Broj niti: ");
		int threadNum = sc.nextInt();

		System.out.println("Trazena rec: ");
		String key = sc.next();

		ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();

		try {
			Scanner in = new Scanner(
							new InputStreamReader(
								new BufferedInputStream(
									new FileInputStream(pathToFile))));

			while (in.hasNextLine()) {
				String line = in.next();
				if (line.isEmpty()) continue;
				queue.add(line);
			}

			for (int i = 0; i < threadNum; i++) {
				GrepThread t = new GrepThread(queue, key);
				t.start();
			}

			in.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + pathToFile);
		} finally {
			sc.close();
		}
	}

}

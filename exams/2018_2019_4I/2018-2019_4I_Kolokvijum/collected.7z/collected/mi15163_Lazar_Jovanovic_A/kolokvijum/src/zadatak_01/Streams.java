package zadatak_01;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Streams {

	public static void main(String[] args) {
		System.out.print("Fajla: ");

		Scanner sc = new Scanner(System.in);

		try {
			InputStreamReader in = new InputStreamReader(
										new BufferedInputStream(
											new FileInputStream(sc.next())), "UTF-8");

			OutputStreamWriter out = new OutputStreamWriter(
										new BufferedOutputStream(
											new FileOutputStream("timestamps.txt")), "UTF-8");

			Scanner input = new Scanner(in);
			PrintWriter pw = new PrintWriter(out);

			while (input.hasNext()) {
				String word = input.next();

				String re = "((0[1-9])|([12][0-9])|(3[01]))-((0[1-9])|(1[0-2]))-(2[0-9]{3})";
				if (word.matches(re)) {
					pw.write(word + "\n");
				}
			}

			input.close();
			pw.close();

			in.close();
			out.close();
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			sc.close();
		}
	}

}

package p03_urls;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		String filePath = sc.next();
		sc.close();

		Scanner in = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(filePath))));

			while(in.hasNextLine()) {
				String line = in.nextLine();

				int firstDoublePoint = line.indexOf(':');

				int indexOfUrl = line.indexOf(":", firstDoublePoint+1); // trazim prvu dvotacku posle prve dvotacke :/
				String urlName = line.substring(indexOfUrl+1); //od druge dvotacke pa plus jedan da ne bi bila : u url
				URL url = new URL(urlName);

				//version
				String urlArray = line.substring(firstDoublePoint + 1, indexOfUrl);
				int v = 4;
				if(urlArray.contains(":"))
					v = 6;

				//protocol
				String protocol = url.getProtocol();
				if(protocol.equalsIgnoreCase("ftp") || protocol.equalsIgnoreCase("sftp")) {
					System.out.println("v" + v + ":" + protocol + ":" + url.getPath());
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println(":(");
		} finally {
			if(in != null) {
				in.close();
			}
		}
	}
}

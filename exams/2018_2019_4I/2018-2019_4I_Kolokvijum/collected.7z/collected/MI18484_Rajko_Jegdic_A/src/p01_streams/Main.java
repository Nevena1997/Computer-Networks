package p01_streams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String inFileName = sc.next();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(inFileName), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(sc.hasNext()) {
				String date = sc.next();
				if(isRegular(date)) {
					try {
						out.write(date);
						out.newLine();
					} catch (IOException e) {
						System.err.println("Greskica! :'(");
					}
				}
			}

		} catch (UnsupportedEncodingException e) {
			System.err.println("Enkodiranje nije podrzano! :((");
		} catch (FileNotFoundException e) {
			System.err.println("Greska sa fajlom! :(");
		} finally {
			if(in != null) {
				in.close();
			}
			if(out != null) {
				try {
					out.flush();
					out.close();
				} catch (IOException e) {
					System.err.println("Greskica sa fajlicem! :((");
				}
			}
		}
	}

	private static boolean isRegular(String date) {
		Boolean ind = null;

		if(date.length() != 10)
			ind = false;

		//DD-MM-YYYY
		String regex = "((3[01])|([12][0-9])|(0[1-9]))-((0[1-9])|(1[12]))-((2[0-9]{2}[1-9])|(2[0-9][1-9][0-9])|(2[1-9][0-9]{2}))";
		ind = date.matches(regex);

		return ind;
	}

}

package treci;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class ParserMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String path = sc.nextLine();

		Scanner in = null;
		try{
			URL url = new URL("file://"+path);
			URLConnection urc = url.openConnection();
			System.out.println(".");
			in = new Scanner(urc.getInputStream());
			System.out.println(".");

			while(in.hasNextLine()){
				System.out.println(".");
				System.out.println(in.nextLine());
			}

		}
		catch(MalformedURLException e){
			System.err.println("Invalid URL!");
		}
		catch(IOException e){
			System.err.println("I/O Error!");
		}
		finally{
			in.close();
			sc.close();
		}

	}

}

package drugi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

public class Searcher implements Runnable{
	private String keyword;
	private List<File> paths;
	private int id;

	public Searcher(String keyword, List<File> paths, int id){
		this.keyword = keyword;
		this.paths = paths;
		this.id = id;
	}

	@Override
	public void run(){
		Scanner in = null;
		File file = null;
		synchronized (paths) {
			if(paths.size() == 0)
				return;
			file = paths.remove(paths.size()-1);
		}
		try{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file))));
			int lineNum = 0;
			while(in.hasNextLine()){
				lineNum++;
				String line = in.nextLine();
				String[] words = line.split(" ");
				for(String word: words){
					if(word.equals(keyword))
						System.out.println(this.id+":"+file.getAbsolutePath()+":"+lineNum);
				}
			}
		}
		catch(FileNotFoundException e){
			System.err.println("File " + file.getName() + " is not found!");
		}
		finally{
			in.close();
		}
	}

}

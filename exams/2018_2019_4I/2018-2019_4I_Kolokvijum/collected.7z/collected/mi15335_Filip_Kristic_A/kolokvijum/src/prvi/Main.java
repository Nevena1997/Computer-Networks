package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(in.hasNext()){
				String word = in.next();
				if(isValidDate(word)){
					out.write(word);
					out.newLine();
				}
			}

		}

		catch(UnsupportedEncodingException e){
			System.err.println("This system does not support UTF-8 enconding o.O");
		}
		catch(FileNotFoundException e){
			System.err.println("File " + file + "is not found!");
		}
		catch(IOException e){
			System.err.println("Failed to Read/Write file!");
		}
		finally{
			try{
				in.close();
				out.flush();
				out.close();
			}
			catch(IOException e){
				System.err.println("Failed to close streams!");
			}
		}

	}

	public static boolean isValidDate(String date){
		if(date.chars().anyMatch(c-> Character.isAlphabetic(c)) || !date.contains("-"))
			return false;
		String[] parts = date.split("-");
		//Forgot how to convert String to Int :(
		/*if(parts[0] > 31 || parts[2] < 2000)
			return false;*/

		return true;
	}

}

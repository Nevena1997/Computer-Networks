package mi16422_Dragica_Andjelkovic_B;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class Drugi {


	public static void main(String[] args) {
		//treba uraditi ucitavanje
		String putanja = "drugi.txt";
		Scanner sc = null;

		try {

			sc = new Scanner(new File(putanja));
			BlockingQueue<Path> queue = new ArrayBlockingQueue<>(10);

			while(sc.hasNextLine()){
				String line = sc.nextLine();
				System.out.println(line);
				queue.put(Paths.get(line));
			}



			Scanner in = new Scanner(System.in);
			System.out.println("Unesite broj n: ");
			int n = in.nextInt();
			System.out.println("Unesite karakter k: ");
			char k = in.next().charAt(0);
			in.close();

			for(int i = 0; i < n; i++)
				new Thread(new BrojPojavljivanja(queue, k)).start();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			sc.close();
		}



	}

}

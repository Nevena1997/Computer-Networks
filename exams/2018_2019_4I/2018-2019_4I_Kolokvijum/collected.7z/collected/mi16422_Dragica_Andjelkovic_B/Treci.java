package mi16422_Dragica_Andjelkovic_B;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;


public class Treci {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Unesite ime fajla:");
		String imeFajla = in.next();
		in.close();

		Scanner sc = null;

		try {
			sc = new Scanner(new File(imeFajla));
			while(sc.hasNext()){
				String line = sc.next();
				String[] str = line.split(":");

				int dan = Integer.parseInt(str[0].substring(1, str[0].indexOf(".")));
				int danasnji_dan = new Date().getDate();


				String host = str[1];
				//System.out.println(host);
				String string_url = str[2] + ":" + str[3];
				//System.out.println(string_url);
				URL url = new URL(string_url);

				if(dobra_ekstenzija(url) && (danasnji_dan == dan + 1))
					System.out.println("v" + getVersion(InetAddress.getByName(host))+ " : " + url.getProtocol() + " : " + url.getPath());


			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(MalformedURLException e){
			e.printStackTrace();
		} catch(UnknownHostException e){
			e.printStackTrace();
		} finally{
			sc.close();
		}
	}

	public static boolean dobra_ekstenzija(URL url){
		String path = url.getPath();
		String ekstenzija = path.substring(path.lastIndexOf('.') + 1);
		//System.out.println(ekstenzija);

		if(ekstenzija.equalsIgnoreCase("txt"))
			return true;
		return false;
	}
	public static int getVersion(InetAddress add){
		byte[] address = add.getAddress();
		int n = address.length;

		if(n == 4)
			return 4;
		else if(n == 16)
			return 6;
		else
			return -1;

	}

}

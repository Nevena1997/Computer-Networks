package mi16422_Dragica_Andjelkovic_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String fileName = sc.next();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			while(in.hasNext()){
				String word = in.next();

				if(word.matches("[a-zA-Z0-9]+[@][a-zA-Z0-9]+[.][a-zA-Z0-9]+")){
					//System.out.println(word);
					out.write(word);
					out.newLine();
				}
			}

			in.close();
			out.flush();
			out.close();

		} catch (FileNotFoundException e) {
			System.err.println("Nije pronadjen fajl");
		} catch(IOException e){
			System.err.println("IOException ");
		} finally{


			try {
				if(in == null)
					in.close();

				if(out == null){
					out.flush();
					out.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}


		}


	}

}

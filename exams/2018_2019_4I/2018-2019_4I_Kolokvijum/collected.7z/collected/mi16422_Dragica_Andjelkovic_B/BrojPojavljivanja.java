package mi16422_Dragica_Andjelkovic_B;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;


public class BrojPojavljivanja implements Runnable {

	Path DUMMY = Paths.get("");
	private BlockingQueue<Path> queue;
	private char k;
	private int count;
	boolean postoji = true;
	public BrojPojavljivanja(BlockingQueue<Path> queue, char k) {
		this.queue = queue;
		this.k = k;
	}

	@Override
	public void run() {

		try{
			boolean done = false;
			while(!done){

				Path p = queue.take();
				if(p == DUMMY){
					done = true;
					queue.put(p);
				} else{
					pojavljivanja(p.toString());
					if(postoji)
						System.out.println(Thread.currentThread().getId() + " : " + p + " : " + count);
				}
			}
		} catch (InterruptedException e) {
				e.printStackTrace();
		}

	}

	public void pojavljivanja(String p){
			//System.out.println(p);
			postoji = true;
			try(Scanner sc = new Scanner(new File(p))){
				count = 0;
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					for(int i = 0; i < line.length();i++)
						if(line.charAt(i) == this.k)
							count++;

				}
			}catch (FileNotFoundException e) {
				postoji = false;
			} catch(IOException e){

			}

	}



}

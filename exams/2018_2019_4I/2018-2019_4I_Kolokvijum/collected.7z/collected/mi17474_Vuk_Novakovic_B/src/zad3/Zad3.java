package zad3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;


public class Zad3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String filename = sc.nextLine();
		try {
			URL url = new URL("file:///" + Paths.get(filename).toAbsolutePath());
			Scanner file_scanner = new Scanner(url.openStream());
			while(file_scanner.hasNext()){
				String line = file_scanner.nextLine();
				if(line.endsWith(".txt")){
					/*
					 * XXX
					 * Deo za datume:
					 * int index1 = line.indexOf(':');

						Date date = new Date(line.substring(1, index1-1));
						Date today = new Date();

						//ako je isti mesec, gledamo da li je isti dan ili da li je juce stigao zahtev(uzimamo da je to u toku 24 h posto nemamo vreme)
						if(date.getMonth() == today.getMonth()
							&&
							(date.getDay() == today.getDay() || date.getDay() + 1 == today.getDay())
							||
							(date.getMonth() + 1 == today.getMonth() &&
							date.getDay() == 30 || date.getDay() == 31
							&& today.getDay() == 1)
						)
						trebalo bi ovako nesto, ali puca gresku
					 * XXX

					 * */


						//OVDE POCINJE KOD ZADATKA
					String[] tokens = line.split(":");//ako ovo ima vise od 4 elementa, onda je sigurno ipv6
					if(tokens.length == 4){
						System.out.print("v4:");
					}
					else
						System.out.print("v6:");
					//za protkol i putanju do fajla
					URL curr_url = new URL(tokens[tokens.length-2] + ":" + tokens[tokens.length-1]);
					System.out.print(curr_url.getProtocol() + ":");
					String file = curr_url.getFile();
					int index_of_slash = file.substring(1).indexOf('/') + 1;
					System.out.println(file.substring(index_of_slash));
				}

			}
			file_scanner.close();
		} catch (MalformedURLException e) {
			sc.close();

			e.printStackTrace();
		} catch (IOException e) {
			sc.close();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sc.close();
	}
}

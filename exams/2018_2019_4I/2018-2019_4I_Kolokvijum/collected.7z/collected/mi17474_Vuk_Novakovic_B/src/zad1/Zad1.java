package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * XXX
 * PAZNJA
 * PAZNJA PAZNJA
 * Menjano je ime projekta i folder u kom se nalazi.
 * testirano je sve nakon toga, no medjutim putanje znaju uvek da naprave probelm,
 * tako da ako nesto ne radi MOLIM VAS proverite prvo da nije do toga pa tek onda skidajte bodove :D
 *
 * XXX
 * */
public class Zad1 {
	public static void main(String[] args) {
		String in;
		String out = "emails.txt";
		Scanner sc = new Scanner(System.in);
		BufferedReader bfIn = null;
		BufferedWriter bfOut = null;
		in = sc.nextLine();

		Pattern email = Pattern.compile("([0-9A-Za-z]+([.][0-9A-Za-z]+)*@[0-9A-Za-z]+([.][0-9A-Za-z]+)*)[.!?,]*");
		Matcher m;
		try {
			 bfIn = new BufferedReader(new InputStreamReader(new FileInputStream(in), "UTF-8"));
			 bfOut = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), "UTF-8"));
			 String line;
			 while((line = bfIn.readLine()) != null){
				 String[] words = line.split(" ");
				 for(String w : words){
					 m=email.matcher(w);
					 if(m.matches()){
						 bfOut.write(m.group(1));
						 bfOut.newLine();
					 }

				 }
			 }
			 bfOut.flush();
			 bfOut.close();
			 bfIn.close();

		} catch (FileNotFoundException e) {
			sc.close();
			try {
				if(bfIn != null)
					bfIn.close();
				if(bfOut != null)
					bfOut.close();
			} catch (IOException e1) {
				System.err.println("Greska pri zatvaranju bafera... nekako...Java je cudna..");
				e1.printStackTrace();
			}

			System.err.println("Nije pronadjen fajl, prverite ime!");
			e.printStackTrace();
		} catch (IOException e) {
			sc.close();
			try {
				if(bfIn != null)
					bfIn.close();
				if(bfOut != null)
					bfOut.close();
			} catch (IOException e1) {
				System.err.println("Greska pri zatvaranju bafera... nekako...Java je cudna..");
				e1.printStackTrace();
			}

			System.err.println("IO greska!");
			e.printStackTrace();
		}
		sc.close();

	}
}

package zad2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileSearcher implements Runnable{

	private char k;
	private ArrayList<String> filenames;
	private int count;

	public FileSearcher(char k, ArrayList<String> filenames) {
		this.k = k;
		this.filenames = filenames;
		count = 0;
	}

	@Override
	public void run() {
		String current_file = null;
		while(!filenames.isEmpty()){
			synchronized (filenames) {
				current_file = filenames.get(0);
				filenames.remove(0);
			}
			try {
				Scanner sc = new Scanner(new FileInputStream(current_file));
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					for(int i=0;i<line.length();++i){
						if(line.charAt(i) == k){
							++count;
						}
					}
				}
				sc.close();
				System.out.println(Thread.currentThread().getId()+ ":" + current_file + ":" + count);
				count = 0;
			} catch (FileNotFoundException e) {
				System.err.println("Ne postoji fajl " + current_file);
			}

		}

	}

}

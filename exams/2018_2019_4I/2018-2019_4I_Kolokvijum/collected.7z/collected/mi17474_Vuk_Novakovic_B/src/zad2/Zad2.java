package zad2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Zad2 {
	public static void main(String[] args) {
		String input;
		System.out.println("Unesite putanju do fajla: ");
		Scanner sc = new Scanner(System.in);
		input = sc.nextLine();

		ArrayList<String> filenames = new ArrayList<>();
		Scanner file_scanner = null;
		try {
			file_scanner = new Scanner(new FileInputStream(input));
			while(file_scanner.hasNext()){
				String filename = file_scanner.nextLine();
				filenames.add(filename);
				System.out.println(filename);
			}

			file_scanner.close();

		} catch (FileNotFoundException e) {
			System.err.println("Lose ime fajla!");
			e.printStackTrace();
		}

		int n;
		char k;
		System.out.println("Unesite n i k: ");
		n = sc.nextInt();
		k = sc.next().charAt(0);
		for(int i = 0;i < n ; ++i){
			Thread t = new Thread(new FileSearcher(k, filenames));
			t.start();
		}

		sc.close();
	}
}

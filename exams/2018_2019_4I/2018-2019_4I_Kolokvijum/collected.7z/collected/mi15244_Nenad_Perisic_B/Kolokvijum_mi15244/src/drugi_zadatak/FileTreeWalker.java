package drugi_zadatak;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class FileTreeWalker implements Runnable {

	public static Path DUMMY = Paths.get("");
	private BlockingQueue<Path> queue;
//	private String c;
	private String c;

	public FileTreeWalker(BlockingQueue<Path> queue, String c) {
		this.queue = queue;
		this.c = c;
	}

	@Override
	public void run() {
		boolean done = false;

			try {
				Path p;
				while(true) {
					p = queue.take();
//					System.out.println(Thread.currentThread());
//					if (Files.isRegularFile(p)) {
//						int broj = search(p.toString());
//						System.out.println(Thread.currentThread().getId() + ":" + p.toString() + ":" + broj);
//					}

					int broj = search(p.toString());
					System.out.println(Thread.currentThread().getId() + ":" + p.toString() + ":" + broj);
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public int search(String p) throws IOException {
		Scanner sc = new Scanner(p);
		int brojac = 0;

		while(sc.hasNext()) {
			String line = sc.next();
			if (line.contains(this.c)) {
				brojac++;
			}
//			for (int i = 0; i < line.length(); i++) {
//				if (line.charAt(i) == this.c)
//					brojac++;
//			}
		}
		sc.close();

		return brojac;
	}


//	@Override
//	public void run() {
//		boolean done = false;
//
//			try {
//				while(!done) {
//					Path p = queue.take();
//					if (p == DUMMY) {
//						done = true;
//						this.queue.put(p); // vracamo nazad u red da bi ostale niti znale da treba da stanu
//					}
//					System.out.println(Thread.currentThread());
//					if (!Files.isRegularFile(p)) {
//						continue;
//					}
//
//					int broj = search(p);
//					System.out.println(Thread.currentThread().getId() + ":" + p.toString() + ":" + broj);
//
//				}
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//	}



}














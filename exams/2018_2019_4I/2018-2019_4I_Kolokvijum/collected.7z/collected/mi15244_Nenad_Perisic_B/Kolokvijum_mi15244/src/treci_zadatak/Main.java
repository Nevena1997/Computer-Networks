package treci_zadatak;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {

		URL url = new URL("file:///C:/Users/nalog/Desktop/mi15244_Nenad_Perisic_B/Kolokvijum_mi15244/log.txt");
		URLConnection uc = url.openConnection();
		InputStream in = uc.getInputStream();
		Scanner log = new Scanner(in);
		String protokol = url.getProtocol();

		while (log.hasNext()) {
//			ovo je da se ispise cela datoteka bez filtriranja
//			System.out.println(log.next());

			String row = log.nextLine();
			String day = row.substring(2,4);
			String month = row.substring(5,7);
			String year = row.substring(8,12);

			if (row.substring(row.length()-3, row.length()).equals("txt")) {
				System.out.println(row);
				int p = row.lastIndexOf(":");
				String niska = row.substring(14,p);
				String protocol = niska.substring(niska.lastIndexOf(":")+1, niska.length());
				String resource = row.substring(p+3);
				if (row.substring(14,row.lastIndexOf(":")).length() > 15) {
					System.out.println("ipv6 " + protocol + " " + resource);
				}
				else {
					System.out.println("ipv4 " + protocol + " " + resource);
				}
			}
		}

		log.close();
	}

}

package drugi_zadatak;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) throws InterruptedException {

		Scanner sc = new Scanner(System.in);
		String filename = sc.next();
		int n = sc.nextInt();
		String k = sc.next();
		sc.close();

		BlockingQueue<Path> queue = new ArrayBlockingQueue<>(1000);

		BufferedReader in = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));

			String line;
			while((line = in.readLine()) != null) {
				queue.put(Paths.get(line));
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
				try {
					if (in != null)
						in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}


//		for (Path p : queue)
//			System.out.println(p);

//		ovde pokrecemo n niti itd

		System.out.println();
		for (int i = 0; i < n; i++) {
			FileTreeWalker ftw = new FileTreeWalker(queue, k);
			Thread t = new Thread(ftw);
			t.start();
		}


	}

}

package treciZadatak;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;

import com.sun.org.apache.xerces.internal.util.URI.MalformedURIException;

public class Treci {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("unesite putanju do log fajla");
		Path path = Paths.get(sc.next());
		sc.close();

//		System.out.println(path.toAbsolutePath().toString() + ":");

		BufferedReader bufin = null;
		try {
			// ne znam putanje na windowsu
			URL url = new URL("file://localhost/" + path.toAbsolutePath().toString());

			bufin = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			while ((line = bufin.readLine()) != null) {
				if (line.contains(".txt")) {
//					System.out.println(line);
					int indexOfBracket = line.lastIndexOf("]");
					String dateS = line.substring(1, indexOfBracket);

					//------------------------------------------------
//					Date izLoga = new Date(Integer.parseInt(dateS.substring(0, 2)),
//							Integer.parseInt(dateS.substring(3, 5)), Integer.parseInt(dateS.substring(6)));
					Date izLoga =new Date(Integer.parseInt(dateS.substring(6)) - 1900, Integer.parseInt(dateS.substring(3, 5)) - 1,
							Integer.parseInt(dateS.substring(0, 2)));
//					Date datumKao = new Date(dateS + ".");
//					System.out.println(izLoga);

					/* razlog komentarisanja je sto mora rucno da se unese danasnji datum da bi radilo */
//					if (isValidDate(izLoga)) {
//						System.out.print("stiglo je u poslednja 24h -> ");
//					}
					//------------------------------------------------

					String tmp = line.substring(indexOfBracket + 2);
					int indexh = tmp.indexOf("h");
					String addrS = tmp.substring(0, indexh - 1);
					String urlS = tmp.substring(indexh);

//					System.out.print(dateS + " ");
//					System.out.print(addrS + " ");
//					System.out.println(urlS);

					InetAddress iaddr = InetAddress.getByName(addrS);
					URL url_current = new URL(urlS);
					System.out.print("v" + ipv4or6(iaddr) + ":");
					System.out.println(url_current.getProtocol() + ":" + url_current.getPath());
				}

			}

			System.out.println();
			System.out.println("---------------------------------");



		} catch (MalformedURIException urle) {
			urle.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (bufin != null)
					bufin.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static boolean isValidDate(Date izLoga) {
		// ne radi u svim slucajevima...

		// samo ako napisemo kao argument danasnji datum radi
		Date today = new Date(2018 - 1900, 11 - 1, 23); // godina - 1900, mesec - 1, i da mora da se unese
		int tday = today.getDay();
		int tyear = today.getYear();
		int tmonth = today.getMonth();

		int day = izLoga.getDay();
		int month = izLoga.getMonth();
		int year = izLoga.getYear();

//		System.out.println(izLoga);
//		System.out.println(today);

		if (tyear != year)
			return false;
		if (tmonth != month)
			return false;
		if (day == tday-1 || day == tday)
			return true;


		return false;
	}

	private static int ipv4or6(InetAddress iaddr) {
		byte[] addr = iaddr.getAddress();
		if (addr.length == 4) return 4;
		else if (addr.length == 16) return 6;
		else return -1;
	}

}

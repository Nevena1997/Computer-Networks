package prviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String inputFile = sc.next();
		sc.close();

		BufferedReader in = null;
		BufferedWriter out = null;

		try {
			in = new BufferedReader(new InputStreamReader(
					new FileInputStream(inputFile), StandardCharsets.UTF_8));
			out = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream("emails.txt"), StandardCharsets.UTF_8));

			String line;
			while ((line = in.readLine()) != null) {
//				System.out.println(line);
				String[] words = line.split("[ ,]");
				for (int i = 0; i < words.length; i++) {
//					System.out.println(words[i]);
					if (words[i].matches("[A-Za-z0-9]+@[a-z]+([.][a-z]+)+")) {
						out.write(words[i]);
						out.newLine();
					}
				}
			}

			out.flush();

		} catch (FileNotFoundException nf) {
			System.err.println("Fajl ne postoji...");
		} catch (IOException ioe) {
			System.err.println("greska pri IO operaciji");
		} finally {
			try {
				if (in != null)
					in.close();
				if (out != null)
					out.close();
			} catch (IOException e) {
				System.err.println("greska pri zatvaranju resursa");
			}
		}
	}

}

package drugiZadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ConcurrentLinkedQueue;


public class Search implements Runnable {

	private ConcurrentLinkedQueue<String> red;
	private char k;
	private int numOfk;

	public Search(ConcurrentLinkedQueue<String> red, char k) {
		this.red = red;
		this.k = k;
		this.numOfk = 0;
	}


	@Override
	public void run() {
		while (true) {
			synchronized (red) {
				if (red.isEmpty()) {
					System.out.println(Thread.currentThread() + " zavrsava sa radom...");
					return ;
				}

				String file = red.poll();

				InputStreamReader in = null;
				try {
					in = new InputStreamReader(new FileInputStream(file));

					this.numOfk = 0;
					int r;
					while ((r = in.read()) != -1)
						if (((char) r) == this.k) {
//							System.out.println((char) r);
							this.numOfk += 1;
						}

					System.out.println(Thread.currentThread().getId() + ":" + file + ":" + numOfk);

				} catch (FileNotFoundException fnf) {
					System.err.println("file " + file + " not found...");
				} catch (IOException e) {
					System.err.println("greska pri io u " + Thread.currentThread());
				} catch (NullPointerException nulle) {
					// nema akcije
					System.err.print("");
				} finally {
					try {
						if (in != null)
							in.close();
					} catch (IOException e1) {
						System.err.println("neuspelo zatvaranje resursa...");
					} catch (NullPointerException nulle) {
						// nema akcije
						System.err.print("");
					}
				}

			}

			try {
				// neka spavaju malo niti
				Thread.sleep((int) (Math.random() * 150));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

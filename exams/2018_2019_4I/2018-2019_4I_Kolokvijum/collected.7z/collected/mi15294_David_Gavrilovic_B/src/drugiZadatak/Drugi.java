package drugiZadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Drugi {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do ulaznog fajla");
		String inputFile = sc.next();

		ConcurrentLinkedQueue<String> red = new ConcurrentLinkedQueue<>();
		BufferedReader in = null;

		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile)));

			String path;
			while ((path = in.readLine()) != null) {
				Path ppath = Paths.get(path);
				red.add(ppath.toString());
			}

			System.out.println("----------------------------");
			for (String r : red)
				System.out.println(r);
			System.out.println("----------------------------");
		} catch (IOException e) {
			System.err.println("greska pri io");
			e.printStackTrace();
		} finally {
			try {
			if (in != null)
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println("Unesite broj niti i jedan karakter");
		int numOfThreads = sc.nextInt();
		char toFind = sc.next().charAt(0);
		System.out.println(toFind);

		sc.close();

		for (int i = 0; i < numOfThreads; i++) {
			Thread t = new Thread(new Search(red, toFind));
			t.start();
		}

	}

}

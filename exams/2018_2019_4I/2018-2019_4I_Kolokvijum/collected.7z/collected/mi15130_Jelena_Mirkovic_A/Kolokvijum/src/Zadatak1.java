import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Zadatak1 {

	public static void CitanjeDatuma(){
		BufferedReader in;
		BufferedWriter out;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream("bla.txt"), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

//			byte[] procitano = new byte[512];
			while(in.read() != -1){
				if(in.readLine().matches("(0?[1-9])|([12][0-9])|(3[01]))[-](0?[1-9])|(1[0-2])[-]2[0-9]{3}"))
					out.newLine();
			}

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void PrekoBafera(){
		BufferedReader in;
		BufferedWriter out;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream("bla.txt"), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

//			byte[] procitano = new byte[512];
			while(in.read() != -1){
				out.newLine();
			}

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void ObicnoCitanje(){
		try {
			FileOutputStream out = new FileOutputStream("timestamps.txt");
//			Scanner sc = new Scanner(System.in);
//			while(sc.hasNextInt()){
//				sc.nextInt();
//			}
			FileInputStream in = new FileInputStream("bla.txt");
			int b;
			while((b=in.read()) != -1)
				out.write(b);

//			sc.close();
			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] arg) {
		ObicnoCitanje();
		PrekoBafera();
		CitanjeDatuma();
	}

}

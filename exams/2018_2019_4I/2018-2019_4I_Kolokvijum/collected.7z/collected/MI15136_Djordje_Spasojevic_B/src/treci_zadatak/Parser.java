package treci_zadatak;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
//import java.util.Date;
import java.util.Scanner;

public class Parser {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		URL url;

		try {
			url = new URL(input);

			sc = new Scanner(new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8")));

			while (sc.hasNext()) {
				String red = sc.next();
				if (red.endsWith(".txt")) {
//					String datum = red.substring(1, red.lastIndexOf("]"));
					red = red.substring(red.lastIndexOf("]")+2);
					String sredniDeo = red.substring(0, red.lastIndexOf(":"));
					String url_ = sredniDeo.substring(sredniDeo.lastIndexOf(":")+1).concat(red.substring(red.lastIndexOf(":")));
					String ip = sredniDeo.substring(0, sredniDeo.lastIndexOf(":"));

					int verzija = ip.contains(":") ? 6 : 4;

					URL temp = new URL(url_);

					String path = temp.getPath();

//					Date danas = new Date();

//					String[] datumi = datum.split("[.]");

					//Hard Code
//					if (datumi[2] == "2018" && datumi[1] == "11" && (datumi[0] == "23" || datumi[0] == "24")) {
//						System.out.println("v"+verzija+":"+temp.getProtocol()+":"+path);
//					}//ni ovo ipak nije radilo

					System.out.println("v"+verzija+":"+temp.getProtocol()+":"+path);

				}
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}

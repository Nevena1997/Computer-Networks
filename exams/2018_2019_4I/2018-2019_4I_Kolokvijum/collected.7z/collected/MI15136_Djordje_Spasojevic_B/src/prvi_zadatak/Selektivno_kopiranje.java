package prvi_zadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Selektivno_kopiranje {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Scanner in = null;
		String input = sc.nextLine();
		BufferedWriter out = null;

		try {

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			String line = null;
			while(in.hasNext()) {
				line = in.nextLine();

				if (line.matches("[A-Za-z0-9]+@[a-zA-Z0-9]+.com")) {
					out.write(line);
					out.newLine();
				}
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sc.close();
			in.close();
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

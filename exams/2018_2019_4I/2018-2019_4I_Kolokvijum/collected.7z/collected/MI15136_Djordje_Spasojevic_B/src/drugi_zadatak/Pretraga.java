package drugi_zadatak;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
//import java.util.concurrent.SynchronousQueue;

public class Pretraga {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input = "putanje.txt";

		ArrayList<String> putanje = new ArrayList<String>();
		try {
			sc = new Scanner(new BufferedInputStream(new FileInputStream(input)));

			while (sc.hasNext()){
				String putanja = sc.nextLine();
				putanje.add(putanja);
				System.out.println(putanja);
			}
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} finally {
			sc.close();
		}

		sc = new Scanner(System.in);

		int n = sc.nextInt();
		String k = sc.next();

//		SynchronousQueue<String> putanjeSync = new SynchronousQueue<String>(true);


		for (int i = 0; i < n; i++) {
			new Thread(new Obrada(k, putanje)).start();;
		}

		sc.close();
	}

}

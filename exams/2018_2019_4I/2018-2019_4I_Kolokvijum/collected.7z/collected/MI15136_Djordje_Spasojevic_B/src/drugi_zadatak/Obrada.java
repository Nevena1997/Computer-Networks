package drugi_zadatak;

import java.util.ArrayList;

public class Obrada implements Runnable {

	ArrayList<String> putanje;
	String k;
	String putanja;

	public Obrada(String k, ArrayList<String> putanje) {
		this.putanje = putanje;
		this.k = k;
		System.out.println(this.putanje);
	}

	@Override
	public void run() {
		while(!this.putanje.isEmpty())
			this.putanja = this.putanje.remove(0);
			System.out.println(putanja + "\t\t" + Thread.currentThread());

			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}

}

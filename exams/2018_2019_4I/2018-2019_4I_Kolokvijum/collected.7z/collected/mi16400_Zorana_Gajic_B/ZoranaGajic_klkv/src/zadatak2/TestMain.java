package zadatak2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TestMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String filename = sc.next();

		BufferedReader in;
		BufferedWriter out;

		BlockingQueue<Path> fileQueue = new ArrayBlockingQueue<>(1000);

		int brojacFajlova = 0;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));

			String line;
			while((line = in.readLine())!= null) {
				System.out.println(line);
				brojacFajlova++;
				Path path = Paths.get(line);
				fileQueue.add(path);
			}

			in.close();

		} catch(IOException e) {
			e.printStackTrace();
		}

		System.out.println("Unesite broj niti i karakter k: ");
		int n = sc.nextInt();
		char k = sc.next().charAt(0);

		int brojFajlovaZaNit = Math.round(n/brojacFajlova);
		for(int i=0; i<n; i++) {
			(new Thread(new Nit(fileQueue, brojFajlovaZaNit, k))).start();
		}

		sc.close();

	}
}

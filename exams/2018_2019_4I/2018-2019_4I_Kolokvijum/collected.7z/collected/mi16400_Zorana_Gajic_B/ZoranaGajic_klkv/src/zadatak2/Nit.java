package zadatak2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class Nit implements Runnable{

	private static BlockingQueue<Path> queue;
	private static int n;
	private static char k;

	public Nit(BlockingQueue<Path> queue, int n, char k) {
		this.queue = queue;
		this.n = n;
		this.k = k;
	}

	@Override
	public void run() {
		try {
			for(int i=0; i<this.n; i++) {
				Path p = queue.take();
				int brojPojavljivanja = brojPojavljivanja(p, k);

				System.out.println("<"+Thread.currentThread() + ">:<" + p + ">:<"+brojPojavljivanja+">");
			}

		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static int brojPojavljivanja(Path path, char k) {
		int brojac = 0;
		InputStreamReader in;
		try {
			in = new InputStreamReader(new FileInputStream(path.toString()));

			int b;
			while((b=in.read())!=-1) {
				if((char)b == k)
					brojac++;
			}
			in.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return brojac;
	}
}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String filename = sc.next();

		sc.close();
		BufferedReader in;
		BufferedWriter out;

		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			String line;
			while((line = in.readLine())!= null) {
				//System.out.println(line);
				if(checkMail(line))
					out.write(line + '\n');
			}

			in.close();
			out.close();

		} catch (UnsupportedEncodingException e) {
			System.out.println("Greska sa UTF-8 encodingom!");
		} catch (FileNotFoundException e) {
			System.out.println("Trazeni fajl " + filename + " ne postoji!");
		} catch (IOException e) {
			System.out.println("IOException se dogodio!");
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		// in.close();
		// out.close();
		}
	}

	private static boolean checkMail(String line) {
		// ako se desi da vise mejlova(reci) odvojenih razmakom ima u jednoj liniji
		String[] reci = line.split(" ");

		String patternString = "[A-Za-z_0-9]+@[a-zA-Z0-9]+\\.[a-zA-Z0-9]+";
		//String patternString2 = "[A-Za-z_0-9]+@[gmail|bk|yahoo|mail|hotmail]+.[com|rs|ru]+";

		Pattern pattern = Pattern.compile(patternString);

		for(String rec: reci) {
			Matcher matcher = pattern.matcher(rec);
			if(matcher.find())
				return true;
		}

		return false;
	}

}

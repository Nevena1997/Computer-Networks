package zadatak3;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.sql.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String filename = sc.next();

		sc.close();

		try {
			URL url = new URL(filename);

			String content = readContentFromURL(url);
			System.out.println("Ispisan ceo sadrzaj fajla: \n" + content);

			String filteredContent = filterContent(content);
			System.out.println("Filtrirani sadrzaj (samo txt): \n" + filteredContent);

			String differentStyleOfOutput = transformOutput(filteredContent);
			System.out.println("Ispis: \n" + differentStyleOfOutput);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static String transformOutput(String content) {
		StringBuffer strBuf = new StringBuffer();
		String[] paths = content.split("\n");

		for(String path: paths) {
			strBuf.append('v');

			// pomocne promenljive
			String path1 = path.substring(path.indexOf(":")+1);
			String path2 = path1.substring(path1.indexOf(":")+1);

			try {

				URL url = new URL(path2);
				// trebalo bi da se napravi Path p da bi pozvali p.getAbsolutePath
				if(path2.contains("."))
					strBuf.append(4);
				else strBuf.append(6);

				strBuf.append(":");
				strBuf.append(url.getProtocol());
				strBuf.append(":");
				strBuf.append(url.getPath() + "\n");

			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

		}

		return strBuf.toString();
	}


	private static String filterContent(String content) {
		String[] paths = content.split("\n");
		StringBuffer strBuf = new StringBuffer();

		for(String path: paths) {
			String[] reci = path.split("\\.");
			String ekstenzija = reci[reci.length-1].trim();
			if(ekstenzija.equals("txt"))
				strBuf.append(path);
		}

		return strBuf.toString();
	}

	private static String readContentFromURL(URL url) throws IOException {
		URLConnection connection = url.openConnection();
		InputStreamReader in = new InputStreamReader(connection.getInputStream());

		StringBuffer strBuf = new StringBuffer();

		int b;
		while((b = in.read())!=-1) {
			strBuf.append((char)b);
		}

		in.close();

		return strBuf.toString();
	}

}

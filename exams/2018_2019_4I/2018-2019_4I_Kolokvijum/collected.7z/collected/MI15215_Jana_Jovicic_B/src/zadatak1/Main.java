package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String inFile = sc.next();
		BufferedReader in;
		BufferedWriter out;

		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(inFile), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			Scanner sc2 = new Scanner(in);
			while(sc2.hasNext()){

				String mail = sc2.next();
				boolean isMail = true;

				int lastDot = mail.lastIndexOf('.');
				int at = mail.indexOf('@');

				if(lastDot == -1 || at == -1)
					isMail = false;

				if(lastDot < at)
					isMail = false;

				if(isMail){
					out.write(mail);
					out.newLine();
					out.flush();
				}

			}

			sc2.close();
			in.close();
			out.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		sc.close();
	}

}

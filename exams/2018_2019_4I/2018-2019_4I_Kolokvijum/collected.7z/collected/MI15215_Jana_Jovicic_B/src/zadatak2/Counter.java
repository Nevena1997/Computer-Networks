package zadatak2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;

public class Counter implements Runnable {

	private ArrayList<Path> paths;
	private char k;

	public Counter(ArrayList<Path> paths, char k) {
		super();
		this.paths = paths;
		this.k = k;
	}


	@Override
	public void run() {
		this.search();
	}

	public synchronized void search(){

		while(true){
		if(!paths.isEmpty()){
			Path p = paths.get(0);

			try {
				InputStreamReader in = new InputStreamReader(new FileInputStream(p.toString()));
				Scanner sc = new Scanner(in);
				int count = 0;

				while(sc.hasNext()){
					//System.out.println(sc.next());

					String word = sc.next();
					int len = word.length();

					for(int i = 0; i < len; i++){
						if(word.charAt(i) == this.k)
							count++;
					}
				}

				System.out.println(Thread.currentThread() + " : " + p.toString() + " : " + count);

				sc.close();

			} catch (FileNotFoundException e) {

//				e.printStackTrace();
			}

			paths.remove(0);
		}
		}
	}

}

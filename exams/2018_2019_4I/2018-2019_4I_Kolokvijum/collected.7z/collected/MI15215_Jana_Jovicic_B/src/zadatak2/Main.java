package zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String file = sc.next();

		try {

			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			Scanner sc2 = new Scanner(in);

			ArrayList<Path> paths = new ArrayList<Path>(100);


			while(sc2.hasNext()){
				Path p = Paths.get(sc2.next());
				paths.add(p);
			}

			for(Path p : paths){
				System.out.println(p);
			}


			System.out.println("Uneti n i k:");
			int n = sc.nextInt();
			char k = sc.next().charAt(0);

			for(int i = 0; i < n; i ++){
				Counter c = new Counter(paths, k);
				Thread t = new Thread(c);
				t.start();
			}

			sc2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}



		sc.close();
	}

}

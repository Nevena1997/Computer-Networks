package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class SelektivnoKopiranje
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Scanner ir = null;
		BufferedWriter bw = null;

		System.out.println("Unesite ime fajla:");
		String fileName = sc.next();
		sc.close();

		try {
			ir = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName),"UTF-8")));
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			while(ir.hasNext()) {
				String in = ir.next();
				if(in.matches("[a-z]+[a-zA-Z0-9]*@[a-z]+[.][a-z]+")) {
					bw.write(in + System.getProperty("line_separator", "\r\n"));
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println("File not found.\n");
		} catch (UnsupportedEncodingException e) {
			System.err.println("Unsupported encoding.\n");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException.\n");
			e.printStackTrace();
		} catch (Exception e) {
			System.err.println("Other exception.\n");
			e.printStackTrace();
		} finally {
			ir.close();
			try {
				bw.close();
			} catch (IOException e) {
				System.err.println("Error while closing the buffered writer.");
			}
		}
	}
}

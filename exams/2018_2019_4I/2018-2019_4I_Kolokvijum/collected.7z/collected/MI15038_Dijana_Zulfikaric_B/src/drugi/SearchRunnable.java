package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class SearchRunnable implements Runnable
{
	private List<String> files;
	private char k;

	public SearchRunnable(List<String> files, String k)
	{
		this.files = files;
		this.k = k.charAt(0);
	}

	@Override
	public void run()
	{
		while(!files.isEmpty()) {
			String filePath;

			synchronized (files) {
				filePath = files.remove(0);
				files.notifyAll();
			}

			Scanner sc = null;

			try {
				sc = new Scanner(new FileInputStream(filePath));
				int brPojavljivanja = 0;

				while(sc.hasNext()) {
					char[] linija = sc.nextLine().toCharArray();
					for(int i = 0; i < linija.length; ++i) {
						if(linija[i] == this.k) {
							brPojavljivanja++;
						}
					}
				}

				System.out.println(Thread.currentThread().getId() + ":" + filePath + ":" + brPojavljivanja);

				synchronized (files) {
					files.notifyAll();
				}

				Thread.yield();
			} catch (FileNotFoundException e) {
				System.err.println("File: " + filePath + "not found.\n");
				e.printStackTrace();
			}  finally {
				sc.close();
			}
		}
	}
}

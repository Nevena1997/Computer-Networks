package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class SearchFiles {
	private List<String> files = Collections.synchronizedList(new LinkedList<String>());
	private int threadNo;
	private String k;

	public SearchFiles(List<String> files, int threadNo, String k)
	{
		this.files = files;
		this.threadNo = threadNo;
		this.k = k;
	}

	public void read(String fileName)
	{
		Scanner sc = null;

		try {
			sc = new Scanner(new FileInputStream(fileName));
			while(sc.hasNext()) {
				String filePath = sc.nextLine();
				System.out.println(filePath);
				files.add(filePath);
			}

			for(int i = 0; i < this.threadNo; ++i) {
				new Thread(new SearchRunnable(files, k)).start();
			}
		} catch (FileNotFoundException e) {
			System.err.println("File not found.\n");
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}

package drugi;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class SearchTest
{
	public static void main(String[] args)
	{
		Scanner sc = null;

		try {
			sc = new Scanner(System.in);
			System.out.println("Unesite ime fajla:");
			String fileName = sc.nextLine();
			System.out.println("Unesite broj tredova:");
			int threadNo = sc.nextInt();
			System.out.println("Unesite karakter k:");
			String k = sc.next();
			List<String> files = new LinkedList<String>();

			SearchFiles sf = new SearchFiles(files, threadNo, k);
			sf.read(fileName);

		} catch (Exception e) {
			System.err.println("Exception.\n");
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}

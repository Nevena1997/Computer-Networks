package treci;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class LogParser
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla:");
		String filePath = sc.nextLine();
		sc.close();

		Scanner reader = null;

		try {
			URL url = new URL(Paths.get(filePath).toUri().toString());
			reader = new Scanner(url.openStream());
			List<String> lines = new LinkedList<String>();
			System.out.println("Sadrzaj log fajla:");

			while(reader.hasNext()) {
				String line = reader.nextLine();
				lines.add(line);
				System.out.println(line);
			}

			System.out.println("\n\nURL putanje koje sadrze putanju do tekstualnog fajla:");
			List<String> linesTXT = new LinkedList<>();

			for(String line: lines) {
				if(!line.substring(line.lastIndexOf('.') + 1, line.length()).equalsIgnoreCase("txt")) {
					continue;
				}
				System.out.println(line);
				linesTXT.add(line);
			}

			System.out.println("\n\nZahtevi koji su stigli samo u poslednjih 24h:");
			for(String line: linesTXT) {
				String datum = line.substring(1, line.indexOf(']'));
//				System.out.println(datum);
				Date now = new Date();
//
//				Iz nekog razloga datum nije zeleo da se formira. (menjala sam redosled dana i meseca,
//				dodavala tacku na kraj, stavljala umesto tacke '-', svaki put je izbacivalo istu gresku,
//				druga opcija bi bila da se datum hardkodira tj da se formira dan, mesec i godina od podataka
//				u stringu datum, pa da se od toga formira sam datum)
//				Rekli ste mi da taj deo koda zakomentarisem i da napisem sta bih dalje uradila.
//				Dakle, datum bi se formirao kao u liniji ispod
//				Date date = new Date(datum);
//				System.out.println("Date given: " + date);
//
//				i zatim bi se u if-u ispod od danasnjeg datuma uzeo sa now.getTime() i date.getTime()
//				broj milisekundi u tim datumima i to bih oduzela da bih poredila sa brojem milisekundi u 24h.
//				Naravno, prethodno bih izracunala bih koliko 24h ima milisekundi.
//				long mils = 24*60*60*100000;
//				if(now.getTime() - date.getTime() <= mils) {
//				i ostatak koda bi bio u ovom if bloku :)
//
				String bezDatuma = line.substring(line.indexOf(datum) + datum.length() + 2, line.length());
				String[] splited = bezDatuma.split(":");
				String u = splited[splited.length - 2] + ":" + splited[splited.length - 1];
				char[] ip = bezDatuma.substring(0, bezDatuma.indexOf(u)-1).toCharArray();
				String verzija = "";
				for(int i = 0; i < ip.length; ++i) {
					if(ip[i] == ':') {
						verzija = "v6";
						break;
					} else if(Character.isDigit(ip[i]) || ip[i] == '.') {
						verzija = "v4";
						continue;
					} else {
						System.err.println("Not an IP address!");
						return;
					}
				}

				URL url1 = new URL(u);
				System.out.println(verzija + ":" + url1.getProtocol() + ":" + url1.getFile());
			}
		} catch (FileNotFoundException e) {
			System.err.println("File: " + filePath + " is not found.\n");
			e.printStackTrace();
		} catch (MalformedURLException e) {
			System.err.println("Malformed URL.\n");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException.\n");
			e.printStackTrace();
		} finally {
			reader.close();
		}
	}
}

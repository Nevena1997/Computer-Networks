package prviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String output_path = "timestamps.txt";
		Scanner sc = new Scanner(System.in);
		String input_path = sc.next();
		sc.close();
		Scanner in = null;
		BufferedWriter out = null;
		try {

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input_path), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output_path),"UTF-8"));
			while(in.hasNext()){
				String tmp = in.next();
				if(tmp.trim().matches("((0[1-9])|([1-2][0-9])|(3[0-1]))-((0[1-9])|(1[0-2]))-2[0-9]{3}")){
					out.write(tmp+'\n');
				}

			}
			out.flush();
		} catch (UnsupportedEncodingException e) {
			System.err.println("UnsupportedEncoding!");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.err.println("File not found!");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO error!");
			e.printStackTrace();
		}
		finally {
			in.close();
			try {
				out.close();
			} catch (IOException e) {
				System.err.println("IO error!");
				e.printStackTrace();
			}
		}

	}

}

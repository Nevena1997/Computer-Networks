package treciZadatak;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String logFile = sc.next();
		sc.close();
		Scanner in = null;
		try {
			URL url = new URL("FILE", "localhost", logFile);
			in = new Scanner(url.openStream());
			while(in.hasNextLine()){
				String line = in.nextLine();
				int version = 4;
				String v = line.substring(line.indexOf(':')+1,line.length());
				//System.out.println(v);
				if(v.indexOf(':') < 3){
					version = 6;
				}
				int lastIndex = line.lastIndexOf(':');
				String protocol = line.substring(0,lastIndex);
				lastIndex = protocol.lastIndexOf(':');
				protocol = protocol.substring(lastIndex+1,protocol.length());
				if(protocol.equals("ftp") || protocol.equals("sftp")){
					String protocolPath = line.substring(line.indexOf(protocol),line.length());
					URL u = new URL(protocolPath);
					System.out.println("v" + version + ":" + u.getProtocol() + ":" + u.getPath());

				}
			}
		} catch (MalformedURLException e) {
			System.err.println("Bad URL!");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO problem!");
			e.printStackTrace();
		}
		finally {
			in.close();
		}

	}

}

package drugiZadatak;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input_path = sc.next();
		List<String> paths = new ArrayList<String>();
		Scanner in = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input_path), "UTF-8")));
			while(in.hasNextLine()){
				paths.add(in.nextLine().trim());
			}
			for(String path : paths)
				System.out.println(path);
			int n = sc.nextInt();
			String goal = sc.next();
			int step = (int) Math.ceil(paths.size() / n) + 1;
			// Give sublist to every thread
			// Probability is almost same for every thread, except maybe last
			// But last has also it owns paths
			for(int i = 0; i < n; i++){
				List<String> tmp = new ArrayList<>();
				for(int j = i*step; j < Math.min((i+1)*step, paths.size()); j++)
					tmp.add(paths.get(j));
				Finder f = new Finder(tmp,goal);
				Thread t = new Thread(f);
				t.start();
			}




		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			sc.close();
			in.close();
		}






	}

}

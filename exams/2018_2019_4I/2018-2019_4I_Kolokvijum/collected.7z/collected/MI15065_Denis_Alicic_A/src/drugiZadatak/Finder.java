package drugiZadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Scanner;

public class Finder implements Runnable {
	private List<String> paths;
	private String key;

	public Finder(List<String> l, String key){
		this.paths = l;
		this.key = key;
	}



	@Override
	public void run() {
		for(String path : paths){
			try {
				Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8")));
				int counter = 0;
				//I count from and you too, I guess 0 :)
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					for(String word : line.split(" ")){
						if(word.equals(key))
							System.out.println("" + Thread.currentThread().getId() + ":" + path + ":" + counter );
					}
					counter++;
				}
				sc.close();

			} catch (UnsupportedEncodingException e) {
				System.err.println("UnsupportedEncoding!");
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				System.err.println("File not found!");
				continue;
			}
		}

	}

}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		BufferedReader br = null;
		BufferedWriter bw = null;
		try{
			if(args.length != 1){
				System.out.println("We need an argument and don't know what exception to throw so exit");
				System.exit(1);
			}
			String input_file = args[0];
			Scanner sc = new Scanner(System.in);
			String output_file = sc.next();

			br = new BufferedReader(new InputStreamReader(new FileInputStream(input_file), "UTF-8"));
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output_file), "UTF-8"));

			StringBuffer sb = new StringBuffer();
			char[] buf = new char[512];
			int bytesRead = 0;
			while((bytesRead = br.read(buf)) != -1) {
				sb.append(buf, 0, bytesRead);
			}
			String[] words = sb.toString().split("([ ]|[\n])");
			for(String word: words) {
				word = word.trim();
				if (word.matches("[a-z0-9A-Z]+@[a-zA-Z0-9]+[.][a-zA-Z]+")) {
					bw.write(word + "\n", 0, word.length() + 1);
					bw.flush();
				}
			}
			br.close();
			bw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("IO exception");
		} catch (Exception e) {
			System.out.println("Unknown Exception");
		}
		finally{
			try{
				if(br == null){
					br.close();
				}
				if(bw == null){
					bw.close();
				}
			} catch (IOException e){
				System.out.println("IO Exception");
				e.printStackTrace();
			}
		}
	}
}

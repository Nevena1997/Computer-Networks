package zad3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Paths;
import java.time.LocalDate;


public class Main {
	public static void main(String[] args) {
		BufferedReader br = null;
		try{
			if(args.length != 1){
				System.out.println("We need an argument and don't know what exception to throw so exit");
				System.exit(1);
			}
			String input_file = args[0];

			URL url = new URL(Paths.get(input_file).toUri().toString());
			br = new BufferedReader(new InputStreamReader(url.openStream()));
			StringBuffer sb = new StringBuffer();
			char[] buf = new char[512];
			int bytesRead = 0;
			while((bytesRead = br.read(buf)) != -1) {
				sb.append(buf, 0, bytesRead);
			}
			br.close();
			String logs = sb.toString();
			System.out.println(logs);

			String[] split_logs = logs.split("\n");

			for (String log: split_logs){
				log = log.trim();
				String ext = log.substring(log.length() - 4, log.length());
				if(ext.equals(".txt")){
					System.out.println(log);
				}
			}

			for (String log: split_logs){
				log = log.trim();
				String date = log.substring(1, 11);
				String tmp = log.substring(13);
				int k = tmp.lastIndexOf(':');
				int k2 = tmp.substring(0, k).lastIndexOf(':');

				String ip = tmp.substring(0, k2);
				String name = tmp.substring(k2 + 1);

				URL u = new URL(name);
				String protocol = u.getProtocol().toLowerCase().toString();
				int v = 4;
				for(int i = 0; i < ip.length(); i++){
					if(!Character.isDigit(ip.charAt(i)) && ip.charAt(i) != '.'){
						v = 6;
						break;
					}
				}
				String path = u.getPath();
				URLConnection uc = u.openConnection();

				// LocalDate.now(); something like this

				System.out.println("v" + v + ":" + protocol + ":" + path);
			}


		} catch (IOException e) {
			System.out.println("IO Exception");
			e.printStackTrace();
		}
		catch (Exception e){
			System.out.println("Unknown Exception");
			e.printStackTrace();
		}
		finally {
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

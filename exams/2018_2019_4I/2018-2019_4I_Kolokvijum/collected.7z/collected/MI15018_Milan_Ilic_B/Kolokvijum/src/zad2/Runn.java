package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class Runn implements Runnable{
	static LinkedList<String> list = null;
	char c;

	public Runn(LinkedList<String> l, char c){
		this.c = c;
		this.list = l;
	}

	public synchronized String get_element() {
		return list.poll();
	}

	@Override
	public void run() {
		BufferedReader br = null;
		try{
			while(true){
				String file = this.get_element();
				if(file == null){
					break;
				}
				else{
					br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
					StringBuffer sb = new StringBuffer();
					char[] buf = new char[512];
					int bytesRead = 0;
					while((bytesRead = br.read(buf)) != -1) {
						sb.append(buf, 0, bytesRead);
					}
					br.close();
					int count = 0;
					for(int i = 0; i < sb.length(); i++){
						if (sb.charAt(i) == this.c){
							count++;
						}
					}
					Thread.currentThread().sleep(100);
					System.out.println(Thread.currentThread().getId() + ":" + file + ":" + count);
				}
			}
		} catch(IOException e){
			System.out.println("IO Exception");
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.out.println("Sleep doesn't work");
			e.printStackTrace();
		}
		finally {
			try {
				if (br != null){
					br.close();
				}
			} catch (IOException e) {
				System.out.println("IO exception");
				e.printStackTrace();
			}
		}
	}
}

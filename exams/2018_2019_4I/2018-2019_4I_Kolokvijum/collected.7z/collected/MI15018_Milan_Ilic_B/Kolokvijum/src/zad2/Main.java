package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		BufferedReader br = null;
		try{
			if(args.length != 1){
				System.out.println("We need an argument and don't know what exception to throw so exit");
				System.exit(1);
			}
			String input_file = args[0];
			br = new BufferedReader(new InputStreamReader(new FileInputStream(input_file), "UTF-8"));
			StringBuffer sb = new StringBuffer();
			char[] buf = new char[512];
			int bytesRead = 0;
			while((bytesRead = br.read(buf)) != -1) {
				sb.append(buf, 0, bytesRead);
			}
			br.close();

			String[] files = sb.toString().split("\n");

			Scanner sc = new Scanner(System.in);

			int n = sc.nextInt();
			char k = sc.next().charAt(0);

			LinkedList<String> list = new LinkedList<String>();

			for (String file: files) {
				file = file.trim();
				list.add(file);
			}
			for(int i = 0; i < n; i++){
				Runn r = new Runn(list, k);
				Thread t = new Thread(r);
				t.start();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IO Exception");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Unknown exception");
			e.printStackTrace();
		}
		finally{
			if(br == null){
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("IO Exception");
					e.printStackTrace();
				}
			}
		}
	}
}

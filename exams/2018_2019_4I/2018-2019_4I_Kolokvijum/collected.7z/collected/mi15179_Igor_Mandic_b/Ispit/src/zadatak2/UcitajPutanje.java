package zadatak2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class UcitajPutanje implements Runnable{
	private BufferedReader in;
	private BlockingQueue<Path> redPutanja;

	public UcitajPutanje(BufferedReader in, BlockingQueue<Path> redPutanja) {
		this.in = in;
		this.redPutanja = redPutanja;
	}

	@Override
	public void run() {
		try {
			izlistajPutanje(in);
			redPutanja.put(Paths.get(""));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void izlistajPutanje(BufferedReader in) throws InterruptedException {
		String linija;
		try {
			while((linija = in.readLine()) != null){
				System.out.println(linija);
				redPutanja.put(Paths.get(linija));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}




}



package zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) {
		System.out.println("Unesite putanju");
		Scanner sc = new Scanner(System.in);
		String putanja = sc.next();

		System.out.println("Unesite karakter");
		char k = sc.next().charAt(0);
		System.out.println("Unesite broj niti");
		int n = sc.nextInt();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)));
			BlockingQueue<Path> redPutanja = new ArrayBlockingQueue<>(10);
			UcitajPutanje up = new UcitajPutanje(in, redPutanja);
			Thread t1 = new Thread(up);
			t1.start();

			for(int i = 0; i<n; i++){
				PrebrojKaraktere pk = new PrebrojKaraktere(redPutanja, k);
				Thread t2 = new Thread(pk);
				t2.start();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sc.close();
	}

}

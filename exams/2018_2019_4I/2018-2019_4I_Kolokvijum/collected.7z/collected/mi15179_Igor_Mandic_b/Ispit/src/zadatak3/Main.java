package zadatak3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;
@SuppressWarnings("deprecation")
public class Main {

	public static void main(String[] args) {
		//pravljenje stringa za url
		System.out.println("Unesite ime fajla ili putanju");
		Scanner sc = new Scanner(System.in);
		String ime = sc.next();
		Path p = Paths.get(ime);
		String putanja = "file:///" + p;


		try {
			//pravljenje url, uzimanje protokola, otvaranje url-a
			URL url = new URL(putanja);
			String protokol = url.getProtocol();
			if(!(protokol.equals("file"))){
				System.out.println("Pogresno uneta adresa");
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
			boolean indEkst = false;
			boolean vreme = false;
			String linija;

			//citanje linije po linije
			while((linija = in.readLine())!=null){

				//provera za ekstenziju
				int indeksPoslednjeTacke = linija.lastIndexOf('.');
				String ekstenzija = linija.substring(indeksPoslednjeTacke + 1);
				if(ekstenzija.equals("txt")){
					indEkst = true;
				}

				//provera za datum
				int indeksZagrada = linija.lastIndexOf(']');
				String datum = linija.substring(1, indeksZagrada);
				String[] nizDatum = datum.split(".");
				int dan = Integer.parseInt(nizDatum[0]);
				int mesec = Integer.parseInt(nizDatum[1]);
				int godina = Integer.parseInt(nizDatum[2]);

				Date datumVreme = new Date(dan, mesec, godina);
				Date danasnji = new Date();
				int sekunde1 = datumVreme.getSeconds();
				int sekunde2 = danasnji.getSeconds();
				if(sekunde2 - sekunde1 < 24*60*60){
					vreme = true;
				}


				//ispis verzije, protokola i naziva
				if(indEkst && vreme){
					int indeks = linija.indexOf(':');
					String ip = linija.substring(indeks + 1, indeks + 10);
					int verzija;
					int indeksTacka = ip.indexOf('.');
					if(indeksTacka != -1)
						verzija = 4;
					else
						verzija = 6;

					int indeksPoslednjeDveTacke = linija.lastIndexOf(':');
					int indeksPretpslednje = linija.lastIndexOf(':', 2);
					String protokol1 = linija.substring(indeksPretpslednje + 1, indeksPoslednjeDveTacke);
					int indeksKoseCrte = linija.lastIndexOf('/');
					String fajl = linija.substring(indeksKoseCrte + 1);
					System.out.println("v" + verzija + ":" + protokol1 + " " + fajl);
				}
			}

			sc.close();
			in.close();




		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}

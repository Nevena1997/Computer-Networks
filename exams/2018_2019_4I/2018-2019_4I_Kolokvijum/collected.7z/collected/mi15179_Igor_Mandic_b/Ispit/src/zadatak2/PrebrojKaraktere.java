package zadatak2;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class PrebrojKaraktere implements Runnable{

	private BlockingQueue<Path> redPutanja;
	private char c;

	public PrebrojKaraktere(BlockingQueue<Path> redPutanja, char c) {
		this.redPutanja = redPutanja;
		this.c = c;
	}

	@Override
	public void run() {
		boolean ind = false;
		while(!(ind)){
			Path p;
			try {
				p = redPutanja.take();
				if(p == Paths.get("")){
					ind = true;
					redPutanja.put(Paths.get(""));
				}
				else{
					int brojPojavljivanja = prebroj(p);
					System.out.println(Thread.currentThread() + " " + p.toString() + " " +  brojPojavljivanja);
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	private int prebroj(Path p) {
		int brojac = 0;
		try {
			FileInputStream in = new FileInputStream(p.toString());
			int b;
			while((b = in.read()) != -1){
				if((char)b == c){
					brojac++;
				}
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Nije moguce uci u fajl");
		}
		return brojac;

	}

}

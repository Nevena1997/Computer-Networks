package drugi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String ulaz = sc.next();

		FileInputStream fi = null;
		FileOutputStream fo = null;

		BufferedReader br = null;
		BufferedWriter bw = null;

		InputStreamReader ir = null;
		OutputStreamWriter ow = null;

		try {
			fi = new FileInputStream(ulaz);
			fo = new FileOutputStream("emails.txt");

			ir = new InputStreamReader(fi, "UTF-8");
			ow = new OutputStreamWriter(fo, "UTF-8");

			br = new BufferedReader(ir);
			bw = new BufferedWriter(ow);

			String s = null;
			String trazenaRec = null;
			int n, k = 0;
			while((s= br.readLine()) != null){
				Path p = Paths.get(s).toAbsolutePath();
				trazenaRec = sc.next();
				n = sc.nextInt();
				k = sc.nextInt();

				Thread t = new Thread(runnable(p, trazenaRec, k));

				for (int i = 0; i < n; i++){
					t.start();
				}

				System.out.println(p);
			}

			bw.flush();
			sc.close();
			fi.close();
			fo.close();
			ir.close();
			ow.close();
			br.close();
			bw.close();
		} catch (FileNotFoundException e) {
			sc.close();
			try {
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Greska pri zatvaranju streamova");
				System.exit(1);
			}
			System.out.println("Nema fajla");
			System.exit(1);
		} catch (UnsupportedEncodingException e) {
			try {
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Greska pri zatvaranju streamova");
				System.exit(1);
			}	System.out.println("Nevazeci encoding");
			System.exit(1);
		} catch (IOException e) {
			try {
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Greska pri zatvaranju streamova");
				System.exit(1);
			}
			System.out.println("I/O greska");
			System.exit(1);
		}

	}

	private static Runnable runnable(Path p, String trazenaRec, int k) {
		try {
			URL u = new URL(p.toString());
			u.openStream();
			String[] niz;
			String s;
			while( (s = x.read()) != null){
				niz = s.split(" ");
				for(String i : niz){
					if(i == trazenaRec){
						k++;
					}
				}
			}

		} catch (IOException e) {
			System.out.println("Nevazeci I/O");
			System.exit(1);
		}

		return null;
	}

}

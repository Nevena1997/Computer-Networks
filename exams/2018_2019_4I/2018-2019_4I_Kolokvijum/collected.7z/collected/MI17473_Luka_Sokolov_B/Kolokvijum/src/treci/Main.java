package treci;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String filePath = sc.next();

		Path p = Paths.get(filePath).toAbsolutePath();
		try {
			URL u = new URL("file:///" + p);

			String s;
			String niz[];
			u.openStream();
			while(sc.hasNext()){
				s = sc.nextLine();
				niz = s.split(":");
				if(niz.length == 4){
					System.out.print("v4:");
					if(niz[niz.length-2] == "https"){
						System.out.println("https:");
					} else if(niz[niz.length-2] == "http"){
						System.out.println("http:");
					}

					String tmp = niz[niz.length].substring(niz[niz.length].indexOf(niz[niz.length].lastIndexOf("/")));
					System.out.println(tmp);
				} else {
					System.out.println("v6:");
					if(niz[niz.length-2] == "https"){
						System.out.println("https:");
					} else if(niz[niz.length-2] == "http"){
						System.out.println("http:");
					}


					String tmp = niz[niz.length].substring(niz[niz.length].indexOf(niz[niz.length].lastIndexOf("/")));
					System.out.println(tmp);
				}

			}

			sc.close();
		} catch (MalformedURLException e) {
			sc.close();
			System.out.println("Pogresan put");
			System.exit(1);
		} catch (IOException e) {
			System.out.println("Neuspelo otvaranje streama");
			System.exit(1);
		}



	}
}

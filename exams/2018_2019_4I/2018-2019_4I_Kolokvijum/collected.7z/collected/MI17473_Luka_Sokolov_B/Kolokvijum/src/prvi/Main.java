package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = null;
		sc = new Scanner(System.in);
		String ulaz = sc.next();


		FileInputStream fi = null;
		FileOutputStream fo = null;

		BufferedReader br = null;
		BufferedWriter bw = null;

		InputStreamReader ir = null;
		OutputStreamWriter ow = null;

		try {
			fi = new FileInputStream(ulaz);
			fo = new FileOutputStream("emails.txt");

			ir = new InputStreamReader(fi, "UTF-8");
			ow = new OutputStreamWriter(fo, "UTF-8");

			br = new BufferedReader(ir);
			bw = new BufferedWriter(ow);

			String s = null;
			String niz[] = null;
			while((s = br.readLine()) != null){
				niz = s.split(" ");
				for (String i : niz){
					if(i.matches("([A-Z]*[a-z]+[0-9]*)@[a-z]+.[a-z]+")){
						bw.write(i);
						bw.newLine();
					}
				}
			}
			bw.flush();
			sc.close();
			fi.close();
			fo.close();
			ir.close();
			ow.close();
			br.close();
			bw.close();
		} catch (FileNotFoundException e) {
			try {
				sc.close();
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Tokovi nisu validno zatvoreni");
				System.exit(1);
			}
			System.out.println("Nepostojeci fajl");
			System.exit(1);
		} catch (UnsupportedEncodingException e) {
			try {
				sc.close();
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Tokovi nisu validno zatvoreni");
				System.exit(1);
			}
			System.out.println("Format nije korektan");
			System.exit(1);
		} catch (IOException e) {
			try {
				sc.close();
				fi.close();
				fo.close();
				ir.close();
				ow.close();
				br.close();
				bw.close();
			} catch (IOException e1) {
				System.out.println("Tokovi nisu validno zatvoreni");
				System.exit(1);
			}
			System.out.println("I/O greska");
			System.exit(1);
		}



	}
}

package Zadatak02;

import java.util.List;

public class FileRunnable implements Runnable {

	private char c;
	private List<String> list;
	private FilesFindChar fc;

	public FileRunnable(List<String> list, char c, FilesFindChar fc) {
		this.c = c;
		this.list = list;
		this.fc = fc;
	}

	@Override
	public void run() {

		String path = fc.popList();
		while(path != null) {
			System.out.println(Thread.currentThread().getId() + ":" + path + ":" + this.fc.numChar(path, c));
			path = fc.popList();
		}
	}



}

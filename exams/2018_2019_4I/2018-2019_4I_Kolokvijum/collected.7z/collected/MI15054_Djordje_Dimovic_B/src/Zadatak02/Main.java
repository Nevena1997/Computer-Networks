package Zadatak02;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do fajla:");
		String inputFile = sc.next();
		System.out.println("Unesite broj niti");
		int n = sc.nextInt();
		System.out.println("Unesite karakter");
		char c = sc.next().trim().charAt(0);
		sc.close();

		FilesFindChar fc = new FilesFindChar(inputFile, n);
		fc.printNumberOfCharacter(c);
	}

}

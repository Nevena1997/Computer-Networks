package Zadatak02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FilesFindChar {

	private String inputFile;
	private int numThreads;
	private List<String> paths;

	public FilesFindChar(String inputFile, int numberThreads) {
		this.inputFile = inputFile;
		this.numThreads = numberThreads;
		this.paths = new ArrayList<String>();
	}

	public int printNumberOfCharacter(char c) {

		Scanner in = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(inputFile))));

			String filePath;

			while(in.hasNextLine()) {
				filePath = in.nextLine().trim();
				System.out.println(filePath);
				paths.add(filePath);

				// System.out.println(Thread.currentThread().getId() + ":" + filePath + ":" + numChar(filePath, c));
			}

			for(int i = 0; i < numThreads; i++)
				new Thread(new FileRunnable(paths, c, this)).start();



		}
		catch (FileNotFoundException e) {
			System.out.println("File " + inputFile + " doesn't exist.");
		}
		finally {
			if(in != null)
				in.close();
		}

		return -1;
	}

	public int numChar(String path, char c) {

		int ret = 0;

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));

			int readed = 0;

			while((readed = br.read()) != -1)
				if((char)readed == c)
					ret++;

		} catch (FileNotFoundException e) {
			System.err.println("File " + path + " doesn't exist.");
			return -1;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return ret;
	}

	synchronized public String popList() {
		if(this.paths.isEmpty())
			return null;
		String first = this.paths.get(0);
		this.paths.remove(0);
		return first;
	}

}

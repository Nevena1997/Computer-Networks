package Zadatak01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	private static final String outputFile = "emails.txt";

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String inputFile = sc.next();
		sc.close();

		Scanner br = null;
		BufferedWriter bw = null;
		try {
			br = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), "UTF-8")));
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile), "UTF-8"));

			char[] buf = new char[256];
			int readed = 0;

			String word;

			while(br.hasNext()) {
				word = br.next();
				System.out.println(word);
				if(valid(word)) {
					bw.write(word);
					bw.newLine();
				}
			}

		}
		catch (UnsupportedEncodingException e) {
			System.err.println("Unsupported encoding");
		}
		catch (FileNotFoundException e) {
			System.err.println("File " + outputFile + " or " + inputFile + " don't exist.");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {

			if(br != null) {
				br.close();
			}

			if(bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	static boolean valid(String word) {
		return word.matches("[A-Za-z0-9]+@[A-Za-z0-9]+\\.[A-Za-z]+");
	}

}

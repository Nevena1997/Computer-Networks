package Zadatak03;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String filePath = sc.next();

		sc.close();

		try {
			URL url = new URL(filePath);

			Scanner in = new Scanner(new InputStreamReader(url.openStream()));

			String line;

			while(in.hasNextLine()) {

				line = in.nextLine();
				if(txt(line))
					printLine(line);
			}

			in.close();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static boolean txt(String line) {

		return line.matches(".+\\.txt");
	}

	private static void printLine(String line) {

		StringBuffer ret = new StringBuffer("");

		String[] splited = line.split(":");

		String dataStr = line.substring(1, line.indexOf(']'));

		// Date date = new Date(dataStr + ".");
		// Date today = new Date();
		// if(date == today)
		// 	return;

		ret.append("v");

		if(splited.length == 4) {
			ret.append(splited[1].split("\\.").length);
		}
		else {
			ret.append(splited.length-3);
		}

		ret.append(":" + splited[splited.length - 2] + ":/");

		String[] path = splited[splited.length-1].split("\\/");

		System.out.println(path[0]);

		for(int i = 3; i < path.length; i++) {
			ret.append(path[i]);
			if(i < path.length - 1)
				ret.append("/");
		}


		System.out.println(ret);
	}
}

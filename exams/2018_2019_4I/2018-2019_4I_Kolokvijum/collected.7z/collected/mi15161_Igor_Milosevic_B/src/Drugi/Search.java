package Drugi;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;



public class Search{

	String lokacijaFajla;
	Character k;
	Lock lock;


	public Search(String lokacijaFajla, Character k) {
		super();
		this.lokacijaFajla = lokacijaFajla;
		this.k = k;
		this.lock = new ReentrantLock();

	}

	public synchronized int prebroj() throws IOException{

//		lock.lock();

		InputStreamReader in = new InputStreamReader(new FileInputStream(lokacijaFajla));
		int b;
		int brojac = 0;
		while((b = in.read()) != -1){
			if((char)b == k){
				brojac++;
			}

		}
		System.out.println(Thread.currentThread().getId() + ":" + lokacijaFajla + ":" + brojac);
		in.close();

//		lock.unlock();
		return brojac;
	}



}

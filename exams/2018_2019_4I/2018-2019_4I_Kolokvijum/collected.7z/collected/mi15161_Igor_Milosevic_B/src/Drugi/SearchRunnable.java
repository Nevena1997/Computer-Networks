package Drugi;

import java.io.IOException;

public class SearchRunnable implements Runnable {

	Search search;
	String lokacijaFajla;
	Character k;



	public SearchRunnable(String lokacijaFajla, Character k) {
		super();
		this.lokacijaFajla = lokacijaFajla;
		this.k = k;
		this.search = new Search(lokacijaFajla, k);
	}



	@Override
	public void run() {

			int ukupanBroj;
			try {
				ukupanBroj = search.prebroj();
				System.out.println(ukupanBroj);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

}



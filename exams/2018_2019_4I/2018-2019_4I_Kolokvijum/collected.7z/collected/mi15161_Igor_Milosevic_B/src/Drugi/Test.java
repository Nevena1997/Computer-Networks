package Drugi;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String ulaz = sc.next();

		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(ulaz),"UTF-8"));

		int n = sc.nextInt();
		Character c = sc.next().charAt(0);

		Scanner adrese = new Scanner(in);
		for (int i = 0; i < n; i++) {

			if(adrese.hasNext()){
				SearchRunnable search = new SearchRunnable(adrese.nextLine(), c);
				Thread t = new Thread(search);
				t.start();
			}

		}




		adrese.close();
		sc.close();
		in.close();
	}

}

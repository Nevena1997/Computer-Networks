package Drugi;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class FileTree  {

	public static void main(String[] args) throws IOException {

		//ova klasa mi je sluzila samo kao pomocna
		//da proverim da l dobro radi sumiranje kad se javlja zadati karakter
		InputStreamReader in = new InputStreamReader(new FileInputStream("emails.txt"));
		int b;
		int brojac = 0;
		while((b = in.read()) != -1){
			if((char)b == 'a'){
				brojac++;
			}

		}
		System.out.println(brojac);
		in.close();

	}
}

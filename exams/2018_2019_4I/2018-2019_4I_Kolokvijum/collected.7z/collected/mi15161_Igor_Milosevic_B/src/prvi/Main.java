package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String imeFajla = sc.next();
		sc.close();

		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(imeFajla), "UTF-8"));
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"),"UTF-8"));

		Scanner mailovi = new Scanner(in);

		while(mailovi.hasNext()){
			String mail = mailovi.next();
			if(mail.matches("([a-z0-9])+@[a-z]+\\.[a-z]+")){
				//System.out.println(mail);
				out.write(mail + "\n\n");
			}
		}
		out.flush();
		mailovi.close();

		in.close();
		out.close();
	}
}

package treci;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String putanja = sc.next();
		//file:///C:/Users/nalog/Desktop/mi15161_Igor_Milosevic_B/secret.txt
		URL u = new URL(putanja);
		URLConnection uc = u.openConnection();
		InputStream in = uc.getInputStream();
		Scanner log = new Scanner(in);
		while(log.hasNext()){
			String red = log.nextLine();
			//System.out.println(red.substring(red.length()-3, red.length()));
			//System.out.println(red.substring(8, 12));
			String dan = red.substring(2, 4);
			String mesec = red.substring(5,7);
			String godina = red.substring(8,12);
			if(red.substring(red.length()-3, red.length()).equals("txt")){
				if((dan.equals("22") || dan.equals("23")) && mesec.equals("11") && godina.equals("2018") ){
					int p = red.lastIndexOf(":");
					String niska = red.substring(14, p);
					String resurs = red.substring(p+3);
					int prviSles = resurs.indexOf("/");
					resurs = resurs.substring(prviSles);
					String protokol = niska.substring(niska.lastIndexOf(':') + 1, niska.length());
//					System.out.println(resurs);
					if(red.substring(14, red.lastIndexOf(':')).length() > 15){
						System.out.println("v6:" + protokol + ":" + resurs );
					}else{
						System.out.println("v4:" + protokol + ":" + resurs );
					}

				}
			}
		}
		log.close();
		sc.close();
	}
}

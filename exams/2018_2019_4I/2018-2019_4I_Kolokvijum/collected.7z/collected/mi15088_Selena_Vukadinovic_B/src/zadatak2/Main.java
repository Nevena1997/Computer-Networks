package zadatak2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Scanner s = new Scanner(sc.next());
		int n = sc.nextInt();
		char k = sc.next().charAt(0);
		while(s.hasNextLine()){
			String linija = s.nextLine();
			System.out.println(linija);
			Thread t = new Thread(new KlasaRunnable(linija, k, Thread.currentThread().getId()));
			t.start();
		}


		s.close();
		sc.close();

	}

}

package zadatak2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class KlasaRunnable implements Runnable {
	String putanja;
	char k;
	long id;

	public KlasaRunnable(String p, char k, long id) {
		this.putanja = new String(p);
		this.k = k;
		this.id = id;
	}

	@Override
	public void run(){
		try(InputStreamReader in = new InputStreamReader(new FileInputStream(putanja))) {
			int c;
			int brojac= 0;
			while(-1 != (c = in.read())){
				if(c == this.k){
					brojac++;
				}
			}

			System.out.println(this.id + ":" + this.putanja + ":" + brojac);

		} catch (FileNotFoundException e) {
		} catch (IOException e1) {}

	}

}

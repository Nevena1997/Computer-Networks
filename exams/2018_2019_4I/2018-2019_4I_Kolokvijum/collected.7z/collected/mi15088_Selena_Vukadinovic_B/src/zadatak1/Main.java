package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		try(BufferedReader bin = new BufferedReader(new InputStreamReader(new FileInputStream(sc.next()) , "UTF-8"));
				BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8")))
			{
			char[] buf = new char[70];
			int read = 0;
			while(-1 != (read = bin.read(buf, 0, 70))){
				if(validan_mail(buf))
					bout.write(buf, 0, read);
			}

		} catch (FileNotFoundException e) {
			System.err.println("Ne postoji fajl sa tim imenom!");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOException!!");
			e.printStackTrace();
		}

		sc.close();
	}

	private static boolean validan_mail(char[] buf) {
		String tekst = Arrays.toString(buf);
		String prvi_deo = (String) tekst.subSequence(0, tekst.indexOf("@"));
		String drugi_deo = (String) tekst.subSequence(tekst.indexOf("@")+1, tekst.length()-1);

		//prvi deo sadrzi slova i brojeve, a drugi slova, brojeve i tacku!
		if(prvi_deo.chars().allMatch(c -> slovo(c) || broj(c))
				&& drugi_deo.chars().allMatch(c -> slovo(c) || broj(c))
				&& drugi_deo.contains("."))
			return true;

		return false;
	}

	private static boolean broj(int c) {
		if(c>= 0 && c<= 9)
			return true;
		return false;
	}

	private static boolean slovo(int c) {
		if((c+'a'>='a' && c+'a'<= 'z') || (c+'A' >= 'A' && c+'A' <= 'Z')){
			return true;
		}
		return false;
	}

}

package zadatak3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

public class Main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		try {
			StringBuffer sb = new StringBuffer("file:://"+sc.next());
			URL u = new URL(sb.toString());
			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			//BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out));

			char[] buf= new char[70];
			int read;
			while(-1 != (read = in.read(buf, 0, 70))){
				//out.write(buf, 0, read);
				String str = buf.toString().trim();
				String ekstenzija = str.substring(str.lastIndexOf("."));

				if(ekstenzija.equals(".txt")){
					String substrOld = str.substring(str.indexOf(":")+1);
					String substrNew = substrOld.substring(str.indexOf(":")+1);
					while(substrNew.contains(":")){
						substrOld = substrNew;
						substrNew = substrNew.substring(substrNew.indexOf(":")+1);
					}

					//Sad substrOld sadrzi URL koji nam treba,a mi ispisujemo liniju koja ga sadrzi
					//System.out.println(str);

					String datum = str.substring(1, str.indexOf("]"));
					int dan = Integer.parseInt(datum.substring(0, datum.indexOf(".")));
					int mesec= Integer.parseInt(datum.substring(datum.indexOf(".")+1, datum.lastIndexOf(".")));
					int godina = Integer.parseInt(datum.substring(datum.indexOf(".")+1));

					Date danas = new Date();
					if(godina != danas.getYear() )
						continue;
					if(mesec != danas.getMonth())
						continue;
					if(dan != danas.getDay() )
						if(dan-1 != danas.getDay())
							continue;

					URL purl = new URL(substrOld);

					System.out.println("v4:" + purl.getProtocol() + ":" + purl.getPath());


				}

			}
			in.close();
		} catch (MalformedURLException e) {
			System.err.println("URLEXCEPTION");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IOEXCEPTION");
			e.printStackTrace();
		}


		sc.close();

	}

}

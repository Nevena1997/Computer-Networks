import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		//Mora apsolutna putanja!!!!!
		//npr C:/Users/nalog/Desktop/MI15119_Mladen_Krcmarevic_A/Zadatak3/in.txt
		Scanner sc = new Scanner(System.in);
		String fileLocation = sc.nextLine();
		sc.close();
		try {
			URL url = new URL("file:///"+fileLocation);
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
			StringBuffer inputFileBuff = new StringBuffer();
			String str;
			while (true){
				str = in.readLine();
				if (str == null)
					break;
				inputFileBuff.append(str+"\n");
			}
			in.close();
			String inputFile = inputFileBuff.toString();
			System.out.println(inputFile);
			System.out.println();
			System.out.println("Filtrirani:");


			String[] lines = inputFile.split("\\n");
			Pattern pat = Pattern.compile(".*?:(.*?):([a-z].*)://(.*)");
			for (int i=0; i<lines.length; i++){
				Matcher m = pat.matcher(lines[i]);
				//Nalazenje validnih datuma

				if (m.find()){
					String ip = m.group(1);
					String protokol = m.group(2);
					String address = m.group(3);
					if (protokol.equals("ftp") || protokol.equals("sftp")){
						StringBuffer out = new StringBuffer("v");
						if (ip.length()>15){
							out.append("6:");
						}
						else{
							out.append("4:");
						}
						URL ur = new URL("ftp://"+address);
						out.append(protokol+":"+ur.getPath());
						System.out.println(out);
					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

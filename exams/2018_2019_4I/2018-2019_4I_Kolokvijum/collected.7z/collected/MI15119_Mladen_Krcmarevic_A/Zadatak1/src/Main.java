import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		String inputFilePath = sc.nextLine();
		sc.close();

		try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(inputFilePath), "UTF-8"))){
			try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"))){
				//Citanje input fajla
				StringBuffer inputFileBuff = new StringBuffer();
				String str;
				while (true){
					str = in.readLine();
					if (str == null)
						break;
					inputFileBuff.append(str);
				}
				String inputFile = inputFileBuff.toString();


				Pattern pat = Pattern.compile("([0-9]{2})-([0-9]{2})-([0-9]{4})");
				Matcher m = pat.matcher(inputFile);
				//Nalazenje validnih datuma
				while (m.find()){
					int day = Integer.parseInt(m.group(1));
					int month = Integer.parseInt(m.group(2));
					int year = Integer.parseInt(m.group(3));

					if (ValidDate(day, month, year)){
						//Ispis u izlazni fajl
						out.write(m.group(0));
						out.newLine();
					}

				}
				out.flush();
			}
			catch(Exception e){
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean ValidDate(int day, int month, int year){
		if (month > 12 || month == 0)
			return false;
		if (month <= 7){
			if (month % 2 == 0){
				if (day > 31){
					return false;
				}
			}
			else{
				if (day > 30){
					return false;
				}
			}
		}
		if (month > 7){
			if (month % 2 == 0){
				if (day > 30){
					return false;
				}
			}
			else{
				if (day > 31){
					return false;
				}
			}
		}
		if (month == 2){
			if ((year % 4 == 0 && day > 28) ||
				(year % 4 != 0 && day > 29))
			return false;
		}
		if (year < 2000)
			return false;
		return true;
	}

}

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;



public class Main {
	static ConcurrentLinkedQueue<String> paths;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		paths = new ConcurrentLinkedQueue<String>();

		Scanner sc = new Scanner(System.in);
		String fileListLocation = sc.nextLine();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fileListLocation)));
			String str;
			while (true){
				str = in.readLine();
				if (str == null)
					break;
				paths.add(str);
			}

			String key = sc.nextLine();
			int n = sc.nextInt();
			sc.close();
			in.close();
			for (int i=0; i<n; i++){
				FinderThread ft = new FinderThread(paths, key);
				Thread t = new Thread(ft);
				t.start();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

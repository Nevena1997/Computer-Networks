import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ConcurrentLinkedQueue;

public class FinderThread implements Runnable{
	ConcurrentLinkedQueue<String> paths;
	String key;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String path;
		while((path = NextPath()) != null){
			FindKeyword(path);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public FinderThread(ConcurrentLinkedQueue<String> paths, String key) {
		this.paths = paths;
		this.key= key;

	}

	private String NextPath(){
		if (!paths.isEmpty())
			return paths.remove();
		else
			return null;
	}

	private void FindKeyword(String path){
		BufferedReader in;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
			String str;
			int line = 1;
			while (true){
				str = in.readLine();
				if (str == null)
					break;
				String[] words = str.split(" ");
				for (int i=0; i<words.length; i++){
					if (words[i].equals(this.key)){
						System.out.println(Thread.currentThread().getName()+":"+ path+":"+line);
						break;
					}

				}
				line++;
			}

			in.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

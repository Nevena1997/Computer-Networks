package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String fajl = sc.nextLine();
		sc.close();
		Scanner in = null;
		BufferedWriter out = null;
		try{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fajl), "utf-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "utf-8"));

			while(in.hasNext()){
				String mail = in.next();
				if(isEmail(mail)) {
					out.write(mail);
					out.write(" ");
				}
			}

		} catch (IOException e){
			e.printStackTrace();
		} finally {
			if(in != null)
				in.close();
			if(out != null)
				out.close();
		}

	}

	private static boolean isEmail(String mail){
		if(mail.length() < 1)
			return false;
		if(!mail.contains("@") || mail.indexOf('@') == 0 || mail.indexOf('.') == mail.length() - 1)
			return false;
		if(mail.indexOf('@') > mail.indexOf('.'))
			return false;
		int i = 0;
		for( i = 0; i < mail.indexOf('@'); i++ ){
			if(!Character.isLetter(mail.charAt(i)) && !Character.isDigit(mail.charAt(i))){
				return false;
			}
		}
		return true;
	}
}

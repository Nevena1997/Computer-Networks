package treci;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class TreciMain {

	public static void main(String[] args) {
		Scanner sc = null;
		try {
			sc = new Scanner(System.in);
			String p = sc.nextLine();
			sc = new Scanner(new File(p));
			while(sc.hasNext()){
				//System.out.println(sc.nextLine());
				String linija = sc.nextLine();
				if(linija.contains(".txt"))
					System.out.println(linija);
			}
		} catch (IOException e){
			e.printStackTrace();
		} finally {
			if(sc != null)
				sc.close();
		}

	}

}

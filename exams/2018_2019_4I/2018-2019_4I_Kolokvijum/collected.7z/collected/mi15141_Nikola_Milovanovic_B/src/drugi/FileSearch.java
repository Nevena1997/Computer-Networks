package drugi;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class FileSearch implements Runnable{
	private BlockingQueue<Path> ps;
	private char k;

	public FileSearch(BlockingQueue<Path> ps, char k){
		this.ps = ps;
		this.k = k;
	}

	@Override
	public void run(){
		try {
			Path a = ps.take();
			int br = obrada(a);
			System.out.println(Thread.currentThread().getId() + ":" + a.toString() + ":" + br);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	int obrada(Path p) throws InterruptedException{
		int brojac = 0;
		Scanner sc = null;
		try {
			sc = new Scanner(p);
			while(sc.hasNext()){
				String line = sc.nextLine();
				for(int i = 0; i < line.length(); i++){
					if(line.charAt(i) == this.k)
						brojac ++;
				}
			}
			return brojac;
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			if(sc != null)
				sc.close();
		}
		return brojac;
	}
}

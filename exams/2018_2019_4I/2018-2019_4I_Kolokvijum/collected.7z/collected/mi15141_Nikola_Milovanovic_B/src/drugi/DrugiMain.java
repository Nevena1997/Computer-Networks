package drugi;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class DrugiMain {
	public static final Path dummy = Paths.get("");
	public static void main(String[] args) {
		Scanner sc = null;
		try {
		sc = new Scanner(System.in);
		String putanja = sc.nextLine();
		char c = sc.next().charAt(0);
		int n = sc.nextInt();
		System.out.println(c);
		BlockingQueue<Path> ps = new ArrayBlockingQueue<>(100);
		sc = new Scanner(new File(putanja));
		while(sc.hasNext()){
			String a = sc.next();
			ps.add(Paths.get(a));
			System.out.println(a);
		}
		//ps.add(dummy);
		for(int i = 0; i < n; i++){
			FileSearch fs = new FileSearch(ps, c);
			Thread t = new Thread(fs);
			t.start();
		}

		} catch (FileNotFoundException e){
			e.printStackTrace();
		} finally {
			if(sc != null)
				sc.close();
		}

	}

}

package _3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String in = sc.next();
		sc.close();
		try {
			URL url = new URL("FILE", "localhost", in);
			System.out.println("Sadrzaj: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			while((line = br.readLine()) != null){
				System.out.println(line);
			}
			br.close();

			br = new BufferedReader(new InputStreamReader(url.openStream()));
			System.out.println("\r\nFiltrirane linije: ");
			while((line = br.readLine()) != null){
				if(check(line))
					//System.out.println(line);
					System.out.println(changedOutput(line) + url.getPath());
			}
			br.close();
		} catch (MalformedURLException e) {
			System.err.println("Pogresna URL adresa");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO greska");
			e.printStackTrace();
		}
	}

	public static boolean check(String line){
		int lastTwoDots = line.lastIndexOf(':');
		//System.out.println(lastTwoDots);
		int secondTwoDots = line.lastIndexOf(':', lastTwoDots-1);
		//System.out.println(secondTwoDots);
		String protocol = line.substring(secondTwoDots+1, lastTwoDots);
		//System.out.println(protocol);
		if(protocol.toUpperCase().equals("FTP") || protocol.toUpperCase().equals("SFTP"))
			return true;
		return false;
	}

	public static String changedOutput(String line){
		StringBuffer sb = new StringBuffer("v");
		int firstTwoDots = line.indexOf(':');
		int firstDot = line.indexOf('.', firstTwoDots+1); //first dot after date

		int lastTwoDots = line.lastIndexOf(':');
		int secondTwoDots = line.lastIndexOf(':', lastTwoDots-1);
		String protocol = line.substring(secondTwoDots+1, lastTwoDots);

		if(firstDot < lastTwoDots)
			sb.append('4');
		else
			sb.append('6');

		sb.append(":"+protocol+":");

		return sb.toString();
	}
}

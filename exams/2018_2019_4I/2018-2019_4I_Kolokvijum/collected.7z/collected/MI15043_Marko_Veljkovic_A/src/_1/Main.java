package _1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String in = sc.next();
		sc.close();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(in), "UTF-8"))){

			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
			String line;
			while((line = br.readLine()) != null){
				String dates[] = line.split(" ");
				int n = dates.length;
				for(int i = 0; i < n; i++){
					if(check(dates[i].trim())){
						bw.write(dates[i]);
						bw.newLine();
					}
				}
			}
			br.close();
			bw.close();
			//System.out.println("Done");
		} catch (FileNotFoundException e) {
			System.err.println("Fajl nije nadjen");
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			System.err.println("Nepodrzano kodiranje");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO greska");
			e.printStackTrace();
		}

	}

	static boolean check(String word){
		char letters[] = word.toCharArray();
		int n = letters.length;
		if(n != 10)
			return false;
		if(!((letters[0] >= '0' && letters[0] < '3') || (letters[0] == '3' && letters[1] >= '0' && letters[1] < '2')))
			return false;
		if(letters[2] != '-' || letters[5] != '-')
			return false;
		if(!((letters[3] == '0' && letters[4] >= '0' && letters[4] <= '9') || (letters[3] == '1' && letters[4] >= '0' && letters[4] < '3')))
			return false;
		if(letters[6] < '2')
			return false;
		if(!(letters[7] >= '0' && letters[7] <= '9'))
			return false;
		if(!(letters[8] >= '0' && letters[8] <= '9'))
			return false;
		if(!(letters[9] >= '1' && letters[9] <= '9'))
			return false;
		return true;
	}

}

package _2;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Search implements Runnable {

	private BlockingQueue<Path> bq;
	private String keyWord;

	public Search(BlockingQueue<Path> bq, String keyWord) {
		this.bq = bq;
		this.keyWord = keyWord;
	}

	@Override
	public void run() {
		boolean done = false;
		while(!done){
			Path p = this.bq.poll();
			if(p == Main.DUMMY){
				done = true;
				this.bq.add(p);
			}
			check(p);
		}
	}

	synchronized public void check(Path p){
		try(Scanner sc = new Scanner(p)){
			int lnNum = 1;
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				if(line.contains(keyWord)){
					System.out.println("ID_NITI:" + p.toString() + ":" + lnNum + "\r\n"); //nisam mogao da nadjem metod za dobijanje id niti
				}
				lnNum++;
			}
		} catch (IOException e) {
		}
	}
}

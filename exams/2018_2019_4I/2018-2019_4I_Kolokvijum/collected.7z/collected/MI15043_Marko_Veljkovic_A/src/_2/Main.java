package _2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	private static final int QUEUE_SIZE = 10;
	static final Path DUMMY = Paths.get("");

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String in = sc.next();
		BlockingQueue<Path> bq = new ArrayBlockingQueue<>(QUEUE_SIZE);
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(in)));
			String line;
			while((line = br.readLine()) != null){
				System.out.println(line);
				Path p = Paths.get(line);
				bq.add(p);
			}
			bq.add(DUMMY);
			br.close();
			System.out.println("Kljucna rec: ");
			String keyWord = sc.next();
			System.out.println("Zeljeni broj niti");
			int n = sc.nextInt();
			for(int i = 0; i < n; i++){
				new Thread(new Search(bq, keyWord)).start();
			}
		} catch (FileNotFoundException e) {
			System.err.println("Fajl nije pronadjen");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO greska");
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}

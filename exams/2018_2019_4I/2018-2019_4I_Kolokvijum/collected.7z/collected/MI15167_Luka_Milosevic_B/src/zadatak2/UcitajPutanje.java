package zadatak2;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class UcitajPutanje {

	private Path putanja;
	private int brojNiti;
	private BlockingQueue<Path> putanje = new ArrayBlockingQueue<Path>(100);
	private char k;
	public static final Path END = Paths.get("");
	public UcitajPutanje(Path putanja,char k,int brojNiti){
		this.putanja = putanja;
		this.brojNiti = brojNiti;
		this.k = k;
	}

	public void ucitaj(){
		for (int i = 0; i < this.brojNiti; i++) {
			Obradi o = new Obradi(putanje,this.k);
			Thread t = new Thread(o);
			t.start();
		}

		Scanner sc = null;
		try {
			sc = new Scanner(putanja);
			String p;
			while(sc.hasNextLine()){
				p = sc.nextLine().trim();
				System.out.println(p);
				putanje.put(Paths.get(p));
			}


			putanje.put(END);
			System.out.println();
		} catch (IOException e) {
			System.err.println("ispada");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(sc!=null)
				sc.close();
		}


	}

}

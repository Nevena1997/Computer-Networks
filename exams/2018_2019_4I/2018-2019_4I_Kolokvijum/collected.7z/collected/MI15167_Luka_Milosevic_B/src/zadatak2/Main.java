package zadatak2;

import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("Unesite putanju:");
		Scanner sc = new Scanner(System.in);
		String putanja = sc.next();
		//C:\Users\nalog\Desktop\MI15167_Luka_Milosevic_B\paths.txt
		System.out.println("Unesite char:");
		char k = sc.next().charAt(0);
		System.out.println("Unesite broj niti:");
		int brojNiti = sc.nextInt();


		sc.close();
		UcitajPutanje up = new UcitajPutanje(Paths.get(putanja), k, brojNiti);
		up.ucitaj();
	}
}

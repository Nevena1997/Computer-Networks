package zadatak2;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Obradi implements Runnable{

	private BlockingQueue<Path> putanje;
	private char k;

	public Obradi(BlockingQueue<Path> putanje, char k) {
		this.putanje = putanje;
		this.k = k;
	}

	@Override
	public void run() {

		while(true){
			try {
				Path p = putanje.take();
				if(p.equals(UcitajPutanje.END)){
					System.out.println("Thread exiting: "+Thread.currentThread());
					putanje.put(UcitajPutanje.END);
					return;
				}

				obradi(p);

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private void obradi(Path p) {
		Scanner sc = null;
		int num = 0;
		try {
			sc = new Scanner(p);
			String line;
			while(sc.hasNextLine()){
				line = sc.nextLine();
				for (int i = 0; i < line.length(); i++) {
					if(line.charAt(i) == this.k)
						num++;
				}
			}

			System.out.println(Thread.currentThread().getId()+":"+p.toAbsolutePath().toString()+":"+num);
		} catch (IOException e) {


		}finally {
			if(sc != null)
				sc.close();
		}

	}

}

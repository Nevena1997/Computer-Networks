package zadatak3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.println("Unesite fajl:");
		String putanja = in.next().trim();
		in.close();
		Scanner sc = null;
		try {
			String apsolutnaPutanja = "file:///"+Paths.get(putanja).toAbsolutePath().toString();
			URL u = new URL(apsolutnaPutanja);
			sc = new Scanner(u.openStream());
			String line = null;
			while(sc.hasNextLine()){
				line = sc.nextLine().trim();
				if(line.substring(line.lastIndexOf(".")+1).equals("txt"))
					obradi(line);
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(sc!=null)
				sc.close();
		}

	}

	private static void obradi(String line) {
		String[] words = line.split("://");
		String protokol = words[0].substring(words[0].lastIndexOf(":")+1);
		words[0] = words[0].substring(0,words[0].lastIndexOf(":"));
		String datum = words[0].substring(0,words[0].indexOf(":"));
		datum = datum.substring(1,datum.length()-1);
//		System.out.println(datum);
		int dan =Integer.parseInt(datum.substring(0,datum.indexOf(".")));
		int mesec = Integer.parseInt(datum.substring(datum.indexOf(".")+1,datum.lastIndexOf(".")));
		int godina = Integer.parseInt(datum.substring(datum.lastIndexOf(".")+1));
		Date d = new Date();
		int tDan = d.getDay();
		int tMesec = d.getMonth();
		int tGodina = d.getYear();
		//nisam obradjivao specijalne slucajeve ako je prvi u mesecu i poslednji dan u mesecu
		if(tGodina == godina)
			if(tMesec == mesec)
				if(tDan-dan <= 1){
					String ip = words[0].substring(words[0].indexOf(":")+1);
					if(ip.contains(":")){
						System.out.println("v6:"+protokol+":"+words[1].substring(words[1].indexOf("/")));
					}else{
						System.out.println("v4:"+protokol+":"+words[1].substring(words[1].indexOf("/")));
					}
				}

//		pitao sam vas na kolokvijumu posto mi ovo getDay getMonth getYear nije vracalo lepe vrednosti za datum pa sam
//		ostavio ovde ispis posto ovaj if gore ne prolazi

//		String ip = words[0].substring(words[0].indexOf(":")+1);
//		if(ip.contains(":")){
//			System.out.println("v6:"+protokol+":"+words[1].substring(words[1].indexOf("/")));
//		}else{
//			System.out.println("v4:"+protokol+":"+words[1].substring(words[1].indexOf("/")));
//		}
	}

}//nekiLogFajl.txt

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Unesite ime fajla:");
		Scanner sc = new Scanner(System.in);
		String fajl = sc.next();
		sc.close();
		BufferedWriter out = null;
		Scanner in = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fajl),"UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt")));
			String word;
			while(in.hasNext()){
				word = in.next();
				if(check(word.trim())){
					out.write(word+"\n");
					out.flush();
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

		} catch(FileNotFoundException e){
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(in != null)
				in.close();
			if(out!=null){
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}

	private static boolean check(String word) {
		String[] words = word.split("@");
		if(words.length>2)
			return false;
		if(!words[1].contains("."))
			return false;
		for (int i = 0; i < words[0].length(); i++) {
			if(!Character.isAlphabetic(words[0].charAt(i)) && !Character.isDigit(words[0].charAt(i)) && words[1].charAt(i)!='.')
				return false;
		}
		for (int i = 0; i < words[1].length(); i++) {
			if(!Character.isAlphabetic(words[1].charAt(i)) && !Character.isDigit(words[1].charAt(i)) && words[1].charAt(i)!='.')
				return false;
		}
		return true;
	}

}

package zadatak2;

public class CharCountRunnable implements Runnable {
	public final int MAX_DELAY = 5;
	private CharCount cc;

	public CharCountRunnable(String fileName, String c) {
		this.cc = new CharCount(fileName, c);
	}

	@Override
	public void run() {
		try {
			cc.count();
			Thread.sleep((int)(Math.random()* MAX_DELAY));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

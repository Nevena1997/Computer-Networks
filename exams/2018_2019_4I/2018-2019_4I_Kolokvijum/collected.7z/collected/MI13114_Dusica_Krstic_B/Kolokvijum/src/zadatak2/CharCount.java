package zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CharCount {
	private static String fileName;
	private static String c;
	private static Lock lock;

	public CharCount(String fileName, String c) {
		CharCount.fileName = fileName;
		CharCount.c = c;
		CharCount.lock = new ReentrantLock();
	}

	public static void setFileName(String fileName) {
		CharCount.fileName = fileName;
	}

	public static void setC(String c) {
		CharCount.c = c;
	}

	public static void setLock(Lock lock) {
		CharCount.lock = lock;
	}

	public void count() {
		lock.lock();
		Scanner in = null;
		int nbAppearances = 0;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(CharCount.getFileName()))));
			char c = CharCount.getC().charAt(0);
			while (in.hasNext()) {
				String text = in.next();
				int n = text.length();
				for (int i = 0; i < n; i++) {
					if (text.charAt(i) == c) {
						nbAppearances++;
					}
				}
			}
			System.out.println(Thread.currentThread() +":" + fileName + ":" + nbAppearances);

		} catch (FileNotFoundException e) {
			System.out.println("Fajl nije pronadjen.");
			e.printStackTrace();
		} finally {
			in.close();
			lock.unlock();
		}
	}

	public static String getFileName() {
		return fileName;
	}

	public static String getC() {
		return c;
	}

}

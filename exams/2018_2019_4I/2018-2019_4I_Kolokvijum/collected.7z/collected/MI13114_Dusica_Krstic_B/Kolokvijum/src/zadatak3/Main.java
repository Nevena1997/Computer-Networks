package zadatak3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();
		sc.close();

		standardniIspis(fileName);
		filtriraniIspis(fileName);

	}

	public static void standardniIspis(String fileName) {
		try {
			URL u = new URL(fileName);
			InputStreamReader in = new InputStreamReader(u.openStream());
			int b;
			while ((b = in.read()) != -1) {
				System.out.println(b);
			}

			in.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void filtriraniIspis(String fileName) {
		try {
			URL u = new URL(fileName);



		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla koji sadrzi email adrese:");
		String fileName = sc.next();
		sc.close();

		Scanner in = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8")));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"),"UTF-8"));

			while (in.hasNext()) {
				String text = in.next();
				if (isEmail(text)) {
					out.write(text);
					out.write("\n");
				}
			}
			out.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println("Podesavanje kodne strane nije uspelo.");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("Ne postoji ulazni fajl.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Pravljenje izlaznog fajla nije uspelo.");
			e.printStackTrace();
		} finally {
			in.close();
		}



	}

	private static boolean isEmail(String text) {
		if (!text.contains("@")) {
			return false;
		}
		String left = text.substring(0, text.indexOf("@"));
		String right = text.substring(text.indexOf("@")+1);
		if (!right.matches("[[a-z]+|[0-9]+]+\\.[a-z]+")) {
			return false;
		}
		if (!left.matches("[[a-z]+|[0-9]+]+[[a-z]*|[0-9]*|_*|\\.]*[[a-z]+|[0-9]+]+")) {
			return false;
		}
		return true;
	}

}

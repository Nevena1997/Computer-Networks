package zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla koji sadrzi putanje:");
		String fileName = sc.next();
		System.out.println("Unesite karakter za koji treba proveriti pojavljivanje:");
		String c = sc.next();
		int nbThreads;
		System.out.println("Unesite broj niti:");
		nbThreads = sc.nextInt();
		sc.close();

		Scanner in = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName))));
			Vector<String> paths = new Vector<String>();
			System.out.println("Putanje koje se nalaze u zadatom fajlu su:");
			while (in.hasNextLine()) {
				String path = in.nextLine();
				System.out.println(path);
				paths.add(path);
			}
			int n = paths.size();
			for (int i = 0; i < nbThreads; i++) {
				CharCountRunnable ccr = new CharCountRunnable(paths.elementAt((int)(Math.random() * n)), c);
				Thread t = new Thread(ccr);
				t.run();
			}

		} catch (FileNotFoundException e) {
			System.out.println("Ulazni fajl nije pronadjen");
			e.printStackTrace();
		} finally {
			in.close();
		}
	}

}

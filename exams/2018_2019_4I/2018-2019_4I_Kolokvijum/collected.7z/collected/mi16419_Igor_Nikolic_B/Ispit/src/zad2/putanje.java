package zad2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class putanje implements Runnable {

	private BufferedReader in;
	private BlockingQueue<Path> red;

	public putanje(BufferedReader in,BlockingQueue<Path> red)
	{
		this.in=in;
		this.red=red;
	}

	@Override
	public void run() {

		try {
			izlistajPutanje(in);
			red.put(Paths.get(""));
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	private void izlistajPutanje(BufferedReader in2) throws InterruptedException {

		String line ;
		try {
			while((line = in2.readLine())!=null)
			{
				System.out.println("Thread id:"+Thread.currentThread().getId() +line);
				red.put(Paths.get(line));

			}
		} catch (IOException e) {

			e.printStackTrace();
		}


	}


}

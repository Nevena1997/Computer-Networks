package zad2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class Provera implements Runnable {

	private BlockingQueue<Path> red;
	private char c;


	public Provera(BlockingQueue<Path> red,char c) {
		this.red=red;
		this.c=c;
	}


	@Override
	public void run() {
		boolean ind = false;

		while(ind == false)
		{
			try{
			Path p = red.take();
			if(p==Paths.get(""))
			{
				ind = true;
				red.put(Paths.get(""));
			}
			else
			{
				int k = count(p);
				System.out.println("Izbrojano je :"+k);
			}
			}catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}

	}


	private int count(Path p) {

		int brojac=0;
		try {

			FileInputStream fin = new FileInputStream(p.toString());

			int b;

			while((b=fin.read()) != -1)
			{

				if((char)b == c)
				{
					brojac++;
				}

			}
			fin.close();



		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return brojac;
	}





}

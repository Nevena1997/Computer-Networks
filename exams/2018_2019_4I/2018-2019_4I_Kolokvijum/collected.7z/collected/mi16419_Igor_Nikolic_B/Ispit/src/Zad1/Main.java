package Zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {

		System.out.println("Unesite mailove");
		Scanner sc = new Scanner(System.in);
		String file = sc.next();


		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"),"UTF-8"));

			String line;

			while((line = br.readLine()) != null)
			{
				String[] array = line.split("\n");

				for(String mail: array)
				{
					if(checkMail(mail))
					{
						bw.write(mail+"\n");
					}

				}


			}


			br.close();
			bw.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}



		sc.close();
	}
	private static boolean checkMail(String mail) {

		int index = mail.indexOf("@");
		if(index>0)
		{
			String beforeat = mail.substring(0,index);
			String afterat  = mail.substring(index+1);

			char[] arr_before = beforeat.toCharArray();
			char[] arr_after = afterat.toCharArray();

			for (char i : arr_before) {

				if(!Character.isAlphabetic(i) && i!='.' && !Character.isDigit(i))
					return false;
			}
			for (char j : arr_after) {

				if(!Character.isAlphabetic(j)&& j!='.' && !Character.isDigit(j))
					return false;
			}




			return true;
		}
		else
			return false;



	}

}

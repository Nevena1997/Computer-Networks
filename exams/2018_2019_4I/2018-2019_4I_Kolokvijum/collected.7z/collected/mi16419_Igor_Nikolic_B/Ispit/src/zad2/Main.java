package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) {

		System.out.println("Enter path");
		Scanner sc = new Scanner(System.in);

		String path = sc.next();

		System.out.println("Enter char");
		char c = sc.next().charAt(0);

		int brojTredova = sc.nextInt();



		try {

			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));

			BlockingQueue<Path> red = new ArrayBlockingQueue<>(brojTredova);

			putanje pu = new putanje(br, red);
			Thread t = new Thread(pu);
			t.start();


			for(int i=0;i<brojTredova;i++)
			{
				Provera pr = new Provera(red, c);
				Thread t1 = new Thread(pr);
				t1.start();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sc.close();


	}

}
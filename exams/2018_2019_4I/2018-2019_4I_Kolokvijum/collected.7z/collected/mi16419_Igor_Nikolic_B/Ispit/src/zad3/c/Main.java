package zad3.c;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		System.out.println("Insert file name");



		Scanner sc = new Scanner(System.in);


		String ime = sc.next();

		Path p = Paths.get(ime);

		String putanja = "file:///"+p;

		try{
			URL url = new URL(putanja);
			String prot = url.getProtocol();

			if(!(prot.equals("file")))
			{
				System.out.println("Wrong address");
			}

			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

			String line;

			while((line = in.readLine())!=null)
			{
				boolean indExt = false;

				int ind1 = line.lastIndexOf('.');
				String ext = line.substring(ind1+1);
				if(ext.equals(".txt"))
				{
					indExt = true;

				}
				boolean indDate = false;
				int ind2 = line.lastIndexOf(']');
				String datum = line.substring(1,ind2);

				String[] ArrayDate = datum.split(".");

				int dan = Integer.parseInt(ArrayDate[0]);
				int mesec = Integer.parseInt(ArrayDate[1]);
				int godina =Integer.parseInt(ArrayDate[2]);


				int ind3 = line.lastIndexOf(':');
				int ind4 = line.lastIndexOf(':',2);
				String prot1 = line.substring(ind3+1,ind4+1);


				int ind4 = line.indexOf(':');
				int ind5 = line.indexOf(':',2);

				String ip = line.substring(ind4+1,ind5+1);


				String url_do_resursa = line.substring(ind5,ind);

				if(indExt)
				{
					System.out.println("ipv4"+ip);
				}



			}




		}
	}




	}

}

package p02_threads;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class CharCounter extends Thread {

	private ConcurrentLinkedQueue<Path> queue;
	private char wantedChar;
	private int charCount = 0;
	private int threadId;

	public CharCounter(ConcurrentLinkedQueue<Path> queue, char wantedChar, int threadId) {
		this.queue = queue;
		this.wantedChar = wantedChar;
		this.threadId = threadId;
	}

	public int getCharCount() {
		return charCount;
	}

	@Override
	public void run() {
		while (true) {
			if (queue.isEmpty())
				return;

			synchronized (queue) {
				Path file = queue.poll();
				countChar(file);
			}
		}
	}

	private void countChar(Path file) {
		try {
			Scanner sc = new Scanner(file);
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				for (int i = 0; i < line.length(); i++) {
					if (line.charAt(i) == this.wantedChar)
						this.charCount = this.charCount + 1;
				}
			}

			sc.close();
			System.out.println(this.threadId + ": " + file + ": " + this.charCount);

		} catch (IOException e) {
			System.err.println("File not found!");
			// try again if file not found
			this.run();
		}

	}

}

package p03_url;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

public class TimeURL {

	// testing purpose
	// file:///C:/Users/nalog/Desktop/mi15266_Petar_Perisic_B/Kolokvijum4iB/logFile.txt

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("$ file path");

		String filePath = sc.nextLine();

		try {
			URL url = new URL(filePath);
			InputStream in = url.openStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));

			/* // backup
			int byteRead;
			while ((byteRead = in.read()) != -1)
				System.out.print((char) byteRead);
			*/

			/* // backup
 			String line;
			while ((line = reader.readLine()) != null) {
				int lastDot = line.lastIndexOf('.');
				if (line.substring(lastDot + 1).equalsIgnoreCase("txt"))
					System.out.println(line);
			}
			*/

			String line;
			StringBuffer sb = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				int lastDot = line.lastIndexOf('.');
				if (line.substring(lastDot + 1).equalsIgnoreCase("txt")) {
					sb.append("v").append("4:")
					  .append(url.getProtocol()).append(":")
					  .append(line.substring(line.lastIndexOf('/')));
					System.out.println(sb.toString());
				}
				sb.setLength(0);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.err.println("$ input file not found!");
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("$ url not found!");
		} finally {
			sc.close();
		}
	}

}
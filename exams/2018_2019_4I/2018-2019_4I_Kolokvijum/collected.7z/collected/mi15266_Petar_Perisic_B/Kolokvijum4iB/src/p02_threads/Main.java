package p02_threads;


import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Main {

	public static void main(String[] args) {

		// get file list
		try {


		Scanner sc = new Scanner(System.in);

		System.out.println("$ fileList path");
		String fileList = sc.nextLine();

		Scanner fileSc = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(fileList))));

		ConcurrentLinkedQueue<Path> queue = new ConcurrentLinkedQueue<Path>();

		while (fileSc.hasNextLine()) {
			String filePath = fileSc.nextLine();
			System.out.println(filePath);

			queue.add(Paths.get(filePath));
		}

		System.out.println("$ threadNum, char");
		int threadNum = sc.nextInt();
		char c = sc.next().charAt(0);

		if (threadNum <= 0) {
			System.out.println("$ wrong thread number!");
			System.exit(-1);
		}

		CharCounter[] counters = new CharCounter[threadNum];
		int tid = 1;
		for (int i = 0; i < threadNum; i++) {
			counters[i] = new CharCounter(queue, c, tid);
			tid = tid + 1;
		}

		for (int i = 0; i < threadNum; i++) {
			counters[i].start();
		}

		for (int i = 0; i < threadNum; i++) {
			counters[i].join();
		}

		fileSc.close();
		sc.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("$ failed to open input file");
		} catch (InterruptedException e) {
			e.printStackTrace();
			System.err.println("$ something went wrong");
		}
	}

}

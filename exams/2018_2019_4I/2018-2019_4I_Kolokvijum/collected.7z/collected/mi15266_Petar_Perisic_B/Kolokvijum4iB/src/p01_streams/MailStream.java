package p01_streams;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class MailStream {

	public static void main(String[] args) {
		// get file path
		Scanner sc = new Scanner(System.in);
		System.out.println("$ file name:");
		String fileName = sc.nextLine();
		sc.close();

		try {
			Scanner fileSc = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(fileName)), "UTF-8"));
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			while (fileSc.hasNext()) {
				String email = fileSc.next();
				if (isEmail(email)) {
					writer.write(email);
					writer.newLine();
				}
			}

			writer.flush();
			writer.close();
			fileSc.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.err.println("$ failed to read from the file!");
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("$ failed during wiriting in file email.txt!");
		}

	}

	private static boolean isEmail(String email) {
		if (email.length() < 3)
			return false;

		if (!Character.isLetter(email.charAt(0)))
			return false;

		int monkey = email.indexOf('@');
		for (int i = 0; i < monkey; i++) {
			if (Character.isDigit(email.charAt(i)) || Character.isLetter(email.charAt(i)))
				continue;
			else
				return false;
		}

		for (int i = monkey + 1; i < email.length(); i++) {
			if (Character.isDigit(email.charAt(i)) || Character.isAlphabetic(email.charAt(i)))
				continue;
			else if (email.charAt(i) == '.')
				continue;
			else
				return false;
		}

		return true;
	}

}

package kolokvijum;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.BlockingQueue;

public class FileTreeWalker implements Runnable {

	public static final Path DUMMY = Paths.get("");

	private BlockingQueue<Path> queue;
	private Path startingDir;

	public FileTreeWalker(BlockingQueue<Path> queue, Path startingDir) {
		this.queue = queue;
		this.startingDir = startingDir;
	}

	@Override
	public void run() {

		try {
			walk(this.startingDir);
			this.queue.put(DUMMY);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void walk(Path dir) {
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
			for (Path p : ds) {
				if (Files.isDirectory(p))
					walk(p);
				else
					this.queue.put(p);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

package kolokvijum;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class SearchKeyword implements Runnable {

	private BlockingQueue<Path> queue;
	private String keyword;

	public SearchKeyword(BlockingQueue<Path> q, String k) {
		this.queue = q;
		this.keyword = k;
	}

	@Override
	public void run() {
		try {
			boolean done = false;
			while(!done) {
				Path p;

				p = this.queue.take();

				if (p == FileTreeWalker.DUMMY) {
					 done = true;
					 this.queue.put(p);
				} else {
					search(p);
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void search(Path p) {
		try (Scanner sc = new Scanner(p)) {
			while(sc.hasNextLine()) {
				String line = sc.nextLine();
				if (line.contains(this.keyword))
					System.out.println("File: " + p.getFileName() + " contains " + this.keyword);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

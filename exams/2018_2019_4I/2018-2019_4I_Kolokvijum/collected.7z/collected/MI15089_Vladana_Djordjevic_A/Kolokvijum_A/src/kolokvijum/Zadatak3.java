package kolokvijum;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Zadatak3 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String putanja = sc.nextLine();
		sc.close();

		Scanner in = null;

		try {
			URL url = new URL(putanja);
			URLConnection uc = url.openConnection();

			if (!url.getProtocol().equalsIgnoreCase("file")) {
				System.err.println("Koristiti samo file protocol!");
				System.exit(1);
			}

			String fajl = url.getPath();

			in = new Scanner(new BufferedReader((new InputStreamReader(new FileInputStream(fajl)))));

			while (in.hasNextLine()) {
				String line = in.nextLine();
				int indexPoslednje = line.lastIndexOf(":");
				if (line.substring(indexPoslednje-5, indexPoslednje-4).equals(":")) {
					String podniska = line.substring(indexPoslednje-4, indexPoslednje);
					if (podniska.equals("sftp")) {
						int indeksKrajaAdrese = indexPoslednje - 5;
						int indeksPocetkaAdresse = line.lastIndexOf("]") + 2;
						String adresa = line.substring(indeksPocetkaAdresse, indeksKrajaAdrese);
						int indeksResursa = line.lastIndexOf("/");
						String resurs = line.substring(indeksResursa+1);
						if (adresa.length() == 15) {
							System.out.println("v4:sftp:" + resurs);
						} else if (adresa.length() == 23) {
							System.out.println("v6:sftp:" + resurs);
						} else {
							System.err.println("Nepoznata IP adresa");
						}
					}
				}

				if (line.substring(indexPoslednje-4, indexPoslednje-3).equals(":")) {
					String podniska = line.substring(indexPoslednje-3, indexPoslednje);
					if (podniska.equals("ftp")) {
						int indeksKrajaAdrese = indexPoslednje - 4;
						int indeksPocetkaAdresse = line.lastIndexOf("]") + 2;
						String adresa = line.substring(indeksPocetkaAdresse, indeksKrajaAdrese);
						int indeksResursa = line.lastIndexOf("/");
						String resurs = line.substring(indeksResursa+1);
						if (adresa.length() == 15) {
							System.out.println("v4:ftp:" + resurs);
						} else if (adresa.length() == 23) {
							System.out.println("v6:ftp:" + resurs);
						} else {
							System.err.println("Nepoznata ip adresa");
						}
					}
				}
			}


		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				in.close();
		}
	}

}

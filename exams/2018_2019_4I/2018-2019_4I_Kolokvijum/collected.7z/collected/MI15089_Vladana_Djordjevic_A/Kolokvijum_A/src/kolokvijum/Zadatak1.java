package kolokvijum;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;


public class Zadatak1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			/*in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while (in.hasNextLine()) {

				String line = in.nextLine();
				if (line.contains("-")) {
					int prvi = line.indexOf("-");
					if (Character.isDigit(line.charAt(prvi-2)) && Character.isDigit(line.charAt(prvi-1))) {
						int dan = Integer.valueOf(line.substring(prvi-2, prvi));
						if (dan >= 01 && dan <= 31) {
							if (Character.isDigit(line.charAt(prvi+1)) && Character.isDigit(line.charAt(prvi+2))) {
								int mesec = Integer.valueOf(line.substring(prvi+1, prvi+3));
								if (mesec >= 1 && mesec <= 12) {
									if (line.substring(prvi+3).equals("-")) {
										if (Character.isDigit(line.charAt(prvi+4)) && Character.isDigit(line.charAt(prvi+5)) && Character.isDigit(line.charAt(prvi+6)) && Character.isDigit(line.charAt(prvi+7))) {
											int godina = Integer.valueOf(line.substring(prvi+4, prvi+8));
											if (godina >= 2000 && godina <= 2018) {
												StringBuilder sb = new StringBuilder(dan + "-" + mesec + "-" + godina);
												out.write(sb.toString());
												out.newLine();
											}
										}
									}
								}
							}
						}
					}
				}
			}*/

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while (in.hasNext()) {
				String word = in.next();
				if (word.matches("(([0-2][0-9])|([3][01]))[-](([0][1-9])|([1][12]))[-]([20][0-9]{2})")) {
					System.out.println(word);
					out.write(word);
					out.newLine();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try{
				if (in != null)
					in.close();
				if (out != null) {
					out.flush();
					out.close();
				}
			} catch (IOException e) {
				System.err.println("Neuspesno zatvaranje resursa!");
			}
		}

	}

}

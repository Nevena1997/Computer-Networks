package kolokvijum;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ThreadsMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String fajl = sc.next();
		sc.close();

		Scanner sc_file = null;

		try {
			sc_file = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fajl))));

			BlockingQueue<Path> queue = new ArrayBlockingQueue<>(1000);

			while (sc_file.hasNextLine()) {
				String putanja = sc_file.nextLine();
				System.out.println(putanja);
				//queue.put(Files.getFileStore(putanja));

				Scanner sc2 = new Scanner(System.in);
				System.out.println("Uneti kljucnu rec za pretragu: ");
				String kljucna_rec = sc2.next();
				System.out.println("Uneti broj n: ");
				int n = sc2.nextInt();
				sc2.close();
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (sc_file != null)
				sc_file.close();
		}

	}

}

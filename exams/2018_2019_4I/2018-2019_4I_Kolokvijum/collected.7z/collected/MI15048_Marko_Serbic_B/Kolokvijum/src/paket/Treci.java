package paket;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Scanner;


public class Treci {

	public static void main(String[] args) {
		Scanner sc = null;
		InputStream a = null;
		try {
			URL u = new URL("file:log.txt");
			a = u.openStream();
			sc = new Scanner(a);

			while (sc.hasNext()) {
				String row = sc.next();
				String[] items = row.split(":");

				// String date = items[0];
				// Date d = new Date() je uporno vracao neki cudan datum
				String path = items[items.length - 2] + ":" + items[items.length - 1];
				String version = null;

				if (items.length > 4) {
					version = "v6";
				} else {
					version = "v4";
				}
				if (path.endsWith("txt")) {
					System.out.println(version + ":" + path);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}

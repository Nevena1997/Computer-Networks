package paket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		String input_file = sc.next();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input_file), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("email.txt"), "UTF-8"));
			while (in.hasNext()) {
				String word = in.next();
				if (isMail(word)) {
					out.write(word);
					out.newLine();
				}
			}
		} catch (UnsupportedEncodingException e) {
			System.out.println("ne valja kodiranje");
			e.printStackTrace();
		} catch(IOException e) {
			System.out.println("ne valja ulaz/izlaz");
			e.printStackTrace();
		} finally {
			if (in != null){
				in.close();
			}
			if (out != null){
				out.close();
			}
		}
	}

	public static boolean isMail(String word) {
		int atFlag = 0;
		for (char a: word.toCharArray()) {
			if (a == '@') {
				atFlag++;
			}
			if (!Character.isDigit(a)
					&& !Character.isAlphabetic(a)
					&& a != '.'
					&& a != '_'
					&& a != '@'
					) {
				return false;
			}
		}

		return atFlag == 1 ? true : false;
	}

}

package TreciZadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Unesite putanju do fajla:");
		Scanner sc = new Scanner(System.in);
		String path = sc.nextLine();
		sc.close();

		InputStreamReader in = new InputStreamReader(new FileInputStream(path));
		Scanner sc1 = new Scanner(in);

		int index = 0;
		while(sc1.hasNextLine()){
			String line = sc1.nextLine();
			if(line.contains("ftp://") ){
				index = line.indexOf('f');
			} else if(line.contains("sftp://")){
				index = line.indexOf('s');
			} else {
				continue;
			}
			String addr = line.substring(index, line.length());
			URL url = null;
			try {
				url = new URL(addr);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

			System.out.println("v" + protocolVersion(line)  + ":" + url.getProtocol() + ":" + path );

		}

		sc1.close();
	}

	private static int protocolVersion(String line){
		int firstIndex = line.indexOf(':');
		int lastIndex = line.lastIndexOf(':');
		firstIndex++; // zbog pocetne dvotacke

		String s = line.substring(firstIndex, lastIndex-1);
		int numElem = 0; // broji sve tacke i dvotacke
		for(int i=0 ; i < s.length(); i++){
			if(s.charAt(i) == ':' || s.charAt(i) == '.')
				numElem++;
		}
		numElem--; // zbog dvotacke na kraju


		// Imamo broj 3 jer je 123.123.123.123 ipv4 adresa koja ima 3 tacke
		if(numElem == 3)
			return 4;
		else if(numElem == 5)
			return 6;
		else
			return -1;

	}

}

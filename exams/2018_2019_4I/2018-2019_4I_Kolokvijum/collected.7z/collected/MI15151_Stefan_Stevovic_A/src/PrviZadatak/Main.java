package PrviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla iz kog citamo podatke:");
		String str = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;
		try {

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(str), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(in.hasNext()){
				String word = in.next();
					if(dateFunction(word)){
						out.write(word);
						out.write(System.setProperty("line.separator", "\r\n"));
					}
			}
			out.flush();



		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			try {
				if(in != null)
					in.close();
				if(out != null)
					out.close();
			} catch (Exception e2) {
				System.out.println("Greska kod zatvaranja fajlova!");
			}
		}

	}

	private static boolean dateFunction(String str){
		// TODO: Nisam imao vremena da odradim sve detaljne provere,
		// koje se odnose na odredivanje da li su brojevi > 0, < 31 itd.

		if(str.length() != 10)
			return false;

		if(str.charAt(2) != '-' || str.charAt(5) != '-')
			return false;

		for(int i = 0 ; i < str.length(); i++){
			if(i != 2 && i != 5){
				if(!Character.isDigit(str.charAt(i)))
					return false;
			}
		}

		return true;
	}

}

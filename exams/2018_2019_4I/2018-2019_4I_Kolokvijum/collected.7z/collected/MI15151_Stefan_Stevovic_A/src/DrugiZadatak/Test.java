package DrugiZadatak;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		try {
			int numOfThread = 5;
			int sizeQueue = 10;

			Scanner sc = new Scanner(System.in);
			System.out.println("Unesite pocetnu putanju do fajla:");
			String startDir = sc.nextLine();
			System.out.println("Unesite ime kljucne reci koju trazite:");
			String keyword = sc.nextLine();
			sc.close();

			SmestaUListu s = new SmestaUListu(startDir, keyword, numOfThread, sizeQueue);
			s.processingFile();

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Greska u metodu main!");
		}

	}

}

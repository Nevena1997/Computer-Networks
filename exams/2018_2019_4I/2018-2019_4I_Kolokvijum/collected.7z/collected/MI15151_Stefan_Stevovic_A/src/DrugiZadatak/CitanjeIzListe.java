package DrugiZadatak;

import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class CitanjeIzListe implements Runnable{
	private BlockingQueue<Path> queue;
	private String keyword;

	public CitanjeIzListe(BlockingQueue<Path> queue, String keyword){
		this.queue = queue;
		this.keyword = keyword;
	}


	@Override
	public void run() {
		boolean finish = false;
		while(!finish){
			try {
				Path p = this.queue.take();
				if(p == SmestaUListu.DUMMY){
					System.out.print(Thread.currentThread().getId() + " is exiting");
					this.queue.put(SmestaUListu.DUMMY);
					finish = true;
					return;
				} else {
					search(p);
				}

				Thread.sleep(100);

			} catch (Exception e) {
				System.out.println("Greska u metodu run!");
			}

		}
	}

	private void search(Path p){
		try {
			Scanner sc = new Scanner(p);
			int numLine = 0;
			while(sc.hasNextLine()){
				numLine++;
				String str = sc.nextLine();
				if(str.contains(keyword)){
					System.out.println("<" + Thread.currentThread().getId() + ">:<" + p + ">:<" + numLine + ">");
				}
			}

			sc.close();
		} catch (Exception e) {
			System.out.println("Greska kod metoda search!");
		}
	}

}

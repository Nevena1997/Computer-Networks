package DrugiZadatak;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class SmestaUListu {

	private int numOfThread;
	private Path startDir;
	private String keyword;

	private BlockingQueue<Path> queue;
	public static Path DUMMY = Paths.get("");

	public SmestaUListu(String startDir, String keyword, int numOfThread, int sizeQueue){
		this.startDir = Paths.get(startDir);
		this.numOfThread = numOfThread;
		this.keyword = keyword;
		this.queue = new ArrayBlockingQueue<>(sizeQueue);
	}

	public void processingFile(){
		for(int i = 0; i < this.numOfThread; i++){
			CitanjeIzListe c = new CitanjeIzListe(this.queue, this.keyword);
			Thread t = new Thread(c);
			t.start();
		}

		try{
			walk(startDir);
			this.queue.add(DUMMY);

		} catch (Exception e) {
			System.out.println("Greska kod processingFile!");
		}
	}

	private void walk(Path startDir){
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(startDir)){
			for(Path d : ds){
				if(Files.isDirectory(d))
					walk(d);
				else
					this.queue.put(d);
			}
		} catch (Exception e) {
			System.out.println("Greska kod metoda wal!");
		}
	}
}

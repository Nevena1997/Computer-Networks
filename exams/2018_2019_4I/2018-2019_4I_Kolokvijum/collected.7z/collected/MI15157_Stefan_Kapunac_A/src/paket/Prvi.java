package paket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {

		Scanner sys = new Scanner(System.in);
		System.out.println("Enter file name: ");
		String inputFile = sys.next();
		sys.close();

		try(Scanner sc = new Scanner(new BufferedInputStream(new FileInputStream(inputFile)), "UTF-8");
			OutputStreamWriter out = new OutputStreamWriter(new BufferedOutputStream(
					new FileOutputStream("timestamps.txt")), "UTF-8");
					) {
			while(sc.hasNext()) {
				String current = sc.next();
				if(isTimestamp(current)) {
					out.write(current + "\r\n");
					out.flush();
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println("Fajl timestamp.txt nije pronadjen.");
			e.printStackTrace();
		} catch(IOException e) {
			System.err.println("IO...");
			e.printStackTrace();
		}

	}

	private static boolean isTimestamp(String s) {

		if(s.length() != 10)
			return false;
		if(!s.chars().allMatch(c -> Character.isDigit(c) || c == '-'))
			return false;
		if(s.charAt(2) != '-' || s.charAt(5) != '-')
			return false;
		int days = Integer.parseInt(s.substring(0, 2));
		if(days < 1 || days > 31)
			return false;
		int months = Integer.parseInt(s.substring(3, 5));
		if(months < 1 || months > 12)
			return false;
		int years = Integer.parseInt(s.substring(6));
		if(years < 2000)
			return false;

		return true;
	}

}

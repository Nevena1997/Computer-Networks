package paket;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Treci {

	public static void main(String[] args) {

		Scanner sys = new Scanner(System.in);

		System.out.println("Enter log file: ");
		String logFile = sys.next();
		sys.close();

		Path p = Paths.get(logFile).toAbsolutePath();
//		System.out.println(p);

		try {
			URL url = new URL("file:///" + p);

			try(Scanner sc = new Scanner(url.openStream())) {
				while(sc.hasNextLine()) {
					String line = sc.nextLine();
					int lastIndex = line.lastIndexOf(':');
					String path = line.substring(lastIndex + 1);
					String beginning = line.substring(0, lastIndex);
	//				System.out.println(path);
					int secondLast = beginning.lastIndexOf(':');
					String protocol = beginning.substring(secondLast + 1);
	//				System.out.println(protocol);
					String firstPart = beginning.substring(0, secondLast);
					String address = firstPart.substring(firstPart.indexOf(':') + 1);
	//				System.out.println(address);

					int version = 4;
					if(address.contains(":"))
						version = 6;

					if(protocol.equals("ftp") || protocol.equals("sftp"))
						System.out.println("v" + version + ":" + protocol + ":" + path);

				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		}



	}

}

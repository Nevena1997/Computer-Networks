package paket;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class LookupThread implements Runnable {

	List<String> filenames;
	String keyword;

	public LookupThread(List<String> filenames, String keyword) {
		this.filenames = filenames;
		this.keyword = keyword;
	}

	@Override
	public void run() {

		System.out.println(Thread.currentThread().getId() + " started");

		while(!filenames.isEmpty()) {
			synchronized (filenames) {
				System.out.println(Thread.currentThread().getId() + " in the loop");
				String file = filenames.remove(filenames.size() - 1);
				lookup(file);
				filenames.notifyAll();
				if(!filenames.isEmpty()) {
					try {
						filenames.wait();
					} catch (InterruptedException e) {
						System.err.println(Thread.currentThread().getId() + " interrupted");
					}
				}
			}
		}
		System.out.println(Thread.currentThread().getId() + " finished");
	}

	private void lookup(String file) {
		try(Scanner sc = new Scanner(new FileInputStream(file))) {
			int line = 0;
			while(sc.hasNextLine()) {
				line++;
				if(sc.nextLine().contains(keyword)) {
					System.out.println(Thread.currentThread().getId() + ":" + file + ":" + line);
				}
			}
		} catch (FileNotFoundException e) {

		}
	}
}

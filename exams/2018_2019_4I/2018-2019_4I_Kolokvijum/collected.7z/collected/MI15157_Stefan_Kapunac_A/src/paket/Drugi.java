package paket;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Drugi {

	public static void main(String[] args) {

		List<String> filenames = Collections.synchronizedList(new ArrayList<>());
		Scanner sys = new Scanner(System.in);
		System.out.println("Enter file: ");
		String inputFile = sys.next();
		try(Scanner sc = new Scanner(new FileInputStream(inputFile))) {
			while(sc.hasNextLine()) {
				String file = sc.nextLine();
				filenames.add(file);
				System.out.println(file);
			}
			System.out.println("Enter keyword: ");
			String keyword = sys.next();
			System.out.println("Enter number of threads: ");
			int n = sys.nextInt();
			sys.close();
			for(int i = 0; i < n; i++) {
				Thread t = new Thread(new LookupThread(filenames, keyword));
				t.start();
			}
		} catch(FileNotFoundException e) {
			sys.close();
		}
	}
}

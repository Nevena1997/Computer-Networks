package i03_parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static List<String> lista = new ArrayList<String>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String s = sc.next();

        Scanner in = null;
        try {
            in = new Scanner(new FileInputStream(s));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while(in.hasNextLine()){
            lista.add(in.nextLine());
        }

       // for (String a : lista) System.out.println(a);

        for (String a: lista) {
            String[] niz = a.split(":");
            String datum = niz[0].trim();
            String IP = niz[1].trim();
            String addr = niz[2].trim().concat(":").concat(niz[3].trim());
            if(a.substring(a.lastIndexOf(".")).equals(".txt")){
                int ip = IP.indexOf(".");
                int v = 0;
                if(IP.length() == 15){
                    v = 4;
                }else if(IP.length() == 19){
                    v=6;
                }else {
                    System.err.println("Pogresna IP adresa");
                }
                System.out.println("v" + ":" + v
                        + addr.substring(0, addr.indexOf(":")) + ":" + addr.substring(addr.lastIndexOf("/")));
            }
        }
    }

}

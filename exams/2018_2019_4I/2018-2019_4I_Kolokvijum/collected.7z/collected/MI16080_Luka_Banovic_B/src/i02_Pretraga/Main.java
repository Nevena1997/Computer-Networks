package i02_Pretraga;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {

    public static List<String> linije = new ArrayList<String>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String file = sc.next();

        try {
            Scanner in = new Scanner(new FileInputStream(file));
            while(in.hasNextLine()){
                linije.add(in.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.err.println("Ne postoji takav fajl.");
        }

        for (String s : linije)
            System.out.println(s);


        String rec = sc.next();
        int n = sc.nextInt();
        char k = sc.next().charAt(0);



        for (int i = 0; i < n; i++) {
            int rand = (int)(Math.random() * linije.size());
            Pretraga p = new Pretraga(linije.get(rand), k);
            System.out.println(Thread.currentThread());
            Nit nit = new Nit(k, p);
            Thread t = new Thread(nit);
            t.start();
            System.out.println(Thread.currentThread() + "  " + p.getBr());
        }



    }
}

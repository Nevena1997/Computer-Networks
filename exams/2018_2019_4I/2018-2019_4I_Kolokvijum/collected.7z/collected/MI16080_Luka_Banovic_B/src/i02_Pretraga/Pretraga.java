package i02_Pretraga;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Pretraga {

    private int br;
    private String s;
    private char k;
    private FileInputStream file;


    public Pretraga(String s, char k) {
        this.br = br;
        this.s = s;
        this.k = k;
    }

    public synchronized void obradi(){
        try {
            file = new FileInputStream(s);
        } catch (FileNotFoundException e) {
            System.err.println("nit neuspelo otvaranje");
        }
        while(true){
        this.br = 0;
        for (int j = 0; j < s.length(); j++) {
            if (s.charAt(j) == 'k') {
                this.br++;
                }
            }
        }
    }

    public int getBr() {
        return br;
    }
}

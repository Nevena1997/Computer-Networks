package i02_Pretraga;

import static i02_Pretraga.Main.linije;

public class Nit implements Runnable {

    private static final int MAX_DELAY = 5;
    private char k;
    private String s;
    private Pretraga p;

    public Nit(char k, Pretraga p) {
        this.k = k;
        this.p = p;
    }



    @Override
    public void run() {

            while(true){
                try{
                    this.p.obradi();
                    Thread.sleep((int)(MAX_DELAY*Math.random()));
            }catch (InterruptedException e){
                 e.printStackTrace();
                }
            }
    }


}

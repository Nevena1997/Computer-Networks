package i01_FileCpy;

import jdk.nashorn.internal.runtime.regexp.RegExp;
import sun.misc.Regexp;

import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String file = sc.nextLine();
        sc.close();

        Scanner in = null;
        BufferedWriter out = null;

        try{
            in = new Scanner(new BufferedInputStream(new FileInputStream(file)), "UTF-8");
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

            while(in.hasNext()){
                String word = in.nextLine();
                String[] word1 = word.split(" ");

                for(int i = 0; i < word1.length; i++)
                {
                    word1[i].trim();
                    if(isEmail(word1[i])) {
                    out.write(word1[i]);
                    out.newLine();
                }
                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("Fajl nije pronadjen");
        } catch (UnsupportedEncodingException e) {
            System.err.println("Pogresno kodiranje");
        } catch (IOException e) {
            System.err.println("Neuspelo citanje fajla");
        }finally {
            try {
                if (in != null)
                    in.close();
                if (out != null) {
                    out.flush();
                    out.close();
                }
            }catch(IOException e){
                System.err.println("Neuspelo zatvaranje strimova");
            }
        }


    }

    private static boolean isEmail(String word) {

       // Regexp reg = new Regexp("([a-zA-Z0-9]+)(@)([a-zA-Z0-9]+)(.)([a-zA-Z0-9]+)");

        return word.matches("([a-zA-Z0-9]+)(@)([a-zA-Z0-9]+)(.)([a-zA-Z0-9]+)");
    }


}

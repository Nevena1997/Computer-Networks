package p3_zadatak3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Input path: ");
		String path = sc.nextLine();

		try {
			URL u = new URL(path);
			URLConnection uc = u.openConnection();

			Scanner in = new Scanner(uc.getInputStream());

			while(in.hasNextLine()) {
				String line = in.nextLine();

		//		System.out.println(line);


				String address = line.substring(line.indexOf(':'), line.lastIndexOf(':'));
		//		InetAddress add = InetAddress.getByName(address);
				String link = line.substring(line.lastIndexOf(':') + 1);

				URL url = new URL(link);
				if(url.getProtocol().toLowerCase().startsWith("ftp") || url.getProtocol().toLowerCase().startsWith("sftp"))
					System.out.println(line);


			}

		in.close();
		sc.close();

		} catch(MalformedURLException e) {
			System.err.println(e);
		} catch(IOException e) {
			System.err.println(e);
		}
	}




}

package p2_zadatak2;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Input filename: ");
		String filename = sc.nextLine();

		sc.close();

		try {

			Scanner f = new Scanner(new FileInputStream(filename));

			LinkedList<String> linesList = new LinkedList<String>();

			int lines = 0;
			while(f.hasNextLine()) {
				String line = f.nextLine();
				linesList.add(line);
				System.out.println(line);
				lines ++;
			}


			BlockingQueue<Path> queue = new ArrayBlockingQueue<>(lines);

			for(int i = 0; i < lines; i++) {
				queue.put(Paths.get(linesList.get(i)));
			}

			f.close();

			System.out.println("Input keyword: ");
			String keyword = sc.nextLine();

			System.out.println("Input thread number: ");
			int n = sc.nextInt();

			for(int i = 0; i < n; i++) {
				Thread t = new Thread(new SearchTask(keyword, queue));
				t.start();
			}


		} catch(FileNotFoundException e) {
			System.err.println(e);
		} catch(InterruptedException e) {
			System.err.println(e);
		}


	}

}

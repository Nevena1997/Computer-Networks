package p2_zadatak2;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class SearchTask implements Runnable {

	private static final Path DONE = Paths.get("");

	private String keyword;
	private BlockingQueue<Path> queue;

	public SearchTask(String keyword, BlockingQueue<Path> queue) {
		this.keyword = keyword;
		this.queue = queue;
	}

	@Override
	public void run() {
		boolean done = false;
		try{
			while(!done) {

				Path p = this.queue.take();

				if(p == DONE) {
					done = true;
					this.queue.put(p);
				}
				else
					search(p);

			}
		} catch(InterruptedException e) {}
	}


	private void search(Path p) {
		try(Scanner sc = new Scanner(p)) {

			for(int i = 1; sc.hasNextLine(); i++) {
				String line = sc.nextLine();
				if(line.contains(keyword))
					System.out.printf("[%d]: %s : %d", Thread.currentThread().getId(), p.toString(), i);
			}

		} catch(IOException e) {
			System.err.println(e);
		}
	}
}

package p1_zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Input file: ");
		String file = sc.nextLine();

		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(in.hasNext()) {
				String word = in.next();

				if(isDate(word)) {
					out.write(word);
					out.newLine();
				}

			}

			System.out.println("done");

		} catch(UnsupportedEncodingException e) {
			System.err.println("Unsupported encoding");
		} catch(FileNotFoundException e) {
			System.err.println("File " + file + " not found");
		} catch(IOException e) {
			System.err.println("Failed to write");
		} finally {
			try {
				if(in != null)
					in.close();
				if(out != null) {
					out.flush();
					out.close();
				}
			} catch(IOException e) {
				System.err.println("Failed to close in or out");
			}
		}

	}

	private static boolean isDate(String word) {
		if(word.length() != 10)
			return false;

		if(word.charAt(2) != '-' || word.charAt(5) != '-')
			return false;

		for(int i = 0; i < word.length(); i++ ) {
			if(i == 2 || i == 5)
				continue;
			else {
				if(!Character.isDigit(word.charAt(i)))
					return false;
			}
		}

		if(word.charAt(0) != '0' && word.charAt(0) != '1' &&  word.charAt(0) !='2' && word.charAt(0) != '3')
			return false;
		if(word.charAt(0) == '0' && word.charAt(1) == '0')
			return false;
		if(word.charAt(0) == '3' && (word.charAt(1) != '0' || word.charAt(1) != '1'))
			return false;

		if(word.charAt(3) != '0' && word.charAt(3) != '1')
			return false;

		if(word.charAt(3) == '1' && (word.charAt(4) != '0' || word.charAt(4) != '1' || word.charAt(4) != '2'))
			return false;

		if(word.charAt(6) != '2')
			return false;

		return true;
	}

}

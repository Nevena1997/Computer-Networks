package treci;

import java.nio.file.Path;
import java.util.concurrent.Callable;

public class Lista implements Callable {

	private String[] lista;
	private Integer count;
	public Lista(){
		count=0;
	}

	public synchronized void dodaj(String s){
		this.lista.append(s);
	}

	@Override
	public Integer call() throws Exception {
		int counter = walk(new Path(lista[0]));

		return count;
	}

	private int walk(Path path) {
		// TODO Auto-generated method stub

		return 0;
	}

}

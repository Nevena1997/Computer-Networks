package treci;

import java.util.concurrent.Callable;

public class CountCharacters implements Callable{
	private Integer count;

	@Override
	public Integer call(){






		return this.count;
	}

}

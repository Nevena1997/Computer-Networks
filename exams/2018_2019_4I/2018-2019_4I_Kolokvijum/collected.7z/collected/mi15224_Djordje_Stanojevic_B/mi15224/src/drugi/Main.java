package drugi;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

public class Main {
	private static final long MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla");
		String ime = sc.next();
		try {
			URL u = new URL("file:\\C:\\Users\\nalog\\Desktop\\mi15224_Djordje_Stanojevic_B\\mi15224\\"+ime);
			URLConnection uc = u.openConnection();
			Scanner s = new Scanner(uc.getInputStream());
			int b;
			while(s.hasNextLine()){
				String line = s.nextLine();
				String[] niz = line.split(":");
				@SuppressWarnings("deprecation")
				Date datum= new Date(niz[0]);

				if(isTxt(niz[niz.length-1])){

					String url = niz[niz.length-2].concat(":"+niz[niz.length-1]);
					URL pom = new URL(url);
					URLConnection ucpom = pom.openConnection();
					ucpom.setIfModifiedSince((new Date(datum.getTime() - MILLISECONDS_PER_DAY)).getTime());
					System.out.println("v"+ipVersion(niz[1])+":"+pom.getProtocol()+":"+pom.getPath());


				}

			}
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sc.close();

	}

	public static int ipVersion(String s){
		String v4m="((0|1)(0-9){2})|(2((0-4)(0-9){2})|(5(0-5)).{3}((0|1)(0-9){2})|(2((0-4)(0-9){2})|(5(0-5))";
		if(s.matches(v4m))
			return 4;
		return 6;
	}
	public static boolean isTxt(String s){
		if(s.length()<5)
			return false;
		if(s.substring(s.length()-4).equals(".txt"))
			return true;
		return false;
	}
}

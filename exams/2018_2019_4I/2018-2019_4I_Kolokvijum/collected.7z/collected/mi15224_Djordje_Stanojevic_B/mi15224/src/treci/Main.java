package treci;

import java.lang.reflect.Array;
import java.util.Scanner;

public class Main {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.println("Unesite n i k:");
		int n =sc.nextInt();
		char k = (char)sc.nextInt();
		Lista lista = new Lista();
		System.out.println("Unesite ime fajla");
		String ime = sc.next();
		Scanner fajl = new Scanner(ime);
		while(fajl.hasNextLine()){
			String imeFajla=fajl.nextLine();
			System.out.println(imeFajla);
			lista.dodaj(imeFajla);
		}


		for(int i=0;i<n;i++){
			CountCharacters = new CountCharacters(list,n,k);
		}




		fajl.close();
		sc.close();
	}

}

package mi15224;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime ulaznog fajla");
		String ime = sc.next();
		sc.close();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(ime),"UTF-8"));
			Scanner s = new Scanner(in);
			OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("emails.txt"),"UTF-8");
			try {

				while(s.hasNext()){
					String mail=s.next();
					if(isEmailAdress(mail))
						out.write(mail);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.err.println("Neuspelo citanje/upisivanje");
				e.printStackTrace();
			}
			finally{
				in.close();
				out.close();
				s.close();
			}
		} catch (IOException e) {
			System.err.println("Neuspelo ucitavanje imena fajla!");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Ovde!");

	}

	public static boolean isEmailAdress(String s){
		String regex = "([a-z]|[0-9])+@([a-z]|[0-9])+.[a-z]+";
		if(s.matches(regex))
			return true;
		return false;
	}



}

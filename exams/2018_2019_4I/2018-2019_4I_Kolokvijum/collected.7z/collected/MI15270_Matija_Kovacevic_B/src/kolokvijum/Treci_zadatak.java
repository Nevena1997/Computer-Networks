package kolokvijum;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Scanner;

import javafx.util.converter.DateStringConverter;

public class Treci_zadatak {
	public static void main(String[] args) {
		BufferedReader br =null;
		Scanner sc = new Scanner(System.in);
		String putanja = sc.nextLine();
		sc.close();
		try{
			File path = new File(putanja);

			URL url = new URL("file:"+path);

			br = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			while((line = br.readLine()) != null){
				int indexDot = line.lastIndexOf('.');
				String ext = line.substring(indexDot+1);

				if(ext.matches("txt")){
					int prvaD = line.indexOf(':');
					int zadD = line.lastIndexOf(':');
					String IPIprot = line.substring(prvaD+1, zadD);
					int predD = IPIprot.lastIndexOf(':');

					String datum = line.substring(0, prvaD);
					datum = datum.substring(1, datum.length()-1);

					String IP = IPIprot.substring(0, predD);
					String adresa = line.substring(datum.length()+2+IP.length()+2);
					int ipD = IP.indexOf(':');
					String v;
					if(ipD == -1){
						v = "4";
					}else{
						v = "6";
					}


					System.out.println("v"+v+":"+url.getProtocol()+":"+url.getPath());


				}

			}
		}catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

package kolokvijum;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;

public class FileSearch implements Runnable{
	ConcurrentLinkedQueue<String> putanje;
	char karakter;
	int brojKaraktera;
	public FileSearch(ConcurrentLinkedQueue<String> putanje, char karakter) {
		this.putanje = putanje;
		this.karakter = karakter;
		this.brojKaraktera = 0;
	}


	@Override
	public void run() {
		while(true){
			String putanja;
			synchronized (putanje) {

				putanja = putanje.remove();
				//pokusano stavljanje try catch bloka za hvatanje exeptiona kad nema elementa na vrhu liste
				if(putanja == null)
					break;
			}
			try {
				FileInputStream fin = new FileInputStream(putanja);
				int b;
				while((b=fin.read()) != -1){
					if((char)b == this.karakter){
						this.brojKaraktera++;
					}
				}
				fin.close();

				System.out.println(Thread.currentThread().toString() + ':' + putanja + ':' + this.brojKaraktera);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}





	}
}

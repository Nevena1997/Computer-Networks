package kolokvijum;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi_zadatak {

	public static boolean testirajString(String zahtev){
		boolean validanString = true;
		char[] nizSlova = zahtev.toCharArray();
		for(int i = 0; i < nizSlova.length; i++){
			if(!Character.isDigit(nizSlova[i]) && !Character.isAlphabetic(nizSlova[i])){
				System.out.println(zahtev);
				validanString= false;
			}

		}
		return validanString;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileName = sc.nextLine();
		sc.close();
		BufferedReader in = null;
		BufferedWriter out = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			String line;
			while((line = in.readLine()) != null){
				int indexAT = line.indexOf('@');
				int indexdot = line.lastIndexOf('.');
				String user = line.substring(0, indexAT);
				String host = line.substring(indexAT+1, indexdot);
				String domen = line.substring(indexdot+1);
				boolean validanMail = true;
				if(testirajString(user)==false || testirajString(host)==false || testirajString(domen)==false){
					validanMail = false;
				}
				if(validanMail){
					out.write(line+"\n");
					out.flush();
				}
			}
			in.close();
			out.close();

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				in.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

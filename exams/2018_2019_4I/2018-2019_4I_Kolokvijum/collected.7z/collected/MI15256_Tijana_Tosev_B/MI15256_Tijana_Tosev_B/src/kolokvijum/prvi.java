package kolokvijum;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class prvi {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite naziv fajla: ");
		String naziv = sc.next();
		sc.close();
		Scanner in;
		BufferedWriter out;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(naziv), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

			while (in.hasNext()) {
				String s = in.next();
				if (isEmail(s)) {
					out.write(s);
					out.newLine();
				}
			}
			in.close();
			out.close();
		} catch (FileNotFoundException ex) {
			System.err.println(ex);
		} catch (IOException e) {
			System.err.println(e);
		}
		// finally {
		// in.close();
		// out.close();
		// }
	}

	private static boolean isEmail(String s) {

		if (!s.contains("@") || s.lastIndexOf(".") == -1)
			return false;

		String untilAt = s.substring(0, s.indexOf('@'));
		if (untilAt.chars().anyMatch(c -> !Character.isDigit(c) && !Character.isAlphabetic(c)))
			return false;
		String afterAt = s.substring(s.indexOf('@') + 1, s.lastIndexOf('.'));
		if (afterAt.chars().anyMatch(c -> !Character.isDigit(c) && !Character.isAlphabetic(c)))
			return false;
		String domen = s.substring(s.lastIndexOf('.') + 1);
		if (domen.chars().anyMatch(c -> !Character.isDigit(c) && !Character.isAlphabetic(c)))
			return false;

		return true;
	}

}

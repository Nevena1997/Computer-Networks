package kolokvijum;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class drugi {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite naziv fajla: ");
		String naziv = sc.next();
		System.out.println("Unesite n: ");
		int n = sc.nextInt();
		System.out.println("Unesite k: ");
		char k = sc.next().charAt(0);
		sc.close();
		try {
			Scanner in = new Scanner(new InputStreamReader(new FileInputStream(naziv)));
			while(in.hasNextLine()) {
				System.out.println(in.nextLine());
			}
			in.close();
		} catch (FileNotFoundException e) {
			System.err.println(e);
		}
		// finally {
		// in.close();
		// }
	}
}

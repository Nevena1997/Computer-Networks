package kolokvijum;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class treci {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite naziv fajla: ");
		String naziv = sc.next();
		sc.close();
		try {
			Scanner in = new Scanner(new InputStreamReader(new FileInputStream(naziv)));
			while (in.hasNextLine()) {
				String line = in.nextLine();

				String datum = line.substring(0, line.indexOf(']', 1) + 1);
				if (!isDate(datum)) {
					break;
				}

				String ipAddress = line.substring(line.indexOf(':')+1);
				if (version(ipAddress) == 4) {
					String link = ipAddress.substring(ipAddress.indexOf(':')+1);
					if (!containsTxt(link)) {
						break;
					}
					URL url = new URL(link);
					String protocol = url.getProtocol();
					String p = url.getPath();
					System.out.println("v4" + ":" + protocol + ":" + p);
				} else if (version(ipAddress) == 6) {
					String link = ipAddress.substring(30);
					if (!containsTxt(link)) {
						break;
					}
					URL url = new URL(link);
					String protocol = url.getProtocol();
					String p = url.getPath();
					System.out.println("v6" + ":" + protocol + ":" + p);
				}
			}
			in.close();
		} catch (MalformedURLException er) {
			System.err.println(er);
		} catch (IOException e) {
			System.err.println(e);
		}
		// finally {
		// in.close();
		// }
	}

	private static int version(String line) {
		if (line.indexOf('.') == 3)
			return 4;

		if (line.substring(0, 29).contains(":"))
			return 6;
		return -1;
	}

	private static boolean isDate(String datum) {
		datum = datum.substring(1, datum.length()-1);
		if (datum.length() < 10)
			return false;
		String dd = datum.substring(0, 2);
		String mm = datum.substring(3, 5);
		String yyyy = datum.substring(6);
		if (!dd.matches("[0-9]{2}"))
			return false;
		if (!mm.matches("[0-9]{2}"))
			return false;
		if (!yyyy.matches("[0-9]{4}"))
			return false;
		return true;
	}

	private static boolean containsTxt(String line) {
		String s = line.substring(line.lastIndexOf('.') + 1);

		if (!s.equals("txt"))
			return false;

		return true;
	}
}

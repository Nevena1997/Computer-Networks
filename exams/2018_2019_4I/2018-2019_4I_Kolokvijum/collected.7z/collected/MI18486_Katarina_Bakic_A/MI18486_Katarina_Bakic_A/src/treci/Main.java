package treci;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws MalformedURLException {
		Scanner sc= new Scanner(System.in);
		String ulaz= sc.next();
		Scanner bin= null;
		InputStreamReader in=null;
		sc.close();
		try {
			bin = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(ulaz))));


			String linija;
			StringBuffer sb =new StringBuffer();
		//	String v= url.getProtocol();

			String protokol;
			int i,prvi,drugi,j=0;
			while(bin.hasNextLine()){
				linija=bin.nextLine();
			//	System.out.println(linija);
				//System.out.println();
				int iUrl= linija.lastIndexOf(":");
				int iUrl2= linija.indexOf(":",iUrl-6);
				int indeks1=linija.indexOf(":", 0);
				int indeks2=linija.indexOf(":", indeks1+1);
				//System.out.println(indeks1+" "+indeks2);
				String pom= linija.substring(indeks2+1, iUrl);
			//	System.out.println(pom);
			//	System.out.println(iUrl+" "+ iUrl2);
				int r=3;

				String urlI=null;
				if(r==3){
					urlI= linija.substring(indeks2+1);
				//	System.out.println("urlI:  "+urlI);
				}
				else{
					urlI= linija.substring(indeks2+2);

				//	System.out.println("urlI:  "+urlI);

				}
				URL url = new URL(urlI);

				int v=4;
				if(!urlI.contains(":")){
					v=6;
				}
				protokol=url.getProtocol();
				if(protokol.equalsIgnoreCase("ftp")|| protokol.equalsIgnoreCase("sftp") ){
					sb.append("v"+v+":");
				//	System.out.println(protokol);
					sb.append(protokol);
					sb.append(":");
					String putanja= url.getPath();
					sb.append(putanja);
					sb.append("\n");
				}

				/*
				 * int c;


				in = new InputStreamReader(url.openStream());
				while((c=in.read())!=-1){
					System.out.println((char)c);
				}
				*/
			}
			System.out.println(sb);


			bin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if(bin!=null){
				bin.close();
			}
			if(in!=null){
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}

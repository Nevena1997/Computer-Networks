package prvi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Scanner bin = null;
		BufferedWriter bout=null;
		String ulaz= sc.next();
		sc.close();
		try {
			bin= new Scanner( new BufferedReader(new InputStreamReader(new FileInputStream(ulaz), "UTF-8")));
			bout= new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			int readB=0;
			String linija;
			while(bin.hasNext()){
				linija=bin.nextLine();
				if(provera(linija)){
					bout.write(linija.toString());
					bout.newLine();
					bout.flush();

					System.out.println(linija);
				}

			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if(bin!=null){
				sc.close();
			}
			if(bout!=null){
				sc.close();
			}
		}

	}

	private static boolean provera(String linija) {
		if(linija.length()<10){
			return false;
		}
		if(!linija.matches("((0[1-9])|([1-2][0-9])|(3[0-1]))[-]((0[0-9])|(1[0-2]))[-][2-9][0-9][0-9][0-9]"))
			return false;
		return true;
	}

}

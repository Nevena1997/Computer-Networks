package zadatak03;

public class SearchRunnable implements Runnable {

	@Override
	public void run() {
		
	}
}



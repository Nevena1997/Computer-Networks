package zadatak03;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("File name: ");
		Scanner sc = new Scanner(System.in);
		String input_file = sc.nextLine();
		sc.close();

		Scanner in = null;
		try {
			URL u = new URL("file:" + input_file);
			URLConnection uc = u.openConnection();
			int length = uc.getContentLength();

			if(length == 0 || uc.getContentType().startsWith("text")){
				throw new IOException("Not a binary file");
			}

			in = new Scanner(new InputStreamReader(uc.getInputStream()));
			while(in.hasNextLine()){
				String line = in.nextLine();
				//System.out.println(line);
				filterLine(line);
			}


			in.close();
		} catch (MalformedURLException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println("IO error");
		} finally {
			in.close();
		}

	}

	private static void filterLine(String line) {
		String url = getURL(line);
		try {
			URL u = new URL(url);
			String protocol = u.getProtocol();

			if(protocol.compareToIgnoreCase("ftp") == 0 || protocol.compareToIgnoreCase("sftp") == 0){
				String ipAddr = getIPAddr(line);
				String ipVersion = "v" + getIpVersion(ipAddr);
				String path = u.getPath();

				System.out.println(ipVersion + ':' + protocol + ':' + path);
			}

		} catch (MalformedURLException e) {
			System.err.println(e.getMessage());
		}

	}

	private static String getIPAddr(String line) {
		String[] splited = line.split(":");
		String ip = splited[1];
		return ip;
	}

	private static int getIpVersion(String ip) {
		try {
			InetAddress addr = InetAddress.getByName(ip);
			int length = addr.getAddress().length;
			if (length == 4)
				return 4;
			if (length == 16)
				return 6;
			return -1;

		} catch (UnknownHostException e) {
			System.err.println("Unknown Host");
		}
		return -1;
	}

	private static String getURL(String line) {
		String[] splited = line.split(":");
		String url = splited[2] + ":" + splited[3];
		return url;
	}

}

package zadatak02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import zadatak03.SearchRunnable;

public class Main {
	public static void main(String[] args) {

		System.out.println("Input file name: ");
		Scanner sc = new Scanner(System.in);
		String input_file = sc.nextLine();

		Scanner reader = null;
		try {
			reader = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input_file), "UTF-8")));

			List<String> lines = new ArrayList<>();

			while(reader.hasNextLine()){
				String line = reader.nextLine();
				lines.add(line);
				System.out.println(line);
			}

			String key = sc.next();
			int n = sc.nextInt();

			for (int i = 0; i < n; i++) {
				Thread t = new Thread(new SearchRunnable());
				t.start();
			}

			reader.close();
		} catch (FileNotFoundException e) {
			System.err.println("File not found: " + input_file);
		} catch (IOException e) {
			System.err.println("IOExeption");
		} finally {
			reader.close();
			sc.close();

		}
 	}
}

package zadatak01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	private static final String OUT_FILE = "timestamps.txt";

	public static void main(String[] args) {

		System.out.println("Input file name: ");
		Scanner sc = new Scanner(System.in);
		String input_file = sc.nextLine();
		sc.close();

		Scanner reader = null;
		try {
			reader = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input_file), "UTF-8")));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter( new FileOutputStream(OUT_FILE), "UTF-8"));

			while(reader.hasNext()){
				String word = reader.next();
				if(isDate(word)) {
					//System.out.println(word);
					out.write(word);
					out.newLine();
				}
			}


			reader.close();
			out.close();
		} catch (FileNotFoundException e) {
			System.err.println("File not found: " + input_file);
		} catch (IOException e) {
			System.err.println("IOExeption");
		} finally {
			reader.close();
		}


	}


	private static boolean isDate(String word) {
		String[] words = word.split("-");
		if (words.length != 3)
			return false;

		int day = 0;
		int month = 0;
		int year = 0;
		try {
			day = Integer.valueOf(words[0]);
			month = Integer.valueOf(words[1]);
			year = Integer.valueOf(words[2]);
		} catch (NumberFormatException e) {
			return false;
		}

		if (day <= 0 || day > 31) return false;
		if (month <= 0 || month > 12 ) return false;
		if (year <= 2000) return false;

		return true;
	}

}

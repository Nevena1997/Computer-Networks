package mi15083_Aleksandra_Jovicic_a;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class zad2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla: ");
		String fajl = sc.nextLine().trim();
		try {
			FileInputStream f;
			f = new FileInputStream(fajl);
			Scanner sc2 = new Scanner(f);
			List<Path> queue = Collections.synchronizedList(new LinkedList<Path>());
			while(sc2.hasNextLine()){
				String k = sc2.nextLine().trim();
				queue.add(Paths.get(k));
			}
			//System.out.println(queue.toString());
			System.out.println("Unesite kljucnu rec: ");
			String key = sc.nextLine().trim();
			System.out.println("Unesite broj niti: ");
			int num = sc.nextInt();
			for(int i = 0; i<num; i++){
				SearchThread st = new SearchThread(queue, key);
				Thread t = new Thread(st);
				t.start();
			}


			sc.close();
			sc2.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}

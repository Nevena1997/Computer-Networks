package mi15083_Aleksandra_Jovicic_a;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class zad1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesi ime fajla: ");
		String name = sc.nextLine().trim();
		try {
			BufferedReader bin = new BufferedReader( new InputStreamReader(new FileInputStream(name), "UTF-8"));
			BufferedWriter bout = new BufferedWriter( new OutputStreamWriter (new FileOutputStream("timestamps.txt"), "UTF-8"));

			/**char[] buf = new char[512];
			int bitesRead = 0;
			while((bitesRead = bin.read(buf))!= -1){
				if()
				bout.write(buf, 0, bitesRead);
			}*/
			Scanner sc2 = new Scanner(bin);
			while(sc2.hasNextLine()){
				String line = sc2.nextLine();
				Scanner sc3 = new Scanner(line);
				while(sc3.hasNext()){
					String word = sc3.next();
					if(word.matches("(([0-2][0-9])|(3[01]))-((0[1-9])|(1[012]))-2[0-9][0-9][0-9]")){
						bout.write(word);
						bout.write("\r\n");
					}
				}
			}
			sc2.close();
			bin.close();
			bout.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		sc.close();

	}

}

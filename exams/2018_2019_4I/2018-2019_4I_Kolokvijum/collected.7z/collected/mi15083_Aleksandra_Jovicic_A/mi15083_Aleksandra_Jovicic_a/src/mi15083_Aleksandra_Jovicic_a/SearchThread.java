package mi15083_Aleksandra_Jovicic_a;

import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class SearchThread implements Runnable {

	private List<Path> queue;
	private String key;

	 public SearchThread(List<Path> q, String k) {
		 this.queue = q;
		 this.key = k;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Path p;
		while(this.queue.size() != 0){
			synchronized (this.queue){
				p = this.queue.remove(0);
				this.queue.notifyAll();
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Scanner sc = new Scanner(p);
				int i = 0;
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					if(line.contains(this.key)){
						System.out.printf("%d:%s:%d\n", Thread.currentThread().getId(), p.toString(), i);
					}
					i++;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		synchronized (this.queue) {
			this.queue.notifyAll();
		}
	}

}

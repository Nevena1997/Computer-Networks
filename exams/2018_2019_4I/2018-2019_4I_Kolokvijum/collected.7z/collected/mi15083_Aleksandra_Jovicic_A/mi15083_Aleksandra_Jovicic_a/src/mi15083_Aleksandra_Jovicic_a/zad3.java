package mi15083_Aleksandra_Jovicic_a;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class zad3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ulaz je file://local/in.txt na primer...
		Scanner sc = new Scanner(System.in);
		String u = sc.nextLine().trim();
		try {
			URL url = new URL(u);
			String fajl = url.getFile();
			FileInputStream fin = new FileInputStream(fajl.substring(1, fajl.length()));
			Scanner sc2 = new Scanner(fin);
			while(sc2.hasNextLine()){
				String line = sc2.nextLine();
				if(line.toLowerCase().contains("ftp") || line.toLowerCase().contains("sftp")){
					String[] data = line.split(":");
					System.out.printf("v%s:%s:%s\n", getVersion(InetAddress.getByName(data[1])), data[2], new URL(data[2]+":"+data[3]).getPath());
				}
			}
			sc2.close();
			fin.close();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		sc.close();

	}
	public static String getVersion(InetAddress a){
		byte[] b = a.getAddress();
		if(b.length == 4)
			return "4";
		if(b.length == 16)
			return "6";
		else
			return "-1";
	}

}

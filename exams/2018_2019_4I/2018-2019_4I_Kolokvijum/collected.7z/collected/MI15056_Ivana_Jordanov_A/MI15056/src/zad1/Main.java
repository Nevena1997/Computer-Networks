package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.channels.FileLockInterruptionException;
import java.nio.file.FileAlreadyExistsException;
import java.util.Scanner;

public class Main {

	public static String vratiAkoJeIspravan(String s){
		//ako prva dva isu manja od 31 vrati ""
		//String dani = s.substring(0, 2);
		//...
		//ako druga dva nizu manja od 12 vrati ""

		//ako je godina manja od 2000 vrati ""


		return s;
	}

	public static void main(String[] args) {
		//ucitaj ime fajl asa standardnog ulaza
		Scanner sc = new Scanner(System.in);
		String nazivFajla = "";
		try{
			nazivFajla = sc.next();
			sc.close();
		} catch(Exception e){
			e.printStackTrace();
		}

		//otvoriti dati fajl
		//napravi fajl timestamps.txt
		try(BufferedReader rd = new BufferedReader(new InputStreamReader(new FileInputStream(nazivFajla), "UTF-8"));
			BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"))){

			//prekopiraj ga u taj fajl
			int c;
			char[] buf1 = new char[1];
			char[] buf9 = new char[9];
			rd.close();
			String datum = "";

			while((c = rd.read(buf1)) != -1){
				if(Character.isDigit(buf1[0])) { //pp niz krece od 1
					datum = datum + (char)(c);

					//iscitaj jos 9 karaktera
					if(rd.read(buf9) != -1) {
						String pom = new String(buf1) + buf9.toString();
						//posalji funkciji na proveru
						String rez = vratiAkoJeIspravan(pom);

						if(!rez.isEmpty()) { //upisi u novi red
							pom = pom + "\n";
							wr.write(pom);
						}
					}
				}
				//ocisti datum
				datum = "";
			}


		} catch(FileNotFoundException e){
			e.printStackTrace();
			System.err.println("fajl nije nadjen");
		} catch(FileAlreadyExistsException e) {
			e.printStackTrace();
			System.err.println("fajl vec postoji");
		} catch(FileLockInterruptionException e){
			e.printStackTrace();
			System.err.println("problem sa katancem");
		} catch(Exception e){
			System.err.println("neobican izuzetak");
			e.printStackTrace();
		}

	}

}

package zad3;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static int verzija(InetAddress x){
		byte[] t = x.getAddress();
		if(t.length == 16)
			return 6;
		else
			return 4;
	}

	public static void main(String[] args) {
		String putanja = args[0];
		URL url;
		try {
			url = new URL("file:" + putanja);
			//URL url = new URL("file:///" + putanja);
			try (InputStreamReader rd = new InputStreamReader(url.openStream());
					Scanner scrd = new Scanner(rd)) {
				//citanje
				while (scrd.hasNextLine()){
					String pom = scrd.nextLine();
					//System.out.println(pom);

					/*pocetak prvog nacina
					//nadjemo drugo pojavljivanje : (dvotacke)
					pom = pom.replaceFirst(":", "");
					String podstring = pom.substring(pom.indexOf(":"), pom.length());
					{
						URL u = new URL(podstring);
						if(u.getProtocol().equals("http") || u.getProtocol().equals("https")){
							System.out.printf("v");
							//System.out.print(verzija(new InetAddress(u)));

						}
					}
					//kraj prvog nacina*/

					//alternativa
					if (pom.contains("http") || pom.contains("https")) {
						System.out.printf("v");

						//System.out.printf(verzija(parcePosleDvotacke));
						System.out.printf("http");
						if(pom.contains("https"))
							System.out.printf("s");
						System.out.println(pom.substring(pom.lastIndexOf('/')));
					}
				}
				scrd.close();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
	}
}

package zad2;

import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class PomRunable implements Runnable {

	private BlockingQueue<Path> red;
	private String kljucnaRec;

	public PomRunable(BlockingQueue<Path> red, String kljucnaRec) {
		this.red = red;
		this.kljucnaRec = " " + kljucnaRec + " "; //!< jer je napomenuto da Anamariju ne prihvata kao mariju
	}

	@Override
	public void run() {
		boolean done = false;
		while(!done){
			try{

				Path p = red.take();

				//ako je pokupila dummy vrati je i zavrsi sa radom
				if(p == Nitii.DUMMY) {
					red.put(p);
					done = true;
				}
				//ako nije trazi rec
				Scanner sc = new Scanner(p);
				int i = 1;
				while(sc.hasNextLine()){
					String linija = sc.nextLine();
					if(linija.contains(kljucnaRec)){
						System.out.println(Thread.currentThread().getId() + ":" + p + ":" +  i);
					}
					i++;
				}
				sc.close();

			} catch(Exception e){
				e.printStackTrace();
			}
		}
	}

}
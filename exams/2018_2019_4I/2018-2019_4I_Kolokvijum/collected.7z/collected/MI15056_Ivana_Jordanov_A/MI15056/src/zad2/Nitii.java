package zad2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Nitii {
	static final int MAX = 200; //pretpostavljamo da sve moze da stane u 200 polja
	public static final Path DUMMY = Paths.get("");

	public static void main(String[] args) {
		String putanja = args[0];
		BlockingQueue<Path> red = new ArrayBlockingQueue<>(MAX);

		try(Scanner sc = new Scanner(new FileInputStream(putanja));) {
			while(sc.hasNextLine()){
				String pom = sc.nextLine();

				//ucitati sve putanje u red
				red.put(Paths.get(pom));

				//ispisati ih na standardni izlaz
				System.out.println(pom);
			}
			//ubaci dummy
			red.put(DUMMY);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(InterruptedException e){
			e.printStackTrace();
		}

		//ucitavanje kljucne reci i broja n
		String kljucnaRec = "";
		int n = 0;
		try{
			Scanner scc = new Scanner(System.in);
			kljucnaRec = scc.next();
			n = scc.nextInt();
			scc.close();
		} catch(Exception e){
			e.printStackTrace();
		}

		//pokretanje n niti
		for(int i = 0; i < n; i++){
			new Thread(new PomRunable(red, kljucnaRec)).start();
		}
	}
}



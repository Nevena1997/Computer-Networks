package kolokvijum_prvi_zadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class TransferReader {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next().trim();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));

			while(in.hasNext())
			{
				String word = in.next();
				if(word.matches("[0-9]{2}-[0-9]{2}-[0-9]{4}")) {
					String[] nums = word.split("-");
					int dd = new Integer(nums[0]).intValue();
					int mm = new Integer(nums[1]).intValue();
					int	yyyy = new Integer(nums[2]).intValue();

					if(dd > 0 && dd <= 31 && mm > 0 && mm <= 12 && yyyy > 2000) {
						out.write(String.format("%d-%d-%d", dd, mm, yyyy));
						out.newLine();
					}
				}
			}

		} catch (FileNotFoundException e) {
			System.err.println(fileName + " doesn't exist...");
		} catch (IOException e) {
			System.err.println("IO error...");
		} finally {
			if(null != in) {
				in.close();
			}

			if(null != out) {
				try {
					out.close();
				} catch (IOException e) {
					System.err.println("Closing out failed...");
				}
			}
		}
	}

}

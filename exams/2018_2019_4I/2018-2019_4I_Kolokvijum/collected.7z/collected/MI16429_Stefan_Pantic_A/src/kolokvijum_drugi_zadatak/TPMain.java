package kolokvijum_drugi_zadatak;

import java.util.Scanner;

	public class TPMain {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			String file = sc.next();

			ThreadPool tp = new ThreadPool(file);

			int tds = sc.nextInt();
			String key = sc.next();
			sc.close();

			tp.run(tds, key);
		}
}

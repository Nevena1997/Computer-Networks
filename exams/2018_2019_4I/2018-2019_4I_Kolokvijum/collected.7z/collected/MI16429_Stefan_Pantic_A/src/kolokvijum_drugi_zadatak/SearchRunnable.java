package kolokvijum_drugi_zadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

public class SearchRunnable implements Runnable {

	private List<String> list;
	private String key;

	public SearchRunnable(List<String> list, String key) {
		this.list = list;
		this.key = key;
	}

	@Override
	public void run() {
		while (true) {
			String fpath;
			synchronized (this.list) {
				if(this.list.size() == 0) {
					return;
				}

				fpath = this.list.get(0);
				this.list.remove(0);
			}

			Scanner sc = null;
			try {
				sc = new Scanner(new InputStreamReader(new FileInputStream(fpath)));
			} catch (FileNotFoundException e) {
				continue;
			}

			int line = 1;
			while(sc.hasNext()) {
				String lajna = sc.nextLine();
				if(lajna.contains(this.key)) {
					System.out.println(Thread.currentThread() + ":" + fpath + ":" + line);
				}

				line += 1;
			}

			sc.close();

		}
	}

}

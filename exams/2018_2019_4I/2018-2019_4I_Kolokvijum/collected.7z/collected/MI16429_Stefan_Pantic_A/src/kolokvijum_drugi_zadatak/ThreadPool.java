package kolokvijum_drugi_zadatak;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class ThreadPool {
	private List<String> list = Collections.synchronizedList(new LinkedList<String>());

	public ThreadPool(String path) {
		try {
			Scanner sc = new Scanner(new InputStreamReader(new FileInputStream(path)));
			while(sc.hasNext()) {
				list.add(sc.nextLine().trim());
			}

			sc.close();
		} catch (FileNotFoundException e) {
			System.err.println("File not found...");
			System.exit(1);
		}
	}

	public void run(int n, String key) {
		for(int i = 0; i < n; ++i) {
			new Thread(new SearchRunnable(list, key)).start();
		}
	}
}

package kolokvijum_treci_zadatak;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class LogReader {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String logPath = sc.next();
		sc.close();

		Path p = Paths.get(logPath);

		// 123.123.123.123
		// http://poincare.matf.bg.ac.rs/~ivan_ristovic/secret.txt

		String urlPath = "";

		try {
			URL url = new URL(p.toUri().toString());
			URLConnection uc = url.openConnection();
			URLConnection uc2 = url.openConnection();
			Scanner in = new Scanner(new InputStreamReader(uc.getInputStream()));
			Scanner in2 = new Scanner(new InputStreamReader(uc2.getInputStream()));
			while(in2.hasNext()) {
				System.out.println(in2.nextLine());
			}

			in2.close();


			while(in.hasNext()) {
				String lajna = in.nextLine();
				int split = lajna.lastIndexOf(":");
				String uptmp = lajna.subSequence(0, split).toString();
				urlPath = uptmp.substring(uptmp.lastIndexOf(":") + 1) + lajna.substring(lajna.lastIndexOf(":"));
				String ip = lajna.substring(lajna.indexOf(":") + 1);
				ip = ip.split(":")[0];

				URL localUrl = new URL(urlPath);
				int ipv = ip.chars().allMatch(c -> Character.isAlphabetic(c) || Character.isDigit(c) && c != '.') ? 6 : 4;

//				String resourcePath = urlPath.substring(urlPath.indexOf("/"));

				if(localUrl.getProtocol().equals("http") || localUrl.getProtocol().equals("https")) {
					System.out.printf("v%d:%s:%s\n", ipv, localUrl.getProtocol(), localUrl.getPath());
				}

			}

			in.close();

//			URL url2 = new URL("http://poincare.matf.bg.ac.rs/~ivan_ristovic/secret.txt");
//
//			System.out.println(url2.getProtocol());

		} catch (MalformedURLException e) {
			System.err.println("Invalid URL: " + urlPath);
		} catch (IOException e) {
			System.err.println("Failed to open URL connection...");
		}
	}

}

package PrviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try{
		in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));

		while(in.hasNext()){
			String word = in.next();
			if(isValid(word)){
				out.write(word);
				out.newLine();
			}
		}


		}catch(FileNotFoundException e){
			System.err.print(e + "not found");
		}catch(IOException e){
			e.printStackTrace();
		}

		finally{
			try{
				if(in != null)
					in.close();
				if(out != null){
					out.flush();
					out.close();
				}

			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}

	private static boolean isValid(String word) {

		if(word.indexOf('.') == -1)
			return false;
		if(word.indexOf('@') == -1)
			return false;



		for(int i=0;i< word.indexOf('@');i++){
			if(!Character.isAlphabetic(word.charAt(i)) && !Character.isDigit(word.charAt(i))){
				return false;
			}
		}

		for(int i=word.indexOf('.')+1;i<word.length();i++){
			if(!Character.isLowerCase(word.charAt(i)))
				return false;
		}
		return true;
	}

}

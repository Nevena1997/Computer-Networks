package test;

import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		LinkedList<String> lista =new LinkedList<String>();

		lista.add("blka");
		lista.add("fdsafdsag");
		lista.removeFirst();
		lista.removeFirst();
		System.out.println(lista.isEmpty());
	}

}

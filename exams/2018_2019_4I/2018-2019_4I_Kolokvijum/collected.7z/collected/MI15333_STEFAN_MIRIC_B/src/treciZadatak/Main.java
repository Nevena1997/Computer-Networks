package treciZadatak;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws MalformedURLException{
		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		sc.close();
		File fajl = new File(file);

		URL baseUrl = new URL("file:///" +fajl.getAbsolutePath());
		try{
			URLConnection uc = baseUrl.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream()));
			String str;
			while((str=in.readLine())!=null){
				if(str.substring(str.lastIndexOf('.')+1).equals("txt")){
					System.out.println(str);
					InetAddress inet;
					//uzimam inet adresu pa proveravam verziju ip adrese, protokol sa getProtokol kad izdvojim
					//substring url-a
				}





			}

		}catch(IOException e){
			e.printStackTrace();
		}
	}

}

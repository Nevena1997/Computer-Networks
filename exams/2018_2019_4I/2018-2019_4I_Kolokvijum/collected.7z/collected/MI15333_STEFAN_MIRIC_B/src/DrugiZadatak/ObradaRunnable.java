package DrugiZadatak;

import java.io.FileNotFoundException;
import java.util.LinkedList;

public class ObradaRunnable implements Runnable{
	private char k;
	private LinkedList<String> lista;

	public ObradaRunnable(int k,LinkedList<String> lista) {
		this.k=(char)k;
		this.lista=lista;
	}



	@Override
	public void run() {
		try{
			while(!this.lista.isEmpty()){
				Fajl file =new Fajl(lista,k);
				file.proveri();
			}
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}

			}

	}





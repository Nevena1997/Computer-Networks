package DrugiZadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		Scanner in=null;
		LinkedList<String> lista =new LinkedList<String>();

		try{
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			while(in.hasNext()){
				String path=in.nextLine();
				lista.add(path);
				System.out.println(path);
			}
		}catch(IOException e){
			e.printStackTrace();
		}

		finally{
				if(in != null)
					in.close();
		}

		int n = sc.nextInt();
		String u= sc.next();
		char k=u.charAt(0);

		sc.close();


		for(int i =0; i<n; i++){
			ObradaRunnable or= new ObradaRunnable(k,lista);
			Thread t = new Thread(or);
			t.start();
		}


	}

}

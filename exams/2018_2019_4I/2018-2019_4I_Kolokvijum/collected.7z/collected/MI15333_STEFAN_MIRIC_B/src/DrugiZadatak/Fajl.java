package DrugiZadatak;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

public class Fajl {
	private LinkedList<String> lista;
	char k;
	private String ime;

	public Fajl(LinkedList<String> lista,char k) {
		this.lista=lista;
		this.k=k;
		this.ime=lista.getFirst();
	}


	public synchronized void proveri() throws FileNotFoundException {
		Scanner in = new Scanner(new File(this.lista.getFirst()));
		lista.removeFirst();
		int c=0;
		while(in.hasNext()){
			String rec = in.next();
			for(int i=0;i<rec.length();i++){
				if(this.k==rec.charAt(i))
					c+=1;
			}
		}

		System.out.println(Thread.currentThread().getId() + ":" + this.ime + ":" + c);

		in.close();
	}



}

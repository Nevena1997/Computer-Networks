package zad_03;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class LogParser {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BufferedReader inFull = null;
		BufferedReader inFiltered = null;
		BufferedReader inChanged = null;

		try {
			String path = sc.next();
//			path = "input3.txt";

//			String path = "input3.txt";
			File f = new File(path);

			URL file = new URL("file:\\"+f.getAbsolutePath());
			inFull = new BufferedReader(new InputStreamReader(file.openStream()));
			inFiltered = new BufferedReader(new InputStreamReader(file.openStream()));
			inChanged = new BufferedReader(new InputStreamReader(file.openStream()));

			// Mogao sam lepo da napravim listu stringova, ali radio sam u hodu
			// tacku po tacku, kako sam citao,
			// pa da ne gubim vreme (posto ga nemam) sada na menjanje onoga sto radi...

			String c;
			System.out.println("Full content of the file:");
			while ((c = inFull.readLine()) != null){
				System.out.println(c);
			}

			System.out.println("Filtered content of the file:");
			while ((c = inFiltered.readLine()) != null){
				if (txtExt(c)) {
					System.out.println(c);
				}
			}

			System.out.println("Formatted content of the file:");
			while ((c = inChanged.readLine()) != null){
				if (txtExt(c)) {
					System.out.println(formatLine(c));
//					System.out.println(c);
				}
//				System.out.println();
			}

//			System.out.println(file.getProtocol());

//			sc.close();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			sc.close();
			try {
				inFull.close();
				inFiltered.close();
				inChanged.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private static String formatLine(String c) {
		StringBuffer result = new StringBuffer("v");
		try {
			int firstTwoDots = c.indexOf(':');
			int secondTwoDots = c.indexOf(':', firstTwoDots + 1);
			int thirdTwoDots = c.indexOf(':', secondTwoDots + 1);
			String ip = c.substring(firstTwoDots + 1, secondTwoDots);
			String protocol = c.substring(secondTwoDots + 1, thirdTwoDots);
			InetAddress addr = InetAddress.getByName(ip);
			if (addr.getAddress().length == 4){
				result.append("4:");
			} else if(addr.getAddress().length == 16) {
				result.append("6:");
			}
			result.append(protocol + ":");
			result.append("WANNABE_PATH");

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	private static boolean txtExt(String c) {
//		int lastPosSlash = c.lastIndexOf('/');
		int lastPosDot = c.lastIndexOf('.');

//		String fileName = c.substring(lastPosSlash + 1, lastPosDot);
		String ext = c.substring(lastPosDot);

		if (ext.equals(".txt"))
			return true;

		return false;
	}
}

package zad_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ArrayBlockingQueue;

public class SearchTask implements Runnable {

	ArrayBlockingQueue<String> files;
	char k;

	public SearchTask(ArrayBlockingQueue<String> files, char k) {
		this.k = k;
		this.files = files;
	}

	@Override
	public void run() {
		try {
			while(!files.isEmpty()) {
				int count = 0;
				String file = files.take();

				InputStreamReader ir = null;
				try {
					ir = new InputStreamReader(new FileInputStream(file));
				}
				catch (FileNotFoundException e) {
					// do nothing, continue with processing files
				}
				int c;
				if (ir != null){
					while((c = ir.read()) != -1){
						if ((char) c == k) {
							count++;
						}
					}
					File f = new File(file);

					System.out.println(Thread.currentThread() + ":" + f.getAbsolutePath() + ":" + count);
				}
				Thread.sleep(10);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

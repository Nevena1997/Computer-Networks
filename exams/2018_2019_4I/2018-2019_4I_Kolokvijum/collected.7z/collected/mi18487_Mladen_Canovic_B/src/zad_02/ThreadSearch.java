package zad_02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;

public class ThreadSearch {

	public static void main(String[] args) {
		try {
			String fileName = "input2.txt";
			ArrayList<String> paths = new ArrayList<>();
			Scanner sc = new Scanner(System.in);
			System.out.print("Name of the source file: ");
			fileName = sc.next();

			int numThreads;
			char k;
			System.out.print("Number of threads: ");
			numThreads = sc.nextInt();
			System.out.print("Charachter to search for: ");
			k = sc.next().charAt(0);
//			System.out.println(fileName + " " + numThreads + " " + k);
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName), "UTF-8"));

			String path;
			while((path = br.readLine()) != null){
				paths.add(path);
			}

			ArrayBlockingQueue<String> files = new ArrayBlockingQueue<>(paths.size());
			files.addAll(paths);

			for (int i = 0; i < numThreads; i++) {
				SearchTask s = new SearchTask(files, k);
				Thread t = new Thread(s);
				t.start();
			}

//			System.out.println(files);
//			System.out.println(paths);

			br.close();

			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

package zad_01;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class CopyFile {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();

		BufferedReader br = null;
		BufferedWriter bw = null;

		try {
			br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName), "UTF-8"));

			bw = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream("emails.txt"), "UTF-8"));
//			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fileName));
//			BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("emails.txt"));
//			BufferedReader br = new BufferedReader(new FileReader(fileName));
//			BufferedWriter bw = new BufferedWriter(new FileWriter("emails.txt"));

//			InputStreamReader ir = new InputStreamReader(new FileInputStream(fileName), "UTF-8");
//			OutputStreamWriter ow = new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8");


//			int readBytes = 0;
//			char[] buf = new char[512];


			String line;
			while((line = br.readLine()) != null){
				Scanner sl = new Scanner(line);
				while (sl.hasNext()){
					String word = sl.next();
					if (isEmail(word)) {
						bw.write(word + "\n");
					}
				}
				sl.close();
			}

			System.out.println("Done!");
//			ir.close();
//			ow.close();
//
//			br.close();
//			bw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sc.close();
			try {
				br.close();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private static boolean isEmail(String e) {
		int atPos = e.indexOf('@');
		if (atPos == -1) {
			return false;
		}

		String preAt = e.substring(0, atPos);
		String postAt = e.substring(atPos + 1);
//		System.out.println(preAt);
//		System.out.println(postAt);
		for (int i = 0; i < preAt.length(); i++) {
//			System.out.println(preAt.charAt(i));
			if (!((preAt.charAt(i) >= 'a' && preAt.charAt(i) <= 'z') ||
					(preAt.charAt(i) >= 'A' && preAt.charAt(i) <= 'Z') ||
					(preAt.charAt(i) >= '0' && preAt.charAt(i) <= '9') ||
					preAt.charAt(i) == '_' ||
					preAt.charAt(i) == '.')){
				return false;
			}
		}

		for (int i = 0; i < postAt.length(); i++) {
//			System.out.println(postAt.charAt(i));
			if (!((postAt.charAt(i) >= 'a' && postAt.charAt(i) <= 'z') ||
					(postAt.charAt(i) >= 'A' && postAt.charAt(i) <= 'Z') ||
					(postAt.charAt(i) >= '0' && postAt.charAt(i) <= '9') || postAt.charAt(i) == '_' ||
					postAt.charAt(i) == '.')){
				return false;
			}
		}
//		System.out.println(preAt + " " + postAt);
		return true;
	}
}

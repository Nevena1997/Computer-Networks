package p01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		try {
			Scanner sc = new Scanner(System.in);
			String filename = sc.next();
			sc.close();

			BufferedReader in = null;
			try {
				in = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			} catch (FileNotFoundException e) {
				System.err.println("Fajl " + filename + " nije pronadjen");
				return;
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				System.err.println("Endocing");
				return;
			}

			BufferedWriter out = null;
			try {
				out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
			} catch (UnsupportedEncodingException | FileNotFoundException e) {
				System.err.println("Fajl timestamps.txt nije pronadjen");
				try {
					in.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}

			Scanner sc1 = null;
			try {
				sc1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.err.println("Fajl " + filename + " nije pronadjen");
				try {
					out.close();
					in.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.err.println("Nije moguce zatvaranje strimova");
				}
				return;
			} catch (UnsupportedEncodingException e) {
				System.err.println("Ecnoding");
				try {
					out.close();
					in.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.err.println("Nije moguce zatvaranje strimova");
				}
				return;
			}

			try {
				while(sc1.hasNext()) {
					String line = sc1.next();
					if(isCorrect(line))
						out.write(line + "\n");
				}
			} catch (IOException e) {
				System.err.println("Pisanje nije moguce");
				try {
					out.close();
					in.close();
					sc1.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.err.println("Nije moguce zatvaranje strimova");
				}
				return;
			}

			sc1.close();

			try {
				out.close();
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.err.println("Nije moguce zatvaranje strimova");
			}
//		}
//
	}

	private static boolean isCorrect(String line) {
		if(line.trim().indexOf('-') == -1)
			return false;

		if(!Character.isDigit(line.charAt(0)) || !Character.isDigit(line.charAt(1)) || line.charAt(2) != '-'
				|| !Character.isDigit(line.charAt(3)) || !Character.isDigit(line.charAt(4)) || line.charAt(5) != '-'
				|| !Character.isDigit(line.charAt(6)) || !Character.isDigit(line.charAt(7)) || !Character.isDigit(line.charAt(8)) || !Character.isDigit(line.charAt(9)))
			return false;

		int day = Integer.parseInt(line.substring(0, 2));
		if(day > 31 || day < 1)
			return false;
//		System.out.println(day);

		int month = Integer.parseInt(line.substring(3, 5));
		if(month > 12 || month < 1)
			return false;
//		System.out.println(month);

		int year = Integer.parseInt(line.substring(6, 10));
		if(year < 2000)
			return false;
//		System.out.println(year);

		return true;
	}

}

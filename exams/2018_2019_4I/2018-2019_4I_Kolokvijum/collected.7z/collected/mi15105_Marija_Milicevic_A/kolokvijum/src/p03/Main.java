package p03;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.next();

		try {
			URL u = new URL("file:C:\\Users\\nalog\\workspace\\kolokvijum\\" + file);
			Scanner sc1 = new Scanner(u.openStream());

			while(sc1.hasNextLine()) {
				String line = sc1.nextLine();

				/* filtrira tako da ostanu samo oni resursi koji su stigli preko ftp ili sftp protokola */
				if(!line.contains("ftp") && !line.contains("sftp"))
					continue;

//				String date = line.substring(line.indexOf('['), line.indexOf(']') + 1);

				String ip_address = line.substring(line.indexOf(':') + 1, line.indexOf("ftp"));
				ip_address = ip_address.substring(0, ip_address.lastIndexOf(":"));
//				System.out.println(ip_address);

				String resoursePath = line.substring(line.lastIndexOf(ip_address) + ip_address.length() + 1);

				System.out.println("v" + ipVersion(ip_address) + ":" + resoursePath);
			}
//
			sc1.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			sc.close();

		}

	}

	private static String ipVersion(String ip_address) {
		if(ip_address.indexOf(':') != -1)
			return "6";
		return "4";
	}
}

package p02;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String dir = sc.next();
		String keyword = sc.next();
		int n = sc.nextInt();

		Path queue = Paths.get(dir);
		for(Path p : queue)
			System.out.println(p);

//		System.out.println(dir);
//		System.out.println(keyword);
		for(Path p : queue) {
			for(int i = 0; i < n; i++) {
				FileTreeWalker ftw = new FileTreeWalker(p, keyword);
				new Thread(ftw).start();
			}
		}

		sc.close();
	}

}

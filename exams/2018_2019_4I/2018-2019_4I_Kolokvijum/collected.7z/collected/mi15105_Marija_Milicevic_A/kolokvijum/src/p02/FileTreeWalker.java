package p02;

import java.nio.file.Path;

public class FileTreeWalker implements Runnable {

	Path path;
	String keyword;

	public FileTreeWalker(Path p, String k) {
		this.path = p;
		this.keyword = k;
	}

	public synchronized void walk()
	{
		while(true) {

		}

	}

	@Override
	public void run() {
		try {
			this.wait();

			this.walk();

			this.notifyAll();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}

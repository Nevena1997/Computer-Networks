package zadatak3;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class URL_file_protocol {

	//funkcija koja proverava da li je u liniji u log fajlu trazeni protokol
	private static boolean isRegularProtocol(String line) throws MalformedURLException{
		//odsecemo datum
		String line1 = line.substring(line.indexOf(":") + 1);
		//dodjemo do pocetka url-a
		String url_string = line1.substring(line1.indexOf(":") + 1);
		URL url;
			url = new URL(url_string);
		if(!url.getProtocol().equals("ftp") || !url.getProtocol().equals("sftp"))
			return false;
		else
			return true;

	}

	public static void main(String[] args) {
		try {
			URL url = new URL("file:///C:/Users/nalog/Desktop/mi16401_Tamara_Garibovic_A/log.txt");
			//System.out.print(url.getProtocol());
			//ako je u pitanju regularni fajl ispisi ga na stdout
			if (url.getProtocol().equals("file")){
			URLConnection uc = url.openConnection();
			Scanner in = new Scanner(new InputStreamReader(uc.getInputStream()));
			while(in.hasNext()){
				String line=in.nextLine();
				//if(isRegularProtocol(line)){ - zakomentarisano je jer iz nekog razloga izbacuje izuzetak kad se proverava
					System.out.println(line);
				//}
			}
			in.close();
			}
		} catch (IOException e) {
			System.err.println("Url failed!");
			e.printStackTrace();
		}

	}

}

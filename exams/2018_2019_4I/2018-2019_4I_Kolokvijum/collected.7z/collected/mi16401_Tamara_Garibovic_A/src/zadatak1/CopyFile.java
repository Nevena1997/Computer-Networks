package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class CopyFile {

	public static boolean isRegularDate(String date){
		return date.matches("(0[1-9]|1[0-9]|2[0-9]|3[012])-(0[1-9]|1[012])-2[0-9]{3}");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla iz kog ce se kopirati podaci:");
		String file = sc.next();
		sc.close();

		try {
			Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8")));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamp.txt"), "UTF-8"));

			while(in.hasNext()){
				String rec = in.next();
				if(isRegularDate(rec)){
				out.write(rec + "\r\n");
				}
			}

			in.close();
			out.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.err.println("File not found!\n");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Closing stream error!\n");
			e.printStackTrace();
		}

	}

}

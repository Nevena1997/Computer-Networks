package zadatak2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class BlockingQueue {
public static void main(String[] args) {
	try {
	Scanner sc = new Scanner(System.in);
	System.out.println("Unesite tekstualni fajl u kome se nalaze putanje:");
	String putanje_fajl = sc.next();
	sc.close();

	//citamo putanje iz fajla i upisujemo u listu
	Scanner sc1;
	sc1 = new Scanner(new FileInputStream(putanje_fajl));
	ArrayList<String> putanje = new ArrayList<>();
	while(sc1.hasNext()){
		putanje.add(sc1.next());
		}
	sc1.close();

	//sadrzaj liste ispisujemo na stdout
	for(int i = 0;i < putanje.size(); i++)
		System.out.println(putanje.get(i));

	java.util.concurrent.BlockingQueue<String> putanje_obrada = null;

	for(int i = 0;i < putanje.size(); i++)
		putanje_obrada.add(putanje.get(i));

	Scanner sc2 = new Scanner(System.in);
	System.out.println("Unesite kljucnu rec za pretragu:");
	String kljucna_rec = sc2.next();
	System.out.println("Unesite broj niti za obradu n:");
	int n = sc2.nextInt();
	sc2.close();

	for(int i = 0; i < n; i++){
		Thread td = new Thread(new Search(putanje_obrada,kljucna_rec));
		td.start();
	}

	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}

}
}

package zadatak2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Search implements Runnable {

	private  BlockingQueue<String> putanje;
	private  String kljucna_rec;

	public Search(java.util.concurrent.BlockingQueue<String> putanje_obrada, String kljucna_rec) {
		this.putanje = putanje_obrada;
		this.kljucna_rec = kljucna_rec;
	}


	@Override
	public void run() {
		try {
			if (this.putanje.size() < 0)
				this.wait();

			String fajl = this.putanje.element();
			Scanner sc = new Scanner(new InputStreamReader(new FileInputStream(fajl)));
			while(sc.hasNext()){
				String word = sc.next();
				if(word.equalsIgnoreCase(this.kljucna_rec)){
					System.out.println(Thread.currentThread().getId() + ":" + fajl);
				}
			}
			sc.close();


			this.notifyAll();
		} catch (InterruptedException | FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}

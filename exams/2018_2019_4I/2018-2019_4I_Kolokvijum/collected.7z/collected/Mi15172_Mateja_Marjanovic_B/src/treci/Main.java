package treci;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String filePath = sc.next();
		try {
			URL url = new URL("FILE", "", filePath);
			URLConnection uc = url.openConnection();
			Scanner in = new Scanner(uc.getInputStream());

			while(in.hasNextLine()) {
				String line = in.nextLine();
				if(line.matches(".+?[.]txt")) {
//					System.out.println(line);
//					deo pod 2


//					deo pod 3
					int version = line.split(":")[0].split(".").length;
					System.out.println("v" + version + ":" + line.split(":")[2] + ":");
				}
			}

			in.close();

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sc.close();
	}
}

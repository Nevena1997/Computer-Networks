package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();

		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(
					new InputStreamReader(new FileInputStream(fileName), "UTF-8")));
			out = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));
			while(in.hasNext()) {
					String word = in.next();
					if(word.matches("[a-zA-Z][a-zA-Z_.0-9-]+[@][a-zA-Z][a-zA-Z_-]+([.][a-z]+)+")) {
						out.write(word + " ");
					}
			}
		} catch (FileNotFoundException e) {
			System.err.println("Fajl ne postoji");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Problem sa citanjem fajla");
			e.printStackTrace();
		} finally {
			if(in != null) {
				in.close();
			}

			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		sc.close();
	}
}

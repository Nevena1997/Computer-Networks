package drugi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Scanner scFile = null;
		try {
			LinkedList<Path> list = new LinkedList<Path>();
			scFile = new Scanner(new FileInputStream(sc.next()));
			while(scFile.hasNextLine()) {
				String filePath = scFile.nextLine();
				System.out.println(filePath);
				list.add(new File(filePath).toPath());
			}

			int n = sc.nextInt();
			char k = sc.next().charAt(0);

			for(int i = 0; i < n; ++i) {
				new Thread(new SearchRunnable(list, k)).start();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(scFile != null) {
				scFile.close();
			}
		}

		sc.close();
	}
}

package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class SearchRunnable implements Runnable {
	private LinkedList<Path> list;
	private int k;

	private Lock lock;

	public SearchRunnable(LinkedList<Path> list, int k) {
		this.list = list;
		this.k = k;

		this.lock = new ReentrantLock();
	}

	@Override
	public void run() {
		while(true) {
			Path p = null;

			lock.lock();
			if(!this.list.isEmpty()) {
				p = this.list.removeFirst();
			} else {
				break;
			}
			lock.unlock();
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			int br = search(p);
			System.out.println(Thread.currentThread().getId() + ":" + p.toAbsolutePath().toString() + ":" + br);
		}
	}

	private int search(Path p) {
		int br = 0;
		Scanner sc = null;
		try {
			sc = new Scanner(new FileInputStream(p.toString()));
			while(sc.hasNext()) {
				String word = sc.next();
				for(char c : word.toCharArray()) {
					if(c == k) {
						br++;
					}
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		if(sc != null) {
			sc.close();
		}
		return br;
	}
}
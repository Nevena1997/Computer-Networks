package zadatak_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner n = new Scanner(System.in);
		String file_name = n.next();
		n.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in  = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file_name),"UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"),"UTF-8"));

			while(in.next() != null){
				if(testNum(in.next())){
					out.write(in.next());
					out.newLine();
				}
			}

			System.out.print("Done");


		} catch (IOException e) {
			in.close();
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			System.out.print("failed to write");
			e.printStackTrace();
		}finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static boolean testNum(String next) {
//		if(!next.matches("[0-9]{2}-[0-9]{2}-[0-9]{4}")){
//			return false;
//		}
		if (next.charAt(2) != '-')
			return false;
		if (next.charAt(5) != '-')
			return false;
		String day = next.substring(0, 1);
		if(testDay(day)){
			return false;
		}
		String month = next.substring(3,4);
		if(testMonth(month)){
			return false;
		}
		String year = next.substring(6,9);
		if(testYear(year)){
			return false;
		}

		return true;
	}



	private static boolean testYear(String year) {
		if(year.charAt(0)<2){
			return true;
		}
		return false;
	}

	private static boolean testMonth(String month) {
		if (month.charAt(0) > 1){
			return true;
		}
		if (month.charAt(0) == 1){
			if(month.charAt(1) > 3){
				return true;
			}
		}
		if(month.charAt(0) == 0){
			if(month.charAt(1) == 0){
				return true;
			}
		}
		return false;
	}

	private static boolean testDay(String day) {
		if (day.charAt(0) > 3){
			return true;
		}
		if (day.charAt(0) == 3){
			if(day.charAt(1) > 1){
				return true;
			}
		}

		return false;
	}
}

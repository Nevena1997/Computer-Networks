package treci;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String putanja=sc.next();
		try {
			URL urlIn=new URL("FILE:"+putanja);
			try {
				urlIn.openConnection();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Scanner in=new Scanner(new InputStreamReader(urlIn.openStream()));
				while(in.hasNext()){
					String linija=in.next();
					if(linija.endsWith(".txt"))
						System.out.println(linija);



				in.close();

				}


			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}




		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}





		sc.close();
	}

}

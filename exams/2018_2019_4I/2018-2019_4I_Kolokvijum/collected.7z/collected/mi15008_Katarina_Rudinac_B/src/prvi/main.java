package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String putanja=sc.next();
		try {
			Scanner in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja), "UTF-8")));
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("emails.txt"), "UTF-8"));
			try {
				String buf=new String();
				while(in.hasNext()){
					buf=in.next();
					if(buf.matches("[a-zA-Z0-9.]+[a-zA-Z0-9]+@[a-zA-Z0-9.]+[a-zA-Z0-9]+[.][a-zA-Z0-9]+")){
						out.write(buf, 0, buf.length());
						out.newLine();
					}
				}
			} catch (IOException e) {
				in.close();
				try {
					out.flush();
					out.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("greska pri citanju");
			}
			in.close();

			try {
				out.flush();
				out.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			System.out.println("Kakvo je ovo kodiranje??");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Gde ti je fajl alo");
		}




		sc.close();
	}

}

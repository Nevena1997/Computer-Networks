package drugi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Search {

	String path;
	char c;
	public Search(String path, char c) {
		// TODO Auto-generated constructor stub
		this.path=path;
		this.c=c;
	}

	synchronized public int prebroj(){
		int k=0;
		
		try {
			InputStreamReader in=new InputStreamReader(new FileInputStream(path), "UTF-8");
			try {
				int karakter;
				while((karakter=in.read())!=-1){
					if(c==karakter)
						k++;
				}
				
				

			} catch (IOException e) {
					try {
						in.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						
					System.out.println("greska pri citanju");
			}

			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
				System.out.println("Kakvo je ovo kodiranje??");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Gde ti je fajl alo");
			}

		
		
		return k;
		
	}
}

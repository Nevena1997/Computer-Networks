package drugi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String putanja=sc.next();
		Stack<String> listaPutanja=new Stack<String>();
		try {
			Scanner in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanja), "UTF-8")));
			String buf=new String();
			while(in.hasNext()){
				buf=in.next();
				listaPutanja.add(buf);
				System.out.println(buf);
			}
			
			int n=sc.nextInt();
			char c=(char)sc.nextByte();
			
			
			for(int i=0; i<n; i++){
				if(!listaPutanja.isEmpty()){
					String path=listaPutanja.pop();
					Search srch=new Search(path, c);
					SearchRunnable sr=new SearchRunnable(srch);
				}
				else{
					break;
				}
				
			}
			
			
			
			
			
			
			in.close();

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			System.out.println("Kakvo je ovo kodiranje??");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Gde ti je fajl alo");
		}




		sc.close();
	}
}

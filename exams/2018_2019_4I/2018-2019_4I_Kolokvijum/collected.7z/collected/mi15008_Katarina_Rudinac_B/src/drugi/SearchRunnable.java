package drugi;

public class SearchRunnable implements Runnable{

	public SearchRunnable(Search srch) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}

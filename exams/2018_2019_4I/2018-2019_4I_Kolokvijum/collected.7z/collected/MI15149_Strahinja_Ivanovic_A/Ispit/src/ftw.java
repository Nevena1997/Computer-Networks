

public class ftw extends second implements Runnable{

    private String putanja, match;

    public ftw(String putanja, String match) {
        this.putanja = putanja;
        this.match = match;
    }

    @Override
    public void run() {
        find(putanja,match);
    }
}

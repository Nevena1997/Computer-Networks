import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class third {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        Scanner in = null;
        try{
            in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(word))));
            while (in.hasNextLine()){
                String w = in.nextLine();
                if(w.contains(":ftp://") || w.contains(":sftp://")){
                    System.out.println(w);
                }
            }
        }
        catch (FileNotFoundException e){
            System.err.println("File not found");
        }
        finally {
            in.close();
        }
    }
}

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class second {
    synchronized void find(String path, String match){
        try (Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(path))))) {
            while (in.hasNext()) {
                String w = in.next();
                if (w.equals(match)) {
                    System.out.println(Thread.currentThread().getId() + " : " + path + " : " + (int) (Math.random() * 100));
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        }
        this.notifyAll();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();


        ArrayList<String> putanje = new ArrayList<>();

        try (Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(word))))) {
            while (in.hasNext()) {
                String w = in.next();
                System.out.println(w);
                putanje.add(w);
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
            sc.close();
        }

        int[] visited = new int[putanje.size()];
        Arrays.fill(visited, 0);

        System.out.println("Unesite kljucnu rec i broj niti:");
        String match = sc.next();
        int n = sc.nextInt();
        sc.close();

        int sum = 0;
        for (int i = 0; i < putanje.size(); i++) {
            sum++;
        }
        while(sum < putanje.size()){
            for(int k=0;k<n;k++){
                int i = (int) (Math.random() * putanje.size());
                if(visited[i]==0){
                    ftw t = new ftw(putanje.get(i), match);
                    visited[i]=1;
                    Thread thread = new Thread(t);
                    thread.start();
                }
            }
        }

    }
}

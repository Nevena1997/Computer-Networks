import java.io.*;
import java.util.Scanner;



public class first {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        sc.close();
        BufferedWriter out = null;
        try (Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(word), "UTF-8")))) {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"), "UTF-8"));
            while (in.hasNext()) {
                String w = in.next();
                if (w.matches("[0-9]{2}-[0-9]{2}-[0-9]{4}")) {
                    out.write(w);
                    out.newLine();
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (UnsupportedEncodingException e) {
            System.err.println("UTF-8 not supported");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

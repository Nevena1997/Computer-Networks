import java.io.*;
import java.util.Scanner;

public class MainTester {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String f = sc.next();
		//sc.close();
		String[] putanje = null;
		int br = 0;

		try{
			Scanner sc1 = new Scanner(new BufferedReader(new FileReader(f)));
			Scanner sc2 = new Scanner(new BufferedReader(new FileReader(f)));



			while(sc1.hasNext()){
				br++;
				System.out.println(sc1.nextLine());
			}
			putanje = new String[br];

			int i = 0;
			while(sc2.hasNext()){
				putanje[i] = sc2.nextLine();
				i++;
			}

			sc1.close();
			sc2.close();
		}catch(Exception e){
			e.printStackTrace();
		}

		System.out.println("Unesite kljucnu rec: ");
		String keyWord = sc.next();



		System.out.println("Unesite broj niti: ");
		Scanner sc4 = new Scanner(System.in);
		int n = sc4.nextInt();


		sc.close();
		sc4.close();

		Pretraga p1 = new Pretraga(putanje,keyWord);

		for(int i = 0;i < n ;i++){

			PretragaRunnable pretraga = new PretragaRunnable(p1,br);
			Thread t = new Thread(pretraga);
			t.start();
		}







	}

}

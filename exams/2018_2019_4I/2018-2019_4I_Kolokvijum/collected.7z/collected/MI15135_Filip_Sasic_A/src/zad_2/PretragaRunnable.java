import java.util.Arrays;

public class PretragaRunnable implements Runnable {

	private final static int MAX_DELAY = 5;

	private Pretraga p1;
	private int broj_fajlova;

	public PretragaRunnable(Pretraga p, int br){
		this.p1 = p;
		this.broj_fajlova = br;
	}

	@Override
	public void run(){
		int[] obradjene = new int[this.broj_fajlova];
		Arrays.fill(obradjene, 0);
		try{
			while(Arrays.stream(obradjene).sum() != this.broj_fajlova){
				int src =(int)(Math.random() * this.broj_fajlova);
				obradjene[src] = 1;
				p1.pretraga1(src);
				Thread.sleep((long)(Math.random()*MAX_DELAY));
			}
		}catch(Exception e){
			e.printStackTrace();
		}

	}


}

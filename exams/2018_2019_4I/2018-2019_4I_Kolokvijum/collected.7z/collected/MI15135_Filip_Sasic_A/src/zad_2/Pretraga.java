import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Pretraga {

	private final String[] putanje;
	private final String kw;
	private Lock lock;



	public Pretraga(String[] putanje, String keyWord){
		this.putanje = putanje;
		this.kw = keyWord;
		this.lock = new ReentrantLock();
	}

	public void pretraga1(int src){
		this.lock.lock();
		try{
			Scanner sc = new Scanner(new BufferedReader(new FileReader(this.putanje[src])));
			String word;
			while(sc.hasNext()){
				word = sc.next();
				if(word.equals(this.kw)){
					System.out.println(Thread.currentThread().getId()+":" + this.putanje[src]);
					sc.close();
					return;
				}
			}
			sc.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.lock.unlock();
		}
	}

}

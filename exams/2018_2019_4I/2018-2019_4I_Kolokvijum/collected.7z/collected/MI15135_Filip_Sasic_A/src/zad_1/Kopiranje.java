import java.io.*;
import java.util.Scanner;

public class Kopiranje {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String f = sc.next();
		sc.close();

		Scanner sc1 = null;
		BufferedWriter bw = null;
		try{

			sc1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8")));
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("timestamps.txt"),"UTF-8"));

			String date;
			while(sc1.hasNext()){
				date = sc1.next();

				if(date.length()!= 10){
					continue;
				}
				if(!Character.isDigit(date.charAt(0)) || !Character.isDigit(date.charAt(1))){
					continue;
				}


				if(!Character.isDigit(date.charAt(3)) || !Character.isDigit(date.charAt(4))){
					continue;
				}

				if(!Character.isDigit(date.charAt(6)) || !Character.isDigit(date.charAt(7))){
					continue;
				}
				if(!Character.isDigit(date.charAt(8)) || !Character.isDigit(date.charAt(9))){
					continue;
				}

				if((date.charAt(2) != '-') || (date.charAt(5) != '-')){
					continue;
				}
				if((date.charAt(0) != '0') && (date.charAt(0) != '1') && (date.charAt(0) != '2') && (date.charAt(0) != '3')){
					continue;
				}
				if((date.charAt(0) == '3') && (date.charAt(1) != '0' || date.charAt(1) != '1')){
					continue;
				}
				if((date.charAt(6) == '0') || (date.charAt(6) == '1')){
					continue;
				}

				bw.write(date);
				bw.newLine();
			}


		}catch(FileNotFoundException e){
			System.out.println("File " + f +" not found!");
			e.printStackTrace();
		}catch(UnsupportedEncodingException e){
			System.out.println("This shouldnt happen!");
			e.printStackTrace();

		}catch(IOException e){
			System.out.println("Failed to write!");
			e.printStackTrace();
		}finally{
			try{
				if(sc1 != null){
					sc1.close();
				}
				if(bw != null){
					bw.flush();
					bw.close();
				}

			}catch(IOException e){
				System.out.println("Failed to close files!");
				e.printStackTrace();

			}
		}


	}

}

package zad1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class FTPServer {
	
	public static void main(String[] args) {
		
		try(ServerSocket server = new ServerSocket(12345)) {
			while(true)
			{
				Socket sock = server.accept();
				ClientManager client = new ClientManager(sock);
				client.run();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}


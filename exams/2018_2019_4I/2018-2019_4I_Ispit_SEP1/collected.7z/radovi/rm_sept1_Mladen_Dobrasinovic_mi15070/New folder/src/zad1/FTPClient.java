package zad1;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class FTPClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Socket sock = new Socket("127.0.0.1", 12345)) {
			//
			Scanner sc = new Scanner(System.in);
			String target = sc.nextLine();
			
			PrintWriter out = new PrintWriter(sock.getOutputStream());
			InputStream ins = sock.getInputStream();
			Scanner in = new Scanner(ins);
			
			out.println(target);
			out.flush();

			// echo functionality
			/*if(!in.nextLine().equals(target))
			{
				sc.close();
				out.close();
				return;
			}*/
			
			// Checking success byte			
			int check = ins.read();
			System.out.println(check);
			if(check == 1)
			{
				System.out.println("Neuspeh");
				sc.close();
				out.close();
				return;
			}
			else if(check == 0)
			{
				String path = target.substring(target.lastIndexOf("/") + 1);
				try (FileOutputStream file = new FileOutputStream(path)) {
					int b;
					while((b = ins.read()) != -1)
						file.write(b);
				}
				
			}
			
			sc.close();
			out.close();
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
}

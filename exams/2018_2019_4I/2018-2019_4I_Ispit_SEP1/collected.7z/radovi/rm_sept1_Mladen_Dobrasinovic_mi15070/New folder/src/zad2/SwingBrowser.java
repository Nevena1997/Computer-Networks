package zad2;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;


public class SwingBrowser {

	private static final String URL = "file:///C:/Users/nalog/Desktop/rm_sept1_Mladen_Dobrasinovic_mi15070/New%20folder/1.html";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		LinkedList<String> history = new LinkedList();
		LinkedList<String> future = new LinkedList();
		int pos = 0;
		JEditorPane jep = new JEditorPane();
		jep.setPage(URL);
		history.add(URL);
		
		jep.setEditable(false);
		jep.addHyperlinkListener(new HyperlinkListener() {
			
			@Override
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
					try {
						jep.setPage(e.getURL());
						
						history.addLast(e.getURL().toString());
						
						// We can't redo anymore
						future.clear();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						jep.setText("Content not found");
					}
			}
		});
		
		JScrollPane jscroll = new JScrollPane(jep);
		JFrame f = new JFrame();
		f.setSize(600,400);
		f.setResizable(true);
		f.setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();
		
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.gridheight = 1;
		c.ipadx = 380;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 50.0;
		f.add(jscroll, c);
		
		JButton jundo = new JButton("<");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1;
		f.add(jundo, c);
		jundo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(history.size() > 1)
					{
					jep.setPage(history.get(history.size() - 2));
					String temp = history.getLast();
					history.removeLast();
					future.addFirst(temp);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton jredo = new JButton(">");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1;
		f.add(jredo, c);
		jredo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(future.size() > 0)
					{
					jep.setPage(future.getFirst());
					history.addLast(future.getFirst());
					future.removeFirst();
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton jca = new JButton("ca");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1;
		f.add(jca, c);
		
		
		
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		EventQueue.invokeLater(new Runnable()
				{
			@Override
					public void run()
					{
						f.setVisible(true);
					}
					
				});
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}


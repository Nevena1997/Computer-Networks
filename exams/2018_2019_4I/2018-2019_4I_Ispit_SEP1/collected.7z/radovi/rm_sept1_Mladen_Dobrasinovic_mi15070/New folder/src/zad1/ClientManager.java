package zad1;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ClientManager implements Runnable {
	
	private Socket sock;
	
	public ClientManager(Socket sock)
	{
		this.sock = sock;
	}
	@Override
	public void run() {
		try {
		Scanner sc = new Scanner(sock.getInputStream());
		BufferedOutputStream out = (new BufferedOutputStream(sock.getOutputStream()));
		PrintWriter pw = new PrintWriter(out);
		
		String file = sc.nextLine();
		
		// echo functionality for testing
		/*
		pw.println(file);
		*/
		
		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream(file);
		}
		catch(FileNotFoundException e)
		{
			out.write(1);
			out.flush();
			//System.out.println("1");
		}
		
		if(fin != null) {
		out.write(0);
		out.flush(); 
		
		//System.out.println("0");
		
		int b;
		while((b = fin.read()) != -1)
			out.write(b);
		  fin.close();
		}	
		
		out.flush();
		out.close();
		sc.close();
		sock.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

}

package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class WebBrowser {

	private static final String HOME_PAGE = "localhost";

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);
		f.setResizable(false);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	//komponente nece biti gde bi trebalo kao na slici, jer nisam siguran sta bi trebalo da odradim
	//mislim da bi trebalo nesto sa defoltnom vrednoscu koja je RELATIVE sto znaci da ce biti odmah ispod
	//ostavio sam ovako nema veze :)
	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);
		lh.goToPage(HOME_PAGE);

		// undo
		JButton btnUndo = new JButton("<");
		btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.undo();
			}
		});
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnUndo, c);

		//redo
		JButton btnRedo = new JButton(">");
		btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.redo();
			}
		});
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnRedo, c);

		//ci
		JButton btnCi = new JButton("ci");
		btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				jep.setText(jep.getText().replaceAll("^<a .* >$", " ")); //ako sam pogodio sidra za pocetak i kraj :D
			}
		});
		c.gridx = 2;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnCi, c);

	}

}

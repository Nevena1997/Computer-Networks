package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStack;
	private int index;

	public LinkHandler(JEditorPane jep) {
		this.jep = jep;
		this.urlStack = new ArrayList<>();
		this.index = -1;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();
		URL u = e.getURL();

		if(type == HyperlinkEvent.EventType.ACTIVATED
				&& !u.equals(urlStack.get(index))) {
			goToPage(u);
		}
	}

	public void goToPage(URL u) {
		try {
			jep.setPage(u);
			index++;
			urlStack.add(index, u);
			for(int i = index + 1; i < urlStack.size(); i++) {
				urlStack.remove(i);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void goToPage(String url) {
		try {
			URL u = new URL(url);
			goToPage(u);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public void undo() {
		if(index > 0) {
			index--;
			URL u = urlStack.get(index);
			try {
				jep.setPage(u);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void redo() {
		if(index < urlStack.size() - 1) {
			index++;
			URL u = urlStack.get(index);
			try {
				jep.setPage(u);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

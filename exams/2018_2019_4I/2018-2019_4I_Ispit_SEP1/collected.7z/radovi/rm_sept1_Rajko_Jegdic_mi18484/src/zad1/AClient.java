package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class AClient {

	public static void main(String[] args) {
		String hostname = "localhost";
		int port = 12345;

		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;

		try(Socket socket = new Socket(hostname, port)) {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			sc = new Scanner(System.in);

			while(true) {
				String s = sc.nextLine();

				out.write(s);
				out.newLine();
				out.flush();

				//poruka od servera
				System.out.println(in.readLine());
			}


		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(in != null) {
					in.close();
				}
				if(out != null) {
					out.close();
				}
				if(sc != null) {
					sc.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}

}

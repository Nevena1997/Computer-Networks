package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class BClient {

	public static void main(String[] args) {
		String hostname = "localhost";
		int port = 12345;

		BufferedReader networkIn = null;
		PrintWriter out = null;

		try (Socket socket = new Socket(hostname, port)) {
			networkIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(socket.getOutputStream());
			BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("Konektovan!");

			while(true) {
				String line = userInput.readLine();
				out.println(line);
				out.flush();

				//odgovor od servera
				System.out.println(networkIn.readLine());
			}

		} catch (IOException e) {
			System.err.println("Izuzetak!");
			e.printStackTrace();
		} finally {
			try {
				if(networkIn != null) {
					networkIn.close();
				}
				if(out != null) {
					out.close();
				}
			} catch (IOException e) {

			}
		}
	}

}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		Scanner sc = null;
		BufferedReader in = null;
		PrintWriter out = null;

		try (Socket client = new Socket("localhost", 12345)){

			System.out.println("Client started.");

			sc = new Scanner(System.in);
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));


			String relPath = sc.nextLine();
			out.println(relPath);
			out.flush();


			System.out.println("Echo odgovor: " + in.readLine());

			String line;
			while ((line = in.readLine()) != null){
				System.out.println(line);
			}


		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (sc != null)
				sc.close();
			if (out != null)
				out.close();

			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

	}



}

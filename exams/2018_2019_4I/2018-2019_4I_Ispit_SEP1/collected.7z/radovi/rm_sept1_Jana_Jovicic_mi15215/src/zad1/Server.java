package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.HashSet;
import java.util.Set;

public class Server {

	private static Set<UserThread> userThreads = new HashSet<UserThread>();

	public static void main(String[] args) {

		try (ServerSocket server = new ServerSocket(12345)){

			System.out.println("Server started");

			while (true){

				Socket client = server.accept();
				System.out.println("Accepted connection");


				UserThread t = new UserThread(client);
				userThreads.add(t);
				t.start();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*
	public static void broadcast(ByteBuffer buff){

		for (UserThread user : userThreads){

			for (byte b : buff.array()){
				user.out.print((char)b);
			}
			user.out.print('\n');
			user.out.flush();
			//buff.flip();
			buff.rewind();
		}
	}
*/

	private static class UserThread extends Thread {

		private byte indicator;
		private Socket client;
		private BufferedReader in;
		private PrintWriter out;
		private ByteBuffer buff;


		public UserThread(Socket client){
			this.client = client;
			this.buff = ByteBuffer.allocate(4096);
			try {
				this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				this.out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		@Override
		public void run() {


			try {
				String relPath = in.readLine();
				out.println(relPath);
				out.flush();

				File f = new File(relPath);
				String absPath = f.getAbsolutePath();

				FileInputStream fin = new FileInputStream(absPath);
				FileChannel fileCh = fin.getChannel();

				if (!fileCh.isOpen()){
					this.indicator = 0;
					this.client.close();
				}

				this.indicator = 1;

				//ByteBuffer buff = ByteBuffer.allocate(4096);

				fileCh.read(buff);

				//broadcast(buff);


				for (byte b : buff.array()){
					out.print((char)b);
				}
				out.print('\n');
				out.flush();

				in.close();
				out.close();
				fin.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
	}

}

package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStack;
	private int index;

	public LinkHandler(JEditorPane jep){
		this.jep = jep;
		this.index = -1;
		this.urlStack = new ArrayList<URL>();
	}

	private void goToPage(URL url){
		urlStack.add(this.index+1, url);
		this.index++;

		for (int i = index+1; i < urlStack.size(); i++)
			urlStack.remove(i);

		try {
			jep.setPage(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void goToPage(String urlStr){
		try {
			URL u = new URL(urlStr);
			goToPage(u);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {

		URL url = e.getURL();
		if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED && url != urlStack.get(index)){
			goToPage(url);
		}
	}


	public void undo(){
		if (index > 0){
			index--;
			try {
				jep.setPage(urlStack.get(index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void redo(){
		if (index < urlStack.size()+1){
			index++;
			try {
				jep.setPage(urlStack.get(index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


}

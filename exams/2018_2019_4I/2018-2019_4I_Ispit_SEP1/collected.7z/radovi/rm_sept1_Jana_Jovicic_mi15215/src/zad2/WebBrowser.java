package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class WebBrowser {

	public static String HOME_PAGE = "file:///C:/Users/nalog/workspace/rm_sept1_Jana_Jovicic_mi15215/1.html";

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 600);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable(){

			@Override
			public void run() {
				f.setVisible(true);
			}

		});

	}


	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);


		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);
		lh.goToPage(HOME_PAGE);


		JButton btnUndo = new JButton("<");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.undo();
			}
		});
		pane.add(btnUndo, c);

		JButton btnRedo = new JButton(">");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		btnRedo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.redo();
			}
		});
		pane.add(btnRedo, c);

		JButton btnCa = new JButton("ca");
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		btnCa.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				jep.setText(jep.getText().replaceAll("<a[^>]*?>", ""));
			}
		});
		pane.add(btnCa, c);

	}

}

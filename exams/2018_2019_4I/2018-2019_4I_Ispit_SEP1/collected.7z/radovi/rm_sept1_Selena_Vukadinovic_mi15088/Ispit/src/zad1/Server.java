package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static void main(String[] args) {

		ByteBuffer putanja = ByteBuffer.allocate(90);

		try(ServerSocketChannel serverCh = ServerSocketChannel.open();
			Selector selektor = Selector.open()) {

			if(!serverCh.isOpen() || !selektor.isOpen())
				System.exit(1);

			serverCh.bind(new InetSocketAddress(12345));
			serverCh.configureBlocking(false);
			serverCh.register(selektor, SelectionKey.OP_ACCEPT);

			while(true){
				selektor.select();
				Set<SelectionKey> svi = selektor.selectedKeys();
				Iterator<SelectionKey> iterator = svi.iterator();

				while(iterator.hasNext()){

					SelectionKey kljuc = iterator.next();
					iterator.remove();

					try{
						if(kljuc.isAcceptable()){
							ServerSocketChannel server = (ServerSocketChannel) kljuc.channel();
							SocketChannel klijent = server.accept();

							klijent.configureBlocking(false);
							SelectionKey kljuc2 = klijent.register(selektor, SelectionKey.OP_WRITE);

							ByteBuffer buf = ByteBuffer.allocate(90);
							klijent.read(buf);
							kljuc.interestOps(SelectionKey.OP_WRITE);
							kljuc2.attach(putanja.duplicate());

						}else if(kljuc.isReadable()){
							SocketChannel klijent = (SocketChannel) kljuc.channel();
							ByteBuffer buf = ByteBuffer.allocate(90);

							buf.rewind();
							buf.put((byte)1);

							kljuc.attach(buf);


						}else if(kljuc.isWritable()){
							SocketChannel klijent = (SocketChannel) kljuc.channel();
							ByteBuffer buf = (ByteBuffer) kljuc.attachment();



							WritableByteChannel out = Channels.newChannel(System.out);
							if(buf.hasRemaining()){
								buf.flip();
								out.write(buf);
							}


						}

					}catch(Exception e){
						kljuc.cancel();
						try{
							kljuc.channel().close();
						}catch(Exception e1){
							e.printStackTrace();
						}
					}

				}

			}



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.SocketChannel;
public class Client {

	public static void main(String[] args) {
		try {
			SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost", 12345));
			klijent.configureBlocking(false);

			System.out.println("Unesite putanju do fajla");
			ReadableByteChannel in = Channels.newChannel(System.in);
			ByteBuffer buf = ByteBuffer.allocate(90);

			in.read(buf);
			buf.flip();
			klijent.write(buf);

			while(true){
				int n = klijent.read(buf);
				if(n>0){
					buf.flip();
					System.out.println(buf);
				}else if(n == -1){
					break;
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}

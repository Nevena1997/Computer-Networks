package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStek;
	private int index = -1;


	public LinkHandler(JEditorPane jep) {
		this.jep = jep;
		this.index = -1;
		this.urlStek = new ArrayList<URL>();
	}


	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		URL u = e.getURL();
		if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED && u != urlStek.get(index)){
			this.goToPage(u);
		}
	}


	public void goToPage(String string) {

		try {
			URL u = new URL(string);
			this.goToPage(u);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}


	private void goToPage(URL u) {
		urlStek.add(index+1, u);
		index++;

		for(int i = index+1; i < urlStek.size(); i++){
			urlStek.remove(i);
		}

		try {
			jep.setPage(u);
		} catch (IOException e) {
			jep.setText("<html>Sorry, we are having some technical problems.</html>");
		}

	}


	public void undo() {
		if(index > 0)
			index--;

		URL u = urlStek.get(index);
		try {
			jep.setPage(u);
		} catch (IOException e) {
			jep.setText("<html>Sorry, we are having some technical problems.</html>");
		}


	}


	public void redo() {

		if(index < urlStek.size() - 1)
			index++;

		URL u = urlStek.get(index);
		try {
			jep.setPage(u);
		} catch (IOException e) {
			jep.setText("<html>Sorry, we are having some technical problems.</html>");
		}

	}


	public void ca() {
		// TODO Auto-generated method stub

	}




}

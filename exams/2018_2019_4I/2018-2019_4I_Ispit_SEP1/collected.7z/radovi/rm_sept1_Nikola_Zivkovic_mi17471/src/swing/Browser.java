package swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class Browser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 450);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container contentPane) {
		// TODO Auto-generated method stub

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		jep.setContentType("text/html");
		try {
			jep.setPage("file:///C:/Users/nalog/workspace/sept1/src/swing/1.html");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JScrollPane js = new JScrollPane(jep);
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 3;
		c.ipadx = 600;
		c.ipady = 350;
		c.weightx = 1.0;
		c.weighty = 1;

		contentPane.add(js, c);

		JButton undo = new JButton("<");
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

			}
		});
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipady = 10;
		c.gridwidth = 1;
		contentPane.add(undo, c);

		JButton redo = new JButton(">");
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

			}
		});
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 1;
		c.gridwidth = 1;
		contentPane.add(redo, c);

		JButton ca = new JButton("ca");
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				File f = new File("file:///C:/Users/nalog/workspace/sept1/src/swing/1.html");

				try {
					BufferedReader reader = new BufferedReader(new FileReader(f));
					String text = "";
					String line;
					while((line = reader.readLine()) != null){

						text += line;
					}

					text.replace("<a>", "");
					text.replace("</a>", "");

					jep.setText(text);

					reader.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 2;
		c.gridwidth = 1;
		contentPane.add(ca, c);
	}

}

package sockets;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Client {

	private static int PORT = 12345;
	private static String HOST = "localhost";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SocketAddress address = new InetSocketAddress(HOST, PORT);
		try {
			SocketChannel client = SocketChannel.open(address);

			ByteBuffer buff = ByteBuffer.allocate(1024);
			Scanner sc = new Scanner(System.in);

			if(sc.hasNext()){
				String request = sc.next();
				System.out.println(request);
				buff = ByteBuffer.wrap(request.getBytes());

				client.write(buff);

				buff.clear();
			}

			sc.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

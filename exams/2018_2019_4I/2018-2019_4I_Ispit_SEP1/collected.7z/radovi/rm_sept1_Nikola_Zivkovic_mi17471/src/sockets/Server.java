package sockets;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	private static int PORT = 12345;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
			Selector selector = Selector.open();){
			serverChannel.bind(new InetSocketAddress(PORT));

			while(true){

				Set<SelectionKey> selectedKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = selectedKeys.iterator();

				while(iterator.hasNext()){

					SelectionKey key = iterator.next();
					iterator.remove();

					SocketChannel channel = SocketChannel.open();
					channel.register(selector, SelectionKey.OP_ACCEPT);
					channel.configureBlocking(false);

					if(key.isAcceptable()){

						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client = server.accept();

						System.out.println(client.getRemoteAddress());

						client.register(selector, SelectionKey.OP_READ);
					}else if(key.isReadable()){

						SocketChannel client = SocketChannel.open();

						ByteBuffer buff = ByteBuffer.allocate(1024);
						client.read(buff);
						String request = buff.array().toString();
						buff.clear();

						System.out.println(request);
					}
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

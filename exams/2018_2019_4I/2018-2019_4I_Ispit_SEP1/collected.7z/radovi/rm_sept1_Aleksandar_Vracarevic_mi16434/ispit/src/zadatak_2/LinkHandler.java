package zadatak_2;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane pane;
	private List<URL> urls;
	private int index;

	public LinkHandler(JEditorPane pane) {
		this.pane = pane;
		this.urls = new ArrayList<>();
		this.index = -1;
	}

	public void undo(){

		System.err.println(this.index);
		if(this.index > 0){
			System.err.println("Undo invoked");
			this.index--;
			try {
				this.pane.setPage(this.urls.get(this.index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void redo(){
		if(this.index < this.urls.size() -1){
			this.index++;
			try{
				this.pane.setPage(this.urls.get(this.index));
			} catch (IOException e){

			}
		}
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {

		if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED){
			// click on link
			System.err.println("Link clicked");
			System.err.println(e.getURL());
			this.index++;

			try {
				this.pane.setPage(e.getURL());
				this.urls.add(e.getURL());


				for(int i = this.index; i < this.urls.size(); i++){
					this.urls.remove(i);
				}


			} catch (IOException e1) {
				this.pane.setText("<html>Couldn't open link</html>");
			}
		}

	}

}

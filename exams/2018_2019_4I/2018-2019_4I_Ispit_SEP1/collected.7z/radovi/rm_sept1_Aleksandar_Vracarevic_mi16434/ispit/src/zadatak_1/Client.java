package zadatak_1;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		int port = 12345;

		try (Socket connection = new Socket("localhost", port); Scanner sc = new Scanner(System.in);) {


			PrintWriter writer = new PrintWriter(new BufferedOutputStream(connection.getOutputStream()));

			while(true){

				// Read responses
				new Thread(new Runnable() {

					@Override
					public void run() {
						try {
							BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
							System.out.println("Response: ");
							int c;
							while((c = in.read()) != -1){
								System.out.print((char)c);
							}
							System.out.println("End of response");
						} catch (IOException e) {

							e.printStackTrace();
						}

					}
				}).start();


				// Write requests
				System.out.println("Enter message for server");
				String sendMsg = sc.nextLine();
				new Thread(new Runnable() {

					@Override
					public void run() {
						if(!sendMsg.isEmpty()){
							writer.println(sendMsg);
							writer.flush();
						}

					}
				}).start();




			}


		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

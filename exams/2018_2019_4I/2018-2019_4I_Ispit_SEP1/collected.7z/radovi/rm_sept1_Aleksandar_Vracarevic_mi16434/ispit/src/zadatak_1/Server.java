package zadatak_1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class Server {

	private static List<ClientHandler> clients = new ArrayList<ClientHandler>();

	public static void main(String[] args) {
		int port = 12345;



		while(true){
			try(ServerSocket server = new ServerSocket();){

				InetSocketAddress address = new InetSocketAddress(port);
				server.bind(address);
				System.out.println("Listening for new connections...");

				Socket client = server.accept();
				System.out.println("Accepted new connection");

				ClientHandler ch = new ClientHandler(client);
				clients.add(ch);
				Thread t = new Thread(ch);
				t.start();


			} catch (IOException e){

			}
		}


	}

	public static void broadcast(String msg){
		for(int i = 0; i < clients.size(); i++){
			try {
				clients.get(i).sendMsg(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

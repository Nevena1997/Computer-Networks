package zadatak_2;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLDocument;

public class Main {

	public static void main(String[] args) {

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		LinkHandler lh = new LinkHandler(jep);;
		try{

			jep.setContentType("text/html");
			File startFile = new File("C:\\Users\\nalog\\workspace\\ispit\\src\\zadatak_2\\prvi.html");
			FileReader reader = new FileReader(startFile);
			System.out.println("Attempting to read from file");
			int c;
			String content = "";
			while((c = reader.read()) != -1){
				content += (char) c;
			}
			jep.setText(content);
			jep.addHyperlinkListener(lh);
		} catch (Exception e){
			e.printStackTrace();
		}

		JScrollPane scrollPane = new JScrollPane(jep);

		JFrame frame = new JFrame("TEST");
		jep.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setContentPane(scrollPane);

		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipadx = 0;
		c.ipady = 0;
		JButton buttonUndo = new JButton("<");
		buttonUndo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.undo();
			}
		});
		jep.add(buttonUndo, c);

		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipadx = 0;
		c.ipady = 0;
		JButton buttonRedo = new JButton(">");
		buttonRedo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.redo();
			}
		});
		jep.add(buttonRedo, c);

		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipadx = 0;
		c.ipady = 0;
		JButton buttonCa = new JButton("ca");
		buttonCa.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Ne znam kako se bese koristi regex, a nisam imao vremena da implementiram parser zasebno
				//jep.setText(jep.getText().replaceAll(regex, replacement))
			}
		});
		jep.add(buttonCa, c);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);

			}
		});

	}



}

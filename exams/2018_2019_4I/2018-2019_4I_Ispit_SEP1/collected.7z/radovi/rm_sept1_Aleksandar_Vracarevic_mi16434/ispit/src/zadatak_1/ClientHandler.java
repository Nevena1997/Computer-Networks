package zadatak_1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientHandler extends Thread{

	private Socket socket;
	private BufferedReader fRead;
	private PrintWriter clientOut;

	public ClientHandler(Socket socket){
		this.socket = socket;
	}

	public void sendMsg(String msg) throws IOException{
		PrintWriter clientOut = new PrintWriter(socket.getOutputStream());
		clientOut.println(msg);
		clientOut.flush();
	}

	@Override
	public void run() {

		try {

			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			String pathname = in.readLine();

			// echo to the client
			clientOut = new PrintWriter(socket.getOutputStream());
			clientOut.println(pathname);
			clientOut.flush();

			// send file to client
			File f = new File(pathname);
			fRead = new BufferedReader(new FileReader(f));

			//clientOut.print((byte)0); // OK byte
			int c;
			while((c = fRead.read()) != -1)
				clientOut.write((char) c);
			clientOut.flush();
			System.err.println("Flushed");


		} catch (IOException e) {
			try {
				socket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			clientOut.write(1); //Not OK byte
			clientOut.flush();
			e.printStackTrace();
		}

	}



}

package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static void main (String[] args) {

		int port = 12345;

		try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
			Selector selektor = Selector.open()) {

			if (!serverChannel.isOpen() || !selektor.isOpen()) {
				System.err.println("Error!");
			}

			serverChannel.bind(new InetSocketAddress(port));
			serverChannel.configureBlocking(false);
			serverChannel.register(selektor, SelectionKey.OP_ACCEPT);

			System.out.println("Server on port: " + port);

			while (true) {
				selektor.select();
				Set<SelectionKey> keys = selektor.selectedKeys();
				Iterator<SelectionKey> iter = keys.iterator();

				// System.out.println("---------");

				while (iter.hasNext()) {
					SelectionKey key = iter.next();
					iter.remove();

					// System.out.println("---------");

					if (key.isAcceptable()) { }

					else if (key.isReadable()) {
						SocketChannel klijent = (SocketChannel) key.channel();

						ByteBuffer buff = ByteBuffer.allocate(1024);
						klijent.read(buff);

						// System.out.println("---------");



						StringBuilder sb = new StringBuilder();
						for (byte b : buff.array()) {
							sb.append(b);
						}

						String msg = sb.toString().trim();

						System.out.println("Poruka: ");
						System.out.println(msg);

						if (!msg.equalsIgnoreCase("stop")) {
							byte[] sadrzaj_fajla = new byte[1024];
							for (int i = 0; i < 1024; i++) {
								// File f = new File(msg);

								try {
									BufferedReader f = new BufferedReader(new InputStreamReader(new FileInputStream(msg)) );

									char[] buff3 = new char[1024];
									try {
										String line;
										while ((line = f.readLine()) != null) {
										System.out.println(line.toString().trim());
										}

									} catch (IOException ex) {
										// TODO Auto-generated catch block
										ex.printStackTrace();
									}
								} catch (FileNotFoundException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								sadrzaj_fajla[i] = ((byte)'a');
							}

							ByteBuffer buff2 = ByteBuffer.allocate(1024);
							buff2.put(sadrzaj_fajla);
							buff2.put((byte) '\t');
							buff2.put((byte) '\n');
							buff2.flip();
						//	klijent.write(buff2);
							key.attach(buff2.duplicate());
							key.interestOps(SelectionKey.OP_WRITE);
					}
						else {
							klijent.close();
						}

					}
					else if (key.isWritable()) {

						SocketChannel klijent = (SocketChannel) key.channel();

						ByteBuffer buff = (ByteBuffer) key.attachment();
						if (buff.hasRemaining()) {
							klijent.write(buff.duplicate());
						}

						key.interestOps(SelectionKey.OP_READ);

					}
				}
			}



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

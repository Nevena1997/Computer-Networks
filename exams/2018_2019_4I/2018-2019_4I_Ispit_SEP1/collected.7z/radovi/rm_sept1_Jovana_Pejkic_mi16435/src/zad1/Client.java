package zad1;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main (String[] args) {

		int port = 12345;

		Scanner sc = null;
		PrintWriter out = null;
		InputStreamReader in = null;

		try {
			Socket soket = new Socket("localhost", port);

			out = new PrintWriter(soket.getOutputStream());
			in = new InputStreamReader(soket.getInputStream());

			while (true) {
				sc = new Scanner(System.in);

				String line;
				while (sc.hasNextLine()) {
					line = sc.nextLine();
					System.out.println("line: " + line);
					if (line.equalsIgnoreCase("stop")) {	// kriterijum zaustavljanja
						break;
					}

					out.write(line);
					out.flush();
				}

				System.out.print(in.read());
			}



		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (sc != null) {
				sc.close();
			}
			if (out != null) {
				out.close();
			}
	//		if (in != null) {
	//			try {
	//				in.close();
	//			} catch (IOException e) {
	//				// TODO Auto-generated catch block
	//				e.printStackTrace();
	//			}
			}

		}

	}

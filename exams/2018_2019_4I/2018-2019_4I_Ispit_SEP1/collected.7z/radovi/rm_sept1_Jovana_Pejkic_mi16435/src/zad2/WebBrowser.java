package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

public class WebBrowser {

	public static final String HOME_PAGE = "http://poincare.matf.bg.ac.rs/~filip/";

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setResizable(true);
		f.setSize(800, 600);
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});
	}



	public static void addComponents(Container pane) {
		// TODO Auto-generated method stub

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		c.fill = GridBagConstraints.HORIZONTAL;

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);
		//lh.gotoPage(HOME_PAGE);



		JScrollPane sc = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 700;
		c.ipady = 500;
		c.weightx = 0.5;
		c.weighty = 0;
		c.gridwidth = 3;
		pane.add(sc, c);


		JButton undo = new JButton("<");
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0.2;
		pane.add(undo, c);


		JButton redo = new JButton(">");
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0.2;
		pane.add(redo, c);


		JButton ca = new JButton("ca");

		ca.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					BufferedReader f = new BufferedReader(new InputStreamReader(new FileInputStream("2.txt")) );

				//	PrintWriter out = new PrintWriter(new File("nova.html", "UTF-8"));
					char[] buff = new char[1024];
					try {
						String line;
						while ((line = f.readLine()) != null) {
						System.out.println(line.toString().trim());
						jep.setText(line.toString().trim());
						}

					} catch (IOException ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
				} catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}


		});

		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0.2;
		pane.add(ca, c);

	}


}

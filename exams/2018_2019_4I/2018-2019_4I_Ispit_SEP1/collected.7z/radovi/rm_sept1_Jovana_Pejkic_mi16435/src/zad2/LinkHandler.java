package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStack;
	private int index;

	public LinkHandler(JEditorPane jep) {
		this.jep = jep;
		this.index = -1;
		this.urlStack = new ArrayList<>();
	}

	/*

	public void gotoPage (URL url) {
		try {
			this.jep.setPage(url);
			this.index++;
			this.urlStack.add(index, url);

			for (int i = this.index + 1; i < this.urlStack.size(); i++) {
				this.urlStack.remove(i);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			this.jep.setText("Error!");
		}
	}


	public void gotoPage (String str) {
		URL u;
		try {
			u = new URL(str);
			this.gotoPage(u);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			this.jep.setText("Error!");
		}
	}
*/
	public void undo () {
		if (this.index > 0) {
			this.index--;
			try {
				this.jep.setPage(this.urlStack.get(index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				this.jep.setText("Error!");
			}
		}
	}


	public void redo() {
		if (this.index < this.urlStack.size()) {
			this.index++;
			try {
				this.jep.setPage(this.urlStack.get(index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				this.jep.setText("Error!");
			}
		}
	}



	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		// TODO Auto-generated method stub

		HyperlinkEvent.EventType type = e.getEventType();
		URL url = e.getURL();

		if (HyperlinkEvent.EventType.ACTIVATED == type && !url.equals(this.urlStack.get(index))) {
			try {
				this.jep.setPage(url);
				// TODO Ili treba gotoPage(url)!!!!!!!!!!!!!!!!!
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				this.jep.setText("Error!");
			}
		}


	}

}

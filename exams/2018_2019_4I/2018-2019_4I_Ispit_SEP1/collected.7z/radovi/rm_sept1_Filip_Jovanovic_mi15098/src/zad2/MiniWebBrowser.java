package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;


public class MiniWebBrowser {

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setSize(600, 600);
		f.setResizable(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});

		setComponents(f.getContentPane());

	}

	private static void setComponents(Container pane){

		GridBagLayout layout = new GridBagLayout();
		pane.setLayout(layout);

		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);

		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JButton btnUndo = new JButton("<");
		btnUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.undo();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridy = 1;
		c.gridwidth = 1;
		c.weighty = 0.0;
		pane.add(btnUndo, c);

		JButton btnRedo = new JButton(">");
		btnRedo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.redo();
			}
		});
		c.gridx = 1;
		pane.add(btnRedo, c);

		JButton btnCa = new JButton("ca");
		btnCa.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.ca();
			}
		});
		c.gridx = 2;
		pane.add(btnCa, c);

	}

	private static class LinkHandler implements HyperlinkListener {

		private JEditorPane jep;
		private List<URL> history;
		private int index = -1;


		private final String HOME_PAGE = "C:\\Users\\nalog\\Desktop\\rm_sept1_Filip_Jovanovic_mi15098\\src\\zad2\\1.html";

		public LinkHandler(JEditorPane jep){
			this.jep = jep;
			history = new ArrayList<URL>();
			setPage(HOME_PAGE);
		}

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			if (e.getEventType() == EventType.ACTIVATED){
				setPage(e.getURL());
			}
		}

		public void undo() {
			if (index > 0){
				index--;
				try {
					jep.setPage(history.get(index));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		public void redo() {
			if (index < history.size() - 1){
				index++;
				try {
					jep.setPage(history.get(index));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		public void ca() {
			String text = jep.getText();
			text = text.replaceAll("<a[^>]*>", "");
			text = text.replaceAll("</a>", "");
			jep.setText(text);
		}

		private void setPage(String urlString) {
			try {
				File f = new File(urlString);
				URL url = f.toURI().toURL();
				setPage(url);
			} catch (MalformedURLException e) {
				jep.setText("<h1>Malformed URL 2!</h1>");
				e.printStackTrace();
			}
		}

		private void setPage(URL url) {
			if(index == -1 || history.get(index) != url){
				history.add(index + 1, url);
				index++;

				if (index < history.size() - 1){
					for (int i = history.size() - 1; i > index; i--){
						history.remove(i);
					}
				}
			}

			try {
				jep.setPage(url);
			} catch (IOException e) {
				jep.setText("<h1>Exception!</h1>");
			}


		}

	}

}

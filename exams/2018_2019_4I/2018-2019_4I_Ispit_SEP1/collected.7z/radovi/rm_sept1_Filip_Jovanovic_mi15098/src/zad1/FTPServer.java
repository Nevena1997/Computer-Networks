package zad1;

import java.io.IOException;
import java.net.ServerSocket;

public class FTPServer {

	public static final int port = 12345;

	public static void main(String[] args) {

		try (ServerSocket server = new ServerSocket(port);){

			while(true){
				try {
					new Thread(new ClientHandler(server.accept())).start();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class FTPClient {

	public static final String host = "localhost";
	public static final int port = 12345;

	public static void main(String[] args) {

		try (Socket sock = new Socket(host, port);
			 Scanner sc = new Scanner(System.in);
			 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			 Scanner in = new Scanner(new BufferedInputStream(sock.getInputStream()))){

			while(true){
				String line = sc.nextLine().trim();
				out.write(line);
				byte indicator = in.nextByte();
				if (indicator == 1){
					break;
				}

				PrintWriter pw = new PrintWriter(new File(line));

				while(in.hasNext()){
					pw.print(in.next());
				}
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandler implements Runnable {

	Socket sock;
	Scanner in;
	PrintWriter out;

	public ClientHandler(Socket sock) throws IOException {
		in = new Scanner(new BufferedInputStream(sock.getInputStream()));
		out = new PrintWriter(new BufferedOutputStream(sock.getOutputStream()));
		this.sock = sock;
	}

	@Override
	public void run() {

		while(true){

			String path = in.nextLine().trim();

			try (Scanner file = new Scanner(new BufferedInputStream(new FileInputStream(new File(path))))){
				byte b = 0;
				out.print(b);

				while(file.hasNext()){
					out.print(file.next());
				}

			} catch (FileNotFoundException e) {
				byte b = 1;
				out.print(b);
				in.close();
				out.close();
				try {
					sock.close();
				} catch (IOException e1) {
				}
				break;
			}

		}

	}

}
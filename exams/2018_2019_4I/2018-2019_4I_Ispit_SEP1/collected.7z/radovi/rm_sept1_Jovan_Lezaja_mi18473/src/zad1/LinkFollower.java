package zad1;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkFollower implements HyperlinkListener{

	private JEditorPane pane;
	private List<URL> urlStack;
	private int index;

	public LinkFollower(JEditorPane pane) {
		this.pane = pane;
		this.index = -1;
		this.urlStack = new ArrayList<URL>();
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();

		if (type == HyperlinkEvent.EventType.ACTIVATED) {
			try {
				URL url = e.getURL();
				urlStack.add(++index, url);
				pane.setPage(url);
			} catch(IOException ex) {
				pane.setText("<html> Oops. Couldn't load page. </html>");
			}
		}
	}

	private void goToPage(URL url) {
		try {
			if (index++ < urlStack.size()) {
				urlStack.add(index, url);
				for (int i=index+1; i < urlStack.size(); i++) {
					urlStack.remove(i);
				}
			}
			pane.setPage(url);
		} catch (IOException ex) {
			pane.setText("<html> Oops. Couldn't load page. </html>");
		}
	}

	public void goToPage(String urlString) {
		try {
			URL url = new URL(urlString);
			goToPage(url);
		} catch (MalformedURLException e) {
			pane.setText("<html> Oops. Couldn't load page. </html>");
		}
	}

	public void undo() {
		if (index > 0) {
			index--;
			try {
				pane.setPage(urlStack.get(index));
			} catch (IOException e) {
				pane.setText("<html> Oops. Couldn't load page. </html>");
			}
		}
	}

	public void redo() {
		if (index < urlStack.size()-1) {
			index++;
			try {
				pane.setPage(urlStack.get(index));
			} catch (IOException e) {
				pane.setText("<html> Oops. Couldn't load page. </html>");
			}
		}
	}

	public void ca() {

	}
}

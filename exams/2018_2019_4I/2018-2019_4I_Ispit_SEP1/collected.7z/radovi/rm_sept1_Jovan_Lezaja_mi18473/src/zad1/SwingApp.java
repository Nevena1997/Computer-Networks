package zad1;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Container;

public class SwingApp {

	private static final String HOME_PAGE = "file:///C:\\Users\\nalog\\Desktop\\rm_sept1_Jovan_Lezaja_mi18473\\src\\1.html";

	public static void main(String[] args) {

		JFrame frame = new JFrame("SwingApp");
		frame.setSize(500, 400);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setResizable(true);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		pane.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		LinkFollower lf = new LinkFollower(jep);
		jep.addHyperlinkListener(lf);
		lf.goToPage(HOME_PAGE);

		JScrollPane scrollPane = new JScrollPane(jep);
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.gridwidth = 3;
		constraints.ipadx = 0;
		constraints.ipady = 400;
		constraints.weightx = 0.0;
		constraints.weighty = 1.0;
		pane.add(scrollPane, constraints);

		JButton undoBtn = new JButton("<");
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 1;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 0.0;
		pane.add(undoBtn, constraints);

		undoBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lf.undo();
			}
		});

		JButton redoBtn = new JButton(">");
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 1;
		constraints.gridy = 1;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 0.0;
		pane.add(redoBtn, constraints);

		redoBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lf.redo();
			}
		});

		JButton caBtn= new JButton("ca");
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 2;
		constraints.gridy = 1;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 0.0;
		pane.add(caBtn, constraints);

		caBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lf.ca();
			}
		});
	}
}

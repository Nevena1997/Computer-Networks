package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Files;

public class Client {

	public static void main(String[] args) {

		BufferedReader userIn = null;
		BufferedReader in = null;
		BufferedWriter out = null;
		try (Socket connection = new Socket("localhost", 12345)) {

			userIn = new BufferedReader(new InputStreamReader(System.in));
			out = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
			in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			System.out.println("Unesite putanju do fajla");
			String path = userIn.readLine();

			out.write(path);
			out.newLine();
			out.flush();

			//line = in.readLine();
			//if (line.equals(0)) {
				BufferedWriter fileOut = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path)));

				String line;
				while ((line = in.readLine()) != null) {
					System.out.println(line);
				}
			//}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (userIn != null) {
					userIn.close();
				}
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {

			}
		}
	}
}

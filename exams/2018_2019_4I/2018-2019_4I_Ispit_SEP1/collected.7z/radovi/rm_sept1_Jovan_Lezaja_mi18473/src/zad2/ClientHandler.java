package zad2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ClientHandler extends Server implements Runnable {

	private Socket socket;

	public ClientHandler(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

			String line = in.readLine();
			/*
			out.write(line);
			out.newLine();
			out.flush();
			*/

			Path path = Paths.get(line);
			String strPath = path.toAbsolutePath().toString();

			URL url = null;
			try {
				url = new URL("file:///" + strPath);
				out.write(0);
				out.newLine();
				out.flush();
			} catch (IOException ex) {
				out.write(1);
				out.newLine();
				out.flush();
			}

			if (url != null) {
				sendFile(url);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	private void sendFile(URL url) {
		for (ClientHandler ch : clients) {
			if (!ch.socket.isClosed()) {
				try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					 BufferedWriter out = new BufferedWriter(new OutputStreamWriter(ch.socket.getOutputStream())))
				{
					String line;
					while((line = in.readLine()) != null) {
						out.write(line);
						out.newLine();
						out.flush();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

package zad2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

	protected static List<ClientHandler> clients;

	public static void main(String[] args) {

		clients = new ArrayList<>();

		while (true) {
			try (ServerSocket server = new ServerSocket(12345)) {
				Socket socket = server.accept();
				ClientHandler hc = new ClientHandler(socket);
				Thread t = new Thread(hc);
				clients.add(hc);
				t.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

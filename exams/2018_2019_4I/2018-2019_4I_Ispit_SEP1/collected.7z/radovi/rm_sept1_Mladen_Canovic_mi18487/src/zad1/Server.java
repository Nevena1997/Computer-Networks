package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static final int PORT = 12345;

	public static void main(String[] args) {
		try (ServerSocket server = new ServerSocket(PORT)) {

			while (true) {
				Socket client = server.accept();
				System.out.println("Client connected!");
				BufferedInputStream inNetwork = new BufferedInputStream(client.getInputStream());
				BufferedWriter outNetwork = new BufferedWriter(new PrintWriter(client.getOutputStream()));
//				InputStreamReader inNetwork = new InputStreamReader(client.getInputStream());
				System.out.println("da");

				int c = 0;
				char[] path = new char[1024];
				int i = 0;
				while ((c = inNetwork.read()) != -1) {
					path[i++] = (char) c;
				}
				System.out.println("prososam");
				String f = new String(path);
				System.out.println(f);

				File file = new File(f);
				if (file.exists()){
					Thread t = new FileSupplier(file, inNetwork, outNetwork);
					t.start();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

class FileSupplier extends Thread {

	BufferedInputStream inNetwork;
	BufferedWriter outNetwork;
	File file;

	public FileSupplier(File file, BufferedInputStream inNetwork, BufferedWriter outNetwork) {
		this.file = file;
		this.inNetwork = inNetwork;
		this.outNetwork = outNetwork;
	}

	@Override
	public void run() {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		StringBuffer contentSB = new StringBuffer();
		int c = 0;
		try {
			while ((c = fis.read()) != -1) {
				contentSB.append((char) c);
			}
			fis.close();
			this.outNetwork.write(contentSB.toString());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
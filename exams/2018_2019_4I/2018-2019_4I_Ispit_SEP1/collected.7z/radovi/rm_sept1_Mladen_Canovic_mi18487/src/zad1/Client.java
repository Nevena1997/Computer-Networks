package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {
		String host = "localhost";
		int port = Server.PORT;

		try (Socket client = new Socket(host, port)) {

			InputStreamReader ir = new InputStreamReader(System.in);
//			InputStreamReader inNetwork = new InputStreamReader(client.getInputStream());
			PrintWriter outNetwork = new PrintWriter(client.getOutputStream());

			while (true) {
				char c = 0;
				char[] pathC = new char[1024];
				int i = 0;
				while ((c = (char) ir.read()) != '\n') {
					pathC[i++] = c;
					System.out.println("hereiam");
				}
				System.out.println("imout");
				String path = new String(pathC);

				System.out.println(path);
				outNetwork.print(path);
				outNetwork.flush();


			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

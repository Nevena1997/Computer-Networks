package zad2;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;


public class HTMLParser {

	public static void main(String[] args) {

		JFrame frame = new JFrame("Swing it");
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setResizable(true);

		addComponents(frame.getContentPane());

		frame.setVisible(true);
	}

	private static void addComponents(Container pane) {

		ParserCallbackImpl pc = new ParserCallbackImpl();
		HTMLEditorKit.Parser p;

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setContentType("text/html");
		try {
			// TODO: fix hardcoded path
			jep.setText(HTMLParser.getFileContent("C:\\Users\\nalog\\workspace\\rm_sept1_Mladen_Canovic_mi18487\\src\\zad2\\1.txt"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 600;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);

		JButton undoBtn = new JButton("<");
		undoBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(undoBtn, c);

		JButton redoBtn = new JButton(">");
		redoBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(redoBtn, c);

		JButton clearABtn = new JButton("ca");
		clearABtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(clearABtn, c);

	}

	private static String getFileContent(String path) throws IOException {
		FileInputStream fis = new FileInputStream(path);
		StringBuffer contentSB = new StringBuffer();
		int c = 0;
		while ((c = fis.read()) != -1) {
			contentSB.append((char) c);
		}
		fis.close();
		return contentSB.toString();
	}

}

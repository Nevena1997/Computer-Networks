package zad2;

import java.io.IOException;
import java.io.Reader;

import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserGetter extends HTMLEditorKit.Parser {

	@Override
	public void parse(Reader r, ParserCallback cb, boolean ignoreCharSet) throws IOException {

	}


}

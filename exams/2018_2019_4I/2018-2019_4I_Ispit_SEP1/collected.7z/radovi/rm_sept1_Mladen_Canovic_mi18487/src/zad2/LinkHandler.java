package zad2;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStack;
	private int index;

	public LinkHandler(JEditorPane jep) {
		this.jep = jep;
		this.urlStack = new ArrayList<URL>();
		this.index = -1;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		EventType type = e.getEventType();
		URL url = e.getURL();

		if (type == EventType.ACTIVATED && url != this.urlStack.get(this.index)) {
			try {
				this.goToPage(url);
			} catch (IOException e1) {
				jep.setText("Unable to go to that page");
			}
		}
	}

	private void goToPage(URL url) throws IOException {
		this.urlStack.add(url);
		this.index++;
		jep.setPage(url);
	}

	public void undo() throws IOException {
		if (this.index > 0) {
			this.index--;
			URL url = urlStack.get(this.index);
			this.goToPage(url);
		}
	}

	public void redo() throws IOException {
		if (this.index < urlStack.size()) {
			this.index++;
			URL url = urlStack.get(this.index);
			this.goToPage(url);
		}
	}

}

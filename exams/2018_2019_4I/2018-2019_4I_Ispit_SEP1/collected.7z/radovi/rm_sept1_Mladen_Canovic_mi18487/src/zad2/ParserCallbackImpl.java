package zad2;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImpl extends ParserCallback {
	@Override
	public void handleText(char[] data, int pos) {

	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		if (HTML.Tag.A == t) {
			// delete
		}
	}

	@Override
	public void handleEndTag(Tag t, int pos) {
		if (HTML.Tag.A == t) {
			// delete
		}
	}
}

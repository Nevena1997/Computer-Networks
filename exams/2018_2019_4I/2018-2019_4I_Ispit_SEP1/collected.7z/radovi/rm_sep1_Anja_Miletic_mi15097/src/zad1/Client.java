package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		Socket sock = null;
		Scanner sc = null;
		try {
			sock = new Socket("localhost", Server.PORT);
			sc = new Scanner(System.in);

			String filePath = sc.next();
			String fileName = filePath.substring(filePath.charAt('\\'));
			File f = new File(fileName);
			BufferedOutputStream fileOut = new BufferedOutputStream(new FileOutputStream(f));
			OutputStreamWriter out = new OutputStreamWriter(sock.getOutputStream());
			BufferedInputStream in = new BufferedInputStream(sock.getInputStream());

			out.write(filePath, 0, filePath.length());

			byte[] buf = new byte[256];
			int bytesRead = 0;
			while((bytesRead = in.read(buf)) != -1) {
				fileOut.write(buf, 0, bytesRead);
			}

			fileOut.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (sock != null) {
				try {
					sock.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}

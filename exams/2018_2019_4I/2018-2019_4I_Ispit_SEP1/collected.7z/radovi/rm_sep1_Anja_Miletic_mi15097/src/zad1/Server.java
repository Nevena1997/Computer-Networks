package zad1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import zad1.ReadFileRunnable;

public class Server{
	public static final int PORT = 12345;

	public static void main(String[] args) {
		ServerSocket conn = null;
		try {
			conn = new ServerSocket(PORT);

			while (true) {
				Socket sock = conn.accept();
				Thread t = new Thread(new ReadFileRunnable(sock));
				t.start();
			}


		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}

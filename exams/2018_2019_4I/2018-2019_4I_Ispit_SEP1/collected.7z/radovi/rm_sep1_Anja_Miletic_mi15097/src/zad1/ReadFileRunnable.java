package zad1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ReadFileRunnable implements Runnable{
	private Socket client;

	public ReadFileRunnable(Socket client) {
		this.client = client;
	}

	@Override
	public void run() {
		InputStreamReader in;
		try {
			in = new InputStreamReader(this.client.getInputStream());

			char[] filePath = new char[256];
			in.read(filePath);

			String fileP = filePath.toString().trim();

			File f = new File(fileP);
			BufferedInputStream fileIn = new BufferedInputStream(new FileInputStream(f));
			BufferedOutputStream fileOut = new BufferedOutputStream(client.getOutputStream());

			byte[] buf = new byte[256];
			int bytesRead = 0;
			while((bytesRead = fileIn.read(buf)) != -1) {
				fileOut.write(buf, 0, bytesRead);
			}

			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}

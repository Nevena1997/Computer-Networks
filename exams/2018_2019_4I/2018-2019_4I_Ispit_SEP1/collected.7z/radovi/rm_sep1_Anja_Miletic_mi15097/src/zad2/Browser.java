package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class Browser {

	public static void main(String[] args) {
		JFrame f = new JFrame("hopefully-enough-to-pass-browser");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 400);

		JEditorPane jep = addComponents(f.getContentPane());
		f.setContentPane(jep);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}

		});

	}

	private static JEditorPane addComponents(Container pane) {
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane();
		jep.add(scrollPane);
		LinkFollower lf = new LinkFollower(jep);
		jep.addHyperlinkListener(lf);

		jep.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		JButton undo = new JButton("<");
		c.gridx = 0;
		c.gridy = 1;
		jep.add(undo);
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				lf.undo();
			}
		});

		JButton redo = new JButton(">");
		c.gridx = 2;
		c.gridy = 1;
		jep.add(redo);
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				lf.redo();
			}
		});


		JButton ca = new JButton("ca");
		c.gridx = 3;
		c.gridy = 1;
		jep.add(ca);
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				lf.ca();
			}
		});
		return jep;
	}

}

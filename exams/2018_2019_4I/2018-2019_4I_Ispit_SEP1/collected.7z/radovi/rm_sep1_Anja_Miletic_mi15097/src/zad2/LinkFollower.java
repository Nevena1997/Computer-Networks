package zad2;

import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkFollower implements HyperlinkListener{
	private JEditorPane pane;
	private int index = -1;
	private URL[] urls;


	public LinkFollower(JEditorPane pane) {
		this.pane = pane;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
			try {
				this.pane.setPage(e.getURL());
				index++;
				urls[index] = e.getURL();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public void undo() {
		if (index > 0) {
			try {
				this.pane.setPage(this.urls[index--]);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void redo() {
		if (index < this.urls.length - 1 && index != -1) {
			try {
				this.pane.setPage(this.urls[index++]);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void ca() {

	}

}

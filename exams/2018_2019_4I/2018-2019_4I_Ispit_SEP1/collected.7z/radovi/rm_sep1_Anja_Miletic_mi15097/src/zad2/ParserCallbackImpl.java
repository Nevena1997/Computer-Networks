package zad2;

import java.io.Writer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{
	private boolean isInLink = false;
	private Writer out;

	public void handleStartTag(HTML.Tag tag, MutableAttributeSet x, int position) {
		if (tag == HTML.Tag.A) {
			isInLink = true;
		}
	}

	public void handleEndTag(HTML.Tag tag, MutableAttributeSet x, int position) {
		if (tag == HTML.Tag.A) {
			isInLink = false;
		}
	}

	public void handleText(char[] text, int position) {
		if (this.isInLink) {

		}
	}
}

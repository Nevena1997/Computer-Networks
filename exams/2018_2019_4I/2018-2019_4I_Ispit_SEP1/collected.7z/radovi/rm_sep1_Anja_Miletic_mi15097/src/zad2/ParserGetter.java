package zad2;

import javax.swing.text.html.HTMLEditorKit;

@SuppressWarnings("serial")
public class ParserGetter extends HTMLEditorKit{
	public HTMLEditorKit.Parser getParser() {
		return super.getParser();
	}
}

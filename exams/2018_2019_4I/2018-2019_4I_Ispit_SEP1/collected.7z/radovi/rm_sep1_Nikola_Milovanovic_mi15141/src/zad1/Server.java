package zad1;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		try(ServerSocket server = new ServerSocket(12345)){
			while(true){
				try(Socket client = server.accept()){

					InputStreamReader in = new InputStreamReader(client.getInputStream());
					int broj;
					broj = in.read();
					StringBuilder sb = new StringBuilder();
					int nesto;
					for(int i = 0; i < broj; i++){
						nesto = in.read();
						sb.append(nesto);
					}

					System.out.println(sb.toString());
				}catch(IOException ex){

				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}

	}

}

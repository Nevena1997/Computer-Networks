package zad1;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;


public class Client {

	public static void main(String[] args) {
		try(Scanner stdIn = new Scanner(System.in);) {
			Socket sock = new Socket("localhost", 12345);

			System.out.println("Unesite putanju");
			String putanja = stdIn.nextLine();
			byte[] a = putanja.getBytes();
			StringBuilder sb = new StringBuilder(putanja);
			OutputStream out = sock.getOutputStream();
			out.write(sb.length());
			//System.out.println(a);
			for(int i = 0; i < sb.length(); i++){
				out.write(sb.charAt(i));
			}
			//OutputStreamWriter out = new OutputStreamWriter(sock.getOutputStream());



		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

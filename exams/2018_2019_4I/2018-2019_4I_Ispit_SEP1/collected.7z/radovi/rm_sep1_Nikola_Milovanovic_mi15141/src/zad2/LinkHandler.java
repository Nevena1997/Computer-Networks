package zad2;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{
	private List<URL> urlStack;
	private int indeks;
	private JEditorPane jep;

	public LinkHandler(JEditorPane jep){
		this.jep = jep;
		this.indeks = -1;
		this.urlStack = new ArrayList<URL>();
	}

	public void undo(){
		if(this.indeks > 0){
			this.indeks --;
			try{
				this.jep.setPage(this.urlStack.get(indeks));
			}catch(IOException e){
				this.jep.setText("Nismo ucitali stranicuuuu ");
			}
		}
	}

	public void redo(){
		if(this.indeks + 1 < this.urlStack.size()){
			this.indeks ++;
			try{
				this.jep.setPage(this.urlStack.get(indeks));
			}catch(IOException e){
				this.jep.setText("Nismo ucitali stranicuuuu ");
			}
		}

	}

	public void ca(){
		this.jep.setText(this.jep.getText().replaceAll("<a.+?>", "").replaceAll("</a>", ""));

	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();
		URL url = e.getURL();

		if(type == HyperlinkEvent.EventType.ACTIVATED && url != this.urlStack.get(indeks)){
			goToPage(url);
			//this.jep.setText("Zastooo");
		}

	}

	public void goToPage(String urlString){
		try{
			URL url = new URL(urlString);
			goToPage(url);
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public void goToPage(URL url){

		try{
			indeks++;
			this.urlStack.add(indeks, url);
			this.jep.setPage(url);
		}catch(IOException e){
			this.jep.setText("Nismo ucitali stranicuuuu " + url);
		}
	}

}

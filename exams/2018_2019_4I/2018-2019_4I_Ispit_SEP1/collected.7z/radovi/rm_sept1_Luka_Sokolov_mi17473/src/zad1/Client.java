package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public static void main(String[] args){
		int port = 12345;
		String host = "localhost";

		BufferedWriter toServer = null;
		BufferedReader fromServer = null;
		Scanner sc = null;

		try {
			Socket s = new Socket(host, port);

			toServer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			sc = new Scanner(System.in);
			fromServer = new BufferedReader(new InputStreamReader(s.getInputStream()));

			while(true){
				System.out.println("Send message to server:");
				String text = sc.nextLine();
				toServer.write(text);
				toServer.newLine();
				toServer.flush();
				System.out.println("Sent.");

				String recieved = fromServer.readLine();
				System.out.println("I've recieved message:" + recieved);
				System.out.println(recieved);


				if(recieved.equals("stop")){
						fromServer.close();
						toServer.close();
						sc.close();
						s.close();
						break;
				}
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (toServer != null){
				try {
					toServer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else if (sc != null){
				sc.close();
			}
		}

	}
}

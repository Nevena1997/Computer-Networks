package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args){
		int port = 12345;

		BufferedWriter toClient = null;
		BufferedReader fromClients = null;

		try {
			ServerSocket server = new ServerSocket(port);

			System.out.println("Connected to server");

			Socket client = server.accept();
			System.out.println("Accepted client.");
			while(true){

				fromClients = new BufferedReader(new InputStreamReader(client.getInputStream()));
				toClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

				String recieved = fromClients.readLine();
				System.out.println("I've recieved path: " + recieved);

				/*
				if(file.exists()){
					toClient.write("0");
				} else {
					toClient.write("1");
					server.close();
				}
				*/

				toClient.write("Recieved filepath exists: here's the text");
				toClient.newLine();
				toClient.flush();
				System.out.println("Content sent back.");



				if (recieved.equals("stop")){
					toClient.write("stop");
					toClient.newLine();
					toClient.flush();
					break;
				}

			}

			toClient.close();
			fromClients.close();
			server.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

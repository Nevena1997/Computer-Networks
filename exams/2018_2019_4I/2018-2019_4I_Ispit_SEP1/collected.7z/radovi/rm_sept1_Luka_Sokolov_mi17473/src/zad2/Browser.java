package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class Browser {
	public static void main(String[] args){
		JFrame frame = new JFrame("Test");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setResizable(true);
		frame.setSize(800, 600);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}

	private static void addComponents(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);

		gbc.fill = GridBagConstraints.BOTH;
		gbc.weighty = 1;
		gbc.weightx = 1;
		gbc.gridwidth = 3;
		gbc.gridx = 0;
		gbc.gridy = 0;
		contentPane.add(jsp, gbc);

		LinkHandler lh = new LinkHandler(jep, "file:\\\\\\C:\\Users\\nalog\\workspace\\rm_sept1_Luka_Sokolov_mi17473\\1.html");
		jep.addHyperlinkListener(lh);


		JButton jbtUndo = new JButton("<");
		jbtUndo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.Undo();
			}
		});
		gbc.gridwidth = 1;
		gbc.weighty = 0;
		gbc.gridx = 0;
		gbc.gridy = 1;
		contentPane.add(jbtUndo, gbc);


		JButton jbtRedo = new JButton(">");
		jbtRedo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.Redo();
			}
		});
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 1;
		contentPane.add(jbtRedo, gbc);

		JButton jbtClear = new JButton("ca");
		jbtClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.Clear();
			}
		});
		gbc.gridwidth = 1;
		gbc.gridx = 2;
		gbc.gridy = 1;
		contentPane.add(jbtClear, gbc);

	}
}

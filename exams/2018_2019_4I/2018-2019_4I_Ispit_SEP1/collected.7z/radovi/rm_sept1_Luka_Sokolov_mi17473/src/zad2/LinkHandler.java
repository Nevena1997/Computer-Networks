package zad2;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;


public class LinkHandler implements HyperlinkListener {
	private JEditorPane jep;
	private ArrayList<URL> urlList = new ArrayList<URL>();


	public LinkHandler(JEditorPane jep, String link){
		this.jep = jep;
		URL url = null;
		try {
			url = new URL(link);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		goToPage(url);
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED){
			goToPage(e.getURL());
		}
		urlList.add(e.getURL());
	}

	public void goToPage(URL link) {
		try {
			jep.setPage(link);
			urlList.add(link);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void Undo() {
		try {
			if(urlList.isEmpty()){
				return;
			}
			jep.setPage(urlList.get(urlList.size()-1));
			urlList.set(urlList.size()-1, urlList.get(urlList.size()-1));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void Redo() {
		try {
			if(urlList.isEmpty()){
				return;
			}
			jep.setPage(urlList.get(urlList.size()+1));
			urlList.set(urlList.size()-1, urlList.get(urlList.size()+1));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void Clear() {
		String s = jep.getText();
		System.out.println(s);
		String tmp = s.replaceAll("<a .*", " ");
		jep.setText(tmp);
	}

}

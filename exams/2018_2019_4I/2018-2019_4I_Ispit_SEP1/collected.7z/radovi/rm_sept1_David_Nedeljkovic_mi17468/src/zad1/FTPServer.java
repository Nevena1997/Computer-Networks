package zad1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
public class FTPServer {

	public static void main(String[] args) {

		BufferedReader bufRead = null;
		PrintWriter out = null;

		System.out.println("Osluskujem na portu 12345" );
		try (ServerSocket server = new ServerSocket(12345)){
			Socket client = server.accept();

			bufRead = new BufferedReader(new InputStreamReader(client.getInputStream(), "UTF-8"));
			out = new PrintWriter(client.getOutputStream());

			while (true) {
				try {
					String putanja = bufRead.readLine();
					//out.println(putanja); // deo pod a)
					//out.flush();			// deo pod a)

					// slanje indikatora
					if (putanja.isEmpty()) {
						out.print(0);
					}
					else {
						out.print(1);
						client.close();
					}

					StringBuffer str = new StringBuffer();
					FileReader fr = new FileReader(putanja);
					int c;
					while ((c = fr.read()) != -1) {
						str.append((char)c);
					}
					String zaSlanje = str.toString();
					out.println(zaSlanje);
					out.println('x');
					out.flush();

				} catch (Exception e) {
					// TODO: handle exception
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (bufRead != null) {
					bufRead.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

	}

}

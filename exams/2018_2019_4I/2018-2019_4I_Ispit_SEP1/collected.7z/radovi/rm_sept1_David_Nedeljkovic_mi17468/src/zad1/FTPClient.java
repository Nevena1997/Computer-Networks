package zad1;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class FTPClient {

	public static void main(String[] args) {

		String host = "localhost";
		BufferedReader bufRead = null;
		PrintWriter out = null;
		BufferedReader in = null;

		try (Socket connection = new Socket(host, 12345)){

			bufRead = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
			in = new BufferedReader(new InputStreamReader(System.in));
			out = new PrintWriter(connection.getOutputStream());

			while (true) {
				System.out.println("Ucitaj putanju: ");
				String putanja = in.readLine();
				out.println(putanja);
				out.flush();

				int indikator;
				if ((indikator = bufRead.read()) != -1) {
					if ((int)indikator == 0) {
						StringBuffer buffer = new StringBuffer(4096);
						int c;
						while ((c = bufRead.read())  != -1) {
							if ((char)c != 'x') {
								buffer.append((char)c);
							}
							else {
								break;
							}
						}
						//System.out.println(buffer.toString().trim());

						FileWriter fWrite = new FileWriter("izlaz.txt");
						fWrite.write(buffer.toString().trim()); // ne upisuje u fajl ...
					}
					else {
						System.out.println("Prekida se...");
					}
				}
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (bufRead != null) {
					bufRead.close();
				}
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}


	}

}

package zad2;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkFollower implements HyperlinkListener{

	private JEditorPane jpane;
	private List<URL> lista;
	private int index;

	public LinkFollower(JEditorPane jpane) {
		super();
		this.jpane = jpane;
		this.lista = new ArrayList<>();
		this.index = -1;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED && (evt.getURL() != lista.get(index))) {
			goToPage(evt.getURL());
		}
	}

	public void goUndo() {
		if (index > 0) {
			index--;
			try {
				jpane.setPage(lista.get(index));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void goRedo() {
		if (index + 1 < lista.size()) {
			try {
				jpane.setPage(lista.get(index+1));
				index++;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private void goToPage(URL u) {
		lista.add(index + 1, u);
		index++;
		for (int i = index + 1; i < lista.size()-1; ) {
			lista.remove(index);
		}
		try {
			jpane.setPage(u);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void goToPage(String adresa) {
		try {
			URL u = new URL(adresa);
			goToPage(u);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

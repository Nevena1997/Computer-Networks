package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class WebBrowser {

	public final static String adresa = "file:///C:/Users/nalog/Desktop/rm_sept1_David_Nedeljkovic_mi17468/1.html";

	public static void main(String[] args) {

		JFrame jframe = new JFrame("test");
		jframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		jframe.setSize(600, 513);
		jframe.setResizable(true);

		addComponents(jframe.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				jframe.setVisible(true);
			}
		});

	}

	private static void addComponents(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jpane = new JEditorPane();
		jpane.setEditable(false);
		JScrollPane jscroll = new JScrollPane(jpane);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 1;
		c.weighty = 1;
		contentPane.add(jscroll, c);

		LinkFollower lf = new LinkFollower(jpane);
		jpane.addHyperlinkListener(lf);
		lf.goToPage(adresa);

		JButton btn1 = new JButton("<");
		btn1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lf.goUndo();

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		contentPane.add(btn1, c);

		JButton btn2 = new JButton(">");
		btn2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lf.goRedo();

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		contentPane.add(btn2, c);

		JButton btn3 = new JButton("ca");
		btn3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jpane.setText(jpane.getText().replaceAll("<a[^>]*?>", ""));
				jpane.setText(jpane.getText().replaceAll("</a>", ""));

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		contentPane.add(btn3, c);

	}

}

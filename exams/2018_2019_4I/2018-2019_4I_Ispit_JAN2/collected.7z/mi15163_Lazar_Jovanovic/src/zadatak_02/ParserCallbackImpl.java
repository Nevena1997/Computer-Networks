package zadatak_02;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImpl extends ParserCallback {
	StringBuilder sb;
	int width = 0;

	boolean inH1 = false;
	boolean inH2 = false;
	boolean inH3 = false;
	boolean inH4 = false;
	boolean inH5 = false;
	boolean inH6 = false;

	public ParserCallbackImpl(StringBuilder sb) {
		this.sb = sb;
	}

	@Override
	public void handleStartTag(Tag tag, MutableAttributeSet arg1, int arg2) {
		if (tag == Tag.H1) {
			if (width > 0) closeAll();

			sb.append("<ul>");

			width++;
			inH1 = true;
		} else if (tag == Tag.H2) {
			if (width > 1) closeAll();

			sb.append("<ul>");

			width++;
			inH2 = true;
		} else if (tag == Tag.H3) {
			if (width > 2) closeAll();

			sb.append("<ul>");

			width++;
			inH3 = true;
		} else if (tag == Tag.H4) {
			if (width > 3) closeAll();

			sb.append("<ul>");

			width++;
			inH4 = true;
		} else if (tag == Tag.H5) {
			if (width > 4) closeAll();

			sb.append("<ul>");

			width++;
			inH5 = true;
		} else if (tag == Tag.H6) {
			if (width > 5) closeAll();

			sb.append("<ul>");

			width++;
			inH6 = true;
		}
	}

	@Override
	public void handleText(char[] text, int arg1) {
		if (inH1 || inH2 || inH3 || inH4 || inH5 || inH6) {
			sb.append(text);
		}
	}

	@Override
	public void handleEndTag(Tag tag, int arg1) {
		if (tag == Tag.H1) {
			inH1 = false;
		} else if (tag == Tag.H2) {
			inH2 = false;
		} else if (tag == Tag.H3) {
			inH3 = false;
		} else if (tag == Tag.H4) {
			inH4 = false;
		} else if (tag == Tag.H5) {
			inH5 = false;
		} else if (tag == Tag.H6) {
			inH6 = false;
		}
	}

	private void closeAll() {
		for (int i = 0; i < width; i++) {
			sb.append("</ul>\r\n");
		}

		width = 0;
	}
}

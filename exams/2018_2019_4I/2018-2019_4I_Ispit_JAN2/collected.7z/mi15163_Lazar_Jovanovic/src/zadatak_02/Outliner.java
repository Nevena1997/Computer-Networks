package zadatak_02;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Outliner {
	public static final String HOMEPAGE = "file:1.html";

	public static void main(String[] args) {
		JFrame f = new JFrame("xd");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		GridBagLayout grid = new GridBagLayout();
		pane.setLayout(grid);
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 600;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JTextArea linkPreview = new JTextArea("Insert link");
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(linkPreview, c);

		LinkHandler lh = new LinkHandler(jep, linkPreview, HOMEPAGE);
		jep.addHyperlinkListener(lh);

		JButton btnShow = new JButton("Prikazi");
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.show();
			}
		});
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnShow, c);

		JButton btnContent = new JButton("Sadrzaj");
		btnContent.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.content();
			}
		});
		c.gridx = 2;
		pane.add(btnContent, c);
	}
}

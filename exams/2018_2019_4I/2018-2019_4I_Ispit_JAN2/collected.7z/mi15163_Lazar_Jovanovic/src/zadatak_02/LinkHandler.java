package zadatak_02;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

public class LinkHandler implements HyperlinkListener {
	private JEditorPane jep;
	private JTextArea linkPreview;
	private URL currUrl = null;

	public LinkHandler(JEditorPane jep, JTextArea linkPreview,String homePage) {
		this.jep = jep;
		this.linkPreview = linkPreview;
		this.goToPage(homePage);
	}


	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
			goToPage(evt.getURL());
		}

	}

	private void goToPage(URL url) {
		try {
			this.jep.setPage(url);
		} catch (IOException e) {
			e.printStackTrace();
		}

		this.linkPreview.setText(url.toString());
	}

	private void goToPage(String path) {
		try {
			URL url = new URL(path);
			currUrl = url;
			goToPage(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			currUrl = null;
		}
	}

	public void show() {
		goToPage(this.linkPreview.getText());
	}

	public void content() {
		StringBuilder sb = new StringBuilder();
		ParserGetter pg = new ParserGetter();
		ParserCallbackImpl pc = new ParserCallbackImpl(sb);
		HTMLEditorKit.Parser p = pg.getParser();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(currUrl.openStream()));
			p.parse(in, pc, true);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(sb.toString());
		this.jep.setText(sb.toString());
	}
}

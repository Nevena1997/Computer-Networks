package zadatak_01;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Server {
	public static final int DEFAULT_PORT = 12345;

	public static void main(String[] args) {
		try (ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()) {
			if (!serverChannel.isOpen() || !selector.isOpen()) {
				System.err.println("Couldn't open server channel and/or selector");
				System.exit(1);
			}

			serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			Map<SocketAddress, Integer> timesSent = new HashMap();

			long lastTime = Integer.MAX_VALUE; // Da bi prvi put usao u petlju
			while (true) {
				if (System.currentTimeMillis() - lastTime < 5000) {
					continue;
				}
				lastTime = System.currentTimeMillis();

				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();
				while (iterator.hasNext()) {
					SelectionKey key = iterator.next();
					iterator.remove();

					try {
						if (key.isAcceptable()) {
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);

							System.out.println("Otvaram konekciju sa " + client.getRemoteAddress());
							timesSent.put(client.getRemoteAddress(), 0);

							ByteBuffer buffer = ByteBuffer.allocate(6);
							SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
							clientKey.attach(buffer);
						} else if (key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer buffer = (ByteBuffer) key.attachment();

							int iter = timesSent.get(client.getRemoteAddress());

							if (iter < 5 ) {
								timesSent.put(client.getRemoteAddress(), iter+1);

								buffer.clear();
								buffer.rewind();

								Random rand = new Random();
								char a = (char) rand.nextInt(255);
								buffer.put((byte) a);
								buffer.flip();

								System.out.println("Saljem " + (int) a);
								client.write(buffer);
							} else {
								System.out.println("Zatvaram konekciju sa " + client.getRemoteAddress());
								System.out.println("Poslao sam ukupno " + timesSent.get(client.getRemoteAddress()));
								client.close();
								key.cancel();
							}
						}
					} catch (IOException e) {
						key.cancel();
						try {
							key.channel().close();
						} catch (IOException ex) {
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

package zadatak_01;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		String host = "localhost";
		try (Socket sock = new Socket(host, Server.DEFAULT_PORT)) {
			BufferedInputStream in = new BufferedInputStream(sock.getInputStream());

			while (true) {

				int b;
				while ((b = in.read()) != -1) {
					System.out.println(b);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

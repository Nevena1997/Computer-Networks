package zad1;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;


public class Client {

	public static void main(String[] args) {

		Socket client;
		try {
			client = new Socket("localhost", 12345);
			InputStreamReader in = new InputStreamReader(client.getInputStream());
			BufferedInputStream b = new BufferedInputStream(client.getInputStream());
			byte[] buf = new byte[4];
			ByteBuffer bb = ByteBuffer.allocate(4);
			bb.asIntBuffer();

			while(true){
				b.read(buf);
				bb.put(buf);
				System.out.println(bb.getInt());

			}
			//ovde ispisivanje nije htelo, pa sam ispisivala u konzoli za server da bih proverila
			//da li se ispisuje slucajni
			//ceo broj

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}


	}

}

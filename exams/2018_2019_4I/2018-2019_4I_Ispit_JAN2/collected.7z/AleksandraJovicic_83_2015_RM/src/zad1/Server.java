package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static int intRandom(){
		return (int)(Math.random()*Integer.MAX_VALUE);
	}

	public static void main(String[] args) {

		try {
			ServerSocketChannel serverChannel = ServerSocketChannel.open();
			Selector selector = Selector.open();

			serverChannel.bind(new InetSocketAddress(12345));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			while(true){
				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();
				while(iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();
					try{
						if(key.isAcceptable()){

							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							SelectionKey key2 =  client.register(selector, SelectionKey.OP_WRITE);
							ByteBuffer bb = ByteBuffer.allocate(4);
							bb.putInt(intRandom());
							bb.flip();
							key2.attach(bb);
						}
						else if(key.isWritable()){
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer bb = (ByteBuffer) key.attachment();

							if(!bb.hasRemaining()){
								bb.clear();
								bb.putInt(intRandom());
								bb.flip();
								System.out.println(bb.getInt());
								client.write(bb);
							}else{
								System.out.println(bb.getInt());
								client.write(bb);

							}
						}



					}catch(IOException e){

						key.cancel();

						try{
							key.channel().close();
						}catch(IOException e2){

						}

					}

					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}




		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

}

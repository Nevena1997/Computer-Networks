package zad2;

import javax.swing.JEditorPane;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class PSI extends HTMLEditorKit.ParserCallback{

	private int level;
	private StringBuffer jep;
	private  boolean flagH;

	public PSI(StringBuffer jep){
		this.jep = jep;
		this.flagH = false;
	}

	public void handleStartTag(HTML.Tag tag, int position){

		int newLevel = 0;
		if(tag == HTML.Tag.H1){
			newLevel = 1;
		}else if(tag == HTML.Tag.H2){
			newLevel = 2;
		}else if(tag == HTML.Tag.H3){
			newLevel = 3;
		}else if(tag == HTML.Tag.H4){
			newLevel = 4;
		}else if(tag == HTML.Tag.H5){
			newLevel = 5;
		}else if(tag == HTML.Tag.H6){
			newLevel = 6;
		}

		if(newLevel != 0){
			if(newLevel > this.level){
				for(int i = 0; i<newLevel-this.level;i++){
					jep.append("	");
				}
			}else if(newLevel < this.level)
			{
				for(int i = 0; i<newLevel;i++){
					jep.append("	");

				}
			}
			this.level = newLevel;
			this.flagH = true;
		}
	}

	public void handleText(char[] text, int position){

		if(this.flagH){
			jep.append(new String(text));
		}

	}

	public void handleEndTag(HTML.Tag tag, int position){

		if(tag == HTML.Tag.H1 || tag == HTML.Tag.H2 || tag == HTML.Tag.H3 || tag == HTML.Tag.H4 || tag == HTML.Tag.H5 || tag == HTML.Tag.H6){
			this.flagH = false;
			jep.append("\r\n");
		}

	}

}

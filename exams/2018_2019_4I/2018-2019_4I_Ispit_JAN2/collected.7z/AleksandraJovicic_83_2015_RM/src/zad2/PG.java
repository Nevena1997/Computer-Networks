package zad2;

import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class PG extends HTMLEditorKit{

	public HTMLEditorKit.Parser getParser(){
		return super.getParser();
	}

}

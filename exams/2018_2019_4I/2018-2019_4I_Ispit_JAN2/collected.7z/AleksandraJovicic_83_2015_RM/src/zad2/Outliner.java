package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

import sun.net.www.content.image.jpeg;

public class Outliner {

	private static final String HOME_PAGE = "file:///C:/Users/nalog/Desktop/AleksandraJovicic_83_2015_RM/src/zad2/1.html";

	public static void main(String[] args) {

		JFrame jf = new JFrame("xd");
		jf.setSize(600, 600);
		jf.setResizable(true);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(jf.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				jf.setVisible(true);
			}
		});

	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		//jep.setEditable(false);
		JScrollPane jsc = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(jsc, c);

		JTextArea jta = new JTextArea(HOME_PAGE);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(jta, c);

		JButton jb1 = new JButton("Prikazi");
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				URL url;
				try {
					url = new URL(HOME_PAGE);
					jep.setPage(url);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(jb1, c);

		JButton jb2 = new JButton("Sadrzaj");
		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				PG pg = new PG();
				HTMLEditorKit.Parser pp = pg.getParser();
				StringBuffer str = new StringBuffer("");

				PSI pci = new PSI(str);


				try {
					URL url = new URL(HOME_PAGE);
					InputStreamReader in = new InputStreamReader(url.openStream());
					pp.parse(in, pci, true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				jep.setText(str.toString());
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(jb2, c);







	}

}

package zadatak01;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Server {

	public static void main(String[] args) {
		int port = 12345;

		System.out.println("Starting server...");

		BufferedWriter out = null;
		//Socket client = null;

		try (ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()) {

			serverChannel.bind(new InetSocketAddress(port));
			serverChannel.configureBlocking(false);

			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			/*
			client = server.accept();

			out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			while (true) {
				Random rand = new Random();
				int random = rand.nextInt(100);
				out.write(random);
				out.newLine();
				out.flush();
			}
			*/

			while (true) {
				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while (iterator.hasNext()) {

					SelectionKey key = iterator.next();
					iterator.remove();

					try {
						if (key.isAcceptable()) {
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							System.out.println("Server connected to client " + client.getLocalAddress());
							client.configureBlocking(false);
							SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);

							ByteBuffer buffer = ByteBuffer.allocate(4);
							Random rand = new Random();
							int random = rand.nextInt(100);
							buffer.putInt(random);
							buffer.flip();
							key2.attach(buffer);
						} else if (key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer buff = (ByteBuffer) key.attachment();

							while (!buff.hasRemaining()) {
								buff.clear();
								Random rand = new Random();
								int random = rand.nextInt(100);
								buff.putInt(random);
								buff.flip();
							}

							client.write(buff);
						}
					} catch (IOException ex) {

					}

				}
 			}

			//client.close();
		} catch (SocketException ex) {

		} catch (IOException ex) {
			System.err.println(ex);
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				//if (client != null) {
					//client.close();
				//}
			} catch (IOException ex) {

			}
		}
	}

	/*public void fiveSeconds() {
		Date now = new Date();
		@SuppressWarnings("deprecation")
		int seconds = now.getSeconds();
		@SuppressWarnings("deprecation")
		now.setSeconds(seconds + 5);
		Date date = new Date();
		while (date != now) {
			date = new Date();
		}
	}*/

}

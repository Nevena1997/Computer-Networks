package zadatak01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SocketChannel;

public class Client {

	public static void main(String[] args) {
		int port = 12345;
		String host = "localhost";

		BufferedReader in = null;

		try (Socket client = new Socket(host, port)) {

			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			//ByteBuffer buff = ByteBuffer.allocate(4);
			//IntBuffer view = buff.asIntBuffer();

			//SocketChannel s = client.getChannel();

			while (true) {

				int num;
				while ((num = in.read()) != -1) {
					System.out.println(num);
				}

				/*
				buff.clear();
				while (buff.hasRemaining())
					s.read(buff);

				buff.rewind();
				int value = view.get();
				buff.clear();
				buff.flip();
				System.out.println(value);
				*/

			}

		} catch (IOException ex) {
			System.err.println(ex);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {

			}
		}
	}

}

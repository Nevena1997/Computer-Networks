package zadatak02;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class TagStripper extends HTMLEditorKit.ParserCallback {

	Writer out;
	String lineSeparator = System.getProperty("line.separator", "\r\n");
	int level = 0;
	int headerLevel = 0;
	boolean inHeader = false;

	public TagStripper(Writer out) {
		this.out = out;
	}

	public void handleText(char[] text, int position) {
		if (inHeader) {
			try {
				this.out.write(text);
				this.out.write(lineSeparator);
				this.out.flush();
			} catch (IOException ex) {
				System.err.println(ex);
			}
		}
	}

	public void handleStartTag(HTML.Tag tag, MutableAttributeSet attributes, int position) {
		if (tag == HTML.Tag.H1) {
			inHeader = true;
			headerLevel = 1;
		} else if (tag == HTML.Tag.H2) {
			inHeader = true;
			headerLevel = 2;
		} else if (tag == HTML.Tag.H3) {
			inHeader = true;
			headerLevel = 3;
		} else if (tag == HTML.Tag.H4) {
			inHeader = true;
			headerLevel = 4;
		} else if (tag == HTML.Tag.H5) {
			inHeader = true;
			headerLevel = 5;
		} else if (tag == HTML.Tag.H6) {
			inHeader = true;
			headerLevel = 6;
		}
	}


	public void handleEndTag(HTML.Tag tag, int position) {
		if (tag == HTML.Tag.H1 || tag == HTML.Tag.H2 || tag == HTML.Tag.H3 || tag == HTML.Tag.H4 || tag == HTML.Tag.H5 || tag == HTML.Tag.H6) {
			inHeader = false;
		}

		if (tag == HTML.Tag.HTML) {
			try {
				this.out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}



}

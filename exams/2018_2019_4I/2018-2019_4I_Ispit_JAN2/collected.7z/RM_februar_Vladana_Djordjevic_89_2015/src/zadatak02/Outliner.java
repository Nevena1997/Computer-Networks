package zadatak02;

import java.net.URL;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class Outliner {

	//public static URL URL = "FILE:///C:\Users\Desktop\file1.html";

	public static void main(String[] args) {
		JFrame f = new JFrame("xd");
		f.setSize(800, 600);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponents(f);

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				f.setVisible(true);
			}
		});
	}

	public static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 510;

		pane.add(scrollPane, c);

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 10;
		pane.add(addressBar, c);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String url = addressBar.getText();
				url = url.trim();
				//String u = "file:///C:/Users/nalog/Desktop/RM_februar_Vladana_Djordjevic_89_2015/RM_februar_Vladana_Djordjevic_89_2015/" + url;
				lh.goToPage(url);
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnPrikazi, c);

		ParserGetter pg = new ParserGetter();
		HTMLEditorKit.Parser p = pg.getParser();

		JButton btnSadrzaj = new JButton("Sadrzaj");
		btnSadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String url = addressBar.getText();
					URL u = new URL(url);
					OutputStreamWriter fout = new OutputStreamWriter( new FileOutputStream(url));
					HTMLEditorKit.ParserCallback pc = new TagStripper(fout);
					InputStreamReader in = new InputStreamReader(u.openStream(), "UTF-8");
					p.parse(in, pc, false);
					jep.setPage(url);
				} catch (FileNotFoundException ex) {
					System.err.println("File doesn't exist");
				} catch (IOException ex) {
					System.err.println(ex);
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnSadrzaj, c);

	}

}

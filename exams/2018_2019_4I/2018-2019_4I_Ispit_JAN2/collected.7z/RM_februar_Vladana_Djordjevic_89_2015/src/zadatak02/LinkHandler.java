package zadatak02;

import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	JEditorPane jep;

	public LinkHandler(JEditorPane jep) {
		this.jep = jep;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
			try {
				this.jep.setPage(evt.getURL());
			} catch (IOException ex) {
				System.err.println(ex);
			}
		}
	}

	public void goToPage(URL url) {
		try {
			this.jep.setPage(url);
		} catch (IOException ex) {

		}
	}

	public void goToPage(String url) {
		try {

			URL u = new URL(url);
			this.goToPage(u);
		} catch (IOException ex) {

		}
	}


}

package drugi;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Outliner {

	public static void main(String[] args) {

		JFrame jf = new JFrame("xd");
		jf.setSize(800, 600);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		AddComponents(jf);

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				jf.setVisible(true);
			}
		});

	}

	static void AddComponents(JFrame pane){
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();


		try{
			URL url = new URL("FILE:///C:\\Users\\nalog\\Desktop\\mi15335FilipKristic\\Ispit\\1.html");
		jep.setPage(url);
		}
		catch(MalformedURLException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}

		JPanel jpanel = new JPanel();

		JTextField urlInput = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = 1;
		jpanel.add(urlInput, c);

		JButton prikaziBtn = new JButton();
		prikaziBtn.setText("Prikazi");
		prikaziBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String s = urlInput.getText();
				try{
				URL url = new URL("FILE", "localhost", s);
				jep.setPage(url);
				}
				catch(MalformedURLException e){e.printStackTrace();}
				catch(IOException e){e.printStackTrace();}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 0;
		jpanel.add(prikaziBtn, c);

		JButton sadrzajBtn = new JButton();
		sadrzajBtn.setText("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 0;
		jpanel.add(sadrzajBtn, c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 20;
		c.ipady = 1;
		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = 0;
		pane.add(jpanel, c);

		JScrollPane jsp = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1000;
		c.gridy = 1000;
		c.ipadx = 800;
		c.ipady = 600;
		c.weightx = 100;
		c.weighty = 100;
		c.gridwidth = 1;

		pane.add(jsp,c);


	}

}

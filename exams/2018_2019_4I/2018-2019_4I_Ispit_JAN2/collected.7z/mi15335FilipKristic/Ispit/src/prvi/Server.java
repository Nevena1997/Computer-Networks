package prvi;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Server {

	public static void main(String[] args){
		final int port = 12345;

		try(ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open()){
			server.bind(new InetSocketAddress(port));
			server.configureBlocking(false);
			server.register(selector, SelectionKey.OP_ACCEPT);

			while(true){
				selector.select();
				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> it = readyKeys.iterator();

				while(it.hasNext()){
					SelectionKey key = it.next();
					it.remove();

					ByteBuffer buffer = ByteBuffer.allocate(20);

					if(key.isAcceptable()){
						ServerSocketChannel srvChannel = (ServerSocketChannel)key.channel();
						SocketChannel client = srvChannel.accept();
						client.configureBlocking(false);
						key.attach(buffer);

					}
					if(key.isWritable()){
						System.out.println("Writable");
						SocketChannel client = (SocketChannel)key.channel();
						buffer = (ByteBuffer)key.attachment();

						Random r = new Random();
						Date time = new Date();
						int seconds = time.getSeconds();
						int i = 0;
						while(i < 5){
							Date time2 = new Date();
							int secondsNow = time2.getSeconds();
							if((secondsNow - seconds) >= 5 ){
								int num = r.nextInt();
								buffer.putInt(num);
								buffer.flip();
								client.write(buffer);
								i++;
								buffer.rewind();
							}
						}

					}
				}
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}

}

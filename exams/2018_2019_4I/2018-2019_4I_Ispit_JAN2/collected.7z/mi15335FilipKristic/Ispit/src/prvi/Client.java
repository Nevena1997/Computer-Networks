package prvi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {
		final int port = 12345;
		BufferedReader in = null;
		Socket connection = null;
		try{
			connection = new Socket("localhost", port);
			in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			int num;
			while(true){
				if(!connection.isConnected()){
					break;
				}
				num = in.read();
				System.out.println(num);
			}
		}
		catch(IOException e){
			System.err.println("Failed to connect to server at port: " + port);
		}
		finally{
			if(connection != null){
				try{
					connection.close();
				}
				catch(IOException e){}
			}
			if(in != null){
				try{
					in.close();
				}
				catch(IOException e){}
			}
		}
	}

}

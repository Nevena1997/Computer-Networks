package RM_pismeni;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class client {

	public static void main(String[] args) {

		try (Socket connection = new Socket("localhost", 12345);) {
			PrintWriter out = new PrintWriter(connection.getOutputStream());
			BufferedInputStream in = new BufferedInputStream(connection.getInputStream());

			System.out.println("Connected to server");
			out.print("Hello server!\n");

			int br;
			while((br = in.read()) != -1){
				System.out.println(br);
			}

			in.close();
			out.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

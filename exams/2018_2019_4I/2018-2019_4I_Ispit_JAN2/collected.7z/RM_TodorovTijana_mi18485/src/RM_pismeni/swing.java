package RM_pismeni;

import java.awt.Container;
import java.awt.GridBagConstraints;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class swing {
	final private static String HOME = "http/www.filip_maric/";
	public static void main(String[] args) {

		JFrame f = new JFrame();
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(400, 300);
		f.setVisible(false);
		f.setResizable(false);

		addComponents(f.getContentPane());

		new Runnable() {
			public void run() {
				f.setVisible(true);
			}
		};
	}

	private static void addComponents(Container pane) {

		pane.getContainerListeners();
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setVisible(false);
		JScrollPane jsp = new JScrollPane(jep);
		/*podesavanje*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 3;
		c.weightx = 10;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridheight = 0;
		c.gridwidth = 0;

		pane.add(jsp, c);
		JTextArea jarea = new JTextArea(HOME);
		/*podesavanje*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 10;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridheight = 0;
		c.gridwidth = 0;
		pane.add(jarea, c);

		JTextField jfild = new JTextField();
		/*podesavanje*/
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 10;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridheight = 0;
		c.gridwidth = 0;
		pane.add(jfild,c);

		JButton btnPrikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;

		/*ukljuci dugme*/
		btnPrikazi.addActionListener(null);
		/*podesavanja*/
		c.gridx = 4;
		c.gridy = 0;
		c.weightx = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridheight = 0;
		c.gridwidth = 0;
		pane.add(btnPrikazi, c);

		JButton btnSadrzi = new JButton("Sadrzi");
		c.fill = GridBagConstraints.HORIZONTAL;
		/*ukljuci dugme*/
		btnSadrzi.addActionListener(null);
		/*podesavanja*/
		c.gridx = 6;
		c.gridy = 0;
		c.weightx = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridheight = 0;
		c.gridwidth = 0;
		pane.add(btnSadrzi, c);
	}
}

package prvi;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Random;


public class NonBlockServer {
	public static void main(String[] args){
		int port = 12345;
		try(ServerSocketChannel serverSocket = ServerSocketChannel.open();Selector selector = Selector.open()){
			serverSocket.bind(new InetSocketAddress(port));
			serverSocket.configureBlocking(false);
			serverSocket.register(selector, SelectionKey.OP_ACCEPT);


			while(true){
				selector.select();
				java.util.Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

				while(iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();

					try{
						if(key.isAcceptable()){

							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							System.out.println("connected to client " + client );
							client.configureBlocking(false);
							client.register(selector, SelectionKey.OP_WRITE);

						}
						else if(key.isWritable()){
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer buffer = ByteBuffer.allocate(1);

							Random rand = new Random();

							for(int i =0;i<5;i++){

								int broj = rand.nextInt(30);
								System.out.println(broj);
								buffer.put((byte)broj);

								buffer.flip();


								client.write(buffer);
								buffer.clear();
								Thread.sleep(5000);
							}
							/*
							 * nisam siguran da li moram(donje naredbe) ali tako prekidam konekciju cim
							 * posaljem 5 brojeva
							 */

							key.cancel();
							key.channel().close();

						}
					}catch (Exception e) {
						// TODO: handle exception
						key.cancel();
						key.channel().close();
					}
				}

				}
			}catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	}

}

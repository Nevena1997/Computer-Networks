package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketClient {

	public static void main(String[] args) {
		int port = 12345;
		String host = "localhost";

		BufferedReader in = null;
		BufferedWriter out = null;
		try(Socket client = new Socket(host,port)){

			in=new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			while(true){
				int broj;

				if((broj = in.read()) == -1){
					break;

				}

				System.out.println(broj);
			}
		}catch (UnknownHostException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally{
			try {
				if(in != null){
					in.close();
				}
				if(out != null){
					out.close();
				}
			} catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}

	}

}

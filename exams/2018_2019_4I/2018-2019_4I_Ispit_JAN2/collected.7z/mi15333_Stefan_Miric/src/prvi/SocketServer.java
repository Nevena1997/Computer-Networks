package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

public class SocketServer {

	public static void main(String[] args) {
		int port = 12345;

		try(ServerSocket server = new ServerSocket(port)){

			System.out.println("connented to " + port);
			Socket client = server.accept();
			System.out.println("accepted socket " + client);

			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			int poslato = 0;
			while(poslato < 10){
				Random rand = new Random();
				int broj = rand.nextInt(100);
				out.write(broj);
				out.newLine();
				out.flush();
				poslato++;
			}
			in.close();
			out.close();
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}

package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class WebBrowser {

	public static void main(String[] args) {
		JFrame f = new JFrame("xd");
		f.setResizable(true);
		f.setSize(800, 600);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);


		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});

	}


	public static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridheight=3;
		c.gridwidth=4;
		c.weightx=1;
		c.weighty=1;
		c.ipadx=0;
		c.ipady=480;
		pane.add(scroll,c);
	/*	try{
			jep.setPage("file:///C:/Users/nalog/Desktop/mi15333_Stefan_Miric/src/drugi/file1.html");
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		} */

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);

		//lh.goToPage("file:///C:/Users/nalog/Desktop/mi15333_Stefan_Miric/src/drugi/file1.html");

		JTextArea txtArea = new JTextArea(1,1);
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=1;
		c.weighty=2;
		c.ipadx=1;
		c.ipady=2;
		pane.add(txtArea,c);


		JButton prikaziBtn = new JButton("prikazi");
		prikaziBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String s= txtArea.getText();
					lh.goToPage(s);
			}
		});
		c.gridx=1;
		c.gridy=0;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=0;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		pane.add(prikaziBtn,c);

		JButton sadrzajBtn = new JButton("sadrzaj");
			sadrzajBtn.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub

				}
			});
		c.gridx=2;
		c.gridy=0;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=0;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		pane.add(sadrzajBtn,c);
	}

}

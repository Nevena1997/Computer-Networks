package drugi;

import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane jep;

	 public LinkHandler(JEditorPane jep) {
		// TODO Auto-generated constructor stub
		this.jep=jep;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		// TODO Auto-generated method stub
		EventType type = e.getEventType();
		URL u = e.getURL();

		if(type == EventType.ACTIVATED){
			goToPage(u);
		}
	}

	public void goToPage(URL url){
		try{

			this.jep.setPage(url);
		}catch (IOException e) {
			// TODO: handle exception
			this.jep.setContentType("text/html");
			this.jep.setText("<html> greska </html>");
		}
	}

	public void goToPage(String urlString){
		try{
			URL url = new URL(urlString);
			goToPage(url);
		}catch (IOException e) {
			// TODO: handle exception
			this.jep.setContentType("text/html");
			this.jep.setText("<html> greska </html>");

		}
	}

}

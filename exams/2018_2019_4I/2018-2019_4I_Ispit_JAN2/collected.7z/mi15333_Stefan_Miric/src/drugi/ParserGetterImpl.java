package drugi;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML.Tag;


public class ParserGetterImpl extends HTMLEditorKit.ParserCallback{

	private JEditorPane jep;
	private char tab = '\t';
	private int level;
	private boolean inTag=false;
	private StringBuilder sb;


	public ParserGetterImpl(JEditorPane jep){
		this.jep=jep;
		this.level = -1;
		this.sb=new StringBuilder();
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		// TODO Auto-generated method stub
		if(t==Tag.H1){
			this.level=1;
			inTag=true;
		}
		else if(t==Tag.H2){
			this.level=2;
			inTag=true;
		}
		else if(t==Tag.H3){
			this.level=3;
			inTag=true;
		}
		else if(t==Tag.H4){
			this.level=4;
			inTag=true;
		}
		else if(t==Tag.H5){
			this.level=5;
			inTag=true;
		}
		else if(t==Tag.H6){
			this.level=6;
			inTag=true;
		}
		if(inTag){
			sb.append("<li>");
			for(int i =0; i< level;i++){
				sb.append(tab);
			}
		}
	}


	@Override
	public void handleEndTag(Tag t, int pos) {
		if(t==Tag.HTML){
			sb.append("</ul>");
			jep.setText(sb.toString());
		}
		if(inTag){
			sb.append("</li>\n");
			inTag=false;
			}
	}

	@Override
	public void handleText(char[] data, int pos) {
		if(inTag)
			sb.append(data);
	}

}

package drugi;

import javax.swing.text.html.HTMLEditorKit;

public class ParserGetter extends HTMLEditorKit{

	/*
	 * bukvalno sam zaboravio sta treba da se vrati :( i ne mogu da povezem ni da proverim
	 * da li dobro parsira
	 */
	public ParserGetter(){
		super.getParser();
	}

}

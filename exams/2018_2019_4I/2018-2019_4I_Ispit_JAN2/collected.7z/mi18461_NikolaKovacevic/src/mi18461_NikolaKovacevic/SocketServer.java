package mi18461_NikolaKovacevic;

import java.nio.*;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashSet;

public class SocketServer {

	public static int port = 12345;

	public static void main(String[] args) {

	SocketAddress addr = new InetSocketAddress(port);
	Selector selector = null;

	try (ServerSocketChannel server = ServerSocketChannel.open()){

		selector = Selector.open();

		server.configureBlocking(false);
		server.bind(addr);
		server.register(selector, SelectionKey.OP_ACCEPT);

		while(true){
			selector.select();

			Set<SelectionKey> keys =  selector.selectedKeys();

			Iterator<SelectionKey> it = keys.iterator();

			while(it.hasNext()){
				SelectionKey key = it.next();

				if(key.isAcceptable()){
					ServerSocketChannel srv = (ServerSocketChannel) key.channel();

					SocketChannel client = srv.accept();
					client.configureBlocking(false);

					ByteBuffer buff = ByteBuffer.allocate(20);

					SelectionKey sk = client.register(selector, SelectionKey.OP_WRITE);
					sk.attach(buff);

				}else if(key.isWritable()){

					SocketChannel client = (SocketChannel) key.channel();

					ByteBuffer buff = (ByteBuffer) key.attachment();

					buff.clear();

					IntBuffer intbuff = buff.asIntBuffer();

					Random rand = new Random();

					for(int i = 0; i < 5; i++){
						int k = rand.nextInt();

						intbuff.put(k);
					}

					buff.position(20);
					buff.flip();

					client.write(buff);
				}

				it.remove();

			}
		}


	} catch (IOException e) {

		e.printStackTrace();
	}finally{
		try {
			if(selector != null)
				selector.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
}

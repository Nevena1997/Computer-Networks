package mi18461_NikolaKovacevic;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit;

import java.util.*;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{

	private boolean h = false;
	private int level = 0;

	private StringBuilder builder;

	public ParserCallbackImpl(StringBuilder builder){
		this.builder = builder;
	}

	public void handleText(char[] data, int pos) {
		if(h){
			// Nisam mogao da se setim kako se \t pise u htmlu xD
			String razmak = "";
			for(int i = 0; i < level; i++){
				razmak += "<ul>";
			}

			builder.append(razmak);
			builder.append("<li>");
			builder.append(data);
			builder.append("</li>");

			razmak = "";
			for(int i = 0; i < level; i++){
				razmak += "</ul>";
			}
			builder.append(razmak);

		}
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		if(t == Tag.H1){
			h = true;
			level = 1;
		}
		else if(t == Tag.H2){
			h = true;
			level = 2;
		}
		if(t == Tag.H3){
			h = true;
			level = 3;
		}
		if(t == Tag.H4){
			h = true;
			level = 4;
		}
		if(t == Tag.H5){
			h = true;
			level = 5;
		}
		if(t == Tag.H6){
			h = true;
			level = 6;
		}

	}

	@Override
	public void handleEndTag(Tag t, int pos) {
		if(t == Tag.H1){
			h = false;
		}
		else if(t == Tag.H2){
			h = false;
		}
		else if(t == Tag.H3){
			h = false;
		}
		else if(t == Tag.H4){
			h = false;
		}
		else if(t == Tag.H5){
			h = false;
		}
		else if(t == Tag.H6){
			h = false;
		}

	}

}

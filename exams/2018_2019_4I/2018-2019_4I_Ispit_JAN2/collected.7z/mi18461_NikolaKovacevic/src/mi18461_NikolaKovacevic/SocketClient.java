package mi18461_NikolaKovacevic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.*;

public class SocketClient {

	public static int port = 12345;
	public static String host = "localhost";

	public static void main(String[] args) {

	BufferedReader in = null;

    try (Socket client = new Socket(host, port)){

    	in = new BufferedReader(new InputStreamReader(client.getInputStream()));

    	int numbers = 0;

		while(true){

			int n;

			if( (n = in.read()) != -1){
				System.out.println(n);
				numbers++;
			}

			if(numbers == 5){
				numbers = 0;
				Thread.sleep(5000);
			}
		}

    } catch (IOException e) {
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
			try {
				if(in != null)
					in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	}

}

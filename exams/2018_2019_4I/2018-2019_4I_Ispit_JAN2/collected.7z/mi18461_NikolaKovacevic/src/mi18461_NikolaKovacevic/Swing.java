package mi18461_NikolaKovacevic;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLEditorKit.Parser;


public class Swing {
	public static String url = null;

	public static void main(String[] args) {
		ParserGetter getter = new ParserGetter();
		Parser parser = getter.getParser();

		JFrame f = new JFrame("kek");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 600);
		Container cont = f.getContentPane();

		cont.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.gridheight = 1;
		c.weightx = 1;
		c.weighty = 1;
		cont.add(jsp, c);


		JTextArea textInput = new JTextArea("FILE:///");
		textInput.addKeyListener(new KeyListener(){

			@Override
			public void keyTyped(KeyEvent e) {
				int offset = "FILE:///".length();
				int end = textInput.getText().length() - offset;

				try {
					url = textInput.getText(offset, end);
				} catch (BadLocationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}
		});

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0.001;
		cont.add(textInput, c);

		JButton show = new JButton("Prikazi");
		show.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					// FILE:///C:\Users\nalog\Desktop\1.html
					File file = new File(url);

					jep.setPage(file.toURI().toURL());
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}

		});
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 1;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 0.05;
		c.weighty = 0.001;
		cont.add(show, c);

		JButton content = new JButton("Sadrzaj");
		content.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {

				StringBuilder builder = new StringBuilder();
				File file = new File(url);
				BufferedReader in = null;

				ParserCallbackImpl clb = new ParserCallbackImpl(builder);

				try {
					URL pt = file.toURI().toURL();
					in = new BufferedReader(new InputStreamReader(pt.openStream(), "UTF-8"));

					parser.parse(in, clb, false);

					jep.setText(builder.toString());
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}finally{
					try {
						if(in != null)
							in.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}

			}

		});
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 2;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 0.05;
		c.weighty = 0.001;
		cont.add(content, c);

		EventQueue.invokeLater(new Runnable(){
			public void run() {
				f.setVisible(true);
			}

		});
	}

}

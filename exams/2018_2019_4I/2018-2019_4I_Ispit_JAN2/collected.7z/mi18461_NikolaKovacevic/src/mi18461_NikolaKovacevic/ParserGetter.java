package mi18461_NikolaKovacevic;

import javax.swing.text.html.HTMLEditorKit;

public class ParserGetter extends HTMLEditorKit {

	public Parser getParser(){
		return super.getParser();
	}
}

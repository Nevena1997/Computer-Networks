package mi291_15;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class Drugi {
	public static void main(String[] args) {
		JFrame jf = new JFrame("xd");
		jf.setSize(600, 400);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setResizable(true);

		Container pane = jf.getContentPane();

		pane.setLayout(new GridBagLayout());
		GridBagConstraints constr = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		constr.fill = GridBagConstraints.HORIZONTAL;
		constr.gridx = 0;
		constr.gridy = 1;
		constr.gridwidth = 1;
		constr.ipadx = 300;
		constr.ipady = 300;
		constr.weightx = 1.0;
		constr.weighty = 1.0;

		pane.add((new JScrollPane(jep)), constr);

		JTextField field = new JTextField();
		constr.fill = GridBagConstraints.HORIZONTAL;
		constr.gridx = 0;
		constr.gridy = 0;
		constr.gridwidth = 4;
		constr.ipadx = 0;
		constr.ipady = 0;
		constr.weightx = 0.0;
		constr.weighty = 0.0;

		pane.add(field, constr);

		JButton show = new JButton("Prikazi");
		show.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(!field.getText().isEmpty())
						jep.setPage(field.getText());
				} catch (IOException e1) {
					jep.setText("Invalid page");
				}

			}
		});
		constr.fill = GridBagConstraints.HORIZONTAL;
		constr.gridx = 1;
		constr.gridy = 0;
		constr.gridwidth = 4;
		constr.ipadx = 0;
		constr.ipady = 0;
		constr.weightx = 0.0;
		constr.weighty = 0.0;

		pane.add(show, constr);

		JButton content = new JButton("Sadrzaj");
		constr.fill = GridBagConstraints.HORIZONTAL;
//		constr.gridx = 2;
//		constr.gridy = 0;
//		constr.gridwidth = 4;
//		constr.ipadx = 0;
//		constr.ipady = 0;
//		constr.weightx = 0.0;
//		constr.weighty = 0.0;

		pane.add(content, constr);

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				jf.setVisible(true);
			}
		});
	}
}

package mi291_15;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;

public class Prvi_server {

	static String host = "localhost";
	static ByteBuffer g_buffer = ByteBuffer.allocate(3);
	static int port = 12345;

	public static void main(String[] args) {

		try(ServerSocketChannel server_channel= ServerSocketChannel.open();
				Selector selector = Selector.open()) {

			if(!server_channel.isOpen() || !selector.isOpen()) {
				System.err.println("Failed to open server or selector");
				System.exit(-1);
			}

			server_channel.bind(new InetSocketAddress(host, port));
			server_channel.configureBlocking(false);
			server_channel.register(selector, SelectionKey.OP_ACCEPT);

			System.out.println("Started server on port "+port);

			while(true) {
				selector.select();

				Iterator<SelectionKey> keys = selector.keys().iterator();

				while (keys.hasNext()) {
					SelectionKey key = (SelectionKey) keys.next();
//					keys.remove();

					try {
						if(key.isAcceptable()) {
							SocketChannel client = server_channel.accept();
							client.configureBlocking(false);
							ByteBuffer buffer = g_buffer.duplicate();
							Random rand = new Random();
							buffer.put((byte) rand.nextInt());
							buffer.put((byte)'\r');
							buffer.put((byte)'\n');
							key.attach(buffer);
							client.register(selector, SelectionKey.OP_WRITE);
						} else if(key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							Random rand = new Random();
							for (int i = 0; i < 5; i++) {
								ByteBuffer buffer = g_buffer.duplicate();
								buffer.put((byte) rand.nextInt(8));
								buffer.put((byte)'\r');
								buffer.put((byte)'\n');
								System.out.println("saljem:");
								client.write(g_buffer);
								Thread.sleep(5000);
//								System.out.println("spavam 5");
							}
//							ByteBuffer toSend =
//									((ByteBuffer)key.attachment());
//							System.out.println(toSend);
//							System.out.println("Saljem:");
//							System.out.write(toSend.capacity());
//							System.out.println("Ovde ne udjem jer blokiram na baferu");
//							client.write(toSend);
						}
					} catch (Exception e) {
						key.cancel();
						key.channel().close();
					}
					key.cancel();
					key.channel().close();
				}
			}

		} catch (Exception e) {
		}

	}
}

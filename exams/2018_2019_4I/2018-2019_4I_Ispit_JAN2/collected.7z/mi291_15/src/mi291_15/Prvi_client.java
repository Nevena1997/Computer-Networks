package mi291_15;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Prvi_client {
	public static void main(String[] args) {
		String host = "localhost";
		int port = 12345;

		try(Socket soc = new Socket(host, port)) {

			BufferedReader in =
					new BufferedReader(new InputStreamReader(soc.getInputStream()));

			while(true) {
				String line = in.readLine();
				System.out.print(line != null ? line+"\n" : "");
			}

		} catch(UnknownHostException e) {
			System.err.println("Invalid url");
			System.exit(-1);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}



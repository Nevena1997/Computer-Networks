package zad1;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class Client {

	public static void main(String[] args) {


		try(SocketChannel client = SocketChannel.open()){
			SocketAddress address = new InetSocketAddress("localhost", 12345);
			client.connect(address);
			System.out.println("Connected");
			client.configureBlocking(false);

			ByteBuffer buffer = ByteBuffer.allocate(4);
			while(true){
				int n = client.read(buffer);

				if(n > 0){
					buffer.flip();
					System.out.println(buffer.getInt());
					buffer.clear();
				}
				else if(n < 0){
					System.out.println("Something went wrong");
					break;
				}

			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}

package zad1;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Server {

	public static void main(String[] args) {

		try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
				Selector selector = Selector.open()){
			if(!serverChannel.isOpen() || !selector.isOpen()){
				System.out.println("Something went wrong!");
				return;
			}

			SocketAddress address = new InetSocketAddress("localhost", 12345);
			serverChannel.bind(address);
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			while(true){
				selector.select();
				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> it = readyKeys.iterator();

				while(it.hasNext()){
					SelectionKey key = it.next();
					it.remove();

					try{
						if(key.isAcceptable()){
							ServerSocketChannel server = (ServerSocketChannel)key.channel();
							SocketChannel client = server.accept();
							System.out.println("Server is ready");
							client.configureBlocking(false);

							SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);

							ByteBuffer buffer = ByteBuffer.allocate(4);
							Random rand = new Random();
							buffer.asIntBuffer().put(rand.nextInt());
							buffer.flip();
							key2.attach(buffer);
						}
						else if(key.isWritable()){
							SocketChannel client = (SocketChannel)key.channel();
							ByteBuffer buffer = (ByteBuffer)key.attachment();
							client.write(buffer);

							buffer.clear();
							Random rand = new Random();
							buffer.asIntBuffer().put(rand.nextInt());
						}
					}
					catch(Exception e){
						System.out.println(e);
						e.printStackTrace();
					}
				}
			}
		}
		catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}

	}

}

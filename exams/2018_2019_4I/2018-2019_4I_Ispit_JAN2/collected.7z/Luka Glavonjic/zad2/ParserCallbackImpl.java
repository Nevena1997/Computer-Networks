package zad2;

import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImpl extends ParserCallback {

	private JEditorPane pane;
	private boolean isInHeader = false;
	private StringBuilder sb = new StringBuilder();

	public ParserCallbackImpl(JEditorPane pane){
		this.pane = pane;
	}

	public void handleText(char[] text, int position){
		sb.append(text);
	}

	public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos) {
		if(t == Tag.H1 || t == Tag.H2 || t == Tag.H3 || t == Tag.H4 || t == Tag.H5 || t == Tag.H6){
    		isInHeader = true;
    	}

		int i = 0;
		if(t == Tag.H1){
			i = 1;
		}
		else if(t == Tag.H2){
			i = 2;
		}
		else if(t == Tag.H3){
			i = 3;
		}
		else if(t == Tag.H4){
			i = 4;
		}
		else if(t == Tag.H5){
			i = 5;
		}
		else if(t == Tag.H6){
			i = 6;
		}

		for(int j = 0; j < i; j++){
			sb.append("\t");
		}
    }

    public void handleEndTag(HTML.Tag t, int pos) {
    	if(t == Tag.H1 || t == Tag.H2 || t == Tag.H3 || t == Tag.H4 || t == Tag.H5 || t == Tag.H6){
    		sb.append("\n");
    		isInHeader = false;
    	}
    }

	public void goToPage(String url) throws IOException{
		pane.setPage(url);
	}

}

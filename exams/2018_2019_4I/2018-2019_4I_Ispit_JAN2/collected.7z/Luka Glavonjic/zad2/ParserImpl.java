package zad2;

import java.io.IOException;
import java.io.Reader;

import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.Parser;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserImpl extends HTMLEditorKit {

	public Parser getParser(){
		return this.getParser();
	}

	public void parse(Reader r, ParserCallback cb, boolean ignoreCharSet) throws IOException{
		this.getParser().parse(r, cb, ignoreCharSet);
	}

}

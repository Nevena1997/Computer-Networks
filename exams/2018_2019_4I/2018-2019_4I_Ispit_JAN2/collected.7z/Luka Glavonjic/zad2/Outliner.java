package zad2;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.ChangedCharSetException;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class Outliner {

	public static void main(String[] args) {

		JFrame f = new JFrame("xd");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 400);

		Container cont = f.getContentPane();

		cont.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();


		JEditorPane pane = new JEditorPane();
		pane.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(pane);
		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 1;
		c.fill = GridBagConstraints.BOTH;
		cont.add(scrollPane, c);

		JTextArea urlArea = new JTextArea();
		urlArea.setSize(400, 50);
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		cont.add(urlArea, c);


		ParserCallbackImpl pc = new ParserCallbackImpl(pane);

		JButton button = new JButton("Prikazi");
		button.setSize(100, 50);
		c.gridx = 1;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		cont.add(button, c);
		button.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					//FILE:///C:\Users\nalog\Desktop\file1.html
					pc.goToPage(urlArea.getText());
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});

		JButton button2 = new JButton("Sadrzaj");
		button2.setSize(100, 50);
		c.gridx = 2;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		cont.add(button2, c);

		button2.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				ParserImpl parser = new ParserImpl();
				String charset = new String();
				try{
					BufferedReader in  = new BufferedReader(new InputStreamReader(new FileInputStream("C:\\Users\\nalog\\Desktop\\file1.html")));

					ParserCallback doNothing = new ParserCallback();
					parser.parse(in, doNothing, true);
				}
				catch(ChangedCharSetException ex){
					System.out.println("exppp is " + ex);
					charset = ex.getCharSetSpec().substring(ex.getCharSetSpec().indexOf('=') + 1);
				}
				catch (IOException ex) {
					// TODO Auto-generated catch block
					System.out.println("ex is " + ex);
					ex.printStackTrace();
				}
				catch(Exception ex){
					System.out.println("asdasd" + ex);
				}

				try{
					BufferedReader in  = new BufferedReader(new InputStreamReader(new FileInputStream("C:\\Users\\nalog\\Desktop\\file1.html"), charset));
					parser.parse(in, pc, false);
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
			}
		});

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});

	}

}

package prvi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;


public class SocketA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 12345;
		String host = "localhost";
		// ovde cemo da primamo poruke koje nam server posalje
		BufferedReader in = null;

		try(Socket sock = new Socket(host, port)) {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));

			while(true){
				if(!(sock.isConnected()))
					break;
				System.out.println(in.readLine());
			}


		} catch (UnknownHostException e) {

		} catch (IOException e) {

		}finally {
			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
					e.printStackTrace();
			}
		}
	}

}

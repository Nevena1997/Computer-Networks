package prvi;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;

public class SocketServerA {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		int port = 12345;
		ByteBuffer buffer = ByteBuffer.allocate(22);

		try (ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()) {
			serverChannel.bind(new InetSocketAddress(port));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			System.err.println("server started on " + port);


			while(true){
				//server ceka 5000 milisekundi
				//serverChannel.wait(5000);
				selector.select();
				Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

				while(iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();

					try {
						if (key.isAcceptable()) {
							ServerSocketChannel server = (ServerSocketChannel)key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							Random rand = new Random();
							byte[] ascii = new byte[20];
							for (int i = 0; i < 5; i++) {
								ascii[i] = (byte)rand.nextInt();
							}
							ByteBuffer newBuffer = buffer.duplicate();
							newBuffer.put(ascii, 0, 20);
							newBuffer.put((byte)'\r');
							newBuffer.put((byte)'\n');
							newBuffer.flip();
							key.attach(newBuffer);
							key.interestOps(SelectionKey.OP_WRITE);
						}else if(key.isWritable()){
							SocketChannel client = (SocketChannel)key.channel();
							ByteBuffer buff = (ByteBuffer)key.attachment();
							if (buff.hasRemaining()){
								client.write(buff);
							}else {
								client.close();
							}
						}
					} catch (IOException e) {
						key.cancel();
						key.channel().close();
						// TODO: handle exception
					}

				}
			}

		//} catch (InterruptedException e) {
			//e.printStackTrace();
			// TODO: handle exception
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}

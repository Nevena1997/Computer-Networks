package drugi;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private List<URL> urlStack;
	private int index;
	private JTextArea addressBar;

	public LinkHandler(JEditorPane jep ,JTextArea addressBar) {
		this.jep = jep;
		this.urlStack = new ArrayList<>();
		this.addressBar = addressBar;
		this.index = -1;
	}

	public void goToPage(URL url) {
		try {
			jep.setPage(url);
			index++;
			urlStack.add(index, url);
			for (int i = index+1; i < urlStack.size(); i++)
				urlStack.remove(i);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.addressBar.setText(url.toString());
	}

	public void goToPage(String urlString) {
		try {
			URL url = new URL(urlString);
			goToPage(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		 HyperlinkEvent.EventType type = evt.getEventType();
		 URL u = evt.getURL();

		 if (type == HyperlinkEvent.EventType.ACTIVATED
				 && !u.equals(urlStack.get(index))) {
			 goToPage(u);
		 }
	}

	/*public void prikazi(){
		URL u = urlStack.get(index);
		//goToPage(u);
		try {
			jep.setPage(u);
			this.addressBar.setText(u.toString());
		} catch (IOException e) {
			jep.setText("error");
			// TODO: handle exception
		}
	}*/

}

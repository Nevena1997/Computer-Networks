package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;

import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class WebBrowser {
	private static final String HOME_PAGE = "file:///C:/Users/nalog/Desktop/2.html";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame f = new JFrame("xd");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		// TODO Auto-generated method stub
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 480;
		pane.add(jep, c);

		JTextArea addressBar = new JTextArea(HOME_PAGE);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(addressBar, c);

		LinkHandler lh = new LinkHandler(jep ,addressBar);
		// da bismo mogli da klikcemo url na stranici
		 jep.addHyperlinkListener(lh);
		 //lh.goToPage(HOME_PAGE);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				URL url = null;
				try {
					url = new URL(HOME_PAGE);
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lh.goToPage(url);
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.2;
		c.weighty = 0.0;
		pane.add(btnPrikazi, c);

		JButton btnSadrzaj = new JButton("Sadrzaj");

		btnSadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					URL url = null;
					url = new URL(HOME_PAGE);
					ParserGetter pg = new ParserGetter();
					ParserCallback pc = new ParserCallback(new OutputStreamWriter(System.out));
					HTMLEditorKit.Parser p = pg.getParser();
					InputStreamReader in = new InputStreamReader(url.openStream());

					p.parse(in, pc, true);
					// uradio sam sve samo nisam zna kako da prebacim iz writera u String da bi ga ispisao u jepu
					// trebao sam da koristim string builder u Parseru ali nisam imao vremena u sustini svuda gde je bilo plus bi trebalo da bude append ,
					//ispisuje mi html kod na standarni izlaz
					jep.setText(pc.getHTML());
				} catch (Exception e2) {
					e2.printStackTrace();
					// TODO: handle exception
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.2;
		c.weighty = 0.0;
		pane.add(btnSadrzaj, c);

	}

}

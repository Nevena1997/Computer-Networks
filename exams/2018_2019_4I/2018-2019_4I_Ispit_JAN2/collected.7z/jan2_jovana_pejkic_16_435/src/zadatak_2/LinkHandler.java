package zadatak_2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

public class LinkHandler implements HyperlinkListener {

	private JLabel label;
	private JTextArea addressBar;
	private JEditorPane pane;
	private List<URL> urlStack;
	private int index;

	public LinkHandler(JEditorPane pane, JLabel label, JTextArea addressBar) {
		this.pane = pane;
		this.label = label;
		this.addressBar = addressBar;
		this.urlStack = new ArrayList<URL> ();
		this.index = -1;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		// TODO Auto-generated method stub

			HyperlinkEvent.EventType type = evt.getEventType();
			URL url = evt.getURL();

			if (type == HyperlinkEvent.EventType.ACTIVATED && url != this.urlStack.get(this.index)) {
				this.goToPage(url);
			}
			else if (type == HyperlinkEvent.EventType.ENTERED) {
				this.pane.setText("<html>" + url.toString() + "</html>");
			}
			else if (type == HyperlinkEvent.EventType.EXITED) {
				this.pane.setText("<html> wow such browser </html>");
			}
	}

	public void goToPage(URL url) {
		this.urlStack.add(this.index + 1, url);
		this.index++;

		for (int i=this.index; i<this.urlStack.size(); i++) {
			this.urlStack.remove(i);
		}

		try {
			this.pane.setPage(url);
		} catch(Exception ex) {
			this.pane.setText("<html> Could not load " + url.toString() + "</html>");
		}
	}

	public void goToPage(String urlStr) {
		try {
			URL url = new URL(urlStr);
			this.goToPage(url);
		} catch(Exception ex) {
			this.pane.setText(urlStr);
		}
	}

	public void prikazi() {
		/*
		 * uzeti tekst iz addressBar komponente
		 * napraviri od tog stringa URL (trim obavezno)
		 * dodati taj URL u listu
		 * postaviti stranu na taj URL (this.pane.setPage(URL))
		 */
		String urlString = this.addressBar.getText();
		try {
			URL u = new URL(urlString);
			// URL u = new URL("file:///C:/Users/nalog/workspace/jan2_jovana_pejkic_16_435/1.html");
			this.pane.setPage(u);
		} catch(Exception ex) {
			this.pane.setText("Enter the address!");
		}
	}

	public void sadrzaj() {
		ParserGetter pg = new ParserGetter();
		HTMLEditorKit.Parser p = pg.getParser();
		ParserCallbackImpl cb = new ParserCallbackImpl(this.pane);

		/*
		 * Radi parse(), nesto ispisuje, ali ne bas ono sto treba.
		 *
		 * */

		// otvaram fajl iz kog cita
		try {
			p.parse(new InputStreamReader ( new FileInputStream ("1.html")), cb, true);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package zadatak_2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class WebBrowser {
	public static final String HOME_PAGE = "file:///C:/Users/nalog/workspace/jan2_jovana_pejkic_16_435/1.html";

	public static void main (String []args) {

		JFrame f = new JFrame("xd");
		f.setSize(600, 400);
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//f.setResizable(false);
		// omoguceno da se prozor moze prosiriti a da se raspored i razmera komponenti ne promeni
		f.setResizable(true);
		f.setLocationRelativeTo(null);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}

		});


	}

	public static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0;
		c.weighty = 1;
		pane.add(scroll, c);

		JLabel label = new JLabel("wow such browser :)");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(label, c);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(addressBar, c);

		LinkHandler lh = new LinkHandler(jep, label, addressBar);
		jep.addHyperlinkListener(lh);
		// TODO ??????

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(prikazi, c);

		prikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lh.prikazi();
			}

		});

		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(sadrzaj, c);

		sadrzaj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				lh.sadrzaj();
			}

		});

	}
}

package zadatak_2;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback {

	private JEditorPane pane;
	private boolean inHeader;
	private int level;
	private String lineSep;

	public ParserCallbackImpl(JEditorPane pane) {
		this.pane = pane;
		this.inHeader = false;
		this.level = 0;
		this.lineSep = System.lineSeparator();		// TODO: System.getProperty("line.separator")
	}

	// handleText(sadrzaj web str, pos)
	@Override
	public void handleText(char[] data, int pos) {
		// TODO Auto-generated method stub
		this.pane.setText(data.toString());
	}

	@Override
	public void handleStartTag(Tag tag, MutableAttributeSet a, int pos) {
		// TODO Auto-generated method stub
		int newLevel = 0;

		if (tag == HTML.Tag.H1) {
			newLevel = 1;
		}
		else if (tag == HTML.Tag.H2) {
			newLevel = 2;
		}
		else if (tag == HTML.Tag.H3) {
			newLevel = 3;
		}
		else if (tag == HTML.Tag.H4) {
			newLevel = 4;
		}
		else if (tag == HTML.Tag.H5) {
			newLevel = 5;
		}
		else if (tag == HTML.Tag.H6) {
			newLevel = 6;
		}
		else {
			return;
		}

		this.inHeader = true;

		if (this.level < newLevel) {
			for (int i=0; i<newLevel - this.level; i++) {
				this.pane.setText(this.lineSep + "<ul>");	// TODO: .setText()
			}
		}

		else if (this.level > newLevel) {
			for (int i=0; i<newLevel - this.level; i++) {
				this.pane.setText(this.lineSep + "</ul>" + this.lineSep);
			}
			this.pane.setText(this.lineSep + "<li>");
		}

		else if (this.level == newLevel) {
			this.pane.setText(this.lineSep + "<li>");
		}
	}

	@Override
	public void handleEndTag(Tag tag, int pos) {
		// TODO Auto-generated method stub
		if (tag == HTML.Tag.HTML && this.inHeader == true) {
			for (int i=0; i<this.level; i++) {
				this.pane.setText("</ul>");
			}
		}
	}

	@Override
	public void handleSimpleTag(Tag t, MutableAttributeSet a, int pos) {
		// TODO Auto-generated method stub
		super.handleSimpleTag(t, a, pos);
	}



}

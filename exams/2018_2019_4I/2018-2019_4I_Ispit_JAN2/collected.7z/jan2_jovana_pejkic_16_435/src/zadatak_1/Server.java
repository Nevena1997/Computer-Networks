package zadatak_1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Server {

	public static int port = 12345;

	public static void main(String []args) {

		System.out.println("SERVER: Listening for connection from port: " + port);

		// random broj
		Random e = new Random();
		e.nextInt();

		/*
		byte[] niz = new byte[5];
		for (int i=0; i<niz.length; i++) {
			niz[i] = 'a';
		}
		*/

		byte[] niz = new byte[60];
		for (int i=0; i<niz.length; i++) {
			niz[i] = 'a';
		}


		try (ServerSocketChannel server_channel = ServerSocketChannel.open();
				Selector selector = Selector.open()) {

			// provera da li su otvoreni
			if (!server_channel.isOpen() || !selector.isOpen()) {
				System.exit(1);
			}

			server_channel.bind(new InetSocketAddress(port));
			server_channel.configureBlocking(false);
			server_channel.register(selector, SelectionKey.OP_ACCEPT);

			while (true) {
				selector.select();
				Set<SelectionKey> spremni = selector.selectedKeys();
				Iterator<SelectionKey> iterator = spremni.iterator();

				while (iterator.hasNext()) {
					SelectionKey key = iterator.next();
					iterator.remove();

					try {
						if (key.isAcceptable()) {	// server
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();

							System.out.println("Connection accepted from client " + client.getRemoteAddress());

							client.configureBlocking(false);
							SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);

							// buffer
							ByteBuffer buffer = ByteBuffer.allocate(74);
							buffer.put(niz, 0, 60);

							/*
							 * Ideja: da napravim 5 puta random broj i stavim u bafer
							 * i to posaljem klijentu
							 *
							 */

							/* Ali ne radi, pa sam zato ostavila da salje ovaj niz,
							   posto to radi!

							Random r1 = new Random();
							buffer.putInt(r1.nextInt());

							Random r2 = new Random();
							buffer.putInt(r2.nextInt());

							Random r3 = new Random();
							buffer.putInt(r3.nextInt());

							Random r4 = new Random();
							buffer.putInt(r4.nextInt());

							Random r5 = new Random();
							buffer.putInt(r5.nextInt());
							*/
							buffer.put((byte) '\r');
							buffer.put((byte) '\n');
							buffer.flip();
							key2.attach(buffer);
						}
						else if (key.isWritable()) {	// klijent
							SocketChannel client = (SocketChannel) key.channel();
							// buffer
							ByteBuffer buffer = (ByteBuffer) key.attachment();

							if (buffer.hasRemaining()) {
								client.write(buffer);
							}
						}
					} catch (IOException ex2) {
						key.cancel();
						try {
							key.channel().close();
						} catch (IOException ex3) {

						}
					}
				}

			}




		} catch (IOException ex) {
			ex.printStackTrace();
		}


	}
}

package zadatak1;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

public class Server {

	public static void main(String[] args) {
		BufferedWriter out = null;

		try(ServerSocket s = new ServerSocket(12345)) {
			while(true){
				Socket conn = s.accept();
				System.err.println("Konektovan klijent");

				out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));

				Random r = new Random();
				int random_num = r.nextInt();

				//String cbuf = "Testiranje";
				out.write(Integer.toString(random_num));
				out.flush();
				conn.close();
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}

	}

}

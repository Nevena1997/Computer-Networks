package zadatak1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.BreakIterator;

public class Client {
	private static final String host = "localhost";

	public static void main(String[] args) {
		try (Socket s = new Socket(host, 12345)){
			System.err.println("Konektovan na server");
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

			StringBuffer sb = new StringBuffer();

			while(true){
				if(in.ready()){
					sb.append(in.readLine());
					System.out.println(sb.toString());
				}
				break;
				//if ... break?
			}
			//System.err.println("Van petlje");
		}
		catch (UnknownHostException ex) {
			//e.printStackTrace();
			System.err.println("Unknown Host Exception");
		}
		catch (IOException e) {
			System.err.println("IO Greska");
			//e.printStackTrace();
		}

	}

}

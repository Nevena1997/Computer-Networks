package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLEditorKit;

public class Browser {

	public static void main(String[] args) {

		JFrame frame = new JFrame("xd");
		frame.setSize(800,600);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new FrameShower(frame));
	}

	public static class FrameShower implements Runnable {
		private Frame frame;

		FrameShower (Frame frame) {this.frame = frame;}

		@Override
		public void run() {
			this.frame.setVisible(true);
		}


	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();	//TODO Parser i parser
		jep.setEditable(false);
		try {
			jep.setPage("file:///C:/Users/nalog/Desktop/1.html");	//TODO Srediti
		} catch (IOException e) {
			jep.setContentType("text/html");
			jep.setText("<html><h1>Neuspeh!</h1></html>");
		}

		ParserGetter pg = new ParserGetter();
		HTMLEditorKit.Parser p = (HTMLEditorKit.Parser) pg.getParser();
		Document doc = jep.getEditorKit().createDefaultDocument();



		JScrollPane scroll = new JScrollPane(jep);
		//scroll.setSize(1000,800);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridheight = 2;
		c.gridwidth = 3;
		c.gridy = 0;
		c.gridx = 1;
		c.ipady = 50;
		c.ipadx = 50;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(scroll, c);


		JTextArea ta = new JTextArea("file:///C:/Users/nalog/Desktop/1.html", 1, 10);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridheight = 2;
		c.gridwidth = 3;
		c.gridy = 2;
		c.gridx = 0;
		c.ipady = 10;
		c.ipadx = 10;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(ta, c);


		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				klikPrikazi(ta, jep);

			}
		});
		c.gridheight = 2;
		c.gridwidth = 3;
		c.gridy = 1;
		c.gridx = 1;
		c.ipady = 100;
		c.ipadx = 110;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(prikazi);//c?



		JButton sadrzaj = new JButton("Sadrzaj");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				klikSadrzaj(jep);

			}
		});
		c.gridheight = 2;
		c.gridwidth = 3;
		c.gridy = 1;
		c.gridx = 1;
		c.ipady = 100;
		c.ipadx = 110;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(sadrzaj);

	}



	public static void klikPrikazi(JTextArea ta, JEditorPane jep){
		String url_string = ta.getText();

		try {
			jep.setPage(url_string);
		}
		catch (IOException e) {
			jep.setContentType("text/html");
			jep.setText("<html><h1>Neuspeh!</h1></html>");
		}
	}

	public static void klikSadrzaj(JEditorPane jep){
		//
	}

}

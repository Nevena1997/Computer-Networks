package zadatak2;

import javax.swing.text.html.HTMLEditorKit;

public class ParserGetter extends HTMLEditorKit {
	private static final long serialVersionUID = 1L;	//Default?

	public Parser getParser(){
		return super.getParser();
	}
}

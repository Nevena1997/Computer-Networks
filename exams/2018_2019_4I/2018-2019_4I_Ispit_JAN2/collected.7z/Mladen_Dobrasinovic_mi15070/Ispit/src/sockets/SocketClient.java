package sockets;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketClient {
	
	public static void main(String [] args)
	{
		try {
			Socket s = new Socket("127.0.0.1", 12345);
			InputStream in = s.getInputStream();
			
			byte[] buffer = new byte[512];
			
			while (!s.isClosed())
			{
				int readCount = in.read(buffer);
				System.out.write(buffer, 0, readCount);
			}
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

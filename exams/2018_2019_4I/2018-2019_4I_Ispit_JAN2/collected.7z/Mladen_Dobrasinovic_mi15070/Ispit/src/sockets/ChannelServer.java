package sockets;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;


public class ChannelServer {

	public static void main(String[] args) {
		try {
		ServerSocketChannel channel = ServerSocketChannel.open();

		channel.bind(new InetSocketAddress(12345));
		channel.configureBlocking(false);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

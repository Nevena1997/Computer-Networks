package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
//import java.net.URL;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class WebBrowser {

	public static final String HOME_PAGE = "FILE:///C:\\Users\\nalog\\Desktop\\LukaBanovic.mi16080\\src\\1.html";


	public static void main(String args[]){


		JFrame f = new JFrame();
		f.setSize(800, 600);
		f.setResizable(true);
		//f.setDefaultCloseOperation(.DISPOSE_ON_CLOSE);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}

		});

	}

	private static void addComponents(Container pane) {
		// TODO Auto-generated method stub
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JTextArea addressBar = new JTextArea(HOME_PAGE);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(addressBar, c);

		JButton btnPrikaz = new JButton("Prikazi");
		btnPrikaz.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String link = addressBar.getText();
				prikazi(jep, addressBar, link);
			}

			private void prikazi(JEditorPane jep, JTextArea addressBar, String link) {
				// TODO Auto-generated method stub
				try {
					try {
					URL url = new URL(link);
					jep.setPage(url);
					} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnPrikaz, c);


		JButton btnSadrzaj = new JButton("Sadrzaj");
		btnSadrzaj.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String html = jep.getText();
				String headers = html.replaceAll("<p>.*"," ")
						.replaceAll("<h1>.*", "<li>\t ")
						.replaceAll("</h1>.*", "\t </li>")
						.replaceAll("<h2>.*", "<li>\t\t ")
						.replaceAll("</h2>.*", "\t\t</li> ")
						.replaceAll("<h3>.*", "<li>\t\t\t ")
						.replaceAll("</h3>.*", "\t\t\t </li>")
						.replaceAll("<h4>.*", "<li>\t\t\t\t ")
						.replaceAll("</h4>.*", "\t\t\t\t</li>")
						.replaceAll("<h5>.*", "<li>\t\t\t\t\t ")
						.replaceAll("</h5>.*", "\t\t\t\t\t</li> ")
						.replaceAll("<h6>.*", "<li>\t\t\t\t\t\t ")
						.replaceAll("</h6>.*", "\t\t\t\t\t\t </li>");

				//Jako los last-minute pokusaj hardkodovanja, oops
				System.out.print(headers);
				jep.setText(headers);
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnSadrzaj, c);

	}
}

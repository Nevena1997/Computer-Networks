package zadatak1;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class Client {

	public static final int DEFAULT_PORT = 12345;

	public static void main(String args[]){

		try {


			Socket client = new Socket("localhost", DEFAULT_PORT);
			BufferedInputStream in = new BufferedInputStream(client.getInputStream());
			System.out.print("Connected to server on port " + DEFAULT_PORT);
			int c;
			while((c = in.read()) != -1){
				System.out.print(c);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}


}

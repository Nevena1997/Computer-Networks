package zadatak1;

import java.io.BufferedOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Server {

	public static final int DEFAULT_PORT = 12345;

	public static void main(String args[]){

		try {
			ServerSocketChannel serverChannel = ServerSocketChannel.open();
			Selector selector = Selector.open();

			InetSocketAddress addr = new InetSocketAddress(DEFAULT_PORT);
			serverChannel.bind(addr);
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT );

			while(true){

				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> it = readyKeys.iterator();
				Random random = new Random();
				Integer br = random.nextInt();


				while(it.hasNext()){
					SelectionKey key = it.next();
					it.remove();

					if(key.isAcceptable()){
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						server.accept();
						server.configureBlocking(false);
						key.attach(random.nextInt());
					}if(key.isWritable() || key.isReadable()){
						SocketChannel client = (SocketChannel) key.channel();
						client.bind(addr);
						ByteBuffer buff = ByteBuffer.allocate(4096);
						buff = (ByteBuffer) key.attachment();
						client.write(buff);
					}
				}
			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
}
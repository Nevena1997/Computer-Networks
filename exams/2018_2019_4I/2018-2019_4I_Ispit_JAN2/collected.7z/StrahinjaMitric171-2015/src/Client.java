import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.DoubleBuffer;

public class Client {

	public static void main(String[] args) {

		System.out.println("Klijent pokrenut...");

		try(Socket sock = new Socket("localhost", 12345)){
 			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			System.out.println("Klijent konektovan");


			while (true) {


				//TODO kada server prekine vezu klijent se zaustavlja

				CharBuffer b = null;
				while(true)
				{
					in.read(b);
					System.out.println("Server poslao: " + b);
				}
			}



		} catch (UnknownHostException e) {
			System.out.println("UnknownHostException");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IOE");
			e.printStackTrace();
		}





	}

}

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Browser {

	public static final String HOME_PAGE = "http://poincare.matf.bg.ac.rs/~filip/";

	public static void main(String[] args) {
		JFrame f = new JFrame("xd");
		f.setSize(600, 600);
		f.setResizable(false);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());

		JEditorPane jep = new JEditorPane();
		try {
			jep.setPage(HOME_PAGE);
		} catch (IOException e) {
			jep.setText("<html>Could not open "+HOME_PAGE+"</html>");
		}
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);

		GridBagConstraints c = new GridBagConstraints();

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 100;
		c.weightx = 1;
		c.weighty = 3;
		

		pane.add(jsp, c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 100;
		c.weightx = 0;
		c.weighty = 1;



		JTextArea addrBar = new JTextArea();


	}

}

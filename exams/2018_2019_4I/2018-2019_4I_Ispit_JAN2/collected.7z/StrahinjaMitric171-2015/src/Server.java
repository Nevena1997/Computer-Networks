import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static final int PORT = 12345;
	public static void main(String[] args) {

		try(ServerSocketChannel ssc = ServerSocketChannel.open() ;
			Selector selector = Selector.open())
		{
			ssc.bind(new InetSocketAddress(PORT));
			ssc.configureBlocking(false);
			ssc.register(selector, SelectionKey.OP_ACCEPT);

			try{
				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while (iterator.hasNext()) {
					SelectionKey key = iterator.next();

					if(key.isAcceptable())
					{
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client = server.accept();

						client.configureBlocking(false);
						client.register(selector, SelectionKey.OP_READ);
						System.out.println("Neko se konektovao");
					} else if (key.isWritable())
					{
						System.out.println("Usao u iswriteable");
					} else if (key.isReadable())
					{

						System.out.println("Usao u readable");
					}

				}

				//SocketChannel sock = ssc.accept();

			} finally {
				System.out.println("Finally");
			}


		} catch (IOException e) {
			System.out.println("IOE");
			e.printStackTrace();
		}

	}

}

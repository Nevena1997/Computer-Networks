package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Main {

	public static final String BASE = "file://localhost/";

	public static void main(String[] args) {
		JFrame f = new JFrame("program");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);

		setupComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void setupComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 500;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(scrollPane, c);

		JTextField addr = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 500;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(addr, c);

//		LinkHandler lh = new LinkHandler(jep);
//		jep.addHyperlinkListener(lh);

		JButton btnShow = new JButton("Prikazi");
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String urlS = addr.getText();
				try {
					jep.setPage(new URL(urlS));
				} catch (IOException ex) {
					jep.setContentType("text/html");
					jep.setText("<html>Unable to load " + urlS + " </html>");
				}
			}
		});
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 50;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(btnShow, c);

		JButton btnContent = new JButton("Sadrzaj");
		btnContent.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				StringBuilder sb = new StringBuilder();

				String[] text = jep.getText().split(" ");
				for (int i = 0; i < text.length; i++) {
					System.err.println(text[i]);
					System.err.println("----------");
					if (text[i].trim().equals("<h1>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h1>")) {
							sb2.append(text[j].trim());
							j++;
						}
						sb.append("\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h2>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h2>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h3>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h3>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h4>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h4>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h5>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h5>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h6>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h6>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t\t\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h7>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h7>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t\t\t\t\t " + sb2.toString() + "\n");
					}
					if (text[i].trim().equals("<h8>")) {
						int j = i+1;
						StringBuilder sb2 = new StringBuilder();
						while (! text[j].trim().equals("</h8>")) {
							sb2.append(text[j].trim()  );
							j++;
						}
						sb.append("\t\t\t\t\t\t\t\t " + sb2.toString() + "\n");
					}
				}

				jep.setContentType("text/plain");
				jep.setText(sb.toString());
			}
		});
		c.gridx = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 50;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(btnContent, c);

	}

}

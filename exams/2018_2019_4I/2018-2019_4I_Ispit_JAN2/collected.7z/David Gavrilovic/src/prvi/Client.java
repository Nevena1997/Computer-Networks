package prvi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SocketChannel;

public class Client {

	public static void main(String[] args) {
		PrintWriter writer = null;
		BufferedInputStream in = null;

		try (Socket sock = new Socket("localhost", Server.DEF_PORT)) {
//		try (SocketChannel sock = SocketChannel.open(new InetSocketAddress("localhost", Server.DEF_PORT))) {
			System.err.println("Client connected");

			writer = new PrintWriter(sock.getOutputStream());
			in = new BufferedInputStream(sock.getInputStream());
			writer.println("go");
			writer.flush();

//			ByteBuffer buffer = ByteBuffer.allocate(4);
//			IntBuffer intBuff = buffer.asIntBuffer();

			int i = 1;
			while (true) {
//				sock.read(buffer);
//				int num = buffer.getInt();
//				System.out.println(num);
				byte[] buf = new byte[4];
				System.err.println(in.read(buf));
				if (i == 5)
					break;
				i++;
			}

			System.err.println("zavrseno");

		} catch (UnknownHostException e) {
			System.err.println("nepoznati host");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (writer != null)
					writer.close();
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

}

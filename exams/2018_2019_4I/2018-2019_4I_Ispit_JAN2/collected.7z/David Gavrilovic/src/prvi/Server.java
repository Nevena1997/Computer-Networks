package prvi;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Random;

public class Server {

	public static int DEF_PORT = 12345;

	public static void main(String[] args) {
		int i = 1;
		try (ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()) {

			serverChannel.bind(new InetSocketAddress(DEF_PORT));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			System.err.println("Server on port " + DEF_PORT);

			while (true) {
				selector.select();

				Iterator<SelectionKey> keys = selector.selectedKeys().iterator();
				while (keys.hasNext()) {
					SelectionKey key = keys.next();
					keys.remove();

					try {
						if (key.isAcceptable()) {
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();

							client.configureBlocking(false);
							client.register(selector, SelectionKey.OP_READ);
							System.err.println(client + " connected");
						} else if (key.isReadable()) {
							SocketChannel client = (SocketChannel) key.channel();

//							ByteBuffer buffer = ByteBuffer.allocate(6);
//							client.read(buffer);
//
//							StringBuilder sb = new StringBuilder();
//							for (byte b : buffer.array())
//								sb.append((char)b);
//							System.err.println(sb.toString().trim());

//							key.attach(buffer);
							key.interestOps(SelectionKey.OP_WRITE);

						} else if (key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer out = ByteBuffer.allocate(4);
							Random rand = new Random();

							out.putInt(rand.nextInt(Integer.MAX_VALUE));
							out.flip();
							System.err.println("pisem");

							if (out.hasRemaining())
								client.write(out);

							// wait for 5 seconds
							try {
								Thread.sleep(5000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}

							if (i >= 5)
								client.close();
							i++;
						}
					} catch (IOException ex) {
						key.cancel();
						key.channel().close();
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

package mi15035;

import java.io.BufferedReader;
import java.io.FileReader;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;

public class Handler {
	private JEditorPane jep;
	private JTextArea addressBar;

	public Handler (JEditorPane jep, JTextArea addressBar) {
		this.jep = jep;
		this.addressBar = addressBar;
	}

	public void prikazi () {
		goToPage(this.addressBar.getText());
	}

	public void goToPage (String path) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(path));
			StringBuffer text = new StringBuffer();
			char c;
			while ((c = (char) in.read()) != -1)
				text.append(c);
			in.close();
			jep.setText(text.toString());
		} catch (Exception e) {
			jep.setText("<html>Nije uspelo otvaranje " + path + "</html>");
		}
		addressBar.setText(path);;
	}
}

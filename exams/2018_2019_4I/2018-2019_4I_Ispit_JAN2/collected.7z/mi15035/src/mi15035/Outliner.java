package mi15035;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Outliner {

	public static void main(String[] args) {
		JFrame f = new JFrame("xd");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800,600);
		f.setResizable(true);
		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable() {
			public void run () {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		jep.setContentType("text/html");
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 10;
		c.ipadx = 0;
		c.ipady = 500;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(scrollPane,c);
		JTextArea addressBar = new JTextArea();
		addressBar.setEditable(true);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 5;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 10;
		c.weighty = 1;
		pane.add(addressBar,c);
		Handler handler = new Handler(jep,addressBar);
		handler.goToPage("FILE:///C:\\Users\\Desktop\\1.html");
		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener (new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				handler.prikazi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 6;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(prikazi,c);
		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 7;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(sadrzaj,c);
	}
}

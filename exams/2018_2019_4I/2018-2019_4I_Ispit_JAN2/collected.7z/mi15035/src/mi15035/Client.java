package mi15035;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class Client {

	public static void main(String[] args) {
		String host = "localhost";
		int port = 12345;
		try {
			SocketAddress address = new InetSocketAddress(host,port);
			SocketChannel client = SocketChannel.open(address);
			client.configureBlocking(false);
			ByteBuffer buffer = ByteBuffer.allocate(10);
			WritableByteChannel out = Channels.newChannel(System.out);
			while (true) {
				int n = client.read(buffer);
				if (n > 0) {
					buffer.flip();
					out.write(buffer);
					buffer.clear();
				}
				if (n == -1)
					break;
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}

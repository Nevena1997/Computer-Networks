package mi15035;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.Date;

public class Server {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		int defaultPort = 12345;
		int maxInt = 1000;
		Date a = new Date();
		Date b = new Date();
		int ispisano = 0;
		try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
				Selector selector = Selector.open()) {
			if (!selector.isOpen() || !serverChannel.isOpen()) {
				System.err.println("Greska");
				System.exit(1);
			}
			serverChannel.bind(new InetSocketAddress(defaultPort));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector,SelectionKey.OP_ACCEPT);
			while (true) {
				selector.select();
				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();
				while (iterator.hasNext()) {
					SelectionKey key = iterator.next();
					iterator.remove();
					try {
						if (key.isAcceptable()) {
							ServerSocketChannel server = (ServerSocketChannel)key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							SelectionKey key2 = client.register(selector,SelectionKey.OP_WRITE);
							ByteBuffer buffer = ByteBuffer.allocate(20);
							key2.attach(buffer);
						}
						if (key.isWritable()) {
							SocketChannel client = (SocketChannel)key.channel();
							ByteBuffer buffer = (ByteBuffer)key.attachment();
							int skip = 0;
							b = new Date();
							if (ispisano > 0 && (b.getSeconds() - a.getSeconds()) < 5)
								skip = 1;
							if (ispisano > 4)
								skip = 1;
							if (skip == 0) {
								if (!buffer.hasRemaining()) {
									double r = Math.random();
									int x = (int)r*maxInt;
									buffer.rewind();
									if (x > 99) {
										buffer.putChar(makeChar(x/100));
										x %= 100;
										buffer.putChar(makeChar(x/10));
										buffer.putChar(makeChar(x%10));
									}
									else if (x > 9) {
										buffer.putChar(makeChar(x/10));
										buffer.putChar(makeChar(x%10));
									}
									else
										buffer.putChar(makeChar(x));
									buffer.putChar('\n');
									buffer.flip();
								}
								a = b;
								client.write(buffer);
							}
						}
					}
					catch (IOException ex) {
						key.cancel();
						try {
							key.channel().close();
						}
						catch (IOException exc) {

						}
					}
				}
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static char makeChar (int x) {
		if (x == 1)
			return '1';
		if (x == 2)
			return '2';
		if (x == 3)
			return '3';
		if (x == 4)
			return '4';
		if (x == 5)
			return '5';
		if (x == 6)
			return '6';
		if (x == 7)
			return '7';
		if (x == 8)
			return '8';
		if (x == 9)
			return '9';
		else
			return '0';
	}

}

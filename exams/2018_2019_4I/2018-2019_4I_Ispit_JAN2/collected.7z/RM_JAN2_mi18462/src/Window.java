import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;



public class Window {

	public static final String HOME_PAGE = "file:///C:/Users/nalog/Desktop/mi18462/1.html";

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(400, 200);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());;
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0 ;
		c.weighty = 1.0 ;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 480;

		pane.add(scrollPane, c);


		JTextField address = new JTextField();

		LinkHandler lh = new LinkHandler(jep, address);
		jep.addHyperlinkListener(lh);
		lh.goToPage(HOME_PAGE);


		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 0 ;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(address, c);


		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.prikazi(address.getText());

			}
		});
		c.gridx = 2;
		c.gridy = 0;
		c.weightx = 0 ;
		c.weighty = 0 ;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnPrikazi, c);


		JButton btnSadrzaj = new JButton("Sadrzaj");
		btnSadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
	//			lh.sadrzaj();

			}
		});

		c.gridx = 3;
		c.gridy = 0;
		c.weightx = 0 ;
		c.weighty = 0 ;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btnSadrzaj, c);

	}

}

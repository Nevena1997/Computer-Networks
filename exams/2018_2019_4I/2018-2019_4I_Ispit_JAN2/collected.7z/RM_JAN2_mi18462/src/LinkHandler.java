import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JEditorPane;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTML;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane jep;
	private JTextField address;

	public LinkHandler(JEditorPane jep, JTextField address){
		this.jep = jep;
		this.address = address;
	}

	public void goToPage(URL u){
		try{
			jep.setPage(u);
		}catch(IOException e){
			e.printStackTrace();
		}

	}

	public void goToPage(String urlString){
		try{
			URL u = new URL(urlString);
			goToPage(u);
		}catch(MalformedURLException e){
			e.printStackTrace();
		}
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();
		URL u = e.getURL();

		if(type == EventType.ENTERED)
			try{
				goToPage(u);
			}catch(Exception ex){
				ex.printStackTrace();
			}

	}

	public void prikazi(String url){

		String name = address.getText();
		Scanner sc = new Scanner(name);
		while(sc.hasNext()){
			jep.setText(sc.nextLine());
		}

		sc.close();
	}

/*
public void sadrzaj(String url){

	Scanner sc = new Scanner(url);
	while(sc.hasNext()){
		String s = sc.nextLine();
		if(s.startsWith("<h1>")){
			jep.setText(t);
		}

	}


}
*/

}

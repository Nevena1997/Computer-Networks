package prvi;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.SocketChannel;

public class Client {

	public static void main(String[] args) {
		try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", 12345))){
			ByteBuffer buff = ByteBuffer.allocate(4);
			IntBuffer view = buff.asIntBuffer();

			while(buff.hasRemaining()){
				client.read(buff);
				int actual = view.get();
				buff.clear();
				System.out.println(actual);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

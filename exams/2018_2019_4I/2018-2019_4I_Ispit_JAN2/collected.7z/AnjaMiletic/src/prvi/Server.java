package prvi;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static void main(String[] args) throws InterruptedException {
		try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
				Selector selector = Selector.open()) {
			serverChannel.bind(new InetSocketAddress(12345));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector,  SelectionKey.OP_ACCEPT);

			while(true) {
				selector.select();
				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while(iterator.hasNext()) {
					SelectionKey key = iterator.next();
					iterator.remove();
					try{
						if(key.isAcceptable()) {

						} else if(key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer output = (ByteBuffer) key.attachment();
							if(!output.hasRemaining()) {
								output.clear();
								for(int i = 0; i < 5; i++){
									int value = (int) Math.floor(Math.random()*100);
									output.putInt(value);
									client.write(output);
									Thread.sleep(5000);
								}
							}
						}
					} catch(IOException ex){
						key.cancel();
						try{
							key.channel().close();
						} catch(IOException exc) {
							exc.printStackTrace();
						}
						ex.printStackTrace();
					}

				}
			}
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}

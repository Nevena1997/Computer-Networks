package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class Outliner {

	public static void main(String[] args) {


		JFrame f = new JFrame("xd");
		f.setSize(600,400);
		f.isResizable();
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		addComponents(f.getContentPane());

//		EventQueue.invokeLater(new FrameShower(f));
		f.setVisible(true);
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);

		LinkHandler lh = new LinkHandler(jep);
		jep.addHyperlinkListener(lh);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JTextField tf = new JTextField("sample");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 5;
		c.gridy = 1;
		c.gridwidth = 15;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(tf, c);

		JButton b1 = new JButton("prikazi");
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.prikazi(tf.getText());
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(b1, c);

		JButton b2 = new JButton("Sadrzaj");
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					lh.sadrzaj(new URL("test.html"));
				} catch (MalformedURLException exc) {
					exc.printStackTrace();
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(b2, c);

		try {
			jep.setPage("test.html");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private class FrameShower implements Runnable {
		private Frame frame;

		public FrameShower(Frame frame) {
			this.frame = frame;
		}

		public void run() {
			this.frame.setVisible(true);
		}

	}
}

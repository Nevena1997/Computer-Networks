package drugi;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{
	private Writer out;
	private int level = 0;
	private boolean inHeader = false;
	private static String lineSeparator = System.getProperty("line.leparator", "\r\n");

	public ParserCallbackImpl(Writer out) {
		this.out = out;
	}


	public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos) {
		int newLevel = 0;
		if(t == HTML.Tag.H1){
			newLevel = 1;
		}
		else if(t == HTML.Tag.H2){
			newLevel = 2;
		}
		else if(t == HTML.Tag.H3){
			newLevel = 3;
		}
		else if(t == HTML.Tag.H4){
			newLevel = 4;
		}
		else if(t == HTML.Tag.H5){
			newLevel = 5;
		}
		else if(t == HTML.Tag.H6){
			newLevel = 6;
		}
		else {
			return;
		}

		this.inHeader = true;
		try {
			if(newLevel > this.level) {
				for(int i = 0; i < newLevel - this.level; i++){
					this.out.write("<ul>" + lineSeparator + "<li>");
				}
			}
			else if(newLevel < this.level) {
				for(int i = 0; i < this.level - newLevel; i++) {
					this.out.write(lineSeparator + "</ul>" + lineSeparator);
				}
				this.out.write(lineSeparator + "<li>");
			}
			else {
				this.out.write(lineSeparator + "<li>");
			}

			this.level = newLevel;
			this.out.flush();

		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	public void handleEndTag(HTML.Tag t, int pos) {
		if(t == HTML.Tag.H1 || t == HTML.Tag.H2 || t == HTML.Tag.H3
				|| t == HTML.Tag.H4 || t == HTML.Tag.H5 || t == HTML.Tag.H6) {
			this.inHeader = false;
		}

		if(t == HTML.Tag.HTML) {
			try {
				while(this.level-- > 0)
					this.out.write(lineSeparator + "</ul>");
				this.out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void handleText(char[] data, int pos) {
		if(this.inHeader){
			try {
				this.out.write(data);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

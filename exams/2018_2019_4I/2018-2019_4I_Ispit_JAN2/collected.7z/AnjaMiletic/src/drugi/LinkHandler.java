package drugi;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

public class LinkHandler implements HyperlinkListener{
	private JEditorPane pane;

	public LinkHandler(JEditorPane pane){
		this.pane = pane;
	}

	public void hyperlinkUpdate(HyperlinkEvent evt) {

	}

	public void sadrzaj(URL url){
		ParserGetter pg = new ParserGetter();
		ParserCallbackImpl pc = new ParserCallbackImpl(new OutputStreamWriter(System.out));
		HTMLEditorKit.Parser p = pg.getParser();

		try {
			InputStreamReader in = new InputStreamReader(url.openStream(), "UTF-8");
			p.parse(in, pc, true);
		} catch(IOException ex){
			ex.printStackTrace();
		}
	}

	public void prikazi(String text){
		try {
			URL url = new URL(text);
			this.pane.setPage(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

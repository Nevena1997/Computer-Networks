import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerSoket {
	public static void main(String[] args) {
		int port = 12345;

		try(ServerSocket server = new ServerSocket(port)) {
			Socket klijent = server.accept();
			BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));



		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if()
		}
	}
}

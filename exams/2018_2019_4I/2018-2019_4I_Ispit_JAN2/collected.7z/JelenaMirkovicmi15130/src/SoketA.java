import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class SoketA {
	public static void main(String[] args) {
		int port = 12345;
		String host = "localhost";
		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;

		try(Socket sock = new Socket(host, port)) {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));


			String s;
			while(s = sc.nextLine() != null){

				out.write(s);
				out.newLine();
				out.flush();

			}

		} catch(UnknownHostReference e) {

		} finally {
			if(in.read() != -1)
				in.close();
			if(out.newLine() != -1)
				out.close();
			if(sc.hasNext() != -1)
				sc.close();
		}

	}
}
import javax.swing.JFrame;

public class DrugiZadatak {
	public static final String HOME = "https://www.matf.bg.ac.rs/~filip";
	public static void main(String[] args) {
		JFrame panel = new JFrame(arg0);

	}

}

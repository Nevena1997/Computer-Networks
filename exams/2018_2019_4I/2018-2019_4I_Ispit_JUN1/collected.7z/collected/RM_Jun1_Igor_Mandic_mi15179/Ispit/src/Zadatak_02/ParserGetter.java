package Zadatak_02;

import javax.swing.text.html.HTMLEditorKit;

public class ParserGetter extends HTMLEditorKit{

	private static final long serialVersionUID = 1L;

	@Override
	protected Parser getParser() {
		// TODO Auto-generated method stub
		return super.getParser();
	}
}

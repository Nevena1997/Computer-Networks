package Zadatak_01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;

public class ObradaKlijenta implements Runnable{

	private Socket klijent;
	private List<Socket> listaKlijenata;

	public ObradaKlijenta(Socket klijent, List<Socket> listaKlijenata) {
		this.klijent = klijent;
		this.listaKlijenata = listaKlijenata;
	}
	@Override
	public void run() {
		try {
			StringBuilder recOdKlijenta = new StringBuilder();
			boolean ind = false;
			if(!ind){
				BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
				int b;
				while((b = in.read())!= -1){
					recOdKlijenta.append((char)b);
					if (b == 0)
						break;
				}
				ind = true;
			}
			for(int i = 0; i<listaKlijenata.size(); i++){
				Socket klijentPom = listaKlijenata.get(i);
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijentPom.getOutputStream()));
				out.write(recOdKlijenta.toString());
				out.write(0);
				out.flush();
				System.out.println(klijentPom);
			}
			System.out.println("izasao");
			ind = false;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

}

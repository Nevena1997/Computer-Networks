package Zadatak_02;

import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{
	private JEditorPane jep;

	public ParserCallbackImpl(JEditorPane jep) {
		this.jep = jep;
	}
}

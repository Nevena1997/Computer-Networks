package Zadatak_01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Klijent {

	public static void main(String[] args) {
		String host = "localhost";
		try(Socket klijent = new Socket(host, 12345)) {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream(), "UTF-8"));
			BufferedReader in = new BufferedReader(new InputStreamReader(klijent.getInputStream(), "UTF-8"));
			while(true){
				Scanner sc = new Scanner(System.in);

				String rec = sc.nextLine();

				out.write(rec);
				out.write(0);
				out.flush();
				StringBuilder rez = new StringBuilder();
				int b;

				while((b = in.read()) != -1){
					rez.append((char)b);
					if(b == 0){
						break;
					}
				}

				System.out.println(rez);

			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package Zadatak_02;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(500, 700);
		f.setResizable(true);
		dodajKomponente(f.getContentPane());
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});


	}

	private static void dodajKomponente(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);
		JScrollPane skrol1 = new JScrollPane(jep1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.weightx = 1.0;
		c.ipadx = 0;
		c.ipady = 300;
		pane.add(skrol1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		JScrollPane skrol2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.weightx = 1.0;
		c.ipadx = 0;
		c.ipady = 300;
		pane.add(skrol2, c);

		JTextArea putanjaDoURL = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(putanjaDoURL, c);

		JButton prikazi = new JButton("Prikazi");

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				prikaziStranice(jep1, jep2, putanjaDoURL);

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(prikazi, c);

		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				osveziStranicu(jep1, jep2);

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(osvezi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				sacuvajTrenutniSadrzaj(jep1, putanjaDoURL);
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(sacuvaj, c);
	}

	protected static void sacuvajTrenutniSadrzaj(JEditorPane jep1, JTextArea putanjaDoURL) {
		String sadrzaj = jep1.getText();
		String putanja = putanjaDoURL.getText();
		putanja = putanja.substring(putanja.indexOf("C"));
		System.out.println(putanja);

		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(putanja)));
			out.write(sadrzaj);
			out.flush();
;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected static void osveziStranicu(JEditorPane jep1, JEditorPane jep2) {
		String sadrzajStranice = jep1.getText();
		jep2.setText(sadrzajStranice);

	}

	protected static void prikaziStranice(JEditorPane jep1, JEditorPane jep2, JTextArea putanjaDoURL) {
		String putanja = putanjaDoURL.getText();
		try {
			URL u = new URL(putanja);
			jep2.setPage(u);

			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			int b;
			StringBuilder sadrzaj = new StringBuilder();
			while((b = in.read()) != -1){
				sadrzaj.append((char)b);
			}
			System.out.println(sadrzaj);
			jep1.setText(sadrzaj.toString());

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

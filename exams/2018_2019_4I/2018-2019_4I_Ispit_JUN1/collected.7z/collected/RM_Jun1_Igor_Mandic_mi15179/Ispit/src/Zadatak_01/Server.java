package Zadatak_01;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class Server {

	public static void main(String[] args) {
		int indeks = -1;
		List<Socket> listaKlijenata = new ArrayList<>();
		try(ServerSocket server = new ServerSocket(12345)) {

			while(true){
				Socket klijent = server.accept();
				indeks += 1;
				listaKlijenata.add(indeks, klijent);
				ObradaKlijenta ok = new ObradaKlijenta(klijent, listaKlijenata);
				new Thread(ok).start();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

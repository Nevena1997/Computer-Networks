package RM_Jun1_Tijana_Todorov_mi18485;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class Drugi {

	public static void main(String[] args) {

		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		jf.setSize(800, 600);

		addComponent(jf.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				jf.setVisible(true);
			}
		});
	}

	private static void addComponent(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jp = new JEditorPane();
		jp.setEditable(false);

		JEditorPane jp1 = new JEditorPane();
		jp1.setEditable(true);

		JScrollPane js1 = new JScrollPane(jp);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 200;
		c.gridwidth = 4;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(js1,c);

		JScrollPane js2 = new JScrollPane(jp1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 200;
		c.gridwidth = 4;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(js2,c);

		JTextArea jarea = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(jarea,c);

		JButton jb1 = new JButton("Prikazi");
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String text = jarea.getText();
				try {
					URL u = new URL(text);
					try {
						jp.setPage(u);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				} catch (MalformedURLException e1) {
					System.out.println("Neispravan url");
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(jb1,c);

		JButton jb2 = new JButton("Osvezi");

		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				ParserGetter pg = new ParserGetter();
				ParserCallback1 pc = new ParserCallback1(new OutputStreamWriter(System.out));
				HTMLEditorKit.Parser p = pg.getParser();
				InputStreamReader in = new InputStreamReader(System.in);
				try {
					p.parse(in, pc, true);
					String text = jarea.getText();
					URL u = new URL(text);
					jp1.setPage(u);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(jb2,c);

		JButton jb3 = new JButton("Sacuvaj");
		jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {


			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(jb3,c);
	}

}

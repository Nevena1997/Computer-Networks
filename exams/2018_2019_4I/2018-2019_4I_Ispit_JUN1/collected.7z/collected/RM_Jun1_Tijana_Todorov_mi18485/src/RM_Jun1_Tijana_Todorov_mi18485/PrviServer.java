package RM_Jun1_Tijana_Todorov_mi18485;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Set;

public class PrviServer {
	public static int port = 12345;
	static Set<Integer> klijenti;
	public static void main(String[] args) {

		try (ServerSocket server = new ServerSocket(port)){

			int id = 0;
			while(true){
				try (Socket connection = server.accept()) {

					BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
					StringBuffer sb = new StringBuffer();

					bw.write("Uspesna konekcija sa serverom!");
					bw.flush();
					id++;
					/*if(connection != null){
						id++;
						//System.out.println("Konekcija, novi klijent: id = " + id);
						klijenti.add(id);
						bw.write("Uspesna konekcija sa serverom!");
						bw.flush();
					}*/
					int c;
					while ((c = br.read())!= -1) {
						sb.append((char)c);

					}
					bw.write(sb.toString());
					bw.flush();


					/*
					String linija = null;
					while (br.readLine() != null) {
						linija = br.readLine();
						System.out.println("Server je primio poruku: " + linija);
					}*/

					/*
					if(connection != null){
						id++;
						//System.out.println("Konekcija, novi klijent: id = " + id);
						klijenti.add(id);
						bw.write("Uspesna konekcija sa serverom!");
						bw.flush();
					}*/
					/*	if(connection.isClosed()){
				id--;
				System.out.println("Konekcija, klijent: id je napustio = " + id);
				bw.write("Uspesna konekcija sa serverom!");
			}*/
				connection.close();
				bw.write("Klijent + " + id + " je napustio chat");
				bw.flush();
				br.close();
				bw.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

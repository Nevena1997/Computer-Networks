package RM_Jun1_Tijana_Todorov_mi18485;

import javax.swing.text.html.HTMLEditorKit;

@SuppressWarnings("serial")
public class ParserGetter extends HTMLEditorKit {
@Override
protected Parser getParser() {
	// TODO Auto-generated method stub
	return super.getParser();
}

}

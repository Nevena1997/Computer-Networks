package RM_Jun1_Tijana_Todorov_mi18485;

import java.io.OutputStreamWriter;

import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallback1 extends ParserCallback {

	private OutputStreamWriter out;

	public ParserCallback1(OutputStreamWriter out) {
		this.out = out;
	}

	@Override
	public void handleText(char[] data, int pos) {
		System.out.println(data);
			super.handleText(data, pos);
	}
}

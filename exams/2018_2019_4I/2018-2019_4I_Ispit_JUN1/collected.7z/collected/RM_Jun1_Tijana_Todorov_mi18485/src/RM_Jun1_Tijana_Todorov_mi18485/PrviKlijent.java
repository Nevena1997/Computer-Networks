package RM_Jun1_Tijana_Todorov_mi18485;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class PrviKlijent {

	public static void main(String[] args) {

		try (Socket soc = new Socket("localhost", PrviServer.port)) {

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(soc.getOutputStream()));
			BufferedReader br1 = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			StringBuffer sb = new StringBuffer();

			int c;
			while ((c = br1.read())!= -1) {
				sb.append((char)c);
				System.out.print((char)c);

			}
			String server = sb.toString();
			System.out.println(server);

			String linije = null;
			while ((linije = br.readLine())!=null) {
				bw.write(linije);
				bw.flush();
			}



			br.close();
			bw.close();
			br1.close();
			soc.close();

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

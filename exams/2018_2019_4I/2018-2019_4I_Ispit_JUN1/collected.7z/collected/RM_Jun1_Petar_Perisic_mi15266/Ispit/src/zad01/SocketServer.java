package zad01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer {

	private static final int PORT = 12345;

	public static void main(String[] args) {
		try (ServerSocket server = new ServerSocket(PORT)) {
			Socket client = server.accept();

			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			out.write("Hello there!\r\n");
			out.write("General Kenobi ...\r\n");
			out.flush();

			String data = null;
			while ((data = in.readLine()) != null) {
				System.err.println(data);
			}

			client.close();
		} catch (Exception e) {
			System.err.println("Error: " + e);
			e.printStackTrace();
		}
	}

}

package zad01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class ThreadClient extends Thread {

	private int id;
	private Socket socket;

	public ThreadClient(int id, Socket socket) {
		this.id = id;
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			Scanner sc = new Scanner(System.in);

			String data;
			while (true) {
				data = sc.nextLine().trim();

				if (data.compareToIgnoreCase("quit") == 0) {
					out.write("bye");
					break;
				}

				// send msg
				out.write(data + "\r\n");

				// read msg
				while ((data = in.readLine()) != null)
					System.out.println(data);
			}

			out.close();
			in.close();
			sc.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int getClientID() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

}

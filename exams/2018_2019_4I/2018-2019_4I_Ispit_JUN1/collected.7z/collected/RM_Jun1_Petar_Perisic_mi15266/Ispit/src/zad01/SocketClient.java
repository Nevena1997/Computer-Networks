package zad01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class SocketClient {

	private static final int PORT = 12345;
	private static final String HOST = "localhost";

	public static void main(String[] args) {
		BufferedReader stdIn = null;
		BufferedReader netIn = null;
		BufferedWriter netOut = null;

		try (Socket connection = new Socket(HOST, PORT)) {
			stdIn = new BufferedReader(new InputStreamReader(System.in));
			netIn = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			netOut = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));

			String data = null;
			while ((data = netIn.readLine()) != null) {
				System.out.println(data);
			}

			String userIn = null;
			System.out.print("# ");
			while ((userIn = stdIn.readLine()).trim().compareToIgnoreCase("stop") != 0) {
				netOut.write(userIn + "\r\n");
				netOut.flush();
				System.out.print("# ");
			}
		} catch (IOException e) {
			System.err.println("Error: " + e);
			e.printStackTrace();
		} finally {
			if (stdIn != null && netIn != null && netOut != null) {
				try {
					stdIn.close();
					netIn.close();
					netOut.close();
				} catch (IOException e2) {
					System.err.println("Error: " + e2);
					e2.printStackTrace();
				}
			}
		}
	}

}

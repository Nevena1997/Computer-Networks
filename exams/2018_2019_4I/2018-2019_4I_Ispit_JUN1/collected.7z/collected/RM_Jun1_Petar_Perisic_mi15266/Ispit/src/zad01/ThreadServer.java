package zad01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

public class ThreadServer {

	private static final int PORT = 12345;

	private static int clientId = 0;
	private static ArrayList<ThreadClient> clientList = new ArrayList<ThreadClient>();

	public static void main(String[] args) {
		try (ServerSocket server = new ServerSocket(PORT)){
			while (true) {
				Socket clientSocket = server.accept();
				ThreadClient client = new ThreadClient(clientId, clientSocket);

				client.start();

				clientList.add(clientId, client);

				clientId++;

				readAndSend();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// read all messages and send to other clients
	private static void readAndSend() {
		// go through all clients
		Iterator<ThreadClient> it = clientList.iterator();
		while (it.hasNext()) {
			ThreadClient tc = it.next();
			it.remove();

			try {
				BufferedReader in = new BufferedReader(new InputStreamReader(tc.getSocket().getInputStream()));
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(tc.getSocket().getOutputStream()));
				// read client message
				String data = in.readLine();

				// send to all other clients
				Iterator<ThreadClient> it2 = clientList.iterator();
				while (it2.hasNext()) {
					ThreadClient tc2 = it2.next();
					it2.remove();

					// check if we are not sending client message to himself
					if (tc2.equals(tc)) {
						continue;
					}

					// check if he is gone
					if (data.trim().compareToIgnoreCase("bye") == 0) {
						int id = tc.getClientID();
						out.write("Client " + id +" has left the chat ...\r\n");
						out.flush();

						clientList.remove(id);
					} else { // write his message to all other clients
						out.write(data);
						out.flush();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

}

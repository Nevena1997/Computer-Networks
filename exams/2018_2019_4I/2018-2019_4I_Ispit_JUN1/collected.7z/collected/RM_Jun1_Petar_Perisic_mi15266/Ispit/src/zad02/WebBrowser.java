package zad02;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class WebBrowser {

	private static final String HOME_PAGE = "file:///C:/Users/nalog/Desktop/1.html";

	public static void main(String[] args) {
		JFrame frame = new JFrame("HTML Editor");
		frame.setSize(new Dimension(600, 700));
		frame.setResizable(true);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		// html code
		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);

		JScrollPane sp1 = new JScrollPane(jep1);

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.gridwidth = 4;
		constraints.ipadx = 0;
		constraints.ipady = 270;
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;

		contentPane.add(sp1, constraints);

		// html prez
		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);

		JScrollPane sp2 = new JScrollPane(jep2);

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 1;
		constraints.gridwidth = 4;
		constraints.ipadx = 0;
		constraints.ipady = 270;
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;

		contentPane.add(sp2, constraints);

		// address bar
		JTextArea addBar = new JTextArea(HOME_PAGE);
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 2;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 0.0;



		contentPane.add(addBar, constraints);

		LinkHandler lh = new LinkHandler(jep1, jep2, addBar);
		jep1.addHyperlinkListener(lh);
		jep2.addHyperlinkListener(lh);

		// BtShow
		JButton btShow = new JButton("Prikazi");

		btShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jep1.setText("");
				jep2.setText("");
				System.out.println(addBar.getText());
				lh.goToPage(addBar.getText());
			}
		});

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 1;
		constraints.gridy = 2;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;

		contentPane.add(btShow, constraints);

		// BtRefresh
		JButton btRefresh = new JButton("Osvezi");

		btRefresh.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.showHtml();
			}
		});

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 2;
		constraints.gridy = 2;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;

		contentPane.add(btRefresh, constraints);

		// BtSave
		JButton btSave = new JButton("Sacuvaj");

		btSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.saveToFile();
			}
		});

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 3;
		constraints.gridy = 2;
		constraints.gridwidth = 1;
		constraints.ipadx = 0;
		constraints.ipady = 0;
		constraints.weightx = 0.0;
		constraints.weighty = 0.0;

		contentPane.add(btSave, constraints);
	}

}

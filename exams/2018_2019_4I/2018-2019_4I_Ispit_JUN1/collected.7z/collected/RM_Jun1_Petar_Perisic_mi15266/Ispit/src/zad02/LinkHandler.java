package zad02;

import java.io.BufferedWriter;

import java.io.FileOutputStream;
import java.io.IOException;

import java.io.OutputStreamWriter;

import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkListener;


public class LinkHandler implements HyperlinkListener {

	private JEditorPane htmlText;
	private JEditorPane htmlShow;

	private JTextArea addBar;


	private static String content;

	public LinkHandler(JEditorPane j1, JEditorPane j2, JTextArea add) {
		this.htmlText = j1;
		this.htmlShow = j2;
		this.addBar = add;
	}

	public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent arg0) {

	};

	void goToPage(String urlString) {
		try {
			URL u = new URL(urlString);
			this.goToPage(u);
		} catch (Exception e) {
			String err = "<html><body> Could not load " + urlString + "</body> </html>";
			this.htmlText.setContentType("text/plain");
			this.htmlShow.setContentType("text/html");

			this.htmlText.setText(err);
			this.htmlShow.setText(err);
		}
	}

	void goToPage(URL url) {
		try {
			this.htmlText.setContentType("text/plain");
			this.htmlShow.setContentType("text/html");

			this.htmlShow.setPage(url);
			content = this.htmlShow.getText();
			this.htmlText.setText(content);
		} catch (IOException e) {
			String err = "<html> Could not load " + url.toString() + " </html>";
			this.htmlText.setContentType("text/plain");
			this.htmlShow.setContentType("text/html");

			this.htmlText.setText(err);
			this.htmlShow.setText(err);
		}
	}

	public void showHtml() {
		content = this.htmlText.getText();
		this.htmlShow.setContentType("text/html");
		this.htmlShow.setText(content);
	}

	public void saveToFile() {
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(addBar.getText())));
			String text = htmlText.getText();
			out.write(text);
			out.flush();
			out.close();
		} catch (Exception e) {
		}
	}

}

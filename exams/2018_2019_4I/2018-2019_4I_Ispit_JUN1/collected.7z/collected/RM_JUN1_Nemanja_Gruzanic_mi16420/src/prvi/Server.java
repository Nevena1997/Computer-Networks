package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		int port =12348;

		BufferedReader in = null;
		BufferedWriter out = null;

		try(ServerSocket server = new ServerSocket(port)){

			while(true){
				try(Socket client = server.accept()){
					System.out.println("uspesno povezivanje klijenta");
					in= new BufferedReader(new InputStreamReader(client.getInputStream()));
					out= new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

					String poruka;
					while((poruka = in.readLine()) != null){
							out.write(poruka);
							out.newLine();
							out.flush();
					}

				}

			}
		} catch(IOException e){
			e.printStackTrace();
		}

	}

}

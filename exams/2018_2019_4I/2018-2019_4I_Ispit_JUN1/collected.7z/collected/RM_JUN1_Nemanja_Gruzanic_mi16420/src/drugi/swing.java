package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;



public class swing {

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 600);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);
		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);

		JScrollPane scrollPane = new JScrollPane(jep1);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0.5;
		pane.add(scrollPane,c);

		JScrollPane scrollPane2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridwidth = 4;
		c.gridy = 1;
		c.weightx = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0.5;
		pane.add(scrollPane2,c);


		JTextArea textArea = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0;
		pane.add(textArea,c);
		JButton prikazi = new JButton("prikazi");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String str = textArea.getText();
				URL url;

				try {
					url = new URL(str);
					InputStream in = url.openStream();
					StringBuilder builder = new StringBuilder();
					int c;
					while((c = in.read()) != -1)
						builder.append((char)c);

					jep1.setText(builder.toString());

				}
				catch (IOException e) {
					e.printStackTrace();
				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 3;
		c.weightx = 0;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0;
		pane.add(prikazi,c);

		JButton osvezi = new JButton("osvezi");
		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sadrzaj = jep1.getText();
				jep2.setContentType("text/html");
				jep2.setText(sadrzaj);
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 4;
		c.weightx = 0;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0;
		pane.add(osvezi,c);

		JButton sacuvaj = new JButton("sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sadrzaj = jep1.getText();
				String putanja = textArea.getText().substring(8);
				try {
					OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(putanja));
					System.out.println(sadrzaj);
					fout.write(sadrzaj);
					fout.flush();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 5;
		c.gridwidth = 0;
		c.weightx = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weighty = 0;
		pane.add(sacuvaj,c);
	}
}

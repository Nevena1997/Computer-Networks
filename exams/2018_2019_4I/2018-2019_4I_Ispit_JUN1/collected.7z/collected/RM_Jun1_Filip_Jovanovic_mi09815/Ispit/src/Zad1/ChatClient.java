package Zad1;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {

	public static void main(String[] args) {

		String host = "localhost";
		int port = 12345;

		try (Socket s = new Socket(host, port);

			Scanner in = new Scanner(new InputStreamReader(s.getInputStream()));
			PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream()));
			Scanner sc = new Scanner(System.in);
			){

			while(true){

				// If there is input on stdin, send it to server out
				if(sc.hasNextLine()){
					out.println(sc.nextLine());
				}

				// if there is input on server in, print it to stdout
				if(in.hasNextLine()){
					System.out.println(in.nextLine());
				}

			}


		} catch (Exception e){
			e.printStackTrace();
		}

	}

}

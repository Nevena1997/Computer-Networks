package Zad1;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class ChatServer {

	public static void main(String[] args) {

		int port = 12345;
		int nextId = 0;

		// List of all messages ever sent trough this chat server
		ArrayList<String> msg = new ArrayList<String>();

		try (ServerSocket server = new ServerSocket(port)){

			while(true){

				try(Socket client = server.accept()){

					// Create new runnable, give it input and output streams, id,
					// and reference to message list
					ClientHandler cHandler = new ClientHandler(client.getInputStream(),
															   client.getOutputStream(),
															   nextId,
															   msg);

					System.out.println("Klijent " + nextId + " se pridruzio chatu.");
					msg.add("Klijent " + nextId + " se pridruzio chatu.");

					nextId++;
					// start the thread
					new Thread(cHandler).start();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static class ClientHandler implements Runnable{

		int clientId;
		Scanner cin;
		PrintWriter cout;
		ArrayList<String> msgList;
		int idx; // index of last read message

		public ClientHandler(InputStream in, OutputStream out, int id, ArrayList<String> msg) {
			clientId = id;
			cin = new Scanner(new InputStreamReader(in));
			cout = new PrintWriter(new OutputStreamWriter(out));
			msgList = msg;
			idx = 0;
			cout.println("Dobrodosao!");
			cout.flush();
		}

		@Override
		public void run() {
			try{
				while(true){
					if(cin.hasNextLine()){
						// if client sent a message
						System.out.println(cin.nextLine());
						synchronized (msgList) {
							// add the message to the list
							msgList.add(cin.nextLine());
//							System.out.println(cin.nextLine());
							notifyAll();
						}
						Thread.yield();
					}

					// if there are unread messages
					if(msgList.size() > idx){
						// send them to the client
						cout.println(msgList.get(idx++));
						cout.flush();
					}

				}
			} catch(Exception e){
				msgList.add("Klijent " + clientId + " je napustio chat.");
			}
		}

	}

}

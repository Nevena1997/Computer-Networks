package Zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static void main(String[] args) {

		JFrame frame = new JFrame("HTML Editor!!!");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setResizable(true);
		frame.setSize(400, 600);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}

	private static void addComponents(Container contentPane) {

		GridBagLayout layout = new GridBagLayout();
		contentPane.setLayout(layout);
		GridBagConstraints c = new GridBagConstraints();

		// Editable component
		JTextArea editable = new JTextArea();
		editable.setEditable(true);
		JScrollPane scrollPaneEditable = new JScrollPane(editable);
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(scrollPaneEditable, c);

		// Read-only component
		JEditorPane readOnly = new JEditorPane();
		readOnly.setEditable(false);
		JScrollPane scrollPaneReadOnly = new JScrollPane(readOnly);
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(scrollPaneReadOnly, c);

		// Text component
		JTextField urlField = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1.0;
		c.weighty = 0.0;
		contentPane.add(urlField, c);

		// Instantiate helper class
		Helper h = new Helper(editable, readOnly, urlField);

		// Buttons
		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				h.prikazi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 2;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btnPrikazi, c);

		JButton btnOsvezi = new JButton("Osvezi");
		btnOsvezi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				h.osvezi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 2;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btnOsvezi, c);


		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				h.sacuvaj();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 3;
		c.gridy = 2;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btnSacuvaj, c);

	}


	private static class Helper{

		private JTextArea editable;
		private JEditorPane readOnly;
		private JTextField urlField;

		public Helper(JTextArea editable, JEditorPane readOnly, JTextField urlField){
			this.editable = editable;
			this.readOnly = readOnly;
			this.urlField = urlField;
		}

		public void prikazi(){
			URL url;
			try {
				url = new URL(urlField.getText().trim());

				try {
					readOnly.setPage(url);

				} catch (IOException e){
					readOnly.setText("<html>Unable to load page!</html>");
				}

				try {
					Scanner sc = new Scanner(new File(url.getFile()));
					StringBuilder sb = new StringBuilder();

					while(sc.hasNextLine()){
						sb.append(sc.nextLine());
						sb.append('\n');
					}
					sc.close();
					editable.setText(sb.toString());

				} catch (Exception e){
					editable.setText("<html>Something is wrong...</html>");
				}

			} catch (MalformedURLException e1) {
				readOnly.setText("<html>Malformed URL!</html>");
				editable.setText("<html>Malformed URL!</html>");
			}

		}

		public void osvezi(){

			String text = editable.getText();
			readOnly.setText(text);
		}

		public void sacuvaj(){
			URL url;
			String text = editable.getText();
			PrintWriter pw;
			try {
				url = new URL(urlField.getText().trim());
				File file = new File(url.getFile());
				pw = new PrintWriter(file);

				pw.print(text);
				pw.close();

			} catch (Exception e1) {

			} finally {
//				pw.close();
			}
		}

	}
}
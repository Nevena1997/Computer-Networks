package zad2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;

public class LinkHandler {
	private JEditorPane jepShow, jepPres;
	private JTextArea adress;


	public LinkHandler(JEditorPane jepShow, JEditorPane jepPres, JTextArea adress) {
		this.jepShow = jepShow;
		this.jepPres = jepPres;
		this.adress = adress;
	}

	public void goToPage(String surl) {
		try {
			URL url = new URL(surl);
			goToPage(url);
		} catch (Exception e) {
			System.err.println(e);
		}
	}


	private void goToPage(URL url) {
		String text = url.getFile();
		jepPres.setText(text);
	}



	public void prikazi() {
		jepShow.setText(jepPres.getText());
		adress.setText(jepPres.getText());
		return;
	}


	public void osvezi() {
		jepPres.setText("Prikaz :)");
		return;
	}


	public void sacuvaj() {
		File f = new File(this.adress.getText());
		try {
			FileWriter fw = new FileWriter(f);
			fw.write(this.jepShow.getText());
			fw.close();
		} catch (IOException e) {
			System.err.println(e);
		}

		String s = f.getAbsolutePath();
		System.out.println(s);
		return;
	}




}

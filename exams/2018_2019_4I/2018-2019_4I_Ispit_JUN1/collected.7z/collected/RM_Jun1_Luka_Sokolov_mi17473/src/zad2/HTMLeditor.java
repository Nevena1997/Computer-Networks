package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLeditor {
	public static void main(String[] args){
		JFrame f = new JFrame("HTML editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);
		f.setSize(800, 600);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		JEditorPane jepShow = new JEditorPane();
		jepShow.setEditable(true);

		JEditorPane jepPres = new JEditorPane();
		jepPres.setEditable(false);

		pane.setLayout(new GridBagLayout());

		JScrollPane jspShow = new JScrollPane(jepShow);
		JScrollPane jspPres = new JScrollPane(jepPres);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridheight = 1;
		gbc.gridwidth = 5;
		gbc.weightx = 1;
		gbc.weighty = 1;
		pane.add(jspShow, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridheight = 1;
		gbc.gridwidth = 4;
		gbc.weightx = 1;
		gbc.weighty = 1;
		pane.add(jspPres, gbc);

		String s = "C:\\Users\\nalog\\Desktop\\RM_Jun1_Luka_Sokolov_mi17473\\src\\1.html";
		JTextArea adress = new JTextArea("FILE:///"+s);
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weighty = 0;
		gbc.weightx = 1;
		gbc.gridwidth = 1;
		pane.add(adress, gbc);

		LinkHandler lh = new LinkHandler(jepShow, jepPres, adress);
		String url = adress.getText();
		lh.goToPage(url);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.prikazi();
			}
		});
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.weighty = 0;
		gbc.weightx = 0;
		pane.add(prikazi, gbc);

		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.osvezi();
			}
		});
		gbc.gridx = 2;
		gbc.gridy = 2;
		gbc.weighty = 0;
		gbc.weightx = 0;
		pane.add(osvezi, gbc);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lh.sacuvaj();
			}
		});
		gbc.gridx = 3;
		gbc.gridy = 2;
		gbc.weighty = 0;
		gbc.weightx = 0;
		pane.add(sacuvaj, gbc);

	}

}

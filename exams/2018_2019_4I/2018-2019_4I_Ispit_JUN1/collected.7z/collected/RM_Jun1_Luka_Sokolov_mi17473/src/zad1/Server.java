package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {
	public static void main(String[] args){
		int port = 12345;

		ServerSocket server = null;
		BufferedReader fromClient = null;
		BufferedWriter toClient = null;

		try {
			server = new ServerSocket(port);
			System.out.println("Opened connection with server");

			while(true){
				Socket client = server.accept();
				System.out.println("Accepted connection from client");

				fromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
				toClient = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

				String s = fromClient.readLine();
				System.out.println("I've read " + s);
				if(s == "exit"){
					System.out.println("Klijent je prekinuo vezu");
					break;
				}

				toClient.write(s);
				toClient.newLine();
				toClient.flush();
				System.out.println("I've sent " + s);


			}

		} catch (IOException e) {
			System.err.println(e);
		} finally {
			try {
				if (server != null) {
					server.close();
				}
				if (toClient != null){
					toClient.close();
				}
				if (fromClient != null){
					fromClient.close();
				}
			} catch (Exception ignore) {

			}
		}

	}
}

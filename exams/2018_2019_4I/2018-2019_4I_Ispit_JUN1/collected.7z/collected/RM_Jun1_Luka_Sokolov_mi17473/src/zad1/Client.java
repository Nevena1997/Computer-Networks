package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client extends Thread {
	public static void main(String[] args){
		int port = 12345;
		String host = "localhost";

		/* Thread c = new Thread(new Runnable() {

			@Override
			public void run() {

			}
		}).start(); */

		BufferedReader fromServer = null;
		BufferedWriter toServer = null;
		Scanner sc = null;

		try (Socket sock = new Socket(host, port)){
			fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			toServer = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			sc = new Scanner(System.in);

			while(true){
				String msg = sc.nextLine();


				toServer.write(msg);
				toServer.newLine();
				toServer.flush();

				if(sc.nextLine() == "exit"){   
					break;
				}

				String s = fromServer.readLine();
				System.out.println(s);

			}
		} catch (IOException e) {
			System.err.println(e);
		} finally {
			try {
				if (fromServer != null){
					fromServer.close();
				}
				if (toServer != null){
					toServer.close();
				}
				if (sc != null ){
					sc.close();
				}
			}catch (Exception ignore) {
			}

		}

	}
}

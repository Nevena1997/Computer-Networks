package zad2;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import javafx.scene.layout.GridPane;


public class HTMLEditor {

	public static void main(String[] args) {

		JLayeredPane gp = new JLayeredPane();
		gp.setLayout(new GridBagLayout());

		JEditorPane jepEditor = new JEditorPane();
		jepEditor.setEditable(false);
		JEditorPane jepResult = new JEditorPane();
		jepEditor.setEditable(true);
		JScrollPane jspEditor = new JScrollPane(jepEditor);
		JScrollPane jspResult = new JScrollPane(jepResult);
		JTextArea fileLocation = new JTextArea("FILE://");
		JButton prikazi = new JButton("Prikazi");
		JButton osvezi = new JButton("Osvezi");
		JButton sacuvaj = new JButton("Sacuvaj");

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;

		gp.add(jspEditor, c);

		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		gp.add(jspResult, c);

		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		gp.add(fileLocation, c);

		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		gp.add(prikazi, c);

		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		gp.add(osvezi, c);

		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		gp.add(sacuvaj, c);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String input = fileLocation.getText();
					StringBuffer content = new StringBuffer();

					URL url = new URL("file", "localhost", input);

					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

					int c;
					while((c = in.read()) != -1)
						content.append((char) c);

					jepEditor.setText(content.toString());
					jepResult.setContentType("text/html");
					jepResult.setText(content.toString());

				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jepResult.setContentType("text/html");
				jepResult.setText(jepEditor.getText());
			}
		});

		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					File saveTo = new File(fileLocation.getText());
					FileWriter fw = new FileWriter(saveTo);
					fw.write(jepEditor.getText());
					fw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});


		JFrame jf = new JFrame("HTML Editor");
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		jf.setSize(800, 600);
		jf.setLayeredPane(gp);
		jf.setVisible(true);
	}
}

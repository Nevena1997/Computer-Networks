package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Server {

	public static final int DEF_PORT = 12345;
	private static List<Thread> clients = new LinkedList<Thread>();

	public static void main(String[] args) {
		try (ServerSocket server = new ServerSocket(DEF_PORT)) {
			while (true) {
//				Socket client = server.accept();
//				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
//				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
//
//				String s;
//				while ((s = in.readLine()) != null) {
//					System.out.println("received: " + s);
//
//					out.write(s);
//					out.newLine();
//					out.flush();
//				}
//
//				in.close();
//				out.close();
//				client.close();

			Socket clientO = server.accept();
			Thread thr = new Thread(new Runnable() {
				private long id = Thread.currentThread().getId();
				private BufferedReader in = null;
				private BufferedWriter out = null;

				@Override
				public void run() {
					try (Socket client = clientO) {
						in = new BufferedReader(new InputStreamReader(client.getInputStream()));
						out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

						String s;
						while ((s = in.readLine()) != null) {
							out.write(s);
							out.newLine();
							out.flush();

//							for (Thread clnt : clients) {
								// kako poslati svima?
								// nova klasa?
//							}
						}

					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							if (in != null)
								in.close();
							if (out != null)
								out.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});

			if (! clients.contains(thr)) {
				clients.add(thr);
				thr.start();
				long i = thr.getId();
				System.out.println(i);
			}

//			for (Thread t : clients)
//				t.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

//	private static class Runner implements Runnable {
//		static long id = 0;
//		private BufferedReader in = null;
//		private BufferedWriter out = null;
//		private Socket s;
//
//		Runner(Socket s) {
//			this.s = s;
//			this.id = Thread.currentThread().getId();
//		}
//
//		public void posalji(String s) throws IOException {
//			out.write(s);
//			out.newLine();
//			out.flush();
//		}
//
//		@Override
//		public void run() {
//			try (Socket client = this.s) {
//
//				this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
//				this.out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
//
//				String s;
//				while ((s = in.readLine()) != null) {
//
//				}
//
//			} catch (IOException e) {
//				e.printStackTrace();
//			} finally {
//				try {
//					if (in != null)
//						in.close();
//					if (out != null)
//						out.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//
//		}
}

package prvi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Klijent {

	public static void main(String[] args) {
		Scanner sc = null;
		PrintWriter out = null;
		BufferedReader in = null;

		try (Socket client = new Socket("localhost", Server.DEF_PORT)) {
			sc = new Scanner(System.in);
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(client.getOutputStream());

			String s;
			while ((s = sc.nextLine()) != null) {
//				System.err.println(s);
				out.println(s);
				out.flush();

				System.out.println(in.readLine());
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (sc != null)
					sc.close();
				if (in != null)
					in.close();
				if (out != null)
					out.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

}

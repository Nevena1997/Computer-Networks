package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Prozor {

	// putanje za testiranje
	private static final String test1 = "file:///C:/Users/nalog/Desktop/RM_jun1_David_Gavrilovic_mi15294/prvi.html";
	private static final String test2 = "file:///C:/Users/nalog/Desktop/RM_jun1_David_Gavrilovic_mi15294/drugi.html";
	private static final String test3 = "file:///C:/Users/nalog/Desktop/RM_jun1_David_Gavrilovic_mi15294/treci.html";

	private static JFrame f = new JFrame("HTML editor");

	public static void main(String[] args) {
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//		f.setResizable(false);
		f.setSize(500, 650);

		init(f.getContentPane());

		EventQueue.invokeLater(new FrameShower(f));
	}

	private static void init(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane upperJep = new JEditorPane();
		JScrollPane scrollUpper = new JScrollPane(upperJep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = f.getHeight() / 2 - 50;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollUpper, c);

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = f.getHeight() / 2 - 50;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scroll, c);

		JTextArea addressBar = new JTextArea(test1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0;
		pane.add(addressBar, c);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String path = addressBar.getText();
				try {
					jep.setPage(path);

					URL url = new URL(path);
					BufferedReader in = new BufferedReader(
							new InputStreamReader(url.openStream()));

					int b;;
					StringBuilder sb = new StringBuilder();
					while ((b = in.read()) != -1)
						sb.append((char)b);
					in.close();

					upperJep.setText(sb.toString());
				} catch (IOException e) {
					upperJep.setText("izabrani fajl ne postoji");
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0;
		pane.add(btnPrikazi, c);

		JButton btnOsvezi = new JButton("Osvezi");
		btnOsvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
//				try {
					String s = upperJep.getText();
//					System.out.println(s);

					jep.setText(s);
//				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0;
		pane.add(btnOsvezi, c);

		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String s = upperJep.getText();
				String toBePath = addressBar.getText();

//				System.out.println(path);
				toBePath = toBePath.substring(8);
				System.out.println(toBePath);

				Path path = Paths.get(toBePath);
				System.out.println(path.toString());

				try {
					BufferedWriter out = new BufferedWriter(
						new OutputStreamWriter(
								new FileOutputStream(path.toString())));

					out.write(s);
					out.flush();
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

				System.err.println("sacuvano!");
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0;
		pane.add(btnSacuvaj, c);
	}

	private static class FrameShower implements Runnable {
		Frame f;

		FrameShower(Frame f) {
			this.f = f;
		}

		@Override
		public void run() {
			this.f.setVisible(true);
		}
	}
}

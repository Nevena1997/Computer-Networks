package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Editor {

	private static final String file = "file:///C:/Users/nalog/Desktop/RM_Jun1_Filip_Jovasevic_mi15142/Ispit/src/zad2/1.html";

	public static void main(String[] args) {

		JFrame f = new JFrame("HTML Editor");
		f.setSize(600, 700);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c= new GridBagConstraints();
		File f = new File(file.substring(file.indexOf("C")).trim());
//		File f = new File("C:/Users/nalog/Desktop/RM_Jun1_Filip_Jovasevic_mi15142/Ispit/src/zad2/1.html");
		StringBuffer text = new StringBuffer();
		try {
			FileInputStream fin = new FileInputStream(f);
			int b;
			while((b = fin.read()) != -1){
				text.append((char)b);
			}
			fin.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		JEditorPane jep1;
			jep1 = new JEditorPane();
			jep1.setEditable(true);
			jep1.setText(text.toString());
			JScrollPane scroll1 = new JScrollPane(jep1);
			c.fill = GridBagConstraints.HORIZONTAL;
			c.gridx = 0;
			c.gridy = 0;
			c.gridwidth = 4;
			c.weighty = 0.0;
			c.weightx = 0.0;
			c.ipadx = 0;
			c.ipady = 290;
			pane.add(scroll1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		try {
			jep2.setPage(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JScrollPane scroll2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.weighty = 0.0;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 290;
		pane.add(scroll2, c);

		JTextArea address = new JTextArea(file);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weighty = 0.0;
		c.weightx = 1.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(address, c);

		Functionalities func = new Functionalities(address, jep2, jep1);
		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				func.goToPage();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weighty = 0.0;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(prikazi, c);



		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				func.refresh();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weighty = 0.0;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(osvezi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weighty = 0.0;
		c.weightx = 0.0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(sacuvaj, c);
	}

}

package zad2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;

public class Functionalities {

	private JTextArea address;
	private JEditorPane pane;
	private JEditorPane pane2;

	public Functionalities(JTextArea address, JEditorPane pane, JEditorPane pane2) {
		this.address = address;
		this.pane = pane;
		this.pane2 = pane2;
	}

	public void goToPage(){
		String newAddress = address.getText();
		try {
			pane.setPage(newAddress);
			String filePath = address.getText();
			File f = new File(filePath.substring(filePath.indexOf("C")).trim());
			StringBuffer text = new StringBuffer();
			FileInputStream fin = new FileInputStream(f);
			int b;
			while((b = fin.read()) != -1){
				text.append((char)b);
			}
			fin.close();
			pane2.setText(text.toString());
		} catch (IOException e) {
			System.err.println("Page doesnt exist!");
			e.printStackTrace();
		}
	}

	public void refresh(){
		String text = pane2.getText();
		pane.setText(text);
	}

	public void save(){
		String fileText = pane2.getText();
		String filePath = address.getText();
		File f = new File(filePath.substring(filePath.indexOf("C")).trim());
		try {
			OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(f));
			fout.write(fileText);
			fout.close();
		} catch(IOException e){
			e.printStackTrace();
		}

	}
}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		try(Socket client = new Socket("localhost", Server.port)){
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			Scanner sc = new Scanner(System.in);

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			while(sc.hasNextLine()){
				String line = (String) sc.nextLine();
				out.write(line);
			}





		} catch (UnknownHostException e) {
			System.err.println(e);
		} catch (IOException e) {
			System.err.println(e);
		}
	}
}

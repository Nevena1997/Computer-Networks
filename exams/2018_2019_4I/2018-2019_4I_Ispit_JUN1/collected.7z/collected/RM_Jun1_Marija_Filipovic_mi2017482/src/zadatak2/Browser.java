package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLDocument;

public class Browser {
	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setSize(400, 600);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});
	}

	public static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);

		JScrollPane scrollPane1 = new JScrollPane(jep1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0;
		c.weighty = 1;
		pane.add(scrollPane1, c);

		JScrollPane scrollPane2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 480;
		c.weightx = 0;
		c.weighty = 1;
		pane.add(scrollPane2, c);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(addressBar, c);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String filePath = addressBar.getText();
				URL url = null;
				try {
					url = new URL(filePath);
					jep2.setPage(url);
				} catch (MalformedURLException e) {
					jep2.setText("<html>Could not open - URL not valid </html>");
				} catch (IOException e) {
					jep2.setText("<html>Could not open" + url + "</html>");
				}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(prikazi, c);

		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String code = jep1.getText();

				jep2.setText(code);
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(osvezi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String code = jep1.getText();

				try {
					FileOutputStream fileOut = new FileOutputStream(addressBar.getText());
					OutputStreamWriter out = new OutputStreamWriter(fileOut, "UTF-8");

					for(char i : code.toCharArray()){
						out.write((char)i);
					}
				} catch (IOException e) {
					jep2.setText("<html>Could not open </html>");
				}
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(sacuvaj, c);

	}
}

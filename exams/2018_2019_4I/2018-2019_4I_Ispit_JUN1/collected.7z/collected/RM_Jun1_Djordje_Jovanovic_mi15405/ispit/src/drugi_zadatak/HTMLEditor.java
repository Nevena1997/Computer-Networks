package drugi_zadatak;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static String fileUrl = "FILE:///home/1.html";

	public static void main(String[] args) {

		JFrame frame = new JFrame("HTML Editor");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 800);
		frame.setResizable(true);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});
	}

	public static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane textPane = new JEditorPane();
		textPane.setEditable(true);
		JScrollPane textScroll = new JScrollPane(textPane);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0;
		c.weighty = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 4;
		c.gridheight = 1;
		pane.add(textScroll, c);

		JEditorPane htmlPane = new JEditorPane();
		htmlPane.setEditable(false);
		JScrollPane htmlScroll = new JScrollPane(htmlPane);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0;
		c.weighty = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 4;
		c.gridheight = 1;
		pane.add(htmlScroll, c);

		JTextArea txtUrl = new JTextArea(fileUrl);
		c.fill = GridBagConstraints.WEST;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		pane.add(txtUrl, c);


		JButton btnShow = new JButton("Prikazi");
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fileLocation = txtUrl.getText();
					URL url = new URL(fileLocation);

					Scanner sc = new Scanner(url.openStream());
					StringBuilder sb = new StringBuilder();
					while (sc.hasNext()) {
						sb.append(sc.nextLine());
						sb.append(System.getProperty("line.separator", "\r\n"));
					}
					sc.close();

					textPane.setText(sb.toString());
					htmlPane.setPage(url);
				} catch (MalformedURLException ex) {
					htmlPane.setText("<html> URL nije validan </html>");
					ex.printStackTrace();
				} catch (IOException ex) {
					htmlPane.setText("<html> I/O Greska </html>");
					ex.printStackTrace();
				}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		pane.add(btnShow, c);

		JButton btnRefresh = new JButton("Osvezi");
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		pane.add(btnRefresh, c);

		JButton btnSave = new JButton("Sacuvaj");
		btnShow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fileLocation = txtUrl.getText();
					URL url = new URL(fileLocation);
					htmlPane.setPage(url);
				} catch (MalformedURLException ex) {
					htmlPane.setText("<html> URL nije validan </html>");
					ex.printStackTrace();
				} catch (IOException ex) {
					htmlPane.setText("<html> I/O Greska </html>");
					ex.printStackTrace();
				}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.gridheight = 1;
		pane.add(btnSave, c);

	}

}

package prvi_zadatak;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

public class Chat implements Runnable {

	private int id;
	private Socket socket;

	public Chat(int id, Socket socket) {
		this.id = id;
		this.socket = socket;
	}

	public int getId() {
		return this.id;
	}

	@Override
	public void run() {
		try {
			Scanner sc = new Scanner(new InputStreamReader(socket.getInputStream()));
			while (true) {
				String message = sc.nextLine();

				for (int i = 0; i < Server.clients.size(); i++) {
					Chat other = Server.clients.get(i);
					if (other.id != this.id) {
						sendMessage(message, other);
					}
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			for (int i = 0; i < Server.clients.size(); i++) {
				Chat other = Server.clients.get(i);
				if (other.id != this.id) {
					sendMessage("Klijent <" + this.id + "> je napustio chat.", other);
				}
			}
		}

	}

	private void sendMessage(String message, Chat other) {
		try {
			PrintWriter out = new PrintWriter(new OutputStreamWriter(other.socket.getOutputStream()));
			out.write(message);
			out.flush();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

}

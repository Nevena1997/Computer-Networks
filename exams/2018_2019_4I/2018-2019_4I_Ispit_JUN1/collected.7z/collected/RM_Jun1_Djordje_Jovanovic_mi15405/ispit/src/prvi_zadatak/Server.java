package prvi_zadatak;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

	public static final int PORT = 12345;
	public static List<Chat> clients = new ArrayList<Chat>();

	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(PORT);

			int nextId = 0;
			while (true) {
				Socket client = server.accept();
				Chat chat = new Chat(nextId++, client);
				clients.add(chat);
				chat.run();
			}

		} catch (IOException ex) {

		}
	}

}

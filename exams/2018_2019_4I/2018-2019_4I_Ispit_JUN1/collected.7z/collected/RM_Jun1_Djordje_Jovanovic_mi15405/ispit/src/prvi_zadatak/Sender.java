package prvi_zadatak;

import java.io.PrintWriter;
import java.util.Scanner;

public class Sender implements Runnable {

	PrintWriter out;

	public Sender(PrintWriter out) {
		this.out = out;
	}

	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			String message = sc.nextLine();
			out.println(message);
			out.flush();
		}
	}
}
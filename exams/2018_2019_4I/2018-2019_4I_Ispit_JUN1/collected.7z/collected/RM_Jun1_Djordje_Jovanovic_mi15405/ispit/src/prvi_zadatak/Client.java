package prvi_zadatak;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;


public class Client {

	public static final String HOST = "localhost";
	public static final int PORT = 12345;


	public static void main(String[] args) {

		InputStreamReader in = null;
		PrintWriter out = null;

		try {
			Socket client = new Socket(HOST, PORT);
			in = new InputStreamReader(client.getInputStream());
			out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));

			Thread t = new Thread(new Sender(out));
			t.start();

			in.close();
			out.close();
			client.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}

package sockets;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.Channels;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

public class Server {

	public static String host = "localhost";

	public static int port = 12345;

	public static void main (String []args) {

		System.out.println("host: " + host);

		byte[] niz = new byte[72];
		for (int i = 0; i < niz.length; i++) {
			niz[i] = 'a';
		}

		try (ServerSocketChannel server_channel = ServerSocketChannel.open();
				Selector selektor = Selector.open()) {

			if (!server_channel.isOpen() || !selektor.isOpen()) {
				System.exit(1);
			}

			server_channel.bind(new InetSocketAddress(port));
			server_channel.configureBlocking(false);
			server_channel.register(selektor, SelectionKey.OP_ACCEPT);

//			while (true) {
//		}

		} catch (IOException e) {
			e.printStackTrace();
		}


	}
}

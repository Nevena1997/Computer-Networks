package sockets;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.SocketChannel;

public class Client {

	public static void main(String []args) {

	String host = "localhost";
	int port = 12345;

	SocketAddress adress = new InetSocketAddress(host, port);
	try {
		SocketChannel klijent = SocketChannel.open(adress);

		ByteBuffer buffer = ByteBuffer.allocate(74);

		klijent.configureBlocking(false);

		while (true) {
			klijent.write(buffer);
		}

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}

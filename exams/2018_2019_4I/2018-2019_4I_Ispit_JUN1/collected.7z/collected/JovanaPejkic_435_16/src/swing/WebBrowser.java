package swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkListener;

public class WebBrowser {

	public static final String HOME_PAGE = "http://poincare.matf.bg.ac.rs/~filip";

	public static void main (String []args) {

		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f.setSize(400, 600);
		//	f.setSize(Math.max(400, f.getWidth()), Math.max(600, f.getHeight()));
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}


		});

	}


	public static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 5;
		c.gridheight = 2;
		c.ipadx = 600;
		c.ipady = 300;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(jep1, c);

		JScrollPane skrol1 = new JScrollPane(jep1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 5;
		c.gridheight = 1;
		c.ipadx = 600;
		c.ipady = 200;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(skrol1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 5;
		c.gridheight = 2;
		c.ipadx = 200;
		c.ipady = 600;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(jep2, c);


		JScrollPane skrol2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 5;
		c.gridwidth = 5;
		c.gridheight = 1;
		c.ipadx = 600;
		c.ipady = 200;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(skrol2, c);


		JTextArea tekst = new JTextArea("");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 6;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(tekst, c);




		JButton prikazi = new JButton("Prikazi");

		LinkHandler lh1 = new LinkHandler(jep1, tekst);
		prikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				lh1.prikazi();
			}

		});


		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 6;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(prikazi, c);


		JButton osvezi = new JButton("Osvezi");

		osvezi.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
//				lh1.__;
			}

		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 6;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(osvezi, c);


		JButton sacuvaj = new JButton("Sacuvaj");

		sacuvaj.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
   			   lh1.sacuvaj();
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 4;
		c.gridy = 6;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(sacuvaj, c);

	}



}

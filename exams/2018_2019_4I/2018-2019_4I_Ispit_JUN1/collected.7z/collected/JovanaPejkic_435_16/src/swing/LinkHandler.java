package swing;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLWriter;
import javax.swing.text.html.parser.TagElement;

import java.awt.TextArea;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.*;
import java.util.*;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane jep;
	private ArrayList<URL> stackURL;
	private int index;
	private JTextArea tekst;
	private String putanja;

	public LinkHandler(JEditorPane jep, JTextArea tekst) {
		this.jep = jep;
		this.stackURL = new ArrayList<>();
		this.index = -1;
		this.tekst = tekst;
	}

	public void prikazi() {

		try { // FileReader

			this.tekst.setText("fajl1.txt");
			this.putanja = this.tekst.getText().toString();

			FileInputStream file = new FileInputStream(new File(putanja));

			byte[] buffer = new byte[1024];
			try {
				file.read(buffer);
//				System.out.println(buffer);
				jep.setText(buffer.toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public void sacuvaj() {

		String gornji_tekst = this.jep.getText().toString();

		try {
			FileWriter fw = new FileWriter(this.putanja);

			fw.write(gornji_tekst);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void osvezi() {

	//	HTMLWriter hw = new HTMLWriter();

	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		// TODO Auto-generated method stub

		HyperlinkEvent.EventType type = evt.getEventType();
		URL u = evt.getURL();

		if (type == HyperlinkEvent.EventType.ACTIVATED &&
				!u.equals(stackURL.get(index))) {
			try {
				jep.setPage(u);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

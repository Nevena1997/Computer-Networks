package prviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {

		while (true) {
			try {
				ServerSocket server = new ServerSocket(12345);
				Socket soc = server.accept();

				BufferedReader in = new BufferedReader(new InputStreamReader(soc.getInputStream()));
				StringBuffer pom = new StringBuffer();

				int c;
				while ((c = in.read()) != -1) {
					pom.append((char) c);
				}

				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(soc.getOutputStream()));
				out.write(pom.toString());

				in.close();
				out.close();
				server.close();
				soc.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}

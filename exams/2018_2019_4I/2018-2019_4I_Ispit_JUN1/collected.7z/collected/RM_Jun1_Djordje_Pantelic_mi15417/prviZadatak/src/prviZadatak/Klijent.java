package prviZadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Klijent {

	public static void main(String[] args) {
		try {
			Socket soc = new Socket("localhost", 12345);
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(soc.getOutputStream()));
			Scanner sc = new Scanner(System.in);
			while (sc.hasNextLine()) {
				out.write(sc.nextLine());
			}


			BufferedReader in = new BufferedReader(new InputStreamReader(soc.getInputStream()));

			String l;
			while((l = in.readLine()) != null)
				System.out.println(l);

			sc.close();
			out.close();
			in.close();
			soc.close();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

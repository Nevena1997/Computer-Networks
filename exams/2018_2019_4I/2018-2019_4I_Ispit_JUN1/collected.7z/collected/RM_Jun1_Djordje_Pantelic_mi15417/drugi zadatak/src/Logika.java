import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;

public class Logika {

	private JTextArea textEdit;
	private JEditorPane jep;
	private JTextArea address;


	public Logika(JTextArea textEdit, JEditorPane jep, JTextArea address) {
		this.textEdit = textEdit;
		this.jep = jep;
		this.address = address;
	}




	public void osvezi() {

		String sadrzaj = this.textEdit.getText();
		this.jep.setText(sadrzaj);
	}

	public void prikazi() {
		String urlString = this.address.getText();
		try {
			URL u = new URL(urlString);
			//this.jep.setPage(u);  ne moze ovako jer kombinacija prikazi -> nesto napisemo -> osvezi -> prikazi ne radi kako treba
			//drugi put ne prikaze opet oba kako treba nego na jednom ostane ono osvezeno sto smo rucno menjali u editoru

			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			StringBuffer sadrzajUrla = new StringBuffer();

			int c;
			while((c = in.read()) != -1)
				sadrzajUrla.append((char)c);


			this.textEdit.setText(sadrzajUrla.toString());
			this.jep.setContentType("text/html");
			this.jep.setText(sadrzajUrla.toString());

		} catch (MalformedURLException e) {
			this.jep.setText("<html>Nije moguce prikazati sadrzaj jer je " + urlString + " neispravan</html>");
		} catch (IOException e) {
			this.jep.setText("<html>Iz nekog razloga nije moguce prikazati " + urlString + " </html>");
		}


	}




	public void sacuvaj() {
		String urlString = this.address.getText();
		String sadrzaj = this.textEdit.getText();
		URI uFajla;
		try {
			uFajla = new URI(urlString);
			File f = new File(uFajla);
			String path = f.getAbsolutePath();
			f.delete();
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path)));
			out.print(sadrzaj);
			out.close();
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}






}

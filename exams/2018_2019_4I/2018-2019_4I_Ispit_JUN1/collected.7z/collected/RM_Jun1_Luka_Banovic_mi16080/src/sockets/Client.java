package sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

public class Client {

	public static void main(String[] args) {
		int port = 12344;
		BufferedReader userInput = null;  
		BufferedReader in = null;
		PrintWriter out = null;
		try { 
			Socket client = new Socket("localhost", port); 

			userInput = new BufferedReader(new InputStreamReader(System.in));
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(client.getOutputStream());

			while(true){

				String s = userInput.readLine();

				out.write(s);
				out.flush();

				int n = in.read();

				if(n > 0){ 
					System.out.println(in.read()); 
				}
				else if(n == -1){
					break;
				}
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
			if(in != null){
				in.close();
			}
			if(out != null){
				out.close();
			}
			if(userInput != null){
				userInput.close();
			}
			}catch(Exception e){

			}

		}

	}

}

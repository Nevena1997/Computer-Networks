package sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Server {


	public static void main(String[] args) throws IOException {

		String hostname = "localhost";
		int port = 12344;

		try(ServerSocketChannel serverChannel= ServerSocketChannel.open(); Selector selector = Selector.open()){

			if(!serverChannel.isOpen() || !selector.isOpen()){
				System.err.println("Could not opent selector or serverChannel");
				System.exit(1);
			}

			serverChannel.bind(new InetSocketAddress(hostname, port));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			while(true){

				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				java.util.Iterator<SelectionKey> iterator = readyKeys.iterator();

				while(iterator.hasNext()){

					SelectionKey key = iterator.next();
					iterator.remove();

					try{

						if(key.isAcceptable()){
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							client.register(selector, SelectionKey.OP_READ);
						}else if(key.isReadable()){

							SocketChannel client = (SocketChannel) key.channel();

							ByteBuffer buffer = ByteBuffer.allocate(4096);
							client.read(buffer);
							SelectionKey key2 = client.register(selector,SelectionKey.OP_WRITE);
							key2.attach(buffer.duplicate());
							buffer.clear();
						}else if(key.isWritable()){
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer buffer = (ByteBuffer) key.attachment();
							if(buffer.hasRemaining()){
								client.write(buffer);
								buffer.clear();
							}else{
								buffer.rewind();
								buffer.clear();
							}
						}
					}finally{
						key.cancel();
						key.channel().close();
					}
				}
			}



		}

	}

}

package swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Paths;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import javafx.event.ActionEvent;
import javafx.scene.shape.Path;

public class HTMLEditor {

	static String first_page = "/RM_Jun1_Luka_Banovic_mi16080/src/swing/1.html";

	public static void main(String[] args) {

		
		JFrame f = new JFrame();
		f.setResizable(true);
		f.setSize(400, 600);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});

	}

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		JEditorPane jep2 = new JEditorPane();
		JScrollPane scrollPane = new JScrollPane(jep1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipady = 250;
		c.ipadx = 400;
		c.weightx = 0.5;
		c.weighty = 0.5;
		pane.add(scrollPane, c);

		JScrollPane scrollPane1 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipady = 250;
		c.ipadx = 400;
		c.weightx = 0.5;
		c.weighty = 0.5;
		pane.add(scrollPane1, c);

		/*JTextArea txtEdit = new JTextArea("OVDE SE PISE HRML");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 0;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 0.5;
		c.weighty = 0.5;
		pane.add(txtEdit, c);

		JTextArea htmlView = new JTextArea("OVDE SE VIDI HTML");
		htmlView.setEditable(false);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 0;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 0.5;
		c.weighty = 0.5;
		pane.add(htmlView, c);
		*/




		JTextArea urlLink = new JTextArea(first_page);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(urlLink, c);

		ActionHandler ah = new ActionHandler(jep1, jep2, urlLink);
		jep2.addHyperlinkListener(ah);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent arg0) {
				// TODO Auto-generated method stub
				ah.prikazi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx =0;
		c.weighty = 0;
		pane.add(btnPrikazi, c);



		JButton btnOsvezi = new JButton("Osvezi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx =0;
		c.weighty = 0;
		pane.add(btnOsvezi, c);

		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(java.awt.event.ActionEvent arg0) {
				// TODO Auto-generated method stub
				ah.sacuvaj();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx =0;
		c.weighty = 0;
		pane.add(btnSacuvaj, c);

	}
}

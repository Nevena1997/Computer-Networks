package swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.file.FileSystem;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchEvent.Modifier;
import java.util.Iterator;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class ActionHandler implements HyperlinkListener{

	private JEditorPane paneEdit;
	private JEditorPane paneView;
	private JTextArea urlLink;

	public ActionHandler(JEditorPane paneEdit, JEditorPane paneView, JTextArea urlLink){
		this.paneEdit = paneEdit;
		this.paneView = paneView;
		this.urlLink = urlLink;
	}

	public void prikazi(){
		try {
			String path = this.urlLink.getText();
			FileInputStream in = new FileInputStream(path);
			BufferedReader input = new BufferedReader(new InputStreamReader(in));
			String s;
			StringBuilder content = new StringBuilder();
			while((s = input.readLine()) != null){
				content.append(s).append("\n");
			}
			this.paneEdit.setText(content.toString());
			//URL url = new URL();
			this.paneView.setPage(path);

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			this.paneView.setText("<html> Could not load " + this.urlLink.getText() + "</html>");
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			this.paneView.setText("<html> Could not load " + this.urlLink.getText() + "</html>");
		}



	}

	public void osvezi(){
		this.sacuvaj();
		this.prikazi();
	}


	public void sacuvaj(){
		String path = this.urlLink.getText();

		try {
			FileOutputStream out = new FileOutputStream(path);
			PrintWriter pr = new PrintWriter(out);
			String content = this.paneEdit.getText();
			int l = content.length();
			byte[] buffer = new byte[l];
			pr.print(buffer);
			pr.flush();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}





	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent arg0) {
		// TODO Auto-generated method stub

	}



}

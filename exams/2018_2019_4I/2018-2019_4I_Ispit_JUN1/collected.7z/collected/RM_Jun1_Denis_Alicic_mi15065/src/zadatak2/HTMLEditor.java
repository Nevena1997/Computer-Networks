package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import sun.font.CreatedFontTracker;

public class HTMLEditor extends JApplet{
	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setSize(600, 480);
		f.setResizable(true);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				f.show(true);
			}
		});

	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea ta = new JTextArea();
		ta.setEditable(true);
		JScrollPane scrollPane = new JScrollPane(ta);
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 480;
		c.ipady = 150;
		pane.add(scrollPane, c);

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane1 = new JScrollPane(jep);
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 480;
		c.ipady = 150;
		pane.add(scrollPane1, c);

		JTextField tf = new JTextField();
		c.gridx = 0;
		c.gridy = 3;
		c.ipadx = 200;
		c.ipady = 0;
		c.gridwidth = 1;
		tf.setEditable(true);
		pane.add(tf,c);

		JButton btPrikaz = new JButton("Prikazi");
		c.gridx = 2;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btPrikaz,c);
		btPrikaz.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					URL url = null;
					try {
						url = new URL(tf.getText());
						jep.setPage(url);
					} catch (MalformedURLException e1) {
						jep.setText("<html> Nije validan URL: " + url + "</html>" );
					} catch (IOException e1) {
						jep.setText("<html> Nije validan URL: " + url + "</html>" );

					}

			}
		});

		JButton btOsvezi = new JButton("Osvezi");
		c.gridx = 3;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btOsvezi,c);
		btOsvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String html = ta.getText();
				jep.setText(html);
			}
		});

		JButton btSacuvaj = new JButton("Sacuvaj");
		c.gridx = 4;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btSacuvaj,c);
		btSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String path = tf.getText();
				path = path.substring(path.indexOf("FILE://")+6);
				try {
					BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path)));
					writer.write(ta.getText());
					writer.flush();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


			}
		});


	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}

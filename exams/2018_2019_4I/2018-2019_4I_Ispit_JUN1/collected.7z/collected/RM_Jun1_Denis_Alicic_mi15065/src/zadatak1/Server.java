package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
	private static int id = 0;
	private static final int DEFAULT_PORT = 12345;
	public static void main(String[] args) {
		int i = 0;
		try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){
			List<Socket> clients = new ArrayList<>();
			while(true){
				System.out.println(i++);
				for(Socket cl: clients){
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(cl.getOutputStream()));
					out.write(id++);
					out.flush();
					out.close();
				}
				Socket client = server.accept();
				Thread t = new Thread(new Runnable() {

					@Override
					public void run() {
						while(true){
							try {
								BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
								String msg = in.readLine();
								for(Socket cl: clients){
									BufferedWriter out = new BufferedWriter(new OutputStreamWriter(cl.getOutputStream()));
									out.write(msg);
									out.flush();
									out.close();
								}
							} catch (IOException e) {
								// TODO Auto-generated catch block
							}
						}

					}
				});
				t.start();
				clients.add(client);
			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}

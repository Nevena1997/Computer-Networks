import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.WindowConstants;

public class Editor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame f=new JFrame("HTML editor");
		f.setSize(500, 720);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);
		AddElements(f.getContentPane());
		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run() {
				f.setVisible(true);

			}

		});

	}

	private static void AddElements(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();
		JEditorPane jep=new JEditorPane();
		jep.setEditable(true);
		JScrollPane scrollPane=new JScrollPane(jep);
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridwidth=4;
		c.ipady=300;
		c.ipadx=0;
		c.weightx=1.0;
		c.weighty=0;
		contentPane.add(scrollPane, c);

		JEditorPane jep2=new JEditorPane();
		jep2.setEditable(false);
		JScrollPane scrollPane2=new JScrollPane(jep2);
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridwidth=4;
		c.ipady=300;
		c.ipadx=0;
		c.weightx=1.0;
		c.weighty=0;
		contentPane.add(scrollPane2, c);

		JTextPane adresa=new JTextPane();
		adresa.setText("");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		c.gridwidth=1;
		c.ipady=0;
		c.ipadx=0;
		c.weightx=1.0;
		c.weighty=0;
		contentPane.add(adresa, c);

		JButton prikazi=new JButton("Prikazi");

		prikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String putanja = Paths.get(adresa.getText()).toAbsolutePath().toString();
					URL url=new URL("FILE:///"+putanja);
					InputStream in=url.openStream();
					Scanner sc=new Scanner(in);
					StringBuilder sb=new StringBuilder();
					while(sc.hasNext()){
						sb.append(sc.nextLine());
						sb.append("\n");
					}
					jep.setText(sb.toString());

				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					System.err.println("Uneta adresa nije validna!");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}


		});



		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=2;
		c.gridwidth=1;
		c.ipady=0;
		c.ipadx=0;
		c.weightx=0.0;
		c.weighty=0;
		contentPane.add(prikazi, c);

		JButton osvezi=new JButton("Osvezi");

		osvezi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				jep2.setContentType("text/html");
				jep2.setText(jep.getText());
				
			}

		});

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=2;
		c.gridwidth=1;
		c.ipady=0;
		c.ipadx=0;
		c.weightx=0.0;
		c.weighty=0;
		contentPane.add(osvezi, c);

		JButton sacuvaj=new JButton("Sacuvaj");

		sacuvaj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				String sadrzaj=jep.getText();
				System.out.println(sadrzaj);
				String putanja = Paths.get(adresa.getText()).toAbsolutePath().toString();
				try {
					PrintWriter pw=new PrintWriter(putanja);
					pw.print(sadrzaj);
					pw.flush();

				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}

		});
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=3;
		c.gridy=2;
		c.gridwidth=1;
		c.ipady=0;
		c.ipadx=0;
		c.weightx=0.0;
		c.weighty=0;
		contentPane.add(sacuvaj, c);

	}

}

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public static int PORT=12345;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=null;
		BufferedReader citac=null;
		BufferedWriter pisac=null;
		try {
			Socket soket=new Socket("localhost", PORT);
			citac=new BufferedReader(new InputStreamReader(soket.getInputStream()));
			pisac=new BufferedWriter(new OutputStreamWriter(soket.getOutputStream()));
			sc=new Scanner(System.in);
			while(true){
				String poruka=sc.nextLine();
				String odgovor=citac.readLine();
				System.out.println(odgovor);				
				pisac.write(poruka);
				pisac.flush();

			}


		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			sc.close();
			if(pisac!=null){
				try {
					pisac.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(citac!=null){
				try {
					citac.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


	}

	}
}

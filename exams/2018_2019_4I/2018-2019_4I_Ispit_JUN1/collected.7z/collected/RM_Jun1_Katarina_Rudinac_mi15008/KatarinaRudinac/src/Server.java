import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static int PORT=12345;
	public static int rbr=0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader citac=null;
		BufferedWriter pisac = null;
		Socket klijenti[] = null;
		BufferedReader citaci[] = null;
		BufferedWriter pisaci[] = null;
		try {
			ServerSocket server=new ServerSocket(PORT);
			while(true){
				Socket klijent=server.accept();
				//klijenti[rbr]=server.accept();
				citac=new BufferedReader(new InputStreamReader(klijent.getInputStream()));
				//citaci[rbr]=new BufferedReader(new InputStreamReader(klijenti[rbr].getInputStream()));
				pisac=new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
				//pisaci[rbr]=pisac;
				String idKlijenta=rbr+"";
				//pisaci[rbr].write(idKlijenta);
				//pisaci[rbr].flush();
				String poruka=citac.readLine();
				System.out.println("server"+poruka);

				rbr++;
				for(int i=0; i<rbr; i++){
					pisac.write(poruka);
					pisac.flush();
				}

			}



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(pisac!=null){
				try {
					pisac.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(citac!=null){
				try {
					citac.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


	}

}

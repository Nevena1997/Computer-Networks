package zadatak1_Sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ClientThread implements Runnable {
	private Socket clientSock;
	int id;
	BufferedReader fromClient;
	BufferedWriter out;

	public ClientThread(Socket client, int id) {
		this.clientSock = client;
		this.id = id;
		try{
			this.fromClient = new BufferedReader(new InputStreamReader(clientSock.getInputStream()));
			this.out = new BufferedWriter(new OutputStreamWriter(clientSock.getOutputStream()));
		} catch (IOException e) {
			//TODO obradi!
		}
	}

	@Override
	public void run() {
		try {
			out.write("Konektovani ste!");
			out.newLine();
			out.flush();
			System.out.println("Nit " + id + " zapoceta");

			String ucitano = new String();
			while(true){
				while((ucitano = fromClient.readLine()) != null){
					Server.writeAll(ucitano);
					Thread.sleep(500); //spavaj pola sekunde
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void write(String msg){
		try {
			out.write(msg);
			out.newLine();
			out.flush();
		} catch (IOException e) {
			// TODO: OBRADI!
		}
	}

}

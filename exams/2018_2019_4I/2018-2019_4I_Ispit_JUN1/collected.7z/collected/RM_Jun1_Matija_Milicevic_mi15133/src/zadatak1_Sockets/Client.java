package zadatak1_Sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		BufferedReader in = null;
		BufferedWriter toServer = null;
		Scanner sc = null;

		try {
			Socket clientSock = new Socket("localhost", Server.PORT);
			//System.err.println("Konektovan na server!");

			in = new BufferedReader(new InputStreamReader(clientSock.getInputStream()));
			toServer = new BufferedWriter (new OutputStreamWriter(clientSock.getOutputStream()));
			sc = new Scanner(System.in);

			String fromServer = new String();

			while(true){
				if((fromServer = in.readLine()) != null){
					System.out.println(fromServer);
					System.out.flush();
				}
				String line = sc.nextLine();
				toServer.write(line);
				toServer.newLine();
				toServer.flush();
			}
		} catch (IOException e) {
			System.err.println("IO izuzetak! Prekid klijenta.");
			//clientExit();
		}

	}

}

package zadatak1_Sockets;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

public class Server {
	final static int PORT = 12345;
	static ArrayBlockingQueue<ClientThread> listaNiti;

	public static void main(String[] args) {

		BufferedWriter out = null;

		ServerSocket serverSock;
		try {
			serverSock = new ServerSocket(PORT);
			System.err.println("Pokrenut server!");
			listaNiti = new ArrayBlockingQueue<ClientThread>(20);

			int i = 1;
			while(true){
				Socket clientSock = serverSock.accept();
				ClientThread t = new ClientThread(clientSock, i);
				listaNiti.add(t);
				new Thread(t).start();
				i++;

			}

		} catch (SocketException e) {
			// TODO Auto-generated catch block
			System.err.println("Konekcija gotova, nit (TODO)");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.err.println("Linija 42, IO Exception!");
		}

	}

	public static synchronized void writeAll(String msg){
		for(ClientThread x : listaNiti){
			x.write(msg);
		}
	}

}

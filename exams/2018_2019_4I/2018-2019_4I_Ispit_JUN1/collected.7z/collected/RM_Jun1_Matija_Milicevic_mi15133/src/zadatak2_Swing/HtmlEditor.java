package zadatak2_Swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.EditorKit;
public class HtmlEditor {

	static String trenutniFajl = null;

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");

		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600,800);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});
	}

	public static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		//GORNJI JEP

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		//jep.setContentType("text/html");
		jep.setContentType("text");
		JScrollPane scroll = new JScrollPane(jep);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(scroll, c);

		//DONJI JEP
		//

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		EditorKit kit = jep2.getEditorKit();
		JScrollPane scroll2 = new JScrollPane(jep2);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(scroll2, c);

		//SKROZ DOLE
		//---------------------------

		//JTextArea text = new JTextArea("");//?
		JTextField textField = new JTextField("file:///C:/Users/nalog/Desktop/HTML/1.html");//  file:///C:/Users/nalog/Desktop/HTML/1.html

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(textField, c);

		JButton dugmePrikazi = new JButton("Prikazi");
		dugmePrikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				prikazi(jep, jep2, textField);
			}
		});

		c.fill = GridBagConstraints.NONE;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(dugmePrikazi, c);

		JButton dugmeOsvezi = new JButton("Osvezi");
		dugmeOsvezi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				osvezi(jep, jep2);
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(dugmeOsvezi, c);

		JButton dugmeSacuvaj = new JButton("Sacuvaj");
		dugmeSacuvaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				sacuvaj(jep);
			}
		});

		c.fill = GridBagConstraints.NONE;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(dugmeSacuvaj, c);

	}

	public static void prikazi(JEditorPane jep, JEditorPane jep2, JTextField text){
		//System.err.println("Prikazi");
		try {
			trenutniFajl = new String(text.getText().trim());
			URL u = new URL(trenutniFajl);
			jep2.setPage(u);
			InputStream in = u.openStream();

			int b;
			StringBuffer sbuf = new StringBuffer();
			while((b = in.read()) != -1){
				sbuf.append((char)b);
			}
			jep.setText(sbuf.toString());
			osvezi(jep, jep2);//TODO
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void osvezi(JEditorPane jep, JEditorPane jep2){
		String text = jep.getText();
		jep2.setContentType("text/html");
		jep2.setText(text);
	}

	public static void sacuvaj(JEditorPane jep){
		if(trenutniFajl == null){
			System.err.println("Nema putanje za sacuvaj");
			return;
		}
		System.err.println("Putanja za prepisivanje je " + trenutniFajl);
		String text = jep.getText();
		//System.err.println(text);
		//TODO
		//Path putanja = new

	}

}

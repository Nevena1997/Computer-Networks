package zadatak2;

import javax.swing.JFrame;

public class FrameShower implements Runnable {

	private JFrame frame;

	public FrameShower(JFrame frame) {
		this.frame = frame;
	}

	@Override
	public void run() {
		this.frame.setVisible(true);
	}

}

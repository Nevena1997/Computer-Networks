package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static void main(String[] args) {

		JFrame frame = new JFrame("HMTL Editor");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(800, 600);
		frame.setResizable(true);

		addComponents(frame.getContentPane());
		EventQueue.invokeLater(new FrameShower(frame));
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jepTop = new JEditorPane();
		jepTop.setEditable(true);

		JEditorPane jepBottom = new JEditorPane();
		jepBottom.setEditable(false);

		JScrollPane scrollTop = new JScrollPane(jepTop);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 250;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scrollTop, c);

		JScrollPane scrollBottom = new JScrollPane(jepBottom);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 250;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scrollBottom, c);

		JTextArea addressTa = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(addressTa, c);

		ListenerDugmica lh = new ListenerDugmica(jepTop, jepBottom, addressTa);
		jepTop.addHyperlinkListener(lh);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(e -> lh.prikazi());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnPrikazi, c);

		JButton btnOsvezi = new JButton("Osvezi");
		btnOsvezi.addActionListener(e -> lh.osvezi());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnOsvezi, c);

		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(e -> lh.sacuvaj());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnSacuvaj, c);

	}

}

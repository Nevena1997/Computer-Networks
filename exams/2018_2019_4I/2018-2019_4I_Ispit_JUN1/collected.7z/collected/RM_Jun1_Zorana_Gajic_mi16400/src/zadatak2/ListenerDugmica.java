package zadatak2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class ListenerDugmica implements HyperlinkListener {

	private JEditorPane jepTop = new JEditorPane();
	private JEditorPane jepBottom = new JEditorPane();
	private JTextArea addressTa = new JTextArea();

	public ListenerDugmica(JEditorPane jepTop, JEditorPane jepBottom, JTextArea addressTa) {
		this.jepTop = jepTop;
		this.jepBottom = jepBottom;
		this.addressTa = addressTa;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
	}

	public void prikazi() {
		String urlString = this.addressTa.getText().trim();

		// Ako ekstenzija url-a nije html
		if(!(urlString.substring(urlString.lastIndexOf('.') + 1).trim().equalsIgnoreCase("html"))) {
			this.jepBottom.setContentType("text/html");
			this.jepBottom.setText("<html> <h3> File is not with html extension </h3></html>");
		}
		else {
			try {
				URL u = new URL(urlString);
				this.jepTop.setText(procitajSadrzaj(urlString));
				this.jepBottom.setPage(u);
			} catch (MalformedURLException e) {
				this.jepBottom.setContentType("text/html");
				this.jepBottom.setText("<html> <h3> Can't open file " + urlString + " </h3></html>");
			} catch (IOException e) {
				e.printStackTrace();
			} // van try
		} // van else
	}

	public void osvezi() {
		String textIznad = this.jepTop.getText();
		this.jepBottom.setText(textIznad);
	}

	public void sacuvaj() {
		String textIznad = this.jepTop.getText();

		String filename = this.addressTa.getText().trim();
		String putanja = filename.substring(filename.lastIndexOf('\\')+1);

		File file = new File(putanja);
		FileOutputStream outToFile = null;
		try {
			outToFile = new FileOutputStream(file);
			outToFile.write(textIznad.getBytes());
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		} finally {
			if(outToFile != null)
				try {
					outToFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

	public String procitajSadrzaj(String filename) {
		StringBuilder sb = new StringBuilder();
		Scanner sc = null;

		try {
			String putanja = filename.substring(filename.lastIndexOf('\\')+1);
			sc = new Scanner(new File(putanja));

			while(sc.hasNextLine()) {
				sb.append(sc.nextLine().trim());
				sb.append("\n");
			}
		} catch (FileNotFoundException e) {
			// obradjeno u prikazi...
		} finally {
			if(sc != null)
				sc.close();
		}

		return sb.toString();
	}

	// FILE:///C:\Users\nalog\Desktop\RM_Jun1_Zorana_Gajic_mi16400\1.html
}

package zadatak1_threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Server {

	public static final int PORT = 12345;
	public static BufferedWriter out = null;
	public static String msg;

	public static Map<Integer, Socket> klijenti = new HashMap<Integer, Socket>();

	public static void main(String[] args) {
		Random r = new Random();

		try(ServerSocket server = new ServerSocket(PORT)) {
			while(true) {
				Socket client = server.accept();

				// Dodajemo novog klijenta
				int id = r.nextInt(10000);
				klijenti.put(id, client);

				// Obavestavamo sve klijente da imamo novog clana
				klijenti.forEach((i, klijent) -> {
					try {
						out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
						out.write("Imamo novog clana sa id: " + id);
						out.newLine();
						out.flush();
					} catch (IOException e) {
					};
				});

				Thread thread = new Thread(new Runnable() {
					@Override
					public void run() {
						BufferedReader inFromClient = null;

						try {
							while(true) {
								inFromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));

								// Citanje poruke pristigle od klijenta
								msg = inFromClient.readLine().trim();
								System.out.println("Received from client: " + msg);

								// Ako je klijent poslao stop obavesticemo sve, izbrisacemo ga iz mape i ugasicemo ga
								if(msg.equalsIgnoreCase("stop")) {
									msg = "Klijent <" + id + "> je napustio chat.";
									klijenti.remove(id);
									client.close();
								}

								// Slanje poruke nazad svim klijentima (ili poruku tog klijenta serveru ili poruku da je napustio chat)
								klijenti.forEach((i, klijent) -> {
									try {
										out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
										out.write(msg);
										out.newLine();
										out.flush();
									} catch (IOException e) {
										e.printStackTrace();
									};
								});

							} // van while
						} catch (IOException e) {
						}  finally {
							try {
								if(inFromClient != null)
									inFromClient.close();
							} catch (IOException e) {
							}
						} // van try

					} // van run
				}); // van thread inicijalizacije

				thread.start();

			} // van while(true) koji prihvata klijente
		} catch (IOException e) {
		} finally {
			if(out != null)
				try {
					out.close();
				} catch (IOException e) {
				}

			// Zatvaraju se svi klijenti iz mape
			klijenti.forEach((i, klijent) -> {
				try {
					klijent.close();
				} catch (IOException e) {
				};
			});

		}
	}
}

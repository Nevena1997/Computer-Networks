package zadatak1_threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		Scanner sc = null;
		BufferedReader inFromServer = null;
		BufferedWriter outToServer = null;

		try(Socket sock = new Socket("localhost", Server.PORT)) {
			sc = new Scanner(System.in);
			inFromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			outToServer = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));;

			// Nije receno u zadatku kako resiti sledece: klijent ceka da posalje novu poruku i ne moze da primi potencijalnu
			// poruku od servera ukoliko ima neki drugi klijent koji salje.
			while(true) {
				System.out.println("Received from server: " + inFromServer.readLine());

				System.out.println("Type in message for server: ");
				String line = sc.nextLine().trim();
				System.out.println("Sending to server: " + line);

				outToServer.write(line);
				outToServer.newLine();
				outToServer.flush();

				if(line.equalsIgnoreCase("stop"))
					break;
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(sc != null)
					sc.close();

				if(inFromServer != null)
						inFromServer.close();

				if(outToServer != null)
					outToServer.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

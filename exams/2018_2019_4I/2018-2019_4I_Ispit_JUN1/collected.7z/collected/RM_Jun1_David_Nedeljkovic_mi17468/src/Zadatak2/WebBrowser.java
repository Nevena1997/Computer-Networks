package Zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class WebBrowser {

	public static void main(String[] args) {

		JFrame jframe = new JFrame("HTML Editor");
		jframe.setSize(600, 530);
		jframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(jframe.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				jframe.setVisible(true);
			}
		});

	}

	private static void addComponents(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jpane = new JEditorPane();
		jpane.setEditable(false);


		JScrollPane jscrol1 = new JScrollPane(jpane);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 215;
		c.weightx = 1.0;
		c.weighty = 0.0;
		contentPane.add(jscrol1, c);

		JScrollPane jscrol2 = new JScrollPane();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 215;
		c.weightx = 1.0;
		c.weighty = 0.0;
		contentPane.add(jscrol2, c);


		JTextArea jtext = new JTextArea();
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		contentPane.add(jtext, c);

		JButton btn1 = new JButton("Prikazi");
		btn1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
					String adresa = jtext.getText();
					try {
						URL u = new URL(adresa);
						try {
							jpane.setPage(u);
						} catch (IOException e) {
							jpane.setText("Nije validna adresa.");
						}

					} catch (MalformedURLException e) {
						System.out.println(e);
					}

			}
		});

		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btn1, c);

		JButton btn2 = new JButton("Osvezi");
		btn2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				ParserGeter ps = new ParserGeter();
				ParserCallBackImpl pc = new ParserCallBackImpl();

			}
		});
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btn2, c);

		JButton btn3 = new JButton("Sacuvaj");
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(btn3, c);


	}

}

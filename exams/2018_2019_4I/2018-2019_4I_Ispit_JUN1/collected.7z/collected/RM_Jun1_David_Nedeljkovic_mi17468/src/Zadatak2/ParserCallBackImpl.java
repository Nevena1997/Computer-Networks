package Zadatak2;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Tag;

public class ParserCallBackImpl extends HTMLEditorKit.ParserCallback{

	public boolean tmp = true;


	@SuppressWarnings("static-access")
	@Override
	public void handleStartTag(Tag t, MutableAttributeSet arg1, int arg2) {
		if(HTML.Tag.H1 == t.H1)
			tmp = true;
		else if (HTML.Tag.H2 == t.H2) {
			tmp = true;
		}else if (HTML.Tag.H3 == t.H3) {
			tmp = true;
		}else if (HTML.Tag.H4 == t.H4) {
			tmp = true;
		}else if (HTML.Tag.H5 == t.H5) {
			tmp = true;
		} else if (HTML.Tag.H6 == t.H6) {
			tmp = true;
		}
		super.handleStartTag(t, arg1, arg2);
	}

	@SuppressWarnings("static-access")
	@Override
	public void handleEndTag(Tag t, int arg1) {
		if(t.H1 == HTML.Tag.H1 || t.H2 == HTML.Tag.H2 || t.H3 == HTML.Tag.H3 || t.H4 == HTML.Tag.H4
				|| t.H5 == HTML.Tag.H5 || t.H6 == HTML.Tag.H6)
			tmp = false;
		super.handleEndTag(t, arg1);
	}

	@Override
	public void handleText(char[] data, int arg1) {
		if(true)
			System.out.println(data);
		super.handleText(data, arg1);
	}


}

package Zadatak2;

import javax.swing.text.html.HTMLEditorKit;

@SuppressWarnings("serial")
public class ParserGeter extends HTMLEditorKit{
	@Override
	protected Parser getParser() {
		// TODO Auto-generated method stub
		return super.getParser();
	}

}

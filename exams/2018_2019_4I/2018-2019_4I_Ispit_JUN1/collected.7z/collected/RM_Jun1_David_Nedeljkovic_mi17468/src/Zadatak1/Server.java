package Zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	private static final int PORT = 12345;

	public static void main(String[] args) throws IOException {

		BufferedReader  br = null;
		PrintWriter bw = null;

		try {
			ServerSocket server = new ServerSocket(PORT);

			while (true) {
				Socket s = server.accept();

				br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
				bw = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));

				String str;
				while((str = br.readLine()) != null) {
					bw.println(str);
					bw.flush();
				}
			}
		} catch (IOException e) {
			System.out.println(e);
			br.close();
			bw.close();
		}

	}

}

package Zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Klijent {

	private static final int PORT = 12345;

	public static void main(String[] args) throws IOException {

		String str = "localhost";
		BufferedReader br = null;
		PrintWriter bw = null;

		try {
			Socket klijent = new Socket(str, PORT);

			br = new BufferedReader(new InputStreamReader(klijent.getInputStream(), "UTF-8"));
			bw = new PrintWriter(new OutputStreamWriter(klijent.getOutputStream(), "UTF-8"));

			BufferedReader bin = new BufferedReader(new InputStreamReader(System.in));

			while(true) {
				// salje se serveru
				String s = bin.readLine();
				bw.println(s);;
				bw.flush();

				// cita sta mu je vraceno
				System.out.println(br.readLine());
			}
		} catch (UnknownHostException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
			br.close();
			bw.close();
		}

	}

}

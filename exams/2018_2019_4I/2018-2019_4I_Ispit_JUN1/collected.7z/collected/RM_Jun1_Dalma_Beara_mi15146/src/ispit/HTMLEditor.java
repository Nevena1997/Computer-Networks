package ispit;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.ChangedCharSetException;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class HTMLEditor {

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setSize(500, 700);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		JScrollPane jscroll1 = new JScrollPane(jep1);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.weightx = 0.0;
		c.weighty = 1.0;
		contentPane.add(jscroll1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		JScrollPane jscroll2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.weightx = 0.0;
		c.weighty = 1.0;
		contentPane.add(jscroll2, c);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 3;
		c.weightx = 0.5;
		c.weighty = 0.0;
		contentPane.add(addressBar, c);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					URL url = new URL("file", "localhost", addressBar.getText());
					try {
						jep2.setPage(url);
					}
					catch(IOException ex) {
						ex.printStackTrace();
					}
				}
				catch(MalformedURLException ex) {
					jep1.setText("Malformed URL");
				}
			}
		});
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 4;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(prikazi, c);

		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ParserGetter pg = new ParserGetter();
				HTMLEditorKit.Parser p = pg.getParser();
				String encoding = "UTF-8";

				try {
					URL url = new URL("file", "localhost", addressBar.getText());
					HTMLEditorKit.ParserCallback doNothing = new ParserCallback();
					InputStreamReader in = new InputStreamReader(url.openStream(), encoding);
					p.parse(in, doNothing, false);
				}
				catch(MalformedURLException ex) {
					jep1.setText("Malformed URL.");
				}
				catch(ChangedCharSetException ex) {
					String mimeType = ex.getCharSetSpec();
					encoding = mimeType.substring(mimeType.indexOf("=") + 1).trim();
				}
				catch(IOException ex) {
					ex.printStackTrace();
				}

				try {
					URL url = new URL("file", "localhost", addressBar.getText());
					StringBuilder sb = new StringBuilder();
					ParserCallbackImpl pc = new ParserCallbackImpl(sb);
					InputStreamReader in = new InputStreamReader(url.openStream(), encoding);
					p.parse(in, pc, false);
					jep1.setText(sb.toString());
				}
				catch(IOException ex) {
					ex.printStackTrace();
				}

			}
		});
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 4;
		c.gridwidth = 4;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(osvezi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					FileInputStream fis = new FileInputStream(addressBar.getText());
					StringBuilder sb = new StringBuilder();
					FileOutputStream fos = new FileOutputStream(addressBar.getText());

				}
				catch(FileNotFoundException ex) {
					ex.printStackTrace();
				}
			}
		});
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 5;
		c.gridwidth = 4;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(sacuvaj, c);
	}

}

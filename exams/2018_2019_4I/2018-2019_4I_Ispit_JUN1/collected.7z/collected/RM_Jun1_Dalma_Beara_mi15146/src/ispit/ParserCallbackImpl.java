package ispit;

import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback {
	private StringBuilder out;

	public ParserCallbackImpl(StringBuilder out) {
		this.out = out;
	}

	public void handleText(char[] text, int position) {
		out.append(text);
	}

}

package ispit;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Server {

	public static void main(String[] args) {
		int port = 1919;
		int numClients = 0;

		try (ServerSocketChannel serverSock = ServerSocketChannel.open()) {
			serverSock.bind(new InetSocketAddress(port));
			Selector selector = Selector.open();
			serverSock.register(selector, SelectionKey.OP_ACCEPT);
			while (true) {
				Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
				while (iterator.hasNext()) {
					SelectionKey key = iterator.next();
					iterator.remove();

					if(key.isAcceptable()) {
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client = serverSock.accept();
						numClients++;
						key.interestOps(SelectionKey.OP_READ);
					}
					else if(key.isReadable()) {
						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer buf = ByteBuffer.allocate(5000);
						client.read(buf);
						key.attach(client);
						key.interestOps(SelectionKey.OP_WRITE);
					}
					else if(key.isWritable()) {
						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer bb = (ByteBuffer) key.attachment();
						while (bb.hasRemaining()) {
							client.write(bb);
						}
					}
				}
			}
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}

	}

}

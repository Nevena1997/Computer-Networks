package ispit;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		int port = 1919;
		String host = "localhost";

		Scanner sc = null;
		BufferedReader in = null;
		BufferedWriter out = null;

		try(Socket sock = new Socket(host, port)) {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			sc = new Scanner(System.in);

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				out.write(line);
				out.newLine();
				out.flush();
			}

			int c;
			while ((c = in.read()) != -1) {
				System.out.println((char) c);
			}
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}

	}

}

package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.event.HyperlinkEvent;

import javafx.scene.layout.Pane;

public class WebBrowser {
	private static String HOME_PAGE=null;
			//"file:///C:/Users/nalog/Desktop/RM_Jun1_Ivan_Ristovic_mi18486/src/zadatak2/1.html";
			//"file:///C:/Users/nalog/Desktop/RM_Jun1_Ivan_Ristovic_mi18486/src/zadatak2/2.html";
	public static void main (String[] args){
		JFrame frame = new JFrame();

		frame.setTitle("HTML Editor");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(800, 600);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints grid = new GridBagConstraints();


		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		jep.setAutoscrolls(false);
		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=0;
		grid.gridy=0;
		grid.gridwidth=4;
		grid.weightx=1.0;
		grid.weighty=1.0;
		grid.ipadx=0;
		grid.ipady=200;
		pane.add(jep, grid);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		jep2.setAutoscrolls(false);

		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=0;
		grid.gridy=2;
		grid.gridwidth=4;
		grid.weightx=1.0;
		grid.weighty=1.0;
		grid.ipadx=0;
		grid.ipady=200;

		pane.add(jep2, grid);



		JTextArea textArea= new JTextArea("FILE:///home/1.html");
		grid.fill= GridBagConstraints.HORIZONTAL;
		grid.gridx=0;
		grid.gridy=3;
		grid.gridwidth=1;
		grid.ipadx=0;
		grid.ipady=0;
		pane.add(textArea, grid);

		LinkHandler lh = new LinkHandler(jep, jep2, textArea);


		JScrollBar scroll = new JScrollBar();
		scroll.setAutoscrolls(true);
		grid.fill= GridBagConstraints.VERTICAL;
		grid.gridx=5;
		grid.gridy=0;
		grid.gridheight=1;
		grid.weightx=0;
		grid.weighty=0;
		grid.ipadx=0;
		grid.ipady=0;
		pane.add(scroll, grid);



		JScrollBar scroll2 = new JScrollBar();
		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=0;
		grid.gridy=1;
		grid.gridwidth=5;
		grid.weightx=0;
		grid.weighty=0;
		grid.ipadx=0;
		grid.ipady=0;
		pane.add(scroll2, grid);

		JScrollBar scroll3 = new JScrollBar();
		grid.fill= GridBagConstraints.VERTICAL;
		grid.gridx=5;
		grid.gridy=2;
		grid.gridheight=1;
		grid.weightx=0;
		grid.weighty=0;
		grid.ipadx=0;
		grid.ipady=0;
		pane.add(scroll3, grid);

		JButton btnPrikazi= new JButton("Prikazi");
		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=1;
		grid.gridy=3;
		grid.gridwidth=1;
		grid.ipadx=0;
		grid.ipady=0;
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.prikazi(textArea.getText());

			}
		});
		pane.add(btnPrikazi, grid);
		JButton btnOsvezi= new JButton("Osvezi");
		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=2;
		grid.gridy=3;
		grid.gridwidth=1;
		grid.ipadx=0;
		grid.ipady=0;

		btnOsvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				StringBuffer sb = new StringBuffer();
				sb.append(jep.getText());
				jep2.setText(sb.toString());
			}
		});

		pane.add(btnOsvezi, grid);
		JButton btnSacuvaj= new JButton("Sacuvaj");
		grid.fill=GridBagConstraints.HORIZONTAL;
		grid.gridx=3;
		grid.gridy=3;
		grid.gridwidth=1;
		grid.ipadx=0;
		grid.ipady=0;
		pane.add(btnSacuvaj, grid);


	}
}

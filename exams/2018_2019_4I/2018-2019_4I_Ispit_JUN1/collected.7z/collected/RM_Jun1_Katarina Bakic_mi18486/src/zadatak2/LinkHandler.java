package zadatak2;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane jep;
	private static JEditorPane jep2;
	private JTextArea textArea;
	private List<URL> urlLista;
	int indeks;
	public LinkHandler(JEditorPane jep, JEditorPane jep2, JTextArea textArea) {
		this.jep=jep;
		this.jep2= jep2;
		this.textArea= textArea;
		urlLista= new ArrayList<>();
		indeks=-1;
	}
	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type= e.getEventType();
		URL url = e.getURL();
		if(type==HyperlinkEvent.EventType.ACTIVATED && !url.equals(urlLista.get(indeks))){
			goToPage(url);
		}
	}
	private void goToPage(URL url) {
		try {
			indeks++;
			urlLista.add(indeks, url);
			jep2.setPage(url);
			for(int i=indeks+1;i<urlLista.size()-1;i++)
				urlLista.remove(i);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			jep2.setText("Url nije validan.");
		}

	}

	public static void prikazi(String url) {
		try {
			URL url2 = new URL(url);
			jep2.setPage(url2);


		} catch (IOException e) {
			// TODO Auto-generated catch block
			jep2.setText("URL nije validan.");
		}
	}

}

package zadatak1;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String [] args){
		int port =12345;
		String host ="localhost";
		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;
		try {
			Socket client = new Socket(host, port);

			while(true){
				in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
				sc= new Scanner(System.in);
				while(sc.hasNextLine()){
					String linija = sc.nextLine();

					out.write(linija);
					out.newLine();
					out.flush();
					System.out.println(in.readLine());
				}

			}

		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				if(in!=null){
					in.close();
				}
				if(out!=null)
					out.close();
				if(sc!=null)
					sc.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}





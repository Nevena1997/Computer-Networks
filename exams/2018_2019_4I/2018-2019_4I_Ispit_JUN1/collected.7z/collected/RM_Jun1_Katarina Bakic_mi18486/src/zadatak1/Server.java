package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	public static void main (String[] args){
		int port =12345;
		BufferedReader bin=null;
		BufferedWriter bout=null;
		Scanner sc = null;
			try (ServerSocket server = new ServerSocket(port)){
			//	System.out.println("Server port: "+ port);
				Socket client = server.accept();
				bin = new BufferedReader(new InputStreamReader(client.getInputStream()));
				bout = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

				while(true){
					String s= bin.readLine();

					bout.write(s);
					bout.newLine();
					bout.flush();
				}


			} catch (IOException e) {
				// TODO Auto-generated catch block

			}finally{
					try {
						if(bin!=null){
							bin.close();
						}
						if(bout!=null)
							bout.close();
						if(sc!=null)
							sc.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

	}
}

package zadatak1;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Niti implements Runnable {

	private ArrayList<Socket> listaSoketa;
	private ServerSocket server;

	public Niti(ArrayList<Socket> listaSoketa, ServerSocket server) {
		this.listaSoketa = listaSoketa;
		this.server = server;
	}

	@Override
	public void run() {
		if (server.isBound() && !server.isClosed()) {
			try {
				listaSoketa.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			listaSoketa.notifyAll();
		}
	}

}

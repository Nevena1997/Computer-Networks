package zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {

	private JEditorPane pane1;
	private JEditorPane pane2;
	private String url;

	public LinkHandler(JEditorPane pane1, JEditorPane pane2) {
		this.pane1 = pane1;
		this.pane2 = pane2;
		this.url = "";
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		HyperlinkEvent.EventType type = evt.getEventType();
		URL u = evt.getURL();

		if (type == HyperlinkEvent.EventType.ACTIVATED) {
			try {
				this.goToPage(u);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public void goToPage(URL page) {
		try {
			this.read(page);
			this.pane2.setPage(page);
		} catch (Exception ex) {
			this.pane2.setText("<html> Could not upload " + page + " </html>");
		}
	}

	public void goToPage(String page) {
		try {
			URL u = new URL(page);
			this.goToPage(u);
		} catch (MalformedURLException ex) {
			this.pane2.setText("The URL is not correct!");
		} catch (Exception ex) {
			this.pane2.setText("<html> Could not upload " + page + " </html>");
		}
	}


	public void read(URL url) {

		BufferedReader reader = null;

		try {
			reader = new BufferedReader(new InputStreamReader(url.openStream()));
			StringBuffer buf = new StringBuffer();

			String line;
			while ((line = reader.readLine()) != null) {
				buf.append(line);
				buf.append("\r\n");
			}
			pane1.setText(buf.toString());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (reader != null)
					reader.close();
			} catch (IOException ex) {

			}
		}
	}


}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {

		String hostname = "localhost";
		BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter out = null;
		BufferedReader in = null;

		try (Socket s = new Socket(hostname, 12345)) {
			out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));

			while (true) {
				String line = userIn.readLine();
				if (line.equalsIgnoreCase("exit"))
					break;

				out.write(line);
				out.newLine();
				out.flush();

				String read = in.readLine();
				System.out.println("Server sent: " + read);

			}
		} catch (UnknownHostException ex) {
			System.err.println("Nepoznati host!");
		} catch (IOException ex) {
			System.err.println(ex);
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}

}

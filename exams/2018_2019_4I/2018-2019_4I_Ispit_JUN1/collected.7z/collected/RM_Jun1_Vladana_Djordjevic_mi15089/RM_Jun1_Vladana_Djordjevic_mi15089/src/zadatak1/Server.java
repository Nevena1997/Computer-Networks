package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

	public static void main(String[] args) {

		BufferedReader in = null;
		BufferedWriter out = null;

		ArrayList<Socket> listaSoketa = new ArrayList<Socket>();

		try (ServerSocket server = new ServerSocket(12345)) {

			Socket client = server.accept();

			/*
			listaSoketa.add(client);
			Niti n = new Niti(listaSoketa, server);
			Thread t = new Thread();
			n.run();
			*/

			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			String line;
			while ((line = in.readLine()) != null) {
				out.write(line);
				out.newLine();
				out.flush();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (out != null)
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}

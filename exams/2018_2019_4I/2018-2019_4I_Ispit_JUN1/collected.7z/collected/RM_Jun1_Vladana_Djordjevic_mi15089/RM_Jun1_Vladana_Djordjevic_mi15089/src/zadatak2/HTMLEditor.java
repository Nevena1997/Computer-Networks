package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static void main(String[] args) {

		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(400, 600);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});

	}

	public static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);
		JScrollPane scrollPane1 = new JScrollPane(jep1);

		c.fill = GridBagConstraints.BOTH;

		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 200;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 4;
		pane.add(scrollPane1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		JScrollPane scrollPane2 = new JScrollPane(jep2);

		c.fill = GridBagConstraints.BOTH;

		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 200;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 4;
		pane.add(scrollPane2, c);

		JTextArea textArea = new JTextArea();

		c.fill = GridBagConstraints.BOTH;

		c.gridx = 0;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		pane.add(textArea, c);

		LinkHandler lh = new LinkHandler(jep1,jep2);
		jep2.addHyperlinkListener(lh);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String unos = textArea.getText();
				String dokument = unos.substring(unos.lastIndexOf('/')+1).trim();

				String pocetakURL = "file:///C:/Users/nalog/Desktop/" +
				"RM_Jun1_Vladana_Djordjevic_mi15089/" +
				"RM_Jun1_Vladana_Djordjevic_mi15089/src/zadatak2/";

				String ceoURL = pocetakURL + dokument;

				try {
					URL u = new URL(ceoURL);

					lh.goToPage(u);
				} catch (MalformedURLException ex) {
					jep2.setText("<html> Neispravan URL! </html>");
				} catch (Exception ex) {
					jep2.setText("<html> Neispravan url! </html>");
				}
			}
		});
		c.fill = GridBagConstraints.BOTH;

		c.gridx = 1;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		pane.add(btnPrikazi, c);

		JButton btnOsvezi = new JButton("Osvezi");
		btnOsvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sadrzaj = jep1.getText();

				jep2.setText(sadrzaj);
			}
		});

		c.fill = GridBagConstraints.BOTH;

		c.gridx = 2;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		pane.add(btnOsvezi, c);

		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sadrzaj = jep1.getText();

				String unos = textArea.getText();
				String dokument = unos.substring(unos.lastIndexOf('/')+1).trim();

				String pocetakURL = "file:///C:/Users/nalog/Desktop/" +
						"RM_Jun1_Vladana_Djordjevic_mi15089/" +
						"RM_Jun1_Vladana_Djordjevic_mi15089/src/zadatak2/";

				String ceoURL = pocetakURL + dokument;

				try {
					URL u = new URL(ceoURL);
				} catch (MalformedURLException ex) {
					jep2.setText("<html> Neispravan url! </html>");
				} catch (Exception ex) {
					jep2.setText("<html> Neispravan url! </html>");
				}

				BufferedWriter out = null;
				try {
					out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dokument)));
					out.write(sadrzaj);
					out.newLine();
					out.flush();
				} catch (FileNotFoundException e) {
					System.err.println("NIJE NADJEN FAJL");
				} catch (IOException ex) {
					ex.printStackTrace();
				} finally {
					if (out != null) {
						try {
							out.close();
						} catch (IOException ex) {
							System.err.println(ex);
						}
					}
				}



			}
		});

		c.fill = GridBagConstraints.BOTH;

		c.gridx = 3;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 1;
		pane.add(btnSacuvaj, c);

	}

}

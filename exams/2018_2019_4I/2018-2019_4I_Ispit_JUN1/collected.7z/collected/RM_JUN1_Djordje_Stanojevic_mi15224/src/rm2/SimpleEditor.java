package rm2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import javafx.event.ActionEvent;

public class SimpleEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame f = new JFrame("HTML Editor");
		f.setSize(400,500);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}

		});


	}
	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);
		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		JScrollPane sp1 = new JScrollPane(jep1);

		GridBagConstraints c  = new GridBagConstraints();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.weightx=1;
		c.weighty=1;
		c.ipadx=200;
		c.ipady=200;
		c.gridwidth=4;
		pane.add(sp1,c);

		JScrollPane sp2 = new JScrollPane(jep2);

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.weightx=1;
		c.weighty=1;
		c.ipadx=200;
		c.ipady=200;
		c.gridwidth=4;
		pane.add(sp2,c);

		JTextField adresa = new JTextField();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		c.weightx=0.7;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		pane.add(adresa,c);

		JButton osvezi = new JButton("Osvezi");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=2;
		c.weightx=0.1;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		pane.add(osvezi,c);
		osvezi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				// TODO Auto-generated method stub
				String filename = adresa.getText().trim();
				try {
					URL url = new URL("file","localhost",filename);
					jep2.setPage(url);
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					jep2.setText("Neispravan url");
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					jep2.setText("Neispravan url");
					e1.printStackTrace();
				}
			}
		});








		JButton prikazi = new JButton("Prikazi");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=2;
		c.weightx=0.1;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		pane.add(prikazi,c);
		prikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				// TODO Auto-generated method stub
				String filename = adresa.getText().trim();
				try {
					URL url = new URL("file","localhost",filename);
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					StringBuilder tekst = new StringBuilder();
					String linija;
					while((linija=in.readLine())!=null){
						tekst.append(linija);
						tekst.append("\n");
					}
					jep1.setText(tekst.toString());
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					jep1.setText("Neispravan url");
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					jep1.setText("Neispravan url");
					e1.printStackTrace();
				}
			}
		});
		JButton sacuvaj = new JButton("Sacuvaj");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=3;
		c.gridy=2;
		c.weightx=0.1;
		c.weighty=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		pane.add(sacuvaj,c);
		sacuvaj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				// TODO Auto-generated method stub
				String filename = adresa.getText().trim();
				try {
					String tekst = jep1.getText();
					BufferedWriter fajl = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename)));

					fajl.write(tekst);
					fajl.close();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


			}

		});


	}

}

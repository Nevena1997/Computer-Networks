package ispit;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor{

	public static void main(String[] args){



		JFrame f = new JFrame("HTML editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(400, 600);

		addComponents(f);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}



	public static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane editor = new JEditorPane();
		JScrollPane scrolleditor = new JScrollPane(editor);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 7;
		c.gridheight = 4;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrolleditor,c);



		JEditorPane display = new JEditorPane();
		display.setEditable(false);
		JScrollPane scrollDisplay = new JScrollPane(display);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 4;
		c.gridwidth = 7;
		c.gridheight = 4;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollDisplay,c);

		JTextArea addressBar = new JTextArea("FILE://");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 5;
		c.gridwidth = 4;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(addressBar, c);

		HTMLProcessor processor = new HTMLProcessor(addressBar, editor, display);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(e -> processor.prikaz());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 6;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(prikazi, c);

		JButton osvezi = new JButton("Osvezi");
		prikazi.addActionListener(e -> processor.osvezi());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 7;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(osvezi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		prikazi.addActionListener(e -> processor.sacuvaj());
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 8;
		c.gridy = 2;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(sacuvaj, c);

	}



}



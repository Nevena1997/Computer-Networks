package ispit;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class HTMLProcessor {

	private JTextArea address;
	private JEditorPane editor;
	private JEditorPane display;

	public HTMLProcessor(JTextArea address, JEditorPane editor, JEditorPane display){
		this.address = address;
		this.display = display;
		this.editor = editor;
	}

	public void prikaz(){

		String adr = address.getText();
		adr = adr.substring(adr.indexOf("/")+3);

		try{
			File fin = new File(adr);
			FileInputStream in = new FileInputStream(fin);
			InputStreamReader reader = new InputStreamReader(in);
			String HTMLContent = "";

			int c;
			while((c = reader.read()) != -1){
				HTMLContent += (char) c;
			}

			reader.close();

			editor.setText(HTMLContent);

			display.setText(HTMLContent);


		} catch (FileNotFoundException ex){
			ex.printStackTrace();
		} catch (IOException ex){

		}

	}

	public void osvezi(){

	}

	public void sacuvaj(){

	}

}

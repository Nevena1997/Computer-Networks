package ispit;

import java.io.IOError;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Client {

	public static final int port = 12345;

	public static void main(String[]args){

		try{


			Socket client = new Socket("localhost", port);

			Scanner sc = new Scanner(System.in);

			String userInput = sc.next();

			SocketChannel channel = client.getChannel();

			ByteBuffer request = ByteBuffer.allocate(userInput.length());

			char[] uinputArray = userInput.toCharArray();
			for(int i = 0; i < uinputArray.length; i++){
				request.put((byte) uinputArray[i]);
			}

			request.flip();
			channel.write(request);

			ByteBuffer response = ByteBuffer.allocate(200);
			channel.read(response);

			response.rewind();
			while(response.hasRemaining()){
				System.out.write(response.get());
			}
			System.out.flush();


		} catch(IOException ex){
			ex.printStackTrace();
		}

	}

}

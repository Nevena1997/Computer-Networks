package ispit;

import java.awt.List;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class Server {

	public static int port = 12345;
	public static int ID = 0;
	public static int index = 0;
	public static StringBuffer messages = new StringBuffer();
	public static ArrayList<ProcessClient> threadPool;

	public static void main(String[] args){



		try{
			threadPool = new ArrayList<>();

			ServerSocket server = new ServerSocket();
			InetSocketAddress addres = new InetSocketAddress("localhost", port);
			server.bind(addres);

			Selector selector = Selector.open();
			ServerSocketChannel channel = server.getChannel();
			//channel.configureBlocking(false);

			Socket client = server.accept();
			System.out.println("Accepted " + client);
			ProcessClient t = new ProcessClient(ID++, client);

			threadPool.add(index,t);
			t.run();
			
			



			//channel.register(selector, SelectionKey.OP_ACCEPT);

			/*
			while(true){

				try{
					selector.select();
				} catch(IOException ex){
					ex.printStackTrace();
				}

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while(iterator.hasNext()){
					SelectionKey key = (SelectionKey) iterator.next();
					iterator.remove();

					if(key.isAcceptable()){

					}

				}



			}*/

		} catch(IOException ex){

		}


	}

}

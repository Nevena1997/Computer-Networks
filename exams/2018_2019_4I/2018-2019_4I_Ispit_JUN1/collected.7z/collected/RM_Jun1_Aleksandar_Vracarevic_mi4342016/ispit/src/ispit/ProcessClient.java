package ispit;

import java.net.Socket;

public class ProcessClient implements Runnable {

	private static int ID;
	private Socket client;

	public ProcessClient(int ID, Socket client) {
		this.ID = ID;
		this.client = client;
	}

	@Override
	public void run() {
		System.out.println("Hey from thread ID " + ID + "|" + client);
		
	}

}

package ispit;

import java.io.BufferedReader;
//import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
import java.net.URL;
import java.nio.Buffer;
import java.nio.ByteBuffer;

import javax.swing.JEditorPane;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane jep1;
	private JEditorPane jep2;
	private JTextField address;

	public LinkHandler(JEditorPane jep1, JEditorPane jep2, JTextField address) {
		this.jep1 = jep1;
		this.jep2 = jep2;
		this.address = address;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();
		if(type == HyperlinkEvent.EventType.ACTIVATED){

		}

	}

	public void goToPage(String urlString, File file) {


		//Iz nekog razloga uvek krece od ovoga
		if(!urlString.endsWith(".html")){
			jep2.setContentType("html/txt");
			jep2.setText("<html> Nije dobra putanja </html>");
			jep1.setText("Nije dobra putanja");
		}

		try{
			int s;
			URL url = new URL(urlString);
			jep2.setPage(url);
			FileInputStream fin = new FileInputStream(file);
			StringBuffer buffer = new StringBuffer();
			while((s = fin.read()) != -1){
				buffer.append(s);
			}
			fin.close();

			jep1.setText(buffer.toString());
		//	jep1.setText(file.toString());

		}catch(IOException ex){
			jep2.setContentType("html/txt");
			jep2.setText("<html> Nije dobra putanja </html>");
			ex.printStackTrace();
		}


	}

	public void prikazi() {
		String urlString = address.getText();
		String fileName = urlString.substring(urlString.lastIndexOf("/")).trim();
		File file = new File(fileName);
		goToPage(urlString, file);
	}

	public void osvezi() {
		String text = jep1.getText();
		String tmp = "tmp.html";

		try {
			//sadrzaj tekst prikaza cuva u tmp fajlju
			FileOutputStream d = new FileOutputStream(tmp);
			byte[] txt = text.getBytes();
			d.write(txt);
			d.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//prikazuje sadrzaj tog fajla u html prikazu
		try {
			jep2.setPage(new URL(tmp));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sacuvaj() {
		String text = jep1.getText();
		String urlString = address.getText();
		String fileName = urlString.substring(urlString.lastIndexOf("/")).trim();

		try {
			//sadrzaj tekst prikaza cuva u fajlju
			FileOutputStream d = new FileOutputStream(fileName);
			byte[] txt = text.getBytes();
			d.write(txt);
			d.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package ispit;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;



public class Browser {

	public static void main(String[] args) {

	//	String home_page = "file:///C:/Users/nalog/Desktop/RM_Jun1_Tamara_Ivanovic_mi18462/1.html";

		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(400,500);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});
	}

	private static void addComponents(Container pane) {
		String home_page = "file:///C:/Users/nalog/Desktop/RM_Jun1_Tamara_Ivanovic_mi18462/1.html";
		String fileName = home_page.substring(home_page.lastIndexOf("/")).trim();
		File file = new File(fileName);

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		//********** Text prikaz***********
				JEditorPane jep1 = new JEditorPane();
				jep1.setEditable(true);
				JScrollPane scrollText = new JScrollPane(jep1);
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 0;
				c.gridy = 0;
				c.weightx = 1.0;
				c.weighty = 1.0;
				c.gridwidth = 4;
				c.ipadx = 480;
				c.ipady = 480;
				pane.add(scrollText, c);


		//********** Html prikaz***********
				JEditorPane jep2 = new JEditorPane();
				jep1.setEditable(false);
				JScrollPane scrollHtml = new JScrollPane(jep2);
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 0;
				c.gridy = 1;
				c.weightx = 1.0;
				c.weighty = 1.0;
				c.gridwidth = 4;
				c.ipadx = 480;
				c.ipady = 480;
				pane.add(scrollHtml, c);

		//**************Address bar**********
				JTextField addressBar = new JTextField();
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 0;
				c.gridy = 2;
				c.weightx = 0;
				c.weighty = 0;
				c.gridwidth = 1;
				c.ipadx = 150;
				c.ipady = 0;
				pane.add(addressBar, c);

				LinkHandler lh = new LinkHandler(jep1, jep2, addressBar);
				jep1.addHyperlinkListener(lh);
				lh.goToPage(home_page, file);

		//**************Prikazi**********
				JButton btnPrikazi = new JButton("Prikazi");
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 1;
				c.gridy = 2;
				c.weightx = 0;
				c.weighty = 0;
				c.gridwidth = 1;
				c.ipadx = 0;
				c.ipady = 0;
				pane.add(btnPrikazi, c);


				btnPrikazi.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						lh.prikazi();

					}
				});

		//**************Osvezi**********
				JButton btnOsvezi = new JButton("Osvezi");
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 2;
				c.gridy = 2;
				c.weightx = 0;
				c.weighty = 0;
				c.gridwidth = 1;
				c.ipadx = 0;
				c.ipady = 0;
				pane.add(btnOsvezi, c);

				btnOsvezi.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						lh.osvezi();

					}
				});

		//**************Sacuvaj**********
				JButton btnSacuvaj = new JButton("Sacuvaj");
				c.fill = GridBagConstraints.HORIZONTAL;
				c.gridx = 3;
				c.gridy = 2;
				c.weightx = 0;
				c.weighty = 0;
				c.gridwidth = 1;
				c.ipadx = 0;
				c.ipady = 0;
				pane.add(btnSacuvaj, c);

				btnSacuvaj.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						lh.sacuvaj();

					}
				});


	}

}

package ispit;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Server {

	public static void main(String[] args) {
		String host = "localhost";
		int port = 12345;

		/*
		try(ServerSocket server = new ServerSocket(port)){

			while(true){

				Socket client = server.accept();
				InputStreamReader in = new InputStreamReader(client.getInputStream());
				OutputStreamWriter out = new OutputStreamWriter(client.getOutputStream());
				Thread t = new Thread(new Runnable() {
					public void run() {
						try {


						} catch (IOException e) {

							e.printStackTrace();
						}
					}
				});
				t.start();
				if(client.isClosed()){
					out.write("Klijent " + t.getId() + "je napustio chat.");
				}

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally{
			server.close();
		}
	}*/

	try(ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()){
		serverChannel.bind(new InetSocketAddress(port));
		serverChannel.configureBlocking(false);
		serverChannel.register(selector, SelectionKey.OP_ACCEPT);

		while(true){
			selector.select();
			Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

			if(iterator.hasNext()){
				SelectionKey key = iterator.next();
				iterator.remove();

				while(true){
					if(key.isAcceptable()){
						ServerSocketChannel server = (ServerSocketChannel)key.channel();

						Thread t = new Thread(new Runnable() {

							@Override
							public void run() {
								try {
									SocketChannel client = server.accept();

								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							}
						});
						t.start();
						//Na baffer posalje podatke o id-u klijenta i ostale podatke i promeni op. na citanje
					//	ByteBuffer out = ByteBuffer.allocate(4000);
						//client.attach(out);
					//	out.write(t.getId());
					//	client.register(selector, OP_READ);

					}else if(key.isReadable()){
						//pokupi dosadasnje operacije i cita ih
						SocketChannel client = (SocketChannel)key.channel();
						client.configureBlocking(false);
						ByteBuffer buff = key.attachment();

						//client.setOption(SelectionKey.OP_WRITE);
					}else if(key.isWritable()){
						SocketChannel client = (SocketChannel)key.channel();
					}
				}


			}


		}


	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}

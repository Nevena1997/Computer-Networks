package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ServerPom {

	public static void main(String[] args) {
		List<Socket> listaKlijenata = new ArrayList<Socket>();

		BufferedReader in = null;
		BufferedWriter out = null;
		int id = -1;
		int port = 12345;
		try(ServerSocket server = new ServerSocket(port)){
			System.out.println("Started server on port " + port);

			while(true){

				try(Socket client = server.accept()){
					System.out.println("Client accepted");
					id++;
					listaKlijenata.add(id, client);

					for(int i = 0; i < listaKlijenata.size(); i++){
						out = new BufferedWriter(new OutputStreamWriter(listaKlijenata.get(i).getOutputStream()));

						out.write(id);
						out.flush();
					}

					in = new BufferedReader(new InputStreamReader(client.getInputStream()));


					String message;
					while((message = in.readLine()) != null){

						for(int i = 0; i < listaKlijenata.size(); i++){
							out = new BufferedWriter(new OutputStreamWriter(listaKlijenata.get(i).getOutputStream()));

							out.write(message);
							out.newLine();
							out.flush();

							if(listaKlijenata.get(i).isClosed()){
								listaKlijenata.remove(i);
								out.write("Klijent <" + id + "> je napustio chat.");
								out.newLine();
								out.flush();
							}
						}
					}



				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				if(in!= null)
					in.close();
				if(out != null)
					out.close();
			} catch(IOException e){

			}
		}

	}

}

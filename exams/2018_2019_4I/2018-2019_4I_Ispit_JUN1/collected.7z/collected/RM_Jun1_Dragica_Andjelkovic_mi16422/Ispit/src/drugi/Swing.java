package drugi;



import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Swing {

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});

	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep1 = new JEditorPane();
		jep1.setEditable(true);

		JScrollPane scrollPane1 = new JScrollPane(jep1);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 250;
		pane.add(scrollPane1, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);

		JScrollPane scrollPane2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 250;
		pane.add(scrollPane2, c);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 3;
		pane.add(addressBar, c);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String stringUrl = addressBar.getText();
				URL url = null;
				try {
					url = new URL(stringUrl);
					InputStream sadrzajURL = url.openStream();
					StringBuilder sb = new StringBuilder();

					int c;
					while((c = sadrzajURL.read()) != -1)
						sb.append((char)c);

					//System.out.println(sb);
					jep1.setText(sb.toString());

					try {
						jep2.setPage(url);
					} catch (IOException e) {
						// TODO Auto-generated catch block\
						jep2.setText("Fajl ne posoji");
						jep1.setText("Fajl ne posoji");
						e.printStackTrace();
					}

				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					jep2.setText("URL nije validan");
					jep1.setText("URL nije validan");
					e.printStackTrace();
				} catch (IOException e1) {
					jep2.setText("Fajl ne posoji");
					jep1.setText("Fajl ne posoji");
					e1.printStackTrace();
				}


			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.5;
		pane.add(btnPrikazi, c);

		JButton btnOsvezi = new JButton("Osvezi");
		btnOsvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sadrzaj = jep1.getText();

				jep2.setContentType("text/html");
				jep2.setText(sadrzaj);



			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.5;
		pane.add(btnOsvezi, c);

		JButton btnSacuvaj= new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String nazivFajla = addressBar.getText();
				String pom = nazivFajla.substring(8);

				String sadrzaj = jep1.getText();


				try {
					FileOutputStream fajl = new FileOutputStream(pom);
					for(char c: sadrzaj.toCharArray())
							fajl.write(c);

					fajl.close();

				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}



			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.weightx = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.5;
		pane.add(btnSacuvaj, c);


	}

}

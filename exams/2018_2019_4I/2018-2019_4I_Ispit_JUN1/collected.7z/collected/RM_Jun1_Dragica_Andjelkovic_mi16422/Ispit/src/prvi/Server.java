package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		BufferedReader in = null;
		BufferedWriter out = null;
		int id = 0;
		int port = 12345;
		try(ServerSocket server = new ServerSocket(port)){
			System.out.println("Started server on port " + port);

			while(true){
				try(Socket client = server.accept()){
					System.out.println("Client accepted");
					in = new BufferedReader(new InputStreamReader(client.getInputStream()));
					out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

					id++;
					out.write(id);
					out.flush();

					String message;
					while((message = in.readLine()) != null){
						out.write(message);
						out.newLine();
						out.flush();

						if(client.isClosed()){
							out.write("Klijent <" + id + "> je napustio chat.");
							out.newLine();
							out.flush();
						}


					}



				} catch(IOException e){

				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				if(in!= null)
					in.close();
				if(out != null)
					out.close();
			} catch(IOException e){

			}
		}

	}

}

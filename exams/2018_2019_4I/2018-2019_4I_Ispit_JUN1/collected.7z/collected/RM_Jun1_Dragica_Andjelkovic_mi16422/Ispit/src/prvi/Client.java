package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {
		BufferedReader sc  = null;
		BufferedReader in = null;
		BufferedWriter out = null;

		String host = "localhost";
		int port = 12345;
		try(Socket client  = new Socket(host, port)){
			sc = new BufferedReader(new InputStreamReader(System.in));
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			// Ispisivanje id-a
			System.out.println(in.read());

			String line;
			while((line = sc.readLine()) != null){
				out.write(line);
				out.newLine();
				out.flush();

			}

			String message;
			while((message = in.readLine()) != null){
				System.out.println(message);
			}

			client.close();

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try{
				if(sc != null)
					sc.close();
				if(in!= null)
					in.close();
				if(out != null)
					out.close();
			} catch(IOException e){

			}
		}
	}

}

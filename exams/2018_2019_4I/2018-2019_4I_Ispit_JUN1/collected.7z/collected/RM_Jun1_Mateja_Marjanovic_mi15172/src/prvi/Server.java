package prvi;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.ServerSocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Server {

	public static void main(String[] args) {
		List<Socket> clients = new ArrayList<>();
		try (ServerSocket server = new ServerSocket(1921)) {
			while (true) {
				Socket client = server.accept();
				new Thread(new Runnable() {
					@Override
					public void run() {
						while (true) {
							if (!clients.contains(client)) {
								clients.add(client);
							}
							Scanner sc = null;
							try {
								sc = new Scanner(client.getInputStream());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							String s = sc.nextLine();
							System.out.println(s);
							Iterator<Socket> iter = clients.iterator();
							while (iter.hasNext()) {
								Socket currentClient = iter.next();
								OutputStreamWriter out = null;
								try {
									out = new OutputStreamWriter(
											currentClient.getOutputStream());
									out.write(s);
									out.write("\r\n");
									out.flush();
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					}
				}).start();

			}
		} catch (IOException e) {
			Iterator<Socket> iter = clients.iterator();
			while (iter.hasNext()) {
				Socket currentClient = iter.next();
				try {
					currentClient.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		}
	}

}

package prvi;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) {
		try (Socket client = new Socket("localhost", 1921)) {
			OutputStreamWriter out = new OutputStreamWriter(
					client.getOutputStream());
			Scanner in = new Scanner(
					client.getInputStream());
			Scanner sc = new Scanner(System.in);
			while (true) {
				String line = sc.nextLine();
				out.write(line);
				out.write("\r\n");
				out.flush();
				String line2 = in.nextLine();
				System.out.println(line2);
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

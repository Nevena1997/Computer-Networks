package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setSize(800, 600);
		f.setResizable(true);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	public static void addComponents(Container pane) {
		pane.setLayout(new GridLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 240;
		c.weightx = 0;
		c.weighty = 1;
		pane.add(scrollPane, c);

		JEditorPane jep2 = new JEditorPane();
		jep2.setEditable(false);
		JScrollPane scrollPane2 = new JScrollPane(jep2);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 240;
		c.weightx = 0;
		c.weighty = 1;
		pane.add(scrollPane2, c);

		JTextArea urlText = new JTextArea("Unesi putanju do fajla");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(urlText, c);

		LinkHandler hendler = new LinkHandler(jep, jep2, urlText);

		JButton prikaziBtn = new JButton("Prikazi");
		prikaziBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				hendler.prikazi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(prikaziBtn, c);

		JButton osveziBtn = new JButton("Osvezi");
		osveziBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				hendler.osvezi();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(osveziBtn, c);

		JButton sacuvajBtn = new JButton("Sacuvaj");
		sacuvajBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				hendler.sacuvaj();
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(sacuvajBtn, c);
	}

}

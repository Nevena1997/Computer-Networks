package drugi;

import java.awt.TextArea;
import java.io.File;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {
	JEditorPane jep1;
	JEditorPane jep2;
	JTextArea address;

	public LinkHandler(JEditorPane jep1, JEditorPane jep2, JTextArea address) {
		this.jep1 = jep1;
		this.jep2 = jep2;
		this.address = address;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		HyperlinkEvent.EventType type = evt.getEventType();
		if (type == HyperlinkEvent.EventType.ACTIVATED) {

		}
	}

	public void osvezi() {

	}

	public void prikazi() {
//		this.jep2.setPage(this.address);
	}

	public void sacuvaj() {
//		File f = new File(this.address.toString());
	}

}

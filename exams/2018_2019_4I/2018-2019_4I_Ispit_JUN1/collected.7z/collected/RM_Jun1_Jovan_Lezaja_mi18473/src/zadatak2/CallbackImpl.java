package zadatak2;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML.Tag;

public class CallbackImpl extends HTMLEditorKit.ParserCallback {
	private JEditorPane pane;
	private StringBuffer content = new StringBuffer();

	public CallbackImpl(JEditorPane jep) {
		this.pane = jep;
	}

	@Override
	public void handleText(char[] data, int pos) {
		content.append(data);
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		super.handleStartTag(t, a, pos);
	}

	@Override
	public void handleEndTag(Tag t, int pos) {
		super.handleEndTag(t, pos);
	}
}

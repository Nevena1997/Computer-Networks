package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.plaf.basic.BasicToolBarUI.DockingListener;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {

	private static String encoding = "UTF-8";

	public static void main(String[] args) {
		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(500,650);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {

		JEditorPane jepEdit = new JEditorPane();
		jepEdit.setEditable(true);

		JEditorPane jepDisplay = new JEditorPane();
		jepDisplay.setEditable(false);

		pane.setLayout(new GridBagLayout());

		GridBagConstraints c = new GridBagConstraints();

		JScrollPane editPane = new JScrollPane(jepEdit);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 500;
		c.ipady = 250;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(editPane, c);

		JScrollPane displayPane = new JScrollPane(jepDisplay);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 500;
		c.ipady = 250;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(displayPane, c);

		JTextArea area = new JTextArea("ovde nesto pise");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(area, c);

		ParserGetter pg = new ParserGetter();
		CallbackImpl cb = new CallbackImpl(jepEdit);
		HTMLEditorKit.Parser parser = pg.getParser();

		JButton showBtn = new JButton("Prikazi");
		showBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					URL url = new URL(area.getText());
					jepDisplay.setPage(url);
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(showBtn, c);

		JButton refreshBtn = new JButton("Osvezi");
		showBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				jepDisplay.setContentType("text/html");
				String text = jepEdit.getText();
				// System.out.println(text);
				jepDisplay.setText(text);
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(refreshBtn, c);

		JButton saveBtn = new JButton("Sacuvaj");
		showBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				BufferedWriter w = null;
				try {
					URLConnection urlc = (new URL(area.getText())).openConnection();
					w = new BufferedWriter(new OutputStreamWriter(urlc.getOutputStream()));
					w.write(jepEdit.getText());
					w.flush();

					w.close();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					try {
						w.close();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					e1.printStackTrace();
				}
			}
		});

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(saveBtn, c);
	}
}

package zadatak1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;


public class Server {

	private static int numClients = 0;

	public static void main(String[] args) {

		ServerSocketChannel serverChannel;
		Selector selector;
		try {
			serverChannel = ServerSocketChannel.open();
			serverChannel.socket().bind(new InetSocketAddress(12345));
			serverChannel.configureBlocking(false);

			selector = Selector.open();

			serverChannel.register(selector, SelectionKey.OP_ACCEPT);
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		while (true) {
			try {
				selector.select();
			} catch (IOException e) {
				e.printStackTrace();
			}

			Set<SelectionKey> keys = selector.selectedKeys();
			Iterator<SelectionKey> iterator = keys.iterator();

			while (iterator.hasNext()) {
				SelectionKey key = iterator.next();
				iterator.remove();

				try {
					if (key.isAcceptable()) {
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client = server.accept();
						System.out.println("Uspesno uspostavljena konekcija! ID klijenta: " + (++numClients));

						client.configureBlocking(false);

						SelectionKey key1 = client.register(selector, SelectionKey.OP_READ);
						ByteBuffer buffer = ByteBuffer.allocate(100);
						key1.attach(buffer);
					} else if (key.isReadable()) {
						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer buffer = (ByteBuffer) key.attachment();

						buffer.clear();
						client.read(buffer);

						key.interestOps(SelectionKey.OP_WRITE);
					} else if (key.isWritable()) {
						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer buffer = (ByteBuffer) key.attachment();

						buffer.flip();
						client.write(buffer);

						key.interestOps(SelectionKey.OP_READ);
					}

				} catch (IOException e) {
					key.cancel();
					try {
						key.channel().close();
					} catch (IOException ex) {
						e.printStackTrace();
					}
				}
			}
 		}
	}
}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


public class ChatClient {

	public static void main(String[] args) {
		String hostname = "localhost";
		int port = 12345;
		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;
		try (Socket sock = new Socket(hostname,port)) {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			sc = new Scanner(System.in);

			while(sc.hasNext()){
			String ulaz = sc.nextLine();

			/*Saljemo serveru ono sto je klijent uneo sa standardnog ulaza*/
			out.write(ulaz);
			out.newLine();
			out.flush();

			}

			/*Ispisujemo ono sto je server poslao.*/
			System.out.println(in.read());

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				/*u slucaju izuzetka zatvaramo otvorene resurse*/
				if(in != null)
				 in.close();
				if(out != null)
					 out.close();
				if(sc != null)
					 sc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

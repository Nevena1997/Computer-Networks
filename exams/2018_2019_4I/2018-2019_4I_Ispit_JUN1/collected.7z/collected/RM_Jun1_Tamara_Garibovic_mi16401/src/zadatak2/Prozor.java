package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Prozor {

	/*	Difoltno upisana putanja do prvog test fajla, a moze se rucno u address baru promeniti*/
	public static final String prvi_test_fajl = "file:///C:/Users/nalog/Desktop/RM_Jun1_Tamara_Garibovic_mi16401/src/zadatak2/1.html";

	public static void main(String[] args) {
		JFrame f = new JFrame("HTMLEditor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(900, 700);
		/*prozoru moze da se menja velicina*/
		f.setResizable(true);
		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});
	}

	private static void addComponents(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		//Skrolabilna komponenta koja prikazuje sadrzaj html-a;
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane spane = new JScrollPane(jep);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 300;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(spane,c);

		JTextArea editor = new JTextArea(350,350);
		JScrollPane seditor = new JScrollPane(editor);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.ipadx = 0;
		c.ipady = 300;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(seditor,c);

		JTextArea url = new JTextArea(prvi_test_fajl);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 160;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(url,c);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					/*URL do fajla ciji sadrzaj se prikazuje*/
					URL html_file = new URL(url.getText());
					/*uzimamo putanju do fajla*/
					String putanja = html_file.getPath();
					Scanner sc = new Scanner(new FileInputStream(putanja));
					StringBuilder sadrzaj_fajla = new StringBuilder();
					/*Kreiramo string koji sadrzi source fajla*/
					while(sc.hasNext()){
						sadrzaj_fajla.append(sc.nextLine());
						sadrzaj_fajla.append("\r\n");
					}
					jep.setPage(url.getText());
					/*upisujemo sadrzaj u komponentu za prikaz sourc-a*/
					editor.setText(sadrzaj_fajla.toString());
					sc.close();
				} catch (IOException e) {
					jep.setText("<html>Could not load page: " + url.getText() + "</html>");
				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(prikazi,c);

		JButton osvezi = new JButton("Osvezi");
		osvezi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				jep.setText(editor.getText());
			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(osvezi,c);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				//Text koji treba da se sacuva
				String text = editor.getText();
				//URL do fajla u koji treba sacuvati text
				try {
					URL u = new URL(url.getText());
					/*Izdvajanje putanje do fajla*/
					String putanja = u.getPath();
					FileOutputStream out = new FileOutputStream(putanja);
					byte[] text_byte = text.getBytes();
					out.write(text_byte);
					out.close();
				} catch (IOException e) {
					System.err.println("Invalid URL string.");
				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 3;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(sacuvaj,c);
	}

}

package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {
	public static void main(String[] args) {

		JFrame f = new JFrame("HTML Editor");
		f.setSize(600, 700);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponent(f.getContentPane());

		EventQueue.invokeLater(() -> f.setVisible(true));
	}

	private static void addComponent(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea ta = new JTextArea();
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 6;
		c.gridheight = 1;
		c.ipadx = 600;
		c.ipady = 300;
		JScrollPane spTextInput = new JScrollPane(ta);
		pane.add(spTextInput, c);

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 6;
		c.gridheight = 1;
		c.ipadx = 700;
		c.ipady = 200;
		JScrollPane spPane = new JScrollPane(jep);
		pane.add(spPane, c);

		JTextArea taFile = new JTextArea();
		c.gridx = 1;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 370;
		c.ipady = 10;
		JScrollPane spFile = new JScrollPane(taFile);
		pane.add(spFile, c);


		JButton btPrikazi = new JButton("Prikazi");
		btPrikazi.addActionListener(e -> {
			try {
				jep.setPage(new URL(taFile.getText()));
			} catch (MalformedURLException e1) {
				jep.setText("Los URL");
			} catch (IOException e1) {
				jep.setText("Nepoznata adresa");
			}
		});
		c.gridx = 2;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btPrikazi, c);


		JButton btOsvezi = new JButton("Osvezi");
		btOsvezi.addActionListener(e -> {
			jep.setEditorKit(new HTMLEditorKit());
			jep.setText(ta.getText());
		});
		c.gridx = 3;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btOsvezi, c);


		JButton btSacuvaj = new JButton("Sacuvaj");
		btSacuvaj.addActionListener(e -> {
			String path = taFile.getText().replaceFirst("FILE:///", "");
			try (OutputStreamWriter out = new OutputStreamWriter(
					new FileOutputStream(path))) {
				out.write(ta.getText());
				jep.setText("Fajl uspesno sacuvan!");
			} catch (FileNotFoundException e1) {
				jep.setText("Unesi naziv fajla za cuvanje");
			} catch (IOException e2) {
				jep.setText("Greska pri otvaranju fajla");
			}
		});
		c.gridx = 4;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(btSacuvaj, c);

	}
}

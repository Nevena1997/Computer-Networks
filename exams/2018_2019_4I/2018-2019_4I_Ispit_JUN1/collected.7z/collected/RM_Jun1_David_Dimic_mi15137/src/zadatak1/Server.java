package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static final int PORT = 12345;

	public static void main(String[] args) {

		/*
		 * NOTE Nisam uspeo da se snadjem s tredovima,
		 * ispod komentarisanog je kod bez
		 *
		try (ServerSocket server = new ServerSocket()) {
			server.bind(new InetSocketAddress(PORT));
			System.err.println("Pokrenut server na portu " + PORT);

			for (int i = 0; i < 3; i++) {

				Thread t = new Thread(new Runnable() {
					@Override
					public void run() {
					BufferedReader in = null;
					BufferedWriter out = null;
					try {

					Socket sok = server.accept();

					System.err.println("Povezan klijent " + sok.getRemoteSocketAddress());

					in = new BufferedReader(new InputStreamReader(sok.getInputStream()));
					out = new BufferedWriter(new OutputStreamWriter(sok.getOutputStream()));

					String s = null;
					while (true) {
						s = in.readLine();

						out.write(s);
						out.newLine();
						out.flush();
					}
					} catch (IOException e) {
						e.printStackTrace();
					}
					finally {
						try {
							if (in != null) in.close();
							if (out != null) out.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
			}
		});
				t.start();
		}

		} catch (IOException e) {
			e.printStackTrace();
		}
*/
		BufferedReader in = null;
		BufferedWriter out = null;;

		try (ServerSocket server = new ServerSocket()) {
			server.bind(new InetSocketAddress(PORT));
			System.err.println("Pokrenut server na portu " + PORT);

			Socket sok = server.accept();
			System.err.println("Povezan klijent " + sok.getRemoteSocketAddress());

			in = new BufferedReader(new InputStreamReader(sok.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(sok.getOutputStream()));

			String s = null;
			while (true) {

				s = in.readLine();

				if (s.equalsIgnoreCase("stop")) {
					sok.close();
					System.err.println("Disconnected " + sok.getRemoteSocketAddress());
				}

				out.write(s);
				out.newLine();
				out.flush();
			}
		} catch (IOException e) {
			System.err.println("IO error: " + e);
		} finally {
				try {
					if (in != null) in.close();
					if (out != null) out.close();
				} catch (IOException e) {
					System.err.println("Close error");
				}
		}
	}
}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Klijent {
	public static void main(String[] args) {
		String host = "localhost";
		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;

		try (Socket klijent = new Socket(host, Server.PORT)) {

			in = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
			sc = new Scanner(System.in);

			while (true) {
				String line = sc.nextLine();

				out.write(line);
				out.newLine();
				out.flush();

				if (line.equalsIgnoreCase("stop")) break;

				System.out.println(in.readLine());
			}

			in.close();
			out.close();
			sc.close();

		} catch (UnknownHostException e) {
			System.err.println("Unknown Host");
		} catch (IOException e) {
			System.err.println("IO error / Server nije pokrenut: " + e);
		}
	}
}

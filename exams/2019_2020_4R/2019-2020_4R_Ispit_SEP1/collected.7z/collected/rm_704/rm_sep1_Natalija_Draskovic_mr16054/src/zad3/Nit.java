package zad3;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Map;
import java.util.Scanner;

public class Nit extends Thread {
    public Path path;
    public Map<String,Integer> mapa;

    public Nit(Path p, Map<String,Integer> mapa){
        this.path=p;
        this.mapa=mapa;
    }

    @Override
    public void run(){
        try (Scanner sc=new Scanner(path)){
            sc.useDelimiter(" ");
            while(sc.hasNext()){
                String rec=sc.next();
                synchronized (mapa){
                    if(mapa.containsKey(rec)) {
                        int br = mapa.get(rec);
                        mapa.replace(rec, br++);
                    }
                    else
                        mapa.put(rec,0);
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

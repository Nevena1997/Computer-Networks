package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try(DatagramSocket socket=new DatagramSocket();
            Scanner sc=new Scanner(System.in)) {
            System.out.println("Klijent pokrenut!");
            int n=sc.nextInt();
            int m=sc.nextInt();
            String loc=""+n+""+m;
            byte[] lokacija=loc.getBytes();
            DatagramPacket paket_za_slanje=new DatagramPacket(lokacija,lokacija.length, InetAddress.getLocalHost(),12345);
            socket.send(paket_za_slanje);
            byte[] poruka=new byte[256];
            DatagramPacket paket_za_prijem=new DatagramPacket(poruka,poruka.length);
            socket.receive(paket_za_prijem);
            String pokriven=new String(poruka,0,poruka.length);
            if (pokriven=="da")
                System.out.println("Pokriven!");
            else
                System.out.println("Nije pokriven!");
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}

package zad3;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Zad3Main {
    public static void main(String[] args) {
        try(Scanner sc=new Scanner(System.in)){
            String putanja=sc.nextLine();
            DirectoryStream<Path> stream= Files.newDirectoryStream(Path.of(putanja));
            Map<String,Integer> mapa=new HashMap<String, Integer>();
            ObidjiDir.mapa=mapa;
            for (Path p: stream){
                if (Files.isRegularFile(p) && p.endsWith(".txt")) {
                    System.out.println(p);
                    new Nit(p,mapa).start();
                }
                else if (Files.isDirectory(p)){
                    ObidjiDir.obidji(p);
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}


package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class UDPServer {
    public static void main(String[] args) {
        try(Scanner fajl=new Scanner(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_sep1_Natalija_Draskovic_mr16054/terrain.txt")));
            DatagramSocket socket=new DatagramSocket(12345)) {
            System.out.println("terrain.txt ucitan!");
            System.out.println("Server pokrenut!");
            int a,b,m,n,r;
            a=fajl.nextInt();
            b=fajl.nextInt();
            List<Integer> lista=new LinkedList<Integer>();
            while (fajl.hasNext()){
                m=fajl.nextInt();
                n=fajl.nextInt();
                r=fajl.nextInt();
                lista.add(m);
                lista.add(n);
                lista.add(r);
            }
            while(true) {
                byte[] poruka = new byte[256];
                DatagramPacket paket_za_prijem = new DatagramPacket(poruka, poruka.length);
                socket.receive(paket_za_prijem);
                String por = new String(poruka, 0, poruka.length);
                int x = new Integer(por.substring(0, 1));
                int y = new Integer(por.substring(1, 2));
                System.out.println("Stigao datagram!");
                byte[] pokriven;
                Iterator<Integer> iter = lista.iterator();
                boolean pokriveno = false;
                while (iter.hasNext()) {
                    m = iter.next();
                    n = iter.next();
                    r = iter.next();
                    if (Math.abs(x-m)<=r && Math.abs(y-n)<=r)
                        pokriveno = true;
                    if (pokriveno)
                        break;
                }
                if (pokriveno)
                    pokriven = "da".getBytes();
                else
                    pokriven = "ne".getBytes();
                DatagramPacket paket_za_slanje = new DatagramPacket(pokriven, pokriven.length, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                socket.send(paket_za_slanje);
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

}

package zad3;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class ObidjiDir {
    public static Map<String,Integer> mapa;

    public static void obidji(Path path){
        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(path);
            for (Path p : stream) {
                if (Files.isRegularFile(p) && p.endsWith(".txt")) {
                    System.out.println(p);
                    new Nit(p,mapa).start();
                } else if (Files.isDirectory(p)) {
                    obidji(p);
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        try(SocketChannel klijent=SocketChannel.open(new InetSocketAddress(7337));
            Scanner sc=new Scanner(System.in)){
            int n=sc.nextInt();
            int m=sc.nextInt();
            int r=sc.nextInt();
            ByteBuffer buff=ByteBuffer.allocate(16);
            buff.clear();
            buff.putInt(n);
            buff.putInt(m);
            buff.putInt(r);
            buff.flip();
            while (true) {
                int pokrivenost;
                pokrivenost = klijent.read(buff);
                System.out.println(pokrivenost);
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    public static void main(String[] args) {

        try(ServerSocketChannel server=ServerSocketChannel.open();
            Selector selector=Selector.open();
            Scanner sc=new Scanner(System.in)) {
            if (!server.isOpen() || !selector.isOpen()){
                System.err.println("Server ili selektor nisu otvoreni");
                System.exit(1);
            }
            server.bind(new InetSocketAddress(7337));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            int a=sc.nextInt();
            int b=sc.nextInt();
            int pokrivenost=0;
            while (true){
                selector.select();
                Iterator<SelectionKey> kljucevi=selector.selectedKeys().iterator();
                while(kljucevi.hasNext()){
                    SelectionKey trenutni=kljucevi.next();
                    kljucevi.remove();
                    if (trenutni.isAcceptable()){
                        ServerSocketChannel serverKanal=(ServerSocketChannel)trenutni.channel();
                        while (true){
                            SocketChannel klijent=serverKanal.accept();
                            SelectionKey klijentKljuc=klijent.register(selector,SelectionKey.OP_READ);
                            ByteBuffer buff=ByteBuffer.allocate(16);
                            klijentKljuc.attach(buff);
                        }
                    }
                    else if (trenutni.isReadable()){
                        SocketChannel klijent=(SocketChannel)trenutni.channel();
                        ByteBuffer buff=(ByteBuffer)trenutni.attachment();
                        int n=buff.getInt();
                        int m=buff.getInt();
                        int r=buff.getInt();
                        if (m<0 || m>a || n<0 || n>b)
                            klijent.close();
                        else {
                            pokrivenost=pokrivenost+4*r*r/a*b;
                            if (pokrivenost==100)
                                break;
                            klijent.register(selector, SelectionKey.OP_WRITE);
                        }
                    }
                    else if (trenutni.isWritable()){
                        SocketChannel klijent=(SocketChannel)trenutni.channel();
                        ByteBuffer buff=(ByteBuffer)trenutni.attachment();
                        buff.clear();
                        buff.putInt(pokrivenost);
                        buff.flip();
                        klijent.register(selector,SelectionKey.OP_WRITE);
                    }
                }
            }

        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}

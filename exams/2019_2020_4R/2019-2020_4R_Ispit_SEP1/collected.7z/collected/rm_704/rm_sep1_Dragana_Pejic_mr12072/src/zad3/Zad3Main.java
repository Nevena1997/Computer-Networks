package zad3;


import java.util.HashMap;

public class Zad3Main {
    public static void main(String[] args) {

        if(args.length != 1){
            System.err.println("Kao argument je potrebno proslediti putanju do direktorijuma");
            System.exit(1);
        }

        String path = args[0];

        HashMap<String, Integer> frequency = new HashMap<>();



    }
}

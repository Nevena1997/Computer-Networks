package zad3;

public class FileHandlerRunnable implements Runnable {

    @Override
    public void run(){

    }
}

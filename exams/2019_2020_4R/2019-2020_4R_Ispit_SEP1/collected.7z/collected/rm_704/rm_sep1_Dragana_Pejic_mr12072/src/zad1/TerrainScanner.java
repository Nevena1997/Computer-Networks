package zad1;

import java.io.IOException;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Scanner;

public class TerrainScanner {

    public static final int DEFAULT_PORT = 7337;
    public static final String HOSTNAME = "localhost";

    public static void main(String[] args) {

        InetSocketAddress addr = new InetSocketAddress(HOSTNAME, DEFAULT_PORT);

        try(SocketChannel client = SocketChannel.open(addr);
            Scanner sc = new Scanner(System.in);
            WritableByteChannel out = Channels.newChannel(System.out)){

            int[] input = new int[3];

            System.out.println("x = ");
            String xLine = sc.nextLine().trim();
            input[0] = Integer.parseInt(xLine);

            System.out.println("y = ");
            String yLine = sc.nextLine().trim();
            input[1] = Integer.parseInt(yLine);

            System.out.println("r = ");
            String rLine = sc.nextLine().trim();
            input[2] = Integer.parseInt(rLine);


           ByteBuffer buf = ByteBuffer.allocate(4);

            for(int i = 0; i < 3; i++){
                buf.putInt(input[i]);
                buf.flip();
                client.write(buf);
                buf.clear();
            }

            ByteBuffer response = ByteBuffer.allocate(256);
            while(client.read(response) != -1){
                response.flip();
                out.write(response);
                response.clear();
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

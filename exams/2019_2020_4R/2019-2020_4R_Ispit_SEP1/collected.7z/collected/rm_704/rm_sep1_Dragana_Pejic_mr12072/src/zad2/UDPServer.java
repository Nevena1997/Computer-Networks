package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedList;

public class UDPServer {

    public static final int PORT = 12345;
    public static final int BUF_SIZE = 256;

    public static void main(String[] args) {

        try(DatagramSocket server = new DatagramSocket(PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("terrain.txt"), StandardCharsets.UTF_8))){

            LinkedList<Skener> skeners = new LinkedList<>();

            String firstLine = in.readLine().trim();
            String[] parts = firstLine.split(" ");
            //System.err.println(parts.length);
            int X = Integer.parseInt(parts[0]);
            int Y = Integer.parseInt(parts[1]);

            String line;
            while((line = in.readLine()) != null){
                line = line.trim();
                String[] slices = line.split(" ");
                int x = Integer.parseInt(slices[0]);
                int y = Integer.parseInt(slices[1]);
                int r = Integer.parseInt(slices[2]);

                Skener element = new Skener(x, y, r);
                skeners.add(element);
            }

            System.err.println("terrain.txt ucitan!");

            while(true){
                DatagramPacket request = new DatagramPacket(new byte[BUF_SIZE], BUF_SIZE);
                server.receive(request);

                System.err.println("Pristigao klijent!");

                String data = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
                String[] bits = data.split(" ");
                int xClient = Integer.parseInt(bits[0]);
                int yClient = Integer.parseInt(bits[1]);

                String answer = "";

                if(xClient < 0 || xClient > X || yClient < 0 || yClient > Y)
                    answer = "ne";

                Iterator<Skener> it = skeners.iterator();
                while(it.hasNext()){
                    Skener ex = it.next();
                    if(ex.belongToSkener(xClient, yClient))
                        answer = "da";
                }

                byte[] bytes = answer.getBytes();
                DatagramPacket response = new DatagramPacket(bytes, bytes.length, request.getAddress(), request.getPort());
                server.send(response);
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

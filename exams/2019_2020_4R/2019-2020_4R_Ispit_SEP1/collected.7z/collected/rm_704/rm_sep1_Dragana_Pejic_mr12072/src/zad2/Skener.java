package zad2;

public class Skener {

    private int x;
    private int y;
    private int r;

    public Skener(int x, int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public int getR(){
        return this.r;
    }

    public boolean belongToSkener(int a, int b){

        if(a < (x - r) || a > (x + r))
            return false;

        if(b < (y - r) || b > (y + r))
            return false;

        return true;
    }

}

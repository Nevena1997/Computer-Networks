package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {

    public static final int PORT = 12345;
    public static final String HOSTNAME = "localhost";
    public static final int BUF_SIZE = 2;

    public static void main(String[] args) {

        try(DatagramSocket socket = new DatagramSocket();
            Scanner in = new Scanner(System.in)){

            InetAddress host = InetAddress.getByName(HOSTNAME);

            System.err.println("Klijent pokrenut");

            String line = in.nextLine().trim();
            byte[] bytes = line.getBytes();

            //System.err.println(bytes.length);

            DatagramPacket request = new DatagramPacket(bytes, bytes.length, host, PORT);
            socket.send(request);

            DatagramPacket response  = new DatagramPacket(new byte[BUF_SIZE], BUF_SIZE);
            socket.receive(response);

            String data = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);

            String dataProper = data.equalsIgnoreCase("da") ? "Pokriven!" : "Nije pokriven!";

            System.out.println(dataProper);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

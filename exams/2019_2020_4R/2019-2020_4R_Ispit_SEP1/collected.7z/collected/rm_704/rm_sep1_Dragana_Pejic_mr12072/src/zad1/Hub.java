package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    public static final int DEFAULT_PORT = 7337;

    public static void main(String[] args) {

        System.err.println("Listening for connections on port " + DEFAULT_PORT);

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner in = new Scanner(System.in)){

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("The server socket channel or selector cannot be opened.");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(DEFAULT_PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            System.out.println("m = ");
            String xLine = in.nextLine().trim();
            int m = Integer.parseInt(xLine);

            System.out.println("n = ");
            String yLine = in.nextLine().trim();
            int n = Integer.parseInt(yLine);

            float pokrivenost = 0;
            int kvadrati = 0;

            while(true){
                selector.select();

                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    try{
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            System.err.println("Accepted connection from " + client.getRemoteAddress());

                            client.configureBlocking(false);
                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buf = ByteBuffer.allocate(4);
                            clientKey.attach(buf);

                        }
                        else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer input = (ByteBuffer) key.attachment();

                            System.err.println("Stigli smo ovde");

                            /*if(client.read(input) > 0){
                                input.flip();

                                byte[] bytes = input.array();
                                String line = bytes.toString();

                                System.err.println();
                            }*/

                            if(input.hasRemaining()){
                                //input.flip();

                                /*byte[] bytes = input.array();
                                String line = bytes.toString();

                                System.err.println(line);*/


                                //byte[] xBuf = new byte[4];
                                //input.get(xBuf, 0, 4);
                                int xClient = input.getInt();  //Integer.parseInt(new String(xBuf));
                                System.out.println("X od klijenta je " + xClient);
                                input.clear();

                                key.interestOps(SelectionKey.OP_WRITE);
                            }

                            client.read(input);
                        }
                        else if(key.isWritable()){

                        }
                    }
                    catch(IOException ex){
                        key.cancel();
                        try{
                            key.channel().close();
                        }
                        catch (IOException cex){
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

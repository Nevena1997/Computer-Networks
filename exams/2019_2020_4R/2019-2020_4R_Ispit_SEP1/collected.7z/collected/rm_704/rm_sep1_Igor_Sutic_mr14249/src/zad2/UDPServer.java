package zad2;

import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPServer {

    public static final int PORT = 12345;

    public static void main(String[] args) throws SocketException {

        try(DatagramSocket server = new DatagramSocket(PORT)){


        }
        catch(Exception e){
            e.printStackTrace();
        }

    }
}

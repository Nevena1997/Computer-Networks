package zad3;


import java.io.*;
import java.nio.file.Path;
import java.util.Map;
import java.nio.*;

// odgovaraju ́ce ulazne tokove podataka, da proˇcita sadrˇzaj tog fajla i
// aˇzurira broj pojavljivanja odgovaraju ́cihreˇci u zajedniˇckoj strukturi podataka
public class ThreadFiles extends Thread{

    private BufferedReader in;
    private Map<String, Integer> mapa;
    private Path path;

    ThreadFiles(BufferedReader in, Map<String, Integer> mapa, Path path){
        this.in = in;
        this.mapa = mapa;
        this.path = path;
    }

    @Override
    public void run() {

        try {
            String line = null;
            int brojac = 0;

            while ((line = in.readLine()) != null)
                    brojac++;

            mapa.put(this.path.toString(), brojac);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;


import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.*;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

//klijent -> x &  y , r -radijus
public class TerrainScanner {


    public static void main(String[] args) {

            try(Scanner sc = new Scanner(System.in)){

                try{

                    SocketAddress addr = new InetSocketAddress(Hub.PORT);
                    SocketChannel client = SocketChannel.open(addr);

                    client.configureBlocking(true);

                    InputStream in =  Channels.newInputStream(client);
                    OutputStream out = Channels.newOutputStream(client);

                    int x = sc.nextInt();
                    int y = sc.nextInt();
                    int r = sc.nextInt();

                    out.write(x);
                    out.write(y);
                    out.write(r);
                    out.flush();

                    // Citamo
                    // in.read...
                    // i pisemo na stdout
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                sc.close();

            }catch (Exception e) {
                e.printStackTrace();
            }

    }
}

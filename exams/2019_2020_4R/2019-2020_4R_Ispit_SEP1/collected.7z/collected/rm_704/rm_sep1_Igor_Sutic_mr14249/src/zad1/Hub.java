package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.Scanner;

//server
public class Hub {

    public static final int PORT =7337;

    public static void main(String[] args) throws IOException {

        try(ServerSocketChannel serverChannel = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner sc = new Scanner(System.in)
        ){

            System.out.println("Unesite dimenzije terena(m,n): ");
            int n = sc.nextInt();
            int m = sc.nextInt();

            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Ne mozemo da otvorimo kanal ili selektora");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            try{

                while(true){

                    selector.select();

                    Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                    while (iter.hasNext()){

                        SelectionKey key;
                        key = iter.next();
                        iter.remove();

                        try{

                            if(key.isAcceptable()){
                                ServerSocketChannel kanal = (ServerSocketChannel) key.channel();
                                SocketChannel client = kanal.accept();

                                System.err.println("Client accepted!");

                                SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);
                                ByteBuffer buffer = ByteBuffer.allocate(3);


                                buffer.flip();


                                clientKey.attach(buffer);

                            }
                            else if(key.isReadable()){

                                SocketChannel client = (SocketChannel) key.attachment();
                                ByteBuffer buffer = (ByteBuffer) key.attachment();

                                buffer.clear();

                                // Ovde treba da pokupim getInputStream od klijenta
                                // i da procitam brojeve koje je poslao i da ih smestim
                                // u ByteBuffer ( Ali ne znam kako da dobijem stream)
                                // i da spremim za pisanje buffer sa flip()


                                InputStream in = Channels.newInputStream(client);

                                byte[] niz = in.readAllBytes();

                                buffer.put(niz);

                                buffer.flip();
                            }
                            else if(key.isWritable()){

                                SocketChannel client = (SocketChannel)key.attachment();
                                ByteBuffer buffer = (ByteBuffer) key.attachment();

                                byte x = buffer.get(0);
                                byte y = buffer.get(2);
                                byte r = buffer.get(4);

                                // Proverim dal je r unutar 9 i 6
                                /*
                                    sad kad sam pokupio:
                                    int x = ...;
                                    int y = ...;
                                    int r = ...;

                                    P = m*n; ovo je polje celo
                                    e sad  proveravamo za x & y:
                                    x1 = (x-1) + (x+1);
                                    y1 = (y-1) + (y+1);
                                    P1 = x1 * y1;

                                    P_u = P1 / P;
                                    if(P_U >= 1)
                                    // tj u nasem slucaju saljemo P_U
                                        return "Jeste pokriven" tj ispis
                                    else
                                    // isto
                                        "Nije pokriven"
                                        idi na metod za kraj npr

                                 */
                            }
                        }
                        catch (Exception e){

                        }
                    }

                }

            }catch (Exception e){
                e.printStackTrace();
            }
            sc.close();
        }

    }
}

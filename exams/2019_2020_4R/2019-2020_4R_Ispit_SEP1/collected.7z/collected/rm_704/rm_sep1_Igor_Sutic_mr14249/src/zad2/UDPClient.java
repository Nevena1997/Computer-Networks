package zad2;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPClient {


    public static void main(String[] args) throws SocketException {

        String host = "localhost";

        try(DatagramSocket dp = new DatagramSocket(UDPServer.PORT)){

            //DatagramPacket request = new DatagramPacket(new byte[1], 1, host, UDPServer.PORT);
           // dp.send(request);

        }
    }
}

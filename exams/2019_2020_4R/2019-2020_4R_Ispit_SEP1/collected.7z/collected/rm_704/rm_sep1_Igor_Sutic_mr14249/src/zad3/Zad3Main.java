package zad3;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

///home/ispit/Desktop/rm_sep1_Ime_Prezime_mXGGXXX

public class Zad3Main {

    public static void main(String[] args) {

        System.out.println("Enter path: ");
        String word;

        // U try-block
        Scanner sc = new Scanner(System.in);
        String pathStr = sc.nextLine();

        Set<String> words = new HashSet<>();
        Path startDir = Paths.get(pathStr);
        Set<Path> arrayFile = new HashSet<>();

        arrayFile = files(startDir, arrayFile);

        for(Path p : arrayFile){

            try {

                BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toString())));

                String line =null;
                int count = 0;
                while((line = in.readLine()) != null)
                    count++;

                System.out.println(p.toString() + "\t" + count);

                //new ThreadFiles(in, words, p).start();

                //System.out.println(rec : brojpojavljivanja);
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }

        sc.close();
    }

    public static Set<Path> files(Path startDir,Set<Path> nizFajlova){


        try(DirectoryStream<Path> dir = Files.newDirectoryStream(startDir)){

            for(Path p : dir){

                if(Files.isDirectory(p)){
                    files(p, nizFajlova);
                }
                else if(Files.isRegularFile(p)){

                    if(p.getFileName().toString().contains(".txt"))
                        nizFajlova.add(p);
                }
            }
        }catch (IOException e){
            e.printStackTrace();
        }

        return  nizFajlova;
    }

}

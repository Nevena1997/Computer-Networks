package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {


        System.out.println("glhf from UDPClient");

        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){

            System.out.println("Klijent pokrenut!");
            int x = sc.nextInt();
            int y = sc.nextInt();

            String xy = Integer.toString(x) + " " + Integer.toString(y);
            byte[] buff = xy.getBytes();

            DatagramPacket zaSlanje = new DatagramPacket(buff, buff.length, InetAddress.getLocalHost(), UDPServer.PORT);

            klijent.send(zaSlanje);

            byte[] buff2 = new byte[256];

            DatagramPacket zaPrijem = new DatagramPacket(buff2, buff2.length);

            klijent.receive(zaPrijem);

            String odgovor = new String(buff2, 0, zaPrijem.getLength());

            System.out.println(odgovor);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {

        System.out.println("glhf from TerrainScanner");

        try(Socket client = new Socket("localhost", 7337);
            Scanner sc = new Scanner(System.in);
            PrintWriter out = new PrintWriter(client.getOutputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
        ){

            int x, y, r;

            x = sc.nextInt();
            y = sc.nextInt();
            r = sc.nextInt();

            String zahtev = Integer.toString(x) + " " + Integer.toString(y) + " " + Integer.toString(r) + "\r\n\r\n";

            out.print(zahtev);
            out.flush();

            String rezultat;
            while((rezultat = in.readLine()) != null)
                System.out.println(rezultat);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

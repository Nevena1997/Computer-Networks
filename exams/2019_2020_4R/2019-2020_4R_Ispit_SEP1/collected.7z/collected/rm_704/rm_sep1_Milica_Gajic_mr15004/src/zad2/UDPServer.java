package zad2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;

public class UDPServer {

    public static int PORT = 12345;
    private int m, n;
    private int[][] mapa;


    public UDPServer(){
        this.m = 0;
        this.n = 0;
    }


    public static void main(String[] args) {

        System.out.println("glhf from UDPServer");
        UDPServer server = new UDPServer();
        server.ucitajPodatke();
        System.out.println("terranian.txt ucitan!");
        server.pokreni();

    }

    private void pokreni() {

        try(DatagramSocket server = new DatagramSocket(PORT)) {


            System.out.println("Server pokrenut!");

            while(true){

                byte[] buff = new byte[256];

                DatagramPacket prijem = new DatagramPacket(buff, buff.length);

                server.receive(prijem);

                System.out.println("Strigao datagram!");

                String xy = new String(buff,0,  prijem.getLength());
                int x = Integer.parseInt(xy.substring(0, xy.indexOf(' ')));
                int y = Integer.parseInt(xy.substring(xy.indexOf(' ') + 1));

                String odgovor;
                if(x >= 0 && x < m && y >= 0 && y < n && mapa[x][y] == 1)
                    odgovor = "Pokriven!";
                else
                    odgovor = "Nije pokriven!";

                DatagramPacket zaSlanje = new DatagramPacket(odgovor.getBytes(), odgovor.length(), prijem.getAddress(), prijem.getPort());

                server.send(zaSlanje);

            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void ucitajPodatke() {

        try(Scanner sc = new Scanner(new FileInputStream("/home/ispit/Desktop/rm_sep1_Milica_Gajic_mr15004/terrain.txt"))) {

            if(sc.hasNextInt())
                this.m = sc.nextInt();
            if(sc.hasNextInt())
                this.n = sc.nextInt();

            mapa = new int[m][n];

            for(int i = 0; i < m; i++){

                for(int j = 0; j < n; j++){

                    mapa[i][j] = 0;
                }
            }

            while(sc.hasNextInt()){

                int x = sc.nextInt();
                int y = sc.nextInt();
                int r = sc.nextInt();


                for(int i = x - r; i < x + r; i++){

                    if(i < 0 || i >= m)
                        continue;

                    for(int j = y - r; j < y + r; j++){

                        if(j < 0 || j >= n)
                            continue;

                        mapa[i][j] = 1;
                    }
                }

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

package zad3;

public class WordCounter implements Runnable {

    private FileTreeWalker walker;

    public WordCounter(FileTreeWalker fileTreeWalker) {

        this.walker = fileTreeWalker;
    }

    @Override
    public void run() {

    }
}

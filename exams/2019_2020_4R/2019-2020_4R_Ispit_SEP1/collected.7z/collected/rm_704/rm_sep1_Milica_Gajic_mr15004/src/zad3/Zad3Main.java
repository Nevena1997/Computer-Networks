package zad3;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Zad3Main {
    public static void main(String[] args) {
        System.out.println("glhf from Zad3Main");

        Scanner sc = new Scanner(System.in);

        String dirName = sc.nextLine();

        sc.close();

        Path dir = Paths.get(dirName);

        new Thread(new FileTreeWalker(dir, 5)).start();

    }
}

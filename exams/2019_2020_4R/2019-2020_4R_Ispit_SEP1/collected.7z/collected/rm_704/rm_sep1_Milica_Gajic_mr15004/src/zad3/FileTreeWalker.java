package zad3;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileTreeWalker implements Runnable {

    private Path dir;
    private int numOfThreads;

    private List<Path> regFiles = Collections.synchronizedList(new ArrayList<>());


    public FileTreeWalker(Path dir, int num) {

        this.dir = dir;
        this.numOfThreads = num;
    }

    @Override
    public void run() {

        for(int i = 0; i < this.numOfThreads; i++){

            new Thread(new WordCounter(this)).start();
        }
    }
}

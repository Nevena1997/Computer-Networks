package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {
    
    private int m,n;
    private int[][] mapa;
    private int popunjeno;
    private double procenat;
    
    public Hub(int m, int n){
        
        this.m = m;
        this.n = n;
        this.mapa = new int[m][n];

        for(int i = 0; i < m; i++){
            for(int j = 0; j < n; j++){
                mapa[i][j] = 0;
            }
        }
        
        this.popunjeno = 0;

        this.procenat = 0.0;
        
    }
    
    public static void main(String[] args) {
        System.out.println("glhf from Hub");

        Scanner sc = new Scanner(System.in);
        int m,n;

        m = sc.nextInt();
        n = sc.nextInt();

        sc.close();

        Hub hub = new Hub(m, n);
        
        hub.pokreni();
    }

    private void pokreni() {

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();
        ){

            if(!server.isOpen() || !selector.isOpen()){

                System.err.println("Greska pri pokretanju servera");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(7337));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            


            while(true){

                selector.select();

                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while(iter.hasNext()){

                    SelectionKey key = iter.next();
                    iter.remove();

                    if (key.isAcceptable()){

                        ServerSocketChannel serverskiKanal = (ServerSocketChannel) key.channel();

                        SocketChannel klijent = serverskiKanal.accept();
                        
                        klijent.configureBlocking(false);

                        klijent.register(selector, SelectionKey.OP_READ);
                    }else if(key.isReadable()){

                        SocketChannel klijent = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        if(buff == null){

                            buff = ByteBuffer.allocate(1024);
                            key.attach(buff);
                        }

                        klijent.read(buff);

                        String mozdaKraj = new String(buff.array());

                        if(mozdaKraj.contains("\r\n\r\n")){
                            
                            

                            String xyr = mozdaKraj.substring(0, mozdaKraj.indexOf('\r'));

                            int x = Integer.parseInt(xyr.substring(0, xyr.indexOf(' ')));

                            xyr = xyr.substring(xyr.indexOf(' ') +1 );

                            int y = Integer.parseInt(xyr.substring(0, xyr.indexOf(' ')));

                            int r = Integer.parseInt(xyr.substring(xyr.indexOf(' ') + 1));
                            
                            popuniMapu(x, y, r);

                            this.procenat = (1.0 * popunjeno) / (m * n);

                            buff.rewind();
                            buff.put(Double.toString(this.procenat).getBytes());
                            buff.put((byte)'\r');
                            buff.put((byte)'\n');
                            buff.flip();

                            key.interestOps(SelectionKey.OP_WRITE);

                        }

                    }else if(key.isWritable()){

                        SocketChannel klijent = (SocketChannel) key.channel();

                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        if(!buff.hasRemaining()){

                            String poslato = new String(buff.array());
                            poslato = poslato.substring(0, poslato.indexOf('\r'));
                            if(!poslato.equalsIgnoreCase(Double.toString(this.procenat))){

                                buff.rewind();
                                buff.put(Double.toString(this.procenat).getBytes());
                                buff.put((byte)'\r');
                                buff.put((byte)'\n');
                                buff.flip();
                                klijent.write(buff);
                            }

                        }else{

                            klijent.write(buff);
                        }



                        if(this.popunjeno == this.m * this.n)
                            klijent.close();
                    }
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void popuniMapu(int x, int y, int r) {



        for(int i = x - r; i < x + r; i ++){
            if(i < 0 || i >= m)
                continue;
            for(int j = y - r; j < y + r; j ++){

                if(j < 0 || j >= n)
                    continue;

                if(mapa[i][j] == 0){

                    mapa[i][j] = 1;
                    popunjeno++;
                }
            }
        }
    }
}

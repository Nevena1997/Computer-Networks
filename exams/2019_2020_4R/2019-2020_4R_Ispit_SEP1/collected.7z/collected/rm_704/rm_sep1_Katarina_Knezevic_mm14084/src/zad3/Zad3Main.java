package zad3;
import java.io.*;
import java.util.HashMap;
import java.util.Scanner;
public class Zad3Main {

    public static void main(String[] args) {
        System.out.println("glhf from Zad3Main");

        // Ucitavanje putanje do fajla sa standardnog ulaza:
        Scanner scanner = new Scanner(System.in);
        String putanja = scanner.nextLine();

        // Zatvaramo skener jer nam nije vise potreban
        scanner.close();

        // Broj linija u proizvoljnom fajlu:
        String putanjaFajla = "terrain.txt";

        try( BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(putanjaFajla)));
             Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(putanjaFajla))))){

            String linija = null;
            int brojLinija = 0;
            while((linija = br.readLine()) != null){
                brojLinija = brojLinija + 1;
            }
            System.out.println(putanjaFajla + " " + brojLinija);

            // Struktura za evidenciju o broju pojavljivanja reci - hash mapa (cuva uredjene parove (rec, broj pojavljivanja))
            HashMap<String, Integer> evidencija = new HashMap<String, Integer>();

            // Citanje fajla i azuriranje strukture:
            String word = null; // rec
            while(sc.hasNext()){
                word = sc.next(); // ucitavamo novu rec
                if(!evidencija.containsKey(word)) // proveravamo da li je u evidenciji
                    evidencija.put(word, 1); // ako nije, stavvljamo je u evidenciju i belezimo jedno pojavljivanje
                else {
                    int prev = evidencija.get(word); // ako jeste, uzimamo prethodnu vrednost pojavljjivanja
                    prev = prev + 1; // uvecavamo prethodnu vrednost za jedan jer smo ponovo naisli na rec
                    evidencija.remove(word, prev + 1); // postavljamo novu vrednost za dati kljuc
                }

            }

        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }


    }



}

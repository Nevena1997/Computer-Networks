package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("Klijent pokrenut!");
        try(DatagramSocket client = new DatagramSocket();
        Scanner scanner = new Scanner(System.in)){

            // Ucitavamo lokaciju klijenta sa standardnog ulaza, tj. njegove x i y koordinate
            int x = scanner.nextInt();
            int y = scanner.nextInt();

            // Pravimo nizove bajtova za slanje i saljemo ih
            String strX = String.valueOf(x);
            byte[] bytesX = strX.getBytes();
            DatagramPacket dpX = new DatagramPacket(bytesX, bytesX.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(dpX);
            String strY = String.valueOf(y);
            byte[] bytesY = strY.getBytes();
            DatagramPacket dpY = new DatagramPacket(bytesY, bytesY.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(dpY);

            // primamo paket sa informacijom o pokrivenosti lokacije na terenu
            byte[] pokrivenost = new byte[2048];
            DatagramPacket prijem = new DatagramPacket(pokrivenost, 2048);
            client.receive(prijem);

            // Odgovor servera ispisujemo na standardni izlaz
            String odgovor = new String(pokrivenost, 0, prijem.getLength());
            System.out.println(pokrivenost);


        }catch(SocketException e){
            e.printStackTrace();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;
public class TerrainScanner {
    public static void main(String[] args) {

        System.out.println("glhf from TerrainScanner");

        try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Hub.PORT));
            Scanner scanner = new Scanner(System.in)){

            // baferi za slanje i primanje podataka
            ByteBuffer bufferX = ByteBuffer.allocate(2048);
            ByteBuffer bufferY = ByteBuffer.allocate(2048);
            ByteBuffer bufferR = ByteBuffer.allocate(2048);
            ByteBuffer buffer = ByteBuffer.allocate(2048);
            int x, y, r;

            // ucitavanje koordinata sa standardnog ulaza
            x = scanner.nextInt();
            y = scanner.nextInt();
            r = scanner.nextInt();

            // priprema bafera i slanje koordinate x serveru
            bufferX.putInt(x);
            bufferX.flip();
            client.write(bufferX);

            // priprema bafera i slanje koordinate y serveru
            bufferY.putInt(y);
            bufferY.flip();
            client.write(bufferY);

            // priprema bafera i slanje radijusa r serveru
            bufferR.putInt(r);
            bufferR.flip();
            client.write(bufferR);

            // citanje i ispis odgovora servera
            while (true) {

                // priprema bafera
                buffer.clear();

                // citanje
                client.read(buffer);

                // ispis
                System.out.println(buffer.getInt());
            }

        }catch(IOException ioe){
            ioe.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;


public class Hub {

    // atribut klase Hub, koji predstavlja port servera
    public static int PORT = 7337;

    public static void main(String[] args) {

        System.out.println("glhf from Hub");

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();
            Scanner scanner = new Scanner(System.in)){

            // ako nije uspelo otvaranje servera ili selectora, izlazimo iz programa
            if(!server.isOpen() || !selector.isOpen())
                System.exit(1);

            // povezivanje na port
            server.bind(new InetSocketAddress(PORT));

            // podesavamo da bude neblokirajuci
            server.configureBlocking(false);

            // registracija servera
            server.register(selector, SelectionKey.OP_ACCEPT);

            // unosenje velicine terena
            int m = scanner.nextInt();
            int n = scanner.nextInt();

            while(true){

                // selektor vrsi selekciju klijenata
                selector.select();
                // iterator kroz set kljuceva
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                // prolazimo kroz set kljuceva
                while(iterator.hasNext()){

                    // uzimamo tekuci kljuc za obradu, a zatim ga izbacujemo iz seta jer nema vise nije potreban
                    SelectionKey trenutniKljuc = iterator.next();
                    iterator.remove();

                    if(trenutniKljuc.isAcceptable()){

                        // prihvatanje klijenata od strane servera
                        ServerSocketChannel serverKanal = (ServerSocketChannel) trenutniKljuc.channel();
                        SocketChannel client = serverKanal.accept();
                        client.configureBlocking(false);
                        //registracija klijenta
                        client.register(selector, SelectionKey.OP_READ);

                    }else if(trenutniKljuc.isReadable()){

                        // hab prima podatke od skenera (klijenta)
                        SocketChannel client = (SocketChannel) trenutniKljuc.channel();
                        ByteBuffer buff = ByteBuffer.allocate(2048);

                        trenutniKljuc.interestOps(SelectionKey.OP_WRITE);
                    }else if(trenutniKljuc.isWritable()){

                        SocketChannel client = (SocketChannel) trenutniKljuc.channel();
                        ByteBuffer buffer = (ByteBuffer)trenutniKljuc.attachment();
                        if(buffer.hasRemaining())
                            client.write(buffer);
                        else
                            client.close();
                        trenutniKljuc.interestOps(SelectionKey.OP_READ);

                    }

                }
            }

        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
}

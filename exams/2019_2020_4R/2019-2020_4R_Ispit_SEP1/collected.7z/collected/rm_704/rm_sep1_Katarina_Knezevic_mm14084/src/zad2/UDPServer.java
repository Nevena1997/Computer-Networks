package zad2;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Scanner;


public class UDPServer {

    public static int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("glhf from UDPServer");

        try(DatagramSocket server = new DatagramSocket(PORT);
            Scanner scanner = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("terrain.txt"))))){

            // ucitavamo podatke o terenu iz fajla terrain.txt

            String teren = scanner.nextLine();
            int m = Integer.valueOf(teren.substring(0, 1));
            int n = Integer.valueOf(teren.substring(2, 3));

            teren = scanner.nextLine();
            int x1 = Integer.valueOf(teren.substring(0, 1));
            int y1 = Integer.valueOf(teren.substring(2, 3));
            int r1 = Integer.valueOf(teren.substring(4, 5));

            teren = scanner.nextLine();
            int x2 = Integer.valueOf(teren.substring(0, 1));
            int y2 = Integer.valueOf(teren.substring(2, 3));
            int r2 = Integer.valueOf(teren.substring(4, 5));

            teren = scanner.nextLine();
            int x3 = Integer.valueOf(teren.substring(0, 1));
            int y3 = Integer.valueOf(teren.substring(2, 3));
            int r3 = Integer.valueOf(teren.substring(4, 5));

            System.out.println("terrain.txt ucitan!");

            while(true){

                // server osluskuje i prihvata klijente
                byte primljeniBajtoviX[] = new byte[2048];
                byte primljeniBajtoviY[] = new byte[2048];
                DatagramPacket paketPrijemX = new DatagramPacket(primljeniBajtoviX, 2048);
                server.receive(paketPrijemX);
                DatagramPacket paketPrijemY = new DatagramPacket(primljeniBajtoviY, 2048);
                server.receive(paketPrijemY);
                System.out.println("Stigao datagram!");


                // x i y koordinate poslate od klijenta
                String strX = new String(primljeniBajtoviX, 0, paketPrijemX.getLength());
                int x = Integer.valueOf(strX);
                String strY = new String(primljeniBajtoviY, 0, paketPrijemY.getLength());
                int y = Integer.valueOf(strY);

                // indikator pokrivenosti
                int pokrivenost = 0;

                // treba proveriti da li se tacka x i y nalazi u nekom od kvadrata na terenu, na osnovu podataka iz fajla

                if(((x <= x1 + r1 && x >= x1 - r1 && y <= y1 + r1 && y >= y1 - r1)|| (x <= x2 + r2 && x >= x2 - r2 && y <= y2 + r2 && y >= y2 - r2) || (x <= x3 + r3 && x >= x3 - r3 && y <= y3 + r3 && y >= y3 - r3)) && x < m && y < n && x > 0 && y > 0)
                    pokrivenost = 1;

                String p = null;

                // odgovarajuci string kojji se salje klijentu kao odgovor
                if(pokrivenost == 0)
                    p = "Nije Pokriven!";
                else
                    p = "Pokriven!";

                // pretvaramo string u niz bajtova kako bismo spakovali informaciju i poslali
                byte[] pokrivenaLokacija = p.getBytes();
                DatagramPacket paketSlanje = new DatagramPacket(pokrivenaLokacija, pokrivenaLokacija.length, paketPrijemX.getAddress(), paketPrijemX.getPort());
                // slanje odgovora
                server.send(paketSlanje);

            }


        }catch(SocketException e){
            e.printStackTrace();
        }catch(FileNotFoundException fnfe){
                fnfe.printStackTrace();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
}

package zad2;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("glhf from UDPClient");
    }
}

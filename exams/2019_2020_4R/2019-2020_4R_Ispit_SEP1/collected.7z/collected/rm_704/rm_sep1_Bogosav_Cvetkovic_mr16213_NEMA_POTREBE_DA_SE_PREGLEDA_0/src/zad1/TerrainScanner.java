package zad1;

public class TerrainScanner {
    public static void main(String[] args) {
        System.out.println("glhf from TerrainScanner");
    }
}

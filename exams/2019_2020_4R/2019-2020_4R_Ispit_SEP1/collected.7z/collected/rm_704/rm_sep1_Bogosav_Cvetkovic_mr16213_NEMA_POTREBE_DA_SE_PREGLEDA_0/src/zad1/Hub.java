package zad1;

public class Hub {
    public static void main(String[] args) {
        System.out.println("glhf from Hub");
    }
}

package zad3;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class WordFinder extends Thread {

    public static Map<String, Integer> mapa;
    private String dir;

    public WordFinder(String dir){

        this.dir = dir;
    }
    Path path = FileSystems.getDefault().getPath(dir);
    @Override
    public void run(){

        try(BufferedReader br = Files.newBufferedReader(path,StandardCharsets.UTF_8)){
        synchronized (mapa){


            for(File f:p){

            }

        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

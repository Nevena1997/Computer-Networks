package zad2;

import java.util.ArrayList;
import java.util.List;

public class Field {
    int width;
    int height;
    List<Skener> lista;

    public Field(int width, int height) {
        this.width = width;
        this.height = height;
        this.lista = new ArrayList<>();
    }
}

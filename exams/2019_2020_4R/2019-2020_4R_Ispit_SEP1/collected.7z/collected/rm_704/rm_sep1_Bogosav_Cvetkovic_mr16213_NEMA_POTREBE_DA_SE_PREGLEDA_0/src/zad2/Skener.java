package zad2;

public class Skener {
    int x;
    int y;
    int radius;

    public Skener(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    boolean pripada(int a,int b){
        if(x+radius>a && x-radius<a && y+radius>b && y-radius<b)
            return true;
        else
            return false;
    }
}

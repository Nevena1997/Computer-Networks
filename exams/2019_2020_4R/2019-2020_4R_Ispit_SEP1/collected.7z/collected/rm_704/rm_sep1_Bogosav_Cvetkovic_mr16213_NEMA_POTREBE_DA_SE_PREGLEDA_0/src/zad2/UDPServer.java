package zad2;

import java.io.*;
import java.net.*;

public class UDPServer {

    public static int PORT = 12345;

    public static void main(String[] args) {
        System.out.println("glhf from UDPServer");

        try(DatagramSocket server = new DatagramSocket();
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("terrain.txt")));
        ){
            String linija =  in.readLine();
            linija.
            server.bind(new InetSocketAddress(PORT));

            while(true){

                byte[] recive_buff = new byte[1024];
                DatagramPacket recive = new DatagramPacket(recive_buff,0,1024);
                server.receive(recive);
                String recived_message = recive.getData().toString();


            }

        }catch (SocketException | FileNotFoundException e){
            e.printStackTrace();}
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

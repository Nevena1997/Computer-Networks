package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    public static final int PORT = 7337;
    public static final String HOST = "localhost";
    public static final int SIZE_OF_BUF_INT = 12;
    public static final int SIZE_OF_BUF_DOUBLE = 8;

    private int n;
    private int m;

    public Hub(int n, int m) {
        this.n = n;
        this.m = m;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        sc.close();

        Hub hub = new Hub(n, m);
        hub.execute();

    }

    private void execute() {

        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            Selector selector = Selector.open()) {

            serverSocketChannel.bind(new InetSocketAddress(PORT));
            serverSocketChannel.configureBlocking(false);

            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true) {

                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                while (it.hasNext()) {
                    SelectionKey key = it.next();
                    it.remove();

                    try {

                        if (key.isAcceptable()) {
                            acceptNewClient(key, selector);
                        } else if (key.isReadable()) {
                            readFromClient(key);
                        } else if (key.isWritable()) {
                            writeToClient(key);
                        }
                    } catch (IOException e) {
                        // this is the problem with only one client so Server will ignore it
                        // and will cancel this client
                        cancelClient(key);
                    }
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void acceptNewClient(SelectionKey key, Selector selector) throws IOException {
        ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();

        SocketChannel socketChannel = serverSocketChannel.accept();

        socketChannel.configureBlocking(false);
        SelectionKey clientKey = socketChannel.register(selector, SelectionKey.OP_READ);

        Attachment att = new Attachment();
        clientKey.attach(att);
    }

    private void readFromClient(SelectionKey key) throws IOException {
        SocketChannel channel = (SocketChannel) key.channel();
        Attachment att = (Attachment) key.attachment();

        channel.read(att.bufferInt);

        if(!att.bufferInt.hasRemaining()) {
            // sva tri broja je procitao i zavrsio je sa citanjem

            att.bufferInt.rewind();
            int x = att.bufferInt.getInt();
            int y = att.bufferInt.getInt();
            int r = att.bufferInt.getInt();

            // TODO provera da li su korektni x y r

            key.interestOps(SelectionKey.OP_WRITE);
        }

    }

    private void writeToClient(SelectionKey key) throws IOException {
        SocketChannel channel = (SocketChannel) key.channel();
        Attachment att = (Attachment) key.attachment();

        if (!att.bufferDouble.hasRemaining()) {
            if (!fillBufferDouble(att))
                return; // necemo da saljemo jer nije proslo 5 sec
        }

        att.bufferDouble.rewind();
        channel.write(att.bufferDouble);

    }

    private boolean fillBufferDouble(Attachment att) {
        Date prevDate = att.getPreviousSendingTime();

        double perc;
        if (prevDate == null) {
            perc =  calculatePercentage();
        } else if (prevDate.getTime() - new Date().getTime() < 5000) {
            // jos nije proslo 5 sekundi
            return false;
        } else
            perc =  calculatePercentage();

        att.bufferDouble.clear();
        att.bufferDouble.putDouble(perc);
        att.previousSendingTime = new Date();

        return true;
    }

    private double calculatePercentage() {
        // TODO
        return 0;
    }

    private void cancelClient(SelectionKey key) {

        SocketChannel sc = (SocketChannel) key.channel();
        key.cancel();
        try {
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private class Attachment {

        private Date previousSendingTime;
        private ByteBuffer bufferInt;
        private ByteBuffer bufferDouble;


        public Attachment() {
            this.previousSendingTime = null;
            this.bufferInt = ByteBuffer.allocate(SIZE_OF_BUF_INT);
            this.bufferDouble = ByteBuffer.allocate(SIZE_OF_BUF_DOUBLE);
        }

        public ByteBuffer getBufferDouble() {
            return bufferDouble;
        }

        public void setBufferDouble(ByteBuffer bufferDouble) {
            this.bufferDouble = bufferDouble;
        }

        public Date getPreviousSendingTime() {
            return previousSendingTime;
        }

        public void setPreviousSendingTime(Date previousSendingTime) {
            this.previousSendingTime = previousSendingTime;
        }

        public ByteBuffer getBufferInt() {
            return bufferInt;
        }

        public void setBufferInt(ByteBuffer buffer) {
            this.bufferInt = buffer;
        }
    }

}

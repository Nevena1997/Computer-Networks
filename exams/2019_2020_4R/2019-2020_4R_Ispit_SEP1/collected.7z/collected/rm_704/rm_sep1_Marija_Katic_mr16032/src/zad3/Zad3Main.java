package zad3;

import java.io.*;
import java.util.*;

public class Zad3Main {

    private Map<String, Integer> mapWords;
    private List<ProcessTxtFile> threads;

    public Zad3Main() {
        this.mapWords = new HashMap<>();
        this.threads = new ArrayList<>();
    }

    public static void main(String[] args) {

        Zad3Main zad3Main = new Zad3Main();
        zad3Main.execute();


    }

    private void execute() {
        Scanner sc = new Scanner(System.in);
        String pathname = sc.next();
        sc.close();

        File dir = new File(pathname);
        traverse(dir);

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        for (String word : mapWords.keySet()) {
            System.out.println(word + ": " + mapWords.get(word));
        }

    }

    private void traverse(File dir) {
        File[] files = dir.listFiles();
        for (File file : files) {
            if (file.isFile()) {
                file.getName().endsWith(".txt");
                System.out.println(file.getAbsolutePath());
                System.out.println(countLines(file));

                ProcessTxtFile thread = new ProcessTxtFile(file);
                thread.start();
                threads.add(thread);

            } else if (file.isDirectory()) {
                traverse(file);
            }
        }
    }

    private int countLines(File file) {
        try (BufferedReader bf = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
            int countlines = 0;
            while(bf.readLine() != null) {
                countlines++;
            }
            return countlines;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }


    private class ProcessTxtFile extends Thread {

        File file;

        public ProcessTxtFile(File file) {
            this.file = file;
        }

        @Override
        public void run() {

            try (BufferedReader bf = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
                String line = null;
                while((line = bf.readLine()) != null) {
                    String[] words = line.trim().split(" ");

                    for(String word : words) {
                        synchronized (mapWords) {
                            Integer count = mapWords.get(word);
                            mapWords.put(word, count == null ? 1 : count + 1);
                        }
                    }

                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}

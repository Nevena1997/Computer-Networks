package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class UDPServer {

    public static final int BUF_SIZE = 128;

    public static final int PORT = 12345;
    public static final String HOST = "localhost";

    private int n;
    private int m;
    private List<int[]> scanners;


    public UDPServer() {
        this.scanners = new ArrayList<>();
    }

    public static void main(String[] args) {
        UDPServer udpServer = new UDPServer();
        udpServer.execute();
    }

    private void execute() {

        File file = new File("/home/ispit/Desktop/rm_sep1_Marija_Katic_mr16032/terrain.txt");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
             DatagramSocket socket = new DatagramSocket(PORT);) {

            System.out.println("Server pokrenut!");

            fillData(br);

            while (true) {
                try {
                    byte[] buf = new byte[BUF_SIZE];
                    DatagramPacket datagramPacket = new DatagramPacket(buf, buf.length);
                    socket.receive(datagramPacket);
                    System.out.println("Stigao datagram");

                    buf = datagramPacket.getData();
                    String str = new String(buf, 0, datagramPacket.getLength(), "ASCII");

//                    System.out.println(str);

                    String[] coordinates = str.trim().split(" ");
                    InetAddress addr = datagramPacket.getAddress();
                    int port = datagramPacket.getPort();

                    if (coordinatesAreIn(Integer.parseInt(coordinates[0]), Integer.parseInt(coordinates[0]))) {
                        sendMsg("da", addr, port, socket);
                    } else {
                        sendMsg("ne", addr, port, socket);
                    }
                } catch (Exception e) {
                    // problem with only one client. ignore!
                }
            }
        } catch(FileNotFoundException e){
            e.printStackTrace();
        } catch(IOException e){
            e.printStackTrace();
        }

    }

    private void fillData(BufferedReader br) throws IOException{

        String line = null;
        line = br.readLine();
        String[] numbers = line.trim().split(" ");
        n = Integer.parseInt(numbers[0]);
        m = Integer.parseInt(numbers[1]);

        while ((line = br.readLine()) != null) {
            numbers = line.trim().split(" ");
            int[] ar = new int[3];
            ar[0] = Integer.parseInt(numbers[0]);
            ar[1] = Integer.parseInt(numbers[1]);
            ar[2] = Integer.parseInt(numbers[2]);
            this.scanners.add(ar);
        }

    }

    private void sendMsg(String msg, InetAddress addr, int port, DatagramSocket socket) throws IOException {
        byte[] buffer = msg.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, 0, buffer.length, addr, port);
        socket.send(packet);
    }


    private boolean coordinatesAreIn(int x, int y) {
        // TODO
        return true;
    }
}

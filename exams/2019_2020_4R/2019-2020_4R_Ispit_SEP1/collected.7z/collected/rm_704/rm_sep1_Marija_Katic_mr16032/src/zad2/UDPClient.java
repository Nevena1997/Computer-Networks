package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {

    public static final int BUF_SIZE = 128;


    public static void main(String[] args) {


        byte[] buf;

//        String coordinates = "1 2";
        // ocekuje se format "x y"
        Scanner sc = new Scanner(System.in);
        String coordinates = sc.nextLine().trim();

        buf = coordinates.getBytes();

        DatagramPacket datagramPacket = new DatagramPacket(buf, 0, buf.length,
                new InetSocketAddress(UDPServer.HOST, UDPServer.PORT));

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.send(datagramPacket);

            byte[] buffer = new byte[BUF_SIZE];
            DatagramPacket packetForRecieve = new DatagramPacket(buffer, buffer.length);

            socket.receive(packetForRecieve);
            System.out.println("Odg stigao");

            buf = packetForRecieve.getData();



            String answer = new String(buf, 0, packetForRecieve.getLength(), "ASCII");

            if (answer.equalsIgnoreCase("da")) {
                System.out.println("Pokriven!");
            } else if (answer.equalsIgnoreCase("ne")) {
                System.out.println("Nije pokriven!");
            } else
                System.out.println("GRESKA. Nerazuman odgovor od Servera");


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

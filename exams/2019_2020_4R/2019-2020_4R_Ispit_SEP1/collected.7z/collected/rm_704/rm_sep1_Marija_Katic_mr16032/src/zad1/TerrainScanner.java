package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {

    public static final int SIZE_OF_BUF = 16;

    private int x;
    private int y;
    private int r;

    public TerrainScanner(int x, int y, int r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        int r = sc.nextInt();
        sc.close();

        TerrainScanner terrainScanner = new TerrainScanner(x, y, r);
        terrainScanner.execute();

    }

    private void execute() {

        try (SocketChannel socketChannel = SocketChannel.open()) {

            socketChannel.connect(new InetSocketAddress(Hub.HOST, Hub.PORT));

            ByteBuffer buf = ByteBuffer.allocate(SIZE_OF_BUF);

            buf.clear();
            buf.putInt(x);
            buf.putInt(y);
            buf.putInt(r);

            buf.flip();
            socketChannel.write(buf);

            buf.clear();

            ByteBuffer bufForRead = ByteBuffer.allocate(8);

            // get the stats
            while (true) {
                socketChannel.read(bufForRead);
//                System.out.println("something read");
                if (!bufForRead.hasRemaining()) {
//                    System.out.println("has remaining");
                    bufForRead.rewind();
                    Double percentage = bufForRead.getDouble();
                    System.out.println(percentage);
                    bufForRead.clear();
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad3;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.*;
import java.util.stream.Stream;

public class Zad3Main {

    public static Map<String,Integer> reci;

    public static void main(String[] args) {

        System.out.println("glhf from Zad3Main");

        Scanner sc=new Scanner(System.in);

        String putanja=sc.next();
        try {


        Stream<Path> putanje=Files.walk(Path.of("/home/ispit/proba"));

        Iterator<Path> p=putanje.iterator();
            System.out.println("Ispis "+p.next());

            Vector<String>  putanje_zapisane=new Vector<>();
            putanje_zapisane.add("/home/ispit/proba/nesto.txt");
            putanje_zapisane.add("/home/ispit/proba/1.txt");

            for(String s:putanje_zapisane){
                Thread nit=new Moja_nit(s,reci);
                nit.start();
            }


        }catch (IOException e){
            e.printStackTrace();
        }
    }

}

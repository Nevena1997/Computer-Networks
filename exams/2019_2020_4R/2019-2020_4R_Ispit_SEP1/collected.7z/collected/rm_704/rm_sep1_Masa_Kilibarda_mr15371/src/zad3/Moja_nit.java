package zad3;

import java.util.Map;

public class Moja_nit extends Thread {

    private String putanja;
    private Map<String,Integer> reci;

    public Moja_nit(String putanja,Map<String,Integer> reci){
        this.putanja=putanja;

    }



    @Override
    public void run() {

    }
}

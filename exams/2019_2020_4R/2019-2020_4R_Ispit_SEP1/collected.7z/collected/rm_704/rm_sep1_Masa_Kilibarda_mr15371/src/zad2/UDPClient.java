package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("glhf from UDPClient");

        try(DatagramSocket klijent=new DatagramSocket();
            Scanner sc=new Scanner(System.in)
        ){

            int x,y;
            x=sc.nextInt();
            y=sc.nextInt();

            StringBuilder poruka=new StringBuilder();
            poruka.append(x).append(" ").append(y);


            DatagramPacket za_slanje=new DatagramPacket(poruka.toString().getBytes(),poruka.length(),new InetSocketAddress("localhost",12345));

            klijent.send(za_slanje);

            //cekamo odgovor servera


            DatagramPacket za_prijem=new DatagramPacket(new byte[2024],2024);
            klijent.receive(za_prijem);

            String stiglo=new String(za_prijem.getData(),0,za_prijem.getLength());
            System.out.println(stiglo);


        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

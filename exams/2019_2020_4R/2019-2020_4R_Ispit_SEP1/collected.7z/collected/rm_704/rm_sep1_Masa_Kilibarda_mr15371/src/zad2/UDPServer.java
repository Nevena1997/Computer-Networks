package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class UDPServer {

    private int m,n;
    private Map<Vector<Integer>,Integer> pokrivenost;

    public static void main(String[] args) {

        System.out.println("glhf from UDPServer");

        int n=-1,m=-1;
        Map<Vector<Integer>,Integer> pok=new HashMap<>();

        try {
            Scanner in=new Scanner(new InputStreamReader(new FileInputStream("terrain.txt")));

            String str=in.nextLine();
            String[] mn=str.split(" ");
            m=Integer.parseInt(mn[0]);
            n=Integer.parseInt(mn[1]);

            while(in.hasNext()){
                String s=in.nextLine();

                String[] brojevi=s.split(" ");
                Vector<Integer> koord=new Vector<>();
                koord.add(Integer.parseInt(brojevi[0]));
                koord.add(Integer.parseInt(brojevi[1]));
                pok.put(koord,Integer.parseInt(brojevi[2]));
            }

        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

       /* System.out.println("Ucitali smo :  Nase m i n su"+m+" "+n);

        for(Vector<Integer> el:pok.keySet()){
            System.out.println(el.get(0)+"  "+el.get(1)+"  "+pok.get(el));
        }*/

        UDPServer server=new UDPServer(m,n,pok);


        server.execute();

    }

    public UDPServer(int m,int n,Map<Vector<Integer>,Integer> pokrivenost){
        this.m=m;
        this.n=n;
        this.pokrivenost=pokrivenost;
    }

    private void execute(){
        try(DatagramSocket server=new DatagramSocket(12345)
        ){
            while (true){
                DatagramPacket za_prijem=new DatagramPacket(new byte[1024],1024);
                server.receive(za_prijem);

                String primili=new String(za_prijem.getData(),0,za_prijem.getLength());
                System.out.println("Pimio sam od klijenta "+primili);
                if(proveri_pokrivenost(primili)){

                    String odg=new String("Pokriven");
                    DatagramPacket za_slanje=new DatagramPacket(odg.getBytes(),odg.length(),za_prijem.getAddress(),za_prijem.getPort());
                    server.send(za_slanje);
                }
                else{
                    String odg=new String("Nije pokriven");
                    DatagramPacket za_slanje=new DatagramPacket(odg.getBytes(),odg.length(),za_prijem.getAddress(),za_prijem.getPort());
                    server.send(za_slanje);
                }

            }


        }catch (IOException e){
            e.printStackTrace();
        }
    }


    private boolean proveri_pokrivenost(String s){
       String[] x_y=s.split(" ");
       int x=Integer.parseInt(x_y[0]);
       int y=Integer.parseInt(x_y[1]);

       int a,b,r;


        for(Vector<Integer> el:pokrivenost.keySet()){
            a=el.get(0);
            b=el.get(1);
            r=pokrivenost.get(el);
            if(Math.abs(Math.sqrt(Math.pow(x-a,2)+Math.pow(y-b,2)))<r)
                return true;

        }

        return false;
    }
}

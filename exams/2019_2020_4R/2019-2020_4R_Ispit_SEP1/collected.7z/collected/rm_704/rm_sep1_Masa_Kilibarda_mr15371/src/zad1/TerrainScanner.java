package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner {
    public static void main(String[] args) {
        System.out.println("glhf from TerrainScanner");
        try(SocketChannel klijent=SocketChannel.open(new InetSocketAddress("localhost",7337));
            Scanner sc=new Scanner(System.in)
        ){
            ByteBuffer buff=ByteBuffer.allocate(100);

            int x,y,r;



            while(true){
                x=sc.nextInt();
                y=sc.nextInt();
                r=sc.nextInt();

                buff.rewind();

                buff.putInt(x);
                buff.putInt(y);
                buff.putInt(r);

                buff.flip();
                klijent.write(buff);

                //cekamo odgovor servera

                buff.clear();
                klijent.read(buff);
                buff.rewind();
                System.out.println("Trenutna pokrivenost je "+buff.getDouble());

            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}

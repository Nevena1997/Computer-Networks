package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    private int m,n;

    public static void main(String[] args) {

        System.out.println("glhf from Hub");

        Scanner sc =new Scanner(System.in);

        int m,n;
        m=sc.nextInt();
        n=sc.nextInt();

        Hub server=new Hub(m,n);
        server.execute();

    }

    public Hub(int m,int n){
        this.m=m;
        this.n=n;
    }

    private void execute(){

        try(ServerSocketChannel server=ServerSocketChannel.open();
            Selector selector=Selector.open()
        ){

            if(!selector.isOpen() || !server.isOpen()){
                System.err.println("Server ili selektor nisu otovreni,prekidamo program");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(7337));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);


            while(true){
                selector.select();

                Iterator<SelectionKey> kljucevi=selector.selectedKeys().iterator();

                while(kljucevi.hasNext()){
                    SelectionKey kljuc=kljucevi.next();
                    kljucevi.remove();

                    if(kljuc.isAcceptable()){
                        ServerSocketChannel serverCH=(ServerSocketChannel) kljuc.channel();
                        SocketChannel klijent=serverCH.accept();

                        System.out.println("Prihvatio kljuc");

                        klijent.configureBlocking(false);

                        klijent.register(selector,SelectionKey.OP_READ);

                    }if (kljuc.isReadable()){
                        System.out.println("Usao da cita");
                        SocketChannel klijent=(SocketChannel) kljuc.channel();
                        ByteBuffer buff=(ByteBuffer) kljuc.attachment();

                        if(buff==null){
                            buff=ByteBuffer.allocate(100);
                            kljuc.attach(buff);
                        }


                        buff.clear();
                        klijent.read(buff);
                        buff.rewind();

                        int x=buff.getInt(),y=buff.getInt(),z=buff.getInt();
                                System.out.println("Od servera stiglo "+x+" "+y+" "+z);

                        double pokrivenost=izracunaj_pokrivenost(x,y,z);

                        buff.rewind();
                        buff.putDouble(pokrivenost);
                        kljuc.attach(buff);

                        kljuc.interestOps(SelectionKey.OP_WRITE);
                    }if(kljuc.isWritable()){
                        System.out.println("Usao da pise");
                        SocketChannel klijent=(SocketChannel) kljuc.channel();
                        ByteBuffer buff=(ByteBuffer) kljuc.attachment();

                        buff.flip();
                        klijent.write(buff);

                        System.out.println("Ispisao");

                        kljuc.interestOps(SelectionKey.OP_READ);
                    }


                }

            }


        }catch (IOException e){
            e.printStackTrace();
        }
    }

    private double izracunaj_pokrivenost(int x,int y,int r){
        //TO DO...

        double p=100;

        if(x==0 || y==0 || x==this.m || y==this.n)
            p-=2*r*r;
        else if((x+r<m) && (y+r<n))
            p-=4*r*r;


        return p;
    }


}

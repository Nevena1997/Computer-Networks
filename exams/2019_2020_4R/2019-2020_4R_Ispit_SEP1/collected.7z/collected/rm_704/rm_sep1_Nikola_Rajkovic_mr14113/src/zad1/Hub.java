package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

public class Hub {

    public static int PORT=7337;

    public static void main(String[] args) {

        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()
        ) {

            Scanner sc = new Scanner(System.in);
            int m = sc.nextInt();
            int n = sc.nextInt();
            sc.close();

            int[][] matrica_tacke = new int[m + 1][n + 1];
            int[][] matrica_kvadrati = new int[m][n];

            for (int i = 0; i <= m; i++) {
                for (int j = 0; j <= n; j++) {
                    matrica_tacke[i][j] = 0;
                }
            }

            for(int i=0; i<m; i++) {
                for(int j=0; j<n; j++) {
                    matrica_kvadrati[i][j]=0;
                }
            }

            int ukupno=m*n;
            int pokrivenih=0;
            double procenat=0;

            if (!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("Doslo je do greske kod otvaranja selektora ili servera");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {
                selector.select();
                Iterator<SelectionKey> it=selector.selectedKeys().iterator();

                SelectionKey key=it.next();
                it.remove();

                try {
                    if(key.isAcceptable()) {
                        ServerSocketChannel server= (ServerSocketChannel) key.channel();
                        SocketChannel client=server.accept();

                        client.configureBlocking(true);
                        SelectionKey clientKey=client.register(selector, SelectionKey.OP_READ);

                        ByteBuffer buff=ByteBuffer.allocate(3);

                        clientKey.attach(buff);

                    } else if(key.isReadable()) {

                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buff = (ByteBuffer) key.attachment();

                        int x = buff.getInt();
                        int y = buff.getInt();
                        int r = buff.getInt();

                        for (int i = x - r; i <= x + r; i++) {
                            for (int j = y - r; j <= y + r; j++) {
                                if (i < 0 || j < 0)
                                    continue;
                                matrica_tacke[i][j] = 1;
                            }
                        }

                        for (int i = 0; i < m; i++) {
                            for (int j = 0; j < n; j++) {
                                if (matrica_tacke[i][j] == 1 && matrica_tacke[i + 1][j] == 1 && matrica_tacke[i][j + 1] == 1 && matrica_tacke[i + 1][j + 1] == 1) {
                                    if (matrica_kvadrati[i][j] == 0) {
                                        matrica_kvadrati[i][j] = 1;
                                        pokrivenih += 1;
                                        procenat = (1.0) * pokrivenih / ukupno;
                                    }
                                }
                            }
                        }

                        buff.rewind();
                        buff.clear();

                        client.configureBlocking(true);
                        SelectionKey clientKey = client.register(selector, SelectionKey.OP_WRITE);
                        clientKey.attach(buff);

                    } else if(key.isWritable()) {
                        SocketChannel client= (SocketChannel) key.channel();
                        ByteBuffer buff= (ByteBuffer) key.attachment();
                        



                    }



                } catch (IOException e) {
                    e.printStackTrace();
                }



            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

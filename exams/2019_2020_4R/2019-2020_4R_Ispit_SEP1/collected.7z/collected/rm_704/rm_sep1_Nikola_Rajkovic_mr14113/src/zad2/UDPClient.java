package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try(DatagramSocket klijent=new DatagramSocket();
            Scanner sc=new Scanner(System.in)
        ) {

            System.out.println("Klijent pokrenut!");

            StringBuilder builder=new StringBuilder();

            builder.append(sc.nextByte());
            builder.append("&");
            builder.append(sc.nextByte());

            //System.out.println(builder.toString());

            byte[] niz=builder.toString().getBytes();
            DatagramPacket paket_za_slanje=new DatagramPacket(niz, niz.length, InetAddress.getLocalHost(), UDPServer.PORT);
            klijent.send(paket_za_slanje);

            //ceka odgovor

            byte[] niz1=new byte[256];
            DatagramPacket paket_za_prijem=new DatagramPacket(niz1, 256);
            klijent.receive(paket_za_prijem);
            String poruka=new String(niz1, 0, paket_za_prijem.getLength());

            if(poruka.trim().equalsIgnoreCase("da"))
                System.out.println("Pokriven!");
            else if(poruka.trim().equalsIgnoreCase("ne"))
                System.out.println("Nije pokriven!");
            else
                System.err.println("Greska!");


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Scanner;

public class UDPServer {

    public static int PORT=12345;

    public static void main(String[] args) {

            try(DatagramSocket server=new DatagramSocket(PORT);
                Scanner sc=new Scanner(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/rm_sep1_Nikola_Rajkovic_mr14113/terrain.txt")))
            ) {
                System.out.println("terrain.txt ucitan!");

                System.out.println("Server pokrenut!");

                int m=sc.nextInt();
                int n=sc.nextInt();

                int[][] matrica=new int[m+1][n+1];
                for(int i=0; i<=m; i++)
                    for(int j=0; j<=n; j++)
                        matrica[i][j]=0;
                sc.nextLine();
                while(sc.hasNext()) {
                    int x = sc.nextInt();
                    int y = sc.nextInt();
                    int r = sc.nextInt();
                    sc.nextLine();
                    for(int i=x-r; i<=x+r; i++) {
                        for (int j = y - r; j <= y + r; j++) {
                            if(i<0||j<0)
                                continue;
                            matrica[i][j]=1;
                        }
                    }
                }

                while(true) {

                    byte[] niz=new byte[256];
                    DatagramPacket paket_za_prijem=new DatagramPacket(niz, 256);
                    server.receive(paket_za_prijem);

                    System.out.println("Stigao datagram!");

                    String poruka=new String(niz, 0, paket_za_prijem.getLength());
                    String xs=poruka.substring(0, poruka.indexOf('&'));
                    String ys=poruka.substring(poruka.indexOf('&')+1);

                    int x=Integer.parseInt(xs);
                    int y=Integer.parseInt(ys);

                    String message="ne";
                    try {
                        if(matrica[x][y]==1)
                            message="da";
                    } catch (ArrayIndexOutOfBoundsException e) {
                        message="ne";
                    }

                    byte[] odgovor=message.getBytes();
                    DatagramPacket paket_za_slanje=new DatagramPacket(odgovor, odgovor.length, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                    server.send(paket_za_slanje);

                }


            } catch (SocketException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

    }
}

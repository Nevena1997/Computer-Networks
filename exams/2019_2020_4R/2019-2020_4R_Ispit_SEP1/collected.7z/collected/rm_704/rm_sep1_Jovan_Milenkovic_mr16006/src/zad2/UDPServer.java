package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class UDPServer {
    public static final int PORT = 12345;
    public static final int SIZE = 128;


    public static void main(String[] args) {
        // read contents of terrain.txt
        String pathToData = "/home/ispit/Desktop/rm_sep1_Jovan_Milenkovic_mr16006/terrain.txt";
        List<Integer> x_list = new ArrayList<>();
        List<Integer> y_list = new ArrayList<>();
        List<Integer> r_list = new ArrayList<>();
        int m, n; // m is horizontal

        DatagramSocket serverSocket = null;
        try {
            List<String> lines = Files.readAllLines(Paths.get(pathToData));
            System.out.println("terrain.txt scanned!");

            String[] firstLine = lines.get(0).trim().split(" ");
            m = Integer.valueOf(firstLine[0]);
            n = Integer.valueOf(firstLine[1]);

            for (int i = 1; i < lines.size(); i++) {
                String[] tokens = lines.get(i).trim().split(" ");
                x_list.add(Integer.valueOf(tokens[0]));
                y_list.add(Integer.valueOf(tokens[1]));
                r_list.add(Integer.valueOf(tokens[2]));
            }
            System.out.println("Registered " + x_list.size() + " radio stations!");

            serverSocket = new DatagramSocket(PORT);
            System.out.println("UDP Server started!");

            DatagramPacket packet = new DatagramPacket(new byte[SIZE], SIZE);


            // serve clients
            while (true) {
                serverSocket.receive(packet); // recieve a client request

                int clientX = readIntFromBuff(packet.getData(), 0);
                int clientY = readIntFromBuff(packet.getData(), 4);
                System.out.println("Datagram packet received!");
                System.out.println("Client location: " + clientX + " " + clientY);


                boolean answer = false;
                for(int i = 0; i < x_list.size(); i++){
                    int x = x_list.get(i);
                    int y = y_list.get(i);
                    int r = r_list.get(i);

                    if(Math.abs(clientX - x) <= r && Math.abs(clientY - y) <= r){
                        answer = true;
                        break;
                    }
                }

                if(answer)
                    packet.getData()[0] = (byte) 1;
                else
                    packet.getData()[0] = (byte) 0;

                // reply to client
                serverSocket.send(packet);
            }
        } catch (IOException e) {
            System.err.println("[ERROR] Couldn't read terrain.txt");
            e.printStackTrace();
        } finally {
            if(serverSocket != null){
                serverSocket.close();
            }
        }
        // System.out.println("glhf from UDPServer");
    }


    public static int readIntFromBuff(byte[] buff, int offset) {
        int x = 0;

        x = x + buff[3 + offset];
        x *= 256;

        x = x + buff[2 + offset];
        x *= 256;

        x = x + buff[1 + offset];
        x *= 256;

        x = x + buff[0 + offset];

        return x;
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Hub { // SERVER
    public static final int PORT = 7337;
    private static final int CAPACITY = 12;
    private static final long TIME_DIFF = 3 * 1000;

    // Map client addresses to their x, y and r
    private static Map<String, Integer> clientX = new TreeMap<>();
    private static Map<String, Integer> clientY = new TreeMap<>();
    private static Map<String, Integer> clientR = new TreeMap<>();

    // Map client addresses to the last time client has been updated with coverage info
    private static Map<String , Long> timeSinceUpdate = new TreeMap<>();

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
             ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open()){

            System.out.println("Insert dimensions of terrain:");

            int m = sc.nextInt();
            int n = sc.nextInt();



            if(!serverChannel.isOpen() || !selector.isOpen()){
                System.err.println("[ERROR] Failed to open server channel and selector");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            System.out.println("[INFO] Started Hub server!");

            // process client requests
            while (true){
                selector.select();

                Iterator<SelectionKey> selectedKeys = selector.selectedKeys().iterator();

                while(selectedKeys.hasNext()){
                    SelectionKey key = selectedKeys.next();
                    selectedKeys.remove();

                    selector.selectedKeys().remove(key);
                    try {
                        if(key.isAcceptable()){
                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();
                            client.configureBlocking(false);

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ | SelectionKey.OP_WRITE);
                            ByteBuffer buffer = ByteBuffer.allocate(CAPACITY);
                            clientKey.attach(buffer);

                            System.out.println("Accepted new client from " + client.getRemoteAddress());
                        } else if(key.isReadable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            buffer.clear();
                            if(client.read(buffer) == -1) { // expected to read 3 integers = 12 bytes of data
                                removeClient(key);
                                continue;
                            }

                            if(buffer.position() == 12) { // read 3 integers
                                buffer.flip();
                                int x = buffer.getInt();
                                int y = buffer.getInt();
                                int r = buffer.getInt();
                                String clientAddress = client.getRemoteAddress().toString();
                                clientX.put(clientAddress, x);
                                clientY.put(clientAddress, y);
                                clientR.put(clientAddress, r);

                                buffer.clear(); // resets position to 0
                                System.out.println("Client " + clientAddress + " x, y and r: " + x + " " + y + " " + r);
                            }
                        } else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();
                            String clientAddress = client.getRemoteAddress().toString();

                            if(!timeSinceUpdate.containsKey(clientAddress))
                                timeSinceUpdate.put(clientAddress, System.currentTimeMillis());

                            if(Math.abs(timeSinceUpdate.get(clientAddress) - System.currentTimeMillis()) >= TIME_DIFF){ // check whether 5 seconds have passed
                                timeSinceUpdate.put(clientAddress, System.currentTimeMillis());

                                // this indicates that client has registered
                                if(clientX.containsKey(clientAddress)){
                                    buffer.clear();
                                    System.out.println("COVERAGE = " + getCoverage(m, n));
                                    buffer.putDouble(getCoverage(m, n));
                                    buffer.flip();

                                    client.write(buffer);
                                    System.out.println("Sent info to client " + clientAddress);
                                }
                            }
                        }
                    } catch (IOException e){
                        e.printStackTrace();
                        removeClient(key);
                    }
                }
            }




        } catch (IOException e){
            System.err.println("[ERROR] IOError occurred. Details:");
            e.printStackTrace();
        }
        // System.out.println("glhf from Hub");
    }

    private static void removeClient(SelectionKey key) {
        if(key.channel() instanceof SocketChannel){
            try {
                String clientAddress = ((SocketChannel) key.channel()).getRemoteAddress().toString();
                clientX.remove(clientAddress);
                clientY.remove(clientAddress);
                clientR.remove(clientAddress);

                System.out.println("Client " + clientAddress + " disconnected");
            } catch (IOException e){
                System.err.println("[INFO] IOError occurred. Details:");
                e.printStackTrace();
            }
        }

        key.cancel();
        try {
            key.channel().close();
        } catch (IOException e){
            // Ignore
        }
    }

    private static double getCoverage(int m, int n){
        boolean[][] covered = new boolean[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++){
                covered[i][j] = false;
            }
        }

        for(String clientAddress : clientX.keySet()){
            int x = clientX.get(clientAddress);
            int y = clientY.get(clientAddress);
            int r = clientR.get(clientAddress);

            for(int i = -r; i < r; i++){ // i < r because i count how many bottom left corners have been covered
                for (int j = -r; j < r; j++){
                    if(x + i >= 0 && x +1 < m && y + j >= 0 && y + j < n)
                        covered[x+i][y+j] = true;
                }
            }
        }

        int count = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++){
                if (covered[i][j])
                    count++;
            }
        }
        return 1.0*count / (m * n);
    }
}

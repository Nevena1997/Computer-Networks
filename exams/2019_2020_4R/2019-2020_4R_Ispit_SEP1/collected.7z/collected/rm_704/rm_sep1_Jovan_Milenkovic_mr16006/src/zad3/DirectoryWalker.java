package zad3;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class DirectoryWalker implements Runnable {
    public static final String END = "";
    private BlockingQueue<String> queue;
    private Path dirPath;

public DirectoryWalker(BlockingQueue<String> queue, Path dirPath) {
        this.queue = queue;
        this.dirPath = dirPath;
    }

    @Override
    public void run() {
        walk(dirPath);

        boolean succeeded = false;
        while(!succeeded){
            try {
                this.queue.put(END);
                succeeded = true;
            } catch (InterruptedException e) {
                //Ignore e.printStackTrace();
            }
        }
    }

    private void walk(Path dirPath) {
        try {
            DirectoryStream<Path> dirStrm = Files.newDirectoryStream(dirPath);

            for(Path p : dirStrm){
                if(Files.isRegularFile(p)) {
                    if(!p.toString().endsWith(".txt"))
                        continue; // skibidi non .txt files

                    boolean succeeded = false;
                    while (!succeeded) {
                        try {
                            this.queue.put(p.toString());
                            succeeded = true;
                        } catch (InterruptedException e) {
                            //Ignore e.printStackTrace();
                        }
                    }
                } else if(Files.isDirectory(p)){
                    this.walk(p);
                }
            }
        } catch (IOException e){
            System.err.println("[ERROR] Error occurred when trying to open/process directory. Details:");
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class TerrainScanner { // CLIENT
    private static final int CAPACITY = 128; // more than enough

    public static void main(String[] args) {


        try (Scanner sc = new Scanner(System.in);
             SocketChannel clientChannel = SocketChannel.open(new InetSocketAddress("localhost", Hub.PORT))) {
            clientChannel.configureBlocking(true);

            ByteBuffer buffer = ByteBuffer.allocate(CAPACITY);


            System.out.print("Input your location and radius of coverage (r): ");
            int x = sc.nextInt();
            int y = sc.nextInt();
            int r = sc.nextInt();

            buffer.clear();
            buffer.putInt(x);
            buffer.putInt(y);
            buffer.putInt(r);
            buffer.flip();

            clientChannel.write(buffer); // blocks until everything from "position" to "limit" has been written
            buffer.clear();

            // enter reading phase
            while (true) {
                clientChannel.read(buffer); // blocks until at least one byte has been read

                //if (buffer.position() >= 8) { // there is enough data for one double
                    buffer.rewind();
                    double coverage = buffer.getDouble();
                    buffer.clear(); // translate everything by 8 positions (overwrites first 8 bytes)

                    System.out.printf("Coverage: %.2f%%\n", coverage * 100);
                //}
            }
        } catch (IOException e) {
            System.err.println("[ERROR] IOError. Details: ");
            e.printStackTrace();
        }
        // System.out.println("glhf from TerrainScanner");
    }


}

package zad3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;

public class FileWordCounter implements  Runnable{
    private BlockingQueue<String> queue;
    private Map<String, Integer> wordCount;

    public FileWordCounter(BlockingQueue<String> queue, Map<String, Integer> wordCount) {
        this.queue = queue;
        this.wordCount = wordCount;
    }

    @Override
    public void run() {
        while (true){
            String filePath = DirectoryWalker.END;

            // take a file from queue
            boolean succeeded = false;
            while(!succeeded){
                try {
                    filePath = queue.take();
                    succeeded = true;
                } catch (InterruptedException e) {
                    //Ignore e.printStackTrace();
                }
            }

            // if there are no more files to process
            if(filePath.equalsIgnoreCase(DirectoryWalker.END)){
                succeeded = false;
                while(!succeeded){
                    try {
                        queue.put(DirectoryWalker.END);
                        succeeded = true;
                    } catch (InterruptedException e) {
                        //Ignore e.printStackTrace();
                    }
                }

                break;
            }

            // process the file
            try {
                List<String> lines = Files.readAllLines(Paths.get(filePath));
                synchronized (System.out){
                    System.out.println(filePath + " " + lines.size());
                }

                // process each line of file
                for(String line : lines){
                    String[] words = line.trim().split("[ \t\n,.!;]");
                    for(String word : words){
                        // update statistics
                        word = word.toLowerCase(); // ignore case
                        if(word.equalsIgnoreCase(""))
                            continue;

                        synchronized (this.wordCount){
                            if (!this.wordCount.containsKey(word)){ // new word
                                this.wordCount.put(word, 1);
                            } else {
                                int count = this.wordCount.get(word);
                                this.wordCount.put(word, count + 1);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

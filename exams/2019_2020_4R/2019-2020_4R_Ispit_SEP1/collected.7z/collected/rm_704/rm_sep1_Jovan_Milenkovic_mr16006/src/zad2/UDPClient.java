package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)){
            System.out.println("Client started!");
            System.out.print("> ");

            int x = sc.nextInt();
            int y = sc.nextInt();

            DatagramSocket clientSocket = null;
            try {
                clientSocket = new DatagramSocket();

                DatagramPacket packet = new DatagramPacket(new byte[UDPServer.SIZE], UDPServer.SIZE, new InetSocketAddress("localhost", UDPServer.PORT));

                writeToBuff(packet.getData(), 0, x);
                writeToBuff(packet.getData(), 4, y);

                // send server your x and y coordinates
                clientSocket.send(packet);

                // server replies
                clientSocket.receive(packet);

                if(packet.getData()[0] == ((byte) 0))
                    System.out.println("Nije pokriven!");
                else
                    System.out.println("Pokriven!");

            } catch (SocketException e){
                System.err.println("[ERROR] Couldn't establish connection");
            } catch (IOException e){
                System.err.println("[ERROR] Error while communicating with server");
            } finally {
                if(clientSocket != null)
                    clientSocket.close();
            }
        }
        // System.out.println("glhf from UDPClient");
    }

    private static void writeToBuff(byte[] buff, int offset, int value){
        buff[0 + offset] = (byte) (value % 256);
        value /= 256;

        buff[1 + offset] = (byte) (value % 256);
        value /= 256;

        buff[2 + offset] = (byte) (value % 256);
        value /= 256;

        buff[3 + offset] = (byte) (value % 256);
    }
}

package zad3;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad3Main {
    public static final int CAPACITY = 20;
    public static final int THREAD_COUNT = 20;

    public static void main(String[] args) {
        Map<String, Integer> wordCount = new TreeMap<>(); // shared data structure
        BlockingQueue<String> queue = new ArrayBlockingQueue<>(CAPACITY);
        Path dirPath;
        Thread[] threads = new Thread[THREAD_COUNT];


        try(Scanner sc = new Scanner(System.in)) {
            String line = sc.nextLine(); // read path to directory
            dirPath = Paths.get(line);


            new Thread(new DirectoryWalker(queue, dirPath)).start();
            for (int i = 0; i < THREAD_COUNT; i++){
                threads[i] = new Thread(new FileWordCounter(queue, wordCount));
                threads[i].start();
            }

            for (int i = 0; i < THREAD_COUNT; i++){
                try {
                    threads[i].join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // sort keys
            List<Map.Entry<String, Integer>> listOfSorted = new ArrayList<Map.Entry<String, Integer>>(wordCount.entrySet());
            Collections.sort(listOfSorted, new Comparator<Map.Entry<String, Integer>>() {
                @Override
                public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                    if(o1.getValue() < o2.getValue())
                        return 1;
                    else if (o1.getValue() > o2.getValue())
                        return  -1;
                    else
                        return 0;
                }
            });

            // print out statistics
            for(Map.Entry<String, Integer> entry : listOfSorted){
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }


        }

        // System.out.println("glhf from Zad3Main");
    }
}

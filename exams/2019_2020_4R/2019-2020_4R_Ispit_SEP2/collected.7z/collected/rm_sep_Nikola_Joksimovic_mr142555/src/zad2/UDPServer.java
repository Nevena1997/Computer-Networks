package zad2;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;


public class UDPServer {

    public static int port = 12345;

    private static Map<String,Float> mapa_racuna;

    public UDPServer(Map<String,Float> mapa_racuna){

        this.mapa_racuna = mapa_racuna;
    }

    public static void main(String[] args) {

        Map<String,Float> mapa_racuna = null;
        UDPServer Serverserver;
        Serverserver = new UDPServer(mapa_racuna);

        try(DatagramSocket server = new DatagramSocket(port)) {


                byte[] bufer = new byte[4];
                DatagramPacket primi = new DatagramPacket(bufer, bufer.length);


            while (true) {

                server.receive(primi);
                String racun = bufer.toString().substring(0,primi.getLength());

                if(mapa_racuna.containsKey(racun)){
                    System.err.println("-1");
                }
                else{
                    // treba jos doraditi

                    float inzos_racuna = mapa_racuna.get(racun);
                    String slati = Float.toString(inzos_racuna);
                    bufer = slati.getBytes();

                    DatagramPacket posalji = new DatagramPacket(bufer, bufer.length, primi.getAddress(),primi.getPort());
                }


                try (Scanner sc = new Scanner(System.in)){

                    System.out.println("Unesi br racuna i iznos za dodavaje");

                    String _racun = sc.nextLine();
                    float _iznos = sc.nextFloat();

                    new Thread(new UnosThread(mapa_racuna, _racun, _iznos)).start();

                }


            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        System.out.println("UDPServer");
    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args){
        System.out.println("UDPServer");

        try(DatagramSocket klijent = new DatagramSocket();
            Scanner sc = new Scanner(System.in)){

            byte[] bufer;

            String f = sc.nextLine();
            bufer = f.getBytes();

            DatagramPacket salji = new DatagramPacket(bufer, bufer.length, InetAddress.getByName("localhost"), UDPServer.port);
            klijent.send(salji);

            DatagramPacket prihvati = new DatagramPacket(bufer, bufer.length);
            klijent.receive(prihvati);



            System.out.println(Float.valueOf(bufer.toString()));

        } catch (SocketException e) {
            e.printStackTrace();
            System.err.println("Nije uspostavljena veza sa Serverom");
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.err.println("Nije dobro ime hosta");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

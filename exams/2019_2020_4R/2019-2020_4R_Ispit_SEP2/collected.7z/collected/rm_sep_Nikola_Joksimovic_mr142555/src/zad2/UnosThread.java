package zad2;

import java.util.Map;

public class UnosThread extends Thread {

    static Map<String, Float> mapa;
    static String  _racun;
    static float _iznos;

    public UnosThread(Map<String, Float> mapa,String _racun, float _iznos){

        this.mapa = mapa;
        this._racun = _racun;
        this._iznos = _iznos;

    }

    @Override
    public void run() {

        this.mapa.put(_racun, _iznos);
    }
}

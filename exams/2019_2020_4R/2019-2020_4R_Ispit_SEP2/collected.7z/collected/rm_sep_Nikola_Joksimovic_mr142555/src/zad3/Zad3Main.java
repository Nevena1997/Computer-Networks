package zad3;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad3Main {

    private static int MAX_BROJ_NINI;
    private static int MAX_BROJ_OBRADA = 10;


    public static void main(String[] args) {


        Date start = new Date();
        long start_time = start.getTime();

        int n = 0;
        String element;


        Queue<Float> queue = new PriorityQueue<Float>();

        try(Scanner sc = new Scanner(System.in)){

            String ime_fajla = sc.nextLine();

            try(Scanner fp = new Scanner(Paths.get("/home/ispit/Desktop/rm_sep_Nikola_Joksimovic_mr142555/src/zad3/elementi.txt"))){

                while(fp.hasNext()){
                    element = fp.next();
                    float f = Float.valueOf(element);
                    queue.add(f);
                    n++;
                }
                System.out.println("Broj elemenata je:" + n);


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Date end = new Date();
        long end_time = end.getTime();




        System.out.println("Vreme izvrsavanja:");
        System.out.println(end_time - start_time + "milisecond(s)");
    }
}

package zad1;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");
    }
}

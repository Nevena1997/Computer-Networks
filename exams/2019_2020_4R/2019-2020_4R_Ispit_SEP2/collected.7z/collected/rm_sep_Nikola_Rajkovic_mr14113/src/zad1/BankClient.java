package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) throws IOException {

        try(SocketChannel client=SocketChannel.open(new InetSocketAddress("localhost", BankServer.PORT));
            Scanner sc=new Scanner(System.in)) {

            String korisnik=sc.nextLine();

            ByteBuffer buffer= ByteBuffer.allocate(4000);

            buffer.clear();
            buffer.put(korisnik.getBytes());

            client.write(buffer);

            client.read(buffer);

            String poruka=buffer.toString();
            String[] poruke=poruka.split("\n");

            for(int i=0; i<poruke.length; i++)
                System.out.println(poruke[i]);

            String izbor=sc.nextLine();
            int broj=sc.nextInt();

            buffer.clear();
            buffer.put(korisnik.getBytes());
            buffer.put(Byte.parseByte(" "));
            buffer.put(izbor.getBytes());
            buffer.put(Byte.parseByte(" "));
            buffer.putInt(broj);
            buffer.flip();

            client.write(buffer);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class BankServer {

    public static final int PORT= 12221;

    public static void main(String[] args) {

        Map<String, SocketChannel> mapa=new HashMap<>();

        try(ServerSocketChannel serverChannel=ServerSocketChannel.open();
            Selector selector= Selector.open()) {

            if(!serverChannel.isOpen()||!selector.isOpen()) {
                System.err.println("Selektor ili Server socket channel nije uspeo da se otvori");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(PORT));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true) {
                selector.select();
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();

                try {
                    while (it.hasNext()) {
                        SelectionKey key = it.next();
                        it.remove();

                        if (key.isAcceptable()) {

                            ServerSocketChannel server = (ServerSocketChannel) key.channel();
                            SocketChannel client = server.accept();

                            SelectionKey clientKey = client.register(selector, SelectionKey.OP_READ);

                            ByteBuffer buffer = ByteBuffer.allocate(4000);
                            clientKey.attach(buffer);

                        } else if (key.isReadable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            buffer.clear();
                            client.read(buffer);
                            String klijent=buffer.toString();

                            if(mapa.containsKey(klijent)) {

                                String[] par=klijent.split(" ");
                                String uplata=par[0];
                                String isplata=par[1];
                                int novac=Integer.parseInt(par[2]);



                            }

                            mapa.put(klijent, client);

                            buffer.clear();
                            buffer.put(klijent.getBytes());
                            buffer.flip();

                            SelectionKey clientKey=client.register(selector, SelectionKey.OP_WRITE);
                            clientKey.attach(buffer);

                        } else if(key.isWritable()) {

                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            String ime=buffer.toString();

                            Set<String> racuni = mapa.keySet();
                            Iterator<String> iter = racuni.iterator();

                            while(iter.hasNext()) {
                                buffer.clear();
                                String rac = iter.next();

                                if(rac==ime)
                                    continue;

                                buffer.put(rac.getBytes());
                                buffer.put((byte) '\n');
                                buffer.flip();

                                client.write(buffer);
                            }

                            SelectionKey clientKey=client.register(selector, SelectionKey.OP_READ);
                            clientKey.attach(buffer);

                        }

                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

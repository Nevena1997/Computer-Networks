package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Map;

public class SlanjeIPrimanjeDatagrama implements Runnable {

    private Map<String, Integer> mapa;

    public SlanjeIPrimanjeDatagrama(Map<String, Integer> mapa) {

        this.mapa=mapa;
    }

    @Override
    public void run() {
        try(DatagramSocket server=new DatagramSocket(UDPServer.PORT)){
            while(true) {
                try {
                    byte[] buf = new byte[4000];
                    DatagramPacket paket_za_prijem = new DatagramPacket(buf, buf.length);
                    server.receive(paket_za_prijem);

                    String racun = new String(buf, 0, paket_za_prijem.getLength());
                    //System.err.println(racun);
                    Integer vrednost;
                    if (mapa.containsKey(racun)) {
                        vrednost = mapa.get(racun);
                    } else {
                        vrednost = -1;
                    }
                    String message = vrednost.toString();

                    byte[] buf1 = message.getBytes();
                    DatagramPacket paket_za_slanje = new DatagramPacket(buf1, buf1.length, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                    server.send(paket_za_slanje);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

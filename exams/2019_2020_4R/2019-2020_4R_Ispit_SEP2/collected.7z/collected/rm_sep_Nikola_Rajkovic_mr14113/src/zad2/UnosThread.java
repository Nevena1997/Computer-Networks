package zad2;

import java.util.Map;
import java.util.Scanner;

public class UnosThread implements Runnable {

    private Map<String, Integer> mapa;

    public UnosThread(Map<String, Integer> mapa) {
        this.mapa=mapa;
    }

    @Override
    public void run() {

        try(Scanner sc=new Scanner(System.in)) {

            while(sc.hasNextLine()) {

                String unos=sc.nextLine();

                String[] racunIVrednost=unos.split(" ");

                String racun=racunIVrednost[0];
                String vrednostS=racunIVrednost[1];
                int vrednost=Integer.parseInt(vrednostS);

                if(mapa.containsKey(racun)) {
                    mapa.replace(racun, vrednost);
                } else {
                    mapa.put(racun, vrednost);
                }
            }
        }
    }
}
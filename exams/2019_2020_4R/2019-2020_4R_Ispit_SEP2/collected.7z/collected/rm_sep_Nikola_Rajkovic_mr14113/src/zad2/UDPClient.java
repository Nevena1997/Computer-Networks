package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        try(DatagramSocket client=new DatagramSocket();
            Scanner sc=new Scanner(System.in)
        ) {

            String unos=sc.nextLine();
            byte[] buf=unos.getBytes();

            DatagramPacket paket_za_slanje=new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), UDPServer.PORT);
            client.send(paket_za_slanje);

            byte[] buf1=new byte[4000];
            DatagramPacket paket_za_prijem=new DatagramPacket(buf, buf.length);
            client.receive(paket_za_prijem);

            String poruka=new String(buf, 0, paket_za_prijem.getLength());
            System.out.println(poruka);


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

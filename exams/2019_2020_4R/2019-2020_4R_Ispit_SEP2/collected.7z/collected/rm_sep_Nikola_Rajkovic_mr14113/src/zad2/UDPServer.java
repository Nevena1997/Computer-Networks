package zad2;
/*
import com.sun.jdi.IntegerValue;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;*/
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static final int PORT=  12345;

    public static void main(String[] args) {

        Map<String, Integer> mapa=new HashMap<>();
        new Thread(new UnosThread(mapa)).start();
        new Thread(new SlanjeIPrimanjeDatagrama(mapa)).start();

        /*try(DatagramSocket server=new DatagramSocket(PORT)) {

            while(true) {

                    byte[] buf=new byte[4000];
                    DatagramPacket paket_za_prijem=new DatagramPacket(buf, buf.length);
                    server.receive(paket_za_prijem);

                    String racun=new String(buf, 0, paket_za_prijem.getLength());
                    //System.err.println(racun);
                    Integer vrednost;
                    if(mapa.containsKey(racun)) {
                        vrednost = mapa.get(racun);
                    } else {
                        vrednost = -1;
                    }
                    String message=vrednost.toString();

                    byte[] buf1 = message.getBytes();
                    DatagramPacket paket_za_slanje=new DatagramPacket(buf1, buf1.length, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                    server.send(paket_za_slanje);


            }
        } catch (SocketException e) {
            e.printStackTrace();
        }*/
    }
}
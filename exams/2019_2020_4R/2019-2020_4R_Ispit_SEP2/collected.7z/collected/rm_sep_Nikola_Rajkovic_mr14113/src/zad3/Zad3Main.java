package zad3;

public class Zad3Main {
    public static void main(String[] args) {
        
    }
}

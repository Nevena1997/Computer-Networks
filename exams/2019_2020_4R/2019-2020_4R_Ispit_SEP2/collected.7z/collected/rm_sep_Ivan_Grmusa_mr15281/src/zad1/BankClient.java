package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {

        System.out.println("BankClient");
        try(Socket client = new Socket("localhost",BankServer.port);
            PrintWriter out = new PrintWriter(client.getOutputStream());
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(client.getInputStream())
            );
            Scanner sc = new Scanner(System.in)) {
            while (true){
                System.out.println("Unesite broj Vaseg racuna");
                int brojRacuna = sc.nextInt();
                out.print(brojRacuna);
                out.print("\r\n\r\n");
                out.flush();


                System.out.println("Moguci racuni na koje mozete posallati novac");

                while (in.readLine()!=null)
                    System.out.println(in.readLine());

                System.out.println("Unesite racun na koji zelite da unesete novac");
                int primalac = sc.nextInt();
                out.print(primalac);
                out.print(" ");
                System.out.println("Koji iznos zelite da posaljete");
                double iznos = sc.nextDouble();
                out.print(iznos);
                out.print("\r\n\r\n");
                out.flush();





            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

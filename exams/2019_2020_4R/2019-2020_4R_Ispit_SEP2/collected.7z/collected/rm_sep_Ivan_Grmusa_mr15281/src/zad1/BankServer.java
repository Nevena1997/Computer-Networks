package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;

public class BankServer {
    public static  int port =12221;
    private  List<Integer> racuni ;
    public static void main(String[] args) throws IOException {
        BankServer server = new BankServer();
        server.pokreni();
    }

    public BankServer(){
        this.racuni = new ArrayList<>();
    }

    private void pokreni() {
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){
            if (!selector.isOpen() || ! server.isOpen()){
                System.err.println("Neuspesno otvaranje selektora ili servera");
                System.exit(1);
            }
            server.bind(new InetSocketAddress(port));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true){
                selector.select();
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                while (iterator.hasNext()){
                    SelectionKey key = iterator.next();
                    iterator.remove();
                    if (key.isAcceptable()){
                        ServerSocketChannel serverskiKanal = (ServerSocketChannel) key.channel();
                        SocketChannel client = serverskiKanal.accept();
                        client.configureBlocking(false);
                        client.register(selector,SelectionKey.OP_READ);

                    } else  if( key.isReadable()){
                        SocketChannel client =(SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();
                        if (buffer==null){
                            buffer = ByteBuffer.allocate(1024);
                            key.attach(buffer);
                        }
                        client.configureBlocking(false);

                        String linija = String.valueOf(client.read(buffer));
                        if (linija.trim().matches("[0-9]+.*")){
                            // samo su uneti brojevi, pa bi trebalo da je to racun samo
                            // jer se za transakciju unosi  brojRacuna iznos
                            int racun = Integer.parseInt(linija);
                            this.racuni.add(racun);
                            // treba da spremimo za ispis ovog clienta
                            spremiBuffer1(buffer,racuni);
                            key.interestOps(SelectionKey.OP_WRITE);
                        }
                        else if(linija.trim().matches("[0-9]+ [0-9]+.*")){
                            String[] unos = linija.split(" ");
                            int racun = Integer.parseInt(unos[0].trim());
                            double iznos = Double.parseDouble(unos[1].trim());
                            System.out.println("Primljen iznos od broja racuna");
                            key.interestOps(SelectionKey.OP_READ);
                            // ne saljemo odgovor ovom clientu
                        }




                    } else  if (key.isWritable()){
                        SocketChannel client = (SocketChannel) key.channel();
                        ByteBuffer buffer = (ByteBuffer) key.attachment();
                        client.configureBlocking(false);
                        System.out.println("radim ovde");
                        if (buffer.hasRemaining())
                            client.write(buffer);
                        buffer.clear();
                        key.interestOps(SelectionKey.OP_READ);

                        System.out.println("radim cak i ovde");
                    }

                }
            }



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private static void spremiBuffer1(ByteBuffer buffer,List<Integer> racuni) {
        Iterator<Integer> iter = racuni.iterator();
        while (iter.hasNext()){
            System.out.println(iter.toString());
            buffer.rewind();
            buffer.put(iter.toString().getBytes());
            buffer.put((byte) '\r');
            buffer.put((byte)'\n');
            iter.next();
        }
        System.out.println("radim ovde");
        buffer.flip();
    }





}

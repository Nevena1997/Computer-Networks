package zad3;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Path;
import java.util.*;

public class Zad3Main {
      public static void main(String[] args) {
        int maxElemenata =15;
        Scanner sc = new Scanner(System.in);
        String file = sc.next();
        System.out.println(file);
        TreeMap<Integer,Integer> brojevi = new TreeMap<Integer, Integer>();
        List<Integer> lista = new ArrayList<>();
        int i =0;
        try (Scanner in = new Scanner(new FileReader(file));
            Scanner in2 = new Scanner(new FileReader(file))){

            while (in.hasNext()){
                Integer broj =Integer.parseInt(in.next());
                lista.add(broj);
                brojevi.put(broj,1);

                i++;


            }
            System.out.println(i);
            int []niz = new int[i];
            int k=0;
            for (Iterator<Integer> it = lista.iterator(); it.hasNext(); ) {
                niz[k]=it.next();
                k++;
            }

                for (int j = 0; j <i ; j++) {
                    new Thread(new PomocnaNit(i,j,niz)).start();
                    brojevi.put(niz[j],j);

                }
                // treba da se ispise iz brojeva, tamo bi trebalo da su sortirani




        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}

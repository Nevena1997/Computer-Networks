package zad3;

import java.util.Scanner;

public class PomocnaNit implements Runnable {
    private  int i;
    private int j;
    private int[] niz;
    public PomocnaNit(int i, int j, int[] niz) {
        this.i=i;;
        this.j=j;
        this.niz=niz;
    }

    @Override
    public void run() {
        int pom=0;
        for (int k = 0; k <j ; k++) {
            if (this.niz[k]<this.niz[j]) {
                pom++;
            }
        }

        synchronized (System.out) {
            System.out.println(pom);
        }
    }
}

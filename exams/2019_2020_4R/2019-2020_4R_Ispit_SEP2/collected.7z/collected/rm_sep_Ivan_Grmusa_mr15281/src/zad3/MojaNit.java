package zad3;

import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

public class MojaNit implements Runnable {
    private  int rbr ;
    private  int broj;
    private  List<Integer> lista;
    private TreeMap<Integer,Integer> brojevi;
    public MojaNit(int i, List<Integer> lista, TreeMap<Integer,Integer>brojevi) {
        this.rbr=i;
        this.lista=lista;
        this.brojevi=brojevi;
    }

    @Override
    public void run() {
        Iterator<Integer> iterator = this.lista.iterator();
        int i=0;
        while (iterator.hasNext()){
            if (i<rbr) {
                i++;
                continue;
            } else {
                int broj = iterator.next();
                break;
            }
        }

        Iterator<Integer> iterator1 = this.lista.iterator();
        i=0;
        int pom=0;
        while (iterator1.hasNext()){

            if (i>=this.rbr){
                synchronized (brojevi){
                    brojevi.put(broj,pom);
                }

                break;
            } else {
                if (iterator1.next()<broj)
                    pom++;
            }
        }
        synchronized (System.out){
            System.out.println(pom);
        }


    }
}

package zad2;

import java.util.Map;
import java.util.Scanner;

public class Nit implements Runnable {
    private Map<Integer,Integer> racuni;
    public Nit(Map<Integer, Integer> racuni) {
        this.racuni=racuni;
    }

    @Override
    public void run() {
        try (Scanner sc = new Scanner(System.in)){


            while (true) {
                int racun = sc.nextInt();
                int stanje = sc.nextInt();
                synchronized (racuni) {
                    if (racuni.containsKey(racun)) {
                        racuni.replace(racun, stanje);
                    } else
                        racuni.put(racun, stanje);
                }
            }

        }

    }
}

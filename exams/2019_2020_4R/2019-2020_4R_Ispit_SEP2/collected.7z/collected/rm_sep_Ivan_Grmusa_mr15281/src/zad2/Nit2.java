package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Map;

public class Nit2 implements Runnable {
    private Map<Integer,Integer> racuni;
    public Nit2(Map<Integer, Integer> racuni) {
        this.racuni=racuni;
    }

    @Override
    public void run() {
        try (DatagramSocket server = new DatagramSocket()){
            while (true){
                byte[] poruka = new byte[32];
                DatagramPacket prijem = new DatagramPacket(poruka,poruka.length);
                server.receive(prijem);

                String racun = prijem.toString();
                System.out.println("radim ovde");
                System.out.println(racun);
                synchronized (racuni){
                    int rac = Integer.parseInt(racun);
                    if (racuni.containsKey(rac)){
                        Integer stanje = racuni.get(rac);
                        byte[] odgovor = stanje.toString().getBytes();
                        DatagramPacket slanje = new DatagramPacket(odgovor,odgovor.length,prijem.getAddress(),prijem.getPort());
                        server.send(slanje);

                    }
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {


    public static void main(String[] args) {
        System.out.println("UDPClient");

        try (DatagramSocket client = new DatagramSocket(UDPServer.port, InetAddress.getLocalHost());
             Scanner sc = new Scanner(System.in)){
            while (true) {
                Integer broj = sc.nextInt();
                byte[] racun = broj.toString().getBytes();

                DatagramPacket slanje = new DatagramPacket(racun, racun.length, InetAddress.getLocalHost(), UDPServer.port);
                client.send(slanje);

                byte[] odg = new byte[32];
                DatagramPacket prijem = new DatagramPacket(odg, odg.length);
                String odgovor = prijem.toString();
                System.out.println(odgovor);


            }
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

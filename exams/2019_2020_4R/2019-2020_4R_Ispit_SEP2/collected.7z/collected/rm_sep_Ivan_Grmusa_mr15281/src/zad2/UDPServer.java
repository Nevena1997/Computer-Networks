package zad2;

import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static int port=12345;
    public static void main(String[] args) {
        Map<Integer,Integer> racuni = new HashMap<>();

        new Thread(new Nit( racuni)).start();
        new Thread(new Nit2(racuni)).start();

        System.out.println("UDPServer");


    }
}

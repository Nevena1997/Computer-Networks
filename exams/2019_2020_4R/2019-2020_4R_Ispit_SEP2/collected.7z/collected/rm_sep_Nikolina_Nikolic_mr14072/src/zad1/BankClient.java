package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketOption;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;
import java.util.Set;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");

        try (SocketChannel klijent =  SocketChannel.open(new InetSocketAddress("localhost", 12221));
             Scanner sc = new Scanner(System.in)) {
            ByteBuffer buf = ByteBuffer.allocate(1024);


            int broj_racuna = sc.nextInt();
            buf.clear();
            buf.putInt(broj_racuna);
            buf.put((byte)'\r');
            buf.put((byte) '\n');
            buf.flip();
            klijent.write(buf);

            buf.clear();
            klijent.read(buf);
            String s = new String(buf.array());
            System.out.println(s.substring(0,s.indexOf('\n')+1));

            buf.clear();
            int broj_racuna_2 = sc.nextInt();
            int iznos = sc.nextInt();
            String s_ = String.valueOf(broj_racuna_2) + " " + String.valueOf(iznos);
            buf.put(s_.getBytes());
            buf.put((byte)'\r');
            buf.put((byte) '\n');
            buf.flip();
            klijent.write(buf);

            buf.clear();
            klijent.read(buf);
            System.out.println(new String(buf.array()));

        }
        catch(IOException e){
            e.printStackTrace();
        }


    }
}

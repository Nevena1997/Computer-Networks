package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BankServer {

    public static Map<Integer, Double> aktivni_racuni = new HashMap<>();


    public static void main(String[] args) {
        System.out.println("BankServer");
        aktivni_racuni.put(1,100.0);
        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()) {
            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Nismo otvorili server ili selektor");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(12221));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while(true){
                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while(iter.hasNext()){
                    SelectionKey trenutniKljuc = iter.next();
                    iter.remove();

                    if(trenutniKljuc.isAcceptable()){
                        ServerSocketChannel server_ = (ServerSocketChannel) trenutniKljuc.channel();
                        SocketChannel klijent = server_.accept();
                        klijent.configureBlocking(false);
                        klijent.register(selector,SelectionKey.OP_READ);
                    }
                    else if(trenutniKljuc.isReadable()){
                        SocketChannel klijent = (SocketChannel) trenutniKljuc.channel();
                        ByteBuffer buf = (ByteBuffer) trenutniKljuc.attachment();
                        if(buf == null){
                            buf = ByteBuffer.allocate(1024);
                        }
                        klijent.read(buf);

                        buf = spisak();
                        trenutniKljuc.attach(buf);
                        trenutniKljuc.interestOps(SelectionKey.OP_WRITE);
                    }
                    else if(trenutniKljuc.isWritable()){
                        SocketChannel klijent = (SocketChannel) trenutniKljuc.channel();
                        ByteBuffer buf = (ByteBuffer) trenutniKljuc.attachment();

                        if(buf.hasRemaining())
                            klijent.write(buf);
                        trenutniKljuc.interestOps(SelectionKey.OP_READ);
                    }
                }

            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    private static ByteBuffer spisak(){
        String s="";
        for(Map.Entry<Integer, Double> p : aktivni_racuni.entrySet()){
            s += p.getKey();
            s += "\r\n";
        }
        byte[] b = new byte[1024];
        b = s.getBytes();
        ByteBuffer buf = ByteBuffer.allocate(1024);
        buf.clear();
        buf.put(b);
        buf.flip();
        return buf;

    }
}

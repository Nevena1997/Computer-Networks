package zad3;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class Zad3Main {
    public static void main(String[] args) {
        Vector<Float> vector = new Vector<Float>();
        Scanner sc = new Scanner(System.in);
            String ime_fajla = sc.nextLine();
            sc.close();
            Scanner f;
            try {
               f  = new Scanner(new FileInputStream(ime_fajla));

                while(f.hasNextFloat()) {
                    vector.add(sc.nextFloat());
                    System.out.println("U petlji sam");
                }
                System.out.println(vector.size());
            }
            catch(IOException e){
                e.printStackTrace();
            }


    }
}///home/ispit/Desktop/rm_sep_Nikolina_Nikolic_mr14072/src/zad3/1.txt

class Nit extends Thread{
    static Vector<Float> v;
    private float f;

    public void run(){


    }
}

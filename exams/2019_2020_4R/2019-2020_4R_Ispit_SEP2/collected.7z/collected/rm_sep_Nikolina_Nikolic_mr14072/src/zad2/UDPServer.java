package zad2;

import javax.swing.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {
    private int port;
    private Map<Integer,Float> aktivni_racuni;

    public UDPServer(int port){
        this.port = port;
        this.aktivni_racuni = new HashMap<>();
    }

    public Map<Integer, Float> getAktivni_racuni() {
        return aktivni_racuni;
    }


    public static void main(String[] args) {
        System.out.println("UDPServer");
        UDPServer server = new UDPServer(12345);
        server.execute();
    }

    private void execute(){
       new Unos(this).start();
       new Slanje_i_Prijem(this).start();

    }
}


 class Unos extends Thread{
    private UDPServer server;

    public Unos(UDPServer server){
        this.server = server;
    }
    public void run(){

            Scanner sc = new Scanner(System.in);
            while (true) {
                int broj_racuna = sc.nextInt();
                if (broj_racuna < 0)
                    break;
                float iznos = sc.nextFloat();
                this.server.getAktivni_racuni().put(broj_racuna, iznos);

            }
        }


        }



        class Slanje_i_Prijem extends  Thread{
    private UDPServer server;

    public Slanje_i_Prijem(UDPServer server){
        this.server = server;
    }

    public void run(){

        try (DatagramSocket server = new DatagramSocket(12345);
             Scanner sc = new Scanner(System.in)) {
            while (true) {

                byte[] niz_za_prijem = new byte[4];
                DatagramPacket paket_za_prijem = new DatagramPacket(niz_za_prijem, 4);
                server.receive(paket_za_prijem);

                int broj_racuna = ByteBuffer.wrap(niz_za_prijem).asIntBuffer().get();
                float d;
                if (this.server.getAktivni_racuni().containsKey(broj_racuna))
                    d = this.server.getAktivni_racuni().get(broj_racuna);
                else
                    d = -1;

                byte[] niz_za_slanje = new byte[8];
                ByteBuffer.wrap(niz_za_slanje).putFloat(d);
                DatagramPacket paket_za_slanje = new DatagramPacket(niz_za_slanje, 8, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
                server.send(paket_za_slanje);

            }
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }


    }


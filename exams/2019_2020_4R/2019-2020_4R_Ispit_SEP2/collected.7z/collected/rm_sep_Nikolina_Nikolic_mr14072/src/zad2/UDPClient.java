package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("UDPClient");
        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            int broj_racuna = sc.nextInt();
            byte[] niz_za_slanje = new byte[4];
            ByteBuffer.wrap(niz_za_slanje).putInt(broj_racuna);
            DatagramPacket paket_za_slanje = new DatagramPacket(niz_za_slanje,4, InetAddress.getLocalHost(),12345);
            klijent.send(paket_za_slanje);

            byte[] niz_za_prijem = new byte[8];
            DatagramPacket paket_za_prijem = new DatagramPacket(niz_za_prijem,8);
            klijent.receive(paket_za_prijem);

            float iznos = ByteBuffer.wrap(niz_za_prijem).asFloatBuffer().get();
            System.out.println(iznos);

        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}

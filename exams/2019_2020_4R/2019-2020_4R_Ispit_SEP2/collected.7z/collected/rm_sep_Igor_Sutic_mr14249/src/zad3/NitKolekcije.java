package zad3;

import java.util.Arrays;
import java.util.List;

public class NitKolekcije extends Thread{

    private float x;
    private int broj_sortirani_el;
    private List<Float> lista;

    public NitKolekcije(float x, List<Float> lista){
        this.x = x;
        this.lista = lista;
        this.broj_sortirani_el = 0;
    }

    @Override
    public void run() {

        this.broj_sortirani_el = 0;
        for(int i = 0; i < this.lista.size(); i++){
            if(this.x >= this.lista.get(i))
                this.broj_sortirani_el++;
        }

    }

    public int getBroj_sortirani_el() {
        return broj_sortirani_el;
    }
}

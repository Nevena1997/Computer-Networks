package zad3;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Zad3Main {
    public static void main(String[] args) {

        // cuvamo broj s
       Map<Float, Integer> struktura = new HashMap<>();

        try(Scanner sc = new Scanner(System.in)){

            // uneli smo ime fajla
            String fileName = sc.next();
            List<Float> lista = new ArrayList<>();

            try{

                Scanner sc1 = new Scanner(Files.newInputStream(Path.of("/home/ispit/Desktop/rm_sep_Igor_Sutic_mr14249/" + fileName)));

                float[] niz_f = new float[0];
                int i = 0;
                while (sc1.hasNext()) {
                    float x = sc1.nextFloat();
                    i++;
                    System.out.println(x);
                    lista.add(x);
                }
                System.out.println("Duzina niza: "+ i);

                for(int j =0 ;j < lista.size(); j++){
                    float broj = lista.get(i);
                    NitKolekcije nit = new NitKolekcije(broj, lista);
                    nit.run();

                    int n = nit.getBroj_sortirani_el();
                    System.out.println(n);

                    struktura.put(broj, n);

                }




            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            for(int k = 0; k < struktura.size(); k++)
                for(int l = 0; l < struktura.size(); l++)
                    if(struktura.get(l) == k)
                        System.out.println(struktura.get(l).toString());

        }
    }
}

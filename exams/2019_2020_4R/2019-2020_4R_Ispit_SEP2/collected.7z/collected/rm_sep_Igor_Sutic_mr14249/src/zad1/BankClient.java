package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args){

        try(Socket client = new Socket("localhost", BankServer.PORT);
            Scanner sc = new Scanner(System.in);
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()))
        ){

            System.out.println("Unesite broj racuna(neophodno je uneti 9 cifara): ");
            String broj_racuna = sc.next();
            broj_racuna += " posaljilac";
            // saljemo serveru nas broj racuna
            out.write(broj_racuna);
            out.flush();

            // citamo sve brojeve racuna, koji se nalaze na serveru
            String line;
            while((line = in.readLine()) != null){
                System.out.println(line);
            }
            //----------------------------------------------------------------------------------

            System.out.println("Unesite broj racuna i iznos koji zelite: ");
            String broj_racuna_1 = sc.next();
            broj_racuna += " primalac";
            int iznos = sc.nextInt();

            // saljemo broj racuna posaljioca i sumu koju zeli
            out.write(broj_racuna_1);
            out.write(iznos);
            out.flush();

            //Sada treba da procitamo poruku od servera

            String poruka_servera;
            while((poruka_servera = in.readLine()) != null){
                // ovde ce nam biti poruke i za primaoca i za posaljioca
                System.out.println(poruka_servera);
            }

            /*
            // primalac
            // sada cekamo da primalac posalje broj racuna i da unese iznos
            try(Socket client_1 = new Socket("localhost", BankServer.PORT);
                Scanner scanner = new Scanner(System.in);
                BufferedWriter out_1 = new BufferedWriter(new OutputStreamWriter(client_1.getOutputStream()));
                BufferedReader in_1 = new BufferedReader(new InputStreamReader(client_1.getInputStream()))
            ){
                System.out.println("Unesite broj racuna i iznos koji zelite: ");
                int broj_racuna_1 = sc.nextInt();
                int iznos = sc.nextInt();

                out_1.write(broj_racuna_1);
                out_1.newLine();
                out_1.write(iznos);
                out_1.flush();

                // sada citamo poruku od servera
                String poruka_servera_1;
                while((poruka_servera_1 = in_1.readLine()) != null)
                    System.out.println(poruka_servera_1);

            }catch (IOException ex){
                ex.printStackTrace();
            }


            // sada treba i posaljilac da procita poruku od servera
            String poruka_servera;
            while((poruka_servera = in.readLine()) != null)
                System.out.println(poruka_servera);
                */

        }
        catch (IOException e){
            e.printStackTrace();
        }


    }
}

package zad1;

import java.io.IOException;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class BankServer {

    public static final int PORT = 12221;

    public static void main(String[] args) throws IOException {

        //treba nam skup za cuvanje racuna
        Set<String> racuni;
        Map<String, Integer> racuni_1;

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open();
        ){

            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Ne mozemo da otvorimo server ili selector!");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);
            racuni = new HashSet<>();

            while(true){

                selector.select();

                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();
                while(iter.hasNext()){

                    SelectionKey key = iter.next();
                    iter.remove();

                    try{

                        if(key.isAcceptable()){

                            ServerSocketChannel server_1 = (ServerSocketChannel) key.channel();
                            SocketChannel client = server_1.accept();
                            System.err.println("Client accepted!");
                        }
                        else if(key.isReadable()){
                            // citamo podatke koje nam salje klijent
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();

                            if(buffer == null){
                                buffer = ByteBuffer.allocate(4096);
                            }

                            buffer.clear();
                            // procitamo poruku od klijenta
                            // moze da bude
                            client.read(buffer);

                            String poruka = new String(buffer.array());

                            if(poruka.contains(" posaljilac")) {
                                // ovde dodajemo racune posaljioca
                                racuni.add(poruka);
                                buffer.put(poruka.getBytes());


                            }
                            else if(poruka.contains(" primalac")){
                                racuni.add(poruka);
                                buffer.put(poruka.getBytes());
                                ByteBuffer ada = ByteBuffer.allocate(1024);
                                client.read(ada);
                                buffer.put(ada);

                            }

                            buffer.flip();
                            key.attach(buffer);

                        }
                        else if(key.isWritable()){
                            SocketChannel client = (SocketChannel) key.channel();
                            ByteBuffer buffer = (ByteBuffer) key.attachment();



                        }

                    }
                    catch (Exception ex){
                        key.channel().close();
                        ex.printStackTrace();
                    }
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}

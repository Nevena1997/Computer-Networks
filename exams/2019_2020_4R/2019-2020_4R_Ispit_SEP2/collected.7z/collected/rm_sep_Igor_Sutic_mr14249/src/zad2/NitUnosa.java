package zad2;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class NitUnosa extends  Thread{

    private Map<String, Float> sadrzaj;

    public NitUnosa(Map<String, Float> mapa){
        this.sadrzaj = new HashMap<>();
    }

    @Override
    public void run() {

        try(Scanner sc = new Scanner(System.in)){

            String br_racuna = sc.next();
            float iznos = sc.nextFloat();

            this.sadrzaj.put(br_racuna, iznos);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public Map<String, Float> getSadrzaj() {
        return sadrzaj;
    }
}

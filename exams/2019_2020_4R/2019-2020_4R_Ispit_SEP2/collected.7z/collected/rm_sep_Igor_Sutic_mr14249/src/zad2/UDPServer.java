package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {

    public static final int PORT = 12345;

    public static void main(String[] args){

        Map<String, Float> mapa = new HashMap<>();
        Map<String, Float> mapa1 = new HashMap<>();
        try(DatagramSocket server = new DatagramSocket(PORT)){

            NitUnosa unos = new NitUnosa(mapa);
            unos.start();

            mapa1 = unos.getSadrzaj();

            readWriteThread nit = new readWriteThread(server, mapa1);
            nit.start();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}

package zad2;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args){

        String host = "localhost";

        try(DatagramSocket client = new DatagramSocket();
            Scanner sc = new Scanner(System.in)
        ){
            System.out.println("Unesite broj racuna: ");
            String broj_racuna = sc.next();

            byte[] buff = broj_racuna.getBytes();

            DatagramPacket requeset = new DatagramPacket(buff, buff.length, InetAddress.getByName(host), UDPServer.PORT);
            client.send(requeset);

            byte[] prijem = new byte[1234];
            DatagramPacket response = new DatagramPacket(prijem, prijem.length);
            client.receive(response);

            String poruka = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);

            System.out.println(poruka);
        }
        catch(SocketException | UnknownHostException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

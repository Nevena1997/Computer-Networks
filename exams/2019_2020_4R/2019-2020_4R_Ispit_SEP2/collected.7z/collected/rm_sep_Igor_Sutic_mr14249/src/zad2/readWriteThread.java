package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class readWriteThread extends  Thread{

    public DatagramSocket server;
    public Map<String, Float> mapa;

    public  readWriteThread(DatagramSocket server, Map<String, Float> map){
        this.server = server;
        this.mapa = map;
    }

    @Override
    public void run() {



        try {
            byte[] buff = new byte[1234];
            DatagramPacket request = new DatagramPacket(buff, buff.length);
            this.server.receive(request);

            String prijem = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);

            if(this.mapa.containsKey(prijem)){
                float iznos = mapa.get(prijem);
                String a = Float.toString(iznos);
                buff = a.getBytes();
            }
            else {
                String a = "-1";
                buff= a.getBytes();

            }

            DatagramPacket response = new DatagramPacket(buff, buff.length, request.getAddress(), request.getPort());
            this.server.send(response);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

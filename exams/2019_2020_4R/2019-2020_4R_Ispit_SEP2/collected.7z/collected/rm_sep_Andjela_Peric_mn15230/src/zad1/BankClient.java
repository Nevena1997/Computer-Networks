package zad1;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
      try (Socket klijent = new Socket(InetAddress.getLocalHost(), BankServer.PORT);
           BufferedReader br = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
           BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
           Scanner sc = new Scanner(System.in)){

          //saljemo serveru broj racuna
          bw.write(35);
          bw.flush();
          //cekamo da nam server vrati brojeve racuna i ispisujemo ih na standardni izlaz
          String line;
          while((line=br.readLine()) != null){
              System.out.println(line);
          }
          //ako korisnik unese broj racuna, saljemo ga serveru uz iznos
          if(sc.hasNextInt()){
              int br_racuna = sc.nextInt();
              int iznos = sc.nextInt();
              bw.write(br_racuna);;
              bw.write(iznos);
              bw.flush();

          }

          System.out.println(br.readLine());




      } catch (UnknownHostException e) {
          e.printStackTrace();
      } catch (IOException e) {
          e.printStackTrace();
      }
    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class BankServer {
    public static int PORT = 12221;

    public static void main(String[] args) {
         try(ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open()){

             if(!server.isOpen() || !selector.isOpen()){
                 System.err.println("Neuspesno otvoren server ili selector.");
                 System.exit(1);
             }
             //server osluskuje na portu
             server.bind(new InetSocketAddress(PORT));
             server.configureBlocking(false);
             server.register(selector, SelectionKey.OP_ACCEPT);

             while(true){
                 selector.select();
                 Iterator<SelectionKey> iter = selector.selectedKeys().iterator();
                 while(iter.hasNext()){
                     SelectionKey trenutniKljuc = iter.next();
                     iter.remove();
                     if(trenutniKljuc.isAcceptable()){
                         //u pitanju je server koji treba da prihvata klijente
                         ServerSocketChannel serverKljuc = (ServerSocketChannel) trenutniKljuc.channel();
                         SocketChannel klijent =  serverKljuc.accept();
                         SelectionKey klijentKljuc = klijent.register(selector, SelectionKey.OP_READ);

                     }
                     else if(trenutniKljuc.isReadable()){
                         ByteBuffer buff = ByteBuffer.allocate(12);
                         buff.clear();
                         if(trenutniKljuc.attachment() == null){
                             trenutniKljuc.attach(buff);
                         }
                         SocketChannel klijent = (SocketChannel) trenutniKljuc.channel();
                         ByteBuffer buff1 = (ByteBuffer) trenutniKljuc.attachment();
                         buff1.clear();
                         klijent.read(buff1);
                         buff1.rewind();
                         int broj_racuna = buff1.getInt();

                         buff1.clear();
                         buff1.putInt(broj_racuna);
                         buff1.putChar('\r');
                         buff1.putChar('\n');
                         buff1.flip();

                         trenutniKljuc.interestOps(SelectionKey.OP_WRITE);


                     }
                     else if(trenutniKljuc.isWritable()){
                         ByteBuffer buff = (ByteBuffer) trenutniKljuc.attachment();
                         SocketChannel klijent = (SocketChannel) trenutniKljuc.channel();

                         if(buff.hasRemaining()){
                             klijent.write(buff);
                         }
                         else
                             trenutniKljuc.cancel();



                     }


                 }



             }


         } catch (IOException e) {
             e.printStackTrace();
         }

    }
}

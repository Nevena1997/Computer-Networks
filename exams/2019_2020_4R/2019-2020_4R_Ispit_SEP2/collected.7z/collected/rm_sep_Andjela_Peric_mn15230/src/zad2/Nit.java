package zad2;

import java.util.Map;
import java.util.Scanner;

public class Nit implements Runnable {

    private Map<Integer,Float> mapa;

   public Nit(Map<Integer,Float> mapa){
       this.mapa=mapa;
   }


    @Override
    public void run() {
        try(Scanner sc = new Scanner(System.in)){
            int broj;
            float vrednost;
            while (sc.hasNext()){
                broj = sc.nextInt();
                vrednost = sc.nextFloat();
                mapa.put(broj, vrednost);
            }



        }
    }
}

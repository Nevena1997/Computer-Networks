package zad2;

import java.io.IOException;
import java.net.*;

public class UDPClient {
    public static void main(String[] args) {
     try(DatagramSocket klijent = new DatagramSocket()){

         int broj_racuna = 231;
         String za_slanje = String.valueOf(broj_racuna);
         DatagramPacket paket_za_slanje = new DatagramPacket(za_slanje.getBytes(), za_slanje.getBytes().length,InetAddress.getLocalHost(),UDPServer.PORT);
         klijent.send(paket_za_slanje);
         //poslali smo broj racuna serveru, sad ocekujemo da nam vrati stanje

         byte[] niz_za_prijem = new byte[4];
         DatagramPacket paket_za_prijem = new DatagramPacket(niz_za_prijem, niz_za_prijem.length);
         klijent.receive(paket_za_prijem);
         String stanje = new String(niz_za_prijem,0,paket_za_prijem.getLength());
         float s = Float.parseFloat(stanje.trim());
         System.out.println("Trenutno stanje je: " + s);



     } catch (SocketException e) {
         e.printStackTrace();
     } catch (IOException e) {


     }

    }
}

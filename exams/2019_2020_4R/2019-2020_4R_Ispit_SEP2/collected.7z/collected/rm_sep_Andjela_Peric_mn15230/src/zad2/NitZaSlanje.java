package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Map;

public class NitZaSlanje implements Runnable {
    private DatagramSocket server = null;
    private Map<Integer,Float> mapa;

    public NitZaSlanje(DatagramSocket server, Map<Integer,Float> mapa){
        this.server=server;
        this.mapa=mapa;
    }

    @Override
    public void run() {

        try {
            byte[] niz_za_prijem = new byte[4];
            DatagramPacket paket_za_prijem = new DatagramPacket(niz_za_prijem,niz_za_prijem.length);
            server.receive(paket_za_prijem);
            //prihvatili smo paket

            String broj_racuna = new String(niz_za_prijem,0,paket_za_prijem.getLength());
            int racun = Integer.parseInt(broj_racuna);
            float za_vracanje = -1;
            if(mapa.containsKey(racun)){
                za_vracanje = mapa.get(racun);
            }

            //pripremamo paket za slanje
            String s = String.valueOf(za_vracanje);
            DatagramPacket paket_za_slanje = new DatagramPacket(s.getBytes(), s.getBytes().length, paket_za_prijem.getAddress(), paket_za_prijem.getPort());
            server.send(paket_za_slanje);



        } catch (IOException e) {
            e.printStackTrace();
        }finally {

                if(server!=null)
                    server.close();

        }

    }
}

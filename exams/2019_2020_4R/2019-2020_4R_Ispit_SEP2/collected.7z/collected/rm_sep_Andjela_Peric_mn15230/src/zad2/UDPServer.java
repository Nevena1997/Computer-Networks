package zad2;

import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

public class UDPServer {
    public static int PORT = 12345;

    public static void main(String[] args) {
         try {
             DatagramSocket server = new DatagramSocket(PORT);
             Map<Integer,Float> mapa = new HashMap<>();

             while (true){
                 new Thread(new Nit(mapa)).start();
                 new Thread(new NitZaSlanje(server,mapa)).start();
             }


         } catch (SocketException e) {
             e.printStackTrace();
         }

    }
}

package zad3;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class Zad3Main {


    public static void main(String[] args) {

        Map<Float,Integer> mapa = new HashMap<>();
        try(Scanner sc = new Scanner(System.in)){
            String fajl = sc.next();
          /* try(Scanner skener = new Scanner(fajl)){
               // skener.useDelimiter(" ");

               Vector<Float> niz = new Vector<Float>();
               int brojac = 0;
                while(skener.hasNextFloat()){
                    float broj = skener.nextFloat();
                    System.out.println(broj);
                    brojac++;
                    niz.add(broj);

                }
               System.out.println(niz.size());
             //  System.out.println(niz);
             for(Float f : niz) {
                 new Thread((new Nit(niz,f))).start();
             }

          */

          try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fajl)))) {

              Vector<Float> niz = new Vector<Float>();
              String line;
              while((line = br.readLine()) != null ) {

                  String[] s = line.split(" ");
                  for (String str : s) {
                      float f = Float.valueOf(str);
                      niz.add(f);
                  }
              }
              System.out.println(niz.size());

              for(int i=0;i<niz.size();i++) {
                 Thread t = new Thread((new Nit(niz,niz.elementAt(i),i,mapa)));
                 t.start();

              }



          } catch (FileNotFoundException e) {
              e.printStackTrace();
          } catch (IOException e) {
              e.printStackTrace();
          }

        }
        }
    }

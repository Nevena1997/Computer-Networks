package zad3;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class Nit implements Runnable {
    private Vector<Float> niz;
    private float trazeni;
    private int pozicija;
    public Map<Float,Integer> mapa;

    public Nit (Vector<Float> niz, float trazeni, int pozicija, Map<Float,Integer> mapa){
        this.niz=niz;
        this.trazeni=trazeni;
        this.pozicija=pozicija;
        this.mapa=mapa;
    }


    @Override
    public void run() {
        int indeks=0;
        for(int i=0;i<niz.size();i++) {
            if(niz.elementAt(i) == trazeni && i==pozicija)
                break;
            if(niz.elementAt(i) < trazeni)
                indeks++;
        }
             System.out.println("Indeks elementa " + trazeni + " je " + indeks);
          if(mapa.containsKey(trazeni)){
              mapa.replace(trazeni,indeks);
          }
          else
              mapa.put(trazeni,indeks);
         }
    }


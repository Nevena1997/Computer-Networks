package zad3;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.util.Scanner;

public class Zad3Main {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite putanju do fajla: ");
        String directory = sc.nextLine();
        File file = new File(directory);

        try(Scanner f = new Scanner(file)){
            double d;
            while(f.hasNextDouble()){
                d = f.nextDouble();
                Nit.lista.add(d);
            }
            System.out.println("Ukupan broj elemenata kolekcije je: " + Nit.lista.size());

        while(Nit.indeks<Nit.lista.size()){
            new Nit().start();
            Nit.indeks++;
        }
        Nit.sort();
        System.out.println(Nit.lista.toString());
        }catch (FileNotFoundException | InterruptedException e){
            e.printStackTrace();
        }

        
    }
}

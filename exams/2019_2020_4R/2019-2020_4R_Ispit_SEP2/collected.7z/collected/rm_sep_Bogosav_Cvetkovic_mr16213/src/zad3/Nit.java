package zad3;

import java.util.*;

public class Nit extends Thread{

    public static List<Double> lista = new ArrayList<>();
    public static int indeks = 0;
    @Override
    public void run() {
        if(indeks<lista.size())
            System.out.println("Argument: " + lista.get(indeks) + " Broj elemenata ispred njega:" + (indeks-1));
    }
    public static void sort() throws InterruptedException {
        Thread.sleep(500);
        long start = System.currentTimeMillis();
        lista.sort(Comparator.comparingDouble(Double::byteValue));
        long end = System.currentTimeMillis();
        System.out.println("Tumbanje niza odradjeno za " + (end-start)/1000.0 + "s");
    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ObradaKlijenta extends Thread {


    public static Map<Integer,Double> racuni = new HashMap<>();
    public static int MAX_DUZINA = 100;
    private DatagramSocket server;

    public ObradaKlijenta(DatagramSocket server){
        this.server = server;
    }


    @Override
    public void run() {
        byte[] niz_prijem = new byte[MAX_DUZINA];
        DatagramPacket recivedPacket = new DatagramPacket(niz_prijem,0,MAX_DUZINA);
        try {
            server.receive(recivedPacket);
            String[] poruka = new String(recivedPacket.getData()).split(" ");
            if(poruka.length == 2) { // ZA INPUT BR_RACUNA IZNOS
                Integer ziro = Integer.parseInt(poruka[0]);
                Double iznos = Double.parseDouble(poruka[1]);

                if (!racuni.containsKey(ziro)) {
                    racuni.put(ziro,iznos);
                } else {
                    byte[] niz = poruka[1].getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(niz, 0, niz.length, recivedPacket.getAddress(), recivedPacket.getPort());
                    racuni.replace(ziro,iznos);
                    server.send(sendPacket);
                }
            }
            else{ // ZA INPUT SAMO BR_RACUNA
                Integer ziro = Integer.parseInt(poruka[0]);
                if (!racuni.containsKey(ziro)) {
                    byte[] niz = "-1".getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(niz, 0, niz.length, recivedPacket.getAddress(), recivedPacket.getPort());
                    server.send(sendPacket);

                } else {
                    byte[] niz = racuni.get(ziro).toString().getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(niz, 0, niz.length, recivedPacket.getAddress(), recivedPacket.getPort());
                    server.send(sendPacket);
                }
            }
            } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}

package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.channels.DatagramChannel;

public class UDPServer {

    public static int MAX_DUZINA = 100;
    public static int PORT = 12345;


    public static void main(String[] args) {
        System.out.println("UDPServer");

        try (DatagramSocket server = new DatagramSocket(PORT)) {

            while(true){

                new ObradaKlijenta(server).start();
            }
        }catch (SocketException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

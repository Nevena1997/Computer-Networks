package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

import static java.lang.System.exit;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("UDPClient");
        Scanner sc = new Scanner(System.in);
        try (DatagramSocket client = new DatagramSocket()) {
            while(true) {
                    /*
                    Ako stignem premesticu ucitavanje racuna sa Klijentske strane u Serversku
                    zadatak sam uradio pre nego sto su asistenti objasnili nadam se da nije preveliki problem
                    * */
                    System.out.println("Unesite ziro racun i iznos u formatu ZIRO_RACUN IZNOS ili samo ZIRO_RACUN ako proveravata stanje (EXIT za kraj programa)");
                    String poruka = sc.nextLine();
                    if(poruka.equalsIgnoreCase("exit")){
                        exit(0);
                    }
                    byte[] niz = poruka.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(niz,0,niz.length, InetAddress.getLocalHost(), UDPServer.PORT);
                    client.send(sendPacket);

                    byte[] niz_recive = new byte[UDPServer.MAX_DUZINA];
                    DatagramPacket recivepacket = new DatagramPacket(niz_recive,0,niz_recive.length);
                    client.receive(recivepacket);
                    String message = new String(recivepacket.getData());
                    System.out.println("Server: " + message);
                }
            } catch (UnknownHostException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}

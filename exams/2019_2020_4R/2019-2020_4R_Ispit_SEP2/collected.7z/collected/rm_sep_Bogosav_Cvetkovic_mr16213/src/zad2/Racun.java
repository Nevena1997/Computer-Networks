package zad2;

public class Racun {
    private int brojRacuna;
    private double iznos_na_racunu;

    public Racun(int brojRacuna, double iznos_na_racunu) {
        this.brojRacuna = brojRacuna;
        this.iznos_na_racunu = iznos_na_racunu;
    }

    public int getBrojRacuna() {
        return brojRacuna;
    }

    public void setBrojRacuna(int brojRacuna) {
        this.brojRacuna = brojRacuna;
    }

    public double getIznos_na_racunu() {
        return iznos_na_racunu;
    }

    public void setIznos_na_racunu(double iznos_na_racunu) {
        this.iznos_na_racunu = iznos_na_racunu;
    }
}

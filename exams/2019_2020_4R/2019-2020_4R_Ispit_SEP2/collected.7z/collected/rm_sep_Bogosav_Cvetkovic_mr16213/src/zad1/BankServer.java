package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class BankServer {

    /*
    NAPOMENA

    Neka stvari u zadatku nisam na vreme shvatio kako funkcionisu moguce je da ima gresaka tokom rada

    */

    public static Map<String,Double> racuni = new HashMap<>();

    public static int PORT = 12221;

    public static int MAX_DUZINA = 100;

    public static void main(String[] args) {
        System.out.println("BankServer");

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()){

            if(!server.isOpen()||!selector.isOpen()){
                System.err.println("Nije uspelo usostavljanje servera");
                server.bind(new InetSocketAddress("localhost",PORT));

                server.register(selector, SelectionKey.OP_ACCEPT);

                server.configureBlocking(false);
                Scanner sc = new Scanner(System.in);
                while(true){

                    selector.select();

                    Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

                    while(iterator.hasNext()){
                        SelectionKey currentKey = iterator.next();
                        iterator.remove();
                        if(currentKey.isAcceptable()){
                            ServerSocketChannel serverKey = (ServerSocketChannel) currentKey.channel();
                            SocketChannel client = serverKey.accept();
                            client.configureBlocking(false);
                            client.register(selector,SelectionKey.OP_READ);

                            /*SERVER REGISTRUJE KLIJENTE*/
                        }
                        if(currentKey.isReadable()){
                            SocketChannel client = (SocketChannel) currentKey.channel();
                            client.configureBlocking(false);
                            ByteBuffer input_ziro = ByteBuffer.allocate(MAX_DUZINA);
                            input_ziro.clear();
                            client.read(input_ziro);
                            String ziro = input_ziro.toString();
                            if(!racuni.containsKey(ziro)){
                                racuni.put(ziro, (double) 0);
                            }
                            racuni.forEach((k,v) -> System.out.println("Ziro racun: " + k));

                            client.read(input_ziro);
                            String[] unos = input_ziro.toString().split(" ");
                            if(!racuni.containsKey(unos[0]))
                                return;
                            double trenutno_stanje = racuni.get(unos[0]);
                            racuni.replace(unos[0],Double.parseDouble(unos[1])+trenutno_stanje);
                            currentKey.attach("Izvrsena je transakcija na racun" + unos[0] + " u iznosu " + unos[1].toString());
                            client.register(selector,SelectionKey.OP_WRITE);
                            /*SERVER PRIMA PORUKE*/
                        }
                        if(currentKey.isWritable()){
                            /**/
                            SocketChannel client = (SocketChannel) currentKey.channel();
                            String poruka = (String) currentKey.attachment();
                            ByteBuffer output = ByteBuffer.wrap(poruka.getBytes());
                            output.flip();
                            client.write(output);
                        }
                    }

                }
            }

        }catch (IOException e){
            e.printStackTrace();
        }

    }
    /*
    private synchronized void transakcija(String primalac,double iznos){
        if(!racuni.containsKey(primalac))
            return;
        double trenutno_stanje = racuni.get(primalac);
        racuni.replace(primalac,iznos+trenutno_stanje);
    }
    */
}

package zad1;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");
        try(Socket client = new Socket("localhost",BankServer.PORT)){

            BufferedWriter sender = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), StandardCharsets.UTF_8));
            BufferedReader reciver = new BufferedReader(new InputStreamReader(client.getInputStream(),StandardCharsets.UTF_8));

            Scanner sc = new Scanner(System.in);
            String ziro_racun;
            System.out.println("Unesite broj vaseg ziro racuna:");
            ziro_racun = sc.nextLine();
            sender.write(ziro_racun);
            sender.newLine();
            sender.flush();

            String message = reciver.readLine();
            System.out.println("Server javlja : " + message);

        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

package zad1;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static java.nio.channels.SelectionKey.OP_ACCEPT;

public class BankServer {

    public static final int PORT = 12221;
    private static final Map<Long, List<ByteBuffer>> porukeZaPrimaoce = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("BankServer");

        try (ServerSocketChannel server = ServerSocketChannel.open();
             Selector selector = Selector.open();
             ) {

            server.configureBlocking(false);
            server.register(selector, OP_ACCEPT);
            server.bind(new InetSocketAddress("localhost", PORT));

            while (true) {

                if (selector.select() > 0) {

                    Set<SelectionKey> selected = selector.selectedKeys();

                    for (SelectionKey key : selected) {

                        if (key.isAcceptable()) {

                            ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
                            serverSocketChannel.accept();

                            key.interestOps(SelectionKey.OP_READ);

                        } else if (key.isWritable()) {

                            ByteBuffer buff = (ByteBuffer) key.attachment();

                            if(buff.hasRemaining()) {
                                ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
                                try {
                                    serverSocketChannel.accept().write(buff);
                                } catch (IOException ioe) {
                                    // TODO print some message to stderr
                                    ioe.printStackTrace();
                                }
                            } else {
                                key.interestOps(SelectionKey.OP_READ);
                            }

                        } else if (key.isReadable()) {

                            ServerSocketChannel channel = (ServerSocketChannel) key.channel();
                            ByteBuffer buff = ByteBuffer.allocate(16); // long + long

                            try {
                                int howMany = channel.accept().read(buff);
                                if (howMany == -1) {

                                    key.interestOps(SelectionKey.OP_WRITE);

                                    long brRacuna = buff.getLong();

                                    if (buff.hasRemaining()) {
                                        // imamo i stanje

                                        // da li treba proveriti da li postoji primalac?

                                        long stanje = buff.getLong();

                                        final String poruka = String.format("Transfer na racun %d (%.d) je uspesno izvrsen", brRacuna, stanje);
                                        byte[] bytes = poruka.getBytes(StandardCharsets.UTF_8);
                                        ByteBuffer outBuff = ByteBuffer.wrap(bytes);
                                        key.attach(outBuff);

                                        // TODO obavesti primaoca
                                        List<ByteBuffer> postojecePoruke = porukeZaPrimaoce.get(brRacuna);

                                        if (postojecePoruke != null) {
                                            final String poruka1 = String.format("Primljeno %.2f od racuna %d", stanje, brRacuna);
                                            byte[] bytes1 = poruka.getBytes(StandardCharsets.UTF_8);
                                            ByteBuffer outBuff1 = ByteBuffer.wrap(bytes);
                                            postojecePoruke.add(outBuff1);
                                        }

                                    } else {

                                        // ovo je bio racun klijenta (ne primaoca)
                                        porukeZaPrimaoce.put(brRacuna, Collections.emptyList());
                                    }


                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }

            }

        } catch (IOException e) {
            System.err.println("Dogodio se neki problem...");
            e.printStackTrace();
        }
    }


}

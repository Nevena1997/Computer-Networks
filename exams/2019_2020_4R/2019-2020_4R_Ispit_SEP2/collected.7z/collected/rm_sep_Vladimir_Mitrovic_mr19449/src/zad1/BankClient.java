package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");

        try (SocketChannel client = SocketChannel.open()) {

            ByteBuffer buff = ByteBuffer.allocate(8);
            buff.putLong(123); // dummy racun
            client.write(buff);

            try (Scanner sc = new Scanner(System.in)) {
                if (sc.hasNextLong()) {
                    long brRac = sc.nextLong();

                    if (sc.hasNextLong()) {
                        long stanje = sc.nextLong();

                        if (client.connect(new InetSocketAddress("localhost", BankServer.PORT))) {

                            ByteBuffer b = ByteBuffer.allocate(16);
                            b.putLong(brRac);
                            b.putLong(stanje);
                            int n = client.write(b);
                        }

                    } // TODO else
                } // TODO else
            }
        } catch (IOException e) {
            System.err.println("Dogodio se neki problem...");
            e.printStackTrace();
        }
    }
}

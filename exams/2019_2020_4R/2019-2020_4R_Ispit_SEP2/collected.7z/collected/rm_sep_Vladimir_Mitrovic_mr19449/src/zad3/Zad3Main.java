package zad3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

public class Zad3Main {

    private static Map<Double, Integer> valueToIndex = Collections.synchronizedMap(new HashMap<>());
    private static List<Double> sortedData = Collections.synchronizedList(new ArrayList<>());
    private static long sortDuration;

    public static void main(String[] args) {

        ucitajKolekciju();
        long startSorting = System.nanoTime();
        sortirajKolekciju();
        sortDuration = (System.nanoTime() - startSorting) / 1000;
        ispisiVremeSortiranja();
        ispisSortiraneKolekcije();
        azurirajStrukturuPodataka();
        pokreniNitZaSvakiElement();
    }

    private static void ispisiVremeSortiranja() {
        System.out.printf("Vreme sortiranja: %dms\n", sortDuration);
    }

    static void ucitajKolekciju() {

        String imeFajla;
        try(Scanner sc = new Scanner(System.in)) {
            imeFajla = sc.nextLine();
        }

        try (
            Scanner sc = new Scanner(new FileInputStream(imeFajla))) {

            int count = 0;

            while (sc.hasNextDouble()) {
                // kasnije ce biti sortirano
                sortedData.add(sc.nextDouble());
                ++count;
            }

            System.out.println("Ukupan broj elemenata kolekcije: " + count);

        } catch (FileNotFoundException e) {
            throw new RuntimeException("Neuspelo citanje fajla: ", e);

        }
    }

    static void sortirajKolekciju() {
        Collections.sort(sortedData);
    }

    static void azurirajStrukturuPodataka() {

        int count = sortedData.size();
        // popunjavamo mapu koja preslikava broj u najmanji index tog broja u kolekciji
        for (int index = 0; index < count; ++index) {
            // get je efikasno jer je u pitanju ArrayList
            // u protivnom bih imao iterator od sortedData...
            double data = sortedData.get(index);

            Integer oldIndex = valueToIndex.get(data);

            if (oldIndex == null) {
                valueToIndex.put(data, index);
            } else {

                // ne radimo nista jer je najmanji index datog broja vec unet (index je rastuca f-ja)
            }
        }
    }

    static void pokreniNitZaSvakiElement() {

        for (final double data : sortedData) {

            new Thread(new Runnable() {
                @Override
                public void run() {
                    // pristup je sinhronizovan
                    System.out.printf("Najmanji indeks broja: %.2f je %d\n", data, valueToIndex.get(data));
                }
            }).start();
        }
    }
    
    static void ispisSortiraneKolekcije() {

        int index = 0;
        int count = sortedData.size();

        for (final double data : sortedData) {
            System.out.printf("%.2f%s", data, ++index == count ? "" : ", ");
        }

        System.out.println();
    }
}

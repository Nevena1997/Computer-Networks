package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static final int PORT = 12345;

    private static Map<Long, Double> racuni = Collections.synchronizedMap(new HashMap<>());

    public static void main(String[] args) {
        System.out.println("UDPServer");

        // citaj podatke o racunima i stanjima sa standardnog ulaza
        new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    try (Scanner sc = new Scanner(System.in)) {

                        while (sc.hasNextLine()) {
                            final String line = sc.nextLine();

                            try (Scanner innerScanner = new Scanner(new StringReader(line))) {
                                if (innerScanner.hasNextLong()) {
                                    final long brRacuna = innerScanner.nextLong();
                                    if (innerScanner.hasNextDouble()) {
                                        final double stanje = innerScanner.nextDouble();
                                        racuni.put(brRacuna, stanje);
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try (DatagramSocket ds = new DatagramSocket(PORT)) {

                    byte[] inputBuff = new byte[8];
                    DatagramPacket packet = new DatagramPacket(inputBuff, inputBuff.length);
                    ds.receive(packet);

                    long brRacuna;

                    // nije neophodno... ali ne smeta
                    try (DataInputStream dis = new DataInputStream(new ByteArrayInputStream(inputBuff))) {
                        brRacuna = dis.readLong();
                    }

                    // pristup je sinhronizovan
                    Double stanje = racuni.get(brRacuna);

                    byte[] outputBuff = doubleToByteArray(stanje);

                    ds.send(new DatagramPacket(outputBuff, outputBuff.length));

                } catch (SocketException e) {
                    System.err.println("Neuspelo pokretanje servera!");
                    e.printStackTrace();
                } catch (IOException e) {
                    System.err.println("Neuspelo primanje ili slanje paketa ili enkodovanje stanja!");
                    e.printStackTrace();
                }

            }
        }).start();

    }

    private static byte[] doubleToByteArray(Double stanje) throws IOException {
        try (
                ByteArrayOutputStream bos = new ByteArrayOutputStream(8);
                DataOutputStream dos = new DataOutputStream(bos);
        ) {

            if (stanje == null) {

                dos.writeDouble(-1.0);
            } else {

                dos.writeDouble(stanje);
            }

            return bos.toByteArray();
        }
    }
}

package zad2;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import static zad2.UDPServer.PORT;

public class UDPClient {


    public static void main(String[] args) {
        System.out.println("UDPClient");

        System.out.println("Unesite broj racuna:");

        long brRacuna;

        try(Scanner sc = new Scanner(System.in)) {
            brRacuna = Long.parseLong(sc.nextLine());
        }

        try (DatagramSocket ds = new DatagramSocket(new InetSocketAddress("localhost", PORT))) {

            DatagramPacket outgoingPacket = new DatagramPacket(longToBuff(brRacuna), 8);
            ds.send(outgoingPacket);

            final byte[] buff = new byte[8]; // ovo je dovoljno za realan br.
            DatagramPacket incomingPacket = new DatagramPacket(buff, buff.length);
            ds.receive(incomingPacket);
            double stanjeNaRacunu = buffToDouble(incomingPacket.getData());

            if (stanjeNaRacunu == -1.0) {

                System.out.printf("Racun: %d trenutno nije aktivan\n", brRacuna);

            } else {

                System.out.printf("Racun: %d, stanje: %.2f\n", brRacuna, stanjeNaRacunu);
            }



        } catch (SocketException e) {
            System.err.println("Problem pri kreiranju DatagramSocket-a");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Problem pri slanju ili dobijanju datagrama");
            e.printStackTrace();
        }
    }

    private static double buffToDouble(byte[] data) throws IOException {

        try (DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data))) {

            return dis.readDouble();
        }
    }

    private static byte[] longToBuff(long brRacuna) throws IOException {

        try (
                ByteArrayOutputStream baos = new ByteArrayOutputStream(8);
                DataOutputStream dos = new DataOutputStream(baos);) {
            dos.writeLong(brRacuna);
            return baos.toByteArray();
        }
    }


}

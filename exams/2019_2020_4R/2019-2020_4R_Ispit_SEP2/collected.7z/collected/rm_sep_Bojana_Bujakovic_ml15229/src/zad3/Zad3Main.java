package zad3;


import java.io.*;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Zad3Main {

    public static int MAX_SIZE=100;

    public static  int Thread_size=5;

    public static class ThreadWorkers implements Runnable{

        Vector<Double> v;

        public ThreadWorkers(Vector<Double> v){
            this.v=v;
        }


        @Override
        public void run() {




        }
    }




    public static void main(String[] args) throws FileNotFoundException {

        Vector<Double> vector=new Vector<>();

        Scanner sc=new Scanner(System.in);
        String file_name=sc.nextLine();
        System.out.println(file_name);





        try {
          //  BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(file_name)));
          //  String ulaz = in.readLine();

            Scanner fajl=new Scanner(Paths.get(file_name));
            while (fajl.hasNext())
                vector.add(fajl.nextDouble());


            for(double e:vector)
                System.out.println(e);


            System.out.println("Ukupan broj elemenata kolekcije je "+ vector.size());


            for (int i=0;i<Thread_size;i++)
                new Thread(new ThreadWorkers(vector)).start();

        } catch (IOException e) {
            e.printStackTrace();
        }







        sc.close();
    }
}

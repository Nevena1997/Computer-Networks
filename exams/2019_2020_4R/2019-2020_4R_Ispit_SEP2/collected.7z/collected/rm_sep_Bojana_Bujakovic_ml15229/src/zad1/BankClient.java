package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {
        System.out.println("BankClient");

        try (Socket klijent = new Socket("localhost", BankServer.PORT);
             Scanner sc=new Scanner(System.in);
             BufferedReader in=new BufferedReader(new InputStreamReader(klijent.getInputStream()));
             PrintWriter pw=new PrintWriter(klijent.getOutputStream());
             BufferedWriter out=new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream()));
             ) {

            String br_racuna="abcd1234";

            pw.write(br_racuna);
            pw.flush();

            //server nam vraca spisak svih aktivnih klijenata

            String linija;
            while (true){
                linija=in.readLine();
                if(linija==null)
                    break;
                else
                    System.out.println(linija);

            }

            String racun_primaoca;
            int iznos;

            racun_primaoca=sc.nextLine();
            iznos=Integer.parseInt(sc.nextLine());

            //salje podatke serveru
            out.write(racun_primaoca);
            out.write(iznos);
            out.newLine();
            out.flush();

            //ceka odgvor

            System.out.println(in.readLine());







        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

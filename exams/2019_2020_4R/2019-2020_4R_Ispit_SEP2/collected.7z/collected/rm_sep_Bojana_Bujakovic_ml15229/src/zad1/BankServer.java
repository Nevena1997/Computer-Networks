package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class BankServer {

    public static int PORT=12221;

    public static void main(String[] args) {
        System.out.println("BankServer");


            try (ServerSocketChannel server = ServerSocketChannel.open();
                 Selector selektor=Selector.open()) {

                if (!server.isOpen() || !selektor.isOpen())
                    System.exit(1);


                server.bind(new InetSocketAddress(PORT));
                server.configureBlocking(false);
                server.register(selektor, SelectionKey.OP_ACCEPT);


                while (true){

                    selektor.select();
                    Iterator<SelectionKey> iter=selektor.selectedKeys().iterator();

                    while (iter.hasNext()){

                        SelectionKey trenutni_kljuc=iter.next();
                        iter.remove();

                        if(trenutni_kljuc.isAcceptable()){

                            ServerSocketChannel server_kanal=(ServerSocketChannel)trenutni_kljuc.channel();

                            SocketChannel klijent=server.accept();

                            klijent.configureBlocking(false);

                            SelectionKey klijent_kljuc= klijent.register(selektor,SelectionKey.OP_READ);





                        }
                        if(trenutni_kljuc.isReadable()){

                            SocketChannel klijent=(SocketChannel) trenutni_kljuc.channel();

                            ByteBuffer bytes=ByteBuffer.allocate(1024);

                            klijent.read(bytes);

                            String racun=bytes.toString();

                            //u  ovom momentu on klijentu treba da vrrati spisak aktivnih racuna

                           SelectionKey klijent_kljuc= klijent.register(selektor,SelectionKey.OP_WRITE);

                            bytes.clear();
                            //u baferu bytes treba smestiti podatke za slanje..
                            //............
                            bytes.flip();
                            klijent_kljuc.attach(bytes);

                        }
                        if(trenutni_kljuc.isWritable()){

                            SocketChannel klijent=(SocketChannel) trenutni_kljuc.channel();

                            ByteBuffer bytes=ByteBuffer.allocate(1024);

                            //sada treba posalti podatke iz bafera




                        }

                    }



                }











            } catch (IOException e) {
                e.printStackTrace();
            }


        }




}

package zad2;

import java.io.IOException;
import java.net.*;

public class UDPClient {
    public static void main(String[] args) {
        System.out.println("UDPClient");


        try (DatagramSocket klijent = new DatagramSocket()) {

            String br_racuna="abcd1234";
            DatagramPacket paket=new DatagramPacket(br_racuna.getBytes(),br_racuna.getBytes().length,
                    InetAddress.getLocalHost(),UDPServer.PORT);

            klijent.send(paket);

            //klijent ceka da server obradi paket i posalje odgovor nazad


            byte[] niz=new byte[2048];
            DatagramPacket paket1=new DatagramPacket(niz,niz.length);
            klijent.receive(paket1);

            String odgovor=new String(niz,0,paket1.getLength());
            System.out.println(odgovor);

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

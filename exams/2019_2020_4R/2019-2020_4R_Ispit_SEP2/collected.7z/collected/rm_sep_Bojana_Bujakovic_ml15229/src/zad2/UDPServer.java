package zad2;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {

    public static int PORT=12345;
    public static Map<String,Double> map=new HashMap<String, Double>();


    public static class InitialThread implements Runnable{




        @Override
        public void run() {

            try (Scanner sc = new Scanner(System.in)) {
                String racun;
                double vrednost;

                String s;
                while (sc.hasNextLine()){
                    racun=sc.next();
                    vrednost=sc.nextDouble();

                    map.put(racun,vrednost);

                }


            }

        }

    }




    public static void main(String[] args) {
        System.out.println("UDPServer");

        try (DatagramSocket server = new DatagramSocket(PORT)) {


            new Thread(new InitialThread()).start();


            while (true){

                byte[] niz_za_primanje = new byte[2048];
                DatagramPacket paket1 = new DatagramPacket(niz_za_primanje, niz_za_primanje.length);
                server.receive(paket1);

                String racun = new String(niz_za_primanje, 0, paket1.getLength());

                int i = -1;
                String odgovor;
                if (map.containsKey(racun))
                    odgovor = Double.toString(map.get(racun));
                else
                    odgovor = Integer.toString(i);

                DatagramPacket paket_za_slanje = new DatagramPacket(odgovor.getBytes(), odgovor.getBytes().length,
                        paket1.getAddress(), paket1.getPort());
                server.send(paket_za_slanje);

            }


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class BankClient {
    public static void main(String[] args) {

        System.out.println("BankClient");

        try (SocketChannel klijent = SocketChannel.open(new InetSocketAddress("localhost", BankServer.PORT));
             Scanner sc = new Scanner(System.in)
        ){

            if(!klijent.isOpen()){
                System.err.println("Problem sa klijentom");
                System.exit(1);
            }


            //klijent.bind(new InetSocketAddress("localhost", BankServer.PORT));
            System.out.println("Unesite br svog racuna");
                String br_mog_racuna = "*";
                br_mog_racuna.concat(sc.nextLine());

                // saljemo serveru racun
                ByteBuffer buff = ByteBuffer.allocate(br_mog_racuna.length());
                buff.put(br_mog_racuna.getBytes());
                klijent.write(buff);


                // dobijamo odgovor od servera
                klijent.read(buff);
                String odgovor_servera = new String(buff.array());
                System.out.println(odgovor_servera);

                // onosimo racun primaoca
                System.out.println("Unessite racun primaoca i iznos(opciono)");
                String racun_primaoca_i_iznos = "~";
                racun_primaoca_i_iznos.concat(sc.nextLine());
                if (racun_primaoca_i_iznos.length() == 1){
                    // ne radimo nista
                } else {
                    buff.put(racun_primaoca_i_iznos.getBytes());
                    klijent.write(buff);


                    // odgovor servera o izvrsenju transakcije
                    klijent.read(buff);
                    String odgovor_servera_o_izvrsenju_transakcije = new String(buff.array());
                    System.out.println(odgovor_servera_o_izvrsenju_transakcije);
                }







        }catch (IOException e){
            e.printStackTrace();
        }




    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BankServer {


    private Map<Integer, Integer> klijenti;
    public  static  int PORT = 12221;

    BankServer (){
        klijenti = new HashMap<Integer, Integer>();

    }


    public static void main(String[] args) {
        System.out.println("BankServer");

        BankServer bankServer = new BankServer();
        try {

            BankServer.izvrsi();

        } catch (IllegalBlockingModeException e) {
            e.printStackTrace();
        }

    }// end of main



    public static void izvrsi() throws IllegalBlockingModeException {

        try(ServerSocketChannel server = ServerSocketChannel.open();
            Selector selector = Selector.open()
        ){

            if(!server.isOpen() || !selector.isOpen()){
                System.err.println("Problem sa serverom ili selektorom");
                System.exit(1);
            }

            server.bind(new InetSocketAddress(PORT));
            server.configureBlocking(false);
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (true){

                selector.select();

                Iterator <SelectionKey> iterator = selector.selectedKeys().iterator();

                while(iterator.hasNext()){

                    SelectionKey trenutni_kljuc = iterator.next();
                    iterator.remove();

                    if(trenutni_kljuc.isAcceptable()){
                        // nas kljuc je server
                        ServerSocketChannel server_1 = (ServerSocketChannel) trenutni_kljuc.channel();
                        SocketChannel klijent = server_1.accept();


                        klijent.register(selector, SelectionKey.OP_READ);


                    } else if (trenutni_kljuc.isReadable()){

                        SocketChannel klijent = (SocketChannel) trenutni_kljuc.channel();

                        ByteBuffer buff = (ByteBuffer) trenutni_kljuc.attachment();

                        if( buff == null){
                            trenutni_kljuc.attach(buff);
                        }

                        klijent.read(buff);
                        String line = new String(buff.array());

                        if (line.contains("*")){
                            // racun klijenta
                            Integer racun_primaoca = Integer.parseInt(line.substring(1));
                            // this.klijenti.put(racun_primaoca, 0);
                            // valjda stavlja default nulu

                            // dgovor od servra
                            String spisak_klijenata = "";
                            /*
                            for(Integer s: this.klijenti){

                                    spisak_klijenata += (this.klijenti.get(s).toString() + "\n");
                                }
                            */

                            buff.rewind();
                            buff.put(spisak_klijenata.getBytes());
                            buff.flip();

                            trenutni_kljuc.interestOps(SelectionKey.OP_WRITE);


                        }else if (line.contains("~")){

                            // dobili smo br_racuna_primaoca i sumu
                            String primaoc =  new String(line.substring(1, line.indexOf(" ")));
                            String iznos =  new String(line.substring(line.indexOf(" ") + 1));

                            Integer racun_primaoca =  Integer.parseInt(primaoc);
                            Integer iznos_primaoca =  Integer.parseInt(iznos);

                            // if( this.klijenti.containsKey(racun_primaoca) )

                            // ne mora transakcija moza samo poruka
                            String odgovor_za_transakciju = "Transfer na racun " + primaoc + "(" + iznos +")" + "je uspesno ostvaren";
                            buff.rewind();
                            buff.put(odgovor_za_transakciju.getBytes());


                            buff.flip();

                            trenutni_kljuc.interestOps(SelectionKey.OP_WRITE);



                        }



                    }// end of isReadable()
                    else if (trenutni_kljuc.isWritable()){
                        SocketChannel klijent = (SocketChannel) trenutni_kljuc.channel();
                        ByteBuffer buff = (ByteBuffer) trenutni_kljuc.attachment();


                        if(buff.hasRemaining()){
                             klijent.write(buff);
                        }else {
                            buff.clear();
                           trenutni_kljuc.interestOps(SelectionKey.OP_READ);
                        }



                    }// end of isWritable()



                }




            }



        }catch (IOException e){
            e.printStackTrace();
        }




    }// end of izvrsi()


}

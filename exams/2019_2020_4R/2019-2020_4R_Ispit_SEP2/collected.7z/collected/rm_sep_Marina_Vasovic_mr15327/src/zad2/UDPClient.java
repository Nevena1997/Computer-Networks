package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {

        System.out.println("UDPClient");

        try (DatagramSocket klijent = new DatagramSocket();
             Scanner sc = new Scanner(System.in)
        ){

            System.out.println("Unesite br racuna koji yelite da dobijete od servera");
            String line = sc.nextLine();
            byte []  niz_za_slanje = line.getBytes();
            DatagramPacket paket_za_slanje =  new DatagramPacket(niz_za_slanje, niz_za_slanje.length, InetAddress.getLocalHost(),UDPServer.PORT);
            klijent.send(paket_za_slanje);


            // odgovor od servera
            byte [] niz_za_primanje = new byte[2048];
            DatagramPacket paket_za_primanje = new DatagramPacket(niz_za_primanje,niz_za_primanje.length);
            klijent.receive(paket_za_primanje);

            String odgovor = paket_za_primanje.getData().toString();
            Integer iznos =  Integer.parseInt(odgovor);
            System.out.println("Vase trenutno stanje iznosi: " + odgovor);



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

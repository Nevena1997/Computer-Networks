package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UDPServer {


    private Map<Integer, Integer> klijenti;
    private DatagramSocket server;
    public  static int PORT = 12345;


    UDPServer() throws SocketException {

        server = new DatagramSocket(PORT);
        klijenti = new HashMap<>();

    }


    public static void main(String[] args) throws SocketException {

        System.out.println("UDPServer");

        UDPServer server_ = new UDPServer();

        try (
             Scanner sc = new Scanner(System.in)
        ){

            while (sc.hasNext()){

                String line = sc.nextLine();
                Integer br_racuna = Integer.parseInt(line);
                server_.klijenti.put(br_racuna, 0);

            }



            byte [] niz_za_primanje= new byte[2048];
            DatagramPacket paket_za_primanje =  new DatagramPacket(niz_za_primanje, niz_za_primanje.length);
            server_.server.receive(paket_za_primanje);
            // u zavisnosti da li bio samo racun ili racun iznos imamo razlicite poruke

            String poruka = paket_za_primanje.getData().toString().substring(0, paket_za_primanje.getLength());
            System.out.println(poruka);
            if (poruka.substring(poruka.indexOf(" ") + 1).isBlank()){
                // imamo samo racun koji vracamo klijentu
                Integer racun = Integer.parseInt(poruka.substring(0,poruka.indexOf(" ")));
                String iznos = server_.klijenti.get(racun).toString();
                byte [] niz_za_slanje = iznos.getBytes();
                DatagramPacket paket_za_slanje = new DatagramPacket(niz_za_slanje, niz_za_slanje.length, paket_za_primanje.getAddress(), paket_za_primanje.getPort());

            }







        } catch (SocketException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}

package zad3;

import java.net.URL;

public class FileParser extends Thread {

    private URL url;

    public FileParser(URL url) {
        this.url = url;
    }

    @Override
    public void run() {

    }

}

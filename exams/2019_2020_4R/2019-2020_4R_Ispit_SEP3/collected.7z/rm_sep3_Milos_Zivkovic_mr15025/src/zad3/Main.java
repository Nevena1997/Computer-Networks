package zad3;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/urls.txt")))) {

            String line;
            List<String> lines = new ArrayList<>();
            while ((line = in.readLine()) != null) {
                lines.add(line.trim());
            }

            System.out.println(lines.size());

            for (String s : lines) {
                try {
                    String[] tokens = s.split(".");
                    URL url = new URL(s);
                    // TODO: "ftp" or "file"?
                    if (url.getProtocol().equalsIgnoreCase("FILE") && tokens.length == 2 && tokens[1].equalsIgnoreCase("txt")) {
                        new FileParser(url).start();
                    }
                } catch (MalformedURLException e) {
                    continue;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

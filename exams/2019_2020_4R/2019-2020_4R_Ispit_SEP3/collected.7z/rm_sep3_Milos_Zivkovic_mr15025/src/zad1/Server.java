package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Server {

    public static final int PORT = 12321;

    public static void main(String[] args) {

        BufferedReader in = null;

        try (ServerSocket server = new ServerSocket(PORT)) {

            List<Participant> participants = new ArrayList<>();
            Scanner sc = new Scanner(System.in); // TODO: close
            String file = sc.nextLine().trim();

            while (true) {
                Socket client = server.accept(); // TODO: close?

                participants.add(new Participant(client));

                if (participants.size() == 1) {
                    // start the quiz
                    for (Participant p : participants) {
                        p.sendMessage("Kviz pocinje sada. Srecno!");
                    }

                    new Quiz(participants, file);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

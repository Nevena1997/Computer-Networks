package zad1;

import java.io.*;
import java.util.List;

public class Quiz extends Thread {

    private final List<Participant> participants;
    private final String file;

    public Quiz(List<Participant> participants, String file) {
        this.participants = participants;
        this.file = file;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(this.file)));

            // parse questions, answers, correct answers into a collection of Question objects


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

class Question {

    public String question;
    public List<String> answers;
    public char correctAnswer;

    public Question(String question, List<String> answers, char correctAnswer) {
        this.question = question;
        this.answers = answers;
        this.correctAnswer = correctAnswer;
    }
}

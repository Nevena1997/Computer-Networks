package zad1;

import java.io.*;
import java.net.Socket;

public class Participant implements AutoCloseable {

    public Socket socket;
    public String name;
    public double result;

    public BufferedWriter out;
    public BufferedReader in;

    public Participant(Socket socket) throws IOException {
        this.socket = socket;

        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String clientName = this.in.readLine();

        this.name = clientName;

        this.out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
        this.result = 0;
    }

    public void sendMessage(String message) {
        try {
            this.out.write(message);
            this.out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws Exception {
        this.out.close();
        this.in.close();
    }
}

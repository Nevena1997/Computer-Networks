package zad1;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        String host = "localhost";

        try (Socket client = new Socket(host, Server.PORT)) {

            // TODO: should this be user input?
            Scanner sc = new Scanner(System.in); // TODO: close
            String clientName = sc.nextLine();

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
            out.write(clientName);
            out.flush();

            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            System.out.println(in.readLine());

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

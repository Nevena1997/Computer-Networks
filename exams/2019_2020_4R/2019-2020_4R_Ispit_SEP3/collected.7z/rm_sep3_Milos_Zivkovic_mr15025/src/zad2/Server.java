package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server {

    public static final int PORT = 12321;
    public static Integer packetCount = 0;

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in); DatagramSocket server = new DatagramSocket(PORT)) {
            String directory = sc.next();
            Path directoryPath = Paths.get(directory);

            while (true) {
                byte[] buff = new byte[512];
                DatagramPacket req = new DatagramPacket(buff, buff.length);
                server.receive(req);
                packetCount++;
                System.out.println(packetCount.toString() + " " + req.getAddress().toString());

                String requestContent = new String(req.getData(), 0, req.getLength());
                String[] tokens = requestContent.strip().split("\\s+");
                // TODO: handle IndexOutOfRange ?
                String filename = tokens[0];
                int x = Integer.parseInt(tokens[1]);
                int y = Integer.parseInt(tokens[2]);
                StringBuilder respContentSb = new StringBuilder();

                readLines(directoryPath, filename, x, y, respContentSb);

                String respContent = respContentSb.toString();
                DatagramPacket resp = new DatagramPacket(respContent.getBytes(), respContent.getBytes().length, req.getAddress(), req.getPort());
                server.send(resp);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void readLines(Path directory, String file, int x, int y, StringBuilder resp) {
        try {
            DirectoryStream<Path> dirStream = Files.newDirectoryStream(directory);

            for (Path p : dirStream) {
                if (Files.isDirectory(p)) {
                    readLines(p, file, x, y, resp);
                } else if (p.getFileName().toString().equals(file)) {
                    String line;
                    int lineCount = 0;
                    // TODO: close
                    BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(p.toAbsolutePath().toString())));
                    while ((line = in.readLine()) != null) {
                        System.out.println(line);
                        lineCount++;

                        if (lineCount > y) {
                            break;
                        }

                        if (lineCount >= x || lineCount <= y) {
                            resp.append(line + "\n");
                        }
                    }

                    if (lineCount < x) {
                        resp = new StringBuilder("Nepravilno zadata naredba");
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package zad2;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        try (DatagramSocket client = new DatagramSocket(); Scanner sc = new Scanner(System.in)) {

            String file = sc.next();
            String x = sc.next();
            String y = sc.next();

            int xx = Integer.parseInt(x);
            int yy = Integer.parseInt(y);

            if (xx <= 0 || yy <= 0 || xx > yy) {
                System.exit(1);
            }

            byte[] buffReq = (file + " " + x + " " + y).getBytes();
            DatagramPacket req = new DatagramPacket(buffReq, buffReq.length, InetAddress.getByName("localhost"), Server.PORT);
            client.send(req);

            byte[] buffResp = new byte[512];
            DatagramPacket resp = new DatagramPacket(buffResp, buffResp.length);
            client.receive(resp);
            System.out.println(new String(resp.getData(), 0, resp.getLength()));

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Server {

    public static int port = 12321;

    public static void main(String[] args) {

        int broj_ucesnika = 0;

        Map<String, Integer> tabela = new HashMap<>();




        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector = Selector.open();
             Scanner sc = new Scanner(System.in)){


            String ime_fajla = sc.nextLine();


            if(!serverChannel.isOpen() || !selector.isOpen()){

                System.err.println("Nije uspeo da otvori ili server ili selector!");
                System.exit(1);
            }

            serverChannel.bind(new InetSocketAddress(port));
            serverChannel.configureBlocking(false);
            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while (true){

                selector.select();
                Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

                while (iter.hasNext()){

                    SelectionKey currentKey = iter.next();
                    iter.remove();

                    if(currentKey.isAcceptable()){

                        ServerSocketChannel server = (ServerSocketChannel) currentKey.channel();
                        SocketChannel client = server.accept();
                        broj_ucesnika++;
                        System.out.println("Client accepted! Trenutni broj ucesnika: " + broj_ucesnika);



                        client.configureBlocking(false);
                        client.register(selector, SelectionKey.OP_READ);

                    }

                    else if(currentKey.isReadable()){

                        SocketChannel client = (SocketChannel) currentKey.channel();

                        ByteBuffer bufin = ByteBuffer.allocate(128);
                        bufin.clear();
                        client.read(bufin);

                        String ime = new String(bufin.array());   // Treba srediti Ime...
                        int index = 0;
                        /*
                        for(int i = 0; i < ime.length(); i++){

                            if(ime.indexOf(i) != char)
                                index = i - 1;
                        }
*/
                        ime.substring(0, index);
                        System.out.println(ime);
                        tabela.put(ime, 0);

                    }

                    else if(currentKey.isWritable()){

                    }
                }
            }






        }catch (IOException e){

            e.printStackTrace();
        }
    }

    public void writeAll(SocketChannel socket){

    }

    public void read(SocketChannel socket){

    }
}

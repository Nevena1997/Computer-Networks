package zad1;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        try (Socket client = new Socket("localhost", Server.port);
             Scanner sc = new Scanner(System.in);
             BufferedWriter bout = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
             BufferedReader bin = new BufferedReader(new InputStreamReader(client.getInputStream()));
             ){

            String ime = sc.nextLine();

            bout.write(ime);
            bout.flush();

            while(true){


            }


        }catch (IOException e){

            e.printStackTrace();
        }

    }
}

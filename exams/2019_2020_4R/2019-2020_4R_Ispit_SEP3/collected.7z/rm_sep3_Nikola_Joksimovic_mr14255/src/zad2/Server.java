package zad2;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server {

    public static int port = 12121;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String ime_foldera = sc.nextLine();
        int broj_paketa = 0;

        //ime_foldera = "/home/ispit/Desktop/rm_sep3_Nikola_Joksimovic_mr14255/tests";
        Path path = Paths.get(ime_foldera);


        try (DatagramSocket server = new DatagramSocket(port);){

            while (true) {

                byte[] bufin = new byte[1024];
                DatagramPacket receving_packet = new DatagramPacket(bufin, bufin.length);
                server.receive(receving_packet);
                broj_paketa++;

                String ulaz = new String(bufin, 0, receving_packet.getLength());
                String[] ulazniz = ulaz.split(" ");
                String ime_fajla = ulazniz[0];
                int x = Integer.parseInt(ulazniz[1]);
                int y = Integer.parseInt(ulazniz[2]);

                System.out.println("Paket broj: " + broj_paketa + "\n IPAdresa:" + receving_packet.getAddress().toString());


                String izlaz = "";

                for(Path p : Files.newDirectoryStream(path)){

                    String putfajla = p.toString();
                    putfajla = putfajla.substring(putfajla.lastIndexOf("/")+1);

                    if(putfajla.matches(ime_fajla.toString())){

                        int redni_broj_linije = 0;
                        Scanner fs = new Scanner(p);
                        while(fs.hasNextLine()){

                            String linija = fs.nextLine();

                            redni_broj_linije++;

                            if(x <= redni_broj_linije && redni_broj_linije <= y){
                                izlaz = izlaz + "\n" + linija;
                            }
                        }


                        if(x <= 0 || redni_broj_linije <= y)
                            izlaz = "Nepravilno zadata naredba";

                        break;
                    }
                }



                byte[] bufout;
                bufout = izlaz.getBytes();
                DatagramPacket sending_packet = new DatagramPacket(bufout, bufout.length, receving_packet.getAddress(), receving_packet.getPort());

                server.send(sending_packet);

            }


        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

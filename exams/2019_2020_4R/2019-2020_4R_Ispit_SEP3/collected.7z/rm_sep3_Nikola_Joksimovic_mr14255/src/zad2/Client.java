package zad2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String ime_fajla = sc.nextLine();
        int x = sc.nextInt();
        int y = sc.nextInt();

        String ulaz = ime_fajla + " " + Integer.toString(x) + " " + Integer.toString(y);

        try (DatagramSocket client = new DatagramSocket()){

            byte[] bufout = new byte[1024];
            bufout = ulaz.getBytes();
            DatagramPacket sending_packet = new DatagramPacket(bufout, bufout.length, InetAddress.getLocalHost(), Server.port);
            client.send(sending_packet);


            byte[] bufin = new byte[2048];
            DatagramPacket receving_packet = new DatagramPacket(bufin, bufin.length);

            client.receive(receving_packet);
            String izlaz = new String(bufin, 0, receving_packet.getLength());


            System.out.println(izlaz);


        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

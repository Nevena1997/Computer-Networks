package zad3;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLConnection;

public class Nit extends Thread {

    private URLConnection urlc;
    private BufferedReader bin;
    private String trazeni_karakter;

    public Nit(URLConnection urlc, String trazeni_karakter){

        this.urlc = urlc;
        this.trazeni_karakter = trazeni_karakter;

        try {
            this.bin = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        }catch (IOException e){
            e.printStackTrace();
            System.err.println("File not found" + urlc.toString());;
        }
    }


    @Override
    public void run(){

        String line;
        int broj_ponavljanja = 0;
        try {
            while ((line = this.bin.readLine()) != null) {

                char[] nizKaraktera = new char[line.length()];


            }
        }catch (IOException e){

            e.printStackTrace();
        }
    }
}

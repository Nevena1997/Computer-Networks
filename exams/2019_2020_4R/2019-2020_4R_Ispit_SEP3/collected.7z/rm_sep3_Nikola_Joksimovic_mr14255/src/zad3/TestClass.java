package zad3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;


public class TestClass {

    public static void main(String[] args) {


        String ime_fajla = "/home/ispit/Desktop/rm_sep3_Nikola_Joksimovic_mr14255/tests2/urls.txt";

        try (BufferedReader bin = new BufferedReader(new FileReader(ime_fajla));
             Scanner sc = new Scanner(System.in)){

            String line;
            int broj_linija = 0;

            String trazeni_karakter = sc.nextLine();

            while ((line = bin.readLine()) != null){

                broj_linija++;


                // ===============================================
                // Treba proveriti da je validni url
                // ===============================================



                URL u = new URL(line);
                String prot = u.getProtocol();
                String extension = u.getFile();
                extension = extension.substring(extension.lastIndexOf('.'));


                if(prot.equalsIgnoreCase("file") && extension.equals(".txt")){

                    URLConnection urlc = u.openConnection();
                    new Thread(new Nit(urlc, trazeni_karakter)).start();

                }

            }
            System.out.println("lines : " + broj_linija);




        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public synchronized void povecaj(){

    }
}

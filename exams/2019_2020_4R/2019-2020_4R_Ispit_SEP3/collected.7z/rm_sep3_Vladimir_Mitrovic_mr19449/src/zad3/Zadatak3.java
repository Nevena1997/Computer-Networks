package zad3;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

public class Zadatak3 {

    public static void main(String[] args) {

        String znak = "";

        try (Scanner sc = new Scanner(System.in)) {

            if(sc.hasNext()) {
                znak = sc.next(".");
            }
        }

        if (znak.isEmpty()) {
            System.err.println("Znak za pretragu ne moze biti prazan");
            System.exit(1);
        }

        try {
            System.out.println("Broj linija u tests/urls.txt: " + brLinijaUFajlu("../tests/urls.txt"));

            AtomicInteger brPronadjenihZnakova = new AtomicInteger(0);

            for (final URL url : kreirajValidneURLs("../tests/urls.txt")) {

                if ("file".equals(url.getProtocol()) && url.getPath().endsWith(".txt")) {

                    final String znakZaPretragu = znak;

                    Thread nit = new Thread(new Runnable() {
                        @Override
                        public void run() {

                            File f = new File(url.getPath());

                            if (!f.exists()) {

                                System.err.println("Fajl " + url.getPath() + " ne postoji");
                                return;
                            }

                            // vrlo neefikasno i netacno u slucaju znakova za koje stvarno treba UTF-8 tj. vise od jednog char
                            char[] buff = new char[1];

                            try (
                                BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8))) {

                                int len;

                                while ((len = br.read(buff)) != -1) {

                                    if (buff[0] == znakZaPretragu.charAt(0)) {
                                        brPronadjenihZnakova.incrementAndGet();
                                    }
                                }

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    // nit.start();

                }


            }

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Doslo je do greske");
            System.exit(1);
        }

    }

    private static int brLinijaUFajlu(String s) throws IOException {

        final AtomicInteger counter = new AtomicInteger(0);
        try (BufferedReader br = new BufferedReader(new FileReader(s))) {


            br.lines().forEach(x -> {counter.incrementAndGet();});
        }

        return counter.get();
    }

    private static URL[] kreirajValidneURLs(String s) throws IOException {

        List<URL> validniUrls = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(s))) {


            br.lines().forEach(x -> {

                try {
                    URL url = new URL(x);
                    validniUrls.add(url);
                } catch (MalformedURLException e) {
                   System.err.println("Preskacemo nevalidni: " + x);
                }

            });
        }

        return validniUrls.toArray(new URL[validniUrls.size()]);
    }
}

package zad2;

import java.io.*;
import java.math.BigDecimal;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

public class Server {

    public static final int PORT = 12121;
    static final int MAX_FILENAME_LENGTH = 64;
    // 64 znaka za ime fajla (proizvoljan br) plus mesto za 3 int-a
    // prvo ide int za duzinu imena fajla, pa ime fajla enkodovano, pa 2 int-a
    static final int MAX_REQUEST_SIZE_IN_BYTES = MAX_FILENAME_LENGTH + 3;
    static final int MAX_RESPONSE_SIZE_IN_BYTES = 80; // proizvoljan limit
    static File servingFolder;

    private static void die(final String poruka) {
        System.err.println(poruka);
        System.exit(1);
    }


    public static void main(final String [] args) {


        System.out.println("Unesite ime foldera: ");
        String imeFoldera = null;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {

            imeFoldera = br.readLine();
        } catch (IOException e) {

            System.err.println("Doslo je do greske prilikom citanja imena foldera");
            e.printStackTrace();
            System.exit(1);
        }

        servingFolder = new File(imeFoldera);

        if (!servingFolder.isDirectory()) {

            die(String.format("Zadato ime: %s ne predstavlja folder!\n", imeFoldera));
        }

        System.out.println("Serviram sadrzaj foldera: " + imeFoldera);

        // ne zelimo overflow ukoliko server bude radio dovoljno dugo / primio dovoljno veliki broj datagrama
        // cena je brzina inkrementiranja i pretvaranja u string


        try (DatagramSocket server = new DatagramSocket(PORT)) {

            BigDecimal redniBroj = new BigDecimal(0);

            byte[] buff = new byte[MAX_REQUEST_SIZE_IN_BYTES];

            while (true) {

                DatagramPacket packet = new DatagramPacket(buff, buff.length);

                try {
                    server.receive(packet);

                    redniBroj = redniBroj.add(BigDecimal.ONE);

                    System.out.printf(
                            "Primljen datagram redni broj: %s, adresa posiljaoca: %s\n",
                            redniBroj.toString(),
                            packet.getAddress().toString());
                    
                    posaljiOdgovor(server, packet);

                } catch (IOException e) {
                    System.err.println("Doslo je do greske pri prijemu datagrama");
                    e.printStackTrace();
                    // postavka zadatka ne zahteva da se prekine sa radom servera
                }
            }

        } catch (SocketException e) {
            System.err.println("Doslo je do greske prilikom pokretanja servera");
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void posaljiOdgovor(DatagramSocket server, DatagramPacket packet) throws IOException {
        
        final byte[] buff = packet.getData();
        


        String imeFajla = new String();

        try (DataInputStream dis = new DataInputStream(new ByteArrayInputStream(buff))) {


            int duzinaImenaFajla = dis.readInt();
            imeFajla = new String(buff, 4, duzinaImenaFajla, StandardCharsets.UTF_8);
            dis.skipBytes(duzinaImenaFajla);
            int prvaLinija = dis.readInt();
            int drugaLinija = dis.readInt();

            byte[] responseBuff = procitajLinije(imeFajla, prvaLinija, drugaLinija);
            DatagramPacket packetToSend = new DatagramPacket(responseBuff, responseBuff.length, packet.getSocketAddress());
            server.send(packetToSend);
        }
        
        
    }

    private static byte[] procitajLinije(String imeFajla, final int prvaLinija, final int drugaLinija) throws IOException {

        try (

                BufferedReader fr = new BufferedReader(new FileReader(new File(servingFolder.getAbsolutePath() + '/' + imeFajla)));
                ByteArrayOutputStream baos = new ByteArrayOutputStream((drugaLinija - prvaLinija + 1) * 80)) {

                    final AtomicInteger redniBrLinije = new AtomicInteger(0);
                    final AtomicInteger velicinaProcitanog = new AtomicInteger(0);

                    Consumer<? super String> counter = (x) -> {
                        int redniBroj = redniBrLinije.incrementAndGet();
                        if (redniBroj >= prvaLinija && redniBroj <= drugaLinija) {
                            byte[] bytes = x.getBytes(StandardCharsets.UTF_8);
                            baos.writeBytes(bytes);
                            velicinaProcitanog.addAndGet(bytes.length);
                        }
                    };

                    fr.lines().forEach(counter);
                    return Arrays.copyOf(baos.toByteArray(), velicinaProcitanog.get());
        }

    }
}

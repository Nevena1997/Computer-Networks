package zad2;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

public class Client {

    private static final InetSocketAddress SERVER_ADDRESS = new InetSocketAddress(Server.PORT);
    private static String procitajLiniju(BufferedReader br, final String poruka) throws IOException {

        System.out.println(poruka);

        return br.readLine();
    }

    private static int procitajBroj(BufferedReader br, final String poruka) throws IOException {

        final String broj = procitajLiniju(br, poruka);

        // moze baciti runtime exception (NumberFormatException)
        return Integer.parseInt(broj);
    }

    private static void die(final String poruka) {
        System.err.println(poruka);
        System.exit(1);
    }

    public static void main(final String[] args) {

        final String imeFajla;
        final int prvaLinija;
        final int drugaLinija;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            imeFajla = procitajLiniju(br, "Unesite ime fajla:");

            if (imeFajla.length() > Server.MAX_FILENAME_LENGTH) {
                die("Ime fajla ne sme biti duze od " + (Server.MAX_FILENAME_LENGTH));
            }

            prvaLinija = procitajBroj(br, "Unesite redni broj prve linije:");
            if (prvaLinija < 0) {
                die("Redni broj prve linije ne sme biti negativan");
            }

            drugaLinija = procitajBroj(br, "Unesite redni broj druge linije:");

            if (prvaLinija > drugaLinija) {

                die("Redni broj prve linije ne sme biti veci od rednog broja druge linije");
            }

            try (DatagramSocket socket = new DatagramSocket()) {
                posaljiPaket(socket, imeFajla, prvaLinija, drugaLinija);
                final DatagramPacket packet = primiPaket(socket);
                ispisi(packet);
            } catch (IOException e) {
                System.err.println("Doslo je do greske pri slanju paketa");
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
            die("Doslo je do greske pri unosu podataka");
        }


    }

    private static void ispisi(DatagramPacket packet) throws IOException {

        try (
                BufferedReader br = new BufferedReader(
                new InputStreamReader(
                        new ByteArrayInputStream(packet.getData()),
                        StandardCharsets.UTF_8))) {

            // TODO: moze i baferisano
            br.lines().forEach(System.out::println);
        }


    }

    private static void posaljiPaket(DatagramSocket socket, String imeFajla, int prvaLinija, int drugaLinija) throws IOException {


        try (
        ByteArrayOutputStream baos = new ByteArrayOutputStream(Server.MAX_REQUEST_SIZE_IN_BYTES);
        DataOutputStream daos = new DataOutputStream(baos)) {

            daos.writeInt(imeFajla.length());
            daos.write(imeFajla.getBytes(StandardCharsets.UTF_8));
            daos.writeInt(prvaLinija);
            daos.writeInt(drugaLinija);

            byte[] buff = baos.toByteArray();

            DatagramPacket packet = new DatagramPacket(buff, buff.length, SERVER_ADDRESS);
            socket.send(packet);
        }
    }

    private static DatagramPacket primiPaket(DatagramSocket socket) throws IOException {

        final byte[] buff = new byte[Server.MAX_RESPONSE_SIZE_IN_BYTES];
        DatagramPacket packet = new DatagramPacket(buff, buff.length);
        socket.receive(packet);

        return packet;
    }
}

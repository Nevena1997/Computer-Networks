package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.CountDownLatch;

public class Server {

    private static final CountDownLatch countDownLatch = new CountDownLatch(5);
    private static final Set<Socket> sockets = Collections.synchronizedSet(new HashSet<>());
    private static final Map<Socket, Long> socketsTimings = Collections.synchronizedMap(new HashMap<>());
    private static final List<String> pitanja = new ArrayList<>();

    public static final int PORT = 12321;
    public static void main(String[] args) {

        String imeFajla = "";

        try (Scanner sc = new Scanner(System.in)) {

            if (sc.hasNext()) {
                imeFajla = sc.next(".*");
            }
        }

        if (imeFajla.isEmpty()) {
            System.err.println("Ime fajla ne moze biti prazno");
            System.exit(1);
        }

        File f = new File(imeFajla);

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {

            br.lines().forEach(x -> pitanja.add(x));

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Greska pri citanju fajla");
            System.exit(1);
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {

            while (true) {
                Socket client = serverSocket.accept();
                sockets.add(client);
                countDownLatch.countDown();

                if (countDownLatch.getCount() == 0) {
                    break;
                }
            }

            for (final Socket socket : sockets) {

                try (OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream())) {

                    osw.write("Kviz pocinje sada. Srecno!");
                }
            }

            while (true) {

                for (final String pitanje : pitanja) {
                    for (final Socket socket : sockets) {

                        try (OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream())) {

                            osw.write(pitanje);
                        }

                    }

                }

                // TODO: dodaj da bude uslovno
                break;
            }

            for (final Socket socket : sockets) {

                try (OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream())) {

                    osw.write("Kviz je zavrsen!");
                }
            }


        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Doslo je do greske");
        }
    }
}

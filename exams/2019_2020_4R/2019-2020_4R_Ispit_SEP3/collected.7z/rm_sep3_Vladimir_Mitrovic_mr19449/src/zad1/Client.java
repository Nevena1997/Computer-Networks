package zad1;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        String imeKlijenta = "";

        try (Scanner sc = new Scanner(System.in)) {

            if (sc.hasNext()) {
                imeKlijenta = sc.next(".*");
            }
        }

        if (imeKlijenta.isEmpty()) {
            System.err.println("Ime klijenta ne moze biti prazno");
            System.exit(1);
        }

        try (
            Socket socket = new Socket("localhost", Server.PORT );
            OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream())) {
            osw.write(imeKlijenta);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Doslo je do greske");
            System.exit(1);
        }

    }
}

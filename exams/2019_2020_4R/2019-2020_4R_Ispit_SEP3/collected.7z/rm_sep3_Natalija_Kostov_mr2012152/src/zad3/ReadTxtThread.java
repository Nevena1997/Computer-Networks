package zad3;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ReadTxtThread extends Thread{

    private URL url;
    private int broj_pojavljivanja;
    private char c;

    ReadTxtThread(URL url, char c){
        this.url = url;
        this.c = c;
    }

    public int getBroj_pojavljivanja() {
        return this.broj_pojavljivanja;
    }

    @Override
    public void run() {
        String filePath = url.getPath();
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {
            String line;
            int br = 0;
            while((line = in.readLine()) != null) {
                char[] l = line.toCharArray();

                for (int i = 0; i < l.length; i++) {
                    if (l[i] == this.c) {

                        br++;
                    }
                }
            }
            this.broj_pojavljivanja = br;
            Thread.yield();

        }catch(FileNotFoundException e){
            System.out.println("File not found" + url.toString());
            Thread.yield();
        }catch(IOException e){
            e.printStackTrace();
        }


    }
}

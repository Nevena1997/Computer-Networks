package zad3;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int br_karaktera = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Unesite karakter za pretragu: ");
        String data = sc.next().trim();
        if(data.length() != 1){
            System.err.println("Morate uneti 1 karakter");
            return;
        }
        char c = data.charAt(0);
        try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("/home/ispit/Desktop/tests/urls.txt")))){
            String line;
            int i = 0;
            while((line = in.readLine())!=null){
                i++;
                try {
                    URL url = new URL(line.trim());
                    if(line.startsWith("FILE") && line.endsWith(".txt")){
                        ReadTxtThread parser = new ReadTxtThread(url,c);
                        parser.start();
                        br_karaktera+=parser.getBroj_pojavljivanja();
                    }
                }catch(MalformedURLException e){
                    continue;
                }
            }
            System.out.println("Broj pojavljianja: " + c + " je " + br_karaktera);
            System.out.println("Broj linija u fajlu: " + i);
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

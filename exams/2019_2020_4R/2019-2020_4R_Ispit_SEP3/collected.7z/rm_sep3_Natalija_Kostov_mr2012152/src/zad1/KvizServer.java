package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class KvizServer {

    public static final int DEFAULT_PORT = 12321;

    public static void main(String[] args) {
        List<String> imenaTakmicara = new ArrayList<String>();
        List<Socket> takmicari = new ArrayList<Socket>();
        try(ServerSocket server = new ServerSocket(DEFAULT_PORT)){
            Scanner sc = new Scanner(System.in);
            String file = sc.nextLine();
            while(imenaTakmicara.size() < 5){
                Socket takmicar = server.accept();
                try(BufferedReader in = new BufferedReader(new InputStreamReader(takmicar.getInputStream()))){
                    String name = in.readLine();
                    imenaTakmicara.add(name);
                    takmicari.add(takmicar);
                }
            }
            for(Socket s : takmicari){
                try(BufferedWriter out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()))){
                    out.write("Kviz pocinje sada. Srecno! ");
                    out.newLine();
                }
            }



        }catch(IOException e){
            e.printStackTrace();
        }
    }
}

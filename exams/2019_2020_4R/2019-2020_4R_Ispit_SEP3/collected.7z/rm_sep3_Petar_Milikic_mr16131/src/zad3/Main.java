package zad3;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try(BufferedReader br=new BufferedReader(
                new InputStreamReader(
                        new FileInputStream("/home/ispit/Desktop/tests/urls.txt")
                )
        );
            Scanner sc=new Scanner(System.in)
        )
        {
            String linija=null;
            int brojac=0;
            System.out.println("ulaz: ");
            String karakter=sc.nextLine().trim();
            if(karakter.length()!=1)
            {
                System.err.println("karakter nije velicine 1!!!");
                System.exit(1);
            }
            int brojacKaraktera=0;

            while ((linija=br.readLine())!=null)
            {
                brojac++;
              // System.out.println(linija);
                try {
                    URL u=new URL(linija);
                    //System.out.println(linija);
                    System.out.println("\t"+"protokol: "+protokol(linija));

                    System.out.println("\t"+jesteTXT(linija));
                    if(jesteTXT(linija)&&protokol(linija).equalsIgnoreCase("FILE")) {
                        URLConnection konekcija = u.openConnection();
                        System.out.println(linija);
                        try (
                                BufferedReader citac = new BufferedReader(
                                        new InputStreamReader(konekcija.getInputStream()
                                                , StandardCharsets.UTF_8))) {
                            String zaPretragu=citac.readLine();
                            String niz[]=zaPretragu.split(" ");
                            for(String s:niz)
                            {
                                if(s.indexOf(karakter)!=-1)
                                    brojacKaraktera++;
                            }


                        }
                    }


                }
                catch (IOException e)
                {
                    System.err.println("not found");

                }
                catch (Exception e)
                {
                   // System.out.println("procitan nevalidan URL,linija: "+brojac);
                    continue;
                }

            }
            System.out.println("result: "+brojacKaraktera);

        } catch (FileNotFoundException e) {
            System.err.println("Nije pronadjen fajl!");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Neka druga greska!");
            e.printStackTrace();
        }
    }
    public  static String protokol(String linija)
    {
        int poz=linija.indexOf(':');
        return linija.substring(0,poz);
    }
    public  static boolean jesteTXT(String linija)
    {
        return linija.contains(".txt");
    }
}

import zad1.Server;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Klijent {

    public static void main(String[] args) {
        try(Socket klijent=new Socket("localhost", Server.PORT);
            Scanner sc=new Scanner(System.in);
            BufferedWriter bw=new BufferedWriter(
                    new OutputStreamWriter(
                            klijent.getOutputStream()
                    )
            ))
        {
            System.out.println("Ime klijenta: ");
            String ime=sc.next();
            bw.write(ime);
            bw.newLine();
            try(BufferedReader citac=new BufferedReader(
                    new InputStreamReader(
                            klijent.getInputStream()
                    )
            ))
            {
                String tmp;
                tmp=citac.readLine();
                System.out.println(tmp);
                while ((tmp=citac.readLine())!=null)
                {


                    System.out.println("stampamo pitanje: ");
                    System.out.println(tmp);
                    System.out.println("Stampamo ponudjene odgovore: ");
                    tmp=citac.readLine();
                    System.out.println(tmp);
                    tmp=citac.readLine();
                    System.out.println(tmp);
                    tmp=citac.readLine();
                    System.out.println(tmp);
                    tmp=citac.readLine();
                    System.out.println(tmp);
                    System.out.println("Imate 10 sekundi da date odgovor: ");
                    tmp=sc.nextLine();
                    System.out.println("Saljemo odgovor: ");
                    bw.write(tmp);

                }
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

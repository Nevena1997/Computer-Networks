package zad1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Server {
    public static  int PORT=12321;

    public static void main(String[] args) {
        try(ServerSocket server=new ServerSocket(PORT);
            Scanner sc=new Scanner(System.in)

        )
        {
            System.out.println("Unesite naziv tekstualnog fajla: ");
            String fajl=sc.next();

                BufferedReader citacFajla=new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(fajl)
                    ));


          /*  catch (IOException e1)
            {
                System.err.println("Fajl nije lepo ucitan!");
                e1.printStackTrace();
                System.exit(1);
            }

           */
          int i=0;
            ArrayList<Socket> klijenti=new ArrayList<>();
            while (i<5)
            {
                System.err.println("*");
                Socket klijent=server.accept();
                klijenti.add(klijent);
               /* try(BufferedReader br=new BufferedReader(
                        new InputStreamReader(klijent.getInputStream())
                ))
                {
                    String poruka=br.readLine();
                    System.out.println(poruka);
                }

                */

            }
            i=0;

                //try
                    /*(BufferedWriter bw=new BufferedWriter(
                        new OutputStreamWriter(klijenti.get(i).getOutputStream())
                ))
                */

                    while(i<5) {
                        BufferedWriter bw=new BufferedWriter(
                                new OutputStreamWriter(klijenti.get(i).getOutputStream()));
                        bw.write("Kviz pocinje sada. Srecno!");
                        bw.newLine();
                    }

                    String tmp=null;
                    while ((tmp=citacFajla.readLine())!=null)
                    {
                        BufferedWriter bw=new BufferedWriter(
                                new OutputStreamWriter(klijenti.get(i).getOutputStream()));
                        bw.write("Pitanje glasi: \n");
                        bw.write(tmp);
                        bw.write("\tponudjeni odgovori: ");
                        String tmp1=citacFajla.readLine();
                        bw.write(tmp1);
                        String tmp2=citacFajla.readLine();
                        bw.write(tmp2);
                        String tmp3=citacFajla.readLine();
                        bw.write(tmp3);
                        String tmp4=citacFajla.readLine();
                        bw.write(tmp4);
                    }
                    System.out.println("Kviz je zavrsen!");



        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println("Neka druga neocekivana greska!!!");
            e.printStackTrace();
        }
    }
}

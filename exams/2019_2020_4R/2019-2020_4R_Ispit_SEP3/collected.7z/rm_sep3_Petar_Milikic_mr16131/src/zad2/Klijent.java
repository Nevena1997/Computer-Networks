package zad2;

import javax.sql.DataSource;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import static java.net.InetAddress.*;

public class Klijent {
    public static void main(String[] args) {
        try(Scanner sc=new Scanner(System.in);
            DatagramSocket klijent=new DatagramSocket()
        )
        {
            InetAddress adresa= getByName("localhost");
            String linija=sc.nextLine();
            DatagramPacket req=new DatagramPacket(new byte[1],1,adresa,Server.PORT);
            klijent.send(req);
            DatagramPacket paket=new DatagramPacket(linija.getBytes(),linija.getBytes().length,adresa,Server.PORT);
            klijent.send(paket);
            DatagramPacket prijem=new DatagramPacket(new byte[1024],1024,adresa,Server.PORT);
            klijent.receive(prijem);
            System.out.println("Primljeno!");
            System.out.println(new String(prijem.getData(),0,prijem.getLength(), StandardCharsets.UTF_8));
        } catch (UnknownHostException | SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

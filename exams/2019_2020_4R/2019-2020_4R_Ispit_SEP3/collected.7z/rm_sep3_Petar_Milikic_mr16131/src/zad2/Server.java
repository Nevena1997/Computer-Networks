package zad2;

import javax.xml.crypto.Data;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Server {
    public static int PORT=12121;

    public static void main(String[] args) {

        try(Scanner sc=new Scanner(System.in);
            DatagramSocket server=new DatagramSocket(PORT)
            )
        {
            System.out.println("*Pocetak");
            String folder=sc.next().trim();
            int brojac=0;
            while (true)
            {

                brojac++;
                DatagramPacket req=new DatagramPacket(new byte[1024],1024);
                server.receive(req);
              //  System.out.println("klijent*1");
                DatagramPacket prijem=new DatagramPacket(new byte[1024],1024,req.getAddress(),PORT);
              //  System.out.println("klijent*2");
                server.receive(prijem);
              //  System.out.println("klijent*3");
                System.out.println("Redni broj paketa: "+brojac);
                System.out.println("IP adresa posiljaoca: "+req.getAddress());
                String primljen=new String(prijem.getData(),0,prijem.getLength(), StandardCharsets.UTF_8);
                String niz[]=primljen.split(" ");
                String ime=null;
                int br1=0,br2=0;
                ime=folder+niz[0];
                br1=Integer.parseInt(niz[1]);
                br2=Integer.parseInt(niz[2]);
                System.out.println("\t"+ime);
                System.out.println("\t"+br1);
                System.out.println("\t"+br2);
                String put=folder+"/"+ime;

                try(BufferedReader citac=new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(ime)
                        )
                ))
                {
                    int brojacLinija=0;
                    String linija=null;
                    String sadrzaj="";
                    while ((linija=citac.readLine())!=null)
                    {
                        if(brojac>=br1&&brojac<=br2) {
                            sadrzaj += linija;
                            linija += "\n";
                        }
                    }
                    DatagramPacket Linija=new DatagramPacket(sadrzaj.getBytes(),sadrzaj.getBytes().length,req.getAddress(),PORT);
                    server.send(Linija);


                }





                System.out.println("\n---------------------\n");

            }



        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}

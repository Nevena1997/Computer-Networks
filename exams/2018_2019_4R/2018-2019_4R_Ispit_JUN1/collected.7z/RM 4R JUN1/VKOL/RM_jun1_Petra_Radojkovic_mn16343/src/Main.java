import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fajl = sc.next();
        sc.close();

        Scanner in = null;
        BufferedWriter bf = null;
        try {
            in = new Scanner(new InputStreamReader(new FileInputStream(fajl), "UTF-8"));
            bf = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("phonenumbers.txt"), "UTF-8"));

            String str;
            while (in.hasNext()){
                str = in.next();
                if (daLiJeBroj(str)){
                    bf.write(str);
                    bf.newLine();
                }
            }

        } catch (Exception e) {
        e.printStackTrace();
        }
        finally {
            try{
            if (in != null){
                in.close();
            }
            if (bf!=null){
                bf.flush();
                bf.close();
            }
            }
            catch (IOException a){
                a.printStackTrace();
            }
        }
    }

    public static boolean daLiJeBroj(String str){
        if(str.length() < 13){
            return false;
        }
        if (str.charAt(0) != '+' || str.charAt(4) != '/'){
            return false;
        }
            for (int i = 1; i<str.length(); i++){
            if (i==4 || i==9){
                continue;
            }
            else{
                if (!Character.isDigit(str.charAt(i))){
                    return false;
                }
            }
            }

        return true;
    }
}

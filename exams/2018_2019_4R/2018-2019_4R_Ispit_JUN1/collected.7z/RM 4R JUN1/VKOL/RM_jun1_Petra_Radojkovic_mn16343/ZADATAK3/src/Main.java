import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try {
            FileInputStream fin = new FileInputStream("logfajl.txt");
            Scanner sc = new Scanner(fin);



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

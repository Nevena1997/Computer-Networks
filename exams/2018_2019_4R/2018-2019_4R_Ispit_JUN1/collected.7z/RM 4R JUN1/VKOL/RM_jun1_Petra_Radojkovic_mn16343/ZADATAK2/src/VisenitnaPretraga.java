public class VisenitnaPretraga implements Runnable{
    private String[] fajl;

    public VisenitnaPretraga (String[] fajl){
        this.fajl = fajl;
    }

    @Override
    public void run() {

    }
}

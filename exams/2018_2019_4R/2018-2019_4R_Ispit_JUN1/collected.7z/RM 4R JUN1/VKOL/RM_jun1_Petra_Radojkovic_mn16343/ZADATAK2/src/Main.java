import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String putanja = sc.next();

       try{
            Scanner sc1;
            FileInputStream fin = new FileInputStream(putanja);
            sc1 = new Scanner(fin);

        int i = 0;
        String[] putanje = new String[100];
        while (sc1.hasNext()){
            putanje[i] = sc1.next().trim();
            i++;
        }
        int n = i;
        sc1.close();

        for (i=0; i<n; i++){
            System.out.println(putanje[i]);
        }

        String key; int n1;
        System.out.println("UNESITE KLJUCNU REC ZA PRETRAGU I BROJ n: ");
        key = sc.next();
        key.trim();
        n1 = sc.nextInt();

        for (i = 0; i<n; i++){
            pretrazi(putanje[i],key);
        }
        sc.close();

    }
    catch(Exception e){
           e.printStackTrace();
    }
}

public static void pretrazi(String putanja, String key)
{
    try {
        FileInputStream fin1 = new FileInputStream(putanja);
        InputStreamReader ir = new InputStreamReader(fin1, "UTF-8");
        Scanner sc4 = new Scanner(ir);
        int k = 0;
        while (sc4.hasNext()) {
            if (sc4.next().equals(key)) {
                System.out.println("Putanja: " + putanja + " : " + "broj_linije: s" + (k+1));
            }
            k++;
        }
        sc4.close();
    }
    catch (Exception e){
        e.printStackTrace();
    }
}


}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class zad1 {

	public static void main(String[] args)
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			String file = sc.nextLine();
			sc.close();
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("phonenumbers.txt"),"UTF-8"));
			String s = new String();
			byte[] b = s.getBytes(StandardCharsets.UTF_8);
			s= new String(b,StandardCharsets.UTF_8);
			String reg = "^[+][0-9][0-9][0-9][/][0-9][0-9][0-9][0-9][-][0-9][0-9][0-9]$";
			while((s=in.readLine())!= null)
			{
				if(s.contains("+")&& s.length()>13)
				{
					s=s.substring(s.indexOf("+"),s.indexOf("+")+13);
				}
				if(s.matches(reg))
				{
					out.write(s);
					out.newLine();
				}
			}
			in.close();
			out.close();
			System.out.println("Gotovo!");
		}
		catch(UnsupportedEncodingException e)
		{
			System.err.println("ne podrzava UTF-8");
		}
		catch(FileNotFoundException e)
		{
			System.err.print("nema fajla");
		}
		catch(IOException e)
		{
			System.err.println("greska kod ispisa");
		}

	}
}

package drugi;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Unesite datoteku:");
		String startingDir=sc.nextLine();
		System.out.println("Unesite trazenu rec:");
		String keyword=sc.nextLine();
		System.out.println("Unesite zeljeni broj niti:");
		int n=sc.nextInt();

		sc.close();

		BlockingQueue<Path> queue=new ArrayBlockingQueue<>(10000);

		try {
			Scanner in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(startingDir))));
			while(in.hasNextLine()) {
				String file=in.nextLine();
				Path p=Paths.get(file);
				queue.put(p);
			}
			in.close();
		}
		catch (FileNotFoundException e) {
			new RuntimeException("File not found.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		for(int i=0; i<n; i++) {
			Search s=new Search(queue, keyword);
			Thread t=new Thread(s);
			t.start();
		}
	}
}
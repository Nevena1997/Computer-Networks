package drugi;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Search implements Runnable {

	private BlockingQueue<Path> queue;
	private String keyword;

	public Search(BlockingQueue<Path> queue, String keyword) {
		this.queue = queue;
		this.keyword = keyword;
	}

	@Override
	public synchronized void run() {
		while(true) {
		try {
			Path p=this.queue.take();
			if(p.toString().equals(""))
				return;
			else {
				Scanner in =new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(p.toString()))));
				int num1=0;
				while(in.hasNextLine()) {
					int num2=0;
					String line=in.nextLine();
					num1++;
					String[] reci=line.split(" ");
					for(int i=0; i<reci.length; i++) {
						if(reci[i].equals(keyword))
							System.out.printf("nit_%d:%s:%d:%d\n",
								Thread.currentThread().getId(), p.toAbsolutePath().toString(), num1, num2);
						num2+=reci[i].length()+1;
					}
				}
				in.close();
				this.queue.put(Paths.get(""));
			}
		}
		catch (FileNotFoundException e) {
			new RuntimeException("File not found.");
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		}

	}

}
package zad2;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class SearchFiles {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		String fajl = sc.next();
		Scanner sc1=new Scanner(new File(fajl));
		List<String> l = new ArrayList<String>();
		while(sc1.hasNext()){
			String s = sc1.nextLine();
			l.add(s);
			System.out.println(s);
		}
		sc1.close();
		String kljuc = sc.next();
		int n=Integer.parseInt(sc.next());
		sc.close();
		List<Search> niti = new ArrayList<Search>(n);
		Search.o=new Indeks(0,l,kljuc);
		for(int i = 0;i<n;++i){
			Search nit =new Search();
			niti.add(nit);
			nit.start();
		}
	}
}
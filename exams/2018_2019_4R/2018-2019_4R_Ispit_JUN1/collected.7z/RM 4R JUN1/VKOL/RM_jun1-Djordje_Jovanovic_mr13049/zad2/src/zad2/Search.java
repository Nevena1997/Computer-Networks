package zad2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

class Indeks{
	int i;
	List<String> fajlovi;
	String kljuc;
	public Indeks(int i, List<String> fajlovi, String kljuc) {
		super();
		this.i = i;
		this.fajlovi = fajlovi;
		this.kljuc = kljuc;
	}
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public List<String> getFajlovi() {
		return fajlovi;
	}
	public void setFajlovi(List<String> fajlovi) {
		this.fajlovi = fajlovi;
	}
	public String getKljuc() {
		return kljuc;
	}
	public void setKljuc(String kljuc) {
		this.kljuc = kljuc;
	}
}

public class Search extends Thread {
	static Indeks o;
	static int br_pokrenutih_niti = 1;
	@Override
	public void run() {
		int id=br_pokrenutih_niti++;
		while(true){
			int i;
			synchronized (o) {
				i=o.getI();
				o.setI(i+1);
			}
			if(i>=o.getFajlovi().size()) break;
			Scanner sc = null;
			try {
				sc = new Scanner(new File(o.getFajlovi().get(i)));
				int br_linije = 0;
				while(sc.hasNextLine()){
					br_linije++;
					String linija = sc.nextLine();//System.out.println(linija);
					String reci[] = linija.split("[ \t]");
					int poz = 0;
					for(String rec:reci){
						if(rec.equals(o.getKljuc()))
							System.out.println("nit_"+id+":"+o.getFajlovi().get(i)+":"+br_linije+":"+poz);
						poz+=rec.length()+1;
					}
				}
			} catch (FileNotFoundException e) {
				//e.printStackTrace();
			}finally{
				if(sc!=null) sc.close();
			}
		}
	}
}

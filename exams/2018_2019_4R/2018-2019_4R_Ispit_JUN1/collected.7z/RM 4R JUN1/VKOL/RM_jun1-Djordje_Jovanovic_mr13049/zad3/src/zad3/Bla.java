package zad3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Bla {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String path = sc.next();
		sc.close();
		URL u = null;
		Scanner in = null;
		try{
			u=new URL("FILE:///C:\\Users\\nalog\\workspace\\zad3\\ulaz.txt");
			in = new Scanner(new BufferedReader(new InputStreamReader(u.openStream())));
			while(in.hasNext()){
				String linija = in.nextLine();
				String reci[] = linija.split("[|]");
				String datum = reci[0].trim();
				String ipadr = reci[1].trim();
				String urldores=reci[2].trim();
				URL url = new URL(urldores);
				String prot = url.getProtocol();
				if(prot.equalsIgnoreCase("http")||prot.equalsIgnoreCase("sftp")){
					if(ipadr.contains(":")) System.out.printf("v6|");
					else System.out.printf("v4|");
					System.out.printf(prot);
					System.out.println("|"+url.getPath());
				}
			}
		}catch(MalformedURLException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(in!=null) in.close();
		}
	}

}

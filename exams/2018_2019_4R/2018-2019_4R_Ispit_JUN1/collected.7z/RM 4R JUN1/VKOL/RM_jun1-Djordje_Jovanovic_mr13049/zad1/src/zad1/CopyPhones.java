package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class CopyPhones {

	public static void main(String[] args) {
		Scanner sc = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			sc = new Scanner(System.in);
			String fajl = sc.next();
			sc.close();
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fajl), "UTF-8"));
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("phonenumbers.txt"), "UTF-8"));
			sc = new Scanner(br);
			while(sc.hasNext()){
				String s = sc.next();
				if(phone(s)) bw.write(s+"\r\n");
			}
		} catch (UnsupportedEncodingException e) {
			System.out.println("Nepodrzaa kodna strana.");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			System.out.println("Fajl nije pronadjen.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Problem sa ulazom/izlazom.");
			e.printStackTrace();
		}finally{
			if(sc!=null) sc.close();
			try {
				if(br!=null) br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if(bw!=null) bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static boolean phone(String s) {
		if(s.length()!=13 || s.charAt(0)!='+' || s.charAt(4)!='/' || s.charAt(9)!='-') return false;
		for(int i =1;i<13;++i){
			if(i==4 || i==9)continue;
			if(s.charAt(i)<'0' || s.charAt(i)>'9') return false;
		}
		return true;
	}

}
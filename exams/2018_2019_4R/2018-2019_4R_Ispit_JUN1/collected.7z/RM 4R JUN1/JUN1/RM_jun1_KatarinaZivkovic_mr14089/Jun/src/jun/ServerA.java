package jun;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 12345;
		try(ServerSocket server = new ServerSocket(port)){
			System.out.println("server startovan na portu"+port);
			while(true){
				Socket client = server.accept();
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				String s = in.readLine();

				try{
					int br = Integer.parseInt(s);
					System.err.println("Stigao paket");
				}catch(NumberFormatException e){
					continue;
				}



				in.close();
				client.close();

			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}

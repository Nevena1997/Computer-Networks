package jun;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;


import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Swing {


	public static void main(String[] args) {

		JFrame f = new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);
		f.setFocusable(true);
		f.setResizable(true);

		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run(){
				f.setVisible(true);
			}
		});


	}

	private static void addComponents(Container pane) {
		// TODO Auto-generated method stub
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		pane.add(scroll,c);

		JTextArea text = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(text,c);



		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				try {

						URL url = new URL(text.getText());
						BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
						String s;
						String ceo = "";
						while((s =in.readLine())!=null){
							ceo = ceo+s;
							ceo = ceo+ "\r\n";
						}
						 jep.setText(ceo);
						 in.close();


				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		c.gridx = 1;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(prikazi,c);

		JButton sacuvaj = new JButton("Sacuvaj");
		sacuvaj.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				try {
					String put = text.getText();
					String putanja = "";
					for(int i = 8;i<put.length();i++)
						putanja = putanja+put.charAt(i);
					System.out.println(putanja);
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(putanja)));
					String novo = jep.getText();
					out.write(novo);
					out.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


			}
		});
		c.gridx = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(sacuvaj,c);




	}

}

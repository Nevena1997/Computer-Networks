package jun;

public class LinkHandler {

}

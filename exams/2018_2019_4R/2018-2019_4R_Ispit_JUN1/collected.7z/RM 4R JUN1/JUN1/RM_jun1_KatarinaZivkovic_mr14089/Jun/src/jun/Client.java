package jun;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 12345;
		String host = "localhost";
		BufferedReader in = null;
		BufferedWriter out = null;
		Scanner sc = null;
		int n;

		try(Socket sock=new Socket(host,port)) {
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			sc = new Scanner(System.in);
			System.out.println("Unesite broj slanja");
			n = sc.nextInt();
			int i = 1;

			Random rand = new Random();
			int br = rand.nextInt();

			out.write(br);
			out.newLine();
			out.flush();
			while(i<n){

				if(in.readLine()!=null){
					Random rand1 = new Random();
					int br1 = rand1.nextInt(1000);

					out.write(br1);
					out.newLine();
					out.flush();
					i++;
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				if(out!=null)
					out.close();
				if(sc!=null)
					sc.close();
				if(in!=null)
					in.close();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}



	}
	}
}


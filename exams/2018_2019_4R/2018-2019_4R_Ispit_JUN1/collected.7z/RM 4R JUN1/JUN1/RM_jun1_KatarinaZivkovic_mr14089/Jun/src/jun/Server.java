package jun;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Server {
	private static int S = 0;
	private static int brojac = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 12345;
		ByteBuffer buffer = ByteBuffer.allocate(6);

		try(ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()){
			serverChannel.bind(new InetSocketAddress(port));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);
			System.err.println("server startovan na portu"+port);
			while(true){
				selector.select();
				Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
				while(iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();
					try{
						if(key.isAcceptable()){
							ServerSocketChannel server = (ServerSocketChannel)key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							client.register(selector, SelectionKey.OP_READ);
						}else if(key.isReadable()){
							SocketChannel client = (SocketChannel)key.channel();
							ByteBuffer buff = ByteBuffer.allocate(5);
							client.read(buff);
							int br = buff.get();
							//String clientNum = sb.toString();
							System.err.println(br);
							S = S + br;
							brojac++;
							if(brojac == 5){
								System.err.println(S);
								brojac = 0;
							}
							byte[] poruka = new byte[4];
							poruka[0] = (byte)((int)'O');
							poruka[1] = (byte)((int)'k');
							ByteBuffer newb = buffer.duplicate();
							newb.put(poruka,0,2);
							newb.put((byte)'\r');
							newb.put((byte)'\n');
							newb.flip();
							key.attach(newb);
							key.interestOps(SelectionKey.OP_WRITE);


						}else if(key.isWritable()){
							SocketChannel client = (SocketChannel)key.channel();
							ByteBuffer buff = (ByteBuffer)key.attachment();
							if(buff.hasRemaining()){
								client.write(buff);

							}else
								client.close();

						}
					}catch(IOException e){
						key.cancel();
						try {
							key.channel().close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
			}catch(IOException e){
				e.printStackTrace();
			}

	}

}

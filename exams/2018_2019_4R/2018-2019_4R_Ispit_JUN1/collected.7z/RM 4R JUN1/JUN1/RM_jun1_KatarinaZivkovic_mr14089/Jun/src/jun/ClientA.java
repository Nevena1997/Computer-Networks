package jun;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Random;

public class ClientA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 12345;
		String host = "localhost";
		BufferedWriter out = null;


		try(Socket sock=new Socket(host,port)) {
			out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			while(true){
				Random rand = new Random();
				int br = rand.nextInt();

				out.write(br);
				out.newLine();
				out.flush();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				if(out!=null)
					out.close();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}



	}
	}
}


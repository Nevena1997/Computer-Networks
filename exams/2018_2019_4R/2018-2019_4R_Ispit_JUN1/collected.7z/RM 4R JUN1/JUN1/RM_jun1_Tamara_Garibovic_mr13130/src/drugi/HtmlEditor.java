package drugi;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HtmlEditor {

	public static void main(String[] args) {
JFrame f=new JFrame("HTML Editor");

f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
f.setSize(800, 600);
addComponents(f.getContentPane());
//Event.Queue.invokeLater()
f.setVisible(true);

	}

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		JEditorPane jep=new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane=new JScrollPane(jep);
		//GridBagConstraints.

		//c.fill=GridBagConstraints.BOTH;
		//c.gridx=

		JLabel lbl=new JLabel();
		JButton btn1=new JButton("Prikazi");

		JButton btn2=new JButton("Sacuvaj");

		JTextArea addressBar=new JTextArea();

	}

}

package Zadatak_02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	JEditorPane jep;
	JTextArea area;
	StringBuilder contents;

	public LinkHandler(JEditorPane jep, JTextArea area) {
		this.jep = jep;
		this.area = area;
		contents = new StringBuilder();
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
		HyperlinkEvent.EventType type  = evt.getEventType();

		if(type ==  HyperlinkEvent.EventType.ACTIVATED){
			URL u = evt.getURL();
			String file = u.getFile();

			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
				String linija = null;
				while((linija = br.readLine())!=null)
					contents.append(linija);
			} catch (FileNotFoundException e) {
				jep.setText("Unet URL ne vodi ni do kojeg html dokumenta");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void prikazi() {
		String s = area.getText();
		try {
			URL u = new URL(s);
			String file = u.getFile();

			contents = null;

			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String linija = null;

			while((linija = br.readLine())!=null)
				contents.append(linija);

			jep.setText(contents.toString());
		} catch (MalformedURLException e) {
			jep.setText("Unet URL ne vodi ni do kojeg html dokumenta");

		} catch (FileNotFoundException e) {
			jep.setText("Unet URL ne vodi ni do kojeg html dokumenta");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void ocisti() {
		String tekst = contents.toString();
		char[] prom = tekst.toCharArray();

		StringBuilder sb = new StringBuilder();

		for(int i=0; i<prom.length;i++){
			//kopiramo karaktere na i-toj poziciji
			//medjutim zelimo da preskocimo sve izmedju <> i same < i >
			//vrsimo proveru da li smo naleteli na <
			if(prom[i] == '<'){
				//ako jesmo, zelimo da skipujemo sve te karaktere i >
				for(int j=i;j<prom.length;j++){
					if(prom[j]=='>'){
						i=j+1;
						//opasnost ako je poslednji tag
						break;
					}
				}

			}
			if(i<prom.length)
				sb.append(prom[i]);
		}

		jep.setText(sb.toString());

	}




}

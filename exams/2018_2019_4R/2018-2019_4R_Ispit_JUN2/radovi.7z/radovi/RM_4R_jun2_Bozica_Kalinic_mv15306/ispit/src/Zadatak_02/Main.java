package Zadatak_02;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {

		JFrame frame = new JFrame("Ukloni HTML tagove");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 600);
		addComponents(frame);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}

	private static void addComponents(JFrame frame) {
		frame.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();


		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.fill = GridBagConstraints.BOTH;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 3;

		frame.add(jsp, c);



		JTextArea area = new JTextArea("Unesite URL :)");
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		//c.anchor = GridBagConstraints.BELOW_BASELINE;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.gridheight = 1;
		c.gridwidth = 1;

		frame.add(area, c);

		LinkHandler lh = new LinkHandler(jep, area);
		jep.addHyperlinkListener(lh);

		JButton prikazi  = new JButton("Prikazi");
		c.gridx = 1;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.fill = GridBagConstraints.NONE;
		//c.anchor = GridBagConstraints.LAST_LINE_END;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		c.gridheight = 1;
		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.prikazi();

			}
		});

		frame.add(prikazi, c);


		JButton ocisti  = new JButton("Ocisti");
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.fill = GridBagConstraints.NONE;
		//c.anchor = GridBagConstraints.LAST_LINE_END;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		c.gridheight = 1;

		ocisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.ocisti();

			}
		});

		frame.add(ocisti, c);

	}

}

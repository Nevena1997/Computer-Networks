package Zadatak_01;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class Nit extends Thread{

	Server server;
	List<String> sadrzaj;
	List<Integer> poslati;
	ReentrantLock lock;

	public Nit(Server s, List<String> sadrzaj, List<Integer> poslati){
		server = s;
		this.sadrzaj = sadrzaj;
		this.poslati = poslati;
	}

	@Override
	public void run() {
		try{
			Socket sock = server.carapa.accept();

			OutputStream out = sock.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(out);
			BufferedWriter bw = new BufferedWriter(osw);

			int n = sock.getInputStream().read();
			String linija = "Ne postoji";


			if(n < sadrzaj.size() && poslati.get(n)==0){
				linija = sadrzaj.get(n);
				poslati.set(n, 1);
			}

			bw.write(linija);


			bw.close();
			osw.close();
			out.close();
			sock.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}

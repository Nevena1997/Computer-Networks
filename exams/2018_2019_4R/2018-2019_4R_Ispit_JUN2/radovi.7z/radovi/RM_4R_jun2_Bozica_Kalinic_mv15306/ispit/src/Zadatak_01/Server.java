package Zadatak_01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

public class Server{

	public static final int PORT = 12345;
	ServerSocket carapa;
	List<String> sadrzaj;
	List<Integer> poslate;

	public Server() throws IOException{
		carapa = new ServerSocket(PORT);
		FileInputStream fin = new FileInputStream("src/serverfile.txt");
		InputStreamReader isr = new InputStreamReader(fin);
		BufferedReader br = new BufferedReader(isr);

		sadrzaj = new ArrayList<String>();
		poslate = new ArrayList<Integer>();

		String linija = null;
		while((linija = br.readLine())!=null){
			sadrzaj.add(linija);
			poslate.add(0);
		}

		br.close();
		isr.close();
		fin.close();
	}




	public static void main(String[] args) {

		try{
			Server s = new Server();
			while(true){
					Nit nit = new Nit(s, s.sadrzaj, s.poslate);
					nit.run();

			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
}

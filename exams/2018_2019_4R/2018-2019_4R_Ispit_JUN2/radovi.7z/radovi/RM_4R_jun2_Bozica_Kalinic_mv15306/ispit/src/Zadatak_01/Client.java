package Zadatak_01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Random;

public class Client {

	public Socket sock;

	public Client() throws UnknownHostException, IOException {

		sock = new Socket("localhost", Server.PORT);

	}

	public static void main(String[] args) throws UnknownHostException, IOException {
		Client c = new Client();
		OutputStream os = c.sock.getOutputStream();
		Random r = new Random(10);
		int n = r.nextInt();
		os.write(n);

		BufferedReader br = new BufferedReader(new InputStreamReader(c.sock.getInputStream()));
		System.out.println(br.readLine());
	}








}

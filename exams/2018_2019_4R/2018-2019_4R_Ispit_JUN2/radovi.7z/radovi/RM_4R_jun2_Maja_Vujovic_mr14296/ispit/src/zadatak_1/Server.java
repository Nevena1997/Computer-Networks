package zadatak_1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static final int PORT=12345;

	public ServerSocket ssocket;


	public Server() {
		try {
			this.ssocket= new ServerSocket(PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run(){
		try {
			BufferedReader b= new BufferedReader(new FileReader("serverfile.txt"));
			String []linije_fajla = null;
			byte []bitovi= null;

			int i = 0;
			while(b.toString() != null){
			linije_fajla[i]=b.readLine();
			bitovi=(byte[]) linije_fajla[i].getBytes();
			i++;
			}


			while(true){
			DatagramPacket dp=new DatagramPacket(bitovi, bitovi.length);
			Socket client=new Socket();
			client.connect(ssocket.getLocalSocketAddress(), PORT);

			ssocket.accept();


			//nedostaje send to client, threads

			b.close();
			ssocket.close();

			}//end while
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}




	}



}

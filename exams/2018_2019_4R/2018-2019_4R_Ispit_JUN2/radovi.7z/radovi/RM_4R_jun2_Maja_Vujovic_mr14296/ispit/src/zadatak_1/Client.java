package zadatak_1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	private Socket socket;
	protected InetAddress adr;

	public Client() {
		try {
			this.adr=InetAddress.getLocalHost();
			this.socket=new Socket(adr,Server.PORT);


		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void recieve(){

		try {
			String hostname="localhostname";
			InetSocketAddress h=new InetSocketAddress(hostname, Server.PORT);
			this.socket.connect(h);
			byte[] primljeno = null;

			DatagramPacket p=new DatagramPacket(primljeno, primljeno.length, h);
			for(int i=0;i<primljeno.length;i++)
				System.out.println(primljeno.toString());


		} catch (IOException e) {
			e.printStackTrace();
		}

	}



}//end class

package zadatak_2;

import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane jep;
	private JTextArea text;
	private URL url;

	public LinkHandler(JEditorPane jep, JTextArea text) {
		super();
		this.jep = jep;
		this.text = text;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent ev) {
		HyperlinkEvent.EventType type=ev.getEventType();
		URL u=ev.getURL();

		if(type==HyperlinkEvent.EventType.ACTIVATED & u != this.url)
			try {
				this.text.setText(u.toString());
				this.jep.setPage(u);
			} catch (IOException e) {
				e.printStackTrace();
			}



	}


	public void changeView() {
		try {
			this.jep.setPage(this.url);
			this.text.setText(this.url.toString());
		} catch (IOException e) {
			this.text.setText("URL nije validan ili ne vodi do HTML fajla!");
		}

	}//end changeView





}

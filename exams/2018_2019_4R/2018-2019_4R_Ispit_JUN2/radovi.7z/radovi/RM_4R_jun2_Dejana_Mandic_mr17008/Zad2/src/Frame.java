import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class Frame {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Ukloni HTML");
		JEditorPane pane = new JEditorPane();
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		JButton bt1 = new JButton("Prikazi");
		JButton bt2 = new JButton("Ocisti");
		JTextField urlTf = new JTextField();
		JScrollPane scroll = new JScrollPane(pane);
		pane.setEditable(false);
		frame.setSize(300, 300);

		bt1.addActionListener(new ActionListener() {

			private String extension(String path) {
				int ind = path.lastIndexOf('.');
				return path.substring(ind + 1);
			}

			@Override
			public void actionPerformed(ActionEvent e) {
				String path = urlTf.getText();


				try {
					URL url=new URL(path);
					if (url == null || !extension(path).equals("html")) {
						pane.setText(" Not valid URL, try again. ");
						return;
					}
					// za testiranje : FILE:///C:/Users/nalog/Desktop/1.html
					InputStream in =url.openStream();
					InputStreamReader inp=new InputStreamReader(in);
					int c;
					StringBuffer s=new StringBuffer();
					while((c=in.read())!=-1){
						s.append((char)c);
					}
					pane.setText(s.toString());
				} catch (IOException e1) {
					pane.setText(" Not valid URL, try again. ");
				}
			}
		});

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;
		c.gridwidth = 4;
		frame.add(scroll, c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.gridwidth = 2;
		frame.add(urlTf, c);

		c.fill = GridBagConstraints.NONE;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		frame.add(bt1, c);

		c.fill = GridBagConstraints.NONE;
		c.gridx = 3;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		frame.add(bt2, c);

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);

			}
		});

	}

	/*String remove(String s){
		StringBuffer all=new StringBuffer();
		for(int i=0;i<=s.length(); i++){
			StringBuffer buf=new StringBuffer();
			if(s.charAt(i)=='<'){
				buf=new StringBuffer();
			}
			if(s.charAt(i)=='>'){

			}

		}
	}*/

}

package pack1;

import java.io.BufferedInputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		try(Socket client=new Socket("localhost", Server.PORT)){
			System.out.println("Line number:");
			Scanner sc=new Scanner(System.in);
			int n=sc.nextInt();
			OutputStreamWriter out=new OutputStreamWriter(client.getOutputStream());

			out.write(n);
			out.flush();
			BufferedInputStream in=new BufferedInputStream(client.getInputStream());
			int c;
			while((c=in.read())!=-1){
				System.out.print((char)c);
			}
			System.err.println("Client finished.");
			in.close();
			out.close();

		}catch (Exception e) {
			//e.printStackTrace();
			System.err.println("Greska klijent");
		}


	}

}

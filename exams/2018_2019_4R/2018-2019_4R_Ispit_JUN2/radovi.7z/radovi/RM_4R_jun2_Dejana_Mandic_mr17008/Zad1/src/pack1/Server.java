package pack1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;


public class Server extends Thread {
	public static final int PORT = 12345;

	private ArrayList<String> lines = new ArrayList<>();

	private Server() {
		super();
		try {
			Scanner sc = new Scanner(new FileInputStream("serverfile.txt"));
			while (sc.hasNextLine()) {
				String s = sc.nextLine();
				lines.add(s);
				//System.out.println(s);
			}
			sc.close();

		} catch (FileNotFoundException e) {
			System.err.println("File not found - serverfile.txt");
		}
	}
	public static void main(String[] args) {

		InputStreamReader in=null;
		BufferedOutputStream out=null;
		try (ServerSocket server = new ServerSocket(PORT)) {
			Server s=new Server();
			System.out.println("Started..");
			while (true) {
				Socket client = server.accept();
				//System.out.println("Here");
				in=new InputStreamReader(client.getInputStream());
				int n=in.read();
				System.out.println(n);
				out = new BufferedOutputStream(client.getOutputStream());
				s.new Nit(out,n).start();

				//in.close();
				//out.close();
			}
		} catch (Exception e) {
			System.err.println("SERVER");
		}
		finally{
			if(in!=null)
				try {
					in.close();
				} catch (IOException e) {
					System.out.println("nooo");
				}
			if(out!=null)
				try {
					out.close();
				} catch (IOException e) {
					System.out.println("nooo");
				}
		}

	}

	private class Nit extends Thread {
		BufferedOutputStream out;
		int n;

		public Nit(BufferedOutputStream out, int n) {
			this.out = out;
			this.n=n;
		}

		@Override
		public void run() {
			//za slanje celog fajla:
			/*for (String line : lines) {
				try {
					out.write(line.getBytes());
					out.write('\r');
					out.write('\n');
					out.flush();
				} catch (IOException e) {
					e.printStackTrace();
					//System.err.println("Error NIT.");
				}
			}*/
			try{
				out.write(lines.get(n).getBytes());
				lines.set(n, null);

				out.write('\r');
				out.write('\n');
				out.flush();
				out.close();

			}catch (Exception e) {
				String s="Ne postoji.";
				try {
					out.write(s.getBytes());
					out.write('\r');
					out.write('\n');
					out.flush();
					out.close();
				} catch (IOException e1) {
					System.out.println("greskaaa");
				}
			}


		}
	}

}

package _1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Server extends Thread{
	public static int PORT=12345;
	ServerSocket server;
	public Server(){
		try {
			server=new ServerSocket(PORT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run(){
		Scanner sc=null;
		Scanner l=null;
		OutputStreamWriter out=null;
		Socket s=null;
		try{
			List<String> lista=new ArrayList<>();
			sc=new Scanner(new FileInputStream("serverfile.txt"));
			while(sc.hasNextLine())lista.add(sc.nextLine());
			while(true){
				int linija=0;
				s=server.accept();
				l=new Scanner(s.getInputStream());
				linija=l.nextInt()-1;
				//////////////////////////
				out=new OutputStreamWriter(s.getOutputStream());
				if(linija>=0 && linija<lista.size())
					out.write(lista.get(linija)+"\n");
				else out.write("Ne postoji.\n");
				out.flush();
				////////////////////////////
				l.close();
				s.close();
			}

		}
		catch(IOException e){e.printStackTrace();}
		catch(Exception e){e.printStackTrace();}
		finally{
			try{
				if(l!=null)l.close();
				if(sc!=null)sc.close();
				if(out!=null)out.close();
				if(s!=null)s.close();
				if(server!=null)server.close();
			}
			catch(Exception e1){}
		}
	}

	public static void main(String[] args) {
			Server ss=new Server();
			ss.start();
	}

}

/*class Nit extends Thread{
	int linija;
	List<String> lista;
	Socket s=null;
	public Nit(Socket s,int linija,List<String> lista){this.s=s;this.linija=linija;this.lista=lista;}
	public void run(){
		OutputStreamWriter out=null;
		Scanner l=null;
		try {
			out=new OutputStreamWriter(s.getOutputStream());
			if(linija>=0 && linija<lista.size())
				out.write(lista.get(linija)+"\n");
			else out.write("Ne postoji.");
			out.flush();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{

			try {
				if(out!=null)
					out.close();
				if(s!=null)s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}*/

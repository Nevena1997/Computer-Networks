package _1;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		Socket s=null;
		OutputStreamWriter out=null;
		Scanner sc=null;
		Scanner in=null;
		try{
			s=new Socket("localhost",Server.PORT);
			out=new OutputStreamWriter(s.getOutputStream());
			sc=new Scanner(System.in);
			int linija=sc.nextInt();
			out.write(String.valueOf(linija)+"\n");
			out.flush();
			in=new Scanner(s.getInputStream());
			System.out.println(in.nextLine());
		}
		catch(IOException e){}
		catch(Exception e){e.printStackTrace();}
		finally{
			try {
				if(sc!=null)sc.close();
				if(out!=null)out.close();
				if(in!=null)in.close();
				if(s!=null)
					s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

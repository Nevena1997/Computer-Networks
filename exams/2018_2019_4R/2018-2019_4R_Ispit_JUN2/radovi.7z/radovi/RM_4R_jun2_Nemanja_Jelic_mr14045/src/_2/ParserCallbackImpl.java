package _2;

import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{
	StringBuffer s;
	public ParserCallbackImpl(StringBuffer s){
		this.s=s;
	}
	public void handleText(char[]data,int pos){
		s.append(data);
		s.append("\r\n");
	}
}

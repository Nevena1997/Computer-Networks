package _2;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;


public class HTMLEditor {

	public static void main(String[] args) {
		JFrame jf=new JFrame("Ukloni HTML tagove v1.0");
		jf.setSize(500,500);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addC(jf.getContentPane());

		java.awt.EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				jf.setVisible(true);
			}
		});
	}
	private static void addC(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		jep.setEditable(false);
		jep.setContentType("text/plain");
		JScrollPane js=new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.weightx=1.0;
		c.weighty=1.0;
		c.gridwidth=3;
		pane.add(js,c);

		JTextArea ta=new JTextArea();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridy=1;
		c.weightx=1.0;
		c.weighty=0.0;
		c.gridwidth=1;
		pane.add(ta,c);

		JButton prikazi=new JButton("Prikazi");
		c.weightx=0.0;
		c.gridx=1;
		pane.add(prikazi,c);

		JButton ocisti=new JButton("Ocisti");
		c.gridx=2;
		pane.add(ocisti,c);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Scanner in=null;
				try {
					in=new Scanner(new InputStreamReader(new URL(ta.getText()).openStream()));
					StringBuffer sb=new StringBuffer();
					while(in.hasNextLine())sb.append(in.nextLine()+"\n");
					jep.setText(sb.toString());
				} catch (IOException e1) {
					jep.setText("\n\n\tNe moze se ucitati stranica");
				}
				finally{
					if(in!=null)in.close();
				}
			}
		});

		ocisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					ParserGetter pg=new ParserGetter();
					HTMLEditorKit.Parser p=pg.getParser();
					StringBuffer s=new StringBuffer();
					ParserCallbackImpl pc=new ParserCallbackImpl(s);
					InputStreamReader in=new InputStreamReader(new URL(ta.getText()).openStream());
					p.parse(in, pc, true);
					jep.setText(s.toString());
					in.close();
				}
				catch(Exception e1){e1.printStackTrace();}
			}
		});
	}

}

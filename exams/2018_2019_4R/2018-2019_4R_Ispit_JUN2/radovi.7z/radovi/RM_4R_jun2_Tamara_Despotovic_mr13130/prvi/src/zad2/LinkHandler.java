package zad2;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener {
private JEditorPane pane;
private JTextArea addressBar;
//private List<URL>urlStack;
public LinkHandler(JEditorPane pane,JTextArea addressBar){
	this.pane=pane;
	this.addressBar=addressBar;
}



public void ocisti(){
	String tekst=addressBar.getText();
	try {
		URL url=new URL(tekst);
	} catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//treba izbrisati<html></html><body></body>
}
public void prikazi(){
try {
	String tekst=addressBar.getText();
	URL url=new URL(tekst);
	try {
		pane.setPage(url);
	} catch (IOException e) {

		e.printStackTrace();
	}
} catch (MalformedURLException e) {

	e.printStackTrace();
}

}
private void changeView(URL u){
	try{

	this.pane.setPage(u);
	}catch(IOException e){
		e.printStackTrace();
	}this.pane.setText("<html>Could not load this page" +u + "</html>");
}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent evt) {
HyperlinkEvent.EventType type=evt.getEventType();
URL u=evt.getURL();
if(type==HyperlinkEvent.EventType.ACTIVATED){
	String tekst=addressBar.getText();

	try {
		pane.setPage(u);
	} catch (IOException e) {

		e.printStackTrace();
	}

}
else if(type==HyperlinkEvent.EventType.ENTERED){

}else if(type==HyperlinkEvent.EventType.EXITED){

}
	}

}

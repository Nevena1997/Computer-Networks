package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Swingic {

	public static void main(String[] args) {
		JFrame f=new JFrame("HTML Editor");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(500, 700);
		addComponents(f.getContentPane());
		EventQueue.invokeLater(new Runnable(){
			public void run(){
			f.setVisible(true);
		}	});


	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		JScrollPane jsp=new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;
		//na koliko celija se proteze
		c.gridwidth=3;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=0.0;
		c.weighty=1.0;
		pane.add(jsp,c);

		JTextArea addressBar=new JTextArea();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;

		c.gridwidth=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1.0;
		c.weighty=0.0;
		pane.add(addressBar,c);
		LinkHandler lh=new LinkHandler(jep, addressBar);
		jep.addHyperlinkListener(lh);
 JButton prikazi=new JButton("Prikazi");
 c.fill=GridBagConstraints.HORIZONTAL;
	c.gridx=1;
	c.gridy=1;
	//na koliko celija se proteze
	c.gridwidth=1;
	c.ipadx=0;
	c.ipady=0;
	c.weightx=0.0;
	c.weighty=0.0;
	pane.add(prikazi,c);

		 prikazi.addActionListener(new ActionListener(){
			 public void actionPerformed(ActionEvent e){
				 lh.prikazi();
			 }
		 });

		 JButton ocisti=new JButton("Ocisti");
		 c.fill=GridBagConstraints.HORIZONTAL;
			c.gridx=2;
			c.gridy=1;
			//na koliko celija se proteze
			c.gridwidth=1;
			c.ipadx=0;
			c.ipady=0;
			c.weightx=0.0;
			c.weighty=0.0;
			pane.add(ocisti,c);

				 ocisti.addActionListener(new ActionListener(){
					 public void actionPerformed(ActionEvent e){
						 lh.ocisti();
					 }
				 });

	}



}

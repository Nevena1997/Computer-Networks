package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread{

public static final int PORT=12345;
ServerSocket socket;

 public Server(){
	 try{

		this.socket=new ServerSocket(PORT);
	 }catch(IOException e){
		 e.printStackTrace();
	 }
 }


	public static void main(String[] args) {
new Server().start();
	}

	public void run(){
		while(true){
			try{
				ServerSocket server=new ServerSocket(Server.PORT);
				Socket client=server.accept();
				BufferedWriter out=new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
				BufferedReader in=new BufferedReader(new FileReader("serverfile.txt"));

				String br_linija=in.readLine();
				String linija;
				int i=0;
				//ceo redni broj koji predstavlja redni broj linije fajla
				int broj=Integer.parseInt(br_linija);
				//while(true){
			//	linija=in.readLine();
				//	i++;
				//	if(broj !=i )
				//		System.err.println("ne postoji linija sa tim celim brojem");
				//}


				out.write(br_linija);
				out.flush();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}
}

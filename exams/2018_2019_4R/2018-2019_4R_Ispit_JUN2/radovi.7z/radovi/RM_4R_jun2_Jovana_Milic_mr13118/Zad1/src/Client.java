import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.xml.ws.handler.MessageContext.Scope;


public class Client {


	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Socket socket = new Socket("localhost", Server.PORT);
		InputStream in = socket.getInputStream();
		int i;
		while( (i= in.read()) != -1)
			System.out.print((char)i);


		socket.close();

	}

}

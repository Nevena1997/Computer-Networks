import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

public class Server extends Thread {
	public final static int PORT = 12345;


	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		ServerSocket server = new ServerSocket(PORT);
		FileInputStream f = new FileInputStream("serverfile.txt");
		InputStreamReader in = new InputStreamReader(f);
		BufferedReader br = new BufferedReader(in);

		ArrayBlockingQueue<String> list = new ArrayBlockingQueue<>(256);
		String line=" ";
		while( (line=br.readLine()) != null){
			try {
				list.put(line);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		new Runnable() {
			public void run() {

			}
		};

		Socket socket = server.accept();
		if(socket.isBound()){

		OutputStream out = socket.getOutputStream();
		BufferedOutputStream bout = new BufferedOutputStream(out);
		try {
			bout.write(	list.take().getBytes());


		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




		}



	}

}

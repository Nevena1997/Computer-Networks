import javax.swing.text.html.HTMLEditorKit;

@SuppressWarnings("serial")
public class ParserGetter extends HTMLEditorKit {
	public Parser getParser( ){
		return super.getParser();

	}

}

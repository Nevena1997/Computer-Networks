import java.io.IOException;
import java.io.Writer;

import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImp extends ParserCallback {
	public Writer out;

	public ParserCallbackImp(Writer out) {
		this.out = out;
	}


	@Override
	public void handleText(char[] data, int pos) {
		// TODO Auto-generated method stub

		try {
			out.write(data);
			out.write("\r\n");
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

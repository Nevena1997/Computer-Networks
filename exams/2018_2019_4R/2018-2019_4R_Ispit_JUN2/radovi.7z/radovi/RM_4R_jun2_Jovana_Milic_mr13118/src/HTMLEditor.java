import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class HTMLEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600,400);
		frame.setTitle("Ukloni HTML tagove v1.0");
		frame.setResizable(true);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				frame.setVisible(true);
			}
		});

	}

	private static void addComponents(Container contentPane) {
		// TODO Auto-generated method stub
		contentPane.setLayout(new GridBagLayout());

		GridBagConstraints c = new GridBagConstraints();
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		//file:///C:/Users/nalog/Desktop/RM_4R_jun2_Jovana_Milic_mr13118/src/1.html

		JScrollPane scroll = new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;
		c.gridwidth=3;
		c.weighty=1;
		c.weightx=1;
		contentPane.add(scroll,c);

		JTextArea textArea= new JTextArea("Uneti URL");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.weightx=1;
		c.weighty=0;
		c.gridwidth=1;
		contentPane.add(textArea,c);

		JButton btnP = new JButton("Prikazi");
		c.gridx=1;
		c.gridy=1;
		c.weightx=0;
		contentPane.add(btnP,c);

		btnP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				String url = textArea.getText();
				URL u;
				try {
					u = new URL(url);
					InputStreamReader reader = new InputStreamReader(u.openStream());
					BufferedReader br = new BufferedReader(reader);
					String line = " ";
					String pom = " ";

					while( (pom = br.readLine()) != null )
						line=line.concat(pom+"\r\n");
					jep.setText(line);
					br.close();
					reader.close();


				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					System.err.println("URL nije validan");
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}




			}
		});

		JButton btnD = new JButton("Ocisti");
		c.gridx=2;
		c.gridy=1;
		contentPane.add(btnD,c);

		btnD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				ParserGetter pg = new ParserGetter();

				StringWriter sw = new StringWriter();

				ParserCallbackImp pc = new ParserCallbackImp(sw);



				HTMLEditorKit.Parser p = pg.getParser();

				String url = textArea.getText();
				URL u;
				try {
					u = new URL(url);
					InputStreamReader in = new InputStreamReader(u.openStream());
					p.parse(in, pc, true);
					jep.setText(sw.toString());
					in.close();

				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}




			}
		});



	}

}

package p01;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Server {

	private static List<String> lines = Collections.synchronizedList(new ArrayList<String>());

	public static void main(String[] args) {

		BufferedReader in = null;
		PrintWriter out = null;
		try (ServerSocket server = new ServerSocket(12345)) {

			readFile();

			while (true) {
				Socket client = server.accept();
				in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				out = new PrintWriter(client.getOutputStream());

				ClientHandler ch = new ClientHandler(client, in, out);

				new Thread(ch).start();
			}

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
			if (out != null)
				try {
					out.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
		}

	}

	private static void readFile() {

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt")));
			String line = null;
			while ((line = in.readLine()) != null)
				lines.add(line);

			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static class ClientHandler implements Runnable {

		private PrintWriter out;
		private BufferedReader in;
		private Socket client;

		public ClientHandler(Socket client, BufferedReader in, PrintWriter out) {
			// TODO Auto-generated constructor stub
			this.client = client;
			this.in = in;
			this.out = out;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub

			try {
				String query = in.readLine();
				if (Integer.parseInt(query) > lines.size()) {
					out.print("Ne postoji\r\n");
					out.flush();
				} else {
					synchronized (lines) {

						String response = lines.get(Integer.parseInt(query) - 1);
						out.write(response + "\r\n");
						out.flush();

					}

					client.close();
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

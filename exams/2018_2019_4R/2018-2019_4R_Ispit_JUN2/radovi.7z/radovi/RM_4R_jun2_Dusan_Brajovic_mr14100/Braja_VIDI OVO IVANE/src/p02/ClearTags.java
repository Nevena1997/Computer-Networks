package p02;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class ClearTags {

	public static void main(String[] args) {

		JFrame f = new JFrame("Ukloni HTML Tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(500, 400);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});

	}

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea htmlPane = new JTextArea();
		htmlPane.setEditable(false);
		JScrollPane sc = new JScrollPane(htmlPane);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.weighty = 1;
		c.gridwidth = 3;

		pane.add(sc, c);

		JTextArea urlBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1;
		c.weighty = 0;
		c.gridwidth = 1;

		pane.add(urlBar, c);

		JButton showBtn = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0;
		c.weighty = 0;

		// func
		showBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				BufferedReader in = null;

				try {
					in = new BufferedReader(
							new InputStreamReader(new FileInputStream((new URL(urlBar.getText()).getPath()))));
					StringBuffer sb = new StringBuffer();
					String line = null;
					while ((line = in.readLine()) != null) {
						sb.append(line + "\r\n");
					}

					htmlPane.setText(sb.toString());
				} catch (Exception e) {
					// TODO: handle exception
				} finally {
					if (in != null)
						try {
							in.close();
						} catch (Exception e2) {
							// TODO: handle exception
						}
				}

			}
		});

		pane.add(showBtn, c);

		JButton clearBtn = new JButton("Obrisi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 1;
		c.weightx = 0;
		c.weighty = 0;

		clearBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub

				String html = htmlPane.getText();
				html = clearTags(html);
				htmlPane.setText(html);

			}
		});

		pane.add(clearBtn, c);
	}

	private static String clearTags(String text) {

		StringBuffer sb = new StringBuffer();
		boolean inTag = false;
		for (int i = 0; i < text.length(); i++) {
			if (!inTag) {
				sb.append(text.charAt(i));
				if (text.charAt(i) == '<')
					inTag = true;
			} else {
				sb.append(" ");
				if (text.charAt(i) == '>')
					inTag = false;
			}
		}

		for(int i = 0; i < sb.length(); i++)
			if (sb.charAt(i) == '<')
				sb.deleteCharAt(i);

		return sb.toString();

	}

}

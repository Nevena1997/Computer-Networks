package p01;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		BufferedReader in = null;
		PrintWriter out = null;
		try (Socket client = new Socket(InetAddress.getLocalHost(), 12345); Scanner sc = new Scanner(System.in)) {

			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(client.getOutputStream());

			String user = sc.next();

			out.write(user + "\r\n");
			out.flush();

			String response = in.readLine();
			System.out.println(response);

		} catch (Exception e) {
			System.err.println(e);
			// TODO: handle exception
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
			if (out != null)
				try {
					out.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
		}

	}

}

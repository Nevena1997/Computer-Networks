package p02;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{

	private Writer out;

	public ParserCallbackImpl(Writer out){
		this.out = out;
	}

	@Override
	public void handleText(char[] data, int pos) {

		try {
			out.write(data);
			out.write("\r\n");
			out.flush();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}

package p01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static final int PORT = 1234;

	public static void main(String[] args) {

		ServerSocket server = null;
		Socket client = null;

		try {
			server = new ServerSocket(PORT);
			client = server.accept();

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			BufferedReader in2 = new BufferedReader(new InputStreamReader(new FileInputStream("C:/Users/nalog/workspace/Ispit/serverfile.txt")));

			String s;
			while((s = in2.readLine()) != null){
				out.write(s+"\r\n");
				out.flush();
			}

			in2.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try{
				if(server != null)
					server.close();
				if(client != null)
					client.close();
			} catch (IOException e) {

			}
		}

	}

}

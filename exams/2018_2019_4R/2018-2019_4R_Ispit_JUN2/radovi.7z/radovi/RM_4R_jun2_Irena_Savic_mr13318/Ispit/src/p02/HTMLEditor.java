package p02;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {

	private static final String url = "FILE:///C:/Users/nalog/workspace/Ispit/1.html";

	public static void main(String[] args) {


		JFrame f = new JFrame("Ukloni HTML tagove");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(700, 600);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JTextArea area = new JTextArea(url);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(area, c);

		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				URL u;
				try {
					u = new URL(area.getText());
					if(area.getText().endsWith("html")){

						BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));

						StringBuffer buf = new StringBuffer();
						String str = "";
						while((str = in.readLine()) != null){
							buf.append(str + "\r\n");
						}

						jep.setText(buf.toString());

						in.close();
					}
					else
						jep.setText("<html>It is not html file.</html>");
				} catch (MalformedURLException e1) {
					jep.setText("<html>URL is not valid.</html>");
				} catch (IOException e1) {
					System.err.println(e1);
				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnPrikazi, c);

		JButton btnOcisti = new JButton("Ocisti");
		btnOcisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				URL u;
				try {
					u = new URL(area.getText());
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("C:/Users/nalog/workspace/Ispit/file.txt")));

					ParserGetter pg = new ParserGetter();
					ParserCallbackImpl pc = new ParserCallbackImpl(out);
					HTMLEditorKit.Parser p = pg.getParser();

					BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
					p.parse(in, pc, true);

					BufferedReader inPom = new BufferedReader(new InputStreamReader(new FileInputStream("C:/Users/nalog/workspace/Ispit/file.txt")));

					StringBuffer buf = new StringBuffer();
					String s;
					while((s = inPom.readLine()) != null)
						buf.append(s+"\r\n");


					jep.setText(buf.toString());
					inPom.close();
					in.close();
					out.close();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnOcisti, c);

	}

}

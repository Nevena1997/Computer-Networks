import java.io.*;
import java.net.*;
import java.util.*;

public class Main {

	static final short PORT = 12345;
	static final String serverFilePath = "serverfile.txt";

	public static void main(String[] args)
	{
		try (
			 ServerSocket socket = new ServerSocket(PORT);
			 Scanner sc = new Scanner(new FileInputStream(serverFilePath));
			)
		{
			List<String> lines = new ArrayList<String>();
			while (sc.hasNextLine())
			{
				lines.add(sc.nextLine());
			}

			while (true)
			{
				Socket clientSocket = socket.accept();
				Client client = new Client(clientSocket, lines);
				new Thread(client).run();
			}
		}
		catch (Exception e)
		{
			System.out.println("Fatalna greska - server se zaustavlja. Poruka: " + e.getMessage());
			e.printStackTrace();
		}

	}

}

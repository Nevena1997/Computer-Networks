import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.locks.Lock;

public class Client implements Runnable
{
	private Socket clientSocket;
	private List<String> content;
	private static Set<Integer> requestedStrings = new TreeSet<Integer>();

	public Client(Socket socket, List<String> content)
	{
		this.clientSocket = socket;
		this.content = content;
	}

	@Override
	public void run()
	{
		try (
				Scanner clientInput = new Scanner(clientSocket.getInputStream());
				PrintStream clientStream = new PrintStream(clientSocket.getOutputStream()))
		{
			int lineIndex = clientInput.nextInt();

			synchronized (requestedStrings)
			{
				if (lineIndex > content.size() || lineIndex < 1 || requestedStrings.contains(lineIndex))
				{
					clientStream.println("Ne postoji");
				}
				else
				{
					clientStream.println(content.get(lineIndex - 1));
					requestedStrings.add(lineIndex);
				}
			}
			for (String line : content)
			{
				clientStream.println(line);
			}
		}
		catch (Exception e)
		{
			System.out.println("Nekriticna greska u vezi sa klijentom. Poruka: " + e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				clientSocket.close();
			}
			catch (IOException e)
			{
				//verovatno je vec zatvorena, nece biti nikakav problem
			}
		}
	}
}

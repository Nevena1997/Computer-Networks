import java.io.IOException;
import java.io.PrintStream;
import java.net.*;
import java.util.*;

public class Main {

	static final short PORT = 12345;

	public static void main(String[] args)
	{
		try (
				Socket socket = new Socket();
				Scanner userInputScanner = new Scanner(System.in);)
		{
			socket.connect(new InetSocketAddress("localhost", PORT));
			try(
					Scanner sc = new Scanner(socket.getInputStream());
					PrintStream ps = new PrintStream(socket.getOutputStream());)
			{
				System.out.print("Unesite broj linije: ");
				int brLinije = userInputScanner.nextInt();
				ps.println(brLinije);
				System.out.println("Linija br. " + brLinije + ": " + sc.nextLine());
				System.out.println("Sve linije: ");
				while (sc.hasNextLine())
				{
					System.out.println(sc.nextLine());
				}
			}
			catch (Exception e)
			{
				throw e;
			}
		}
		catch (Exception e)
		{
			System.out.println("Greska: " + e.getMessage());
			e.printStackTrace();
		}


	}

}

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.*;

import javax.swing.*;

public class Main {

	private static String RemoveHTMLTags(String html)
	{
		boolean skip = false;
		StringBuilder retsb = new StringBuilder();
		for (char c : html.toCharArray())
		{
			if (c == '<')
			{
				skip = true;
				continue;
			}
			if (c == '>')
			{
				skip = false;
				continue;
			}
			if (!skip)
			{
				retsb.append(c);
			}
		}
		return retsb.toString();
	}
	public static void main(String[] args)
	{

		/* html viewer */
		JEditorPane editorPane = new JEditorPane();
		editorPane.setEditable(false);
		editorPane.setBounds(0, 0, 800, 600);
		editorPane.setAutoscrolls(true);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.add(editorPane);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

		JPanel bottomPanel = new JPanel();
		FlowLayout bottomLayout = new FlowLayout();
		bottomLayout.setAlignOnBaseline(true);
		bottomLayout.setHgap(0);
		bottomLayout.setVgap(0);
		bottomPanel.setLayout(bottomLayout);

		/* text field */
		JTextField textField = new JTextField();
		textField.setPreferredSize(new Dimension(500, 25));
		textField.setEditable(true);

		/* buttons */
		JButton buttonShow = new JButton();
		buttonShow.setText("Prikazi");
		buttonShow.setPreferredSize(new Dimension(150, 25));
		buttonShow.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				String urlString = textField.getText();
				try
				{
					URL url = new URL(urlString);
					URLConnection connection = url.openConnection();
					String html_text = connection.getContent().toString();
					editorPane.setText(html_text);
				}
				catch (Exception ex)
				{
					editorPane.setText("URL invalid or unable to reach it.");
				}
			}

		});

		JButton buttonClear = new JButton();
		buttonClear.setText("Ocisti");
		buttonClear.setPreferredSize(new Dimension(150, 25));
		buttonClear.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				String html = editorPane.getText();
				editorPane.setText(RemoveHTMLTags(html));
			}

		});

		bottomPanel.add(textField);
		bottomPanel.add(buttonShow);
		bottomPanel.add(buttonClear);

		/* main pane */
		JSplitPane mainPane = new JSplitPane();
		mainPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		mainPane.setDividerLocation(560);
		mainPane.setTopComponent(scrollPane);
		mainPane.setBottomComponent(bottomPanel);;

		/* frame */
		JFrame mainFrame = new JFrame();
		mainFrame.setContentPane(mainPane);

		mainFrame.setSize(820, 650);
		mainFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		mainFrame.setVisible(true);
		EventQueue.invokeLater(new Runnable()
				{
					@Override
					public void run()
					{
						mainFrame.setVisible(true);
					}
				});
	}
}

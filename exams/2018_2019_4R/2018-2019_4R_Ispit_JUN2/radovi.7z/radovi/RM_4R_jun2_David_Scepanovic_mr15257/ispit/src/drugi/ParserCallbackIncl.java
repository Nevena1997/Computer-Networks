package drugi;

import java.io.IOException;
import java.io.StringWriter;

import javax.swing.text.html.HTMLEditorKit;

public final class ParserCallbackIncl extends HTMLEditorKit.ParserCallback {

	private StringWriter writer = new StringWriter();

	@Override
	public void handleText(char[] data, int pos) {
		try {
			writer.write(data);
			writer.write("\r\n");
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void finalize() throws Throwable {
		writer.close();
	}

	@Override
	public String toString() {
		return writer.toString();
	}

}

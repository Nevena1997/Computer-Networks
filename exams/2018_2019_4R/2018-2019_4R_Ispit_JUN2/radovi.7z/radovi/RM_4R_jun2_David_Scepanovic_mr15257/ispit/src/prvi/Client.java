package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public final class Client {

	public static void main(String[] args) {
		try (Socket client = new Socket(InetAddress.getLocalHost(), Server.PORT);
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), "UTF-8"));
				PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(client.getOutputStream(),"UTF-8")));
				Scanner sc = new Scanner(System.in);) {
			out.println(sc.nextInt());
			out.flush();
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line=in.readLine()) != null)
				sb.append(line);
			System.out.println(sb.toString());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

package drugi;

import javax.swing.text.html.HTMLEditorKit;

public final class ParserGetter extends HTMLEditorKit{

	private static final long serialVersionUID = 6381250103266861958L;

	@Override
	public Parser getParser() {
		return super.getParser();
	}

}

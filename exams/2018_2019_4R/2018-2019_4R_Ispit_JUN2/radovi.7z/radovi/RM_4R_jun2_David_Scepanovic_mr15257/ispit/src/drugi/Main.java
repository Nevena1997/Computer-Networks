package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public final class Main {

	public static void main(String[] args) {
		JFrame f = new JFrame("Ukloni HTML tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 400);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(()->f.setVisible(true));
	}

	private static void addComponents(Container contentPane) {
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);

		JScrollPane scrollPane = new JScrollPane(textArea);
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 3;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		contentPane.add(scrollPane, c);

		JTextArea linkView = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		contentPane.add(linkView, c);


		JButton showButton = new JButton("Prikazi");
		showButton.addActionListener(e->{
			BufferedReader in = null;
			try {
				String urlString = linkView.getText().trim();
				if(urlString.lastIndexOf('.') == -1)
					throw new MalformedURLException();
				if(urlString.substring(urlString.lastIndexOf('.')).compareTo(".html") != 0)
					throw new MalformedURLException();
				URL url = new URL(urlString);
				in = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
				StringBuilder sb = new StringBuilder();
				String line = null;
				while((line=in.readLine()) != null)
					sb.append(line);
				textArea.setText(sb.toString());
			} catch (MalformedURLException e1) {
				textArea.setText("Url nije validan ili ne vodi do HTML fajla");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			} finally {
				if(in != null)
					try {
						in.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
			}

		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(showButton, c);

		JButton clearButton = new JButton("Ocisti");
		clearButton.addActionListener(e->{
			ParserCallbackIncl callback = new ParserCallbackIncl();
				try {
					new ParserGetter().getParser().parse(new StringReader(textArea.getText()), callback, true);
					textArea.setText(callback.toString());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
		});
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		contentPane.add(clearButton, c);
	}

}

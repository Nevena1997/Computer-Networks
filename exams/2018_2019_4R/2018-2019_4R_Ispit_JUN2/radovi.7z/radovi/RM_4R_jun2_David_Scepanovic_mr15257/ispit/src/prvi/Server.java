package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public final class Server{

	public static final int PORT = 12345;

	private static ServerSocket server;
	private static BufferedReader in;

	static {
		try {
			server = new ServerSocket(PORT);
			in = new BufferedReader(new InputStreamReader(new FileInputStream("src\\serverfile"), "UTF-8"));
		} catch (IOException e) {
			Server.close();
			e.printStackTrace();
		}
	}

	private Server() {
	}

	private static void close() {
		try {
			if (in != null)
				in.close();
			if (server != null)
				server.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		ArrayList<String> lines = new ArrayList<>();
		Set<Integer> takenNonSynchronized = new HashSet<>();
		Set<Integer> taken = Collections.synchronizedSet(takenNonSynchronized);
		try {
			String line = null;
			while ((line=in.readLine()) != null)
				lines.add(line);
		} catch (IOException e) {
			Server.close();
			System.exit(1);
			e.printStackTrace();
		}
		while (true) {
			Socket clientTmp = server.accept();
				new Thread() {
					@Override
					public void run() {
						Socket client = clientTmp;
						try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(), "UTF-8"));
								Scanner sc = new Scanner(new BufferedReader(new InputStreamReader(client.getInputStream(), "UTF-8")))) {
							int i = sc.nextInt();
							if(i < 0 || i>=lines.size())
								out.write("Ne postoji");
							else {
								if(taken.add(i)) {
									out.write(lines.get(i));
									taken.remove(i);
								} else
									out.write("Ne postoji");
							}
							out.flush();
						} catch (IOException e) {
							try {
								client.close();
							} catch (IOException e1) {
								e1.printStackTrace();
							}

						}
					}
				}.start();
		}
	}


}

package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class Server extends Thread {

	public static final int PORT = 12345;

	public static void main(String[] args) {
		new Server().start();
	}// END OF main

	@Override
	public void run() {

		BufferedReader in = null;
		BufferedWriter out = null;
		BufferedReader fileIn = null;
		Map<Integer,String> data;

		try ( ServerSocket server = new ServerSocket(PORT) ){

			while( true ){

				Socket client = server.accept();
				System.out.println("Client connected: " + client.getLocalAddress());

				in = new BufferedReader( new InputStreamReader( client.getInputStream()) );
				out = new BufferedWriter( new OutputStreamWriter( client.getOutputStream() ) );

				fileIn = new BufferedReader( new InputStreamReader( new FileInputStream("serverfile.txt") ) );
				data = new HashMap<Integer,String>();

				data = readData(fileIn);
				/*for( int i = 1; i <= data.size(); i++ ){
					out.write(data.get(i));
					out.write("\n");
					out.flush();
					System.out.println(data.get(i) + " " + i);
				}*/

				int line = in.read();

				if( !data.containsKey(line) ){
					out.write("Ne postoji");
					out.write("\n");
					out.flush();
				}
				else{
					out.write(data.get(line));
					out.write("\n");
					out.flush();
				}
				System.out.println("Line sent!");

				// Remove the line so the others can't access it
				data.remove(line);

				if( data.isEmpty() )
					break;

			}// END OF while

		} catch (IOException e) {
			System.err.println(e);
		}

	}// END OF run

	private static Map<Integer, String> readData(BufferedReader fileIn) throws IOException {
		Map<Integer,String> temp = new HashMap<>();
		String line;
		int lineCount = 1;

		while( (line = fileIn.readLine()) != null ){
			temp.put(lineCount, line);
			lineCount++;
		}

		return temp;
	}// END OF readData

}// END OF class

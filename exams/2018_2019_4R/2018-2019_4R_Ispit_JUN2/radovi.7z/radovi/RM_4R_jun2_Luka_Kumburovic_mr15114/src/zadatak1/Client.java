package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {

		String host = "localhost";
		BufferedReader in = null;
		BufferedWriter out = null;
		int demandLine = 1;

		try ( Socket client = new Socket(host, Server.PORT) ){

			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new BufferedWriter( new OutputStreamWriter(client.getOutputStream()) );

			out.write(demandLine);

			String receivedLine = in.readLine();
			System.out.println(receivedLine);


		} catch (UnknownHostException e) {
			System.err.println(e);
		} catch (IOException e) {
			System.err.println(e);
			try {
				in.close();
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}// END OF main

}// END OF class

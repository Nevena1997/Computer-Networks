package zadatak2;

import java.io.IOException;
import java.io.Writer;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML.Tag;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback {

	Writer out;
	boolean insideTags = false;

	public ParserCallbackImpl(Writer out){
		this.out = out;
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		insideTags = true;
	}

	@Override
	public void handleEndTag(Tag t, int pos) {
		insideTags = false;
	}

	@Override
	public void handleText(char[] data, int pos) {

		if( insideTags )
			try {
				out.write(data.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}

	}

}// END OF class

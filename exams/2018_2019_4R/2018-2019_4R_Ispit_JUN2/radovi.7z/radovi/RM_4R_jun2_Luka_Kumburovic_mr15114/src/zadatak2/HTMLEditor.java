package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLEditor {

	static JEditorPane pane;
	static JScrollPane scrollPane;
	static JTextArea addressBar;
	static JButton show;
	static JButton clear;


	public static void main(String[] args) {

		JFrame frame = new JFrame("Ukloni HTML tagove v1.0");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(800,600);
		addComponents( frame.getContentPane() );

		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}// END OF main


	private static void addComponents(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		pane = new JEditorPane();
		pane.setEditable(false);
		scrollPane = new JScrollPane(pane);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 3;
		c.gridheight = 1;
		c.weightx = 3;
		c.weighty = 1;
		contentPane.add(scrollPane, c);

		LinkHandler handler = new LinkHandler(pane, addressBar);

		addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1;
		c.weighty = 0;
		contentPane.add(addressBar, c);


		show = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 0;
		c.weighty = 0;
		contentPane.add(show, c);
		show.addActionListener( e -> handler.showPage() );

		clear = new JButton("Ocisti");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 0;
		c.weighty = 0;
		contentPane.add(clear, c);
		clear.addActionListener( e -> handler.clearPage() );

	}// END OF addComponents

}// END OF class

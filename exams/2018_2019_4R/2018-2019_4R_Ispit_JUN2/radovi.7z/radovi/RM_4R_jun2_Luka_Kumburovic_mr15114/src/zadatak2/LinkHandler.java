package zadatak2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.text.html.HTMLEditorKit.Parser;

public class LinkHandler {

	private JEditorPane pane;
	private JTextArea addressBar;

	ParserGetter pg = new ParserGetter();
	ParserCallbackImpl pc;
	Parser p = pg.getParser();

	public LinkHandler( JEditorPane pane, JTextArea addressBar){
		this.pane = pane;
		this.addressBar = addressBar;
	}

	public void showPage(){

		try {
			pane.setPage(new URL(addressBar.getText()));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void clearPage(){
		try {
			URL url = new URL(addressBar.getText());

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(url.toString())));
			String text = pane.getText();
			out.write(text);
			out.close();
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(url.toString())));
			pc = new ParserCallbackImpl(out);

			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(url.toString())));

			try {
				p.parse(in, pc, true);
			} catch (IOException e) {
				e.printStackTrace();
			}

			pane.setPage(url);

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch ( IOException e ){
			e.printStackTrace();
		}

	}

}// END OF class
package zadatak1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {


public static final int PORT=18899;

	public static void main(String[] args) throws IOException  {

		ServerSocket sock = new ServerSocket(PORT);
		List<String> lista = new ArrayList<>();
		List<Integer> index = new ArrayList<Integer>();
		BufferedReader ir = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt"),"UTF-8"));
		String s;

		while((s=ir.readLine())!=null){
			lista.add(s);
		}
		BufferedReader bf=null;
		OutputStreamWriter out =null;
		while(true){
			Socket cl = sock.accept();
			try{

				System.out.println("server");
				bf = new BufferedReader(new InputStreamReader(cl.getInputStream(),"UTF-8"));

				out = new OutputStreamWriter(cl.getOutputStream());
				int br= bf.read();

				if(br<lista.size()){
					if(index.indexOf(br-1)==-1){
						index.add(br-1);
						out.write(lista.get(br-1));
						out.flush();
					}
					else{
						out.write("Neki klijent je vec zahtevao ovu liniju");
						out.flush();
					}
				}
				else{
					out.write("Ne postoji");
					out.flush();
				}

		 } catch (IOException e) {
			e.printStackTrace();
		 }
		 finally{
			 if(out!=null)
				 out.close();
			 if(bf!=null)
				 bf.close();


		 }}


		}
	}
package zadatak2;

import java.io.IOException;
import java.io.Reader;

import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserGetter extends HTMLEditorKit.Parser{

	@Override
	public void parse(Reader arg0, ParserCallback arg1, boolean arg2) throws IOException {
		// TODO Auto-generated method stub

	}

}

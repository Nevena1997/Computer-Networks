package zadatak1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {

		Socket sock = new Socket(InetAddress.getLocalHost(),  Server.PORT);
		Scanner sc = new Scanner(System.in);

		BufferedReader br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		OutputStreamWriter out = new OutputStreamWriter(sock.getOutputStream());
		try{
			System.out.println("Uneti broj linije");

			int n = sc.nextInt();

			out.write(n);
			out.flush();

			String s = br.readLine();
			System.out.println("Server je poslao: "+s);
		}catch (IOException e) {
			if(out!=null)
				out.close();
			if(br!=null)
				br.close();
		}
		sock.close();
		sc.close();
	}

}

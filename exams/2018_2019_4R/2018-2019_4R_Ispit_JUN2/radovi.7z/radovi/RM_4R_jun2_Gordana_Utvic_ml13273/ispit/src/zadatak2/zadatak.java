package zadatak2;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class zadatak {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Ukloni HTML tagove v1.0");
		frame.setSize(450,400);

		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension dim = tk.getScreenSize();

		frame.setLocation((dim.width - frame.getWidth())/2, (dim.height- frame.getHeight())/2);
		frame.setExtendedState(WindowConstants.EXIT_ON_CLOSE);
		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {

				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();


		JTextField tf = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
	    c.weightx=1.0;
		c.weighty = 0.0;
		pane.add(tf,c);

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=1;
		c.weightx=0.0;
		c.weighty = 0.0;
		c.ipadx=0;
		c.ipady=0;
		pane.add(prikazi,c);

		JButton ocisti = new JButton("Ocisti");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=0.0;
		c.weighty = 0.0;
		pane.add(ocisti,c);


		JEditorPane ta = new JEditorPane();
		JScrollPane jsp = new JScrollPane(ta, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		c.fill = GridBagConstraints.BOTH;
		c.gridx =0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.weighty = 1.0;
		c.weightx = 0.0;
		c.ipadx=0;
		c.ipady=0;
		pane.add(jsp, c);
		ta.setEditable(false);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					URL url = new URL(tf.getText());
					URLConnection con = url.openConnection();
					InputStreamReader ir = new InputStreamReader(con.getInputStream(),"UTF-8");
					int c;
					StringBuilder sb = new StringBuilder();

					if(tf.getText().endsWith(".html"))
					{
						while((c = ir.read())!=-1){
							sb.append((char)c);
					}
					}else{
						sb.append("Nije html prezent");
					}
					ir.close();
					ta.setText(sb.toString());
				} catch (MalformedURLException e) {
					 ta.setText("URL nije validan");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
//		file:///C:/Users/nalog/Desktop/RM_4R_jun2_Gordana_Utvic_ml13273/ispit/zad.html
		ocisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				StringBuilder sb = new StringBuilder();
				sb.append(ta.getText());
				StringBuilder novi = new StringBuilder();
				int otvoren = 0;

				for(int i=0;i<sb.length();i++){
					if(sb.charAt(i)=='<')
						otvoren = 1;
					if(sb.charAt(i)=='>'){
						otvoren =0;
					}
					if(otvoren==1 || sb.charAt(i)=='>'){
						novi.append("");
					}else novi.append(sb.charAt(i));
				}
				ta.setText(novi.toString());

			}
		});
	}

}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {

	public static final int PORT = 12345;
	public static BufferedReader ServerIn = null;

	public Server() throws IOException {
		try{
			ServerIn = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt")));

		} catch(FileNotFoundException e){
			System.out.println("File not found.");
			System.exit(-1);
		}
	}

	public static void main(String[] args) throws IOException{
		new Server().start();
	}

	public void run(){
		try(ServerSocket server = new ServerSocket(PORT)){
			while(true){
				try {
					Socket client = server.accept();
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
					BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

					String brLinije = in.readLine();
					int x = Integer.parseInt(brLinije);

					String linija = getDataToSend(x);

					out.write(linija);
					out.flush();
					out.close();
					client.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e1) {
			try {
				ServerIn.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e1.printStackTrace();
		}

	}

	private static String getDataToSend(int x) throws IOException{
		String linija;
		ServerIn = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt")));

		while(true){
			linija = ServerIn.readLine();
			if(linija == null)
				break;
			x--;
			if(x == 0)
				break;
		}

		if(x == 0)
			return linija;
		else
			return "Ne postoji";
	}
}

package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static final String HOST = "localhost";
	public static BufferedReader in = null;
	public static PrintWriter out = null;
	public static Scanner sc = null;

	public static void main(String[] args) throws IOException {
		try(Socket client = new Socket(HOST, Server.PORT)){
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(client.getOutputStream());

			sc = new Scanner(System.in);
			String brLinije = sc.nextLine();

			out.write(brLinije);
			out.write("\r\n");
			out.flush();

			String line = in.readLine();
			System.out.println(line);

		} catch(IOException e){
			e.printStackTrace();
		} finally{
			try{
				if(in != null)
					in.close();
				if(out != null)
					out.close();
				if(sc != null)
					sc.close();
			} catch(IOException e1){

			}
		}

	}

}



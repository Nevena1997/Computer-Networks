public class zad1 {


}

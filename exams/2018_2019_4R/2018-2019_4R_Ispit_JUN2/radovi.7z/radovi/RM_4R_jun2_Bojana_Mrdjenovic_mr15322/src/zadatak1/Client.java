package zadatak1;

import java.io.*;
import java.net.*;
import java.util.Random;

public class Client {
	public static void main(String[] args) throws IOException {

		String host = "localhost";
		int port = Server.port;
		Socket s = new Socket(host, port);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
		BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));

		PrintWriter pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream()));
		Random r = new Random();
		int n = r.nextInt(50);
		pw.write(n);
		pw.flush();

		String str;
		while((str = br.readLine()) != null){
			System.out.println(str);
		}
	}
}

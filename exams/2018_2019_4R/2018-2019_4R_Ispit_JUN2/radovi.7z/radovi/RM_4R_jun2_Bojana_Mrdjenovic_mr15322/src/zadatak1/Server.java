package zadatak1;

import java.io.*;
import java.lang.reflect.Array;
import java.net.*;
import java.util.Collection;
import java.util.List;

public class Server extends Thread {

	public static final int port = 12345;
	ServerSocket ss;
	Server() throws IOException{
		ss = new ServerSocket(port);
	}
	public static void main(String[] args) throws IOException {
		new Server().start();
	}

	public void run() {
		//FileInputStream fis = new FileInputStream("zadatak1/serverfile.txt");
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		try{
			while(true){
				Socket s = ss.accept();
				OutputStreamWriter osw = new OutputStreamWriter(s.getOutputStream());
				BufferedWriter bw = new BufferedWriter(osw);
				String str;
				while((str = br.readLine()) != null){
					bw.write(str);
					bw.write("\n");
					bw.flush();
				}
			}
		} catch(IOException e){
			e.printStackTrace();
		} finally{
			try {
				br.close();
				ss.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

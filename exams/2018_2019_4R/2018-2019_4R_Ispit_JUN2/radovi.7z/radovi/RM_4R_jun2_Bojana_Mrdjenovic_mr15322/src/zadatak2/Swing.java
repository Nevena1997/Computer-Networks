package zadatak2;

import java.awt.*;

import javax.swing.*;

public class Swing {

	public static void main(String[] args) {
		JFrame f = new JFrame("Ukloni HTML tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);
		f.setSize(600, 600);
		addComponents(f);

		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run() {
				f.setVisible(true);
			}

		});

	}

	private static void addComponents(JFrame f){
		JEditorPane jep = new JEditorPane();
		JScrollPane scroll = new JScrollPane(jep);
		f.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();


		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 4;
		c.gridheight = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		f.add(scroll, c);

		JTextField tf = new JTextField();
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.HORIZONTAL;
		f.add(tf, c);

		JButton prikazi = new JButton("Prikazi");
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.NONE;
		f.add(prikazi, c);

		JButton ocisti = new JButton("Ocisti");
		c.gridx = 3;
		c.gridy = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.NONE;
		f.add(ocisti, c);

	}

}

package dva;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.CharBuffer;

import javax.swing.*;
import javax.swing.text.html.HTMLEditorKit;

import java.awt.*;

public class Browser {

	private static URL CURRENT_PAGE = null;

	public static void main(String[] args){
		JFrame frame = new JFrame("Browser");
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable(){

			@Override
			public void run() {
				frame.setVisible(true);

			}

		});
	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 3;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(jsp, c);

		JTextArea addressBar = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1;
		c.weighty = 0;
		pane.add(addressBar, c);

		JButton btnShow = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(btnShow, c);

		btnShow.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					URL u = new URL(addressBar.getText());
					jep.setText("Ne znam ovaj deo. sorry");

					Browser.setCURRENT_PAGE(u);
				} catch (MalformedURLException e) {
					jep.setText("Ne postoji.");
				} //catch (FileNotFoundException e) {
				//	jep.setText("Ne postoji.");
				//}
				catch (IOException e) {
					e.printStackTrace();
				}

			}
		});



		JButton btnClear = new JButton("Ocisti");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 1;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(btnClear, c);

		btnClear.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try{
					ParserGetter pg = new ParserGetter();
					File f = new File("dummy.txt");
					MyParserCallback pc = new MyParserCallback(new OutputStreamWriter(new FileOutputStream(f)));
					HTMLEditorKit.Parser parser = pg.getParser();
					URL u = Browser.getCURRENT_PAGE();
					InputStreamReader in = new InputStreamReader(u.openStream());
					parser.parse(in, pc, true);

					jep.setPage(f.toURI().toURL());
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		});


	}

	public static URL getCURRENT_PAGE() {
		return CURRENT_PAGE;
	}

	public static void setCURRENT_PAGE(URL cURRENT_PAGE) {
		CURRENT_PAGE = cURRENT_PAGE;
	}


}

package dva;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class MyParserCallback extends HTMLEditorKit.ParserCallback {
	Writer out;

	public MyParserCallback(Writer out){
		this.out = out;
	}

	public void handleEndTag(HTML.Tag tag, int position){
		if(tag == HTML.Tag.HTML){
			try {
				out.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void handleText(char[] text, int position){
		try {
			out.write(text);
			out.write('\n');
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

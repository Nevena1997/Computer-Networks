package jedan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		String hostname = "localhost";
		int port = Server.PORT;


		try {
			Socket client = new Socket();
			client.connect(new InetSocketAddress(hostname,port));
			client.setSoTimeout(100);

			Scanner sc = new Scanner(System.in);
			String line = sc.next().trim();
			sc.close();

			PrintWriter out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
			BufferedReader networkIn = new BufferedReader(new InputStreamReader(client.getInputStream()));


			out.println(line);
			Thread.sleep(50);

			char[] buffer = new char[1000];
			if(networkIn.read(buffer) != 0){
				System.out.println(buffer);
			}

			out.close();
			networkIn.close();
			client.close();
		} catch (IOException e) {
			System.err.print("Connection closed with host.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

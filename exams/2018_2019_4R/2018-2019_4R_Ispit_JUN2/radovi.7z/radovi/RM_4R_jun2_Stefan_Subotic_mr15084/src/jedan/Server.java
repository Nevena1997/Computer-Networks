package jedan;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class Server {
	public static int PORT = 12345;

	static List<String> lines;

	public static void main(String[] args){
		ServerSocket server = null;

		try {
			server = new ServerSocket(PORT);
			BufferedReader fileReader =new BufferedReader( new InputStreamReader(new FileInputStream("serverfile.txt")));
			lines = new ArrayList<String>();

			while(true){
				String line = fileReader.readLine();
				if(line == null)
					break;

				lines.add(line);
			}
			fileReader.close();

			while(true){
				Socket client = server.accept();
				System.out.println("Connected with " + client.getInetAddress().toString());
				client.setSoTimeout(100);

				Thread connectionThread = new ConnectionThread(client);
				connectionThread.start();

			}

		} catch (SocketException e) {
			System.out.println("Connection Closed");
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try {
				server.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

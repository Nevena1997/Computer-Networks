import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class HTMLEditor {

	public static void main(String[] args) {

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);

		JScrollPane pane = new JScrollPane(jep);

		JFrame f = new JFrame("Ukloni HTML tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setContentPane(pane);
		f.setSize(600, 400);
		f.setVisible(true);

	}

}

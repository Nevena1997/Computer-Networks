import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server extends Thread {

	public static final int PORT = 12722;

	private ServerSocket socket;
	private BufferedReader in;

	public Server() throws IOException {
		this.socket = new ServerSocket(PORT);

		try {
			this.in = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt")));
		}
		catch(FileNotFoundException e) {
			System.err.println("File doesn't exist.");
		}
	}

	public Vector<String> addToContainer() throws IOException {
		Vector<String> linije = new Vector<>();
		String str = null;

		if(in == null)
			return null;

		while((str = in.readLine()) != null) {
			linije.add(str);
		}
		return linije;
	}

	@Override
	public void run() {
		while(true) {
			Socket conn;

			try {
				conn = this.socket.accept();
				Vector<String> vec = addToContainer();
				BufferedReader in1 = new BufferedReader(new InputStreamReader(conn.getInputStream()));

				int linenNum = in1.read();

					String s = vec.get(linenNum);
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));

					if(s==null) {
						out.write("Ne postoji.");
						out.flush();
					}
					else {
						out.write(s);
						out.flush();

					}
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws IOException {
		Client client = new Client();
		client.runClient();
		new Server().start();
	}
}
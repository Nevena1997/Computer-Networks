import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

public class Client {

	private String host = "localhost";
	private Socket socket;

	Scanner sc = new Scanner(System.in);
/*
	public Client() {
		try {
			this.socket = new Socket(host, Server.PORT);
		}
		catch(SocketException e) {
			System.err.println(e);
		}
		catch(IOException e) {
			System.err.println(e);
		}
	}
*/

	public void runClient() throws IOException {
		try {
			Socket s = new Socket(host, Server.PORT);

			System.out.println("Unesite broj linije:");
			int p = sc.nextInt();
			sc.close();

			BufferedWriter out = null;
			try {
				out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));

				out.write(p);
				out.flush();
			}
			catch (IOException e) {
				System.err.println(e);
			}
			BufferedReader in = null;
			try {
				in = new BufferedReader(new InputStreamReader(s.getInputStream()));

				while(in != null) {
					System.out.println(in.read());
				}
			}
			catch(IOException e) {
				System.err.println(e);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}
}
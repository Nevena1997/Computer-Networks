package prviZad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;

public class Nit implements Runnable{
	private Socket client;
	private List<String> sadrzajFajla;

	public Nit(Socket client, List<String> sadrzajFajla){
		this.client = client;
		this.sadrzajFajla = sadrzajFajla;
	}

	@Override
	public void run() {
		BufferedReader in = null;
		BufferedWriter out = null;
			try {
				out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
				in = new BufferedReader(new InputStreamReader(client.getInputStream()));

				/*int i = 0;
				while(i < sadrzajFajla.size()){
					out.write(this.sadrzajFajla.get(i));
					out.newLine();
					out.flush();
					i++;
				}*/

				int redniBr = in.read();

				if(redniBr < this.sadrzajFajla.size()){
					out.write(this.sadrzajFajla.get(redniBr));
					out.newLine();
					out.flush();
					this.sadrzajFajla.add(redniBr, "Ne postoji.");
				}else{
					out.write("Ne postoji.");
					out.newLine();
					out.flush();
				}


			} catch (IOException e) {
				e.printStackTrace();
			} finally{
					try {
						if(in != null)
							in.close();
						if(out != null)
							out.close();
						client.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
	}

}

package prviZad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;


public class Client {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int redniBr = sc.nextInt();
		sc.close();

		BufferedReader in = null;
		BufferedWriter out = null;
		try {
			Socket client = new Socket("localhost", Server.PORT);
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new BufferedWriter (new OutputStreamWriter(client.getOutputStream()));

			/*String s;
			while((s = in.readLine()) != null)
				System.out.println(s);*/

			out.write(redniBr);
			out.flush();

			String s = in.readLine();
			System.out.println(s);

			client.close();

		} catch (IOException e) {
			e.printStackTrace();
		} finally{
				try {
					if(in != null)
						in.close();
					if(out != null)
						out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}

}

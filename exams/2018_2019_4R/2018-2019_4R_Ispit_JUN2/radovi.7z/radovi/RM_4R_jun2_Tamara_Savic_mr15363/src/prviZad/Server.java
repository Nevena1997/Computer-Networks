package prviZad;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
	public static final int PORT = 12345;

	public static void main(String[] args) {
		BufferedReader in = null;
		try {
			List<String> sadrzajFajla = new ArrayList<String>();
			in = new BufferedReader(new InputStreamReader(new FileInputStream("serverfile.txt")));

			String s;
			while((s = in.readLine()) != null)
				sadrzajFajla.add(s);

			try {
				ServerSocket server = new ServerSocket(PORT);

				while(true){
					Socket client = server.accept();
					new Nit(client, sadrzajFajla).run();

					boolean signal = true;
					for(int i = 0; i < sadrzajFajla.size(); i++)
						if(!sadrzajFajla.get(i).equals("Ne postoji."))
							signal = false;

					if(signal)
						server.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
				try {
					if(in != null)
						in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

		}


	}

}

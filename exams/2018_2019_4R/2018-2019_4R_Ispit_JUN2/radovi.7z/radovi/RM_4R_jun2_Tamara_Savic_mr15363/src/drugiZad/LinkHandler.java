package drugiZad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLDocument;

public class LinkHandler{
	private JEditorPane jep;
	private JTextArea textArea;

	public LinkHandler(JEditorPane jep, JTextArea textArea) {
		this.jep = jep;
		this.textArea = textArea;
	}

	public void prikazi(){
		try {
			String s = this.textArea.getText();
			URL url = new URL(s);

			int indeks = url.getFile().indexOf(".");
			if(!url.getFile().substring(indeks+1).equalsIgnoreCase("html"))
				jep.setText("<html>URL ne vodi do html fajla.</html>");

			InputStream in = url.openConnection().getInputStream();

			EditorKit htmlKit = jep.getEditorKitForContentType("text/html");
			jep.setEditorKit(htmlKit);
			HTMLDocument doc = (HTMLDocument) htmlKit.createDefaultDocument();

			jep.read(in, doc);

			this.textArea.setText(s);

		} catch (MalformedURLException e) {
			jep.setText("<html>URL nije validan.</html>");;
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void ocisti(){
		BufferedReader in = null;
		BufferedWriter out = null;
		try {
			String s = this.textArea.getText();
			URL url = new URL(s);

			in = new BufferedReader(new InputStreamReader(new FileInputStream(url.getPath())));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(url.getPath())));

			String line;
			int indeksPocetka;
			int indeksKraja;
			StringBuilder sb1 = new StringBuilder();
			while((line = in.readLine()) != null){
				StringBuilder sb = new StringBuilder();
				sb.append(line);
				while((indeksPocetka = line.indexOf("<")) != -1){
					indeksKraja = line.indexOf(">");
					sb.replace(indeksPocetka, indeksKraja , "");
				}
				sb1.append(sb.toString());
			}

			out.write(sb1.toString());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				if(in != null)
					in.close();
				if(out != null)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

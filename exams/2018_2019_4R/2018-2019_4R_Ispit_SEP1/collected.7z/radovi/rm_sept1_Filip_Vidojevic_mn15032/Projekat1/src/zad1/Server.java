package zad1;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public class Server {
	public static int PORT=23456;

	public static void main(String[] args) {
		ServerSocketChannel s=null;
		Selector selector=null;
		try {
			s=ServerSocketChannel.open();
			s.bind(new InetSocketAddress(PORT));
			s.configureBlocking(false);

			selector=Selector.open();
			s.register(selector, SelectionKey.OP_ACCEPT);

			while(true){
				Thread.sleep(1000);
				selector.select();

				Set<SelectionKey> kljucevi=selector.selectedKeys();
				Iterator<SelectionKey> iterator=kljucevi.iterator();
				while(iterator.hasNext()){
					SelectionKey key=iterator.next();
					iterator.remove();

					if(key.isAcceptable()){
						ServerSocketChannel kanal=(ServerSocketChannel) key.channel();
						SocketChannel client=kanal.accept();
						client.configureBlocking(false);
						SelectionKey key2=client.register(selector, SelectionKey.OP_WRITE);
					}
					else if(key.isWritable()){
						SocketChannel client=(SocketChannel) key.channel();

						String datum=new Date().toString();

						datum=datum+"\n";
						ByteBuffer bafer=ByteBuffer.allocate(datum.length());
						bafer.put(datum.getBytes());
						bafer.flip();
						client.write(bafer);


					}


				}
			}
		} catch (IOException e) {

			e.printStackTrace();
		}catch(InterruptedException e){
			e.printStackTrace();
		}finally{

			try {
				if(selector!=null)
					selector.close();
				if(s!=null)
					s.close();
			} catch (IOException e) {

				e.printStackTrace();
			}

		}


	}

}

package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Drugi {

	public static void main(String[] args) {
		JFrame f=new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600,400);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run(){
				f.setVisible(true);
			}


		});
	}
	private static void addComponents(Container pane){
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();

		c.fill=GridBagConstraints.BOTH;
		c.weightx=0.0;
		c.weighty=1.0;
		c.gridx=0;
		c.gridy=2;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=3;

		JScrollPane scrollPane=new JScrollPane(jep);
		pane.add(scrollPane,c);

		JTextArea addressBar=new JTextArea();


		c.fill=GridBagConstraints.HORIZONTAL;
		c.weightx=1.0;
		c.weighty=0.0;
		c.gridx=0;
		c.gridy=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=3;


		pane.add(addressBar,c);

		JButton btnUcitaj=new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				URL u=null;
				String adresa=addressBar.getText();
				if(!adresa.contains(".html"))
				{
					jep.setContentType("text/html");
					jep.setText("<html> nije html</html>");
					jep.setEditable(true);
					return ;
				}
				try {
					u=new URL(adresa);
				} catch (MalformedURLException e1) {
					jep.setContentType("text/html");
					jep.setText("<html> ne valja URL</html>");
					return ;
				}


				try {
					BufferedReader buf=new BufferedReader(new InputStreamReader(u.openStream()));
					String s=null;
					String text="";
					while((s=buf.readLine())!=null)
						text=text+s+"\n";

					jep.setContentType("text/plain");
					jep.setText(text);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		c.fill=GridBagConstraints.BOTH;
		c.weightx=1.0;
		c.weighty=0.0;
		c.gridx=0;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;


		pane.add(btnUcitaj,c);

		JButton btnPrikazi=new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {



					String text=jep.getText();
					jep.setContentType("text/html");
					jep.setText(text);
					jep.setEditable(false);

			}
		});
		c.fill=GridBagConstraints.BOTH;
		c.weightx=1.0;
		c.weighty=0.0;
		c.gridx=1;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;


		pane.add(btnPrikazi,c);

		JButton btnSacuvaj=new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String text=jep.getText();
				try {
					String putanja=addressBar.getText();
					if(putanja.length()<8)
					{
						jep.setContentType("text/html");
						jep.setText("Ne valja putanja za fajl");
						return ;
					}
					OutputStreamWriter wr=new OutputStreamWriter(new FileOutputStream(putanja.substring(7)));
					wr.write(text);
					wr.close();
				} catch (FileNotFoundException e1) {
					jep.setContentType("text/html");
					jep.setText("Ne valja putanja za fajl");
					e1.printStackTrace();
				}catch(IOException e1){
					e1.printStackTrace();
				}
			}
		});
		c.fill=GridBagConstraints.BOTH;
		c.weightx=1.0;
		c.weighty=0.0;
		c.gridx=2;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;


		pane.add(btnSacuvaj,c);



	}


}

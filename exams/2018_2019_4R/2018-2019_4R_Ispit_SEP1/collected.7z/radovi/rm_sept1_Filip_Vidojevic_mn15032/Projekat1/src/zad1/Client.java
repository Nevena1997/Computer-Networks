package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class Client {

	public static void main(String[] args) {

		int brojac=0;
		SocketChannel kanal=null;
		WritableByteChannel out=Channels.newChannel(System.out);
		try {

			kanal=SocketChannel.open(new InetSocketAddress("localhost",Server.PORT));
			while(true){
				if(brojac==5){
					kanal.close();
					out.close();
					break;
				}

				ByteBuffer bafer=ByteBuffer.allocate(50);
				kanal.read(bafer);
				bafer.flip();

				out.write(bafer);
				bafer.clear();
				brojac++;
			}


		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				kanal.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		System.out.println("Klijent prekinuo vezu");
	}

}

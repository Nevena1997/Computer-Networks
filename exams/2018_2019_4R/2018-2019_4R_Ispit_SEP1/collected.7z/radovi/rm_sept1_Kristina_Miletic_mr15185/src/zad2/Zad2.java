package zad2;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Zad2 {
	public static void main(String[] args) {
		JFrame f=new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600,400);

		dodajKomponente(f.getContentPane());

		java.awt.EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});
	}

	private static void dodajKomponente(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		jep.setEditable(true);

		JScrollPane jscroll=new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=2;
		c.gridwidth=3;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=0.0;
		c.weighty=1.0;
		pane.add(jscroll, c);

		JTextArea addressBar=new JTextArea();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridwidth=3;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1.0;
		c.weighty=0.0;
		pane.add(addressBar, c);


		LinkHandler lh=new LinkHandler(jep, addressBar);
		jep.addHyperlinkListener(lh);

		JButton btnUcitaj=new JButton("Ucitaj");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridwidth=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1.0;
		c.weighty=0.0;
		pane.add(btnUcitaj, c);

		btnUcitaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.ucitaj();

			}
		});

		JButton btnPrikazi=new JButton("Prikazi");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=1;
		c.gridwidth=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1.0;
		c.weighty=0.0;
		pane.add(btnPrikazi, c);

		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.prikazi();

			}
		});

		JButton btnSacuvaj=new JButton("Sacuvaj");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=1;
		c.gridwidth=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1.0;
		c.weighty=0.0;
		pane.add(btnSacuvaj, c);

		btnSacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				lh.sacuvaj();

			}
		});
	}


}

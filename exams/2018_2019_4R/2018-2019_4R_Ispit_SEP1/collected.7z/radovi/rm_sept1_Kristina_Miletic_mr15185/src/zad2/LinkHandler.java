package zad2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;

public class LinkHandler implements HyperlinkListener{
	private JEditorPane pane;
	private JTextArea addressBar;

	public LinkHandler(JEditorPane pane, JTextArea addr){
		this.pane=pane;
		this.addressBar=addr;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {

		if(e.getEventType()==EventType.ACTIVATED)

			try {
				this.pane.setPage(e.getURL());

			} catch (IOException e1) {
				this.pane.setContentType("text/html");
				this.pane.setText("<html>Could not load "+e.getURL()+"</html>");
			}
	}

	public void ucitaj(){
		URL url=null;
		String tekst="";
		String s;
		BufferedReader in=null;

		try {
			url=new URL(addressBar.getText());
			if(!url.toString().endsWith(".html") || !url.getProtocol().equalsIgnoreCase("file")){
				this.pane.setContentType("text/html");
				this.pane.setText("<html>URL "+url+" not valid</html>");
			}

			in=new BufferedReader(new InputStreamReader(url.openStream()));

			while((s=in.readLine())!=null){
				tekst+=s+"\n";
			}

			this.pane.setText(tekst);
			in.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void prikazi(){
		try {
			this.pane.setPage(addressBar.getText());
			this.pane.setEditable(false);
		} catch (IOException e) {
			this.pane.setContentType("text/html");
			this.pane.setText("<html>Could not load page</html>");
		}


	}

	public void sacuvaj(){
		String putanja = addressBar.getText().substring(8, addressBar.getText().length());
		OutputStreamWriter out=null;
		String tekst=pane.getText();
		try {
			out=new OutputStreamWriter(new FileOutputStream(putanja));

			out.write(tekst);
			out.flush();

			out.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}

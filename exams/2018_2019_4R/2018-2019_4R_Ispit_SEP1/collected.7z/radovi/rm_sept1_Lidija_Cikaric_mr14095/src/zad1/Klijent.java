package zad1;


import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Klijent {


	public static final int PORT = 23456;

	public static void main(String[] args) {



		// sock ce se ispravno zatvoriti u slucaju izuzetka
		try (Socket sock = new Socket("localhost",PORT)) {


			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));

			System.out.println(out);



		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

}

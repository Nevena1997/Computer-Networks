package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;



public class Zadatak2 {

	public static void main(String[] args) {


		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		f.setSize(500, 400);


		addComponents(f.getContentPane());

		EventQueue.invokeLater(new FrameShower(f));




	}

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane csrollPane = new JScrollPane(jep);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 2;
	//	c.gridheight = 2;
		c.weightx = 0.0;
		c.weighty = 0.0;

		pane.add(csrollPane, c);


		JTextField tf = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(tf,c);

		JButton btnUcitaj = new JButton("ucitaj");
		c.fill = GridBagConstraints.CENTER;
		c.gridx = 0;
		c.gridy = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnUcitaj,c);

		JButton btnPrikazi = new JButton("prikazi");
		c.fill = GridBagConstraints.CENTER;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnPrikazi,c);

		JButton btnSacuvaj = new JButton("sacuvaj");
		c.fill = GridBagConstraints.CENTER;
		c.gridx = 3;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(btnSacuvaj,c);


		JTextArea ta = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 3;
		c.gridy = 5;
		c.ipadx = 2;
		c.ipady = 3;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(ta,c);


		btnUcitaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					URL u = new URL(tf.getText().toString());
					jep.setPage(u);
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					ta.setText("URL nije validan ili ne vodi do HTML fajla.");

					e1.printStackTrace();
				}

			}
		});


		btnPrikazi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {


			}
		});


		btnSacuvaj.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

			}
		});





	}

	public static class FrameShower implements Runnable{

		Frame frame;

		public FrameShower(Frame frame) {
			this.frame = frame;
		}

		@Override
		public void run() {
			this.frame.setVisible(true);

		}

	}
}

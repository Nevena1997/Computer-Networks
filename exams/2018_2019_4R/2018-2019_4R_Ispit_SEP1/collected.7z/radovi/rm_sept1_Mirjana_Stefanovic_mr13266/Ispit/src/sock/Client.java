package sock;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {



			int port=23456;
			String hostname="localhost";

			try {

				Socket socket = new Socket (hostname,port);
				int i=0;

				while(true)

				{
					BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

					int b;

					StringBuffer sb = new StringBuffer("");

					while ((b=br.read())!=-1)
					{
						sb.append((char)b);

					}


					String vreme=sb.toString().trim();
					i++;

					System.out.println("trenutno je "+vreme+" na portu "+port);

					if (i==5)
					{
						socket.close();
						break;}

				}


			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}









	}

}

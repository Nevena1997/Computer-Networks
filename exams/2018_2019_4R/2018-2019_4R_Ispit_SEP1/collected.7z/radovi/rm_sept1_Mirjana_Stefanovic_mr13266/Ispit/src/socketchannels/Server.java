package socketchannels;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;

public class Server {

	public static void main(String[] args){

		ByteBuffer buf;
		InetSocketAddress adr;
		int port=12345;


		try (ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector=Selector.open())

		{

			serverChannel.bind(new InetSocketAddress(port));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			while(true)
			{

				selector.select();
				Iterator<SelectionKey> iterator=selector.selectedKeys().iterator();

				while (iterator.hasNext())
				{
					SelectionKey key=iterator.next();
					iterator.remove();

					if (key.isAcceptable())

					{

						ServerSocketChannel server=(ServerSocketChannel)key.channel();
						SocketChannel client=server.accept();

						client.configureBlocking(false);
						client.register(selector, SelectionKey.OP_WRITE);

                    }

					else if (key.isWritable())

					{
						SocketChannel client=(SocketChannel)key.channel();

					    Date now=new Date();
					    byte[] niz=now.toString().getBytes();
					    ByteBuffer buff=ByteBuffer.wrap(niz);

					    if(buff.hasRemaining())
					    	client.write(buff);

					    key.attach(buff);
					    key.interestOps(SelectionKey.OP_WRITE);


					}




				}



			}




		} catch (IOException e) {

			e.printStackTrace();
		}



	}


}

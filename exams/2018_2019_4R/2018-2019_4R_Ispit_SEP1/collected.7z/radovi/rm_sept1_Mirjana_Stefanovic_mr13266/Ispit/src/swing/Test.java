package swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Test {

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800,600);
		f.setResizable(true);

		addComponents(f);

		EventQueue.invokeLater(new FrameShower(f));


	}

	public static class FrameShower implements Runnable {

		private Frame f;

		FrameShower(Frame f){
			this.f=f;
		}

		@Override
		public void run() {
			this.f.setVisible(true);

		}


	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		jep.setEditable(true);

		JScrollPane sc = new JScrollPane(jep);

		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=2;
		c.gridwidth=3;
		c.weighty=1;
		c.weightx=1;
		c.ipadx=0;
		c.ipady=0;

		pane.add(sc,c);

		JTextField tf = new JTextField();

	    c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridwidth=3;
		c.weighty=0;
		c.weightx=1;
		c.ipadx=0;
		c.ipady=0;

		pane.add(tf, c);

		JButton ucitajBtn = new JButton();
		ucitajBtn.setText("Ucitaj");

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridwidth=1;
		c.weighty=0;
		c.weightx=1;
		c.ipadx=0;
		c.ipady=0;

		ucitajBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				URL url;
				try {

					url = new URL(tf.getText());

					if(!tf.getText().endsWith("html") && !tf.getText().endsWith("HTML"))
					{
						System.out.println("URL ne vodi do html fajla.");
						jep.setContentType("text/html");
						jep.setText("<html><h1>URL ne vodi do html fajla!</h1><html>");

					}

					else {

					BufferedReader br=new BufferedReader(new InputStreamReader(url.openStream()));
					String tekst="";
					String s=null;

					while ((s=br.readLine())!=null)
						tekst+=s+"\n";

					jep.setText(tekst);  }


				} catch (MalformedURLException e) {
					jep.setText("URL nije validan.");
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}
		});

		pane.add(ucitajBtn,c);

		JButton prikaziBtn = new JButton();
		prikaziBtn.setText("Prikazi");

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=1;
		c.gridwidth=1;
		c.weighty=0;
		c.weightx=1;
		c.ipadx=0;
		c.ipady=0;



		pane.add(prikaziBtn,c);

		prikaziBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				String tekst=jep.getText();
				jep.setContentType("text/html");
				jep.setText(tekst);
				jep.setEditable(false);

			}
		});

		JButton sacuvajBtn = new JButton();
		sacuvajBtn.setText("Sacuvaj");

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=1;
		c.gridwidth=1;
		c.weighty=0;
		c.weightx=1;
		c.ipadx=0;
		c.ipady=0;

		pane.add(sacuvajBtn,c);

		sacuvajBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				String putanja=tf.getText().substring(8, tf.getText().length());

				try {


					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(putanja)));
					bw.write(jep.getText());
					bw.flush();
					bw.close();



				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}
		});



	}

}

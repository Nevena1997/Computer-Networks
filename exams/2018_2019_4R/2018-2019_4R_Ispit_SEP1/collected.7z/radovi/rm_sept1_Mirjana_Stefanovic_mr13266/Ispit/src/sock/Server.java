package sock;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {

	public static int port=23456;
	public static String hostname="localhost";

	public static void main (String[] args)

	{


		try {


			ServerSocket server=new ServerSocket(port);
			System.out.println("Server started...");

			while (true)
			{

				Socket conn=server.accept();
				//System.out.println("Accepted connection from "+conn.getLocalPort());
				Date now=new Date();

				String vreme=now.toString();
				//System.out.println(vreme);

				BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
				bw.write(vreme);
				bw.flush();

				Thread.sleep(1000);


			}



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


}




}
package zad1;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class Client {

	public static void main(String[] args) {



		try (SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", 23456)); WritableByteChannel out = Channels.newChannel(System.out)){

			ByteBuffer buffer = ByteBuffer.allocate(256);

			int i = 0;


			while(true){

				if(i == 5)
					break;
				int n = client.read(buffer);

				if(n > 0){

					if(!buffer.hasRemaining()){

						buffer.flip();
						out.write(buffer);
						buffer.clear();
						i ++;
					}
				}

				if(n == -1)
					break;
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

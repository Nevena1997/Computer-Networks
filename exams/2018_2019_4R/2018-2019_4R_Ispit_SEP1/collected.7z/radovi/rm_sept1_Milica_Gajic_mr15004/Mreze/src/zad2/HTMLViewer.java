package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;



public class HTMLViewer {

	public static void main(String[] args) {

		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 400);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {

				f.setVisible(true);

			}
		});

	}

	private static void addComponents(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane srcoll = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 1.0;

		contentPane.add(srcoll, c);

		JTextArea addr = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;

		contentPane.add(addr, c);

		JButton ucitaj = new JButton("Ucitaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;

		ucitaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String url = addr.getText().trim();

				try {
					URL u = new URL(url);
					URLConnection uc = u.openConnection();
					if(!uc.getContentType().startsWith("text/html")){
						jep.setContentType("text/html");
						jep.setText("<html>Nije html fajl</html>");

					}

					else{

						jep.setContentType("text/plain");
						jep.setPage(u);

					}


				} catch (IOException e1) {
									}
				jep.setContentType("text/html");
				jep.setText("<html>Neispravan url</html>");
			}
		});

		contentPane.add(ucitaj, c);

		JButton prikazi = new JButton("Prikazi");

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String text = jep.getText();

				jep.setContentType("text/plain");
				jep.setText(text);

			}
		});

		contentPane.add(prikazi, c);

		JButton sacuvaj = new JButton("Sacuvaj");

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;

		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String url = addr.getText().trim();

				try {
					URL u = new URL(url);

					String file = u.getFile();

					FileOutputStream out = new FileOutputStream(file);

					jep.setContentType("text/html");
					byte[] content = jep.getText().getBytes();

				    out.write(content);

				    out.close();


				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					jep.setContentType("text/html");
					jep.setText("<html> Neispravan url</html>");
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		contentPane.add(sacuvaj, c);

	}

}

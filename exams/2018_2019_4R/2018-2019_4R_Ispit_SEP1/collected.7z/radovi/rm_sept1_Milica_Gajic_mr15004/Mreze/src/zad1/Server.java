package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;



public class Server {

	public static void main(String[] args) {

		try(ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open()) {

			server.bind(new InetSocketAddress(23456));
			server.configureBlocking(false);
			server.register(selector, SelectionKey.OP_ACCEPT);

			while(true){

				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();

				Iterator<SelectionKey> iter = readyKeys.iterator();

				while(iter.hasNext()){

					SelectionKey key = iter.next();
					iter.remove();

					if(key.isAcceptable()){

						ServerSocketChannel s = (ServerSocketChannel) key.channel();
						SocketChannel client = s.accept();
						client.configureBlocking(false);
						SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);

						ByteBuffer buffer = ByteBuffer.allocate(256);

						Date now = new Date();

						dataForBuffer(now, buffer);


						key2.attach(buffer);

					}
					else if(key.isWritable()){


						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer buffer = (ByteBuffer) key.attachment();

						if(!buffer.hasRemaining()){

							buffer.clear();
							Date now = new Date();

							dataForBuffer(now, buffer);

							buffer.flip();


						}

						client.write(buffer);
					}

				}

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@SuppressWarnings("deprecation")
	private static void dataForBuffer(Date now, ByteBuffer buffer) {



		String date = now.toGMTString();
		byte[] buf = date.getBytes();

		buffer.put(buf);
		buffer.put((byte)'\r');
		buffer.put((byte)'\n');
		buffer.flip();


	}

}

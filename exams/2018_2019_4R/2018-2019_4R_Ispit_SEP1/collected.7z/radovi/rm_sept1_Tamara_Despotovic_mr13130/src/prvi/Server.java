package prvi;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.util.Iterator;
import java.util.Set;

public class Server {
public static final int PORT=23456;
	public static void main(String[] args) {

try {
	ServerSocketChannel server=ServerSocketChannel.open();
server.configureBlocking(false);
Selector selector=Selector.open();

while(true){
	selector.select();
	Set<SelectionKey> key=selector.selectedKeys();

	Iterator<SelectionKey> iterator=key.iterator();
	while(iterator.hasNext()){
		SelectionKey key1=iterator.next();

		if(key1.isAcceptable()){

		}else if(key1.isReadable()){

		}else if(key1.isWritable()){
	}
}
}




} catch (IOException e) {

	e.printStackTrace();
}
	}

}

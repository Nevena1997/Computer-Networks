package prvi;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;


public class Client {

	public static void main(String[] args) {
		String host="localhost";
		int port=Server.PORT;
		try{
		SocketAddress address=new InetSocketAddress(host,port);
		SocketChannel client=null;
		client=SocketChannel.open(address);
       client.configureBlocking(false);
		ByteBuffer buf=ByteBuffer.allocate(74);
      int broj=0;

      WritableByteChannel out=Channels.newChannel(System.out);
      while(true){
    	  int n=client.read(buf);
    	  if(n>0){
    		  buf.flip();
    		  out.write(buf);
    	  }
    	  broj++;
    	  if(broj==5){
    		  broj=0;
    		  client.close();
    	  }
      }



		}catch(IOException e){
			e.printStackTrace();

		}
	}

}

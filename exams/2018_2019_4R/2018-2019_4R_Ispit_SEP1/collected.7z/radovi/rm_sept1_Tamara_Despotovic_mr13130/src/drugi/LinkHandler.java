package drugi;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

public class LinkHandler implements HyperlinkListener{
private JEditorPane pane;
private JTextArea addressBar;

public LinkHandler(JEditorPane pane,JTextArea addressBar ){
	this.pane=pane;
	this.addressBar=addressBar;
//public setAddressBar(JTextArea addressBar){
//	this.addressBar=addressBar;
//}
}
	public void  hyperlinkUpdate (HyperlinkEvent evt){
HyperlinkEvent.EventType type=evt.getEventType();
URL u=evt.getURL();
if(type==HyperlinkEvent.EventType.ACTIVATED){
try {
	this.pane.setPage(u);
} catch (IOException e) {

	e.printStackTrace();
}
}else if(type== HyperlinkEvent.EventType.ENTERED){
this.goToPage(u);
}else if(type==HyperlinkEvent.EventType.EXITED){
this.pane.setText("wow");
}
	}


	public void goToPage(URL url){
		this.changeView(url);

	}

	public void changeView(URL url){
		try{
			this.pane.setPage(url);
		}catch(MalformedURLException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

public void ucitaj() {
	ParserGetter pg=new ParserGetter();

//	ParserCallbackImpl pc=new ParserCallbackImpl();
HTMLEditorKit pc=new HTMLEditorKit();
}

public void prikazi() {
	// TODO Auto-generated method stub

}
public void setAddressBar(JTextArea addressBar2) {
	this.addressBar=addressBar2;

}
public void sacuvaj() {
	// TODO Auto-generated method stub

}






}

package drugi;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback {
private Writer out;

public ParserCallbackImpl(Writer out){
	this.out=out;
}

public void HandleText(char []text,int position){
try {
	this.out.write(text);
	this.out.write("\r\n");
	this.out.flush();
} catch (IOException e) {

	e.printStackTrace();
}

}
}

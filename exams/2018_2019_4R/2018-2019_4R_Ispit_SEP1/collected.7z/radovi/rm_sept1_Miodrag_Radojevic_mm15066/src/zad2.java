import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class zad2 {

    private static final String ls=System.getProperty("line.separator","\r\n");

    private static String text="FILE:///home/student/Desktop/rm_sept1_Miodrag_Radojevic_mm15066/1.html";

    private static URL poslednji=null;
    public static void main(String[] args) {

        JFrame f=new JFrame("test");
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.setSize(600,400);

        Container pane=f.getContentPane();
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c=new GridBagConstraints();

        JEditorPane jep=new JEditorPane();
        jep.setEditable(true);
        JScrollPane scrollPane=new JScrollPane(jep);
        c.fill=GridBagConstraints.BOTH;
        c.gridx=0;
        c.gridy=2;
        c.weightx=0;
        c.weighty=0.94;
        c.gridwidth=3;
        c.ipadx=0;
        c.ipady=0;
        pane.add(scrollPane,c);

        JButton ucitaj=new JButton("Ucitaj");
        c.fill=GridBagConstraints.BOTH;
        c.gridx=0;
        c.gridy=1;
        c.weightx=0.3333;
        c.weighty=0.03;
        c.gridwidth=1;
        c.ipadx=0;
        c.ipady=0;
        pane.add(ucitaj,c);

        JButton prikazi=new JButton("Prikazi");
        c.fill=GridBagConstraints.BOTH;
        c.gridx=1;
        c.gridy=1;
        c.weightx=0.3333;
        c.weighty=0.03;
        c.gridwidth=1;
        c.ipadx=0;
        c.ipady=0;
        pane.add(prikazi,c);

        JButton sacuvaj=new JButton("Sacuvaj");
        c.fill=GridBagConstraints.BOTH;
        c.gridx=2;
        c.gridy=1;
        c.weightx=0.3333;
        c.weighty=0.03;
        c.gridwidth=1;
        c.ipadx=0;
        c.ipady=0;
        pane.add(sacuvaj,c);

        JTextArea ta=new JTextArea();
        c.fill=GridBagConstraints.BOTH;
        c.gridx=0;
        c.gridy=0;
        c.weightx=0.0;
        c.weighty=0.03;
        c.gridwidth=3;
        c.ipadx=0;
        c.ipady=0;
        pane.add(ta,c);

        StringBuilder sb=new StringBuilder();

        ucitaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String u=ta.getText().trim();
                //u=text;// ova linija kada nije u komentaru daje dirktnu putanju
                if(!u.contains(".html"))
                    ta.setText("Nije dat URL do HTML fajla.");
                else { URL url=null;
                    try {
                        url = new URL(u);
                        } catch (MalformedURLException e1) {
                        ta.setText("Dati URL nije validan.");
                    }

                    if(!url.getProtocol().equalsIgnoreCase("FILE"))
                        ta.setText("Nije FILE protokol u pitanju.");

                    if(!Files.isReadable(Paths.get(url.getPath())))
                        ta.setText("Nije zadata putanja do fajla koji se moze citati, mozda fajl ne postoji.");
                    else {
                        if (url != null) {
                            try (BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()))) {
                                String pom;
                                sb.delete(0,sb.length());//brisemo sadrzaj buffera
                                while ((pom=br.readLine())!=null){
                                    sb.append(pom);
                                    sb.append(ls);
                                }
                                jep.setContentType("text/plain");
                                jep.setEditable(true);
                                poslednji=url;
                                jep.setText(sb.toString());
                            } catch (IOException e1) {
                                ta.setText("Greska pri otvaranju streama za dati fajl.");
                            }

                        }
                    }
                }
            }
        });

        prikazi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String kod=jep.getText();
                jep.setContentType("text/html");
                jep.setText(kod);
                jep.setEditable(false);
            }
        });

        sacuvaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String izmenjenKod=jep.getText();
                if(poslednji!=null){
                    File file=new File(poslednji.getPath());
                    String text=jep.getText();
                    try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)))) {
                        bw.write(text);
                        bw.flush();
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }


                }
            }
        });

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                f.setVisible(true);
            }
        });

    }

}

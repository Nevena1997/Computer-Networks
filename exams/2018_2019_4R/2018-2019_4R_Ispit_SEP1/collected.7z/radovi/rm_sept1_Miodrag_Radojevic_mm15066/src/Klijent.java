import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Klijent {

    private static final int NUM=5;

    public static void main(String[] args) {

        try (Socket sock = new Socket("localhost", Server.DEF_PORT);
             BufferedReader br=new BufferedReader(new InputStreamReader(sock.getInputStream()))) {
            String pom;
            for(int i=0;i<NUM;i++){
                if ((pom=br.readLine())!=null)
                    System.out.println(pom);
                else
                    break;// inace izlazimo iz petlje,ako je server prekinuo vezu
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}

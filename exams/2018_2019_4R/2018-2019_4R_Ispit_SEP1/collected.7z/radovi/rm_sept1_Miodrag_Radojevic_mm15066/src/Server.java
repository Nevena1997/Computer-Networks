import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;

import static java.lang.Thread.sleep;

public class Server {

    public static final int DEF_PORT=23456;

    public static void main(String[] args) {


        try (ServerSocketChannel serverChannel = ServerSocketChannel.open();
             Selector selector=Selector.open()) {
            serverChannel.bind(new InetSocketAddress(DEF_PORT));
            serverChannel.configureBlocking(false);

            serverChannel.register(selector, SelectionKey.OP_ACCEPT);

            while(true){

                selector.select();
                Iterator<SelectionKey> iterator=selector.selectedKeys().iterator();

                while (iterator.hasNext()){

                 SelectionKey key=iterator.next();
                 iterator.remove();

                 if(key.isAcceptable()){
                  ServerSocketChannel server=(ServerSocketChannel)key.channel();
                  SocketChannel klijent=server.accept();
                  System.out.println("Server je prihvatio klijenta....");//cisto zbog vodjenja evidencije
                  klijent.configureBlocking(false);
                  StringBuffer sb=new StringBuffer();

                    Date d=new Date();
                    sb.append(format(d)+"\r\n");
                  // ovde je potrebno izvuci datum!
                     key=klijent.register(selector,SelectionKey.OP_WRITE);// probamo ovako
                     key.attach(ByteBuffer.wrap(sb.toString().getBytes()));

                 }else if(key.isWritable()){
                     SocketChannel klijent=(SocketChannel)key.channel();
                     ByteBuffer buf=(ByteBuffer)key.attachment();
                     if(!buf.hasRemaining()){
                         buf.rewind();
                         buf.clear();
                         StringBuilder sb=new StringBuilder();
                         Date d=new Date();
                         sb.append(format(d)+"\r\n");
                         buf=ByteBuffer.wrap(sb.toString().getBytes());
                         key.attach(buf);
                     }
                     try {
                                 klijent.write(buf);
                         } catch (IOException e) {
                             key.cancel();//klijent je prekinuo vezu
                         }


                 }
                 sleep(1000);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            //e.printStackTrace();
        }


    }

    private static String format(Date d){
        String god=d.toString().substring(d.toString().lastIndexOf(' ')+1);
        return naDvaPolja(d.getDay())+"-"+naDvaPolja(d.getMonth())+"-"+god+" "+naDvaPolja(d.getMinutes())+":"+naDvaPolja(d.getSeconds());
    }

    private static String naDvaPolja(int br){
        if(br<10){
            return "0"+br;
        }
        return String.valueOf(br);
    }

}

package zadatak_1;

public class Server {

	public static final int PORT = 23456;
	
}

package zadatak_2;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLEditorKit.Parser;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

import com.sun.java_cup.internal.runtime.Scanner;


public class HTMLEditor {
	
	public static String FILE_PATH = null;

	public static void main(String[] args){
		
		JFrame frame = new JFrame("HTML Editor");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 500);
		
		addComponents(frame);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				frame.setVisible(true);
			}
		});
		
	}
	
	private static void addComponents(JFrame frame){
		
		frame.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		

		JTextArea ta = new JTextArea();
		ta.setEditable(true);
		JScrollPane scroll = new JScrollPane(ta);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridheight = 1;
		c.gridwidth = 3;
		frame.add(scroll, c);
		
		JTextField tf = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridheight = 1;
		c.gridwidth = 3;
		frame.add(tf, c);
		
		JButton ucitaj = new JButton("Ucitaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0.3;
		c.weighty = 0.0;
		c.gridheight = 1;
		c.gridwidth = 1;
		frame.add(ucitaj, c);
		
		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0.3;
		c.weighty = 0.0;
		c.gridheight = 1;
		c.gridwidth = 1;
		frame.add(prikazi, c);
		
		JButton sacuvaj = new JButton("Sacuvaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.weightx = 0.3;
		c.weighty = 0.0;
		c.gridheight = 1;
		c.gridwidth = 1;
		frame.add(sacuvaj, c);
		
		ucitaj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					try {
						FILE_PATH = tf.getText();
						if(!FILE_PATH.contains(".html")){
							ta.setText("Not an HTML file");
							FILE_PATH = null;
						}
						else{
							ta.setText("");
							URL url = new URL(FILE_PATH);
							BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
							
							String line = null;
							while((line = in.readLine()) != null)
								ta.append(line + "\n");
							in.close();
						}
					} catch (MalformedURLException e1) {
						ta.setText("Invalid URL");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						ta.setText("Caught IOException");
					}
				
			}
		});
		
		// this one doesn't work exactly as planned
		// instead of visually displaying HTML, it just prints out text without tags
		// could've probably used textarea.setDocument() but ran out of time:)
		
		prikazi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String taString = ta.getText();
				
				
				try {
					Reader r = new StringReader(taString);
					ParserGetter pg = new ParserGetter();
					ParserCallbackImpl pc = new ParserCallbackImpl(r, ta);
					Parser p = pg.getParser();
					p.parse(r, pc, true);
					//set Text Area non editable after this
					ta.setEditable(false);
					r.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		sacuvaj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					String taText = ta.getText();
					URL url = new URL(FILE_PATH);
					String path = url.getPath();
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(path))));
					out.write(taText);
					out.flush();
					out.close();
				} catch (FileNotFoundException e1) {
					ta.setText("File for saving not found");
				} catch (MalformedURLException e1) {
					ta.setText("Invalid URL for saving the file");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					ta.setText("Caught IOException while trying to save to file");
				}
				
			}
		});
		
	}
	
}

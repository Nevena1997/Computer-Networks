package zadatak_2;

import java.io.BufferedReader;
import java.io.Reader;

import javax.swing.JTextArea;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImpl extends ParserCallback{

	private JTextArea ta;
	private Reader r;

	public ParserCallbackImpl(Reader r, JTextArea ta){
		this.ta = ta;
		this.ta.setText("");
		this.r = r;
	}
	
	

	@Override
	public void handleText(char[] data, int pos) {
		this.ta.append((new String(data)) + "\n");
	}

}

package zad1;

import java.net.InetAddress;
import java.net.Socket;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Client {

	public static void main(String args[]){

		try{

			Socket socket = new Socket(InetAddress.getByName("localhost"), Server.PORT);
			System.err.println("Connected");
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out));

			for(int i=0; i<5; i++){
				String datum = in.readLine();
				out.write(datum);
			}

			System.err.println("Closing connection");
			in.close();
			out.close();
			socket.close();

		}catch(IOException e){
			e.printStackTrace();
		}

	}

}

/**
 * 
 */
/**
 * @author nalog
 *
 */
package zad1;
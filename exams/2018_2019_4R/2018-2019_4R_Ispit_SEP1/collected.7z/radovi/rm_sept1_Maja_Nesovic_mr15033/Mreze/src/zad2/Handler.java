package zad2;

import java.net.URL;
import java.net.MalformedURLException;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;


public class Handler implements HyperlinkListener {

	private JEditorPane jep;
	private JTextArea txtArea;

	public Handler(JEditorPane jep, JTextArea txtArea){
		this.jep = jep;
		this.txtArea = txtArea;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {

		HyperlinkEvent.EventType type = e.getEventType();

		if(type == HyperlinkEvent.EventType.ACTIVATED){

			try {
				this.jep.setPage(new URL("FILE:///home/user/1.html"));
			} catch(FileNotFoundException e1){
				this.jep.setContentType("text/html");
				this.jep.setText("<html> URL nije validan. </html>");
			} catch (MalformedURLException e1) {
				this.jep.setContentType("text/html");
				this.jep.setText("<html> URL nije validan. </html>");
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}else if(type == HyperlinkEvent.EventType.ENTERED){

		}else if(type == HyperlinkEvent.EventType.EXITED){

		}
	}

	public void ucitaj(){

		try {
			this.jep.setPage(new URL(this.txtArea.getText().toString()));
		} catch(FileNotFoundException e1){
			this.jep.setContentType("text/html");
			this.jep.setText("<html> URL nije validan. </html>");
		}catch (MalformedURLException e1) {
			this.jep.setContentType("text/html");
			this.jep.setText("<html> URL nije validan. </html>");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	public void prikazi(){


		jep.setEditable(false);
	}

	public void sacuvaj(){

	}
}

package zad1;

import java.io.IOException;
//import java.io.BufferedReader;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.net.InetSocketAddress;

import java.util.Set;
import java.util.Iterator;
import java.util.Date;

public class Server {

	public static final int PORT = 23456;

	public static void main(String args[]){

		try(ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open()){



			server.bind(new InetSocketAddress(PORT));
			server.configureBlocking(false);
			server.register(selector, SelectionKey.OP_ACCEPT);

			System.err.println("Server started...");

			while(true){
				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while(iterator.hasNext()){

					SelectionKey key = iterator.next();
					iterator.remove();

					try{

						if(key.isAcceptable()){
							ServerSocketChannel channel = (ServerSocketChannel)key.channel();
							SocketChannel cli = channel.accept();
							//SelectionKey key2 = cli.register(selector, SelectionKey.OP_WRITE);
							ByteBuffer buffer = ByteBuffer.allocate(4096);

							buffer.put(new Date().toString().getBytes());
							buffer.put((byte) '\n');
							buffer.flip();

							//key2.attach(buffer);
							key.attach(buffer);
						}else if(key.isWritable()){
							SocketChannel client = (SocketChannel) key.channel();
							client.register(selector, SelectionKey.OP_WRITE);
							ByteBuffer buffer = (ByteBuffer) key.attachment();
							if(! buffer.hasRemaining()){

								buffer.rewind();
								buffer.clear();

								buffer.put(new Date().toString().getBytes());
								buffer.put((byte) '\n');
								buffer.flip();
							}
							client.write(buffer);
						}

					}catch(IOException e){

						key.cancel();
						try{
							key.channel().close();
						}catch(Exception ex){

						}
					}

					try {
						Thread.sleep(1000);
					} catch (InterruptedException exx) {
						exx.printStackTrace();
					}
				}
			}


		}catch(IOException e){
			e.printStackTrace();
		}

	}


}

package zad2;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.PlainDocument;
import javax.swing.text.html.HTMLDocument;

public class Glavna {

	public static void main(String[] args) {
		JFrame frame = new JFrame("test");
		frame.setSize(600, 400);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(frame);

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}

	private static void addComponents(JFrame frame) {
		frame.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextField tf = new JTextField();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 0;
		c.gridheight = 1;
		c.gridwidth = 3;
		c.fill = GridBagConstraints.HORIZONTAL;
		frame.add(tf, c);

		JButton ucitaj = new JButton("Ucitaj");
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1/(double)3;
		c.weighty = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		frame.add(ucitaj, c);

		JButton prikazi = new JButton("Prikazi");
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 1/(double)3;
		c.weighty = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		frame.add(prikazi, c);

		JButton sacuvaj = new JButton("Sacuvaj");
		c.gridx = 2;
		c.gridy = 1;
		c.weightx = 1/(double)3;
		c.weighty = 0;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		frame.add(sacuvaj, c);

		JEditorPane ep = new JEditorPane();
		JScrollPane sp = new JScrollPane(ep);
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1;
		c.weighty = 1;
		c.gridheight = 1;
		c.gridwidth = 3;
		c.fill = GridBagConstraints.BOTH;
		frame.add(sp, c);

		ucitaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				/* FILE:///C:\Users\nalog\Desktop\rm_sept1_Aleksandar_Ivanovic_mr15208\1.html */
				ep.setEditable(true);
				ep.setContentType("text/plain");
				ep.setText("");
				BufferedReader in = null;
				try {

					URL url = new URL(tf.getText());
					in = new BufferedReader(new InputStreamReader(url.openStream()));

					String tekst = "";
					String s = null;
					while((s = in.readLine()) != null)
						tekst += s  + "\n";

					ep.setText(tekst);

				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				} finally {
					if(in != null) {
						try {
							in.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
		});

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				BufferedReader in = null;
				try {

					URL url = new URL(tf.getText());
					in = new BufferedReader(new InputStreamReader(url.openStream()));

					String tekst = "";
					String s = null;
					while((s = in.readLine()) != null)
						tekst += s  + "\n";

					ep.setContentType("text/html");
					ep.setText(tekst);
					ep.setEditable(false);
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				} finally {
					if(in != null) {
						try {
							in.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}

			}
		});

		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				BufferedWriter out = null;
				try {
					out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tf.getText().substring(8,tf.getText().length()))));
					out.write(ep.getText());
					out.write("\n");
					out.flush();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				} finally {
					if(out != null) {
						try {
							out.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}


			}
		});

	}
}

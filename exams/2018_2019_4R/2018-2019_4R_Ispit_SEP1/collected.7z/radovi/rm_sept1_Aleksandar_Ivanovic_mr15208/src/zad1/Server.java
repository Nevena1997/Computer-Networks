package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public class Server extends Thread {
	public static final int PORT = 23456;
	public Server() {
	}
	public static void main(String[] args) {
		new Server().start();
	}

	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		try (ServerSocketChannel server = ServerSocketChannel.open(); Selector selector = Selector.open()) {
			server.bind(new InetSocketAddress(PORT));
			server.configureBlocking(false);
			server.register(selector, SelectionKey.OP_ACCEPT);
			while(true) {

				selector.select(); /* kazemo serveru da na svaku sekundu proveri ko hoce
											da se poveze i onima koji su vec povezani da posalje poruku */
				Thread.sleep(1000);
				Set<SelectionKey> selectedKeys = selector.selectedKeys();
				Iterator<SelectionKey> i = selectedKeys.iterator();
				while(i.hasNext()) {
					SelectionKey key = i.next();
					try {

						i.remove();
						if(key.isAcceptable()) {
							ServerSocketChannel ser = (ServerSocketChannel) key.channel();
							SocketChannel client = ser.accept();
							client.configureBlocking(false);
							client.register(selector, SelectionKey.OP_WRITE);
						} else if(key.isWritable()) {
							SocketChannel client = (SocketChannel) key.channel();
							Date date = new Date();

							String datum = date.getDate()+":"+date.getMonth()+":"+(date.getYear()+1900) + " " + date.getMinutes() + ":" + date.getSeconds();
							ByteBuffer buf = ByteBuffer.wrap(datum.getBytes());
							while(buf.hasRemaining())
								client.write(buf);
							byte[] x = new byte[1];
							x[0] = (byte) -1;
							buf = ByteBuffer.wrap(x); /* ovde saljemo -1 jedan za kraj ovog unosa */
							while(buf.hasRemaining())
								client.write(buf);
						}
					} catch(Exception e) {
						key.cancel();
						if(key.channel() != null)
							key.channel().close();
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

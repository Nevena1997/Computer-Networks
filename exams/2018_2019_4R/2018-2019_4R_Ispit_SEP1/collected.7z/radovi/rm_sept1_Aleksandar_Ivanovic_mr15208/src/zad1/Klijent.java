package zad1;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Klijent {

	public static void main(String[] args) {
		try ( Socket socket = new Socket("localhost", Server.PORT); InputStreamReader in = new InputStreamReader(socket.getInputStream()); ) {
			int brojac = 0;
			while(true) {

				String s = "";
				int i = 0;
				while((i = (byte) in.read()) != -1) { /* kad primimo -1 znaci da smo u s skupili ceo datum */
				  s += (char) i;
				}
				System.out.println(s);
				brojac++;
				if(brojac == 5)
					break;
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

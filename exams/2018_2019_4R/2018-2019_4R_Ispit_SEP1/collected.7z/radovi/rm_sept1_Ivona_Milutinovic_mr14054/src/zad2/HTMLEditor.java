package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLDocument;

public class HTMLEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame("test");
		frame.setSize(600,800);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		addComponents(frame);
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane jsp = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 0;
		c.weighty = 1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(jsp,c);

		JTextField tf = new JTextField("file:///C:/Users/nalog/workspace/rm_sept1_Ivona_Milutinovic_mr14054/1.html");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 0;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(tf,c);

		JButton ucitaj = new JButton("Ucitaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0.33;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(ucitaj,c);

		ucitaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				URL url = null;
				try {
					url = new URL(tf.getText());

					if(!url.toString().endsWith(".html"))
						jep.setText("Zadati URL" + url.toString() +"ne vodi do html fajla");
					else{
						BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
						String s = null;
						StringBuffer sb = new StringBuffer();
						while((s = in.readLine()) != null)
							sb.append(s + "\n");

						jep.setText(sb.toString());

					}
				} catch (MalformedURLException e1) {
					jep.setText("Zadati URL" + url.toString() +"nije validan");
				} catch(IOException e2){
					e2.printStackTrace();
				}
			}
		});

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0.33;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(prikazi,c);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String s = jep.getText();
				EditorKit editorKit = (EditorKit) jep.getEditorKitForContentType("text/html");
				HTMLDocument doc = (HTMLDocument) editorKit.createDefaultDocument();
				jep.setEditorKit(editorKit);
				jep.setEditable(false);

				// ideja: procitati sadrzaj teksta, sacuvati ga negde, a zatim citati iz tog fajla

				// cuvamo tekst
				OutputStreamWriter out;
				try {
					out = new OutputStreamWriter(new FileOutputStream("file:///C:/Users/nalog/workspace/rm_sept1_Ivona_Milutinovic_mr14054/sadrzaj"));
					out.write(jep.getText());
					out.flush();
					System.out.println(jep.getText());
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				URL url = null;
				try {
					url = new URL("file:///C:/Users/nalog/workspace/rm_sept1_Ivona_Milutinovic_mr14054/1.html");
					jep.setPage(url);

				}catch(IOException e1){
					e1.printStackTrace();
				}

			}
		});

		JButton sacuvaj = new JButton("Sacuvaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.weightx = 0.34;
		c.weighty = 0;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(sacuvaj,c);

		sacuvaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String s = tf.getText().substring(7);
				OutputStreamWriter out;
				try {
					out = new OutputStreamWriter(new FileOutputStream(s));
					out.write(jep.getText());
					out.flush();

				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
	}


}

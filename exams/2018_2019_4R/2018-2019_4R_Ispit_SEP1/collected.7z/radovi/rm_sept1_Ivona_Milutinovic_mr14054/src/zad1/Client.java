package zad1;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

public class Client {

	public static void main(String[] args) {

		int counter = 0;
		try(SocketChannel client = SocketChannel.open(new InetSocketAddress("localhost", Server.PORT)); WritableByteChannel out = Channels.newChannel(System.out)){

			ByteBuffer buffer = ByteBuffer.allocate(32);


				while(client.read(buffer) != -1){
					buffer.flip();
					out.write(buffer);
					buffer.clear();
					counter++;
					if(counter >= 5)
						break;
				}

		}catch(IOException e){
			e.printStackTrace();
		}
	}


}
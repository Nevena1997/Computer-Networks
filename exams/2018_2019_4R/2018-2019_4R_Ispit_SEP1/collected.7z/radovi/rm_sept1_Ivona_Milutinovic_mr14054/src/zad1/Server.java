package zad1;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;

public class Server {

	public static final int PORT = 23457;

	public static void main(String[] args) {

		try(ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()){

			if(!serverChannel.isOpen() || !selector.isOpen() ){
				System.err.println("Serverski kanal ili selektor nisu otvoreni");
				System.exit(-1);
			}

			serverChannel.configureBlocking(false);
			serverChannel.bind(new InetSocketAddress(PORT));

			serverChannel.register(selector, SelectionKey.OP_ACCEPT);


			while(true){

				selector.select();

				Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();

				while(iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();
					try{
						if(key.isAcceptable()){
							ServerSocketChannel server = (ServerSocketChannel) key.channel();
							SocketChannel client = server.accept();
							client.configureBlocking(false);
							SelectionKey key2 = client.register(selector, SelectionKey.OP_WRITE);

							StringBuffer sb = new StringBuffer();
							sb.append(new Date().getDate());
							sb.append("-");
							sb.append(new Date().getMonth() + 1);
							sb.append("-");
							sb.append(new Date().getYear()+1900);
							sb.append(" ");
							sb.append(new Date().getMinutes());
							sb.append(":");
							sb.append(new Date().getSeconds());
							sb.append("\r\n");
							ByteBuffer buffer = ByteBuffer.allocate(sb.toString().length() * 2 + 2);


							buffer = java.nio.ByteBuffer.wrap(sb.toString().getBytes());
							key2.attach(buffer);

						}else if(key.isWritable()){
							SocketChannel client = (SocketChannel) key.channel();
							ByteBuffer buffer = (ByteBuffer) key.attachment();

							while(true){
								long now = System.currentTimeMillis();

								if(!buffer.hasRemaining()){
									buffer.rewind();
									buffer.clear();
									StringBuffer sb = new StringBuffer();
									sb.append(new Date().getDate());
									sb.append("-");
									sb.append(new Date().getMonth() + 1);
									sb.append("-");
									sb.append(new Date().getYear() + 1900);
									sb.append(" ");
									sb.append(new Date().getMinutes());
									sb.append(":");
									sb.append(new Date().getSeconds());
									sb.append("\r\n");

									buffer = ByteBuffer.allocate(sb.toString().length() * 2 + 2);


									buffer = java.nio.ByteBuffer.wrap(sb.toString().getBytes());
									while(System.currentTimeMillis() - now < 1000){

									}
									client.write(buffer);


								}
								else{
									client.write(buffer);

								}


							}
						}
					}catch(IOException e){
						key.cancel();
						try{
							key.channel().close();
						}catch(IOException e1){
							e1.printStackTrace();
						}

					}
				}
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}

package rm_sept1_Lazar_Nisic_ml13090;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class Handler implements HyperlinkListener {

	private JEditorPane jp;
	private JTextArea ar1;
	private JTextArea ar2;




	public Handler(JEditorPane jp, JTextArea ar1, JTextArea ar2) {
		super();
		this.jp = jp;
		this.ar1 = ar1;
		this.ar2 = ar2;
	}

	public void hyperlinkUpdate(HyperlinkEvent evt){
		HyperlinkEvent.EventType tip = evt.getEventType();
		URL u = evt.getURL();
		if(tip == HyperlinkEvent.EventType.ACTIVATED){
			this.prikazi();
		}


	}

	public void prikazi(){
		String s = this.ar1.getText();
		URL u;
		try {
			u = new URL(s);
			this.jp.setPage(u);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(IOException ex){
			ex.printStackTrace();
		}

	}



	public void ucitaj(){

		String s = this.ar1.getText();
		try {
			URL u = new URL(s);
			BufferedReader in = new BufferedReader(new InputStreamReader(u.openStream()));
			String p;
			StringBuffer sb = new StringBuffer();
			while((p=in.readLine()) != null)
				sb.append(p);
			this.ar2.setText(sb.toString());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}



	public void sacuvaj(){
		String s = this.ar1.getText();
		try {
			URL u = new URL(s);
			String st = this.jp.getText();
			String fajl = u.getFile();
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fajl)));
			out.write(st);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}




}

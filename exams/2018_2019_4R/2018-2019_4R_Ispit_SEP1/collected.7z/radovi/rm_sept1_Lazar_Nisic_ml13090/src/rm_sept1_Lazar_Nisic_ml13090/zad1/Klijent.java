package rm_sept1_Lazar_Nisic_ml13090;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

public class Klijent {

	public static void main(String[] args){

		BufferedReader in = null;
		BufferedWriter out = null;

		try{
			
			Socket socket = new Socket("localhost", Server.PORT);

			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

			String s;

			for(int i=0;i<5;i++){
				s=in.readLine();
				System.out.println("Trenutno vreme je:" + s);
				out.write("Primio!");
				out.flush();
			}
			String p = "end";
			out.write(p);
			out.flush();
			socket.close();
		}

		catch(IOException e){
			e.printStackTrace();
		}

		finally{
			try{
				if(in!=null)
					in.close();
				if(out!=null)
					out.close();
			}
			catch(IOException e){
				e.printStackTrace();
			}

		}

	}
}

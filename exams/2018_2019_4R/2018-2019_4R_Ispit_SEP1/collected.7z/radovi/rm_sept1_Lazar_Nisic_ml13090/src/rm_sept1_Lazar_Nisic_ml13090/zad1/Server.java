package rm_sept1_Lazar_Nisic_ml13090;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {

	public static final int PORT = 23456;

	public static void main(String[] args){

		BufferedReader in = null;
		BufferedWriter out = null;

		try{
			ServerSocket server = new ServerSocket(PORT);

			while(true){
				try{
					Socket connection = server.accept();

					in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					out = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));

					Date d = new Date();
					out.write(d.toString() + "\n");
					out.flush();

					String str = in.readLine();
					if(str.trim().equalsIgnoreCase("end"))
						break;

					try{
						Thread.sleep(1000);
					}
					catch(Exception e){
						e.printStackTrace();
					}
					connection.close();
				}
				catch(IOException e){
					e.printStackTrace();
				}


			}
		}

		catch(IOException e){
			e.printStackTrace();
		}

		finally{
			try{
				if(in!=null)
					in.close();
				if(out!=null)
					out.close();

			}
			catch(IOException e){
				e.printStackTrace();
			}

		}

	}

}

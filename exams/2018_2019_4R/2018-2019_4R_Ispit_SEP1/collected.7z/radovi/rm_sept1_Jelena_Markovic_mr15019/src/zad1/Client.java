package zad1;

import java.nio.*;
import java.io.*;
import java.net.*;
//import java.net.MulticastSocket;
import java.time.*;
import java.util.Date;
import java.util.Date.*;
@SuppressWarnings({ "static-access", "deprecation" })
public class Client{

	private static final int PORT = 23456;
    private static int br_primljenih = 0;

    public static void main(String[] args){
	try {
	     MulticastSocket socket = new MulticastSocket();
         InetSocketAddress group = new InetSocketAddress("localhost",PORT);
         socket.joinGroup(group.getAddress());

         byte[] buf = new byte[256];
         DatagramPacket packet = new DatagramPacket(buf,buf.length);
         socket.receive(packet);
         br_primljenih++;
         String received = new String(packet.getData(),0, packet.getLength());

         Date d = new Date();
      //   d.parse(received);
         System.out.println(d.parse(received));


        // System.out.println()
         if (br_primljenih == 5){
        	 socket.leaveGroup(group.getAddress());
        	 socket.close();
         }
	} catch (IOException e){
		e.printStackTrace();
	}

    }
}

package zad1;

import java.nio.*;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
//import java.sql.Time;
import java.time.*;
import java.time.temporal.*;
import java.io.*;
import java.net.*;

import java.util.*;
public class Server implements Runnable{

	private static final int PORT = 23456;
 //  private static DatagramSocket sock;

	public static void main(String[] args) {
		new Server().run();

	}


	public Server(){
		/*try{
		  sock = new DatagramSocket(PORT);

		} catch (SocketException e){
			e.printStackTrace();
		}*/
	}

	public void run(){
		System.out.println("Server is running...");
		LocalTime t=LocalTime.now();

		System.out.println(t.toString());
		LocalDate d = LocalDate.now();
		System.out.println(d.toString());
		//byte[] buf = new byte[256];
		try(ServerSocketChannel serverChannel = ServerSocketChannel.open(); Selector selector = Selector.open()){

			/*InetAddress group = InetAddress.getLocalHost();*/
		//	Date d;

			serverChannel.bind(new InetSocketAddress(PORT));
			serverChannel.configureBlocking(false);
			serverChannel.register(selector, SelectionKey.OP_ACCEPT);

			while(true){
				selector.select();

				Set<SelectionKey> readyKeys = selector.selectedKeys();
				Iterator<SelectionKey> iterator = readyKeys.iterator();

				while (iterator.hasNext()){
					SelectionKey key = iterator.next();
					iterator.remove();

					if (key.isAcceptable()){
						ServerSocketChannel server = (ServerSocketChannel) key.channel();
						SocketChannel client = server.accept();
						ByteBuffer buf = ByteBuffer.allocate(256);

				        buf.putInt(d.getDayOfMonth());
				        buf.putInt(d.getMonthValue());
				        buf.putInt(d.getYear());
				        buf.putInt(t.getMinute());
				        buf.putInt(t.getSecond());

					/*	buf=t.toString().getBytes();
						buft.toString().getBytes();
						//buf(t.toString().getBytes());
						//buf.putLong(d.)*/
						SelectionKey key2 = client.register(selector, SelectionKey.OP_READ);
						key2.attach(buf);
					} else if (key.isReadable()){
						SocketChannel client = (SocketChannel) key.channel();
						ByteBuffer buf2 = ByteBuffer.allocate(256);
					}
				}
			}


		} catch(IOException ex){

		}
	}
}

package zad2;

import javax.swing.text.*;
import javax.swing.text.html.*;
import java.net.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

	public static void main(String[] args) {

		JFrame f = new JFrame();
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600,400);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable(){
			public void run(){
				f.setVisible(true);
			}
		});

	}

	private static void addComponents(Container pane){

		GridBagLayout g = new GridBagLayout();
		pane.setLayout(g);
		GridBagConstraints c = new GridBagConstraints();

		JTextField tf = new JTextField();
		c.fill =GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(tf,c);

		JEditorPane jep = new JEditorPane();
		jep.setEditable(true);
		JScrollPane scrollPane = new JScrollPane(jep);
		EditorKit htmlKit = jep.getEditorKitForContentType("text/plain");
		PlainDocument doc = (PlainDocument) htmlKit.createDefaultDocument();
		jep.setEditorKit(htmlKit);

		JButton ucitaj = new JButton("ucitaj");
	    ucitaj.addActionListener(new ActionListener(){
	    	public void actionPerformed(ActionEvent e){
	    		try{
	    		  URL u = new URL(tf.getText());
	    		  InputStream in = u.openStream();
	    		  jep.read(in, doc);
	    		} catch (MalformedURLException ex){
	    			ex.printStackTrace();
	    		} catch (IOException ex2){
	    			ex2.printStackTrace();
	    		}
	    	}
	    });
		c.fill =GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(ucitaj,c);

		JButton prikazi = new JButton("prikazi");
		prikazi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
                   StringBuffer sb = new StringBuffer().append(jep.getText());
                   jep.setEditable(false);

                  EditorKit htmlKit2 = jep.getEditorKitForContentType("text/html");
           		   HTMLDocument doc2 = (HTMLDocument) htmlKit2.createDefaultDocument();
           		   jep.setEditorKit(htmlKit2);
           		   StringReader sr = new StringReader(sb.toString());
           		   try{
           		   jep.read(sr,doc2);
                   //jep.setText(sb.toString());
           		   }catch (Exception ex){
           			   ex.printStackTrace();
           		   }
			}
		});
		c.fill =GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(prikazi,c);

		JButton sacuvaj = new JButton("sacuvaj");
		sacuvaj.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try{
		    		  URL u = new URL(tf.getText());
		    		  //jep.setText(u.getFile());

		    		  System.out.println( u.getFile().substring(0,u.getFile().lastIndexOf('/')));
		    		  File fajl = new File(u.getFile().substring(0, u.getFile().lastIndexOf('/')),"2.html");
		    		  OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(fajl));
		    		  out.write(jep.getText());
		    		  out.close();
				}catch (Exception ex){
					ex.printStackTrace();
				}
			}
		});
		c.fill =GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=2;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(sacuvaj,c);



		c.fill =GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=3;
		c.gridwidth = 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 3.0;
		c.weighty = 4.0;
		pane.add(scrollPane,c);


	}

}

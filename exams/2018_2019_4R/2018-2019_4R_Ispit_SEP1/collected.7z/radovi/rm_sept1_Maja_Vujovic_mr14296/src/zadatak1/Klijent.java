package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Klijent {

	public static void main(String[] args) {
		try {
			Socket s=new Socket("localhost", 23456);
			BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			BufferedWriter out=new BufferedWriter(new OutputStreamWriter(System.out));
			String str=null;
			int brojac=0;

			while((str=in.readLine()) != null){
				out.write(str);
				out.write('\n');
				out.flush();
				brojac++;

				if(brojac==5){
					s.close();
				}
			}//end while

			in.close();
			out.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}


	}

}

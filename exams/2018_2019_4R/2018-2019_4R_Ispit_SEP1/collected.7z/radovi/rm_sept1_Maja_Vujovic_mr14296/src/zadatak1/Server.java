package zadatak1;

public class Server {


	public static void main(String[] args) {


	}//end main

}//end class

package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;

import javafx.scene.control.Hyperlink;

public class Zadatak2 {

	public static void main(String[] args) {
		JFrame frame= new JFrame("test");
		frame.setSize(600, 500);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);

			}//end run
		});//end runnable




	}//end main

	private static void addComponents(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		jep.setEditable(true);
		jep.setVisible(false);
		JScrollPane sp=new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=2;
		c.gridheight=0;
		c.gridwidth=0;
		c.weightx=1;
		c.weighty=0;
		pane.add(sp, c);

		JTextArea unos=new JTextArea();
		unos.setEditable(true);
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridheight=1;
		c.gridwidth=GridBagConstraints.REMAINDER;
		c.weightx=0;
		c.weighty=0;
		pane.add(unos, c);


		JButton ucitaj=new JButton("Ucitaj");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=2;
		c.weighty=0;
		pane.add(ucitaj, c);


		JButton prikazi=new JButton("Prikazi");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=1;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=2;
		c.weighty=0;
		pane.add(prikazi, c);

		JButton sacuvaj=new JButton("Sacuvaj");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=1;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=2;
		c.weighty=0;
		pane.add(sacuvaj, c);

		JTextArea ta=new JTextArea();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=2;
		c.gridheight=1;
		c.gridwidth=1;
		c.weightx=2;
		c.weighty=1;
		pane.add(ta, c);}

		//ostaje dodati odgovarajuce akcije za pritisnute dugmice


//
//			public void ucitaj(){
//				URL url;
//				try {
//					url = new URL(unos.getText());
//					BufferedReader r=new BufferedReader(new InputStreamReader(url.openStream()));
//					String s=null;
//
//					while((s=r.readLine()) != null){
//						ta.append(s);
//					}//end while
//
//					r.close();
//
//
//				} catch (MalformedURLException e1) {
//					e1.printStackTrace();
//				} catch (IOException e1) {
//					e1.printStackTrace();
//				}
//			}//end ucitaj
//
//			public void sacuvaj(){
//				String putanja=new String(unos.getText().substring(8, unos.getText().length()));
//				BufferedWriter w;
//
//				try {
//					w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(putanja)));
//					String s=ta.getText();
//
//					w.write(s);
//					w.close();
//				} catch (FileNotFoundException e) {
//					e.printStackTrace();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//
//
//			}//end sacuvaj
//



	}//end add components
//end class

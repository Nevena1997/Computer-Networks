package zad1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;



public class Server {

	public static final int PORT = 12345;

	public static void main(String[] args) {

		byte[] buf = new byte[4];

		// obezbedjeno je zatvaranje resursa
		try (DatagramSocket socket = new DatagramSocket(PORT)){

	//		System.out.println("server");
			// konstruktor za primanje paketa
			DatagramPacket packet = new DatagramPacket(buf, buf.length);
			socket.receive(packet);

			if(packet.getData().length != 4){
				System.err.println("Paket koji je stigao nije 4B");
			}

			System.out.println("Stigao datagram!");

		//	System.out.println("server");
			// stampanje sadrzaja paketa na standardni izlaz
			String s = new String(packet.getData(),0,packet.getLength());
		//	System.out.println(s);

			// potrebno je konvertovati String u Integer

			int n=0;
			int pr = 1;
			for(int i=s.length()-1;i>=0;i--){
				int a = (int) (s.charAt(i) - '0');
				n += a*pr;
				pr *= 10;
			}
			// System.out.println("n: " + n);

			// c)


			byte[] fibonaci = new byte[8];
			long f1=0, f2 = 1, f3;
			Long rez;
			// saljem pakete klijentu
			while(n > 0){

				f3 = f1 + f2;
				rez = f3;

				// priprema za sledecu iteraciju
				f1 = f2;
				f2 = f3;

				// jos je potrebno prebaciti rez u byte
				fibonaci = rez.toString().getBytes();


				// slanje paketa
				packet = new DatagramPacket(fibonaci, fibonaci.length, packet.getAddress(), packet.getPort());
				socket.send(packet);

				// n je broj iteracija
				n--;
			}



		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

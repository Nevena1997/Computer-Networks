package zad1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;


public class Client {


	public static void main(String[] args) {

			// obezbedjeno je ispravno zatvaranje resursa
			try (DatagramSocket socket = new DatagramSocket(); Scanner sc = new Scanner(System.in)){

				InetAddress adresa = InetAddress.getByName("localhost");

				byte[] buf = new byte[4];


				System.out.println("Unesi pozitivan broj n ne veci od 80: ");
				Integer n = sc.nextInt();
				if (n < 0){
					System.err.println("n nije pozitivan");

				}
				if(n>80)
					System.err.println("Unet je broj veci od 80");


				String sn = n.toString();
				buf = sn.getBytes();

				// ovo je konstruktor za slanje paketa
				DatagramPacket packet = new DatagramPacket(buf, buf.length, adresa, Server.PORT);
				socket.send(packet);

				System.out.println("poslat paket");


				// c)

				byte[] fibonaci = new byte[8];

				// klijent od servera prima fibonacijeve brojeve. svaki u posebnom paketu
				while(true){

					packet = new DatagramPacket(fibonaci, fibonaci.length);
					socket.receive(packet);

					// potrebno je ispisati broj na standarni izlaz
					String p = new String(packet.getData(),0,packet.getLength());
					// nema potrebe da se konveruje u Integer jer se ne vrse nikakve operacije nad njima sa klijentske strane.
					// potrebno je samo da se ispisu
					System.out.println(p);

				}


			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

}

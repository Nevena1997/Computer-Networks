package zad_01;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UDPServer extends Thread{

	public static final int PORT = 12345;
	private DatagramSocket socket;
	// niz gde cemo cuvati izracunate fib. brojeve
	private static int[] fibArr = new int[80];

	public UDPServer() throws SocketException {
		this.socket = new DatagramSocket(PORT);
		fibArr[1] = 1;
	}

	public static void main(String[] args) throws SocketException{

		new UDPServer().start();

	}

	@Override
	public synchronized void start() {

		// Objedinicu prvi i drugi primer

		DatagramPacket dp;

		while (true) {

			byte[] buf = new byte[4];
			byte[] fibBuf = new byte[8];

			// Nisam siguran kako bih elegantnije pretvarao byte[] u int, pa prebacujem u string pa u int :)

			try{
				dp = new DatagramPacket(buf, buf.length);
				socket.receive(dp);
				System.err.println("Stigao datagram!");
				int n = Integer.parseInt(new String(dp.getData()).trim());
				int fibNum = calculateFibs(n - 1, fibArr);

				for(int i = 0; i < n; i++){
					fibBuf = Integer.toString(fibArr[i]).getBytes();
					dp = new DatagramPacket(fibBuf, fibBuf.length, dp.getAddress(), dp.getPort());
					socket.send(dp);
				}


			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	public int calculateFibs(int n, int[] arr){

		if(n == 0){
			return arr[0];
		}

		if(arr[n] != 0){
			return arr[n];
		}

		arr[n] = calculateFibs(n - 1, arr) + calculateFibs(n - 2, arr);
		return arr[n];
	}

}

package zad_01;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;


public class UDPClient {

	public static void main(String[] args) throws SocketException {

		// Objedinicu prvi primer gde se samo salje int sa sledecim

		DatagramSocket socket = new DatagramSocket();

		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();

		if(num > 80 || num < 1){
			System.out.println("Broj mora biti izmedju 1 i 80");
			System.exit(1);
		}

		byte[] buf = Integer.toString(num).getBytes();
		byte[] fibBuf = new byte[8];

		try {
			DatagramPacket dp = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(), UDPServer.PORT);
			socket.send(dp);

			// for each fib. num. that we 'requested' receive one package and print it
			for(int i = 0; i < num; i++){
				dp = new DatagramPacket(fibBuf, fibBuf.length);
				socket.receive(dp);
				if(i != num - 1)
					System.out.print(new String(dp.getData()).trim() + ", ");
				else
					System.out.print(new String(dp.getData()));
			}

			sc.close();
			socket.close();

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

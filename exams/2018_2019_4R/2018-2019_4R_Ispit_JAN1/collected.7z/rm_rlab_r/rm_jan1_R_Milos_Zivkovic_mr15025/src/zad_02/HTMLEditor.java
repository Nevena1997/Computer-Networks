package zad_02;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {

	public static void main(String[] args) {

		JFrame frame = new JFrame("Simple HTML Editor");
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addFrameContent(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				frame.setVisible(true);

			}
		});

	}

	private static void addFrameContent(Container container) {

		container.setLayout(new GridBagLayout());;
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		jep.setContentType("text/plain");
		JScrollPane scrollPane = new JScrollPane(jep);
		c.gridx = 0;
		c.gridy = 0;
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 3;
		c.weightx = 1;
		c.weighty = 0.99;
		c.ipadx = 0;
		c.ipady = 0;

		container.add(scrollPane, c);

		JTextArea ta = new JTextArea();
		ta.setLineWrap(true);
		c.gridx = 0;
		c.gridy = 1;
		// TODO : check this
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.weightx = 0.6;
		c.weighty = 0.01;
		c.ipadx = 0;
		c.ipady = 0;

		container.add(ta, c);

		JButton prikazi = new JButton("Prikazi");
		prikazi.addActionListener(new ActionListener() {

			// program tolerise samo apsolutnu putanju, to bi moglo da se popravi eventualno
			// file:///C:/Users/nalog/Desktop/rm_jan1_R_Milos_Zivkovic_mr15025/1.html

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					// Ovo je no - no, posto po slici treba raw text da ispisujemo koliko vidim
//					URL fileURL = new URL(ta.getText().trim());
//					jep.setPage(fileURL.toString());

					// tako da cu izbildovati String i postaviti jep.setText na taj string
					String path = ta.getText().substring(10); // ??
					InputStreamReader in = new InputStreamReader(new FileInputStream(path));
					StringBuilder sb = new StringBuilder();

					int c;
					while((c = in.read()) != -1){
						sb.append((char) c);
					}

					jep.setText(sb.toString());

					in.close();

//				} catch (MalformedURLException e1) {
//					jep.setText("Malformed URL");
//					e1.printStackTrace();
////					System.exit(1);
				} catch (IOException e1) {
					jep.setText("IOException, sorry lad (:");
					e1.printStackTrace();
//					System.exit(1);
				}

			}
		});

		c.gridx = 1;
		c.gridy = 1;
		// TODO : check this
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.weightx = 0.2;
		c.weighty = 0.01;
		c.ipadx = 0;
		c.ipady = 0;

		container.add(prikazi, c);

		JButton ocisti = new JButton("Ocisti");
		ocisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO : Zakomentarisano, nije bas najpametnije, ne radi kako treba

//				// da bi parsovali HTML i uklonili tagove,
//				// ParserGetter da se metod postavi na public
//				// ParserCallbackImpl da bi vrsili parsovanje
//				// (treba mi da implementiramo, posto onaj inicijalni ne radi nista :)) )
//
//				// od parsergettera uzmemo HTMLKit.Parser i koristimo
//				// njegov parse metod, a jedan od argumenata je parsercallbackimpl
//
//				// unutar ParserCallbackImpl overridujemo metode za parsovanje odredjenih
//				// delova HTML dokumenta, zavisno od nasih zahteva
//
//				String path = ta.getText().substring(10); // ??
//				try(InputStreamReader in = new InputStreamReader(new FileInputStream(path));) {
//					HTMLEditorKit.Parser p = new ParserGetter().getParser();
//					ParserCallbackImpl pci = new ParserCallbackImpl();
//					p.parse(in, pci, true);
//
//					// sad mislim da mogu unutar parsercallbackimpl
//					// da cuvam listu stringova recimo u kojoj cu cuvati text linije
//					// i da na kraju njih naguram u JEditorPane
//
//					// verovatno moze bolje koristeci neki Document ili tako nesto
//
//					StringBuilder sb = new StringBuilder();
//					for(String s : pci.lines){
//						sb.append(s);
//					}
//
//					jep.setText(sb.toString());
//
//				} catch (FileNotFoundException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				} catch (IOException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//

			}
		});

		c.gridx = 2;
		c.gridy = 1;
		// TODO : check this
		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.weightx = 0.2;
		c.weighty = 0.01;
		c.ipadx = 0;
		c.ipady = 0;

		container.add(ocisti, c);
	}

}

package zad_02;

import java.util.List;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;

public class ParserCallbackImpl extends ParserCallback {

	public static List<String> lines;

	// a onda overridovanje metoda koje zelimo da koristimo
	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
//		// TODO Auto-generated method stub
//		super.handleStartTag(t, a, pos);
	}

	@Override
	public void handleEndTag(Tag t, int pos) {
//		// TODO Auto-generated method stub
//		super.handleEndTag(t, pos);
	}

	@Override
	public void handleSimpleTag(Tag t, MutableAttributeSet a, int pos) {
//		// TODO Auto-generated method stub
//		super.handleSimpleTag(t, a, pos);
	}

	@Override
	public void handleComment(char[] data, int pos) {
//		// TODO Auto-generated method stub
//		super.handleComment(data, pos);
	}

	@Override
	public void handleError(String errorMsg, int pos) {
//		// TODO Auto-generated method stub
//		super.handleError(errorMsg, pos);
	}

	@Override
	public void handleText(char[] data, int pos) {
//		// TODO Auto-generated method stub
//		super.handleText(data, pos);

		lines.add(new String(data));
	}



}

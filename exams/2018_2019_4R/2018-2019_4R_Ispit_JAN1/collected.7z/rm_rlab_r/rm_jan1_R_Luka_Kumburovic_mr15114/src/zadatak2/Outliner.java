package zadatak2;

import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML.Tag;

public class Outliner extends HTMLEditorKit.ParserCallback{

	JEditorPane pane;
	boolean isInsideTag;
	String displayText;

	public Outliner(JEditorPane pane){
		this.pane = pane;
		isInsideTag = false;
		displayText = "";
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {

	}// END OF handleStartTag

	@Override
	public void handleEndTag(Tag t, int pos) {
		displayText += "<br>";
	}// END OF handleEndTag

	@Override
	public void handleText(char[] data, int pos) {

		StringBuilder sb = new StringBuilder();

		for ( int i = 0; i < data.length; i++ ){
			if (data[i] == '\n')
				sb.append("<br>");

			sb.append(data[i]);
		}

		displayText += sb.toString();
		pane.setText(displayText);
	}// END OF handleText
	//FILE:///Users/nalog/Desktop/rm_jan1_R_Luka_Kumburovic_mr15114/1.html

}// END OF class

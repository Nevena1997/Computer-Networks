package zadatak2;

import javax.swing.text.html.HTMLEditorKit;

@SuppressWarnings("serial")
public class ParserGetter extends HTMLEditorKit {

	@Override
	public Parser getParser() {
		return super.getParser();
	}
}

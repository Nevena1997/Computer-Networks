package zadatak2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {

	public static void main(String[] args) {

		JFrame frame = new JFrame("Ukloni HTML tagove v1.0");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(800, 600);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable(){
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				frame.show();
			}
		});

	}// END OF main

	private static void addComponents(Container pane) {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		c = setConstraints ( GridBagConstraints.BOTH, 0, 0, 4, 0, 0, 1.0, 1.0 );
		JScrollPane scrollPane = new JScrollPane(jep);
		pane.add(scrollPane, c);

		JTextArea addressBar = new JTextArea();
		c = setConstraints ( GridBagConstraints.HORIZONTAL, 0, 1, 1, 0, 0, 1.0, 0.0 );
		pane.add(addressBar, c);

		JButton prikazi = new JButton("Prikazi");
		c = setConstraints ( GridBagConstraints.HORIZONTAL, 1, 1, 1, 0, 0, 0.0, 0.0 );

		prikazi.addActionListener(e -> {
			if ( !addressBar.getText().isEmpty() ){
				try {
					URL url = new URL(addressBar.getText());
					jep.setPage(url);

				} catch (MalformedURLException e1) {
					e1.printStackTrace();
					jep.setText("Invalid URL!");
				} catch (IOException e1) {
					e1.printStackTrace();
					jep.setText("Invalid URL!");
				}
			}
		});

		pane.add(prikazi, c);

		JButton ocisti = new JButton("Ocisti");
		c = setConstraints ( GridBagConstraints.HORIZONTAL, 2, 1, 1, 0, 0, 0.0, 0.0 );

		ocisti.addActionListener(e -> {

			if ( !addressBar.getText().isEmpty() ){
				ParserGetter pg = new ParserGetter();
				Outliner outliner = new Outliner(jep);
				HTMLEditorKit.Parser p = pg.getParser();

				URL url;
				try {
					url = new URL(addressBar.getText());
					InputStreamReader in = new InputStreamReader(url.openStream(), "UTF-8");

					p.parse(in, outliner, true);
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				} catch (UnsupportedEncodingException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		});

		pane.add(ocisti, c);

	}// END OF addComponents

	private static GridBagConstraints setConstraints( int fill, int gridx, int gridy, int gridwidth, int ipadx, int ipady, double weightx, double weighty ){

		GridBagConstraints c = new GridBagConstraints();

		c.fill = fill;
		c.gridx = gridx;
		c.gridy = gridy;
		c.gridwidth = gridwidth;
		c.ipadx = ipadx;
		c.ipady = ipady;
		c.weightx = weightx;
		c.weighty = weighty;

		return c;
	}

}// END OF class








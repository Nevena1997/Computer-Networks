package zadatak1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Server {

	public static final int PORT = 12345;

	public static void main(String[] args) {

		byte[] buffer = new byte[4];
		long[] fibArray = fibonnaci();

		try ( DatagramSocket socket = new DatagramSocket(PORT) ) {

			while ( true ){

				DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
				socket.receive(packet);

				System.err.println("Stigao datagram!");

				int count = Integer.parseInt(new String(packet.getData(), 0, packet.getLength()));

				byte[] outBuffer = new byte[8];
				for ( int i = 0; i < count; i++ ){

					//outBuffer = (byte[])fibArray[i];
					packet = new DatagramPacket(outBuffer, 8, InetAddress.getByName("localhost"), Server.PORT);
					socket.send(packet);
				}

			}

		} catch ( IOException ex ){
			ex.printStackTrace();
		}

	}// END OF main

	private static long[] fibonnaci(){

		long[] temp = new long[80];
		temp[0] = 1;
		temp[1] = 1;

		for ( int i = 2; i < 80; i++ )
			temp[i] = temp[i-1] + temp[i-2];

		return temp;

	}// END OF fibonnaci

}// END OF class

package zadatak1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	private static Scanner userIn = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.print("Unesite broj: ");
		int numberForSending = userIn.nextByte();

		while (numberForSending < 0 || numberForSending > 80) {

			System.out.print("Broj mora biti izmedju 0 i 80! ");
			System.out.print("Unesite broj: ");
			numberForSending = userIn.nextInt();
		}

		byte[] outBuffer = new byte[4];
		try (DatagramSocket socket = new DatagramSocket()) {

			//outBuffer = (byte[]) numberForSending;
			DatagramPacket packet = new DatagramPacket(outBuffer, 4, InetAddress.getByName("localhost"), Server.PORT);
			socket.send(packet);

			byte[] receivedNumber = new byte[8];
			for (int i = 0; i < numberForSending; i++) {

				packet = new DatagramPacket(receivedNumber, receivedNumber.length);
				socket.receive(packet);

				String number = new String(packet.getData(), 0, packet.getLength());
				System.out.println(number);
			}

		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}// END OF main

}// END OF class

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class HTML {

	public static void main(String[] args) {
		JFrame f=new JFrame("Ukloni HTML tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);

		f.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep= new JEditorPane();
		jep.setEditable(true);


		//...
	}

	static String ocisti(String s){//pretpostavljam da je validan HTML
		StringBuilder rez=new StringBuilder();
		for(int i=0;i<s.length();++i)
			if(s.charAt(i)=='<'){
				int otvorenih = 1;
				for(++i;otvorenih!=0;++i){
					if(s.charAt(i)=='<') ++otvorenih;
					else if(s.charAt(i)=='>'){
						--otvorenih;
						--i;
					}
				}
			}else
				rez.append(s.charAt(i));
		return rez.toString();
	}
}
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class Klijent{

	public static void main(String[] args) {
		try (DatagramSocket sok = new DatagramSocket()){
			int n=0;
			try (Scanner sc = new Scanner(System.in)){
				n = sc.nextInt();
			} catch (Exception e) {
				e.printStackTrace();
			}
			byte[] baf=ByteBuffer.allocate(4).putInt(n).array();
			DatagramPacket pak = new DatagramPacket(baf,4,InetAddress.getLocalHost(),12345);
			sok.send(pak);
			for(int i=0;i!=n;++i){
				byte[] baf1 = new byte[8];
				DatagramPacket pak1 = new DatagramPacket(baf1,8);
				sok.receive(pak1);
				System.out.println(ByteBuffer.wrap(baf1).getLong());
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
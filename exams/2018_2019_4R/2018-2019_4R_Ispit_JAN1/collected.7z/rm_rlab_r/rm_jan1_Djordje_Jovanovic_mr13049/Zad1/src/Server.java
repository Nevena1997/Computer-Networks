import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.Vector;

public class Server {

	public static void main(String[] args) {
		Vector<Long> v=new Vector<Long>();
		v.add((long)0);
		v.add((long)1);
		try (DatagramSocket sok= new DatagramSocket(12345)){
			while(true){
				byte[] baf = new byte[4];
				DatagramPacket pak = new DatagramPacket(baf,4);
				sok.receive(pak);
				System.out.println("Stigao datagram!");
				for(int i=0;i!=ByteBuffer.wrap(baf).getInt();++i){
					long x;
					if(i!=v.size())
						x=v.get(i);
					else{
						x=v.lastElement().longValue()+v.get(v.size()-2).longValue();
						v.add(Long.valueOf(x));
					}
					byte[] baf1 = ByteBuffer.allocate(8).putLong(x).array();
					DatagramPacket pak1 = new DatagramPacket(baf1,8,pak.getAddress(),pak.getPort());
					sok.send(pak1);
				}
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
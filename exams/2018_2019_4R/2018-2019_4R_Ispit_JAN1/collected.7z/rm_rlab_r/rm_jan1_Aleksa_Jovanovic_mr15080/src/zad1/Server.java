package zad1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;

public class Server {


	static long[] fib=new long[80];
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		generisiFib();
		try(DatagramSocket socket=new DatagramSocket(12345)){
			while(true){

				byte []buff=new byte[4];
				DatagramPacket packet=new DatagramPacket(buff, 4);
				try {
					socket.receive(packet);
					System.out.println("Stigao datagram!");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				int n=ByteBuffer.wrap(buff).getInt();
				if(n>79) continue;
				SocketAddress address=packet.getSocketAddress();
				for(int i=0;i<n;i++){

					byte []broj=ByteBuffer.allocate(8).putLong(fib[i]).array();
					packet=new DatagramPacket(broj, 8, address);
					try {
						socket.send(packet);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}


			}



		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	private static void generisiFib() {
		// TODO Auto-generated method stub
		fib[0]=0;
		fib[1]=1;
		for(int i=2;i<80;i++)
			fib[i]=fib[i-1]+fib[i-2];
	}

}

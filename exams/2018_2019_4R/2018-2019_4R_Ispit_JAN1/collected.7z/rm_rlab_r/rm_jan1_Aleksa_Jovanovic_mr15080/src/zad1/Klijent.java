package zad1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class Klijent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(DatagramSocket socket=new DatagramSocket()){

			int n=0;

			//ucitavamo broj sa ulaza
			try(Scanner sc=new Scanner(System.in)){

				n=sc.nextInt();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			//smestamo u niz bajtova
			byte[] buff=ByteBuffer.allocate(4).putInt(n).array();

			//Saljemo paket
			try {
				DatagramPacket packet=new DatagramPacket(buff, buff.length, InetAddress.getByName("localhost"),12345);
				socket.send(packet);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			//Primamo fibonacijeve brojeve
			for(int i=0;i<n;i++){
				if(n>79) break;
				byte [] buf=new byte[8];

				DatagramPacket packet=new DatagramPacket(buf, 8);
				try {
					socket.receive(packet);
					long fib=ByteBuffer.wrap(buf).getLong();
					System.out.println(fib);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}





		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

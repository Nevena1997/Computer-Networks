package zad2;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//JFrame
		JFrame f=new JFrame("Ukloni HTML tagove v1.0");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(800, 600);


		//Namestanje layout
		f.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		//JEditorPane
		JEditorPane jep=new JEditorPane();
		jep.setEditable(false);

		//JScrollPane
		JScrollPane scrollPane=new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=4;
		c.weightx=1.0;
		c.weighty=1.0;
		f.getContentPane().add(scrollPane, c);

		//TextArea za unos url-a

		JTextArea url=new JTextArea("URL");

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=3;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=2;
		c.weightx=1.0;
		c.weighty=0.0;

		f.getContentPane().add(url, c);


		//Button prikazi
		JButton btnPrikazi =new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					URL u=new URL(url.getText());
					try(InputStream in=u.openConnection().getInputStream()){

						StringBuilder sb=new StringBuilder();
						int c;
						while((c=in.read())!=-1){
							sb.append((char)c);
						}
						jep.setText(sb.toString());
					}catch (IOException e2) {
						// TODO: handle exception
						e2.printStackTrace();
					}


				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					System.out.println("Ne postoji URL");
					e1.printStackTrace();
				}

				System.out.println("Prikazi");
			}
		});

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=2;
		c.gridy=3;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		c.weightx=0.0;
		c.weighty=0.0;

		f.getContentPane().add(btnPrikazi, c);


		//Button ocisti
		JButton btnOcisti=new JButton("Ocisti");
		btnOcisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String s=jep.getText();
				String [] sa=s.split("[<][^>]*[>]");
				StringBuilder sb=new StringBuilder();
				for(String temp: sa)
					sb.append(temp);

				jep.setText(sb.toString());
				System.out.println("Ocisti");
			}
		});

		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=3;
		c.gridy=3;
		c.ipadx=0;
		c.ipady=0;
		c.gridwidth=1;
		c.weightx=0.0;
		c.weighty=0.0;

		f.getContentPane().add(btnOcisti, c);


		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});

	}

}

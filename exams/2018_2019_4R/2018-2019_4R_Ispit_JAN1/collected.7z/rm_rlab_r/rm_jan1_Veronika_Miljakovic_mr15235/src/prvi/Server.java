package prvi;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class Server extends Thread {


	private static   DatagramSocket sock;
	public int n;
	private List<Long> lista;


	public Server() throws SocketException   {
		//ovde konstruisemo niz od 80 fibonaci brojeva kako ne bi za svakog klijenta iznova racunali brojeve vec samo uzmemo prvih n

			this.sock = new DatagramSocket(12345);

			this.lista = new ArrayList<Long>();
			long fibonaci1 = 0;
			long fibonaci2 = 1;
			for(int i=0; i<80; i++)
			{
				lista.add(i, fibonaci1);
				long sledeci = fibonaci1 + fibonaci2;
				fibonaci1 = fibonaci2;
				fibonaci2 = sledeci;
			}
	}

	public static void main(String[] args)   {

			try {
				new Server().start();
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				sock.close();
			}

	}

	public void run() {

		byte[] buf = new byte[4];
		while(true) {
		DatagramPacket packet = null;
		try {

			//Server od klijenta prima broj n
			packet  = new DatagramPacket(buf, buf.length);
			this.sock.receive(packet);

			System.out.println("Stigao datagram!");

			n = ByteBuffer.wrap(buf).getInt();


		//	int fibonaci1 = 1;
		//	int fibonaci2 = 1;
			byte[] buferfibonaci = new byte[8];
			for(int i=0; i<n; i++)
			{
				buferfibonaci = ByteBuffer.allocate(8).putLong(this.lista.get(i)).array();
				packet = new DatagramPacket(buferfibonaci, buferfibonaci.length, packet.getAddress(), packet.getPort());
				this.sock.send(packet);
		/*		System.out.println("Poslao sam sledeci fibonaci"); */

		//		int sledeci = fibonaci1+fibonaci2;
		//		fibonaci1 = fibonaci2;
		//		fibonaci2 = sledeci;


			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {

		}

		}
	}

}

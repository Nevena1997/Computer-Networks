package prvi;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		byte[] buf = new byte[4];
		try {

			Scanner sc = new Scanner(System.in);
			int broj = sc.nextInt();
			if(broj<0 || broj>80)
			{
				System.err.println("Greska, nije validan broj");
				return;
			}
			buf = ByteBuffer.allocate(4).putInt(broj).array();

			DatagramPacket packet = new DatagramPacket(buf, buf.length, InetAddress.getByName("localhost"), 12345);
			DatagramSocket sock = new DatagramSocket();
			sock.send(packet);
			//System.out.println("Poslao sam paket");
		//	Poslali smo serveru broj n i sad ce on nama da posalje fibonacijeve brojeve
			byte[] buferprijem = new byte[8];

			for(int i=0; i< broj; i++)
			{

				packet = new DatagramPacket(buferprijem, buferprijem.length);
				sock.receive(packet);
				//ispisujemo jedan po jedan fibonaci
				System.out.println(ByteBuffer.allocate(8).wrap(buferprijem).getLong());
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {

		}



	}

}

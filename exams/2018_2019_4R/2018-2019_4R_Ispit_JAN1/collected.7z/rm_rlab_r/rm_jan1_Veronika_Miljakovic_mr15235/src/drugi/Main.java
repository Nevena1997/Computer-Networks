package drugi;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {

		JFrame f = new JFrame("Ukloni HTML tagove v1.0");
		f.setSize(600,600);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setResizable(true);

		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);

			}
		});

	}

	private static void addComponents(Container contentPane) {

		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.gridwidth = 3;
		contentPane.add(scroll,c);

		JTextArea tekst = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		contentPane.add(tekst,c);

		JButton dugmePrikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		contentPane.add(dugmePrikazi,c);

		dugmePrikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					URL url = new URL(tekst.getText());
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					String ispis = "";
					String s;
					while((s = in.readLine()) != null)
						ispis+=s + "\n";

					jep.setText(ispis);

				} catch (MalformedURLException e1) {

					jep.setText("OVAJ URL NIJE VALIDAN!");
				} catch (IOException e1) {
					jep.setText("OVAJ URL NIJE VALIDAN!");
				}

			}
		});

		JButton dugmeOcisti = new JButton("Ocisti");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.gridwidth = 1;
		contentPane.add(dugmeOcisti,c);

		dugmeOcisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				jep.setText(jep.getText().replaceAll("<[^>]*>", ""));

			}
		});

	}

}

package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowStateListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class Test {

	// FILE:///C:/Users/nalog/Desktop/prvi.html
	
	public static void main(String[] args) {

		JFrame jf=new JFrame("Ukloni HTML tagove");

		jf.setSize(500,500);
		jf.setResizable(true);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		addComponents(jf.getContentPane());

		EventQueue.invokeLater(new FrameShower(jf));

	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		JScrollPane sc=new JScrollPane(jep);
	    JTextArea ta=new JTextArea();

		Handler h=new Handler(jep,ta);

		JButton prikazi=new JButton("Prikazi");
		JButton ocisti=new JButton("Ocisti");

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				h.prikazi();

			}
		});


		ocisti.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				h.ocisti();

			}
		});


		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;
		c.weightx=1;
		c.weighty=1;
		c.gridwidth=3;
		pane.add(sc,c);

		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=1;
		c.weightx=1;
		c.weighty=0;
		c.gridwidth=1;
		pane.add(ta,c);

		c.fill=GridBagConstraints.BOTH;
		c.gridx=1;
		c.gridy=1;
		c.weightx=0;
		c.weighty=0;
		c.gridwidth=1;
		pane.add(prikazi,c);

		c.fill=GridBagConstraints.BOTH;
		c.gridx=2;
		c.gridy=1;
		c.weightx=0;
		c.weighty=0;
		c.gridwidth=1;
		pane.add(ocisti,c);


	}

	public static class FrameShower implements Runnable {
		private JFrame f;

		public FrameShower(JFrame f)
		{
			this.f=f;
		}

		@Override
		public void run() {
			this.f.setVisible(true);

		}
	}

}

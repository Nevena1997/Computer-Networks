package zad1;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
public class Server {

		public static int PORT = 12345;


	public static void main(String[] args) {

		DatagramSocket socket=null;

		while(true)

		{
			try {

		// prima paket od klijenta

			byte[] buf=new byte[4];
			socket=new DatagramSocket(PORT);

			DatagramPacket packet=new DatagramPacket(buf, buf.length);
			socket.receive(packet);

			if(packet!=null)
				{


					String primljen=new String(packet.getData(),0,packet.getLength());
					int n=Integer.parseInt(primljen);
					InetAddress adr=packet.getAddress();
					int port=packet.getPort();

					// ispisuje poruku i proverava uslove

					System.out.println("Stigao datagram!\r\n");


					if (n<80 && n>0)
							System.out.println("Saljem prvih "+n+" Fibonacijevih brojeva.\r\n");
					else
						{
							System.out.println("Broj mora biti manji od 80.\r\n");
							break;
						}

					// salje klijentu n paketa

					byte[] buf2=new byte[8];

					for (int j=0;j<n;j++)
					{

						String poruka=""+fibonaci(j);
						buf2=poruka.getBytes();
						packet=new DatagramPacket(buf2, buf2.length,adr, port);
						socket.send(packet);
					}



				}



			}

		catch(Exception e){
			e.printStackTrace();

		}
			// zatvaranje resursa

			finally
			{
				try {
					if(socket!=null)
						socket.close();

				}

				catch(Exception e)
				{
					e.printStackTrace();
				}
			}


	}


}

	// funkcija vraca n-ti Fibonacijev broj

	public static long fibonaci(int n)
	{  if(n==0 || n==1)
		return n;

		long l0=0;
		long l1=1;

		for (int i=2;i<=n;i++)
		{
			long tmp=l1;
			l1=l0+l1;
			l0=tmp;

		}

		return l1;

	}

}

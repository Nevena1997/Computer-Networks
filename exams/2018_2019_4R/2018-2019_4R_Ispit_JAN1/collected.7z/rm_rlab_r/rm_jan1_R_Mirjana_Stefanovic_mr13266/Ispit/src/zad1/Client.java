package zad1;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		DatagramSocket socket=null;
		InetAddress adr=null;
		Scanner sc=null;

		try {

			// klijent salje jedan broj serveru

			byte[] buf=new byte[4];

			sc=new Scanner(System.in);
			System.out.println("Unesi broj:\r\n");
			int broj=sc.nextInt();

			String poruka=""+broj;

			socket=new DatagramSocket();
			adr=InetAddress.getByName("localhost");
			buf=poruka.getBytes();
			DatagramPacket packet=new DatagramPacket(buf,buf.length, adr, Server.PORT);
			socket.send(packet);

			// prima n paketa, u svakom po jedan Fibonacijev broj

			byte[] buf2=new byte[8];

			for (int i=0;i<broj;i++)

			{
				packet=new DatagramPacket(buf2, buf2.length);
				socket.receive(packet);
				String primljen=new String(packet.getData(),0,packet.getLength());
				int n=Integer.parseInt(primljen);
				System.out.println("Stigao "+i+". Fibonacijev broj: "+n);
			}


		}

		catch(Exception e){
			e.printStackTrace();
		}

		// zatvaranje resursa

		finally
		{
			try {
				if(socket!=null)
					socket.close();
				if(sc!=null)
					sc.close();

			}

			catch(Exception e)
			{
				e.printStackTrace();
			}
		}


	}


}

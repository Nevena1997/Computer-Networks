package zad2;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.WindowStateListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
public class Handler {

	private JEditorPane jep;
	private JTextArea ta;

	public Handler (JEditorPane jep, JTextArea ta){
		this.jep=jep;
		this.ta=ta;
	}


	public void prikazi(){

		String s=this.ta.getText();

		//if (!(s.endsWith("html")))
			//this.jep.setText(s+" nije HTML fajl.");

		URL u;

		try {

			u = new URL(s);
			BufferedReader br=new BufferedReader(new InputStreamReader(u.openStream()));
			String tekst="";
			String linija=null;
			while((linija=br.readLine())!=null)
				tekst+=linija+"\r\n";
			this.jep.setText(tekst);

		} catch (MalformedURLException e) {

			this.jep.setText(s+" nije validan URL.");

		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public void ocisti(){

	String s1=this.jep.getText();

	String s2=s1.replaceAll("<[/]?html>", "");
	String s3=s2.replaceAll("<[/]?h[123456]>","");
	String s4=s3.replaceAll("<[/]?p>", "");
	String s5=s4.replaceAll("<[/]?body>", "");
	String s6=s5.replaceAll("<!DOCTYPE[^>]+>","");
	String s7=s6.replaceAll("<[/]?ol>", "");
	String s8=s7.replaceAll("<li>", "");

	this.jep.setText(s8);
}

}

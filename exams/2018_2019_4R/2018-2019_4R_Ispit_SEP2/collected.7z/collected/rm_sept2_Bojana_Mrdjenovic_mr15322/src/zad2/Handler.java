package zad2;

import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class Handler implements HyperlinkListener{

	private JEditorPane jep;
	private JTextArea jta;
	public Handler(JEditorPane jep, JTextArea jta){
		this.jep = jep;
		this.jta = jta;
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		HyperlinkEvent.EventType type = e.getEventType();
		String url = this.jta.getText();

		if(type == HyperlinkEvent.EventType.ACTIVATED){
			try {
				this.jep.setPage(url);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	public void prikazi() throws IOException{
		String u = this.jta.getText();
		URL url = new URL(u);
		this.jep.setPage(url);
	}


}

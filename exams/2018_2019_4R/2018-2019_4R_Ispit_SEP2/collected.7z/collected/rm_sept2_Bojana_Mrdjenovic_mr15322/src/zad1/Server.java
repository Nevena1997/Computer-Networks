package zad1;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

public class Server extends Thread{
	public final int port = 34567;
	public final String hostname = "localhost";

	private ServerSocket serverSocket;
	private List<Socket> listaCekanja;

	public Server() throws IOException{
		serverSocket = new ServerSocket(port);
		listaCekanja = new ArrayList<Socket>();
	}

	public static void main(String[] args) throws IOException {
		 Server server = new Server();
		 server.start();

	}

	public void run(){
		try {
			Socket clientSocket = serverSocket.accept();
			BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			String s = in.readLine();

			if(s.equalsIgnoreCase("send")){
				while((s = in.readLine()) != null){
					for(Socket sock : listaCekanja){
						BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
						out.write(s);
					}
				}

				for(Socket sock : listaCekanja){
					sock.close();
				}

				listaCekanja.clear();
			}

			if(s.equalsIgnoreCase("recv")){
				listaCekanja.add(clientSocket);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

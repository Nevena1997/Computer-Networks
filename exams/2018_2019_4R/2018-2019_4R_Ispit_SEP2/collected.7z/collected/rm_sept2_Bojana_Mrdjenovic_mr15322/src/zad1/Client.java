package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class Client {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws UnknownHostException, IOException {
		Server s = new Server();
		Socket client = new Socket(s.hostname, s.port);

		System.out.println("Unesite rezim");
		String rezim = sc.next();

		if(rezim.equalsIgnoreCase("send"))
			new Client().send(client);

		else if(rezim.equalsIgnoreCase("recv"))
			new Client().recv(client);

		else{
			System.out.println("Unesite 'send' ili 'recv'");
			System.exit(-1);
		}

		client.close();
		sc.close();

	}

	private void send(Socket client) throws IOException{
		System.out.println("Unesite putanju do fajla");
		String putanja = sc.next();
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)));
		out.write("send");
		out.flush();

		String s;
		while((s = br.readLine()) != null)
			out.write(s);

		br.close();
		out.close();
	}

	private void recv(Socket client) throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
		String s;
		while((s = in.readLine()) != null)
			System.out.println(s);

		in.close();
	}

}

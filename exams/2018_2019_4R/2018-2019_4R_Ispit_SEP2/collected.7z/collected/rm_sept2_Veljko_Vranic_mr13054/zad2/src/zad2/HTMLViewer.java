package zad2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;

import javafx.scene.Parent;
import javafx.scene.Scene;

public class HTMLViewer {
	public static final String LOCATION = "C:/Users/nalog/Desktop/rm_sept2_Veljko_Vranic_mr13054/zad2/test.html";

	public static void main(String[] args) {

		InputStreamReader istream = null;
		try {
			istream = new FileReader(LOCATION);
		} catch (FileNotFoundException e) {
			System.out.println("Lokacija fajla nije validna");
			e.printStackTrace();
		}
		int x = 0;

		StringBuffer sb = new StringBuffer();

		int y = 10000;
		try {
			while (( x = istream.read()) > 0 && y > 0) {
				sb.append((char) x);
				y--;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			istream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		String html = sb.toString().trim();

		// postavljanje underscore-a na h1
		html.replaceAll("<h1>", "<h1><u>");
		html.replaceAll("</h1>", "</u></h1>");

		// izvlacenje sadrzaja
		StringBuffer newContent = new StringBuffer();
		newContent.append("<html><body>");
		boolean inside = false;
		for (int i = 0; i < html.length(); i++) {
			if (html.charAt(i) == '<' && html.charAt(i+1) == 'h' && html.charAt(i+3) == '>') {
				int z = html.charAt(i+2) - '0';
				System.out.println(z);
				for (int p = 0; p < z; p++) {
					newContent.append("<ul>");
				}
				newContent.append("<li>");
				inside = true;
			}
			if (inside) {
				newContent.append(html.charAt(i));
			}
			if (html.charAt(i) == '<' && html.charAt(i+1) == '/' && html.charAt(i+2) == 'h' && html.charAt(i+4) == '>') {
				int z = html.charAt(i+3) - '0';
				newContent.append("/li>");
				for (int p = 0; p < z; p++) {
					newContent.append("</ul>");
				}
				newContent.append("\n");
				inside = false;
			}
		}
		newContent.append("</body></html>");
		System.out.println(newContent.toString());

		JEditorPane jer = new JEditorPane("text/html", newContent.toString());
		jer.setVisible(true);


		JTextField jtext = new JTextField();
		jtext.setText("Upisi url");
		jtext.setSize(200, 100);
		jtext.setBackground(Color.WHITE);
		jtext.setVisible(true);

		JScrollPane scrollPane = new JScrollPane(jer);
		scrollPane.setVisible(true);

		JSplitPane jsplitPane = new JSplitPane();
		jsplitPane.setBottomComponent(scrollPane);
		jsplitPane.setDividerSize(5);
		jsplitPane.setDividerLocation(100);
		jsplitPane.setVisible(true);
		jsplitPane.setResizeWeight(0.5);

		JButton loadButton = new JButton();
		loadButton.setVisible(true);
		loadButton.setText("Prikazi");

		// dodati on action listener, za click procitaj sadrzaj jtext.getText();
		//loadButton.addActionListener(arg0);
		// onda tek ide load filea i ovaj replace sa <u> tagom

		// dodati on action listener, za click
		// izmeni po zeljenim kriterijumima i renderuj ponovo sa setPage na editorPane-u




		JButton contentButton = new JButton();
		contentButton.setVisible(true);
		contentButton.setText("Sadrzaj");

		JSplitPane jbuttonsPane = new JSplitPane();
		jbuttonsPane.setVisible(true);
		jbuttonsPane.setDividerLocation(300);
		jbuttonsPane.setSize(200, 100);
		jbuttonsPane.setLeftComponent(loadButton);
		jbuttonsPane.setRightComponent(contentButton);
		jbuttonsPane.setResizeWeight(0.5);

		JScrollPane scrollPane2 = new JScrollPane(jbuttonsPane);
		scrollPane2.setVisible(true);

		JSplitPane jsplitPaneLeft = new JSplitPane();
		jsplitPaneLeft.setBottomComponent(jbuttonsPane);
		jsplitPaneLeft.setTopComponent(jtext);
		jsplitPaneLeft.setDividerSize(5);
		jsplitPaneLeft.setDividerLocation(0.5);
		jsplitPaneLeft.setVisible(true);
		jsplitPaneLeft.setOrientation(0);
		jsplitPaneLeft.setResizeWeight(1);

		jsplitPane.setTopComponent(jsplitPaneLeft);
		jsplitPane.setOrientation(0);

		JFrame frame = new JFrame("Test");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 400);
		frame.setContentPane(jsplitPane);
		frame.setResizable(true);

		//HTMLEditorKit editorKit = (HTMLEditorKit) jer.getEditorKit();
		//System.out.println(document.getLength());
	}

}

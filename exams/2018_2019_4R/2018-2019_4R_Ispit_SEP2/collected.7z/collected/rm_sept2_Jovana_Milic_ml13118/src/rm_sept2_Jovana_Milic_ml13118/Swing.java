package rm_sept2_Jovana_Milic_ml13118;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.html.HTML;


public class Swing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame();
		frame.setSize(600,400);
		addComp(frame.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				frame.setVisible(true);

			}
		});

	}

	private static void addComp(Container contentPane) {
		// TODO Auto-generated method stub
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea textArea= new JTextArea();
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=0;
		c.gridwidth=2;
		c.weightx=1;
		contentPane.add(textArea,c);

		JButton btnP = new JButton("Prikazi");
		c.fill=GridBagConstraints.HORIZONTAL;
		c.gridx=0;
		c.gridy=1;
		c.gridwidth=1;
		c.weightx=0.5;
		contentPane.add(btnP,c);



		JButton btnS = new JButton("Sacuvaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx=1;
		c.gridy=1;
		c.weightx=0.5;
		contentPane.add(btnS,c);

		JEditorPane jep = new JEditorPane();
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=2;
		c.gridwidth=2;
		c.weightx=1;
		c.weighty=1;
		contentPane.add(scrollPane,c);

		btnP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					URL u = new URL(textArea.getText());

					BufferedReader br = new BufferedReader(new InputStreamReader(u.openStream()));
					String line ="";
					String aLine ="";
					while( (line = br.readLine())!=null ){
						aLine=aLine.concat(line+"\r\n");
					}

					jep.setText(aLine);

					//    file:///C:/Users/nalog/Desktop/rm_sept2_Jovana_Milic_ml13118/src/1.html




				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btnS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub


				String text = jep.getText();

				String text1 = text.replaceAll("<h1>[ \t\n]*([^<]*)</h1>", "<li>\t$1");
				String text2 = text1.replaceAll("<h2>[ \t\n]*([^<]*)</h2>", "<li>\t\t$1");
				String text3 = text2.replaceAll("<h3>[ \t\n]*([^<]*)</h3>", "<li>\t\t\t$1");
				String text4 = text3.replaceAll("<h4>[ \t\n]*([^<]*)</h4>", "<li>\t\t\t\t$1");
				String text5 = text4.replaceAll("<h4>[ \t\n]*([^<]*)</h4>", "<li>\t\t\t\t\t$1");
				String text6 = text5.replaceAll("<h4>[ \t\n]*([^<]*)</h4>", "<li>\t\t\t\t\t\t$1");

				try {
					FileOutputStream f = new FileOutputStream("p.html");
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(f, "UTF-8"));

					try {
						bw.write(text6);
						bw.flush();
						bw.close();

						jep.setPage("file:///C:/Users/nalog/Desktop/rm_sept2_Jovana_Milic_ml13118/p.html");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}


				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println(text3);


			}
		});








	}

}

package Sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Socket client = new Socket();
			System.out.println("Izaberi rezim rada recv ili send");
			Scanner sc = new Scanner(System.in);

			String r = sc.next();
			System.out.println(r);
			try {
				client.connect(new InetSocketAddress(34567));
				BufferedWriter bw = new BufferedWriter( new OutputStreamWriter( client.getOutputStream(),"UTF-8"));
				bw.write(r.toCharArray());
				bw.flush();


				if(r.equalsIgnoreCase("recv")){
					//klijent prima fajl od drugog klijenta, ceka da mu server posalje

					InputStreamReader in =new InputStreamReader(client.getInputStream(),"UTF-8");
					char [] cbuf = new char[255];
					client.wait();
					in.read(cbuf);
					System.out.println(Server.getdata(cbuf));
					String file = Server.getdata(cbuf);
					FileInputStream fin = new FileInputStream(new File(file));
					BufferedReader bfile = new BufferedReader(new InputStreamReader(fin));
					String line="";

					while( (line=bfile.readLine())!=null){
						System.out.println(line);
					}



				}
				else if(r.equalsIgnoreCase("send")){
					System.out.println("uneti naziv fajla");

					String f = sc.next();

					bw.write(f.toCharArray());
					bw.flush();

				}



			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}







	}

}

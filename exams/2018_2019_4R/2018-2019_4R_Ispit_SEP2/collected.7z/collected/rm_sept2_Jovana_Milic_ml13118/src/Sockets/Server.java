package Sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;

import com.sun.xml.internal.fastinfoset.util.CharArray;

import javafx.beans.binding.ListBinding;

public class Server {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BlockingQueue<Socket> list = null;
		int count =0;

		try {
			ServerSocket server = new ServerSocket(34567);

			while(true){
				Socket client = server.accept();
				//System.out.println(client.getLocalPort());
				InputStreamReader in = new InputStreamReader(client.getInputStream(),"UTF-8");
				BufferedReader br = new BufferedReader(in);

				char [] buf = new char[255];

				//br.read(buf, 0, client.getReceiveBufferSize());
				in.read(buf);
				String rezim = getdata(buf);
				System.out.println("rezim je "+rezim);

				rezim = rezim.trim();

				if( rezim.equalsIgnoreCase("recv") ){

					System.out.println("rezim recv");
					try {
						//stavljas u listu cekanja
						count++;
						client.wait();
						list.put(client);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
/*
					OutputStreamWriter out = new OutputStreamWriter(client.getOutputStream(),"UTF-8");
					out.write("fajlic".toCharArray());
					out.flush();
					System.out.println("poslato");
*/


				}
				else if(rezim.equalsIgnoreCase("send")){
					//	System.out.println("rezim send prima fajl od klijenta");

						in.read(buf);
						System.out.println(getdata(buf));
						while(count>0){
							Socket client2= list.take();
							client2.notify();
							OutputStreamWriter out = new OutputStreamWriter(client2.getOutputStream(),"UTF-8");
							out.write("fajlic".toCharArray());
							out.flush();
							client2.close();
						}
						count = 0;



				} else {
					System.out.println("ovde ");
				}





			}



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getdata(char[] buf) {
		// TODO Auto-generated method stub
		if(buf==null)
			return null;
		StringBuilder sb = new StringBuilder();
		for( int i=0; i< buf.length; i++)
			sb=sb.append((char)buf[i]);

		return sb.toString();

	}

}

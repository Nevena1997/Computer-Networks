package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

public class LinkHandler implements HyperlinkListener{

	private JEditorPane pane;
	private JTextArea addressBar;

	public LinkHandler(JEditorPane pane, JTextArea add) {
		this.pane=pane;
		this.addressBar=add;
	}
	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		if(e.getEventType()==EventType.ACTIVATED)
			try {
				this.pane.setPage(e.getURL());
			} catch (IOException e1) {
				this.pane.setText("<html>Could not load "+e.getURL()+" </html>");
			}

	}

	public void prikazi(){
		URL url=null;

		try {
			url=new URL(this.addressBar.getText());
			this.pane.setPage(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sadrzaj(){
		ParserGetter pg=new ParserGetter();
		HTMLEditorKit.Parser p=pg.getParser();
		ParserCallbackImpl pc=new ParserCallbackImpl(new OutputStreamWriter(System.out));

		URL url=null;
		String encoding="UTF-8";
		BufferedReader in;

		try {
			url=new URL(this.addressBar.getText());
			in=new BufferedReader(new InputStreamReader(url.openStream(),encoding));
			p.parse(in, pc, true);

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package zad2;

import java.io.IOException;
import java.io.Writer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{
	private Writer out;
	private boolean inHeader=false;

	public ParserCallbackImpl(Writer out){
		this.out=out;
	}

	@Override
	public void handleText(char[] data, int pos) {
		if(inHeader){
			try {
				this.out.write(data);
				this.out.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
		if(t==HTML.Tag.H1){
			try {
				this.out.write(" ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(t==HTML.Tag.H2){

			try {
				this.out.write("  ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(t==HTML.Tag.H3){

			try {
				this.out.write("   ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(t==HTML.Tag.H4){

			try {
				this.out.write("    ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(t==HTML.Tag.H5){

			try {
				this.out.write("     ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(t==HTML.Tag.H6){

			try {
				this.out.write("      ");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
			return;
		inHeader=true;

	}

	@Override
	public void handleEndTag(Tag t, int pos) {
		if(t==HTML.Tag.H1 || t==HTML.Tag.H2 || t==HTML.Tag.H3 || t==HTML.Tag.H4 || t==HTML.Tag.H5 || t==HTML.Tag.H6){
			inHeader=false;
			try {
				this.out.write("\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 }



}

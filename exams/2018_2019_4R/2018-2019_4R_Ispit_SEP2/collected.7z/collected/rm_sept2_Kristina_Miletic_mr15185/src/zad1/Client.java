package zad1;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		try {
			Socket s=new Socket("localhost", Server.PORT);

			System.out.println("Unesite rezim: ");
			String rezim=sc.nextLine();

			if(rezim.equalsIgnoreCase("send")){
				System.out.println("unesite putanju do fajla:");
				String putanja=sc.nextLine();
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package zad1;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server extends Thread{

	public static int DEFAULT_PORT = 34567;
	public static List<Socket> listaKlijenata = new ArrayList<Socket>();

	public static void main(String[] args)
	{

		new Server().start();

	}

		public void run() {

			try {
				ServerSocket server  = new ServerSocket(DEFAULT_PORT);
				Socket client = server.accept();

				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				//ucitavano indikator
				int indikator = in.read();


				//ako je nula onda je send
				if(indikator == 0)
				{
					//primamo fajl od klijenta
						String fajl = in.readLine();

						for(int i = 0; i<listaKlijenata.size();i++)
						{
							Socket sock = listaKlijenata.get(i);
							BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
							out.write(fajl);
							out.flush();
							listaKlijenata.remove(i);

						}



				}

				//ako je jedan onda je recv
				else if(indikator == 1)
				{
						listaKlijenata.add(client);


				}


			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}




		}




}

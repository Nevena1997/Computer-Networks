package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Klijent {


	public static void main(String[] args) throws UnknownHostException, IOException{

		Socket client = new Socket("localhost", Server.DEFAULT_PORT);

		Scanner sc = new Scanner(System.in);

		int indikator = sc.nextInt();

		BufferedWriter slanjeiden = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
		slanjeiden.write(indikator);

		//ako je indikator nula onda je send, a ako je 1 onda je receive
		if(indikator == 0)
		{
			BufferedReader networkIn = new BufferedReader(new InputStreamReader(System.in));
			String putanja = networkIn.readLine();

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			out.write(putanja);
			out.flush();


		}

		else if(indikator == 1)
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			String linija;
			if((linija = in.readLine()) != null)
				System.out.println(linija);
		}
	}
}

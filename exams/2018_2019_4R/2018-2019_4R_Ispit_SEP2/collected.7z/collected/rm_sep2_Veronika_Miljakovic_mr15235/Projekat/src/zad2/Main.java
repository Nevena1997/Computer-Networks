package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOError;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class Main {

	public static void main(String[] args) {


		JFrame f =  new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600,400);

		f.setResizable(true);

		addComponents(f.getContentPane());


		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				f.setVisible(true);
			}
		});


	}


	public static void addComponents(Container pane)
	{

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		JScrollPane scroll = new JScrollPane(jep);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy= 3;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scroll,c);


		TextField tekst = new TextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy= 0;
		c.ipadx = 0;
		c.ipady = 0;
		c.gridwidth = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(tekst, c);

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy= 1;
		c.ipadx = 2;
		c.ipady = 0;
		c.gridwidth = 0;
		c.gridheight = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(prikazi, c);

		prikazi.addActionListener(new ActionListener() {

			@Override

					public void actionPerformed(ActionEvent e) {

						try {

							URL url = new URL(tekst.getText());

							jep.setPage(url);


				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}



			}
		});


		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy= 1;
		c.ipadx = 2;
		c.ipady = 1;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		pane.add(sadrzaj, c);

		sadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {




			}
		});

	}

}

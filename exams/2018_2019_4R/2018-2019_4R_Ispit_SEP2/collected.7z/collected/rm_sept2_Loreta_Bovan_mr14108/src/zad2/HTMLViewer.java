package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class HTMLViewer {

	public static void main(String[] args) {
		JFrame f = new JFrame("test");
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		f.setSize(600, 400);

		addConstants(f.getContentPane());

		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run(){
				f.setVisible(true);
			}
		});
	}

	private static void addConstants(Container pane) {
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scroll = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.1;
		c.weighty = 0.1;
		pane.add(scroll, c);

		JTextArea text = new JTextArea();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0;
		c.weighty = 0;
		pane.add(text, c);

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 0.1;
		c.weighty = 0;
		pane.add(prikazi, c);

		prikazi.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String path = text.getText();
					URL url = new URL(path);
					jep.setPage(url);
				} catch (MalformedURLException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		});

		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipady = 0;
		c.weightx = 0.1;
		c.weighty = 0;
		pane.add(sadrzaj, c);
	}

}

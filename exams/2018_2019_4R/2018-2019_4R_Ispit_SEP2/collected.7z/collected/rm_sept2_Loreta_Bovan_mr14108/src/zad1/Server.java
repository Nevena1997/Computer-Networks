package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

	public static final int PORT = 34567;
	private static List<ClientHandler> clients = new ArrayList<ClientHandler>();
	private static List<ClientHandler> cekaju = new ArrayList<ClientHandler>();
	private static int broj_posiljalaca;

	public static void main(String[] args) {

		while(true){
			try(ServerSocket server = new ServerSocket(PORT)){
				broj_posiljalaca = 0;
				Socket client = server.accept();
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

				ClientHandler c = new ClientHandler(client, in, out);
				clients.add(c);
				c.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	private static class ClientHandler extends Thread {

		private BufferedReader in;
		private BufferedWriter out;
		private Socket sock;

		public ClientHandler(Socket sock, BufferedReader in, BufferedWriter out){
			this.sock = sock;
			this.in = in;
			this.out = out;
		}

		@Override
		public void run(){
			try {
				String option = in.readLine();

				if(option.trim().equalsIgnoreCase("send")){
					broj_posiljalaca++;
					if(broj_posiljalaca > 1){
						System.err.println("Ne sme biti vise od jednog posiljaoca");
						this.sock.close();
					}

					int s;
					StringBuffer sb = new StringBuffer();
					while((s = in.read()) != -1)
						sb.append((char)s);

					for(ClientHandler c : cekaju){
						c.out.write(sb.toString());
						c.out.newLine();
						c.out.flush();
						c.sock.close();
					}

					broj_posiljalaca--;
					this.sock.close();
				} else if(option.trim().equalsIgnoreCase("recv")){
					cekaju.add(this);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

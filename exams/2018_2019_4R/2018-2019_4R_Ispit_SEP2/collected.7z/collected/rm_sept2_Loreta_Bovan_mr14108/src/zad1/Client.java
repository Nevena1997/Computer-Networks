package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		Scanner sc = null;

		try(Socket sock = new Socket("localhost", Server.PORT)){
			sc = new Scanner(System.in);
			System.out.println("Uneti opciju: [send/recv]");
			String option = sc.nextLine();

			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));

			if(option.trim().equalsIgnoreCase("send")){
				out.write(option);
				out.newLine();
				out.flush();

				System.out.println("Uneti putanju do fajla: ");
				String path = sc.nextLine();
				BufferedReader file = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
				StringBuffer sb = new StringBuffer();
				int s;

				while((s = file.read()) != -1)
					sb.append((char)s);

				file.close();

				out.write(sb.toString());
				out.newLine();
				out.flush();
			} else if(option.trim().equalsIgnoreCase("recv")){
				out.write(option);
				out.newLine();
				out.flush();

				String s;
				while((s = in.readLine()) != null)
					System.out.println(s);
			}

			sc.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

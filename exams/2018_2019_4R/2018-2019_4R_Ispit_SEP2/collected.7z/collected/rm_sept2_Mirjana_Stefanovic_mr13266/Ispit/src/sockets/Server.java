package sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Vector;

public class Server {

	public static final int PORT=34567;


	public static void main(String[] args){

		try {

		ServerSocket server = new ServerSocket(PORT);
		Socket con= server.accept();

		Vector<Socket> primanje=new Vector<Socket>();
		Vector<Socket> slanje=new Vector<Socket>();

		BufferedReader br=new BufferedReader(new InputStreamReader(con.getInputStream()));
		String odgovor=br.readLine();
		//System.out.println("Rezim: "+odgovor);
		br.close();


		if (odgovor.equalsIgnoreCase("recv"))
			{

				primanje.add(con);
				System.out.println("Smesten u listu za primanje\n");

			}


		else if (odgovor.equalsIgnoreCase("send"))

		{	if(slanje.isEmpty())
				{
					slanje.add(con);
					//System.out.println("Smesten u listu za  slanje\n");

					for(int i=0;i<primanje.size();i++)

					{
						BufferedReader r=new BufferedReader(new InputStreamReader(con.getInputStream()));
						BufferedWriter w=new BufferedWriter(new OutputStreamWriter(primanje.get(i).getOutputStream()));

						String s=null;

						while((s=r.readLine())!=null)
							w.write(s);

						primanje.get(i).close();


					}

				}

			else
				{
					System.out.println("Samo jedan klijent moze biti u rezimu za slanje\r\n");
					con.close();
				}
		}


		/*for(int i=0;i<primanje.size();i++)
			System.out.println(""+primanje.get(i).getInetAddress());*/



server.close();

	}

		catch(Exception e){
			e.printStackTrace();

		}

	}



}

package swing;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JTextField;

public class LinkHandler {

	private JEditorPane jep;
	private JTextField tf;

	public LinkHandler(JEditorPane jep, JTextField tf) {

		this.jep = jep;
		this.tf = tf;
	}

	public void prikaziAction(){


	try {

			URL url=new URL(this.tf.getText());
			this.jep.setPage(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			this.jep.setText("Greska");
		}



	}

	public void sadrzajAction(){

		String tekst=this.jep.getText();

		String s=tekst.replaceAll("<p>[^<]+</p>","");
		s=s.replaceAll("<a[^>]*>[^<]+</a>","");
		s=s.replaceAll("<ul>[^<]+</ul>","");
		s=s.replaceAll("<ol>[^<]+</ol>","");
		s=s.replace("[ \\s\\t]*<img[^>]+>", "");

		s=s.replaceAll("<h1>", "<ul><li><u>");
		s=s.replaceAll("</h1>", "</u>");

		s=s.replaceAll("<h2>", "<li>");
		s=s.replaceAll("</h2>", "");

		s=s.replaceAll("<h3>",  "<li>");
		s=s.replaceAll("</h3>", "");

		s=s.replaceAll("<h4>",  "<li>");
		s=s.replaceAll("</h4>", "");

		s=s.replaceAll("<h5>", "<li>");
		s=s.replaceAll("</h5>", "");

		s=s.replaceAll("<h6>", "<li>");
		s=s.replaceAll("</h6>", "");

		this.jep.setContentType("text/html");
		this.jep.setText(s);
	}


}

package swing;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class Test {

	public static void main (String[] args)
	{
		JFrame jf=new JFrame("test");
		jf.setResizable(true);
		jf.setSize(800,600);

		addComponents(jf);

		EventQueue.invokeLater(new FrameShower(jf));

	}

	public static class FrameShower implements Runnable {

		private Frame f;

		FrameShower (Frame f){

			this.f=f;
		}

		@Override
		public void run() {
			this.f.setVisible(true);

		}
	}

	public static void addComponents (Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c=new GridBagConstraints();

		JEditorPane jep=new JEditorPane();
		JScrollPane sc=new JScrollPane(jep);

		JTextField tf=new JTextField();

		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=0;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1;
		c.weighty=0;
		c.gridwidth=3;

		pane.add(tf,c);

		LinkHandler lh=new LinkHandler(jep,tf);

		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=2;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1;
		c.weighty=1;
		c.gridwidth=3;

		pane.add(sc,c);

		JButton prikazi=new JButton();
		prikazi.setText("Prikazi");

		c.fill=GridBagConstraints.BOTH;
		c.gridx=0;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1;
		c.weighty=0;
		c.gridwidth=1;

		pane.add(prikazi,c);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.prikaziAction();

			}
		});


		JButton sadrzaj=new JButton();
		sadrzaj.setText("Sadrzaj");

		c.fill=GridBagConstraints.BOTH;
		c.gridx=1;
		c.gridy=1;
		c.ipadx=0;
		c.ipady=0;
		c.weightx=1;
		c.weighty=0;
		c.gridwidth=1;

		pane.add(sadrzaj,c);

		sadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				lh.sadrzajAction();

			}
		});


	}

}

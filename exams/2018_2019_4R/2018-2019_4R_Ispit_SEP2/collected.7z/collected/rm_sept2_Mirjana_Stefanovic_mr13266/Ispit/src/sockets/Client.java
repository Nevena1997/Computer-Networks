package sockets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

public class Client {

	public static void main (String[] args)

	{

		String hostname="localhost";

		try {

		Socket socket = new Socket(hostname, Server.PORT);

		System.out.println("send/recv?");

		Scanner sc=new Scanner(System.in);
		String odgovor=sc.next();

		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		bw.write(odgovor);
		bw.flush();
		bw.close();
		


		if (odgovor.equalsIgnoreCase("recv"))

		{
			BufferedReader br=new BufferedReader(new InputStreamReader(socket.getInputStream()));

			String tekst="";
			String line=null;

			while((line=br.readLine())!=null)
				tekst+=line+"\r\n";

			System.out.print(tekst);
			br.close();

		}

		else if (odgovor.equalsIgnoreCase("send"))

		{

			System.out.println("Unesite putanju do fajla koja se salje serveru\n");
			String putanja=sc.next();
			URL url=new URL(putanja);

			BufferedReader br=new BufferedReader(new InputStreamReader(url.openStream()));
			BufferedWriter bw2=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

			String line=null;

			while((line=br.readLine())!=null)
				bw2.write(line+"\r\n");

			bw2.flush();
			bw2.close();
			br.close();


		}


		}

		catch(Exception e){
			e.printStackTrace();
		}

	}

}

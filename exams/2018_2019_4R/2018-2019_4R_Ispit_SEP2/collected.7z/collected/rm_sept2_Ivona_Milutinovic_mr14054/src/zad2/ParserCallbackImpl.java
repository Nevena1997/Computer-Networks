package zad2;


import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback{

	private JEditorPane out;
	private StringBuffer sb;
	private int level;
	private boolean inHeader;
	private boolean inH1;

	public ParserCallbackImpl(JEditorPane out) {
		super();
		this.out = out;
		inHeader = false;
		inH1 = false;
		level = 1;
		sb = new StringBuffer();
		out.setContentType("text/html");
	}

	public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos){

		int newLevel = 1;
		if(t == HTML.Tag.HTML)
			sb.append("<html>");

		if(t == HTML.Tag.BODY)
			sb.append("<body>");

		if(t == HTML.Tag.H1){
			inH1 = true;
			newLevel = 1;
		}
		else if(t == HTML.Tag.H2)
			newLevel = 2;
		else if(t == HTML.Tag.H3)
			newLevel = 3;
		else if(t == HTML.Tag.H4)
			newLevel = 4;
		else if(t == HTML.Tag.H5)
			newLevel = 5;
		else if(t == HTML.Tag.H6)
			newLevel = 6;
		else
			return;
		inHeader = true;


		if(newLevel > level)
			for(int i = 0; i < newLevel - level; i++){
				sb.append("<ul><li>\r\n");
			}
		else if(level > newLevel){
			for(int i = 0; i < level - newLevel; i++)
				sb.append("</ul>\r\n");
			sb.append("<li>\r\n");
		}
		else
			sb.append("<li>\r\n");

		level = newLevel;
	}


	public void handleEndTag(HTML.Tag t, int pos){
		if(t == HTML.Tag.HTML)
			closeTags();

		if(t == HTML.Tag.H1){
			inH1 = false;
			inHeader = false;
		}

		else if( t == HTML.Tag.H2 || t == HTML.Tag.H3 || t == HTML.Tag.H4 || t == HTML.Tag.H5 || t == HTML.Tag.H6){
			inHeader = false;

		}
	}

	public void handleText(char[] data, int pos){

		if(inHeader){
			if(inH1){
				sb.append("<u>");
				sb.append(data);
				sb.append("</u>\r\n");
			} else{
				sb.append(data);
				sb.append("\r\n");
			}
		}
	}

	public void closeTags(){

		while(this.level-- >0)
			sb.append("</ul>");

		sb.append("</body></html>");
		out.setText(sb.toString());
	}
}

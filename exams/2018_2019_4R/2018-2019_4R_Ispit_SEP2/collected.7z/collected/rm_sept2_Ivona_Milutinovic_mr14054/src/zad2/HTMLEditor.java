package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.ChangedCharSetException;
import javax.swing.text.html.HTMLEditorKit;

public class HTMLEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame f = new JFrame("test");
		f.setSize(400, 300);
		f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		addComponents(f.getContentPane());

		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				f.setVisible(true);
			}
		});

	}

	public static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane jsp = new JScrollPane(jep);

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridheight = 1;
		c.gridwidth = 2;
		c.weightx = 1;
		c.weighty = 1;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(jsp,c);

		JTextField tf = new JTextField("file:///C:/Users/nalog/workspace/rm_sept2_Ivona_Milutinovic_mr14054/src/zad2/1.html");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 1;
		c.gridwidth = 2;
		c.weightx = 1;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(tf,c);

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 0.5;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(prikazi,c);

		prikazi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					URL url = new URL(tf.getText());
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

					StringBuffer sb = new StringBuffer();
					String s = null;
					while((s = in.readLine()) != null)
						sb.append(s + "\n");
					jep.setContentType("text/html");
					jep.setText(sb.toString());

					in.close();
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}


			}
		});


		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 0.5;
		c.weighty = 0;
		c.ipadx = 0;
		c.ipady = 0;
		pane.add(sadrzaj,c);

		sadrzaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				ParserGetter pg = new ParserGetter();
				HTMLEditorKit.Parser p = pg.getParser();
				ParserCallbackImpl pc = new ParserCallbackImpl(jep);

				URL url = null;
				String encoding = "UTF-8";
				try{
					url = new URL(tf.getText());
					InputStreamReader in = new InputStreamReader(url.openStream(), encoding);

					HTMLEditorKit.ParserCallback doNothing = new HTMLEditorKit.ParserCallback();
					p.parse(in, doNothing, false);

				}catch(ChangedCharSetException e1){
					String s = e1.getCharSetSpec();
					encoding = s.substring(s.indexOf("=") + 1);
				}catch (IOException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}

				try{
					InputStreamReader in = new InputStreamReader(url.openStream(), encoding);
					p.parse(in, pc, false);

				}catch(ChangedCharSetException e1){
					String s = e1.getCharSetSpec();
					encoding = s.substring(s.indexOf("=") + 1);
				}catch (IOException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}


			}
		});
	}
}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

	public static final int PORT = 34567;
	private static List<Socket> listaCekanja = new ArrayList<Socket>();
	private static boolean onlyOne = true;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(ServerSocket server = new ServerSocket(PORT)){

			while(true){
				Socket client = null;
				try{
					client = server.accept();
					ClientHandler c = new ClientHandler(client);
					c.start();
				}catch(IOException e){

				}


			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static class ClientHandler extends Thread{

		private Socket client;

		private BufferedReader in;
		public ClientHandler(Socket client) {
			this.client = client;
			try {
				in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void run() {

			try {
				String indikator = in.readLine();
				if(indikator.equalsIgnoreCase("send")){
					if(onlyOne == false)// onlyOne = false kada je samo jedan klijent u send rezimu rada
						client.close();
					else{
						onlyOne = false; // onlyOne = true kada ni jedan klijent nije u send rezimu rada
						String putanja = in.readLine();

						// prosledjuje se klijentima u listi cekanja
						for(Socket s : listaCekanja){
							System.out.println(s);
							 BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
							 out1.write(putanja);
							 out1.newLine();
							 out1.flush();
						}
						// svim klijentima zatvaramo vezu
						for(Socket s : listaCekanja){
							 listaCekanja.remove(s);
							 s.close();
						}
						client.close();
					}
				}else if(indikator.equalsIgnoreCase("recv")){
					listaCekanja.add(client);

				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}

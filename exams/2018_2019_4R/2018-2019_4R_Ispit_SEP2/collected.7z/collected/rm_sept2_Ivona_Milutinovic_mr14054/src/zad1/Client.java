package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Socket client = new Socket("localhost", Server.PORT)){

			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

			BufferedReader in1 = new BufferedReader(new InputStreamReader(client.getInputStream()));
			BufferedWriter out1 = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));

			String indikator = in.readLine();
			out1.write(indikator);
			out1.newLine();
			out1.flush();

			if(indikator.equalsIgnoreCase("send")){
				String putanja = in.readLine();
				out1.write(putanja);
				out1.newLine();
				out1.flush();
			}else if(indikator.equalsIgnoreCase("recv")){
				String fajl = in1.readLine();

				BufferedReader in2 = new BufferedReader(new InputStreamReader(new FileInputStream(fajl)));
				String s = null;
				while((s = in2.readLine()) != null)
					System.out.println(s);

				in2.close();
			}


		}catch(IOException e){
			e.printStackTrace();

		}

	}

}

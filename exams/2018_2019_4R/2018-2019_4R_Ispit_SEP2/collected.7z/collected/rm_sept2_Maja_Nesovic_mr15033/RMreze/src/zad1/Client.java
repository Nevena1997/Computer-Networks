package zad1;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.net.Socket;
import java.net.InetAddress;
import java.util.Scanner;
import java.util.Date;

public class Client {

	public static void main (String args[]){

		try{
			Socket sock = new Socket(InetAddress.getByName("localhost"), Server.PORT);

			Scanner ulaz = new Scanner(System.in);
			System.out.println("Izaberite rezim rada: [send/recv]");
			String rezim = ulaz.next();

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));

			if(rezim.equalsIgnoreCase("send")){

				System.out.println("Unesite putanju do fajla: ");
				String putanja = ulaz.next();
				String sadrzajFajla = "";
				BufferedReader fileIn = null;

				try{
					fileIn = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)));
				}catch(FileNotFoundException ex){
					System.out.println("Fajl nije nadjen. Saljem datum umesto sadrzaja fajla. :) ");
				}

				if(fileIn == null){
					sadrzajFajla = sadrzajFajla + new Date().toString();

				}else{
					String s = null;
					while((s = fileIn.readLine()) != null){
						sadrzajFajla = sadrzajFajla + s + "\n";
					}
				}

				if(fileIn != null)
					fileIn.close();

				out.write(rezim);
				out.newLine();
				out.write(sadrzajFajla);
				out.newLine();
				out.flush();

			}else if(rezim.equalsIgnoreCase("recv")){

				out.write(rezim);
				out.newLine();
				out.flush();

				String s = null;
				while((s = in.readLine()) != null)
					System.out.println(s);

			}else{
				System.out.println("GRESKA: nepostojeci rezim!");
			}

			if(in != null)
				in.close();
			if(out != null)
				out.close();

			ulaz.close();
			sock.close();

		}catch(IOException e){
			e.printStackTrace();
		}
	}
}

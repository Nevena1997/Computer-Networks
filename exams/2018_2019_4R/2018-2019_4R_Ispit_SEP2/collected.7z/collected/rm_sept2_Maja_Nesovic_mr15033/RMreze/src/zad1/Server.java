package zad1;

import java.net.Socket;
import java.net.ServerSocket;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.ArrayList;

public class Server {

	public static final int PORT = 34567;

	public static void main(String args[]){

		try{
			ServerSocket server = new ServerSocket(PORT);


			List<Socket> clientsToReceive = new ArrayList<Socket>();
			int brSend = 0;
			while(true){

				Socket client = server.accept();
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

				String sadrzaj = "";
				String rezim = in.readLine();

				if(rezim.equalsIgnoreCase("recv")){

					clientsToReceive.add(client);

				}else if(rezim.equalsIgnoreCase("send")){

					brSend++;
					if(clientsToReceive.size()==0 && brSend>1){
						break;
					}

					String tmp = null;
					while((tmp = in.readLine()) != null){
						sadrzaj = sadrzaj + tmp + "\n";
					}

					sendToAll(sadrzaj, clientsToReceive);

					if(clientsToReceive.size() > 0)
						brSend=0;

					for(int i=0;i < clientsToReceive.size(); i++){
						Socket cl = clientsToReceive.get(i);
						clientsToReceive.remove(i);
						cl.close();
					}


				}

			}

			server.close();
		}catch(IOException e){
			e.printStackTrace();
		}

	}

	private static void sendToAll(String sadrzaj, List<Socket> klijenti){

		try{
			for(Socket client: klijenti){
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
				out.write(sadrzaj);
				out.newLine();
				out.flush();
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
}

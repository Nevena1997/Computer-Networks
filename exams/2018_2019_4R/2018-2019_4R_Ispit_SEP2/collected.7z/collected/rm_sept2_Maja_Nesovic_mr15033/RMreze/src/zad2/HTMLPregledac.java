package zad2;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class HTMLPregledac {

	public static void main(String args[]){

		JFrame frame = new JFrame("HTML pregledac");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(600, 400);
		frame.setResizable(true);

		addComponents(frame.getContentPane());

		EventQueue.invokeLater(new Runnable(){
			@Override
			public void run(){
				frame.setVisible(true);
			}
		});
	}

	private static void addComponents(Container pane){

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		JTextArea txtArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(txtArea);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add(scrollPane, c);

		JTextField txtField = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(txtField, c);

		JButton prikazi = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(prikazi, c);

		JButton sadrzaj = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add(sadrzaj, c);


		prikazi.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {

				try{
					URL url = new URL(txtField.getText());
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					String tm = null;
					String str = "";
					while((tm = in.readLine()) != null){
						str = str + tm + "\n";
					}
					//str.replaceAll("<([a-z]*)> [a-zA-Z1-9]*</1> ", "");
					txtArea.setText(str);

					in.close();
				}catch(MalformedURLException ex){
					ex.printStackTrace();
				}catch(Exception ex){
					ex.printStackTrace();
				}


			}

		});


		sadrzaj.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {

				try{
					URL url = new URL(txtField.getText());
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
					String tm = null;
					String str = "";
					while((tm = in.readLine()) != null){
						//tm.replaceAll("", "");
						str = str + tm + "\n";
					}

					txtArea.setText(str);
					in.close();
				}catch(MalformedURLException ex){
					ex.printStackTrace();
				}catch(Exception ex){
					ex.printStackTrace();
				}


			}

		});

	}

}

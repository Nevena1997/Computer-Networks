package zad2;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.text.html.HTMLEditorKit.Parser;

public class Test {

	public static void main(String[] args) {

		JFrame frame = new JFrame("test");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.setSize(800, 600);

		try {
			addComponents(frame.getContentPane());
		} catch (IOException e) {
			e.printStackTrace();
		}

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				frame.setVisible(true);
			}
		});

	}// END OF main

	private static void addComponents(Container pane) throws IOException {

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		// ----------------------------------------------
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(jep);
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		pane.add( scrollPane, c );
		// ----------------------------------------------

		// ----------------------------------------------
		JTextField addressBar = new JTextField();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add( addressBar, c );
		// ----------------------------------------------

		// ----------------------------------------------
		JButton showButton = new JButton("Prikazi");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add( showButton, c );

		showButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					jep.setPage(new URL( addressBar.getText() ));
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		// ----------------------------------------------

		// ----------------------------------------------
		JButton contentButton = new JButton("Sadrzaj");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		c.gridwidth = 1;
		c.ipadx = 0;
		c.ipady = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		pane.add( contentButton, c );

		ParserGetter pg = new ParserGetter();
		// writing temporary to 2.html so the given file wont lose its content
		OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("2.html"));
		ParserCallbackImpl pc = new ParserCallbackImpl(jep, addressBar, out);
		Parser p = pg.getParser();

		contentButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				BufferedReader in;
				try {
					int begin = addressBar.getText().lastIndexOf("/");
					String name = addressBar.getText().substring(begin + 1, addressBar.getText().length());
					in = new BufferedReader(new InputStreamReader(new FileInputStream(name), "UTF-8"));
					p.parse(in, pc, false);

					jep.setPage(new URL("file:///C:/Users/nalog/Desktop/rm_sept2_Luka_Kumburovic_mr15114/2.html"));
				} catch (UnsupportedEncodingException | FileNotFoundException e1) {
					e1.printStackTrace();
				} catch( IOException ex ){
					ex.printStackTrace();
				}


			}
		});
		// ----------------------------------------------

	}// END OF addComponents


}// END OF class

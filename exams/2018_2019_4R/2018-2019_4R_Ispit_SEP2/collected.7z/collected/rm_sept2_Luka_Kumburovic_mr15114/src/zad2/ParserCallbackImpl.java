package zad2;

import java.io.IOException;
import java.io.Writer;

import javax.swing.JEditorPane;
import javax.swing.JTextField;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTML.Tag;

public class ParserCallbackImpl extends HTMLEditorKit.ParserCallback {

	JEditorPane pane;
	JTextField addressBar;
	String tabs = "";
	Writer out;
	boolean inHeader = false;

	public ParserCallbackImpl( JEditorPane pane, JTextField addressBar, Writer out ){
		this.pane = pane;
		this.addressBar = addressBar;
		this.out = out;
	}

	@Override
	public void handleStartTag(Tag tag, MutableAttributeSet a, int pos) {

		inHeader = true;

		if( tag == Tag.H1 )
			tabs = "\t";
		else if( tag == Tag.H2 )
			tabs = "\t\t";
		else if( tag == Tag.H3 )
			tabs = "\t\t\t";
		else if( tag == Tag.H4 )
			tabs = "\t\t\t\t";
		else if( tag == Tag.H5 )
			tabs = "\t\t\t\t\t";
		else if( tag == Tag.H6 )
			tabs = "\t\t\t\t\t\t";
		else
			tabs = "";
	}

	@Override
	public void handleEndTag(Tag t, int pos) {

		inHeader = false;
	}

	@Override
	public void handleText(char[] data, int pos) {

		if( inHeader ){
			try {
				out.write(tabs);
				out.write(data);
				out.write("<br>");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}




}// END OF class

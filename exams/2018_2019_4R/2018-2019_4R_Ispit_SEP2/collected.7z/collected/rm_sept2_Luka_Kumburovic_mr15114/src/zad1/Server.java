package zad1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static final int PORT = 34567;

	public static void main(String[] args) {

		PrintWriter out = null;
		BufferedReader in = null;
		int send = 1;
		int recv = 2;
		String temp = "";

		try{
			ServerSocket server = new ServerSocket(PORT);

			while( true ){

					Socket client = server.accept();
					System.err.println("Client connected on port: " + PORT);

					out = new PrintWriter(client.getOutputStream());
					in = new BufferedReader(new InputStreamReader(client.getInputStream()));

					int desicion = in.read();

					if( desicion == send ){

						System.out.println("Send indicator received.");

						while( (temp = in.readLine()) != null ){
							System.out.println(temp);
						}

					}
					else if( desicion == recv ){

						// dok god je temp prazan ne saljemo mu nista
						while( temp.equals("") );

						out.write(temp);

					}

			}// END OF while

		} catch( IOException ex ){
			System.err.println("Server could not be started...");
		}

	}// END OF main

}// END OF class























package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static Scanner userInput = new Scanner(System.in);

	public static void main(String[] args) {

		String host = "localhost";

		String filePath;
		PrintWriter out = null;
		BufferedReader in = null;
		int send = 1;
		int recv = 2;

		try{

			Socket client = new Socket(host, Server.PORT);

			System.out.print("Choose operation(send/recv): ");
			String command = userInput.next();

			if ( command.trim().equalsIgnoreCase("send") ){

				System.out.print("\nEnter the file path: ");
				filePath = userInput.next();

				out = new PrintWriter(client.getOutputStream());
				out.write(send);
				out.flush();

				String fileContent = readFile( new File(filePath) );

				out.write(fileContent);
				out.flush();

				System.out.println("File sent to server.");

			}
			else if ( command.trim().equalsIgnoreCase("recv") ){

				out = new PrintWriter(client.getOutputStream());
				out.write(recv);
				out.flush();

				in = new BufferedReader( new InputStreamReader(client.getInputStream()) );

				String content;
				while( ( content = in.readLine() ) != null )
					System.out.println(content);

				in.close();
			}
			else{
				System.err.println("Command don't exist, stoping connection...");
			}

			out.close();
			client.close();

		} catch( IOException ex ){
			System.err.println("Client could not connect to port: " + Server.PORT);

		}


	}// END OF main

	public static String readFile( File file ){

		String temp = "";

		try {

			Scanner fileInput = new Scanner( file );

			while( fileInput.hasNextLine() ){
				temp += fileInput.nextLine();
				temp += "\n";
			}

			fileInput.close();

			return temp.substring(0, temp.length() - 1);

		} catch (FileNotFoundException e) {
			System.err.println("File can't be opened!");
			return new String("");
		}

	}

}// END OF class









import os
import re

regex = re.compile(r'([mM].)_?(\d{5})_?([A-Z][a-z]+)_?([A-Z][a-z]+)_([AB])')
with open('RM KOL REZ.csv', 'w') as f:
    for folder in os.listdir():
        m = regex.search(folder)
        if m is not None:
            f.write(f'{m.group(1)}{m.group(2)},{m.group(3)} {m.group(4)},{m.group(5)}\n')
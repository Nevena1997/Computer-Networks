package mn15230_Andjela_Peric_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Zad1 {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String fajl = sc.next();
		BufferedReader bin = null;
		BufferedWriter bout = null;

		try {
			bin = new BufferedReader(new InputStreamReader(new FileInputStream(fajl), "ASCII"));
			bout = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));
			String linija;

			while((linija = bin.readLine()) != null){
				String[] reci = linija.split(" ");
				for(String e: reci){
					if(hex(e)){
						bout.write(e);
						bout.newLine();
					}

				}

			}

		} catch (UnsupportedEncodingException e) {
			System.out.println("Nepodrzana kodna shema.");
		} catch (FileNotFoundException e) {
			System.out.println("Fajl nije pronadjen.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			bin.close();
			bout.close();
			sc.close();
		}
	}

	private static boolean hex(String e) {
		if((e.charAt(0) != '0') || (e.charAt(1) != 'x'))
			return false;
		String ostalo = (e.substring(2)).toLowerCase();

		if(ostalo.chars().anyMatch((c -> ((int) c > (int)'f'))))
			return false;



		return true;
	}

}

package mn15230_Andjela_Peric_B;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Zad2 {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	String fajl1,fajl2;
	fajl1=sc.next();
	fajl2=sc.next();
	BufferedReader bin1=null;
	BufferedReader bin2=null;

	try {
		bin1 = new BufferedReader(new InputStreamReader(new FileInputStream(fajl1)));
		bin2 = new BufferedReader(new InputStreamReader(new FileInputStream(fajl2)));

	    int n1,n2;
       String p = bin1.readLine();
       n1 = Integer.parseInt(p);
       String s = bin1.readLine();
       n2 = Integer.parseInt(s);


	   int [] v1 = new int[n1];
	   int [] v2 = new int[n2];

       String[] prvi = bin1.readLine().split(" ");
       String[] drugi = bin2.readLine().split(" ");

       for(int i=0;i<n1;i++){
		   v1[i] = Integer.parseInt(prvi[i]);
	   }


     for(int j=0;j<n2;j++){
		   v2[j] = Integer.parseInt(drugi[j]);
	   }

	   for(int e:v1)
		   System.out.println(e);
	   for(int e:v2)
		   System.out.println(e);

	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}

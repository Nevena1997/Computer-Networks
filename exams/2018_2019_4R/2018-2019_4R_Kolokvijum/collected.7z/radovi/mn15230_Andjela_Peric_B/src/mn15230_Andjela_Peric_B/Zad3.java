package mn15230_Andjela_Peric_B;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Zad3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s;

		while(sc.hasNextLine()){
			s=sc.nextLine();
			try {
				URL u = new URL(s);

			//	if(u.getHost().contains("1")){
				System.out.println(u.getProtocol() + " " + u.getDefaultPort()+ " " + u.getHost() + " " +
				  u.getPath());
		//		}

			//	else{

				String[] delovi = u.getPath().split(":");
				String adresa;
				if(delovi[0].charAt(0) != '/'){
					adresa = delovi[0];
				}
				else
					adresa = delovi[0].substring(1);
				String putanja = delovi[1].substring(4);

		        InetAddress adr = InetAddress.getByName(adresa);


				System.out.println( "(v4)" + " " + u.getProtocol() + " " + u.getDefaultPort()+ " " +
						  putanja + " " + bajtovi(adr));

		//		}


		} catch (MalformedURLException e) {
				System.out.println("Neispravan URL.");
			} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}

	private static String bajtovi(InetAddress adr) {
		byte[] b = adr.getAddress();
		String s = "[" + b[0]+ " " + b[1] + " "+ b[2] + " " + b[3] + "]";
		 return s;
		 }

	/*private static String verzija(InetAddress adr) {
		byte[] bajtovi = adr.getAddress();
           if(bajtovi.length == 4)
        	   return "(v4)";
           else
        	   return "(v6)";
	}*/
}

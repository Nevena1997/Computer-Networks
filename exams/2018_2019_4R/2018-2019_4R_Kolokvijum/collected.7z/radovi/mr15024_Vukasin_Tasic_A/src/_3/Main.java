package _3;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {
	

	public static void main(String[] args) {
		URL u;
		Scanner sc = new Scanner(System.in);
		while(true){
			try{
				String naziv = sc.next();
				u = new URL(naziv);
				if(u.equals("exit"))
					break;
			
					
				System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());
				
					
			}catch(MalformedURLException xd){
				System.out.println("URL nije validan");
			}
		}
		
		sc.close();
	}

}

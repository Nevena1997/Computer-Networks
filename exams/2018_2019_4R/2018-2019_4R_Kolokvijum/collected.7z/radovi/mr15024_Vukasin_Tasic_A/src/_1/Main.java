package _1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Unesite naziv fajla: ");
		String fajl = sc.next();
		
		sc.close();

		BufferedReader in = null;
		BufferedWriter out = null;

		try {
		
			in = new BufferedReader(new FileReader(fajl));
			out = new BufferedWriter(new FileWriter("names.txt"));

			

			String x;
			String split[];
			while((x=in.readLine()) != null){
				split = x.split(" ");
				
				if(Character.isUpperCase(split[0].charAt(0)) && Character.isUpperCase(split[0].charAt(1))){
					int m = 0;
					for(int i=0; i<split[0].length(); i++)
						if(!Character.isAlphabetic(split[0].indexOf(i)))
							m=1;
					for(int i=0; i<split[1].length(); i++)
						if(!Character.isAlphabetic(split[0].indexOf(i)))
							m=1;

					if(m==0){
					out.write(split[0] + " " + split[1]);
					out.write("\r\n");
					}
				}

			}



		} catch (FileNotFoundException e) {
			System.out.println("Neuspelo otvaranje datoteke");
		} catch (IOException e) {
			System.out.println("Neuspelo citanje iz datoteke");
		}finally{
			try{
			in.close();
			out.close();
			}catch(IOException e){
				System.out.println("Neuspelo zatvaranje");
			}
		}



	}

}

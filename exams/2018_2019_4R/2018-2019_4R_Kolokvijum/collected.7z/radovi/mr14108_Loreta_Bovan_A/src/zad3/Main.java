package zad3;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		while(true){
			Scanner sc = new Scanner(System.in);
			try {
				if(sc.hasNext()){
					String line = sc.nextLine();
					URL u = new URL(line);

					System.out.println(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath());

					if(!noIP(u.getHost())){
						InetAddress addr = InetAddress.getByName(u.getHost());
						System.out.print("(v" + getVersion(addr) + ") " + u.getProtocol() + " [" );
						printBytes(addr);
						System.out.println("]");
					}
				}
			} catch (MalformedURLException e) {
				System.err.println("Nije unet validan URL.");
			} catch (UnknownHostException e) {
				System.err.println("Nije unet validan URL.");
			} finally {
				sc.close();
			}
		}

	}

	private static boolean noIP(String str) {
		if(str.indexOf(":") != -1)
			return false;

		return str.chars().anyMatch(c -> !Character.isDigit(c) && c != '.');
	}

	private static void printBytes(InetAddress addr){
		byte[] address = addr.getAddress();

		for(int i = 0; i < address.length; i++){
			int tmp = address[i] < 0 ? address[i] + 256 : address[i];
			System.out.print(tmp + " ");
		}
	}

	private static int getVersion(InetAddress addr){
		byte[] address = addr.getAddress();

		if(address.length == 4)
			return 4;
		else if(address.length == 16)
			return 6;
		else
			return -1;
	}

}

package zad2;

import java.io.FileReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do prve datoteke: ");
		String dat1 = sc.nextLine();
		System.out.println("Unesite putanju do druge datoteke:");
		String dat2 = sc.nextLine();
		
		
		sc.close();
		
		
	}

}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Uneti ime fajla:");
		String dat = sc.nextLine();

		sc.close();
		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(dat), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			while(in.hasNext()){
				String word = in.next();
				if(isName(word)){
					out.write(word);
					out.newLine();
				}
			}

		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(in != null)
				in.close();

			if(out != null){
				out.flush();
				out.close();
			}
		}
	}

	private static boolean isName(String word){
		if(word.length() <= 1)
			return false;

		if(!Character.isUpperCase(word.charAt(0)))
			return false;

		for(int i = 0; i < word.length(); i++)
			if(!Character.isLowerCase(word.charAt(i)))
				return false;

		return true;
	}


}

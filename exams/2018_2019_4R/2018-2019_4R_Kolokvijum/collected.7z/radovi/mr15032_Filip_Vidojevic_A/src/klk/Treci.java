package klk;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Treci {
//metod ispituje da li je prosledjena adresa, ako jeste vraca br bajtova ako nije vraca -1
	private static int jesteAdresa(String adresa){
		int v4=1;
		for(int i=0;i<adresa.length();i++){
			if(adresa.charAt(i)!='.' && !Character.isDigit(adresa.charAt(i))){
				v4=-1;
				break;
			}
		}
		if(v4==1)
			return 4;
		int v6=1;
		for(int i=0;i<adresa.length();i++){
			if(adresa.charAt(i)!=':' && !Character.isDigit(adresa.charAt(i)) && adresa.toLowerCase().charAt(i)!='a' && adresa.toLowerCase().charAt(i)!='b' && adresa.toLowerCase().charAt(i)!='c' && adresa.toLowerCase().charAt(i)!='d' && adresa.toLowerCase().charAt(i)!='e' && adresa.toLowerCase().charAt(i)!='f'){
				v4=-1;
				break;
			}
		}
		if(v6==1)
			return 6;

		return -1;
	}
	private static void parsiraj(String adresa){
		String[] niz=adresa.split(".");
		System.out.print("[");
		for(int i=0;i<niz.length-1;i++)
			System.out.print(niz[i]+" ");
		System.out.print(niz[niz.length-1]);
		System.out.println("]");
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			String linija=sc.nextLine();
			if(linija.trim().equalsIgnoreCase("exit"))
				break;
			try{
				URL u=new URL(linija);
				System.out.println(u.getProtocol()+ " " + u.getAuthority() + " " + u.getPath());
				if(jesteAdresa(u.getHost())==4){
					System.out.print("(v4) "+u.getProtocol()+" " + u.getPath()+" ");
					//iz nekog razloga mi ne radi parsiraj lepo
					//parsiraj(u.getHost());
				}else if(jesteAdresa(u.getHost())==6){
					System.out.println("(v6) "+u.getProtocol()+" "+u.getPath());
				}
			}catch(MalformedURLException e){
				System.out.println("URL nije validan");
				e.printStackTrace();
			}
		}
		sc.close();
	}

}

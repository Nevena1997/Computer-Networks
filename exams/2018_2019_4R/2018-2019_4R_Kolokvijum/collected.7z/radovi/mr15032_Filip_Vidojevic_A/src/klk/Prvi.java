package klk;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	private static boolean vlastito(String ime){
		if(!Character.isUpperCase(ime.charAt(0)))
			return false;
		for(int i=1;i<ime.length();i++)
			if(!Character.isLetter(ime.charAt(i)) || !Character.isLowerCase(ime.charAt(i)))
				return false;
		return true;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String ime=sc.next();
		sc.close();
		BufferedWriter w=null;
		Scanner sc1=null;
		try{
			w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));
			sc1=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(ime),"UTF-8")));
			while(sc1.hasNext()){
				String niska=sc1.next();
				if(vlastito(niska)){
					w.write(niska);
					w.newLine();
				}
			}
			sc1.close();
			w.flush();
			w.close();
		}catch(FileNotFoundException e){
			if(sc1!=null)
					sc1.close();
			if(w!=null){
				try{
				w.flush();
				w.close();
				}catch(IOException e1){
					e1.printStackTrace();
				}
			}
			System.out.println("Ne postoji fajl");
			e.printStackTrace();
		}catch(UnsupportedEncodingException e){
			if(sc1!=null)
				sc1.close();
			if(w!=null){
				try{
					w.flush();
					w.close();

				}catch(IOException e1){
					e1.printStackTrace();
				}
		}
			System.out.println("Nije dobro enkodiranje");
			e.printStackTrace();
		}catch(IOException e){
			if(sc1!=null)
				sc1.close();
			if(w!=null){
				try{
				w.flush();
				w.close();

				}catch(IOException e1){
					e1.printStackTrace();
				}
		}
			System.out.println("Greska sa ulazno-izlaznim operacijama");
			e.printStackTrace();
		}

	}

}

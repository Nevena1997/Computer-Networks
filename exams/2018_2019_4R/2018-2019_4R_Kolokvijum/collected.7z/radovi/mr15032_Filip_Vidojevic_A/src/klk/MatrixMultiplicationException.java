package klk;

public class MatrixMultiplicationException extends Exception {
	private String poruka;
	public MatrixMultiplicationException(){
		this.poruka="Ne moze se mnoziti";
	}
	public void ispisiPoruku(){
		System.out.println(poruka);
	}
}

package klk;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DrugiMain {
	private static int zbir=0;
	public static void setZbir(int zb){
		zbir+=zb;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String ime1=sc.next();
		String ime2=sc.next();
		sc.close();
		int n1;
		int n2;
		try{
		Scanner f1=new Scanner(new FileInputStream(ime1));
		Scanner f2=new Scanner(new FileInputStream(ime2));

		int brojac=0;
		while(f1.hasNext()){
			brojac=brojac+1;
			f1.nextLine();
		}
		n1=brojac;
		brojac=0;
		while(f2.hasNext()){
			brojac=brojac+1;
			f2.nextLine();
		}
		n2=brojac;
		f1.close();
		f2.close();
		if(n1!=n2)
			throw new MatrixMultiplicationException();
		

		int[][] matrica1=new int[n1][n1];
		int[][] matrica2=new int[n1][n1];
		Scanner f11=new Scanner(new FileInputStream(ime1));
		Scanner f21=new Scanner(new FileInputStream(ime2));

		int i,j;
		for(i=0;i<n1;i++)
			for(j=0;j<n1;j++){
				matrica1[i][j]=f11.nextInt();
			}
		for(i=0;i<n1;i++)
			for(j=0;j<n1;j++)
				matrica2[i][j]=f21.nextInt();
		int[][] rezultujuca=new int[n1][n1];
		Lock lock=new ReentrantLock();
		for(i=0;i<n1;i++)
			for(j=0;j<n1;j++)
				new Thread(new Mnozenje(matrica1,matrica2,i,j,lock,rezultujuca)).start();
		try{
			Thread.sleep(3000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		for(i=0;i<n1;i++){
			for(j=0;j<n1;j++)
				System.out.print(rezultujuca[i][j]+" ");
			System.out.println();}
		System.out.println(zbir);
		}catch(IOException e){
			e.printStackTrace();
			return ;
		}catch(MatrixMultiplicationException e){
			e.ispisiPoruku();
			return ;
		}



	}

}

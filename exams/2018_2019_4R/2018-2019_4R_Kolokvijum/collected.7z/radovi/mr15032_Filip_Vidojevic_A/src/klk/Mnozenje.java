package klk;

import java.util.concurrent.locks.Lock;


public class Mnozenje implements Runnable{
	private int i;
	private int j;
	private int[][] matrica1;
	private int[][] matrica2;
	private Lock lock;
	private int[][] rezultujuca;

	public Mnozenje(int[][] matrica1,int[][] matrica2,int i,int j,Lock l,int[][] rezultujuca){
		this.matrica1=matrica1;
		this.matrica2=matrica2;
		this.i=i;
		this.j=j;
		this.lock=l;
		this.rezultujuca=rezultujuca;
	}
	@Override
	public void run(){
		int suma=0;
		try{
			int k=0;
			for(k=0;k<matrica1.length;k++)
				suma+=matrica1[i][k]*matrica2[k][j];
			rezultujuca[i][j]=suma;
			this.lock.lock();
			DrugiMain.setZbir(suma);
			this.lock.unlock();
		}catch(Exception e){
			suma=0;
			e.printStackTrace();
		}
	}
}

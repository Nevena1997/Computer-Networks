package z03;


import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {





		String urlStr;

	try(Scanner sc = new Scanner(System.in)){
		while(sc.hasNextLine()){

			urlStr = sc.nextLine();


				URL u = new URL(urlStr);

				int pocetni = urlStr.indexOf(':');

				while(urlStr.charAt(++pocetni) == '/');

				int zavrsni = urlStr.indexOf('/', pocetni);

				String potencijalnaAdr = urlStr.substring(pocetni, zavrsni);

				if(potencijalnaAdr.contains(".") && potencijalnaAdr.indexOf(':') != -1)
					potencijalnaAdr = potencijalnaAdr.substring(0, potencijalnaAdr.indexOf(':'));

				if(jeAdresa(potencijalnaAdr)){



					InetAddress a = InetAddress.getByName(potencijalnaAdr);



					byte[] x = a.getAddress();

					if(x.length == 4)
						System.out.print("(v4) ");


					else

						System.out.print("(v6) ");

					System.out.print(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath() + " ");

					if(x.length == 4){
						System.out.print("[");
						for(int i = 0; i < x.length; i++){
							System.out.print(x[i] < 0 ? x[i] + 256 : x[i]);
							System.out.print(" ");
						}

						System.out.print("]\n");

					}
				}

				else{

					System.out.print(u.getProtocol() + " " + u.getAuthority() + " " + u.getPath() + "\n");
				}

		}



		}catch(MalformedURLException e){
				System.err.println("Url nije validan!");
				e.printStackTrace();

			} catch (UnknownHostException e) {
				System.err.println("Nevalidna adresa");
			}







}

	private static boolean jeAdresa(String potencijalnaAdr) {

		if(potencijalnaAdr.contains(":"))
			return true;

		char[] karakteri = potencijalnaAdr.toCharArray();


		for(int i = 0; i < karakteri.length; i++)
			if(!Character.isDigit(karakteri[i]) && karakteri[i] != '.')
				return false;

		return true;
	}

}

package z02;

public class MatrixMultiplicationException extends Throwable{

	

}

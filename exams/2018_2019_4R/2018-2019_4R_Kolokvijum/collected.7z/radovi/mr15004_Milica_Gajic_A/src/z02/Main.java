package z02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);

		String fajl1 = sc.nextLine().trim();

		String fajl2 = sc.nextLine().trim();

		sc.close();

		int dim1, dim2;

		try(Scanner sc1 = new Scanner(new InputStreamReader(new FileInputStream(fajl1)));
				Scanner sc2 = new Scanner(new InputStreamReader(new FileInputStream(fajl2)))){



			dim1 = Integer.parseInt(sc.next());



			dim2 = Integer.parseInt(sc.next());


			if(dim1 != dim2)
				throw new MatrixMultiplicationException("Matrice se ne mogu mnoziti");

			while(sc1.hasNext()){

				System.out.print(sc1.next() + " ");
			}

			System.out.println();

			while(sc2.hasNext()){

				System.out.print(sc2.next() + " ");
			}

			System.out.println();


		} catch (FileNotFoundException e) {
			System.err.println("Ne mogu da nadjem fajl");
		}

	}

}

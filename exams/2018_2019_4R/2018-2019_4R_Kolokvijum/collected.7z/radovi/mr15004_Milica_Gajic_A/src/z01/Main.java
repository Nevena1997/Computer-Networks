package z01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String fajl = sc.nextLine().trim();

		sc.close();



			try(Scanner sc2 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fajl), "UTF-8")));

				BufferedWriter out =new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"))) {



				String ime;

				while(sc2.hasNext())
					if(jesteIme(ime = sc2.next())){
						out.write(ime);
						out.newLine();
					}
				System.out.println("Gotovo!");


			} catch (FileNotFoundException e) {

				System.out.println("Ne mogu da pronadjem fajl " + fajl);
			} catch (IOException e) {

				e.printStackTrace();
			}



	}

	private static boolean jesteIme(String ime) {


		if(ime.length() < 1)
			return false;

		char[] niz = ime.toCharArray();

		if(!Character.isUpperCase(niz[0]))
			return false;

		for(int i = 1; i < niz.length; i++)
			if(!Character.isLowerCase(niz[i]))
				return false;


		return true;
	}

}

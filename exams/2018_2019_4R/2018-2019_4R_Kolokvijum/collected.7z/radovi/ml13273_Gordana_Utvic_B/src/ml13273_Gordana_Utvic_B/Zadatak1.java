package ml13273_Gordana_Utvic_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Zadatak1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Uneti ime fajla");
		String file = sc.next();

		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file))));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));

			while(in.hasNext()){
				String s = in.next();
				if(validHNum(s))
				{
					out.write(s);
					out.newLine();
				}
			}


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {

			try {
				if(in!=null){
					in.close();
				}
				if(out!=null){
					out.flush();
					out.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

	private static boolean validHNum(String s)   {

	 	int n = s.length();
		if(n<3)
			return false;

		if(!s.startsWith("0x"))
			return false;

	 for(int i=2; i<n;i++){
			if(Character.isDigit(s.charAt(i)))
			{
			}
			else if(Character.toUpperCase(s.charAt(i))!='A' && Character.toUpperCase(s.charAt(i))!='B' && Character.toUpperCase(s.charAt(i))!='C'
				&& Character.toUpperCase(s.charAt(i))!='D')
			{
				return false;
				}
	 		else if(!Character.isLetter(s.charAt(i))){
				return false;
			}
	 }
		return true;

}
}

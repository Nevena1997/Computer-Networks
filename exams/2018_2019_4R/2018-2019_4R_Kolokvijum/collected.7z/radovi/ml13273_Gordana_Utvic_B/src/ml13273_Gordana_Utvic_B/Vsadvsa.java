package ml13273_Gordana_Utvic_B;

public class Vsadvsa extends Throwable {

}

package ml13273_Gordana_Utvic_B;

import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Zadatak3 {

	public static void main(String[] args) {


			try (Scanner sc = new Scanner(System.in);){
				while(true){
					System.out.println("Uneti url ili exit");
					String unos = sc.nextLine();

					if(unos.equalsIgnoreCase("exit"))
						break;

					URL url = new URL(unos);

					String host = url.getAuthority();

					if(!proveri(host)){


						System.out.print( url.getProtocol()+" " +host+ " "  + url.getPort()+ " "+url.getPath() );
					 }
					else{
						int m = verzija(InetAddress.getByName(host));
						System.out.print("(v"+m+")");
						System.out.print("  " + url.getProtocol() +  "  " + url.getPath());
						if(m == 4){
							ispisi_v4(InetAddress.getByName(host));
						}
					}



					System.out.println();
				}
			}
			catch (MalformedURLException e) {

				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	}

	private static boolean proveri(String host) {

		if(Character.isLetter(host.charAt(0)))
				return false;

		if(host.contains(":"))
			return false;
		return true;
	}

	public static int verzija(InetAddress addr){
		byte[] b = addr.getAddress();
		if(b.length==4)
			return 4;
		else if(b.length == 16)
			return 6;
		return -1;
	}

	static void ispisi_v4(InetAddress addr){
		byte [] b= addr.getAddress();
		System.out.print("[ ");
		for(int i = 0; i< b.length;i++){
			System.out.print(b[i]>0?b[i]:b[i]+256);
			System.out.print(" ");
		}
			System.out.println("]");
	}

}

package ml13273_Gordana_Utvic_B;

import java.util.List;

public class Vektori {
	private List<Integer> prvi;
	private List<Integer> drugi;



 public Vektori(List<Integer> prvi, List<Integer> drugi) {
		this.prvi = prvi;
		this.drugi = drugi;
	}

public synchronized List<Integer> po_jedan(){

	int m = prvi.size();



	return drugi;

}
}

package ml13273_Gordana_Utvic_B;

import java.io.IOException;
import java.util.List;

import javax.swing.ListModel;

public  class Mnozi implements Runnable {
	private List<Integer> prvi;
	private List<Integer> drugi;

	private int i;

	public Mnozi(List<Integer> prvi, List<Integer> drugi,int i) {
		super();
		this.prvi = prvi;
		this.drugi = drugi;
		this.i=i;
	}



	@Override
	public void run() {
		// TODO Auto-generated method stub

	}



}

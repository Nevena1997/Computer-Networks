package ml13273_Gordana_Utvic_B;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.LinkedBlockingDeque;

public class Zadatak2 {

	public static void main(String[] args) throws IOException {


		Scanner sc = new Scanner(System.in);
		List<Integer> f = new Vector();

		System.out.println("Putanja do 1");
		String file  = sc.next();

		Scanner in = new Scanner(Paths.get(file));

		int m = 0;
		while(in.hasNextInt()){
			f.add(in.nextInt());
			m++;
		}
		in.close();
		System.out.println("Putanja do 2");
		String fi  = sc.next();

		Scanner ul = new Scanner(Paths.get(fi));
		List<Integer> d = new Vector();

		int n = 0;
		while(ul.hasNextInt()){
			d.add(ul.nextInt());
			n++;
		}

		if(n!=m)
		{
			System.err.println("dimenzje su razlicite");


		}


		for(int i = 0; i< n;i++)
			new Thread(new Mnozi(f,d,i)).start();

	}

}

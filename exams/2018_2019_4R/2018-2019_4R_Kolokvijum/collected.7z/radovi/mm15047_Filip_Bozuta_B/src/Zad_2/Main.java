package Zad_2;

import java.io.FileInputStream;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {

		String putanja1, putanja2;

		Scanner sc;



		try {

			sc = new Scanner(System.in);

			putanja1 = sc.next();
			putanja2 = sc.next();

			Scanner sc1 = new Scanner(new FileInputStream(putanja1));
			Scanner sc2 = new Scanner(new FileInputStream(putanja2));

			Vector<Double> vektor_1 = new Vector<Double>();
			Vector<Double> vektor_2 = new Vector<Double>();

			int dimenzija_1 = 0;
			int dimenzija_2 = 0;

			while(sc1.hasNext()) {

				vektor_1.add(sc1.nextDouble());
				dimenzija_1++;
			}

			while(sc2.hasNext()) {

				vektor_2.add(sc2.nextDouble());
				dimenzija_2++;
			}

			VectorMultiplicationException e = new VectorMultiplicationException();

			if(dimenzija_1 != dimenzija_2) {

				throw e;
			}
			else {

				System.out.println("Vektor 1:");
				for(Double d: vektor_1)
					System.out.print(d + " ");

				System.out.println();
				System.out.println("Vektor 2:");
				for(Double d: vektor_2)
					System.out.print(d + " ");
				System.out.println();

				SkalarniProizvod sp = new SkalarniProizvod(vektor_1, vektor_2);

				for(int i = 0; i < dimenzija_1; i++)
				{
					RacunanjeProizvoda rp = new RacunanjeProizvoda(sp, i);
					Thread t = new Thread(rp);
					t.start();
				}

				System.out.println("Skalarni proizvod ovih vektora je: " + sp.Norma());
			}

			sc.close();
			sc1.close();
			sc2.close();

		}catch(Exception e) {

			e.printStackTrace();
		}
	}
}

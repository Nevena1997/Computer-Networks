package Zad_2;

import java.util.Vector;

public class SkalarniProizvod {

	private Vector<Double> vektor1;
	private Vector<Double> vektor2;

	private int index;
	private int dimenzija;

	private double norma;

	public SkalarniProizvod(Vector<Double> v1, Vector<Double> v2) {

		vektor1 = new Vector<Double>();
		vektor2 = new Vector<Double>();

		dimenzija = 0;

		for(Double d: v1) {
			vektor1.add(d);
			dimenzija++;
		}

		for(Double d: v2)
			vektor2.add(d);

		index = 0;
		norma = 0.0;
	}

	public synchronized void RacunajProizvod() {

		norma += vektor1.get(index) * vektor2.get(index);
	}

	public double Norma() {

		return norma;
	}

	public int Dimenzija() {

		return dimenzija;
	}

	public void setIndex(int i) {

		index = i;
	}
}

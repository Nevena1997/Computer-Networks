package Zad_2;

public class RacunanjeProizvoda implements Runnable{


	private SkalarniProizvod proizvod;
	private int index;

	public RacunanjeProizvoda(SkalarniProizvod sp, int i) {

		proizvod = sp;
		index = i;
	}

	@Override
	public void run() {

		try {

			if(index < proizvod.Dimenzija()) {

				proizvod.setIndex(index);
				proizvod.RacunajProizvod();
			}

		}catch(Exception e) {

			e.printStackTrace();
		}
	}
}

package Zad_2;

import java.util.Vector;

public class VectorMultiplicationException extends Exception{

	@Override
	public void printStackTrace() {

		System.out.println("Vektori nisu istih dimenzija!");
	}
}

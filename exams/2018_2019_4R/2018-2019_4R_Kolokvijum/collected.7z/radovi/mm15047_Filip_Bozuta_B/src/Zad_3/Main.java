package Zad_3;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc;

		try {

			sc = new Scanner(System.in);

			URL[] u = new URL[200];
			int i = 0;

			while(sc.hasNextLine())
			{
				u[i] = new URL(sc.nextLine());
				i++;

				String u_format = u[i].toExternalForm();
				InputStreamReader in = new InputStreamReader(u[i].openStream());

				InetAddress address;

				System.out.println(u[i].getProtocol() + " " + u[i].getPort() + " " + u[i].getHost() + " " + u[i].getPath());

			}

			sc.close();
		}catch (Exception e) {

			e.printStackTrace();
		}
	}

}

package Zad_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc;

		BufferedReader in;
		BufferedWriter out;

		try {

			sc = new Scanner(System.in);

			String putanja = sc.next();

			in = new BufferedReader(new InputStreamReader(new FileInputStream(putanja)));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));

			char[] buffer = new char[512];
			int bytesRead;

			while((bytesRead = in.read(buffer)) != -1) {

				String[] reci = (new String(buffer)).split("\\s+");

				for(String rec: reci) {

					char[] rec_kao_niz = rec.toCharArray();

					int ind = 1;

					if(rec_kao_niz[0] != '0' || rec_kao_niz[1] != 'x')
						ind = 0;

					for(int i = 2; i < rec_kao_niz.length; i++) {

						char c = rec_kao_niz[i];

						if(!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') || (c == '\0')))
							ind = 0;
						}


					if(ind == 1) {
						out.write(rec);
						out.newLine();
					}
				}
			}

			sc.close();
			in.close();
			out.close();

		}catch(Exception e) {

			e.printStackTrace();
		}finally {

		}
	}
}

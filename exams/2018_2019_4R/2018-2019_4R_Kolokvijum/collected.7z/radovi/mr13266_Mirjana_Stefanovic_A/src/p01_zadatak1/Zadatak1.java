package p01_zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Zadatak1 {

	public static boolean validna (String s){

		boolean veliko=false;
		boolean malo=false;
		boolean ostalo=false;
		int i;

		char c = s.charAt(0);

		if (Character.isUpperCase(c))
			veliko = true;

		for (i=1; i<s.length(); i++)
		{
			c = s.charAt(i);
			if (Character.isLowerCase(c))
				malo = true;
			else
				ostalo = true;

		}

		if (veliko && malo && !ostalo)
			return true;
		else

			return false;


	}

	public static void main(String[] args) {

        System.out.println("Unesite naziv fajla.");
		Scanner sc = new Scanner(System.in);
		String file  = sc.next();
		System.out.println(file);

        try {

			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			String line;

			while ((line = br.readLine()) != null )
			{
				String[] niske = line.split(" ");

				for (String s : niske){
					if(validna(s))
						bw.write(s+"\r\n");

				}


			}

			br.close();
            bw.close();
            sc.close();
		}

		catch (Exception e){
			e.printStackTrace();
		}


	}

}

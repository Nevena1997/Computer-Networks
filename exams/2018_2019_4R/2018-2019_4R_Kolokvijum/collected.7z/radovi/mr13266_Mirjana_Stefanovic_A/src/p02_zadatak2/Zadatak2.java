package p02_zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;


public class Zadatak2 {

	public static boolean kvadratna(int[][] m){
		if(m.length == m[0].length)
			return true;
		else
			return false;
	}

	public static void ispisi(int[][] m){

		int i,j;
		for (i=0;i<m.length;i++)
		{	StringBuffer s= new StringBuffer("");
			for (j=0;i<m[i].length;j++)
				s.append(m[i][j]);
			System.out.println(s+"\r\n");
		}

	}

	public static void ucitajMatricu(int[][] m, String filename){

		try {
		BufferedReader br= new BufferedReader(new InputStreamReader (new FileInputStream(filename)));

		String line="";
		int i= 0;

		while ((line=br.readLine())!=null)
		{
			String[] brojevi = line.split(" ");
			int j=0;
			for (j=0;j<brojevi.length;j++)
				m[i][j]=Integer.parseInt(brojevi[j]);
	    }

		}

		catch(Exception e)
		{
			e.printStackTrace();
		}

	}



	public static void main(String[] args) throws MatrixMultiplicationException {

		try {

			Scanner sc = new Scanner(System.in);
			System.out.println("Unesite naziv prvog fajla.");
			String prvi = sc.next();
			System.out.println("Unesite naziv drugog fajla.");
			String drugi = sc.next();

			/*
			 *
			 *
			 * int[][] m1= null;
            int [][] m2=null;

			ucitajMatricu(m1,prvi);
			ucitajMatricu(m2,drugi);

			if (!kvadratna(m1) || !kvadratna(m2) || m1.length!=m2.length)
				throw new MatrixMultiplicationException("Matrice se ne mogu mnoziti.");

			int [][] mr=null;
			
			*
			*
			*/

			BufferedReader br= new BufferedReader(new InputStreamReader(new FileInputStream(prvi)));
			String line="";
			while( (line=br.readLine()) != null )
				{System.out.println(line+"\r\n");
				}

			BufferedReader br2= new BufferedReader(new InputStreamReader(new FileInputStream(drugi)));
			String line2="";
			while( (line2=br2.readLine()) != null )
				System.out.println(line2+"\r\n");


        br.close();
        br2.close();

		}

		catch(Exception e ){
			e.printStackTrace();
}



	}

}

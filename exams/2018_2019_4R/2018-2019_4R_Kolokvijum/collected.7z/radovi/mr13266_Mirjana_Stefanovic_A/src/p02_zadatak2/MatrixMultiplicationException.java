package p02_zadatak2;

public class MatrixMultiplicationException extends Exception {

public MatrixMultiplicationException(String message) {
		super(message);

	}



}

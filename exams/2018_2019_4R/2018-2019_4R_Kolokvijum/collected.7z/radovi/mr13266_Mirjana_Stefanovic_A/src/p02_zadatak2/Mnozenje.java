package p02_zadatak2;

public class Mnozenje implements Runnable {
	
	private int i;
	private int j;
    private int r;
    
    public Mnozenje (int i, int j){
    	this.i=i;
    	this.j=j;
    }
    
    

	@Override
	public void run() {
		int rezultat = 0;
		
		
	}

	

}

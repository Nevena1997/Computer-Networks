package p03_zadatak3;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zadatak3 {

	public static int verzija(InetAddress adresa){

		byte[] a= adresa.getAddress();

		if (a.length == 4)
			return 4;
		else if (a.length == 16)
			return 6;
		else
			return -1;

	}

	public static void main(String[] args) {

		try {

			System.out.println("Unesite URL.");
			Scanner sc = new Scanner(System.in);
			String url = sc.next();

			try{

			URL u = new URL(url);

			String protokol = u.getProtocol();
			String aut = u.getAuthority();
			String putanja = u.getPath();


			System.out.println(protokol+" "+aut+" "+putanja);


			}
			catch(MalformedURLException ex){
				System.out.println(url+" nije validan URL.");
			}

			System.out.println("Unesite URL.");
			String url2 = sc.next();

			try{

				URL u = new URL(url2);

				String protokol = u.getProtocol();
				String aut = u.getAuthority();
				String putanja = u.getPath();

				InetAddress adresa = InetAddress.getByName(u.getHost());

				if(verzija(adresa) == 4)

				{
					System.out.println("(v4) "+protokol+" "+putanja+" ["+adresa+" ]");
					byte[] a= adresa.getAddress();
					/*int i;
					for (i=0; i<a.length; i++)
						if (a[i] < 0)
							System.out.println(a[i]+256);
						else
							System.out.println(a[i]);*/
				}

				else if (verzija(adresa) == 6){

					System.out.println("(v6) "+protokol+" "+putanja+" ");
				}

				else
					System.out.println("Greska.");

				}
				catch(MalformedURLException ex){
					System.out.println(url2+" nije validan URL.");
				}

			sc.close();

		}

		catch (Exception e){


		}

	}

}

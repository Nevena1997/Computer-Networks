package zad_2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String path = sc.nextLine();

		try(DirectoryStream<Path> dirStr = Files.newDirectoryStream(Paths.get(path))) {

			for(Path paths:dirStr) {
				if(Files.isDirectory(paths))
					continue;
				else {
					search(paths);
				}
			}

		}

	}
	public static void search(Path path) throws IOException {
		Scanner sc = new Scanner(path);


	}

}


package zad_3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		if(sc.hasNext()) {
			String str = sc.nextLine();

			try {
				URL url = new URL(str);

				String hostpart = url.getHost();


				if(isNotIP(hostpart)) {
					System.out.printf("%s %s %s\n", url.getProtocol(), url.getAuthority(), url.getPath());
				}

				else {

					try {

						InetAddress addr = InetAddress.getByName(hostpart);
						int version = addr.getAddress().length;

						if(version == 4) {
							System.out.print("(v4) ");
							System.out.printf("%s %s ", url.getProtocol(), url.getPath());
							getBytes(addr);
						}

						else if(version == 16) {
							System.out.print("(v6) ");
							System.out.printf("%s %s ", url.getProtocol(), url.getPath());
						}
						else {
							System.err.println("IP address is not valid!");
							return;
						}
					}
					catch(UnknownHostException e) {
						System.err.print("IP address is not valid!");
					}
				}
			}
			catch(MalformedURLException e) {
				e.printStackTrace();
			}
			finally {
				sc.close();

			}
		}

	}
	public static boolean isNotIP(String str) {
		if(str.indexOf(':') != -1)
			return false;

		return str.chars().anyMatch(c -> !Character.isDigit(c) && c != '.');
	}

	public static int getVersion(String addr) {
		if(addr.length() == 4)
			return 4;

		else if(addr.length() == 16)
			return 6;

		else
			return -1;
		}

	public static void getBytes(InetAddress ip) {

		byte[] bytes = ip.getAddress();

		System.out.print("[ ");
		for(int i = 0 ; i < bytes.length ; i++) {
			int u = bytes[i] < 0 ? bytes[i] + 256 : bytes[i];
			System.out.print(u+" ");
		}
		System.out.print("]");

	}

}
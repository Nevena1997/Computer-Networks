package zad_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();

		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			while(in.hasNext()) {
				String str = in.next();

				if(isNameOrSurname(str)) {
					out.write(str);
					out.newLine();
				}
			}
		}
		catch(FileNotFoundException e) {
			System.err.print("File not found!");
		}
		catch(UnsupportedEncodingException e) {
			System.err.println("Encoding is not good!");
		}
		catch(IOException e) {
			System.err.println("IOException!");
		}
		finally {
			try{
				if(in != null)
					in.close();

				if(out != null) {
					out.flush();
					out.close();
				}
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static boolean isNameOrSurname(String str) {
		if(str.length() < 1)
			return false;

		if(!Character.isUpperCase(str.charAt(0)))
			return false;

		for(int i = 1 ; i < str.length() ; i++) {
			if(!Character.isLowerCase(str.charAt(i)))
				return false;
		}
		return true;
	}
}

package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Vektor
{

	public static void main(String[] args)
	{

		try(Scanner sc = new Scanner(System.in);)
		{
			String s;
			char v;
			while((s=sc.nextLine()) != null)
			{
				try(FileInputStream in = new FileInputStream(s))
				{
					v=(char)in.read();
					System.out.println(v);
					in.close();
				}
				catch (FileNotFoundException e)
				{
					e.printStackTrace();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
	}

}

package drugi;


public class VectorMultiplicationException
{
	private String v1;
	private String v2;

	public void exception()
	{
		if(v1.length() != v2.length())
			System.err.println("Vektori nisu iste duzine, nije moguce izvrsiti mnozenje");
	}
}

package treci;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class URLScanner
{

	public static void main(String[] args)
	{
		try(Scanner sc = new Scanner(System.in))
		{
			String s;
			while((s=sc.nextLine())!=null)
			{
				URL url = new URL(s);
				if((url.getProtocol() == null) && (url.getHost() == null))
					System.out.println("Url nije validan");

				System.out.println(url.getProtocol()+" "+url.getHost()+" "+url.getDefaultPort()+" "+url.getPath());

			}

		}
		catch (IOException e)
		{
			e.printStackTrace();
		}


	}

}

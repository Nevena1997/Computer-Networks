package zadatak01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Unesite ime fajla:");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		sc.close();
		BufferedReader in=null;
		BufferedWriter out=null;

		try {
			in=new BufferedReader(new InputStreamReader(new FileInputStream(s),"UTF-8"));
			out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));
			char[] cbuf=new char[512];
			char[] outbuff= new char[512];
			int read;


			while((read=in.read(cbuf))!=-1){
				int i=0;
				int j=-1;

				while(i<read){
					if(Character.isUpperCase(cbuf[i])){
						j++;
						outbuff[j]=cbuf[i];
						while(Character.isLowerCase(cbuf[i+1]))
						{
							j++;
							i++;
							outbuff[j]=cbuf[i];
						}
						j++;
						outbuff[j]=Character.LINE_SEPARATOR;
					}
					i++;
				}
				if(Character.isUpperCase(outbuff[j-1]))
					j-=2;
				out.write(outbuff, 0, j);
			}
			System.out.println("Done.");

			in.close();
			out.close();

		} catch (FileNotFoundException e) {
			System.out.println("File not found, please try again.");
		} catch (IOException e) {
			System.out.println("Some IO exception. Try again.");
		}
		finally {

				try {
					if(in!=null){
						in.close();
					}
					if(out!=null){
						out.close();
					}

				} catch (IOException e) {
					System.out.println("Closing file failed.");
				}

		}


	}

}

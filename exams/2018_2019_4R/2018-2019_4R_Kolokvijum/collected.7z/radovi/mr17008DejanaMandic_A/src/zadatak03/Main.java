package zadatak03;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

/*http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt
 * */
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    while(true){
	    	String ur=sc.nextLine();
	    	try {
				URL url=new URL(ur);
				String protocol=url.getProtocol();
				String aut=url.getAuthority();
				String path=url.getPath();
				System.out.println(protocol+" "+aut+" "+path);

				String host=url.getHost();
				try {

					//fali provera da li je uopste ip adresa??
					InetAddress adr=InetAddress.getByName(host);
					if (adr instanceof Inet4Address)
					{
						System.out.println("(v4) "+ protocol+" "+path+ " "+adr.getAddress());
					}
					else if(adr instanceof Inet6Address)
					{
						System.out.println("(v6) "+ protocol+" "+path+ " "+adr.getAddress());
					}


				} catch (UnknownHostException e) {
					System.out.println("greska host");
				}


			} catch (MalformedURLException e) {
				sc.close();
				System.out.println("greska, url");
			}

	    }

	}
}

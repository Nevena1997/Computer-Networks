package zadatak02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	private static int matrix1[][];
	private static int matrix2[][];
	private static int result[][];

	public static void main(String[] args) {
		System.out.println("Prvi fajl:");
		Scanner sc=new Scanner(System.in);
		String fajl1=sc.nextLine();
		System.out.println("Drugi fajl:");
		String fajl2=sc.nextLine();
		sc.close();

		try {
			Scanner sc1=new Scanner(new File(fajl1));
			Scanner sc2=new Scanner(new File(fajl2));

			int n=Integer.parseInt(sc1.nextLine());
			int n2=Integer.parseInt(sc2.nextLine());
			if(n!=n2) throw new MatrixMulException();


			matrix1=new int[n][n];
			matrix2=new int[n][n];

			read(sc1,matrix1, n);
			read(sc2, matrix2, n);
            result=new int[n][n];

            System.out.println("Matrica1:");
            print(matrix1,n);
            System.out.println("Matrica2:");
            print(matrix2,n);

			for(int i=0; i<n; i++){
				for(int j=0; j<n; j++){
					Thread1 th=new Thread1(i, j, n, matrix1, matrix2, result);
					Thread t=new Thread(th);
					t.start();
				}
			}
			System.out.println("res:");
			print(result,n);

		} catch (FileNotFoundException e) {
			System.out.println("nema fajla");
		} catch (MatrixMulException e) {
			System.out.println("nemoguce mnozenje");
		}
	}

	public static void read(Scanner sc,int [][] mat, int n)
	{
		for(int i=0; i<n; i++){
			for(int j=0; j<n; j++){
				mat[i][j]=sc.nextInt();
			}
		}
		sc.close();
	}
	public static void print(int [][] mat, int n){
		for(int i=0; i<n; i++){
			String s="";
			for(int j=0; j<n; j++){
				s+=" "+mat[i][j];
			}
			System.out.println(s);
		}

	}

}

package zadatak02;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Thread1 implements Runnable {

	int i, j, n;
    int [][] matrix1;
    int [][] matrix2;
    int [][] result;
    Lock lock;
    Condition con;

	public Thread1(int i, int j, int n, int[][] matrix1,int [][] matrix2, int [][] result) {
		super();
		this.n = n;
		this.i = i;
		this.j = j;
		this.matrix1 = matrix1;
		this.matrix2 = matrix2;
		this.result=result;
		lock=new ReentrantLock();
	}

	@Override
	public void run() {
		mul();
    }

	public void mul(){
		result[i][j]=0;
		for(int p=0;p<n;p++){
			result[i][j]+=matrix1[i][p]*matrix2[p][j];
		}
	}

}

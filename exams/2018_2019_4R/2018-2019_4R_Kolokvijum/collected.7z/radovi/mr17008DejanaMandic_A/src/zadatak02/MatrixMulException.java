package zadatak02;

public class MatrixMulException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 2147227532046829943L;

}

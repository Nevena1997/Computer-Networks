import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.*;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Zad1 {

    private static final String izlaz="names.txt";

    public static void main(String[] args) {

        try(Scanner sc=new Scanner(System.in)){

            String ulaz=sc.nextLine().trim();

            try(Scanner scan=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(ulaz),"UTF-8")));
            BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(izlaz),"UTF-8"))){

                while(scan.hasNext()){

                    String tek=scan.next().trim();
                    if(Pattern.matches("^[A-Z][a-z]+$",tek)){
                        bw.write(tek);
                        bw.newLine();
                        bw.flush();
                    }

                }

            } catch (FileNotFoundException e) {
                System.err.println("Fajl nije korektno zadat, nije pronadjen.");
            } catch (UnsupportedEncodingException e) {
                System.err.println("Kodna strana nije podrzana.");
            } catch (IOException e) {
                System.err.println("IO izuzetak!");
            }
        }

    }

}

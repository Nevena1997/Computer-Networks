public class MatrixMultiplicationException extends Exception{

    private String sadrzaj="MatrixMultiplicationException";

    public MatrixMultiplicationException(){
    }

    @Override
    public String toString() {
        return sadrzaj;
    }
}

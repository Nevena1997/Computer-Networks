import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.concurrent.CancellationException;

public class Zad3 {


    public static void main(String[] args) {

        //new URL("http://2001:0db8:85a3:0000:0000:8a2e:0370:7334/dir1/dir2/test.txt");
        try(Scanner sc=new Scanner(System.in)){

            while(true){
                String s=sc.nextLine().trim();
                //program staje sa radom nakon unosa exita
                if(s.compareToIgnoreCase("exit")==0)
                    break;

                try {
                    URL u=new URL(s);
                    System.out.printf("%s %s %s\n",u.getProtocol(),u.getAuthority(),u.getPath());

                    String tek=u.getAuthority();
                    if(Character.isDigit(tek.charAt(0)))
                        ispisiDodatneInfo(u);

                } catch (MalformedURLException e) {
                    System.err.println("Nevalidno uneta URL adresa. Unesite ponovo.");
                    continue;
                }


            }

        }


    }

    private static void ispisiDodatneInfo(URL u){

        String s=u.getAuthority();
        try {
            if(s.contains(".")) {
                if(s.contains(":")) {
                    s=s.substring(0,s.lastIndexOf(":"));
                }
                InetAddress ia = InetAddress.getByName(s);
                byte[] b = ia.getAddress();
                for (int i = 0; i < 4; i++)
                    if (b[i] < 0)
                        b[i] += 256;
                System.out.printf("(v%d) %s %s [%d %d %d %d]\n", 4, u.getProtocol(), u.getPath(), b[0], b[1], b[2], b[3]);
            }
            else {
                System.out.printf("(v%d) %s %s\n", 6, u.getProtocol(), u.getPath());
            }

        } catch (UnknownHostException e) {
            System.err.println("Nepoznat host.");
        }
    }

}

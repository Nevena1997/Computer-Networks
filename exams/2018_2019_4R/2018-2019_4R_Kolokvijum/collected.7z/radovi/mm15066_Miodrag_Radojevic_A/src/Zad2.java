import java.io.*;
import java.util.Scanner;

public class Zad2 {


    private static int zbirRez=0;

    public static void main(String[] args){

        try(Scanner sc=new Scanner(System.in)){

            String ulaz1=sc.next().trim();
            String ulaz2=sc.next().trim();

            //ISPISI MATRICE!
            int[][] m1=null,m2=null;
            int n1=0,n2=0;

            //Ucitavamo i ispisujemo PRVU matricu
            try(BufferedReader br1=new BufferedReader(new InputStreamReader(new FileInputStream(ulaz1)))) {

                System.out.println("Prva matrica:");
                String linija=br1.readLine();
                String[] vrsta=linija.split(" ");
                System.out.println(linija);
                n1=vrsta.length;//ovako smo odredili dimenziju prve matrice
                m1=new int[n1][n1];
                for(int j=0;j<n1;j++)
                    m1[0][j]=Integer.parseInt(vrsta[j]);

                for(int i=1;i<n1;i++){
                    linija=br1.readLine();
                    System.out.println(linija);
                    vrsta=linija.split(" ");
                    for(int j=0;j<n1;j++){
                        m1[i][j]=Integer.parseInt(vrsta[j]);
                    }
                }

                System.out.println("****************");

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            //Ucitavamo i ispisujemo DRUGU matricu
            try(BufferedReader br2=new BufferedReader(new InputStreamReader(new FileInputStream(ulaz2)))) {

                System.out.println("Druga matrica:");
                String linija=br2.readLine();
                String[] vrsta=linija.split(" ");
                System.out.println(linija);
                n2=vrsta.length;//ovako smo odredili dimenziju prve matrice
                m2=new int[n2][n2];
                for(int j=0;j<n2;j++)
                    m2[0][j]=Integer.parseInt(vrsta[j]);

                for(int i=1;i<n2;i++){
                    linija=br2.readLine();
                    System.out.println(linija);
                    vrsta=linija.split(" ");
                    for(int j=0;j<n2;j++){
                        m2[i][j]=Integer.parseInt(vrsta[j]);
                    }
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            //PROVERITI DA LI SU MATRICE ISTE DIMENZIJE!!!

            if(n1!=n2)
                try {
                    throw new MatrixMultiplicationException();
                } catch (MatrixMultiplicationException e) {
                    e.printStackTrace();
                }

                //za slucaj da su matrice istih dimenzija
            int n=n1;

            int[][] rezultat=new int[n][n];

            Thread[][] nizNiti=new Thread[n][n];
            for(int i=0;i<n;i++)
                for(int j=0;j<n;j++) {
                    nizNiti[i][j] = new Thread(new Zad2Nit(i, j, m1, m2, rezultat));
                    nizNiti[i][j].start();
                }

                //cekamo sve niti
            for(int i=0;i<n;i++)
                for(int j=0;j<n;j++) {
                    nizNiti[i][j].join();
                }

            //Ispis rezultujuce matrice
            System.out.println("\nRezultujuca matrica:");
            for(int i=0;i<n;i++) {
                for (int j=0; j < n; j++) {
                    System.out.print(rezultat[i][j] + " ");
                }
                System.out.println();
            }

            System.out.println("Zbir rezultujuce matrice je: "+zbirRez);


        } catch (InterruptedException e) {
            //samo ignorisemo interrupt
        }

    }

    public static synchronized void zbir(int sabirak){
        zbirRez+=sabirak;
    }

}

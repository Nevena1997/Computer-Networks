public class Zad2Nit implements Runnable {

    private final int i;
    private final int j;
    private final int[][] m1;
    private final int[][] m2;
    private int[][] rez;

    public Zad2Nit(int i,int j,int[][] m1,int[][] m2,int[][] rez){
        this.i=i;
        this.j=j;
        this.m1=m1;
        this.m2=m2;
        this.rez=rez;
    }

    @Override
    public void run() {
        int n=m1.length;
        int suma=0;
        for(int t=0;t<n;t++){
            System.out.println(t);
            suma+=m1[i][t]*m2[t][j];}
        rez[i][j]=suma;
        Zad2.zbir(suma);
    }
}

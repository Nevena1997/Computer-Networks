package prvi_zadatak;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		String file=sc.next();
		sc.close();

		Scanner in=null;
		BufferedWriter out=null;
		try{
			in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));

			while(in.hasNext()){
				String hex=in.next();
				if(isHexadecimal(hex)){
					out.write(hex);
					out.newLine();
				}
			}
			out.close();
		}catch(UnsupportedEncodingException e){
			System.err.println("Find new JVM, this encoding isn't supported.");
		}catch(FileNotFoundException e){
			System.err.println("File could not be found.");
		}catch(IOException e){
			System.err.println("Exception with Input/Output.");
		}finally{
				if(in!=null)
					in.close();
				try{
					if(out!=null){
						out.flush();
					    out.close();
					}
				}catch(IOException e){
					e.printStackTrace();
				}

		}
	}
	private static boolean isHexadecimal(String string){
		if(string.length()<3)
			return false;
		if(!string.startsWith("0x"))
			return false;
		string.toLowerCase();
		for(int i=0; i<string.length(); i++)
			if((!Character.isDigit(string.charAt(i))) && (string.charAt(i)!='a' || string.charAt(i)!='b' || string.charAt(i)!='c' || string.charAt(i)!='d' || string.charAt(i)!='f'))
					return false;
		return true;

	}

}

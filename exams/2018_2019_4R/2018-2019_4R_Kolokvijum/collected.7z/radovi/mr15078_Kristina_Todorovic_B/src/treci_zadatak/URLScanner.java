package treci_zadatak;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class URLScanner {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			String host=sc.nextLine();
			try{
				URL url=new URL(host);
				if(isHostname(url.getHost())){
					System.out.print(url.getProtocol() + " ");
				    System.out.print(url.getAuthority() + " ");
				    System.out.print(url.getDefaultPort() + " ");
				    System.out.print(url.getHost() + " ");
				    System.out.print(url.getPath());
				    System.out.println();
				}else{
					try{
						InetAddress addr=InetAddress.getByName(host);
						byte[] array=addr.getAddress();
						int ver=array.length;
						System.out.printf("(v%d) %s %d %s", ver, url.getProtocol(), url.getPort(), url.getPath());
						if(ver==4){
							System.out.print("[");
						    for(int i=0; i<array.length; i++){
						    	int b=array[i]<0 ? array[i]+256 : array[i];
						    	System.out.print(b + " ");
						    }
						    System.out.print("]");
						    System.out.println();
						}
					}catch(UnknownHostException e){
						e.printStackTrace();
					}

				}
			}catch(MalformedURLException e){
				sc.close();
				System.out.println("URL is not valid!");
				return;
			}

		}
		sc.close();
	}

	private static boolean isHostname(String host){
		if(host.indexOf(':')!=-1)
			return false;
		return host.chars().anyMatch(c->!Character.isDigit(c) && c!='.');
	}

}

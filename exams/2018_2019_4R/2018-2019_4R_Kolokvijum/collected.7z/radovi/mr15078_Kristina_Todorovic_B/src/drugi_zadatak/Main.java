package drugi_zadatak;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import java.nio.file.Path;
import java.nio.file.Paths;


public class Main {


	public static void main(String[] args){
		if(args.length<2){
			System.err.println("Too few arguments for program!");
			return;
		}

		int n1[]=new int[100];
		int n2[]=new int[100];

		int length1=0;
		int length2=0;

		Path path1=Paths.get(args[1]);
		Path path2=Paths.get(args[2]);
		try {
			BufferedReader in1=new BufferedReader(new InputStreamReader(new FileInputStream(path1.toString())));
			BufferedReader in2=new BufferedReader(new InputStreamReader(new FileInputStream(path2.toString())));
			while(in1.read()!=-1){
				System.out.print(in1.read() + " ");
				n1[length1]=in1.read();
				length1++;
			}
			System.out.println();
			in1.close();
			while(in2.read()!=-1){
				System.out.print(in2.read() + " ");
				n2[length2]=in2.read();
				length2++;
			}
			System.out.println();
			in2.close();

			for(int i=0; i<100; i++)
				new Thread(new VectorMultiplicationException(length1, length2)).start();


		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}




	}
}




package drugi_zadatak;

import java.io.IOException;

public class VectorMultiplicationException implements Runnable{

	private int m[];
	private int n[];

	public VectorMultiplicationException(int mLength, int nLength) throws IOException{
		if(mLength!=nLength)
			throw new IOException("Different dimensions");

		this.m=new int[mLength];
		this.n=new int[nLength];

	}
	public void run(){

	}
}

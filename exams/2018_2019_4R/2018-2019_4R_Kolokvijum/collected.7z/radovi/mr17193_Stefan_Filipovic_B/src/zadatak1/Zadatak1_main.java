package zadatak1;

import java.util.Scanner;

import java.io.*;


public class Zadatak1_main {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {

			String fileName = sc.nextLine();
			fileName = "src/zadatak1/" + fileName;
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new
					FileOutputStream("src/zadatak1/hex.txt"), "ASCII"));

			String text = new String();
			exit:
			while ((text = in.readLine()) != null) {
				if (text.charAt(0) != '0' && text.toLowerCase().charAt(1) != 'x')
					continue;
				for (int i = 2; i < text.length(); i++) {
					if (text.charAt(i) >= '0' && text.charAt(i) <= '9')
						continue;
					else if (text.toLowerCase().charAt(i) >= 'a' && text.toLowerCase().charAt(i) <= 'f')
						continue;
					else
						continue exit;
				}
				out.write(text);
				out.newLine();
			}
			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

package zadatak3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class URL_Scanner {

	public static void main(String[] args) throws MalformedURLException {
		try (Scanner sc = new Scanner(System.in)) {

			String tt = new String();

			while ((tt = sc.nextLine()) != null) {

				URL url = new URL(tt);

				System.out.println("Protocol : " + url.getProtocol());
				System.out.println("Default port : " + url.getDefaultPort());
				System.out.println("Host name : " + url.getHost());
				System.out.println("Path : " + url.getPath());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

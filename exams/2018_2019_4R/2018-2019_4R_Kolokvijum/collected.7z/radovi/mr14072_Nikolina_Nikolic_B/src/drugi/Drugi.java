package drugi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class Drugi {

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);
		String fajl1=sc.nextLine().trim();
		String fajl2=sc.nextLine().trim();
		Scanner in1=null;
		Scanner in2=null;
		int[] a=new int[100];
		int[] b=new int[100];
		try {
			 in1=new Scanner((Readable) new InputStreamReader(new FileInputStream(fajl1)));
			 int i=0;
			 while(in1.hasNextInt()){
				a[i]=in1.nextInt();
				System.out.print(a[i] + " ");
				i++;
			 }

			 in2=new Scanner((Readable) new InputStreamReader(new FileInputStream(fajl2)));
			 int j=0;
			 while(in2.hasNextInt()){
				 b[j]=in2.nextInt();
				 System.out.print(b[j] + " ");
				 j++;


			 }

			 int n=a.length;

			 for(int k=0;k<n;k++){
				 Multiplication m=new Multiplication(a,b,n,k);
				 Thread t=new Thread(m);
				 t.start();
			 }


		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}




	}

}

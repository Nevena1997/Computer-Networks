package drugi;

public class VectorMultiplicationException {





}

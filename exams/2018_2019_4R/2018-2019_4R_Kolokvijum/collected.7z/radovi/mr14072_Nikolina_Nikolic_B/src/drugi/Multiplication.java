package drugi;

public class Multiplication implements Runnable {

	private int[] a;
	private int[] b;
	private int n;
	private int indeks;
	public int[] rezultat;

	public Multiplication(int[] a, int[] b, int n, int i){
		this.a=a;
		this.b=b;
		this.n=n;
		this.indeks=i;
	}

	public void run(){
		rezultat[this.indeks] =a[this.indeks]*b[this.indeks];

	}






}

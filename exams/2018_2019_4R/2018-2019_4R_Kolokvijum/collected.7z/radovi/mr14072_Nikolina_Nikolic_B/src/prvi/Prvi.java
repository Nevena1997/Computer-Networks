package prvi;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		String ulazni_fajl=sc.next();
		sc.close();
		Scanner ins=null;
		BufferedWriter out=null;

		try {
			InputStreamReader in=new InputStreamReader(new FileInputStream(ulazni_fajl));
			ins=new Scanner(in);

			OutputStreamWriter os= new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII");
			out=new BufferedWriter(os);

			while(ins.hasNext()){
				String s=ins.next();
				if(isHex(s)){
					out.write(s);
					out.newLine();
				}
			}


		} catch (FileNotFoundException e) {

			System.out.println("Fajl nije pronadjen");
		} catch (UnsupportedEncodingException e) {

			System.out.println("Koddna strana nije podrzana");
		} catch (IOException e) {

			System.out.println("Problem sa otvaranjem resursa");
		}
		finally{

				try {
					if(ins!=null)
						ins.close();

					if(out!=null){
						out.flush();
					    out.close();
					}
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

		}



	private static boolean isHex(String s){

		if(s.charAt(0)!= '0')
			return false;

		if(s.charAt(1)!= 'x')
			return false;

		for(int i=2;i<s.length();i++)
			if(!Character.isDigit(s.charAt(i)) && (s.charAt(i)!='A'  || s.charAt(i)!='a' || s.charAt(i)!='B' || s.charAt(i)!='b'
					|| s.charAt(i)!='C' || s.charAt(i)!='c' || s.charAt(i)!='D' || s.charAt(i)!='d'
					|| s.charAt(i)!='E' || s.charAt(i)!='e' || s.charAt(i)!='F' || s.charAt(i)!= 'f'))
				return false;




		return true;
	}

}

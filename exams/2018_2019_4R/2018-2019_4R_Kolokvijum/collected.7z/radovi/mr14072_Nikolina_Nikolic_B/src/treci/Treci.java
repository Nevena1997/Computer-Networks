package treci;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Treci {

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);

		while(sc.hasNextLine()){
			String line=sc.nextLine().trim();
			try {
				URL u=new URL(line);

				String[] n=line.split("/");
                String adresa=n[2];
                if(V4adresa(adresa)){

                	System.out.print("(v4)" + u.getProtocol()+ " " + u.getDefaultPort()+ " " + u.getPath()  );
                	return;
                }
                	if(V6adresa(adresa)){
                		System.out.print("(v6)" + u.getProtocol()+ u.getPath());
                		return;
                	}


				System.out.print(u.getProtocol()+ " "+ u.getDefaultPort() + " "+ u.getHost() + " "+ u.getPath());
                System.out.println();



                }




			catch (MalformedURLException e) {
				System.out.println("URL nije validan");
			}
			finally{
				sc.close();
			}
		}


}

	private static int getVersion(InetAddress a){
		byte[] b=a.getAddress();

		if(b.length==4)
			return 4;
		if(b.length==6)
			return 6;
		return -1;

	}

	private static boolean V6adresa(String s){
		String[] niz= s.split(":");
		if(niz.length!=6)
			return false;

		return true;


	}

	private static boolean V4adresa(String s){

		String[] niz=s.split(".");
		if(niz.length!=4) return false;


		return true;

		}

}

package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zad1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ulaz = sc.nextLine();
		/* U try(-----------) smo definisali ovecitace pa ce se sami zatvoriti
		 * Fajl sa imenom se ulaz.txt se nalazi u folderu projekta relativna putanja
		 * Samo ulaz.txt treba uneti
		 * */

		try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(ulaz),"UTF-8"));
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"))) {
			String linija = in.readLine();
			while(linija != null) {
				Pattern pattern = Pattern.compile("[A-Z][a-z]+");
				Matcher matcher = pattern.matcher(linija);
				while(matcher.find())
					out.write(matcher.group(0) + "\r\n");
				linija = in.readLine();
			}
		} catch(IOException e) {
			e.printStackTrace(); /* Ovo ce da ispise sve moguce greske */
		}
		sc.close();

	}

}

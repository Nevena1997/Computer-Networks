package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Zad2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fajl1 = sc.nextLine(); /* ove se takodje kao u prvom unosi samo ime fajla m1.txt i m2.txt a fajlovi su smesteni u fodler projekta */
		String fajl2 = sc.nextLine();
		int velicina_matrice_1 = 0;
		int velicina_matrice_2 = 0;
		int matrica1[][] = null;
		int matrica2[][] = null;
		try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fajl1), "UTF-8"))) {
			velicina_matrice_1 = Integer.parseInt(in.readLine());
			matrica1 = new int[velicina_matrice_1][velicina_matrice_1];
			for(int i = 0; i < velicina_matrice_1; i++) {
				String brojevi[] = in.readLine().split(" ");
				for(int j = 0; j < velicina_matrice_1; j++)
					matrica1[i][j] = Integer.parseInt(brojevi[j]);
			}


			for(int i = 0; i < velicina_matrice_1; i++) {
				for(int j = 0; j < velicina_matrice_1; j++)
					System.out.print(matrica1[i][j] + " ");
				System.out.println();
			}

		} catch(IOException e) {
			e.printStackTrace();
		}

		try(BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fajl2), "UTF-8"))) {
			velicina_matrice_2 = Integer.parseInt(in.readLine());
			matrica2 = new int[velicina_matrice_2][velicina_matrice_2];
			for(int i = 0; i < velicina_matrice_2; i++) {
				String brojevi[] = in.readLine().split(" ");
				for(int j = 0; j < velicina_matrice_2; j++)
					matrica2[i][j] = Integer.parseInt(brojevi[j]);
			}

			for(int i = 0; i < velicina_matrice_2; i++) {
				for(int j = 0; j < velicina_matrice_2; j++)
					System.out.print(matrica2[i][j] + " ");
				System.out.println();
			}

		} catch(IOException e) {
			e.printStackTrace();
		}

		if(velicina_matrice_1 != velicina_matrice_2) {
			sc.close();
			throw new MatrixMultiplicationException(new Error("Matrice su razlicitih dimenzija!"));
		}

		/* nece da radi ArrayList<ArrayList<Integer> > matrica = Collections.syncrhonizedList(new ArrayList<ArrayList<Integer> >());
		 * trazi da se kastuje, kad se kastuje i pokrene program podivlja i izbacuje raznorazne greske
		 * */
		ArrayList<ArrayList<Integer> > matrica =Collections.synchronizedList(new ArrayList<ArrayList<Integer> >());

		for(int i = 0; i < velicina_matrice_1; i++) {
			matrica.add(new ArrayList<Integer>());
			for(int j = 0; j < velicina_matrice_1; j++) {
				matrica.get(i).addAll(new ArrayList<Integer>());
				matrica.get(i).add(0);
			}
		}
		for(int i = 0; i < velicina_matrice_1; i++)
			for(int j = 0; j < velicina_matrice_1; j++) {
				Thread t = new Thread(new Niti(i, j, velicina_matrice_1, matrica, matrica1, matrica2));
				t.start();
			}
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* i ovde je matrica izracunata treba sacekati da sve niti */
		for(int i = 0; i < velicina_matrice_1; i++) {

			for(int j = 0; j < velicina_matrice_1; j++) {
				System.out.print(matrica.get(i).get(j));
			}
			System.out.println();
		}
		sc.close();
	}

}

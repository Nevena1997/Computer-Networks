package zad2;

import javax.management.RuntimeErrorException;

public class MatrixMultiplicationException extends RuntimeErrorException{

	public MatrixMultiplicationException(Error e) {
		super(e);
		// TODO Auto-generated constructor stub
	}

}

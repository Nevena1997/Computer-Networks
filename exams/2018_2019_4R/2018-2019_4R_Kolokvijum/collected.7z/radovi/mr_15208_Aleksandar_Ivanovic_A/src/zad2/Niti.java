package zad2;

import java.util.ArrayList;

public class Niti implements Runnable {
	int k;
	int l;
	int n;
	int m1[][];
	int m2[][];
	ArrayList<ArrayList<Integer>> matrica;
	public Niti(int k, int l, int n, ArrayList<ArrayList<Integer> > matrica, int m1[][], int m2[][]) {
		this.k = k;
		this.l = l;
		this.n = n;
		this.m1 = m1;
		this.m2 = m2;
		this.matrica = matrica;
	}
	@Override
	public void run() {
/* Ovo cese sigurno zavrsiti a matrica je vec postavljena na 0 tako da je poslednji deo zadatka ispuenjen xD
 * nece da radi syncrhonized ArrayList<ArrayList<Integer>>
 */
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				matrica.get(i).set(j,  m1[k][j] + m2[j][l]);
			}

		}

	}
	/* Sustinski neresni deo bismo resili tako sto bi imali while(true)
	 * u kom bi smo iznova racunali zbir i ispisvali ga sve bi bilo
	 * syncrhonized(matrica) :P
	 */

}

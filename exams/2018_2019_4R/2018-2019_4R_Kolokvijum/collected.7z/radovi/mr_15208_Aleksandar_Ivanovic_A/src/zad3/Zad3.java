package zad3;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zad3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String linija;
		while(sc.hasNext()) { /* Ovde se unos prekida sa ctrl+z */
			linija = sc.nextLine();
			try {
				URL url = new URL(linija);
				Pattern pattern1 = Pattern.compile("([0-9]+)[.]([0-9]+)[.]([0-9]+)[.]([0-9]+)"); /* Ima i srecnijih nacinada se ovo uradi ali samo hocemoda proverimo da li se javlja obrazac
				 																		 takodje za v6 slucaj pobunice se sama URL klasa u slucaju da nestane valja */
				Matcher matcher1 = pattern1.matcher(linija);
				if(matcher1.find()) {
					System.out.println("(v4)" + " " + url.getProtocol() + " " +
							url.getFile().substring(url.getFile().indexOf("/", 1), url.getFile().length()) + " [" + matcher1.group(1)  + " " + matcher1.group(2) + " " + matcher1.group(3) + " " + matcher1.group(4) +"]");
				} else /* Ovo je slucaj da u url nemamo ni ipv4 adresu ni ipv6 */
					System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getFile());
			} catch (MalformedURLException e) { /* baci ce sam izuzetak pa cemo samo da odstampamo poruku u catch delu */
				System.out.println("Url nije ispravan!");
			}
		}
		sc.close();
	}
	/* http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt */
	/**/

}

package mr14294_Mirjana_Jovanovic_B;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

// Skalarni proizvod vektora ( samo prva stavka)
public class Drugi {

	public static void main(String[] args) {
		Scanner skener = new Scanner(System.in);
		String fajl1 = skener.nextLine().trim();
		String fajl2 = skener.nextLine().trim();
        String v1 = null;
        String v2 = null;

		try {
		    FileInputStream  fin1 = new FileInputStream(fajl1);
	     	InputStreamReader sr1 = new InputStreamReader(fin1, "ASCII");
	     	BufferedReader br1 = new BufferedReader(sr1);

	     	FileInputStream fin2 = new FileInputStream(fajl2);
			  InputStreamReader sr2 = new InputStreamReader(fin2, "ASCII");
			  BufferedReader br2 = new BufferedReader(sr2);



			  String line = "";

			  while((line = br1.readLine()) != null){
				   v1 = line;


			  }

			  String line2 = "";
			  while((line2 = br2.readLine()) != null){
				   v2 = line2;
			     }


			  br1.close();
			  br2.close();

			  System.out.println("Prvi vektor:  "+ v1);
              System.out.println("Drugi vektor: " + v2);

              skener.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}









	}

}

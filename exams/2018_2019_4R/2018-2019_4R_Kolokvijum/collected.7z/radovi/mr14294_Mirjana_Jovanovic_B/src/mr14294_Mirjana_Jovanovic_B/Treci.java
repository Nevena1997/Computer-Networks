package mr14294_Mirjana_Jovanovic_B;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

// URL Scanner

public class Treci {

	public static void main(String[] args) {


     Scanner skener = new Scanner(System.in);


 // U beskonacnoj petlji unosimo url liniju po liniju i izvrsavamo zahteve zadatka.
// Program se prekida kada korisnik unese rec exit.

     while(true){

    	 System.out.println("Unesite zeljeni url. Za izlazak iz programa unesite exit. :) ");
    	 String linija = skener.nextLine().trim();

    	 if(linija.equalsIgnoreCase("exit"))
    		 break;

    	  //  Ispisujemo protokol, authority i putanju
    	  // Radi samo za url oblika : http://www.bg.ac.rs:3030/dir1/dir2/test.txt
    	 try {
			URL u = new URL(linija);

            System.out.println("Protokol:" + u.getProtocol());
            System.out.println("Authority: " + u.getAuthority());
            System.out.println("Putanja: " + u.getPath());

           // System.out.println("<KorisceniProtokol> <PodrazumevaniPort> <HostName> <PutanjaDoResursa>");

            System.out.print("Formatiran izlaz:   ");

            System.out.print(u.getProtocol() + "  " + u.getHost() + " " +  u.getDefaultPort() + " " + u.getPath() );

            System.out.println("\n\n");



             // Nisam uspela da izdvojim IP adresu iz URL-a pa sam isprobala funkcije na random IP adresi
             // verzija & ispis bajtova (v4) [123 123 123 123 ]



           InetAddress adresa = InetAddress.getByName("123.123.123.123");
            int verzija = getVersion(adresa);


            System.out.print("(v" + verzija + ")" );
            getBytes(adresa);


    	 } catch (MalformedURLException e) {
			System.err.println("URL NIJE VALIDAN!  ");


		} catch (IOException e) {


		}finally{


		}




     }


      skener.close();

	}



//Funkcija koja ispisuje bajtove adrese:
	private static void getBytes(InetAddress adresa) {

		byte[] addr = adresa.getAddress();

		System.out.print("[");

		for(int i = 0; i< addr.length ; i++){

			System.out.print(addr[i]+" ");
		}

		System.out.print("]");


	}

// Funkcija koja pronalazi verziju IP adrese: IPv4 || IPv6
	private static int getVersion(InetAddress adresa) {

		byte[] addr = adresa.getAddress();

		if(addr.length == 4){
			return 4;
		}
		if(addr.length == 16)
			return 6;


		return -1;

	}



}



//TESTER:   http:///123.123.123.123:80/dir1/dir2/test.txt


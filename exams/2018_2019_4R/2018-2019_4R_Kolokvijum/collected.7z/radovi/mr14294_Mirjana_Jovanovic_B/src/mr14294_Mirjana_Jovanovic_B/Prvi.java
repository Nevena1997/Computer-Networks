package mr14294_Mirjana_Jovanovic_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

// SELEKTIVNO KOPIRANJE FAJLA

public class Prvi {

	public static void main(String[] args) {

	  try {

		  Scanner skener = new Scanner(System.in);
		  String fajl = skener.nextLine().trim();


		  // Otvaramo fajl za citanje ukoliko takav fajl postoji

		  FileInputStream fin = new FileInputStream(fajl);
		  InputStreamReader sr = new InputStreamReader(fin);
		  BufferedReader br = new BufferedReader(sr);

		  // Otvaramo fajl za ispis
		  // Ukoliko ne postoji hex.txt nas program ce ga sam generisati :)
		  FileOutputStream fout = new FileOutputStream("hex.txt");
		  OutputStreamWriter sw = new OutputStreamWriter(fout, "ASCII");
		  BufferedWriter bw = new BufferedWriter(sw);

		  String line = "";

		  // Citamo liniju po liniju i proveravamo za svaku rec da li je validan heksadekadni broj.
		  while((line = br.readLine()) != null){


			  String[] niske = line.split(" ");

			  for(String niska: niske){

				if(isHeks(niska)){

					bw.write(niska +"\n");
				}




			  }





		  }



		  br.close();
		  bw.close();
          skener.close();


	} catch (FileNotFoundException e) {
		System.err.println("Pokusavate da otvorite nepostojeci fajl! FATAL ERROR! ");

	} catch (UnsupportedEncodingException e) {


	} catch (IOException e) {
        System.err.println("Problem sa ulazno-izlaznim operacijama! ");

	}finally{

	}


	}


// Funkcija za ispitivanje da li je broj heksadekadan.
	private static boolean isHeks(String niska) {

		if(niska.length() < 2)
			return false;


        if(niska.charAt(0) != '0' || niska.charAt(1) != 'x')
        	return false;

		for(int i = 2; i< niska.length(); i++){

                 if(niska.charAt(i)!= '0'
        		   && niska.charAt(i) != '1'
        		   && niska.charAt(i)!= '2'
        		   && niska.charAt(i)!= '3'
        		   && niska.charAt(i)!= '4'
        		   && niska.charAt(i)!= '5'
        		   && niska.charAt(i)!= '6'
        		   && niska.charAt(i)!= '7'
        		   && niska.charAt(i)!= '8'
        		   && niska.charAt(i)!= '9'
        		   && niska.charAt(i)!= 'A'
        		   && niska.charAt(i)!= 'B'
        		   && niska.charAt(i)!= 'C'
        		   && niska.charAt(i)!= 'D'
        		   && niska.charAt(i)!= 'F')
        	   return false;


		}





		return true;
	}

}

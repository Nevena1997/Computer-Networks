package mr13130_Tamara_Despotovic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String fajl=sc.next();
		//System.out.println(fajl);
		try{


		BufferedReader bfin=new BufferedReader(new InputStreamReader(new FileInputStream(fajl),"UTF-8"));
		BufferedWriter bfout=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));
		Scanner sc_in=new Scanner(bfin);
		String rec=sc_in.next();
System.out.println(rec);
		while(sc_in.hasNext()){
			System.out.println(rec);
			if(validna(rec)){
				try{
				bfout.write(rec);
				bfout.write("\n");
				}catch(IOException e){
					System.out.println("Nemoguce pisati u bfout" + bfout);
				}
			}

		}
		sc_in.close();
		try{
			bfin.close();
			bfout.close();
		}catch(IOException e){
			System.out.println("Nije moguce zatvoriti bfin i bfout");
			e.printStackTrace();
		}


		}catch(FileNotFoundException e){
			System.out.println("Nije pronadjen fajl");
			e.printStackTrace();

		}catch(UnsupportedEncodingException e){
			System.out.println("Nepoznata kodna shema");
			e.printStackTrace();
		}finally{
			sc.close();

		}
	}
private static boolean validna(String rec) {
	int duzina_reci=rec.length();
	if(!Character.isUpperCase(rec.charAt(0)))
		return false;
	for(int i=0;i<rec.length();i++){

		if(Character.isDigit(rec.charAt(i)))
			return false;
		}
	for(int i=1;i<duzina_reci;i++){
		if(!Character.isLowerCase(rec.charAt(i)))
			return false;
	}

return true;
}








}


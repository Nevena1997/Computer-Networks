package mr13130_Tamara_Despotovic_A;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Treci {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String file=sc.next();
		System.out.println(file);
		try{
			//URL url=new URL("http://" +file);
			//URL url=new URL(file);
			//URLConnection url_conn=url.openConnection();
			//InputStream stranica=url_conn.getInputStream();
			//System.out.println(url);

			//Scanner sc_strana=new Scanner(stranica);
			Scanner sc_strana=new Scanner(file);
			while(sc_strana.hasNext()){
				String linija=sc_strana.nextLine();
				String[] delovi = linija.split(":");


				String ip=ip_adresa(delovi[1]);
			URL url=new URL(linija);
			System.out.println(url);
				if(ip != null){
					System.out.println(ip + " " + url.getProtocol() + " " + url.getPath());
				}else{
					 System.out.println(delovi[0] + " " + delovi[1] + " " + delovi[2]);
						//System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath().getBytes());
					}



			}



		}catch(IOException e){
			System.out.println("Nemoguce otvoriti fajl na ovoj adresi ili konekcija");
			e.printStackTrace();
		}
		sc.close();
	}
	private static String ip_adresa(String string){
		if(string.contains("."))
			return "(v4)";
		if(string.contains(":"))
			return "(v6)";
			return null;
	}

}

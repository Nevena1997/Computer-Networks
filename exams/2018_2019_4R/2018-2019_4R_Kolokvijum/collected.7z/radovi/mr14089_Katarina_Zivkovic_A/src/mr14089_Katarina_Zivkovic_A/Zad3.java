package mr14089_Katarina_Zivkovic_A;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Pretraga pocinje za izlaz iz pretrage unesite: exit");
		String line = sc.nextLine();
		if(!line.equalsIgnoreCase("exit"))
			ucitaj(line,sc);
		
		sc.close();

	}

	private static void ucitaj(String line, Scanner sc) {
		// TODO Auto-generated method stub
			try {
				URL u = new URL(line);
				System.out.printf("%s %s %s\r\n", u.getProtocol(),u.getAuthority(),u.getPath());
				
				String version = u.getAuthority();
				String ip = version.substring(0, version.lastIndexOf(":"));
				System.out.printf("%s\r\n",ip);
				
				InetAddress ia = InetAddress.getByName(ip);
				byte[] adresa = ia.getAddress();
				if(adresa.length == 4){
					System.out.printf("(v4) %s %s ", u.getProtocol(),u.getPath());
					stampajbajtove(adresa);
				}
				if(adresa.length == 16)
					System.out.printf("(v6) %s %s ", u.getProtocol(),u.getPath());
				
				
				System.out.println("Novi unos");
				line = sc.nextLine();
				if(!line.equalsIgnoreCase("exit"))
					ucitaj(line,sc);
				else return;
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				System.out.printf("%s NOT SUPPORTED\r\n",line);
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	private static void stampajbajtove(byte[] adresa) {
		// TODO Auto-generated method stub
		System.out.print("[");
		for(int i=0;i<adresa.length;i++)
			if (adresa[i]<0)
				adresa[i] = (byte) (adresa[i]+256);
			else
				adresa[i] = adresa[i];
		for(int i=0;i<adresa.length;i++)
			if(i!=adresa.length-1)
				System.out.printf("%d ", adresa[i]);
			else
				System.out.printf("%d]", adresa[i]);
		System.out.println();
		
	}

}

package mr14089_Katarina_Zivkovic_A;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Zad2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite putanju do prvog fajla");
		String fajl1 = sc.nextLine();
		System.out.println("Unesite putanju do drugog fajla");
		String fajl2 = sc.nextLine();
		sc.close();
		try(InputStreamReader prva = new InputStreamReader(new FileInputStream(fajl1));
				InputStreamReader druga = new InputStreamReader(new FileInputStream(fajl2));) {
			
			int c = prva.read();
			char n = (char) c;
			while((c = prva.read())!=-1)
				System.out.print((char) c);
			System.out.println();
			int d = druga.read();
			char m = (char) d; 
			while((d = druga.read())!=-1)
				System.out.print((char) d);
			MatrixMultiplicationException nova = new MatrixMultiplicationException(n,m);
			for(int i = 0;i<Character.getNumericValue(n);i++)
				for(int j = 0;j<Character.getNumericValue(n);j++)
				new Thread(new Mnozi(i,j,fajl1,fajl2)).start();
				
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

}

package mr14089_Katarina_Zivkovic_A;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class Mnozi implements Runnable {

	private int i;
	private int j;
	private String f1;
	private String f2;
	private int[] prvi;
	private int[] drugi;
	private int[] rez;
	private int n;
	private int kon;
	private int globalni;
	
	public Mnozi(int i,int j, String fajl1, String fajl2){
		this.i = i;
		this.j = j;
		this.f1 = fajl1;
		this.f2 = fajl2;
	}
	
	public void run(){
		procitaj(f1,f2);
		pomnozi();
		saberi();
		ispisi();
		globalnizbir();
	}

	private void globalnizbir() {
		// TODO Auto-generated method stub
		globalni+=kon;
	}

	private void ispisi() {
		// TODO Auto-generated method stub
		System.out.print(kon);
	}

	private void saberi() {
		// TODO Auto-generated method stub
		this.kon = 0;
		for(int k = 0;i<this.n;i++)
			kon += rez[k];
	}

	private void pomnozi() {
		// TODO Auto-generated method stub
		for(int k = 0;i<this.n;i++)
			rez[k] = prvi[k]*drugi[k];
	}

	private void procitaj(String f12, String f22) {
		// TODO Auto-generated method stub
		
		try {
			InputStreamReader prva = new InputStreamReader(new FileInputStream(f1));
			InputStreamReader druga = new InputStreamReader(new FileInputStream(f2));
			int c = prva.read();
			char n = (char) c;
			this.n=Character.getNumericValue(n);
			for(int k = 0;k<Character.getNumericValue(n);k++){
				if(i == k){
					int b = 0;
					while(b<Character.getNumericValue(n)){
						c = prva.read();
						prvi[b] = Character.getNumericValue((char) c);
						b++;
					}
				}
					
			}
			int m = 0;
			for(int l = 0;l<Character.getNumericValue(n);l++){
				for(int k = 0;k<Character.getNumericValue(n);k++){
					if(k == j){
						c = prva.read();
						drugi[m] = Character.getNumericValue((char) c);
						m++;
					}
				}
					
			}
			prva.close();
			druga.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
}

package mr14089_Katarina_Zivkovic_A;

public class MatrixMultiplicationException {

	private char n;
	private char m;
	
	public MatrixMultiplicationException(char n,char m){
		if(n!=m)
			System.err.println("Greska");
		else{
			this.n = n;
			this.m = m;
		}
		this.printStackTrace();
	}

	private static void printStackTrace() {
		// TODO Auto-generated method stub
		
	}
	
}

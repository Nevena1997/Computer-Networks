package mr14089_Katarina_Zivkovic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Zad1 {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite fajl");
		String fajl = sc.nextLine();
		sc.close();
		
		try(Scanner in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(fajl),"UTF-8")));
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));) {
			while(in.hasNext()){
				String line = in.next();
				if(isName(line)){
					out.write(line);
					out.newLine();
				}
			}
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			System.err.println("UnsupportedEncodingException");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("FileNotFoundException");
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.err.println("IOException");
			e1.printStackTrace();
		}
		
		
	}

	private static boolean isName(String line) {
		// TODO Auto-generated method stub
		if(!Character.isUpperCase(line.charAt(0)))
			return false;
		for(int i=1;i<line.length();i++){
			if(!Character.isLowerCase(line.charAt(i)))
				return false;
			if(Character.isDigit(line.charAt(i)))
				return false;
		}
		return true;
	}
	
}

package paket;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Zad3 {

	public static void main(String[] args)
	{

		Scanner sc = new Scanner(System.in);


		String ulaz = sc.next();
		sc.close();

		try {
			URL u = new URL(ulaz);

			System.out.println(u.getProtocol() + " " + u.getDefaultPort() + " " + u.getHost() + " " + u.getPath());

			String niz[] = ulaz.split("/");


			if(niz[2].chars().allMatch(c -> (Character.isDigit(c) || c == '.')))
			{
				InetAddress id = InetAddress.getByName(niz[2]);

				byte[] b = id.getAddress();
				if(b.length == 4)
					System.out.println("v4");
				if(b.length == 6)
					System.out.println("v6");

				System.out.println(" " + u.getProtocol() + " " + u.getPort() + " " + u.getPath());
				System.out.print("[");
				for(int i=0; i<b.length; i++)
					System.out.print(b[i]);
				System.out.print("]");
			}

			if(niz[2].chars().allMatch(c -> (Character.isDigit(c) || c == ':')))
			{
				InetAddress id = InetAddress.getByName(niz[2]);

				byte[] b = id.getAddress();
				if(b.length == 4)
					System.out.println("v4");
				if(b.length == 6)
					System.out.println("v6");

				System.out.println(" " + u.getProtocol() + " " + u.getPort() + " " + u.getPath());
				System.out.print("[");
				for(int i=0; i<b.length; i++)
					System.out.print(b[i]);
				System.out.print("]");
			}





		} catch (MalformedURLException e) {

			System.out.println("URL nije validan!");
			e.printStackTrace();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}

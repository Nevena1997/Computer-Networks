package paket;

public class VectorMultiplicationException extends Throwable {


}

package paket;

import java.util.LinkedList;
import java.util.List;
import java.util.Vector;



public class Nit implements Runnable {

	private List<String> vector1;
	private List<String> vector2;


	public Nit(List<String> vector1, List<String> vector2) {
		this.vector1 = vector1;
		this.vector2 = vector2;
	}

	int r;

	@Override
	public synchronized void run() {

		while(true)
		{
			if(this.vector1.size() < 1)
				break;
			if(this.vector2.size() < 1)
				break;

			int a = Integer.valueOf(this.vector1.remove(0));
			int b = Integer.valueOf(this.vector2.remove(0));

			r = a*b;


			System.out.print(r);
		}

		try {
			
			Thread.sleep((long) Math.random() * 50);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}

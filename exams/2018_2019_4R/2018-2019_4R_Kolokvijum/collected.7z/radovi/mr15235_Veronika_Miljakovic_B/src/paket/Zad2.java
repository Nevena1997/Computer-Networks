package paket;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Zad2 {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String putanja1 = sc.next();
		String putanja2 = sc.next();
		List<String> v1 = Collections.synchronizedList(new LinkedList<String>());
		List<String> v2 = Collections.synchronizedList(new LinkedList<String>());





		try {
			Scanner in1 =new Scanner( new BufferedReader(new InputStreamReader(new FileInputStream(putanja1))));
			Scanner in2 =new Scanner( new BufferedReader(new InputStreamReader(new FileInputStream(putanja2))));

			int n1 = in1.nextInt();
			for(int i=0; i<n1; i++)
			{
				int broj = in1.nextInt();
				System.out.print(broj);
				String b = Integer.toString(broj);
				v1.add(b);


			}

			int n2 = in2.nextInt();

			for(int i=0; i<n2; i++)
			{
				int broj = in2.nextInt();
				System.out.print(broj);
				String b = Integer.toString(broj);
				v2.add(b);

			}


			if(n1!= n2)
			{ 
				throw new VectorMultiplicationException();

			}
			if(n1 == n2)
			{
			System.out.print("[");
			for(int i=0; i<n1; i++)
				new Thread(new Nit(v1, v2));

			}
			System.out.print("]");



		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}





	}

}

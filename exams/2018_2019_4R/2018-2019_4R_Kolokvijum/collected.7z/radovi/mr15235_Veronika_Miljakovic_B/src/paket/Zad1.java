package paket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.util.Scanner;

public class Zad1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String ime_putanje = sc.next();

		sc.close();

		Scanner in = null;
		BufferedWriter out = null;
		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(ime_putanje), "ASCII")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));

			String niska;

			while(in.hasNext())
			{
				niska = in.next();

				if(niska.charAt(0) != '0')
					continue;

				if(niska.charAt(1) != 'x')
					continue;

				String niska1 = niska.substring(2, niska.length());

				if(niska1.chars().anyMatch(c -> (!Character.isLetter(c) & !Character.isDigit(c))))
						continue;

				int brojac = 0;
				char[] c = niska1.toCharArray();
				for(int i=0; i<c.length; i++)
				{	if(Character.toLowerCase(c[i]) > 'f');
						brojac = 1;
					System.out.println("" + c[i] + " " + (c[i] > 'f'));
				}

				if(brojac == 1)
					continue;

				out.write(niska);
				out.newLine();
			}

			in.close();
			out.close();

			System.out.println("Done!");

		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(in != null)
				in.close();
			if(out!=null)
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}


	}

}

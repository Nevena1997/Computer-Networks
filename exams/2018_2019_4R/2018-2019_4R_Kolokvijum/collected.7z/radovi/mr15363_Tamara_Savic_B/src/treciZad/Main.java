package treciZad;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		while(sc.hasNextLine()){
			String u = sc.nextLine();

			if(u.equalsIgnoreCase("exit") || u.equalsIgnoreCase("quit"))
				break;

			try {

				URL url = new URL(u);

				if(!isHostName(url.getHost())){

					InetAddress address = InetAddress.getByName(url.getHost());

					System.out.print("(v" + verzija(address) + ") " + url.getProtocol() + " ");

					if(url.getPort() != -1)
						System.out.print(url.getPort() + " ");

					System.out.print(url.getPath() + " ");

					if(verzija(address) == 4){
						System.out.print("[");

						byte[] add = address.getAddress();

						for(int i = 0; i < add.length; i++){
							int unsignedByte = add[i] < 0 ? add[i] + 256 : add[i];
							System.out.print(unsignedByte);
							if(i != 3)
								System.out.print(" ");
						}

						System.out.print("]");
					}

					System.out.println();
					}

				else
					System.out.println(url.getProtocol() + " " + url.getDefaultPort() + " " + url.getHost() + " " + url.getPath());

			} catch (MalformedURLException e) {
				System.out.println("Neispravan URL.");
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		}

		sc.close();

	}

	private static int verzija(InetAddress address) {
		byte[] add = address.getAddress();

		if(add.length == 4)
			return 4;
		else
			return 6;

	}

	private static boolean isHostName(String host) {

		if(host.indexOf(":") != -1)
			return false;

		return host.chars().anyMatch(c -> !Character.isDigit(c) && c != '.');
	}

}

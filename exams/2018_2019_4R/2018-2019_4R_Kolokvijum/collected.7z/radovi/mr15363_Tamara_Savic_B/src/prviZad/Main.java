package prviZad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file))));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));

			String word;
			while(in.hasNext()){
				word = in.next();

				if(isHex(word)){
					out.write(word);
					out.newLine();
				}
			}

			System.out.println("Done!");


		} catch (FileNotFoundException e) {
			System.err.println("Nepostojeci file: " + file);
		} catch (IOException e) {
			System.err.println("Neuspesno pisanje u izlazni file.");
		} finally {
			try {
				if(in != null)
					in.close();
				if(out != null){
					out.flush();
					out.close();
				}
				} catch (IOException e) {
					System.err.println("Neuspesno zatvaranje tokova.");
			}
		}
	}



	private static boolean isHex(String word) {

		if(word.charAt(0) != '0' || word.charAt(1) != 'x')
			return false;

		for(int i = 2; i < word.length(); i++)
			if(!Character.isDigit(word.charAt(i)) && !(Character.toLowerCase(word.charAt(i)) >= 'a' && Character.toLowerCase(word.charAt(i)) <= 'f'))
				return false;

		return true;
	}

}

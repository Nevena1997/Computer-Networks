package drugiZad;

@SuppressWarnings("serial")
public class VectorMultiplicationException extends Exception {

}

package drugiZad;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file1 = sc.nextLine();
		String file2 = sc.nextLine();
		sc.close();

		BufferedReader in1 = null;
		BufferedReader in2 = null;

		try {
			in1 = new BufferedReader(new InputStreamReader(new FileInputStream(file1)));
			in2 = new BufferedReader(new InputStreamReader(new FileInputStream(file2)));

			int n1 = Integer.valueOf(in1.readLine());
			int n2 = Integer.valueOf(in2.readLine());

			if(n1 != n2)
				throw new VectorMultiplicationException();

			int[] vektor1 = new int[n1];
			int[] vektor2 = new int[n2];

			String broj;
			int i = 0;
			while((broj = in1.readLine()) != null){
				vektor1[i] = Integer.valueOf(broj);
				i++;
			}

			i = 0;
			while((broj = in2.readLine()) != null){
				vektor2[i] = Integer.valueOf(broj);
				i++;
			}

			System.out.println("Prvi vektor:");
			for(i = 0; i < n1; i++)
				System.out.print(vektor1[i] + " ");
			System.out.println();

			System.out.println("Drugi vektor:");
			for(i = 0; i < n2; i++)
				System.out.print(vektor2[i] + " ");
			System.out.println();

			for(i = 0; i < n1; i++)
				new Thread(new Nit(vektor1, vektor2, i)).start();

			Thread.sleep(1000);

			System.out.println(Nit.L1);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (VectorMultiplicationException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			try {
				if(in1 != null)
					in1.close();
				if(in2 != null)
					in2.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}

}

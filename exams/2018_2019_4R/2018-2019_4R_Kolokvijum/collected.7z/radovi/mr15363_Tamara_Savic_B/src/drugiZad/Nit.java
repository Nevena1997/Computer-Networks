package drugiZad;

public class Nit implements Runnable {

	private int[] vektor1;
	private int[] vektor2;
	private int indeks;
	public static int L1 = 0;

	public Nit(int[] vektor1, int[] vektor2, int indeks){
		this.vektor1 = vektor1;
		this.vektor2 = vektor2;
		this.indeks = indeks;
	}

	@Override
	public synchronized void run() {

		L1 += vektor1[indeks] * vektor2[indeks];

	}

}

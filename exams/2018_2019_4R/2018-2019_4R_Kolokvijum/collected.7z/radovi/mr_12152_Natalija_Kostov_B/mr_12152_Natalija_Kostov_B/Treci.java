package mr_12152_Natalija_Kostov_B;


import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Treci {
	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		try {
			while(sc.hasNextLine()){
				String page= sc.nextLine();
				URL url = new URL(page);
				if(isHostname(url.getHost()))
					System.out.println(url.getProtocol() + " " + url.getDefaultPort() + " "
												+ url.getHost() + " " + url.getPath());
				else{
					String host = url.getHost();
					InetAddress addr= InetAddress.getByName(host);
					byte[] address = addr.getAddress();
					if(getVersion(url.getHost())==4){
						System.out.print("(v" + getVersion(host) + ") " + url.getProtocol() + " "
												+ url.getDefaultPort()  + " " + url.getPath() + " [");
						for(int i=0;i<address.length;i++)
							System.out.print(address[i]<0? address[i]+256 : address[i] + " ");
						System.out.print("]");
						System.out.println();
						}
					else if(getVersion(url.getHost())==6)
						System.out.println("(v" + getVersion(host) + ") " + url.getProtocol() + " "
												+ url.getDefaultPort()  + " " + url.getPath());



				}
			}
		} catch (MalformedURLException e) {
			System.err.println("Nije validan url");
			sc.close();
		}
		catch (UnknownHostException e) {
			System.err.println("Nepoznat host");
			sc.close();
		}
		sc.close();

	}

	private static int getVersion(String host) throws UnknownHostException{
		InetAddress addr;
		addr=InetAddress.getByName(host);
		byte[] address = addr.getAddress();
		if(address.length == 4)
			return 4;
		else if(address.length == 16)
			return 6;
		else
			return -1;
	}

	private static boolean isHostname(String host){
		if(host.indexOf(':')!= -1)
			return false;
		else
			return host.chars().anyMatch(c-> !Character.isDigit(c) && c!='.');
	}

}

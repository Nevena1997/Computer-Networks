package mr_12152_Natalija_Kostov_B;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Prvi {
	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);

		System.out.println("Unesite ime fajla");
		String filename= sc.nextLine();

		sc.close();
		try{
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(filename));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream("C:\\Users\\nalog\\Desktop\\mr_12152_Natalija_Kostov_B\\hex.txt"),"ASCII"));
			Scanner s = new Scanner(in);
			while(s.hasNext()){
				String rec=s.next();
				if(rec.startsWith("0x")){
					out.write(rec.charAt(0));
					out.write(rec.charAt(1));
					for(int i=2;i<rec.length();i++){
						if(Character.isDigit(rec.charAt(i)) || rec.charAt(i)=='a' || rec.charAt(i)=='b' || rec.charAt(i)=='c'
								|| rec.charAt(i)=='d' || rec.charAt(i)=='e' || rec.charAt(i)=='f'
								|| rec.charAt(i)=='A' || rec.charAt(i)=='A' || rec.charAt(i)=='C'
								|| rec.charAt(i)=='D' || rec.charAt(i)=='E' || rec.charAt(i)=='F')
						out.write(rec.charAt(i));
					}
					out.newLine();

				}

			}
			in.close();
			out.close();
			s.close();
			System.out.println("Done (:");
		}catch(FileNotFoundException e){
			System.err.println("Fajl ne postoji");
		}
		catch(IOException e){
			System.err.println("Kraj ulaza");
		}
	}

}

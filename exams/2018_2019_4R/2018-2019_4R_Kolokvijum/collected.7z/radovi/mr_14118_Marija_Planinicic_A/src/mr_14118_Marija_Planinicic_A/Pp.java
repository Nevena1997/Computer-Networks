package mr_14118_Marija_Planinicic_A;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Pp implements Runnable {

	private String file;
	private int nn;
	private static int zbir;

	public Pp(String file, int nn) {
		// TODO Auto-generated constructor stub
		this.file=file;
		this.nn=nn;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
      //otvori fajl procit
     //imas i tamo isto ovo???
	  try {
		Scanner sc=new Scanner(new FileInputStream(file));
		  //citam sadrzaj, prva lin 1 2 3
		  while(sc.hasNext()){
			  String line=sc.nextLine();
			  String[] red=line.split(" ");
			  synchronized(file) {
			 for(int i=0;i<line.length();i++){
				// red[i]*=i;
			 }
			  }
			  System.out.println("aa " + line);


		  }
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}


}

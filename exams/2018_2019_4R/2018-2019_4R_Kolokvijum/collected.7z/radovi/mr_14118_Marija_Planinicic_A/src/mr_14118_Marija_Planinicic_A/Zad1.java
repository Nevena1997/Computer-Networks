package mr_14118_Marija_Planinicic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Zad1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc=new Scanner(System.in);
		System.out.println("unesite ime fajla");
		String file=sc.nextLine();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8")));
			out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));

			while(in.hasNext()){
				String line=in.nextLine();
				if(isvalid(line)){
					out.write(line);
					out.newLine();
				}


			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if (in!=null)
					in.close();
				if(out!=null)
					out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}


	}

	private static boolean isvalid(String line) {
		// TODO Auto-generated method stub
		//return false;
		//ako mi svaka linija sadrzi ime i prez npr: Jelena Jelic
		//                                           Marko Markovic
		//                                           Sanja Anic

		String regex="^[A-Z][a-z]+ $";
		Pattern pat=Pattern.compile(regex);
		return pat.matcher(line).matches();

	}

}

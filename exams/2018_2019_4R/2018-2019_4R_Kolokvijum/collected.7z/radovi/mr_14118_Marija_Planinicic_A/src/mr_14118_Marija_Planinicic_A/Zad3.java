package mr_14118_Marija_Planinicic_A;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zad3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //http://www.matf.bg.ac.rs
	 // http:///123.123.123.123
		Scanner sc=new Scanner(System.in);
		try{
      //sc=new Scanner(System.in);
      System.out.println("Unesite url");
      String u1=null;
      while(sc.hasNext()){
       System.out.println("Unesite url");
       u1=sc.nextLine();

		URL u=new URL(u1);


		  //System.out.println(u.getProtocol() +" "+ u.getAuthority() + " " + u.getPath());


		  //ako se unese v4     vidi sa // ova 2 ili 3     {1,3}-da mora bar 1 sam stavila
	      String line="^[a-z]+:///?([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}).$";
	      Pattern pat=Pattern.compile(line.trim());
	      Matcher m=pat.matcher(u1);
	      //String aa=m.group();
	      if (m.find()){
	    	  String adresa=m.group(1).trim();
	    	  InetAddress ad1=InetAddress.getByName(adresa);
	    	  //InetAddress ad=InetAddress.getByAddress(m.group(1), null);
	    	  //ad1.getAddress()
	    	  //System.out.println("aaaaa " +ad1);
	    	  System.out.println("(v4)  " + u.getProtocol() + u.getPath() +  " " +ad1);
	    	 // System.out.println("v4"); // + u.getProtocol() + u.getPath());
	      }

	      //ako je v6:  1243:123E:....8 puta, stavila sam samo velika slova
	      //vidi posle dal je dobro ovaj regex ///
	      String line1="^[a-z]+:///?([0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}:[0-9A-Z]{0,4}).$";
	      Pattern pat1=Pattern.compile(line1);
	      Matcher m1=pat1.matcher(u1);
	      if(m1.find()){
            if(m1.group(1)!=null){
	    	  System.out.println("(v6) "+ u.getProtocol() + u.getPath() );
            }
	      }




      }
	} catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (UnknownHostException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		sc.close();
	}


	}

}

package mr_14118_Marija_Planinicic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Zad2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 try {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
		System.out.println("unesite ime fajla");
		String file=sc.nextLine();

        Scanner aa=new Scanner(new FileInputStream(file));
        int n=aa.nextInt();

			Scanner in=new Scanner(new InputStreamReader(new FileInputStream(file)));
			while(in.hasNext()){
				String line=in.nextLine();
				System.out.println(line);


			}
			//int n;
			//koja je dimenzija , pise u fajlu prva linija
			 int nn=n*n;
			 for(int i=0;i<nn;i++){
				 //fajl, broj niti
				 Thread t=new Thread(new Pp(file,nn));
				 t.start();

			 }

		}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}


		 //zatvori sc i in
	}

}

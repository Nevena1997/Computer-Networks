package paketic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class CopyFile {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in);
				BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(sc.nextLine())));
				BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));){


			String line;
			String[] st;
			while((line = in.readLine()) != null){
				st = line.split(" ");

				for(int i=0;i<st.length;i++){
					if(st[i].matches("0x[a-f0-9A-F]{6}"))
						out.write(st[i]+"\r\n");
				}

			}

			sc.close();
			in.close();
			out.close();

		}catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("File is not found!");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			System.out.println("Unsupported encoding!");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IO exception!");
		}
	}

}

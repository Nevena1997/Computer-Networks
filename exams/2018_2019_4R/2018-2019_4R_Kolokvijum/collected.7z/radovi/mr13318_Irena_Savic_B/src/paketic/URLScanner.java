package paketic;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class URLScanner {


	public static void main(String[] args) {


		try (Scanner sc = new Scanner(System.in);){


			String u = sc.nextLine();
			String port = "";

			URL url = new URL(u);

			System.out.println(url.getProtocol() + " " + url.getHost()+ " " + url.getDefaultPort() + " " + url.getPath());


			InetAddress address = InetAddress.getByName(url.getHost());
			byte[] bytes = address.getAddress();



			if(url.getPort() != -1)
				port = url.getPort() + "";

			if(bytes.length == 4)
				System.out.println("(v4) " + url.getProtocol() + " " + port + " " + url.getPath());

			if(bytes.length == 16)
				System.out.println("(v6) " + url.getProtocol() + " " + port + " " + url.getPath());

			sc.close();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}


	}


}

package zad03;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		
		while(sc.hasNext()){
			try {
				String urltext=sc.nextLine();
				URL url=new URL(urltext);
				if(!isIpAddress(url))
				System.out.println(url.getProtocol()+" "+url.getDefaultPort()+" "+url.getHost()+" "+url.getPath());
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				System.out.println("URL nije validan");
			}
		}
		
		sc.close();
	}

	private static boolean isIpAddress(URL url) {
		String host=url.getHost();
		if(host.split(":").length>2){
			System.out.println("(v6) "+url.getProtocol()+" "+url.getPath());
			return true;
			}
		String []address=host.split("\\.");
		for(int i=0;i<address.length;i++){
			for(char c:address[i].toCharArray())
			if(!(Character.isDigit(c) || c==':'))
				return false;
		}
		int port=url.getPort();
		if(port==-1){
			System.out.println("(v4) "+ url.getProtocol()+" "+url.getPath()+" ["+address[0]+" "+address[1]+" "+address[2]+" "+address[3]+"]");
		}else{
			System.out.println("(v4) "+ url.getProtocol()+" "+url.getPort()+" "+url.getPath()+" ["+address[0]+" "+address[1]+" "+address[2]+" "+address[3]+"]");	
		}
		return true;
	}

}

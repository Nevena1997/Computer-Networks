package zad02;

public class Proizvod implements Runnable{

	public static Indeks ind;
	public static Indeks norm1;
	public static Indeks norm2;
	private int []a;
	private int []b;

	public Proizvod(int []a,int []b){
		this.a=a;
		this.b=b;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		int i;
		synchronized (ind) {
			i=ind.getI();
			if(i>ind.getN())
				return;
			ind.setI(i+1);
		}
		int p=a[i]*b[i];
		synchronized (norm1) {
			norm1.setP(norm1.getP()+a[i]);
		}
		synchronized (norm2) {
			norm2.setP(norm2.getP()+b[i]);
		}
		synchronized (ind) {
			ind.setP(ind.getP()+p);
		}
	}

}

package zad02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws VectorMultiplicationException {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		String file1=sc.next();
		String file2=sc.next();
		sc.close();
		Scanner v1=null;
		Scanner v2=null;
		
		int []a=new int[0];
		int []b=new int[0];
		int n1=0;
		int n2=0;
		
		try {
			v1=new Scanner(new FileInputStream(file1));
			v2=new Scanner(new FileInputStream(file2));
			n1=v1.nextInt();
			a=new int[n1];
			for(int i=0;i<n1;i++){
				a[i]=v1.nextInt();
				System.out.print(a[i]+" ");
			}
			System.out.println();
			n2=v2.nextInt();
			b=new int[n2];
			for(int i=0;i<n2;i++){
				b[i]=v2.nextInt();
				System.out.print(b[i]+" ");
			}

			System.out.println();
			if(n1!=n2)
				throw new VectorMultiplicationException();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(v1!=null)
				v1.close();
			if(v2!=null)
				v2.close();
		}
		Proizvod.ind=new Indeks(n1);
		Proizvod.norm1=new Indeks(n1);
		Proizvod.norm2=new Indeks(n2);
		Thread []t=new Thread[n1];
		for(int i=0;i<n1;i++){
			t[i]=new Thread(new Proizvod(a,b));
			t[i].start();
		}
		for(int i=0;i<n1;i++){
			try {
				t[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		System.out.println("Proizvod je: "+Proizvod.ind.getP());
		System.out.println("Norma prvog vektora je "+Proizvod.norm1.getP());
		System.out.println("Norma drugog vektora je "+Proizvod.norm2.getP());

	}

}

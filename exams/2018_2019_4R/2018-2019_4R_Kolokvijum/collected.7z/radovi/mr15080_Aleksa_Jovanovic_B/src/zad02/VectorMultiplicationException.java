package zad02;

public class VectorMultiplicationException extends Throwable {

}

package zad02;

public class Indeks {

	private int i;
	private int n;
	private int p;
	public Indeks(int n){
		this.i=0;
		this.n=n;
		this.p=0;
	}
	public int getN() {
		return n;
	}
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
}

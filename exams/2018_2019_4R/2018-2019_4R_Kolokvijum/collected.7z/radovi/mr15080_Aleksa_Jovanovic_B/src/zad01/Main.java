package zad01;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String file=sc.next();
		sc.close();
		
		FileInputStream input=null;
		BufferedWriter output=null;
		Scanner in=null;
		try {
			input=new FileInputStream(file);
			output=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));
			in = new Scanner(input);
			while(in.hasNext()){
			
				String word=in.next();
				if(isHex(word)){
					output.write(word);
					output.newLine();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

			System.out.println("Neuspesno otvaranje fajla");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			System.out.println("Nije podrzan format ASCII");
		} catch (IOException e) {
			// TODO Auto-generated catch block

			System.out.println("Neuspesno pisanje ili citanje iz fajla");
		}finally {
		

			if(in!=null){
			in.close();}
			if(output!=null){
			try {
				output.flush();
				output.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Neuspesno zatvaranje output.txt fajla");
			}
			}
			
		}
		
		

	}
	
	private static boolean isHex(String word){
		if(word.charAt(0)!='0')
			return false;
		if(word.charAt(1)!='x' && word.charAt(1)!='X')
			return false;
		for(int i=2;i<word.length();i++){
			char c=word.charAt(i);
			if(!Character.isDigit(c) && !((c>='a' && c<='f') || (c>='A' && c<='F')))
				return false;
		}
		
		return true;
	}

}

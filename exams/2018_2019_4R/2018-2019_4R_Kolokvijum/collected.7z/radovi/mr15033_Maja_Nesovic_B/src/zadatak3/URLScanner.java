package zadatak3;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class URLScanner {

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		URL u;
		String baseUrl;

		try {

			while(sc.hasNext()){

				baseUrl = sc.next();
				u = new URL(baseUrl);

				System.out.print(u.getProtocol() + " " + u.getAuthority() + " " + u.getDefaultPort() + " " + u.getHost() + " " + u.getPath());
				System.out.println();
			}

		} catch (MalformedURLException e) {
				System.err.println("Not valid URL...");
		} finally{
			sc.close();
		}

	}


}


package zadatak1;

import java.io.IOException;
//import java.io.InputStreamReader;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class Main {

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();

		//BufferedReader in = null;
		BufferedWriter out = null;

		try{
			sc = new Scanner(new BufferedInputStream(new FileInputStream(file)));
			//in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("mr15033_Maja_Nesovic_B/hex.txt"), "ASCII"));

			String hexNum;
			while(sc.hasNext()){
				hexNum = sc.next();

				if(isHexNum(hexNum)){
					out.write(hexNum);
					out.newLine();
				}

			}

		}catch(UnsupportedEncodingException e){
			System.err.println("Broken VM...");
		}catch(FileNotFoundException e){
			System.err.println("File not found...");
		}catch(IOException e){
			System.err.println("Cannot write ...");
		}finally{

			try{
				sc.close();
				if(out != null){
					out.flush();
					out.close();
				}
			}catch(IOException ex){
				System.err.println("Cannot close stream...");
			}
		}
	}

	public static boolean isHexNum (String s) {

		if(s.length() < 2)
			return false;
		if(!s.startsWith("Ox"))
			return false;

		for(int i=0; i<s.length(); i++){
			if(!Character.isDigit(s.charAt(i)) && s.charAt(i)!='a' && s.charAt(i)!='A' && s.charAt(i)!='b' && s.charAt(i)!='B' && s.charAt(i)!='c' && s.charAt(i)!='C' && s.charAt(i)!='d' && s.charAt(i)!='D' && s.charAt(i)!='e' && s.charAt(i)!='E' && s.charAt(i)!='f' && s.charAt(i)!='F')
				return false;
		}

		return true;


	}

}

package zadatak2;

public class VMTest implements Runnable {


	private VectorMultiplication vm_test;
	private int i;
	private int MAX = 500;
	public VMTest(VectorMultiplication vm, int i){
		this.vm_test = vm;
		this.i = i;
	}

	@Override
	public void run(){

		try{
			vm_test.proizvod(i);
			Thread.currentThread().sleep((int)(Math.random()*MAX));
		} catch(InterruptedException e){
			e.printStackTrace();
		}
	}

}

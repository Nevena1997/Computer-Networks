package zadatak2;

import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.util.Scanner;

public class Main {

	public static void main(){

		Scanner sc = new Scanner(System.in);
		VectorMultiplication vm;
		String p1, p2;
		int[] a;
		int[] b;
		int n;

		sc.close();
	}

}


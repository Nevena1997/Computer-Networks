package zadatak2;

import java.util.Arrays;

public class VectorMultiplication {

	private final int[] x;
	private final int[] y;
	private final int[] result;
	private int l1_norm;

	public VectorMultiplication(int n, int[] a, int[] b){

		this.x = new int[n];
		this.y = new int[n];
		this.result = new int[n];
		this.l1_norm = 0;

		for(int i = 0; i<n; i++){
			this.x[i] = a[i];
			this.y[i] = b[i];
		}
		Arrays.fill(this.result, 0);
	}

	public synchronized void proizvod(int i){

		this.result[i] = this.x[i]*this.y[i];

		int norm = 0;
		for(int j=0;j<this.result.length;j++)
			norm += this.result[j];
		this.l1_norm = norm;

		this.notifyAll();

	}

	public int getL1Norm(){
		return this.l1_norm;
	}

}

package drugi;

public final class MatrixMultiplication extends Thread {

	private int[][] first, second;
	private int i, j, result;

	public MatrixMultiplication(int[][] first, int[][] second, int i, int j) {
		this.first = first;
		this.second = second;
		this.i = i;
		this.j = j;
		this.result = 0;
	}

	@Override
	public void run() {
		this.result = 0;
		int tmp = 0;
		for(int k = 0; k < first[0].length; ++k)
			for(int t = 0; t < second.length; ++t)
				tmp += first[this.i][k]*second[t][this.j];

		this.result = tmp; //TEK NA KRAJU CE AZURIRATI REZULTAT PA AKO SE PREKINE TOKOM RACUNA RESULT OSTAJE 0
	}

	public int getResult() {
		return result;
	}
}

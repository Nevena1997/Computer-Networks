package drugi;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public final class Main {

	public static void main(String[] args) {
		if(args.length==1)
			System.err.println("Nevalidan ulaz u program.");
		Scanner in = null;
		List<int[][]> list = new LinkedList<int[][]>();
		try {
			for(int i=1; i < args.length; ++i){
				in = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(args[i])), "UTF-8"));
				int[][] nextMatrix = readMatrix(in);
				list.add(nextMatrix);
				System.out.println(Arrays.deepToString(nextMatrix));
				in.close();
			}
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			in.close();
		}

		int[][] result = list.remove(0);
		int[][] next = null;
		while(!list.isEmpty()) {
			next = list.remove(0);
			try {
				MatrixMultiplicationException.check(result, next);
				MatrixMultiplication[][] m = new MatrixMultiplication[result.length][result.length];
				for (int i = 0; i < next.length; ++i)
					for (int j = 0; j < next.length; ++j) {
						m[i][j] = new MatrixMultiplication(result, next, i, j);
						m[i][j].start();
				}
				for (int i = 0; i < next.length; ++i)
					for (int j = 0; j < next.length; ++j)
						m[i][j].join();
				for (int i = 0; i < next.length; ++i)
					for (int j = 0; j < next.length; ++j)
						result[i][j] = m[i][j].getResult();
			} catch (MatrixMultiplicationException | InterruptedException e) {
				e.printStackTrace();
				continue;
			}
		}
		System.out.println("Rezultat:");
		System.out.println(Arrays.deepToString(result));
	}

	private static final int[][] readMatrix(Scanner in) {
		int n = in.nextInt();
		int[][] matrix = new int[n][n];
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				matrix[i][j] = in.nextInt();
		return matrix;
	}
}

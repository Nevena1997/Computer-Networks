package drugi;

public final class MatrixMultiplicationException extends Throwable{

	private static final long serialVersionUID = -1828706623328340437L;

	public static final void check(int[][] first, int[][] second) throws MatrixMultiplicationException{
		if(first.length == 0 || first[0].length != second.length)
			throw new MatrixMultiplicationException();
	}
}

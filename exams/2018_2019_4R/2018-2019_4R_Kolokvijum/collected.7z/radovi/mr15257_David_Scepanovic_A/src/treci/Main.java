package treci;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

public final class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		URL u = null;

		try {
			while (sc.hasNext()) {
				u = new URL(sc.nextLine());
				String protocol = u.getProtocol();
				String authority = u.getAuthority();
				String file = u.getFile();
				System.out.println(protocol + " " + authority + " " + file);
				if(!isHostName(authority)){
					InetAddress node = InetAddress.getByName(u.toString());
					int version = getVersion(node);
					System.out.println("(v" + version + ") " + protocol + " " + file + (version == 4 ? Arrays.toString(getBytes(node)) : ""));
				}

			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}

	}

	private static int getVersion(InetAddress node) {
		int length = node.getAddress().length;
		if(length == 4)
			return 4;
		if(length == 16)
			return 6;
		return -1;
	}

	private static boolean isHostName(String s) {
		if(s.indexOf(':') == -1)
			return false;
		return s.chars().anyMatch(c->!Character.isDigit(c) && c!='.');
	}

	private static int[] getBytes(InetAddress node) {
		byte[] bytes = node.getAddress();
		int[] result = new int[bytes.length];
		for (int i = 0; i < bytes.length; ++i)
			result[i] = bytes[i] < 0 ? bytes[i] + 256 : bytes[i];
		return result;
	}

}

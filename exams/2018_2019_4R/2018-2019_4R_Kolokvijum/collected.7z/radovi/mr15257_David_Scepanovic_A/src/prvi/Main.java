package prvi;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public final class Main {

	public static void main(String[] args) {
			try (Scanner sc = new Scanner(System.in);
					Scanner in = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(sc.next())), "UTF-8"));
					BufferedWriter out= new BufferedWriter(new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream("names.txt")), "UTF-8"));
					) {
				String next = null;
				while(sc.hasNext()){
					next=sc.next();
					if(check(next))
						out.write(next);
						out.newLine();
				}
				out.flush();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
				System.err.println("Nedozvoljeno UTF-8 kodiranje.");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				System.err.println("Nepostojeci fajl.");
			} catch (IOException e) {
				e.printStackTrace();
				System.err.println("Greska pri I/O operaciji.");
			}
	}

	private static final boolean check(String s) {
		if(s.length()<2)
			return false;
		if(!Character.isUpperCase(s.charAt(0)))
			return false;
		return s.substring(1).chars().allMatch(c->Character.isLowerCase(c));
	}
}

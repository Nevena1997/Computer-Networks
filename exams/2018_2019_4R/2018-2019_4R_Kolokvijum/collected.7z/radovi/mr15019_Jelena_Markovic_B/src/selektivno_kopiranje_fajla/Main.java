package selektivno_kopiranje_fajla;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ulazni_fajl = sc.next();
		sc.close();
		try{
		Scanner br = new Scanner(new InputStreamReader(new FileInputStream(ulazni_fajl)));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));
		try{
        while (br.hasNext()){
        	String word = br.next();
        	System.out.println(word);
        	if (is_hex(word)){
        		bw.write(word);
        		bw.newLine();
        	}
        }
        br.close();
        bw.close();
		} catch (IOException e){
			e.printStackTrace();
		}
		} catch (FileNotFoundException e){
			System.err.println("there is no such file");
		} catch (UnsupportedEncodingException e){
			System.err.println("encoding not supported");
		}

	}

	private static boolean is_hex (String niska){
		if (!niska.startsWith("0x"))
			return false;
		for (int i=2;i<niska.length();i++)
			if (!Character.isDigit(niska.charAt(i)) && !('A'<=Character.toUpperCase(niska.charAt(i)) &&
			'F'>=Character.toUpperCase(niska.charAt(i))))
				return false;
		return true;
	}
}

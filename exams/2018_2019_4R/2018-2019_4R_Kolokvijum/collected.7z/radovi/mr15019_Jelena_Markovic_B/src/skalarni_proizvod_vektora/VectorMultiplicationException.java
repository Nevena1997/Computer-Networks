package skalarni_proizvod_vektora;


public class VectorMultiplicationException extends Throwable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


}

package skalarni_proizvod_vektora;

import java.util.Scanner;
import skalarni_proizvod_vektora.VectorMultiplicationException;
//import java.util.concurrent.*;
public class Main {
	public static int sum = 0;
	public static int norma1, norma2 =0;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String file1 = sc.next();
		String file2 = sc.next();
		sc.close();


		Scanner sc1= new Scanner(file1);
		int dim1 = sc1.nextInt();
		int[] v1= new int[dim1];
		for (int i=0;i<dim1;i++)
			v1[i]=sc1.nextInt();
		sc1.close();

		System.out.println("Prvi vektor je: ");
		for (int i=0;i<dim1;i++)
			System.out.print(v1[i]+" ");
        System.out.println();

		Scanner sc2 = new Scanner(file2);
		int dim2 = sc2.nextInt();
		int[] v2= new int[dim2];
		for (int i=0;i<dim2;i++)
			v2[i]=sc2.nextInt();
        sc2.close();

        System.out.println("Drugi vektor je: ");
		for (int i=0;i<dim1;i++)
			System.out.print(v2[i]+" ");
        System.out.println();

        try{
		if (dim1 != dim2) throw  new  VectorMultiplicationException();
        } catch (VectorMultiplicationException e){
        	System.out.println("Vektori razlicite dimenzije ne mogu se mnoziti");
        }
		Thread[] niti = new Thread[dim1];
		for (int i=0;i<dim1;i++){
            niti[i] = new Thread(new ThreadCalculate(v1,v2,i));
            niti[i].start();
		}
		try{
		Thread.sleep(100);
		} catch (InterruptedException e){
			e.printStackTrace();
		}
		//Thread.yield();
		System.out.println("suma je "+sum);
		System.out.println("norma1 je "+norma1);
		System.out.println("norma2 je "+norma2);

	}

}

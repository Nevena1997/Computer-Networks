package skalarni_proizvod_vektora;

import java.util.concurrent.locks.*;

public class ThreadCalculate implements Runnable{

	private static int result =0;
	private int[] v1,v2;
	private int koordinata;
    private Lock lock;
	public ThreadCalculate(int[] v1, int[] v2, int koordinata){
		this.v1=v1;
		this.v2=v2;
		this.koordinata=koordinata;
		lock = new ReentrantLock();

	}
	public void run(){
		result = v1[koordinata]*v2[koordinata];
		Main.sum += result;
		System.out.println("suma je "+Main.sum);
		lock.lock();
		Main.norma1 += v1[koordinata];
		lock.unlock();
		lock.lock();
		Main.norma2 += v2[koordinata];
		lock.unlock();

	}
}

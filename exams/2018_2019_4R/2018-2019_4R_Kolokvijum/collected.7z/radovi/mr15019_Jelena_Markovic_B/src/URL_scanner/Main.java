package URL_scanner;

import java.net.URL;
import java.net.UnknownHostException;
import java.net.MalformedURLException;
import java.util.Scanner;
import java.net.InetAddress;
import java.net.Inet4Address;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()){
			String line = sc.nextLine();
			try{
			   URL url = new URL(line);
			   System.out.println(url.getProtocol()+" "+ url.getDefaultPort()+" "+
						url.getHost() + " "+ url.getPath());

			  if (url.getHost().equals("")){
				//   String address = url.getPath().substring(0, url.getPath().indexOf("/",1));
				   String address = url.getPath().substring(1, url.getPath().lastIndexOf(":"));
				   System.out.println("address"+ address);
				   try{
				   InetAddress addr = InetAddress.getByName(address);
					 System.out.println(addr);
					 Inet4Address a = (Inet4Address) addr;
					 System.out.println(a);
					 byte[] bajtovi = a.getAddress();
				/*	 for (int i=0;i<bajtovi.length();i++)
						 System.out.println(bajtovi[i]+" ");*/
				   } catch(UnknownHostException e){
						 e.printStackTrace();
					 }
			  }

			} catch (MalformedURLException e){
				System.err.println("neispravna adresa");
			}
		}
		sc.close();

	}

}

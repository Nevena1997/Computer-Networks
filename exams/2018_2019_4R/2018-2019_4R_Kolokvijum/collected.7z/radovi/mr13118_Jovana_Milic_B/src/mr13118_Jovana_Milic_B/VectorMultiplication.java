package mr13118_Jovana_Milic_B;

import java.util.Vector;
import java.util.concurrent.BlockingQueue;


public class VectorMultiplication implements Runnable {
	private Vector<Integer> v;
	private Vector<Integer> v2;
	private BlockingQueue<Integer>qb;
	private int n;
	public VectorMultiplication(Vector<Integer> vect, Vector<Integer> vect2, int n, BlockingQueue<Integer>qb) {
		// TODO Auto-generated constructor stub
		this.v=vect;
		this.v2=vect2;
		this.n=n;
		this.qb=qb;


	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean b=true;
		if(b){
			b=false;


			//System.out.println(Thread.currentThread().getId());
			v.setElementAt(new Integer(v.get(n) *v2.get(n)), n);

			//System.out.println(v);
			//System.out.println(v2);
		}
	}

}

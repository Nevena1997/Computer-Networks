package mr13118_Jovana_Milic_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		String filename=sc.next();
		try (
				BufferedReader br = new BufferedReader(new InputStreamReader (new FileInputStream(filename)));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter (new FileOutputStream("hex.txt"),"ASCII"));) {
			String line;
			while( (line=br.readLine())!=null)
			{
				if(line.matches("0x[0-9A-Fa-f]*")){
					bw.write(line+"\r\n");
					bw.flush();
				}
			}


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("File is not found");
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.err.println("IOEexception ");
			e1.printStackTrace();
		}
		finally {
			sc.close();
		}


	}

}

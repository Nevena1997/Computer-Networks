package mr13118_Jovana_Milic_B;

public class VectorMultiplicarionException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	


}

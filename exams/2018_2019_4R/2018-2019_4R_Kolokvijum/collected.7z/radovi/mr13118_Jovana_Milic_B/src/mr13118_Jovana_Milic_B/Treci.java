package mr13118_Jovana_Milic_B;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Treci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		while(sc.hasNext()){
			//http://123.123.123.123:80/dir1/dir2
			//http://2001:0db8:5a3:::8a5e:0370:7334/dir1
			String s = sc.next();

			if( s.trim().equalsIgnoreCase("exit"))
				break;

			try {
				URL url = new URL(s);
				String host = url.getHost();
				if(host.matches("([0-9]*\\.){3}[0-9]*")){
					if(url.getPort()==-1)
						System.out.print("(v4) "+url.getProtocol()+" " + url.getPath()+" " );
					else
						System.out.print("(v4) "+url.getProtocol()+ " "+url.getDefaultPort() +" " + url.getPath()+" " );
					host=host.replaceAll("([0-9]*)\\.([0-9]*)\\.([0-9]*)\\.([0-9]*)", "[$1 $2 $3 $4]");
					System.out.println(host);
					//
				}
				//String h ="2001:0db8:5a3:::8a5e:0370:7334";
				else if( host.matches("([0-9A-Fa-f]?:){7}[0-9A-Fa-f]?"))
					System.out.println("(v6)"+ url.getProtocol()+" "+ url.getPath());
				else{
					if(url.getPort()==-1)
						System.out.println(url.getProtocol() +" "+ url.getHost()+" " + url.getPath());
					else
						System.out.println(url.getProtocol() +" "+ url.getHost()+" "  + url.getDefaultPort()+ " " + url.getPath());

				}

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				System.err.println("URL Nije validan");
				continue;

			}



		}
		sc.close();



	}

}

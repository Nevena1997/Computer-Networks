package mr13118_Jovana_Milic_B;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Drugi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		try {
			BufferedReader br = new BufferedReader( new InputStreamReader( new FileInputStream(sc.next())));
			BufferedReader br2 = new BufferedReader( new InputStreamReader( new FileInputStream(sc.next())));
			String line;
			String []s=null;
			int i=0;

			while( ( line=br.readLine())!=null ){
				//System.out.println(line);
				s=line.split(" ");
			}

			Vector<Integer> vect=new Vector<Integer>(s.length);
			//System.out.println(s.length);
			for(i=0;i<s.length;i++){
				Integer integ =new Integer(s[i]);
				vect.add(integ);
			}
			String line2;
			String [] s2=null;
			while( ( line2=br2.readLine())!=null ){
				//System.out.println(line);
				s2=line2.split(" ");
			}

			Vector<Integer> vect2=new Vector<Integer>(s2.length);
			//System.out.println(s.length);
			for(i=0;i<s2.length;i++){
				Integer integ =new Integer(s2[i]);
				vect2.add(integ);
			}



			System.out.println(vect.toString());
			System.out.println(vect2.toString());
			if(vect.size()!= vect2.size())
				System.err.println("greska");

			int j;
			int n=vect.size();
			//System.out.println(n);
			BlockingQueue<Integer> bq = new ArrayBlockingQueue<Integer>(1);
			try {
				bq.put(new Integer(0));
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			for(j=0; j<n; j++){
				VectorMultiplication vm = new VectorMultiplication(vect,vect2,j,bq);
				Thread t = new Thread(vm);
				t.start();
				try {
					Thread.sleep(15);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(vect);







		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

}

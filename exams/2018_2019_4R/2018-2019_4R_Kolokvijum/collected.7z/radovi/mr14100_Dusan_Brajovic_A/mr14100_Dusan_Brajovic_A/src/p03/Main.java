package p03;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String input;

		while (true) {
			input = sc.nextLine();

			if (input.equalsIgnoreCase("stop"))
				break;

			try {
				URL url = new URL(input);
				if (check(url.getHost())) {
					if (url.getHost().contains(":")) {
						// v6
						System.out.printf("v6 %s %s %s\n", url.getProtocol(), url.getAuthority(), url.getPath());
					} else {
						System.out.printf("v4 %s %s %s [%s]\n", url.getProtocol(), url.getAuthority(), url.getPath(),
								url.getHost().toString().replace('.', ' '));
					}
				} else {
					System.out.printf("%s 	%s	%s\n", url.getProtocol(), url.getAuthority(), url.getPath());
				}
			} catch (MalformedURLException e) {
				// TODO: handle exception
				System.out.println("URL nije validan!");
				e.printStackTrace();
			}

		}

		sc.close();

	}

	private static boolean check(String ip) {
		if (ip.contains(":"))
			return true;

		if (ip.chars().allMatch(c -> Character.isDigit(c) || c == '.'))
			return true;

		return false;
	}

}

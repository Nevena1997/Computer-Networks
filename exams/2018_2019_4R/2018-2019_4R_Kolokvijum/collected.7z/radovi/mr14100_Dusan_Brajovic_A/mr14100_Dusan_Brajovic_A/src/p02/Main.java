package p02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String firstFile = sc.nextLine();
		String secondFile = sc.nextLine();
		sc.close();

		try {


			String 	input;
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(firstFile)));
			System.out.println("Prva matrica");
			while((input = in.readLine()) != null)
				System.out.println(input);

			in.close();
			in = new BufferedReader(new InputStreamReader(new FileInputStream(secondFile)));
			System.out.println("Druga matrica");
			while((input = in.readLine()) != null)
				System.out.println(input);



		} catch (FileNotFoundException e) {
			// TODO: handle exception
			System.err.println("Fajl nije pronadjen");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}


	}


}

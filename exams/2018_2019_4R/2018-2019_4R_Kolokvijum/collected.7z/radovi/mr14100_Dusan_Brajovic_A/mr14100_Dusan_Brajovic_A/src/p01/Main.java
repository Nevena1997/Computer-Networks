package p01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		sc.close();

		BufferedWriter out = null;

		try {
			sc = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(input), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			String word;
			while (sc.hasNext()) {
				word = sc.next();
				if (check(word)) {
					out.write(word);
					out.newLine();
				}
			}

		} catch (FileNotFoundException e) {
			// TODO: handle exception
			System.err.println("Uneseni fajl ne postoji");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {

			try {
				sc.close();
				out.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}

	}

	private static boolean check(String s) {
		if (s.length() < 1)
			return false;
		if (!Character.isUpperCase(s.charAt(0)))
			return false;

		for (int i = 1; i < s.length(); i++) {
			if (!Character.isLetter(s.charAt(i)) || Character.isUpperCase(s.charAt(i)))
				return false;
		}
		return true;
	}

}

package mr14095_Lidija_Cikaric_A;



import java.nio.file.Paths;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;



public class Drugi {

	public static void main(String[] args) {

		// za ulaz se daje putanja do tajlova u kojem su matrice
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesi putanju do fajlova u kojima se nalaze kvadratne matrice ");
		String p = sc.nextLine();
		String d = sc.nextLine();

		Path prva =  Paths.get(p);
		Path druga = Paths.get(d);

		try {
			Scanner sc1 = new Scanner(prva);
			while(sc1.hasNext())
				System.out.print(sc1.next());
			sc1.close();

			System.out.print("\n");

			Scanner sc2 = new Scanner(druga);
			while(sc2.hasNext())
				System.out.print(sc2.next());
			sc2.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sc.close();





	}



	public class MatrixMultiplicationException{

	//	private int dim1;
	//	private int dim2;

		public MatrixMultiplicationException(int d1, int d2){
	//		this.dim1 = d1;
	//		this.dim2 = d2;
		}
/*
		// napomena: proveravam samo za kvadratne matrice
		if(dim1 !=dim2){
			new Throwable("Matrice ne mogu da se mnoze.");
		}
*/

	}

}

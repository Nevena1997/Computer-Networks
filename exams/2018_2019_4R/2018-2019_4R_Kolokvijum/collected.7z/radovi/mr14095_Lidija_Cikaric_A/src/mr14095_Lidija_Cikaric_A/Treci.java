package mr14095_Lidija_Cikaric_A;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Treci {

	public static void main(String[] args) {

		String linija;
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesi URL ");
		while(sc.hasNextLine()){
			//System.out.println("Unesi URL ");
			linija = sc.nextLine();

			try {

				URL u = new URL(linija);


				System.out.printf("%s %s %s\n",u.getProtocol(), u.getAuthority(), u.getPath());


				System.out.println("\nUnesi URL ");
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.print("URL nije validan");
			}



		}

		sc.close();

	}

}

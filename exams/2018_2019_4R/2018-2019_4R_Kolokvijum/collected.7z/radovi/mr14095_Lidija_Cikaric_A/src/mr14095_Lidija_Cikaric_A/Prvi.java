package mr14095_Lidija_Cikaric_A;


import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {

		// sa standardnog ulaza se unosi sadrzaj koji se upisuje u datoteku names.txt
		// svaka linija je novo ime

	try {
		String ime;


	//	BufferedInputStream in = new BufferedInputStream(new InputStreamReader(in))

		//FileOutputStream x = new FileOutputStream("names.txt");
	//	OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("names.txt"));


		OutputStreamWriter o = new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8");
		BufferedWriter out = new BufferedWriter(o);


		Scanner sc = new Scanner(System.in);
		while(sc.hasNextLine()){
			ime = sc.nextLine();
			//System.out.println(ime);

			if(isName(ime)){
				// System.out.println(ime);

				 out.write(ime);
				 out.write('\n');
				}

		}

		sc.close();
		if(out != null){
			out.flush();
			out.close();
		}

	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}






	}


	public static boolean isName (String ime){

		if(ime.matches("[A-Z][a-z]*[ ][A-Z][a-z]*") )
			return true;

		return false;



	}

}

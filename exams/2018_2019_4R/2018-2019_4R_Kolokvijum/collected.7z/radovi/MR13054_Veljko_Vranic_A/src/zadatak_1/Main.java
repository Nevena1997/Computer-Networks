package zadatak_1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite ime fajla koji zelite da iskopirate");
		String fileName = null;
		if (sc.hasNext()) {
			fileName = sc.next();
		}
		sc.close();

		Scanner fileScanner = null;
		OutputStreamWriter out = null;
		try {
			fileScanner = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(fileName)), "UTF-8"));
			out = new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream("names.txt")), "UTF-8");

			String currentWord = null;
			while (fileScanner.hasNext()) {
				currentWord = fileScanner.next();
				if (checkIsName(currentWord)) {
					out.write(currentWord);
					out.write(Character.LINE_SEPARATOR);
					out.flush();
				}
			}

			if (fileScanner != null) {
				fileScanner.close();
			}
			if (out != null) {
				out.flush();
				out.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			if (fileScanner != null) {
				fileScanner.close();
			}
			if (out != null) {
				out.flush();
				out.close();
			}
			System.out.println("Uneti fajl nije pronadjen");
		} catch (Exception e) {
			e.printStackTrace();
			if (fileScanner != null) {
				fileScanner.close();
			}
			if (out != null) {
				out.flush();
				out.close();
			}
			System.out.println("Desila se greska");
		}
		System.out.println("Gotovo. Rezultate pogledati u fajlu pod imenom names.txt");
	}

	public static boolean checkIsName(String sample){
		System.out.println(sample);
		if (sample == null || (sample.length() < 1)) {
			return false;
		}
		if (!Character.isUpperCase(sample.charAt(0))) {
			return false;
		}
		return sample.matches(".[a-z]+");
	}
}

package zadatak_3;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

// http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt
public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite URLove jedan za drugim u pojedinacnim linijama");
		String urlString = null;
		while (sc.hasNextLine()) {
			urlString = sc.nextLine();

			try {
				URL url = new URL(urlString);
				StringBuffer sb = new StringBuffer();
				String authority = url.getAuthority();
				String protocol = url.getProtocol();
				String path = url.getPath();

				String response = parseAdress(authority);

				sb.append(response);
				sb.append(" ");
				sb.append(protocol);
				sb.append(" ");
				sb.append(authority);
				sb.append(" ");
				sb.append(path);

				if (response.equals("(v4)")) {
					String[] bytes = authority.split("\\.");
					sb.append("[");
					for (int i = 0 ; i < 4; i++) {
						sb.append(bytes[0]);
						if (i < 3 ) {
							sb.append(" ");
						}
					}
					sb.append("]");
				}
				System.out.println(sb.toString());

			} catch (MalformedURLException e) {
				e.printStackTrace();
				System.out.println("Ovo nije validan URL");
			}
		}
		sc.close();
	}

	public static String parseAdress(String authority) {
		System.out.println(authority);

		if (authority.matches("[0-2]?[0-9]?[0-9]\\.[0-2]?[0-9]?[0-9]\\.[0-2]?[0-9]?[0-9]\\.[0-2]?[0-9]?[0-9].*")) {
			return "(v4)";
		}

		if (authority.matches("([0-9a-f]?[0-9a-f]?[0-9a-f]?[0-9a-f]?:)+.*")) {
			return "(v6)";
		}

		return "";
	}
}

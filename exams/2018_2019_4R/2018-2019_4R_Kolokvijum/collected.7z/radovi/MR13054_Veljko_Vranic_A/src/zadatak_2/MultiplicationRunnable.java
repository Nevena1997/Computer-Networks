package zadatak_2;

public class MultiplicationRunnable implements Runnable {
	public static int firstIndex;
	public static int secondIndex;

	public MultiplicationRunnable(int i, int j) {
		firstIndex = i;
		secondIndex = j;
	}
	public void run() {
		int tmp = 0;
		for (int z = 0; z < Matrica.n; z++) {
			 tmp += Matrica.firstMatrix[firstIndex][z] * Matrica.secondMatrix[z][secondIndex];
		}
		//System.out.println("Thread  " + Thread.currentThread().getId() + " i " + firstIndex +  " j " + secondIndex);
		Matrica.resultMatrix[firstIndex][secondIndex] = tmp;
	}
}

package zadatak_2;

public class MatrixMultiplicationException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


}

package zadatak_2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Matrica {

	public static int [][] firstMatrix = new int[10][10];
	public static int [][] secondMatrix = new int[10][10];

	public static int [][] resultMatrix = new int[10][10];

	public static int n;
	public static boolean matrixBusy = false;

	public static void main(String[] args) {
		System.out.println("Unesite putanju do fajla prve matrice i pritisnite enter");
		Scanner sc = new Scanner(System.in);
		String firstFileName = null;
		String secondFileName = null;
		int firstMatrixSize = 0;
		int secondMatrixSize = 0;
		if (sc.hasNextLine()) {
			firstFileName = sc.nextLine();
			System.out.println("Unesite putanju do fajla druge matrice i pritisnite enter");
			if (sc.hasNextLine()) {
				secondFileName = sc.nextLine();
			}
		}

		sc.close();
		Scanner fileScanner = null;
		try {
			fileScanner = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(firstFileName)), "UTF-8"));

			int numberOfElements = 0;
			int [] arrayFirst = new int[200];

			while (fileScanner.hasNextInt()) {
				arrayFirst[numberOfElements] = fileScanner.nextInt();
				numberOfElements++;
			}
			if (Math.abs(Math.sqrt(numberOfElements) - Math.floor(Math.sqrt(numberOfElements))) < 0.00001) {
				firstMatrixSize = (int) Math.floor(Math.sqrt(numberOfElements));
			}

			fileScanner = new Scanner(new InputStreamReader(new BufferedInputStream(new FileInputStream(secondFileName)), "UTF-8"));

			numberOfElements = 0;
			int [] arraySecond = new int[200];

			while (fileScanner.hasNextInt()) {
				arraySecond[numberOfElements] = fileScanner.nextInt();
				numberOfElements++;
			}
			if (Math.abs(Math.sqrt(numberOfElements) - Math.floor(Math.sqrt(numberOfElements))) < 0.00001) {
				secondMatrixSize = (int) Math.floor(Math.sqrt(numberOfElements));
			}

			if (fileScanner != null) {
				fileScanner.close();
			}

			if (firstMatrixSize != secondMatrixSize) {
				if (fileScanner != null) {
					fileScanner.close();
				}
				throw new MatrixMultiplicationException();
			}
			n = firstMatrixSize;
			System.out.println("Prva matrica :");
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					firstMatrix[i][j] = arrayFirst[i * n + j];
					System.out.print(arrayFirst[i * n + j]);
					System.out.print(" ");
				}
				System.out.println();
			}
			System.out.println("Druga matrica :");

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					secondMatrix[i][j] = arraySecond[i * n + j];
					System.out.print(arraySecond[i * n + j]);
					System.out.print(" ");
				}
				System.out.println();
			}

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n ; j++) {
					new Thread(new MultiplicationRunnable(i, j)).start();
					Thread.sleep(100);
				}
			}
			System.out.println("Glavni thread se probudio, suma je " + getResultMatrixSum());

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					System.out.print(resultMatrix[i][j]);
					System.out.print(" ");
				}
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (fileScanner != null) {
				fileScanner.close();
			}
			System.out.println("Desila se greska");
		}
	}

	public static Lock lock = new ReentrantLock();

	public static synchronized int getResultMatrixSum(){
		if (lock.tryLock()) {
			try {
				matrixBusy = true;
				int sum = 0;
				for (int i = 0; i < n; i ++) {
					for (int j = 0; j < n ; j++) {
						sum += resultMatrix[i][j];
					}
				}
				return sum;
			} finally {
				lock.unlock();
				matrixBusy = false;
			}
		}

		return 0;
	}
}

package mr14201AndjelaDornik;

import java.util.Scanner;
import java.net.URL;
import java.net.URLConnection;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;

public class Zad3 {



	public static void main(String[] args)
	{

	System.out.println("ucitaj URL adrese: ");

	 Scanner sc= new Scanner(System.in);
	 String adresa="";


	 while(sc.hasNext())
	 {

		try{

		adresa= sc.next();
		URL url = new URL(adresa);
		try{
         String s=  url.openConnection().getContentType();




		}

		catch(IOException e){



		}

      System.out.println(" <KORISCENI_PROTOKOL>  <HOSTNAME>  <PODRAZUMEVANI_PORT>  <PUTANJA_DO_RESURSA>");

      System.out.println(url.getProtocol()+" "+ url.getHost() +" "+ url.getDefaultPort()+ " "+ url.getPath());


		}
		catch(MalformedURLException e)
		{

           System.err.println("NIje validan URl");

		}


	 }



	}



}

package mr14201AndjelaDornik;

import java.io.IOException;
import java.util.Scanner;
import  java.io.FileNotFoundException;
import  java.io.UnsupportedEncodingException;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class Zad1 {

	public static void main(String[] args)
	{
Scanner sc= new Scanner(System.in);

String fajl1 = sc.next();
sc.close();


Scanner in= null;
BufferedWriter out= null;




try{

in= new Scanner(new BufferedReader(new  InputStreamReader(new FileInputStream(fajl1),"UTF-8")));

out= new BufferedWriter(new OutputStreamWriter(new   FileOutputStream("hex.txt"),"ASCII"));

while(in.hasNext()){


String text="";
if(isHex(text=in.next()))
{
      out.write(text);
     out.write(" ");
}


}

in.close();


}catch(FileNotFoundException e){

System.err.println("Fajl "+ fajl1 +" ne postoji .... ");

}
catch(UnsupportedEncodingException e){

	System.err.println("Proveri encoding .");


}catch(IOException e){


	System.err.println();


}




	}



	public static boolean isHex(String text){

        if(!(text.startsWith("0x")))

                return false;

        for(int i=0;i< text.length();i++)
        {
             if(!(Character.isDigit(text.charAt(i))) || !(text.charAt(i)=='A')  || !(text.charAt(i)=='A')
            		|| !(text.charAt(i)=='A') || !(text.charAt(i)=='B')|| !(text.charAt(i)=='C')|| !(text.charAt(i)=='D')
            		|| !(text.charAt(i)=='E') || !(text.charAt(i)=='F') || !(text.charAt(i)=='a')
            		|| !(text.charAt(i)=='b') || !(text.charAt(i)=='c') || !(text.charAt(i)=='d') || !(text.charAt(i)=='e')
            		|| !(text.charAt(i)=='f'))

            	 return false;

        }
        	return true;
	}


}

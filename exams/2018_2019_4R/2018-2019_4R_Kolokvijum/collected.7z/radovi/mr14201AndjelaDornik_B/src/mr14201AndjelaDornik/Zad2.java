package mr14201AndjelaDornik;

import java.util.Scanner;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;




public class Zad2 {

private static final int  MAX=20 ;


	public static void main(String[] args)
	{

	System.out.println("Unesite direktorijum pocetni od kga krecem,odnosno putanju do fajlova: ");

	Scanner sc= new Scanner(System.in);
	String path=  sc.next();
    Path putanja= Paths.get(path);
    BlockingQueue<Path> fajlovi =new ArrayBlockingQueue<>(MAX);
    ArrayList arr= new ArrayList<>(fajlovi);
    for(int i=0;i<arr.size();i++){



    }



	}


}

package zadatak3;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		List<URL> l=new ArrayList<URL>();
		while(sc.hasNext())
			try {
				URL url=new URL(sc.nextLine());
				l.add(url);
				System.out.println(url.getProtocol()+" "+url.getDefaultPort()+" "+url.getHost()
				+" "+url.getPath());
			} catch (MalformedURLException e) {
				System.out.println("URL nije validan");
				e.printStackTrace();
			}
		sc.close();
	}

}

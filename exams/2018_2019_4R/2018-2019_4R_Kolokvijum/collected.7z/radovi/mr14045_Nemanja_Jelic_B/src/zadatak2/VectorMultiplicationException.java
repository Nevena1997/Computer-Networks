package zadatak2;

public class VectorMultiplicationException extends Throwable{
	public void print(){System.err.println("Vektori nemaju istu dimenziju");}
}

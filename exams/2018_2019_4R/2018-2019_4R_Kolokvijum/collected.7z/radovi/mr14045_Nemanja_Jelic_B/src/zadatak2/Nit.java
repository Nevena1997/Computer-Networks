package zadatak2;


public class Nit implements Runnable{
	private int x[],y[];
	private int n;

	public Nit(int x[],int y[],int n){
		this.n=n;
		this.x=x;
		this.y=y;
	}

	public void run(){
		for(int i=0;i<n;i++){
		try{
			long v=x[i]*y[i];
			Main.changeNorma(v);
			Main.r[i]=v;
			Thread.yield();
		}
		catch(Exception e){e.printStackTrace();}
		}
		Main.ispis();
	}
}

package zadatak2;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

	private static long Norma=0;
	public static long r[]=null;
	public synchronized static void ispis(){
		for(long j:Main.r)System.out.print(j+" ");
		System.out.println();
	}

	public synchronized static void changeNorma(long v){Norma+=v;}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Path path1=Paths.get(sc.nextLine());
		Path path2=Paths.get(sc.nextLine());
		sc.close();
		Scanner s1=null;
		Scanner s2=null;

		try{
			s1=new Scanner(path1);
			s2=new Scanner(path2);
			//System.out.println(s1.next());
			int n=s1.nextInt();
			int m=s2.nextInt();

			int v1[]=new int[n];
			int v2[]=new int[m];

			for(int i=0;i<n;i++)v1[i]=s1.nextInt();
			for(int i=0;i<m;i++)v2[i]=s2.nextInt();

			System.out.println();
			for (int i : v1)System.out.print(i+" ");
			System.out.println();
			for (int i : v2)System.out.print(i+" ");
			System.out.println();

			if(m!=n){//System.err.println("Razlicite dimenzije vektora");
			VectorMultiplicationException vme=new VectorMultiplicationException();
			throw vme;}
			r=new long[n];
			Nit nit=new Nit(v1,v2,n);
			for(int i=0;i<n;i++){
				new Thread(nit).start();
			}
		}
		catch(VectorMultiplicationException e){e.print();}
		catch(Exception e){e.printStackTrace();}
		finally{
			if(s1!=null)s1.close();
			if(s2!=null)s2.close();
		}
	}

}

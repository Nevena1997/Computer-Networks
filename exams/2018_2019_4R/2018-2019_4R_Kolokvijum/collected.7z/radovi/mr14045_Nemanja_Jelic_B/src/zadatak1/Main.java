package zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		BufferedWriter out=null;
		Scanner in=null;

		try{
			Scanner sc=new Scanner(System.in);
			in=new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(sc.nextLine()),"ASCII")));
			sc.close();
			out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));

			while(in.hasNext()){
				String s=in.next();
				if(s.charAt(0)=='0' && s.charAt(1)=='x'){
					String t=s.substring(2).toLowerCase();
					if(t.length()>0){
						boolean b=true;
						for(char c:t.toCharArray())
							if(!Character.isDigit(c) && c!='a' && c!='b' && c!='c'
									&& c!='d' && c!='e' && c!='f'){b=false;break;}
						if(b){
							out.write(s);
							out.newLine();
						}
					}
				}
			}
		}
		catch(Exception e){e.printStackTrace();}
		finally{
			try{
				if(in!=null)in.close();
				if(out!=null){
					out.flush();
					out.close();
				}
			}
			catch(Exception e){e.printStackTrace();}
		}
	}

}

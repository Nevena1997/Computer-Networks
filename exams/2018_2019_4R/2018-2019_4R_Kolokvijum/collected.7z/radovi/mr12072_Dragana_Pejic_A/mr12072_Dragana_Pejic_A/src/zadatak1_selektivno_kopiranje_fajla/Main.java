package zadatak1_selektivno_kopiranje_fajla;

import java.io.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("Enter file name: ");

		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			while(in.hasNext()){

				String word = in.next();

				if(isName(word)){
					out.write(word);
					out.newLine();
				}
			}

			System.out.println("Done!");

		} catch (UnsupportedEncodingException e) {
			System.err.println("Current JVM doesn't support the required encoding.");
		} catch(FileNotFoundException e){
			System.err.println("File " + file + " not found.");
		} catch (IOException e) {
			System.err.println("Error occured while writing into the output file.");
		} finally {

			if(in != null)
				in.close();

			if(out != null){
					try {
						out.flush();
						out.close();
					} catch (IOException e) {
						System.err.println("Error occured while closing the output stream.");
					}
			}
		}
	}

	private static boolean isName(String word) {

		if(word.length() < 1)
			return false;

		if(!Character.isLetter(word.charAt(0)))
			return false;

		if(Character.isLowerCase(word.charAt(0)))
			return false;

		for(int i = 1; i < word.length(); i++)
			if(!Character.isLetter(word.charAt(i)))
				return false;
			else if(Character.isUpperCase(word.charAt(i)))
				return false;

		return true;
	}

}

package zad_03;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		while(true){
			String u = sc.nextLine();

			try {
				URL url = new URL(u);
				System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getPath());

			} catch (MalformedURLException e) {
				System.out.println("URL is not valid!");
				sc.close();
			}

		}
	}

	private static int getVersion(InetAddress addr){
		byte[] address;
		address = addr.getAddress();

		if(address.length == 4)
			return 4;
		else if(address.length == 16)
			return 6;
		else
			return -1;
	}

}

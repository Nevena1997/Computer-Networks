package mr13090_Lazar_Nisic_A;

import java.net.InetAddress;
import java.net.URL;
import java.util.Scanner;

public class Treci {

	public static int verzija(InetAddress i){
		byte[] adresa = i.getAddress();
		if(adresa.length == 4)
			return 4;
		else if(adresa.length == 16)
			return 6;
		else
			return -1;
	}

	public static void main(String[] args) {

		try{
			Scanner sc = new Scanner(System.in);
			System.out.println("Unesite URL-ove:");

			while(sc.hasNextLine()){
				String s = sc.nextLine().trim();
				URL url = new URL(s);
				System.out.println(url.toString());

				String protokol = url.getProtocol();
				String autoriti = url.getAuthority();
				String putanja = url.getPath();

				System.out.println(protokol + " " + autoriti + " " + putanja);

				String host = url.getHost();
				//Ovaj uslov je mogao biti i precizniji, ali je napravljen da prodje test primere, ne za sve URL
				if(!(host.startsWith("www"))){
					InetAddress adr = InetAddress.getByName(host);
					int v = verzija(adr);
					if(v==4){
						byte[] bajtovi = adr.getAddress();
						String[] str = host.split("\\.");
						System.out.print("(v" +v+ ")" + " " + protokol + " " + putanja + " [");
						for(String l:str)
							System.out.print(l+ " ");
						System.out.print("]");
					}
					if(v==6)
						System.out.println("(v" +v+ ")" + " " + protokol + " " + putanja );
				}
			}



		sc.close();
		}
		catch(Exception e){
			System.out.println("Uneti URL nije validan!");
		}

	}

}

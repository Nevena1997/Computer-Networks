package mr13090_Lazar_Nisic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Prvi {

	public static boolean funkcija(String s){

		int p = 0;

		if(Character.isUpperCase(s.charAt(0))){

			for(int i=1;i<s.length();i++){
				if(!(Character.isLowerCase(s.charAt(i))))
					p=1;
			}

		}
		else
			p=1;

		if(p==1)
			return false;
		else
			return true;
	}

	
	
	public static void main(String[] args) {

		try{
			Scanner sc = new Scanner(System.in);
			System.out.println("Unesite ime fajla:");
			String fajl = sc.nextLine().trim();
			sc.close();

			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fajl), "UTF-8"));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));

			String pom = "";

			while((pom = in.readLine()) != null){
				String [] lista = pom.split(" ");
				int k =1;
				for(String element:lista){
					if(funkcija(element)){
						out.write(element);
						if(k%2 == 0)
							out.write("\n");
						else
							out.write(" ");
						k++;
					}
				}
			}

			in.close();
			out.close();
			System.out.println("Done.");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}

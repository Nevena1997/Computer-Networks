package mr13090_Lazar_Nisic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Paths;
import java.util.Scanner;

import javafx.scene.shape.Path;

public class Drugi {

	public static void main(String[] args) {
		try{
			Scanner sc = new Scanner(System.in);
			System.out.println("Unesite fajlove:");
			while(sc.hasNextLine()){
				String s = sc.nextLine();
				BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(s), "UTF-8"));
				String pom = "";
				while((pom=in.readLine())!=null){
					System.out.println(pom);
				}
				in.close();
			}
			sc.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}

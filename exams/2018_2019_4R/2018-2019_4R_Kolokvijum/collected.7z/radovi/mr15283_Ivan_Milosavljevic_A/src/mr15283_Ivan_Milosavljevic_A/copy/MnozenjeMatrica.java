/*package mr15283_Ivan_Milosavljevic_A.copy;

public class MnozenjeMatrica implements Runnable{

	@Override
	public void run() {
		try{
			int n;
		int[][] m1 = new int[n][n];

			for(int i=0,j=0,i<n,i++,j++){

			}


		}
		finally{

		}


	}

}*/

package mr15283_Ivan_Milosavljevic_A.copy;

public class MatrixMultiplicationException extends Exception{
 public static final Exception MatrixMultiplicationException = null;



	public void Exception(int m,int n){
	if(m!=n)
		try {
			throw MatrixMultiplicationException;
		} catch (java.lang.Exception e) {

			e.printStackTrace();
		}
	}

}

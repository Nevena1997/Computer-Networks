package mr15283_Ivan_Milosavljevic_A.copy;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.lang.reflect.Array;
import java.nio.file.Path;

public class matrice {

	public static void main(String[] args)  throws MatrixMultiplicationException {

	Scanner sc=new Scanner(System.in);
	int[][] matrica1;
	int[][] matrica2;
 	Scanner in;
 	BufferedWriter out;
 	int n = 0;
 	int m=0;
 	int[][] matrice = new int[n][n];
 	int[][]matrice2 = new int[m][m];

	try{
		 while(sc.hasNext()){


		String file=sc.next();
		in= new Scanner(new FileInputStream(file));
		int trBr = in.nextInt();
		for(int i=0,j=0;in.hasNext();i++,j++){
			matrice[j][i]=trBr;
			n++;
		}

		out= new BufferedWriter(new OutputStreamWriter(System.out));
		out.write(trBr);


		 	}
		 while(sc.hasNext()){


				String file=sc.next();
				in= new Scanner(new FileInputStream(file));
				int trBr = in.nextInt();
				for(int i=0,j=0;in.hasNext();i++,j++){
					matrice[j][i]=trBr;
					m++;
				}

				out= new BufferedWriter(new OutputStreamWriter(System.out));
				out.write(trBr);
	}
		 }
		catch(IOException e){
			System.err.print(e);
		}

	finally{
		int m1size=(int) Math.sqrt(n);
		int m2size=(int) Math.sqrt(m);

		sc.close();

	}


	}







}

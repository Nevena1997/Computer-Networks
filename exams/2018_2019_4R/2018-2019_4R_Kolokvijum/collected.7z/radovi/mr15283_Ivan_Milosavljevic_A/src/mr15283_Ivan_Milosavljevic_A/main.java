package mr15283_Ivan_Milosavljevic_A;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class main {

	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		String file=sc.next();

		Scanner in;
		BufferedWriter out;


	try{
		in= new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8")));
		out= new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));

		while(in.hasNext()){
			String name1=in.next();
			String name2=in.next();
			if(imePrezime(name1)&&imePrezime(name2))
			out.write(name1+name2+ "/n");


		}

	}
	catch(IOException e){
		System.err.print(e);
	}
	/*catch(UnsupportedEncodingException e){
	System.err.print(e);
}
	catch(FileNotFoundException e){
		System.err.print(e);
	}
	*/
	catch(SecurityException e){
		System.err.print(e);
	}
	finally{
		sc.close();


	}
	}
	public static Boolean imePrezime(String s){
		if(s.matches("^[A-Z][a-z]+$")){
			return true;
		}
		return false;
	}


}

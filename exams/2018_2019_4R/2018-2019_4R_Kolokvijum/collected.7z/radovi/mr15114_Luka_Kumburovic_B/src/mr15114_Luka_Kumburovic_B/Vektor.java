package mr15114_Luka_Kumburovic_B;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Vektor {

	private List<Float> x;

	public Vektor(){
		x = Collections.synchronizedList(new LinkedList<>());
	}

	public Vektor( List<Float> x ){
		this.x = Collections.synchronizedList(new LinkedList<>(x));
	}

	public List<Float> getX() { return x; }
	public void setX(List<Float> x) { this.x = x; }

	public int getDimension(){ return x.size(); }

	public void compareDimension( Vektor v ) throws VectorMultiplicationException{

		if( this.getDimension() != v.getDimension() ){
			throw new VectorMultiplicationException();
		}

		System.out.println("Dimensions are equal!");;

	}

	public float norm(){
		float sum = 0;
		for( int i = 0; i < getDimension(); i++ )
			sum += x.get(i);

		return sum;
	}

	@Override
	public String toString() {
		StringBuffer line = new StringBuffer("[");
		for( float xi : x )
			line.append(xi+", ");

		line.deleteCharAt(line.length()-1);
		line.deleteCharAt(line.length()-1);
		line.append("]\n");
		return line.toString();
	}

}// END OF class

package mr15114_Luka_Kumburovic_B;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zad3 {

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		Pattern p = Pattern.compile("([0-9]{1,3}\\.){3}[0-9]{1,3}");
		Matcher m = null;

		System.out.print("Enter url-s, 'exit' to stop: ");
		ArrayList<URL> urls = new ArrayList<>();
		String line = "";
		while( true )
			try {
				line = input.nextLine();
				if( line.equals("exit") )
					break;
				urls.add(new URL(line));
			} catch (MalformedURLException e) {
				System.err.println("URL is not valid!");
			}
		input.close();

		for( URL url: urls ){
			m = p.matcher(url.getHost());
			if(m.find())
				System.out.println("(v4) " + url.getPort() + " " + url.getPath() + " " + printBytes(url));

			else if( url.getHost().contains(":") )
				System.out.println("(v6) " + url.getProtocol() + " " + url.getPath());

			else
			System.out.println(url.getProtocol() + " " + url.getDefaultPort() + " " + url.getHost() + " " + url.getPath());

			m.reset();
		}





	}// END OF main

	public static String printBytes(URL url){
		StringBuffer rez = new StringBuffer("[ ");
		String temp = url.getHost();
		String[] tempArray = temp.split("\\.");
		for( String t : tempArray ){
			rez.append(t + " ");
		}
		rez.append("]");

		return rez.toString();
	}

}// END OF class

















package mr15114_Luka_Kumburovic_B;

public class VektorAdd implements Runnable{

	private Vektor v1;
	private Vektor v2;
	private static int i = 0; // checking point
	private static Vektor rez;

	public VektorAdd(Vektor v1, Vektor v2) {
		this.v1 = v1;
		this.v2 = v2;
		rez = new Vektor();
	}

	@Override
	public void run() {
		synchronized(rez){
			while( i != v1.getDimension() ){
				rez.getX().add(v1.getX().get(i) * v2.getX().get(i));
				System.out.println(rez.norm());
				i++;
			}
			System.out.println(rez);
		}

	}// END OF run

}// END OF class

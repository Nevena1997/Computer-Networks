package mr15114_Luka_Kumburovic_B;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

public class Zad2 {

	public static Scanner input = new Scanner(System.in);
	public static Scanner input1 = null;

	public static void main(String[] args) {

		Vektor v1 = null;
		Vektor v2 = null;

		String fileName1, fileName2;
		System.out.print("Enter two files: ");
		fileName1 = input.next();
		fileName2 = input.next();

		if( fileName1.equals("") || fileName2.equals("") ){
			System.err.println("Enter valid file names!");
			System.exit(0);
		}

		input.close();
		input = null;

		LinkedList<Float> x1 = new LinkedList<>();
		LinkedList<Float> x2 = new LinkedList<>();

		try {
			input = new Scanner( new File(fileName1) );
			input1 = new Scanner( new File(fileName2) );

			while( input.hasNext() )
				x1.add(input.nextFloat());

			while( input1.hasNext() )
				x2.add(input1.nextFloat());

			v1 = new Vektor(x1);
			v2 = new Vektor(x2);

			v1.compareDimension(v2);

			System.out.println(v1);
			System.out.println(v2);


		} catch (FileNotFoundException e) {
			System.err.println("File can't be found!");
		} catch (VectorMultiplicationException e) {
			System.err.println(e.getMessage());
		}

		for( int i = 0; i < v1.getDimension(); i++ )
			new Thread(new VektorAdd(v1,v2)).start();

	}// END OF main

}// END OF class




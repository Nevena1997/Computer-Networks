package mr15114_Luka_Kumburovic_B;

public class VectorMultiplicationException extends Exception {

	public VectorMultiplicationException(){
		super();
	}

	public VectorMultiplicationException(String s){
		super(s);
	}

	@Override
	public String getMessage() {
		return "Vectors dimensions do not match!";
	}



}

package mr15114_Luka_Kumburovic_B;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zad1 {

	public static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		Pattern p = Pattern.compile("0x([0-9]|[a-f]|[A-F])+");
		Matcher m = null;

		String fileName;
		System.out.print("Enter file name: ");
		fileName = input.next();

		if( fileName.equals("") ){
			System.err.println("Enter valid file name!");
			System.exit(0);
		}

		try( BufferedReader in = new BufferedReader(
								 new InputStreamReader(
								 new FileInputStream(fileName)));

			 OutputStreamWriter out = new OutputStreamWriter(
					 				  new BufferedOutputStream(
					 				  new FileOutputStream("hex.txt")),"ASCII");
		   ){

			String line;
			String[] words;
			while( (line = in.readLine()) != null ){
				words = line.split(" ");
				for( String word: words ){
					m = p.matcher(word);
					if( m.matches() ){
						out.write(word);
						out.write("\n");
					m.reset();
					}
				}
			}

		} catch( FileNotFoundException ex ){
			System.err.println("File does not exist!");
		} catch( IOException ex ){
			System.err.println(ex.getMessage());
		}
		System.out.println("hex.txt holds the result!");

	}// END OF main

}// END OF class

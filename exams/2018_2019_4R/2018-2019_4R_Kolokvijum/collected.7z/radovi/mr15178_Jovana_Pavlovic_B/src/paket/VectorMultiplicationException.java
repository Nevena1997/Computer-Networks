package paket;

public class VectorMultiplicationException {
	
	public VectorMultiplicationException() {
		
	}

}

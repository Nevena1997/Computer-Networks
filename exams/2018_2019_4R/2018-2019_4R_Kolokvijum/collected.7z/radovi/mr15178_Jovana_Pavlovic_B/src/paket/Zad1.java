package paket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Zad1 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		
		try {
			BufferedReader fin = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			BufferedWriter fout = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));
			
			int b;
			char[] buf = new char[512];
			while((b = fin.read(buf)) != -1)
				fout.write(buf, 0, b);
				
			fin.close();
			fout.close();
			
			System.out.println("Done");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		sc.close();
	}
}

package paket;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

//http:///123.123.123.123:80/dir1/dir2/test.txt
//http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt

public class Zad3 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		while(sc.hasNext()) {
			String line = sc.nextLine();
			
	        try {
				URL url = new URL(line.toString());
	
				if(isHostName(url.getHost()))
					System.out.println(url.getProtocol() + " " + url.getHost() + " " + url.getDefaultPort() + " " + url.getPath());
				else {
					if(getVersion(url.getHost()) == 4)
						System.out.println("(v4) " + url.getProtocol() + " " + url.getDefaultPort() + " " + url.getPath());
					else if(getVersion(url.getHost()) == 6)
						System.out.println("(v6) " + url.getProtocol() + " " + url.getPath());
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} 
		}
		
		sc.close();
	}
	
	private static boolean isHostName(String host) {
		
		if(host.indexOf(':') != -1)
			return false;
		
		for(int i = 0; i < host.length(); i++)
			if(!Character.isDigit(host.charAt(i)) && host.charAt(i) != '.')
				return true;
		return false;
	}
	
	private static int getVersion(String host) {
		byte[] adrr = null;
		
		try {
			InetAddress adr = InetAddress.getByName(host);
			adrr = adr.getAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		//for(int i = 0; i < adrr.length; i++) {
		//	int poz = adrr[i] < 0 ? adrr[i] + 256 : adrr[i];
		//	System.out.print(poz + " ");
		//}
		
		if(adrr.length == 4)
			return 4;
		else if(adrr.length == 16)
			return 6;
		else return -1;
	}
}


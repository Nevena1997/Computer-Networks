package Treci_zadatak;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class URL_validan {
public static void main(String[] args) throws IOException{
	URL url= new URL("http://www.matf.bg.ac.rs:3030");
	System.out.println(url.getAuthority());
	System.out.println(url.getProtocol());
	System.out.println(url.getPath());
    URLConnection u=url.openConnection();
    //Scanner sc=new Scanner(System.in);
    //String[] s;
    //while(sc.hasNextLine()){
    //	s=sc.NextLine();
    //	URL url=new URL();

    //}


}
}

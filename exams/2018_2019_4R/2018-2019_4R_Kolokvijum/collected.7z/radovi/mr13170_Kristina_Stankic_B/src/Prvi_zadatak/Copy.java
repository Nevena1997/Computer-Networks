package Prvi_zadatak;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.charset.*;


public class Copy {
//private static final String StandardCharset = null;

public static void main(String[] args){
	try {
		//Scanner sc=new Scanner(System.in);
		//String s;
		//String naziv=sc.toString();
		try{
		//BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/in.txt", StandardCharsets.US_ASCII)));
		//BufferedWriter hex = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/hex.txt",StandardCharsets.US_ASCII)));
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/in.txt")));
		BufferedWriter hex = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/hex.txt")));
		Scanner sc=new Scanner(in);
		String s;

		while(sc.hasNext()){
			s=sc.next();
            String[] tmp=s.split(" ");
            for(int i=0;i<tmp.length;i++){
            if(tmp[i].matches("[0][x]([A-Z]*[a-z]*[0-9]*)*")){
            	hex.write(s+" "+"\r\n");}}}


		System.out.println("Done!\n");
	    in.close();
	    hex.close();
	    sc.close();

		}

		catch(FileNotFoundException e){
			e.printStackTrace();

		}
		//InputStreamReader in=new InputStreamReader(new FileInputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/in.txt"));
		//OutputStreamWriter out=new OutputStreamWriter(new FileOutputStream("C:/Users/nalog/workspace/mr13170_Kristina_Stankic_B/out.txt"));
        //char[] buf=new char[512];
		//int byteR=0;
		//while((byteR=in.read(buf)) != -1){
		//	out.write(buf,0,byteR);
		//}
	    //System.out.println("Done!\n");
	    //in.close();
	    //out.close();
	    //}


	}
	 catch (IOException e) {
		e.printStackTrace();}
}
}
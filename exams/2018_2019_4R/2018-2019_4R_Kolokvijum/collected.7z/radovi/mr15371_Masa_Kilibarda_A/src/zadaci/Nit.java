package zadaci;

public class Nit implements Runnable{
	private Proizvod p;

	public Nit() {

	}

	@Override
	public void run() {
		p.pomnozi();
	}

}

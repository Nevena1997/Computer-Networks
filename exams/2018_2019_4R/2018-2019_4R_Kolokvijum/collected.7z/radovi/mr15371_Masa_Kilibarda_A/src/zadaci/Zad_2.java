package zadaci;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Zad_2 {

	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in);
		//String fajl_1=sc.next();
		//String fajl_2=sc.next();


			//Scanner in_1=new Scanner(new InputStreamReader(new FileInputStream(fajl_1)));
			//Scanner in_2=new Scanner(new InputStreamReader(new FileInputStream(fajl_2)));

			//System.out.println("nes");
			int[][] matrica_1= {
					{1,2,3},
					{2,3,4},
					{1,1,2}
			};
			int[][] matrica_2= {
					{1,2,3},
					{2,3,4},
					{1,1,2}
			};
			//int[sc.nextLine().split(" ").length][sc.nextLine().split(" ").length];
//			int i=0;
//			while(in_1.hasNext()){
//				String red=sc.next();
//				System.out.println(red);
//				String[] el=red.split(":");
//				for(int j=0;j<el.length;j++)
//					matrica_1[i][j]=Integer.parseInt(el[j]);
//				i++;
//			}
			for (int k = 0; k < matrica_1.length; k++) {
				for (int j = 0; j < matrica_1[k].length; j++) {
					System.out.println(matrica_1[k][j]);
				}
			}

			int n=3;
			Proizvod pr=new Proizvod(matrica_1,matrica_2);

			for(int br=0;br<n*n;br++){
				Nit nit =new Nit();
				Thread t=new Thread(t);
				t.start();
			}

	}

}

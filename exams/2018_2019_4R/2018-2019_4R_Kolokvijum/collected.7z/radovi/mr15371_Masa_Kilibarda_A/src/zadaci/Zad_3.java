package zadaci;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad_3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			String url_str=sc.nextLine();
			//if(!validan(url_str))
				//System.err.println("Nije validan URL");
			try {
				URL url=new URL(url_str);
				String url_authority=url.getAuthority();
				String aut=authority(url_authority);
				if(aut.equals("nema_IP"))
			 	 System.out.println(url.getProtocol()+" "+url.getAuthority()+" "+url.getPath());
				else if(aut.equals("v4"))
					System.out.println("(v4) "+url.getProtocol()+" "+url.getPath());/// DO TO [123 123 123 123]
			} catch (MalformedURLException e) {
				System.err.println("Greska pri pravljenu URL");
				e.printStackTrace();
			}

		}
		sc.close();
	}
// sftp://2001:Odb8:85a3:::8a2e:0370:7334/dir1/dir2/test.txt
	private static String authority(String url_authority) {
		String[] niz_v4=url_authority.split("\\.");
		//String[] niz_v6=url_authority.split(":");
		if(niz_v4.length==4){
			return "v4";
		}
		else return "nema_IP";

	}

	private static boolean validan(String url_str) {
		// TODO Auto-generated method stub
		return false;
	}

}

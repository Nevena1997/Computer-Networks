package zadaci;

public class Proizvod {
	private int[][] matr_1;
	private int[][] matr_2;
	private int[][] ukupno;
	private boolean[][] upisan;

	public Proizvod(int[][] matr_1,int[][] matr_2) {
		this.matr_1=matr_1;
		this.matr_2=matr_2;
		ukupno=new int [matr_1.length][matr_1.length];
		upisan=new boolean [matr_1.length][matr_1.length];
		for (int a = 0; a < matr_1.length; a++)
			for (int b = 0; b < matr_1[a].length; b++)
				upisan[i][j]=false;
	}

	public synchronized void pomnozi(){
		//mnozimo i-tu vrtu prve i j-otu vrstu druge
		for (int a = 0; a < matr_1.length; a++)
			for (int b = 0; b < matr_1[a].length; b++) {
				if(upisan==false)
					i=a;
				j=b;
			}


		int suma=0;
		int[] prva=matr_1[i];
		int n=matr_1.length;
		int[] druga=new int[n];
		int el=0;
		for (int a = 0; a < matr_1.length; a++)
			for (int b = 0; b < matr_1[a].length; b++) {
				if(b==j)
				druga[el]=matr_2[a][el];
				el++;
			}

		for(int k=0;k<n;k++)
			suma+=prva[k]*druga[k];
		ukupno[i][j]=suma;

	}
	public int getN(){
		return matr_1.length;
	}
}

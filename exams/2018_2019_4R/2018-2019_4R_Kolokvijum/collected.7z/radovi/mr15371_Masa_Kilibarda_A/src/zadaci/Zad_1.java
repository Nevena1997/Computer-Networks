package zadaci;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Zad_1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String fajl=sc.next();
		sc.close();
		try {
			BufferedReader bfin=new BufferedReader(new InputStreamReader(new FileInputStream(fajl),"UTF-8"));
			BufferedWriter bfout=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));

			Scanner sc_in=new Scanner(bfin);

			while(sc_in.hasNext()){
				String rec=sc_in.next();
				if(validna(rec)){
					try {
						bfout.write(rec);
						bfout.write("  ");
					} catch (IOException e) {
						System.err.println("Nije moguce pisanje u "+ bfout);
						e.printStackTrace();
					}

				}
			}

			sc_in.close();

			try {
				bfin.close();
				bfout.close();
			} catch (IOException e) {
				System.err.println("Nije moguce zatvoriti fajlove");
				e.printStackTrace();
			}

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			System.err.println("Fajl "+fajl+" ne moze da se otvori"+", ili nije podrazan UTF-8");
			e.printStackTrace();
		}
	}

	private static boolean validna(String rec) {
		char prvo=rec.charAt(0);
		if(prvo>='A' && prvo<='Z'){
			char [] niz=rec.substring(1).toCharArray();
			for(char el:niz){
				if(!(el>='a' && el<='z'))
					return false;
			}
			return true;
		}else
			return false;
	}

}

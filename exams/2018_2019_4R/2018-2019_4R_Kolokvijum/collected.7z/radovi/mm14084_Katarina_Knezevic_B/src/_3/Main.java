package _3;

import java.net.URL;
import java.util.Scanner;
import java.net.MalformedURLException;
import java.net.InetAddress;

public class Main {

	public static void main(String[] args){

		try{

			Scanner sc = new Scanner(System.in);

			while(sc.hasNextLine()){

			String url = sc.nextLine();
			URL u = new URL(url);

			/*
			 //Pretpostavimo da smo izvukli IP adresu iz url-a,
			//tada proveravamo verziju adrese i zavisno od verzije ipsisujemo bjtove ili ne pored ostalih informacija
			
			String adr = "123.123.123.123"; //Konkretno za ovu adresu ce se ispisati podaci, analogno bi bilo i za neku adresu tipa v6
			getBytes(adr);
			if(getVersion(adr) == 4){

			System.out.printf("(v4) ");
			System.out.printf("%s ", u.getProtocol());
			System.out.printf("%s ", u.getPort());
			System.out.printf("%s ", u.getHost());
			System.out.printf("%s ", u.getPath());
			getBytes(adr);

			}else if(getVersion(adr) == 6){

					System.out.printf("(v6) ");
					System.out.printf("%s ", u.getProtocol());
					System.out.printf("%s ", u.getPort());
					System.out.printf("%s ", u.getHost());
					System.out.printf("%s ", u.getPath());

				}else if(getVersion(adr) == -1){

					System.err.println("Invalid IP address");
				}*/


				//Ako nije uneta IP dresa unutar URL-a:

				System.out.printf("%s ", u.getProtocol());
				System.out.printf("%s ", u.getPort());
				System.out.printf("%s ", u.getHost());
				System.out.printf("%s\n", u.getPath());
			}
			sc.close();

		}catch(MalformedURLException e){
			System.err.println("URL is not valid!");
		}

	}

	// Metod koji vraca verziju IP adrese, ako je prosledjena kao niska, pod uslovom da je v4
	private static int getVersion(String adr){

		if(adr.indexOf('.') != -1)
			if(adr.split(".").length == 4)
				return 4;

		if(adr.indexOf(':') != -1)
			if(adr.split(".").length == 8)
				return 6;

		return -1;
	}

	// Metod koji ispisuje bajtove IP adrese:
	private static void getBytes(String adr){

		//Pretpostavka je da se radi o verziji IPv4 jer je tako naglaseno u tekstu zadatka
		String[] s = adr.split(".");
		System.out.printf("[");

		for(int i = 0; i < s.length - 1; i++)
			System.out.printf("%s ", s[i]); //ispisujemo sve osim poslednjeg jer on ne zahteva ispis razmaka
		System.out.printf("%s", s[s.length - 1]); //ispisujemo poslednji bez razmaka, a zatim i zagradu

		System.out.printf("]\n");
	}
}

package _1;

import java.util.Scanner;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

class Main {

		public static void main(String[] args){

				//Ucitavamo ime fajla sa standardnog ulaza:
				Scanner sc = new Scanner(System.in);
				String file = sc.next();
				sc.close();

				Scanner in = null;
				BufferedWriter out = null;

				try{

					in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file), "ASCII")));
					out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt")));

					while(in.hasNext()){

						// Ucitavamo rec po rec iz fajla:
						String s = in.next();

						// Validne reci (heksadekadne brojeve) upisujemo u fajl hex.txt
						if(isHex(s)){
							out.write(s);
							out.newLine();
						}
					}

				// Obrada mogucih izuzetaka:
				}catch(FileNotFoundException e){
					System.err.printf("File %s does not exist!\n", file);
				}catch(UnsupportedEncodingException e){
					System.err.println("Encoding ASCII is not suported!");
				}catch(IOException e){
					System.err.println("Failed to open file!");
				}finally{

					try{

							//Zatvaranje fajlova:
							if(in != null)
								in.close();

							if(out != null){
								out.flush();
								out.close();
							}

					//Obrada mogucih izuzetaka:
					}catch(IOException e){
							System.err.println("Failed to close streams!");
					}
				}
		}

		//Metod kojim se proverava da li je niska heksadekadni broj:
		private static boolean isHex(String s){

			//Niska koja je heksadekadni broj mora imati najmanje 3 karaktera, npr. 0xF:
			if(s.length() < 3)
				return false;

			//Proveravamo pojedinacne karaktere niske:
			if(s.charAt(0) != '0')
				return false;

			if(s.charAt(1) != 'x' && s.charAt(1) != 'X')
				return false;

			for(int i = 2; i < s.length(); i++){

				if(!Character.isDigit(s.charAt(i)) && s.charAt(i) != 'A'&& s.charAt(i) != 'a'&& s.charAt(i) != 'B' && s.charAt(i) != 'b' && s.charAt(i) != 'C'&& s.charAt(i) != 'c' && s.charAt(i) != 'D'&& s.charAt(i) != 'd' && s.charAt(i) != 'E' && s.charAt(i) != 'e' && s.charAt(i) != 'F' && s.charAt(i) != 'f')
						return false;
			}

			//Ako su svi karakteri validni, vracamo true:
			return true;

		}
}

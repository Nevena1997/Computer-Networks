package treci;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException{
		URL u;
		Scanner sc = new Scanner(System.in);

		try{
			u = new URL(sc.next());

		}finally{

		}

	}

}

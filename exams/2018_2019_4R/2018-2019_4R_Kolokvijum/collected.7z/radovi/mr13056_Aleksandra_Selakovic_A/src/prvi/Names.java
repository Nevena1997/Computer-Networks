package prvi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Names {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		String ulaz = sc.next();
		BufferedReader bin = null;
		BufferedWriter bout = null;

		try{
			bin = new BufferedReader(new InputStreamReader(new FileInputStream(ulaz), "UTF-8"));
			bout = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));

			String linija;
			while((linija=bin.readLine()) != null){
				String[] niz = linija.split(" ");
				for(String e:niz){
					if(e.matches("[A-Z][a-z]*")){
						bout.write(e);
						bout.write("\n");
					}
				}
			}

		}catch (FileNotFoundException e){
			System.out.println("Fajl nije pronadjen.");
			e.printStackTrace();
		}catch (UnsupportedEncodingException e){
			System.out.println("Nepostojeca kodna sema.");
			e.printStackTrace();
		}catch (IOException e){
			System.out.println("Nije moguce citanje iz fajla.");
			e.printStackTrace();
		}finally{
			sc.close();
			bin.close();
			bout.close();
		}


	}

}

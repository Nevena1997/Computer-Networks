package Task1;

import java.io.*;
import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner standardInput = new Scanner(System.in);
		String inputFileName = standardInput.next();
		try( BufferedReader inputFileReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFileName), "UTF-8"));
			 BufferedWriter outputFileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"), "UTF-8"));
			)
		{
			String line;
			while ((line = inputFileReader.readLine()) != null)
			{
				String[] words = line.split(" ");
				for (String word : words)
				{
					System.out.println(word);
					if (word.isEmpty())
					{
						continue;
					}
					if (Character.isUpperCase(word.charAt(0))
						&& word.substring(1).chars().allMatch(c -> Character.isLowerCase(c)))
					{
						outputFileWriter.write(word);
						outputFileWriter.newLine();
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("File with this name does not exist.");
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		standardInput.close();
	}

}

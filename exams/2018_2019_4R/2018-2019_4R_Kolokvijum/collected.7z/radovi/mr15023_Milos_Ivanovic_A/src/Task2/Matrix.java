package Task2;

import java.util.Scanner;

public class Matrix {

	private int[][] m_Elements;

	public Matrix(int n)
	{
		m_Elements = new int[n][n];
	}

	public void setElement(int x, int y, int element)
	{
		m_Elements[x][y] = element;
	}
	public int getElement(int x, int y)
	{
		return m_Elements[x][y];
	}
	public int getDimension()
	{
		return m_Elements.length;
	}

	public void Print()
	{
		int dim = getDimension();
		for (int i = 0; i < dim; ++i)
		{
			for (int j = 0; j < dim; ++j)
			{
				System.out.print(m_Elements[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static Matrix ParseMatrix(Scanner sc)
	{
		try
		{
			int dimension = sc.nextInt();
			Matrix returnMatrix = new Matrix(dimension);
			for (int i = 0; i < dimension; ++i)
			{
				for (int j = 0; j < dimension; ++j)
				{
					returnMatrix.setElement(i, j, sc.nextInt());
				}
			}
			return returnMatrix;
		}
		catch (Exception e)
		{
			System.out.println("Exception occured - no matrix could be read from the file");
			throw(e);
		}
	}

}

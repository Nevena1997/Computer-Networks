package Task2;

@SuppressWarnings("serial")
public class MatrixMultiplicationException extends Throwable {

}

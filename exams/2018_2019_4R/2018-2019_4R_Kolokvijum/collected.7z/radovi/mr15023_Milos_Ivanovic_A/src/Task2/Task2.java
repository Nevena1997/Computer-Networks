package Task2;
import java.io.*;
import java.util.Scanner;
public class Task2 {

	public static void main(String[] args) {
		if (args.length != 2)
		{
			System.out.println("Wrong amount of input arguments.");
			return;
		}
		try (
			Scanner input1 = new Scanner(new FileInputStream(args[0]));
			Scanner input2 = new Scanner(new FileInputStream(args[1]));
			)
		{
			Matrix matrix1 = Matrix.ParseMatrix(input1);
			Matrix matrix2 = Matrix.ParseMatrix(input2);
			if (matrix1.getDimension() != matrix2.getDimension())
			{
				throw new MatrixMultiplicationException();
			}
			MultiplyMatrices(matrix1, matrix2);
		}
		catch (MatrixMultiplicationException e)
		{
			System.out.println("Matrices could not be multiplied due to dimension mismatch.");
			return;
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void MultiplyMatrices(Matrix inputMatrix1, Matrix inputMatrix2)
	{
		System.out.println("Matrix 1: ");
		inputMatrix1.Print();
		System.out.println("Matrix 2: ");
		inputMatrix2.Print();
		int dimension = inputMatrix1.getDimension();
		Matrix outputMatrix = new Matrix(inputMatrix1.getDimension());
		Thread[][] runners = new Thread[dimension][dimension];
		for (int i = 0; i < dimension; ++i)
		{
			for (int j = 0; j < dimension; ++j)
			{
				MatrixMultiplicationTask multiplySingle = new MatrixMultiplicationTask(inputMatrix1, inputMatrix2, i, j, outputMatrix);
				(runners[i][j] = new Thread(multiplySingle)).start();
			}
		}
		for (int i = 0; i < dimension; ++i)
		{
			for (int j = 0; j < dimension; ++j)
			{
				try
				{
					runners[i][j].join();
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
		}
		System.out.println("Output Matrix: ");
		outputMatrix.Print();
		System.out.println("Sum of the elements of output matrix: " + MatrixMultiplicationTask.GetElementSum());
	}
}

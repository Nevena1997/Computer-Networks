package Task2;

public class MatrixMultiplicationTask implements Runnable {

	private static int g_ElementSum;
	private static synchronized void UpdateElementSum(int newElement)
	{
		g_ElementSum += newElement;
	}
	public static int GetElementSum()
	{
		return g_ElementSum;
	}

	Matrix m_InputMatrix1, m_InputMatrix2, m_OutputMatrix;
	int m_i, m_j;
	public MatrixMultiplicationTask(Matrix inputMatrix1, Matrix inputMatrix2, int i, int j, Matrix outputMatrix)
	{
		m_InputMatrix1 = inputMatrix1;
		m_InputMatrix2 = inputMatrix2;
		m_OutputMatrix = outputMatrix;
		m_i = i;
		m_j = j;
	}
	@Override
	public void run() {
		int result = 0;
		try
		{
			int matrixDimension = m_OutputMatrix.getDimension();
			for (int k = 0; k < matrixDimension; ++k)
			{
				result += m_InputMatrix1.getElement(m_i, k) * m_InputMatrix2.getElement(k, m_j);
			}
			m_OutputMatrix.setElement(m_i, m_j, result);
		}
		catch (Exception e)
		{
			result = 0;
		}
		UpdateElementSum(result);
	}

}

package Task3;

import java.net.*;
import java.util.Scanner;

public class Task3 {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (true)
		{
			try
			{
				String line = sc.nextLine();
				if (line.equals("!exit") || line.equals("!quit"))
				{
					break;
				}
				URI uri = new URI(line);
				try
				{
					URL url = uri.toURL();
					if (url.getHost().isEmpty())
					{
						System.out.println("Bad format in url.");
					}
					else
					{
						PrintURL(new URL(line));
					}
				}
				catch (MalformedURLException e)
				{
					System.out.println("(v6) " + uri.getScheme() + " " + uri.getPath());
				}
			}
			catch (URISyntaxException | IllegalArgumentException e)
			{
				System.out.println("URL could not be parsed.");
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		sc.close();
	}

	private static void PrintURL(URL url)
	{
		String host = url.getHost();
		if (host.chars().noneMatch(c -> Character.isAlphabetic(c)))
		{
			//IPv4 - no alphabetic characters, only numbers/dots
			String ipBytes = "[ ";
			String[] ipNumbers = host.split("\\.");
			for (String ipNumber : ipNumbers)
			{
				ipBytes += ipNumber + " ";
			}
			ipBytes += "]";
			System.out.println("(v4) " + url.getProtocol() + " " + url.getFile() + " " + ipBytes);
		}
		else
		{
			System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getFile());
		}
	}
}

package ml15229_Bojana_Bujakovic_B;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Prvi {


	public static void main(String[] args) throws IOException {


		System.out.println("Unesite naziv fajla:");
		Scanner sc=new Scanner(System.in);
        String fajl=sc.next();
        BufferedReader bin=null;
        BufferedWriter bout=null;

        try {
			bin=new BufferedReader(new InputStreamReader(new FileInputStream(fajl),"ASCII"));
			bout=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));

			String linija;

			while((linija=bin.readLine())!=null){
			     String[] reci=linija.split(" ");
			     for (String e:reci)
			    	 if(hex(e)){
			    		 bout.write(e);
			    		 bout.write("\n");
			    	 }
			}


		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			System.out.println("Nije podrzano kodiranje ili nije pronadjen fajl");
			e.printStackTrace();
		}
        finally{
        	bin.close();
        	bout.close();
        	sc.close();
        }




	}

	private static boolean hex(String e) {

		if (!(e.startsWith("0x")))
		return false;
		else
		return true;


		/*
      String s=e.substring(2).toLowerCase();

    if (f(s))
         return true;
      else
    	  return false;
*/
       }
/*
	private static boolean f(String s) {

		char[] niz=s.toCharArray();
		for(int i=0;i<niz.length;i++){
			if(niz[i]!="0" && niz[i]!="1" && niz[i] ){

			}
		}
*/
	}



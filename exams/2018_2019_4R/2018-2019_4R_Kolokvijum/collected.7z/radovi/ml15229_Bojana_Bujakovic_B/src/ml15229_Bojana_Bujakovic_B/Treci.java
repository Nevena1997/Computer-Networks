package ml15229_Bojana_Bujakovic_B;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;

public class Treci {


	public static void main(String[] args) throws IOException {

		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		String s;

		while((s=bf.readLine())!=null){


			try {
				URL u=new URL(s);

                if (u.getHost().contains(":"))
                	System.out.println("(v6)"+" "+u.getProtocol()+" "+ u.getPath());
                else if(adresa(u.getHost()))
                    System.out.println(u.getProtocol()+" "+u.getDefaultPort()+" "+u.getHost()+" "+u.getPath());
                else{
                	InetAddress a=InetAddress.getByName(u.getHost());
                	byte[] b=a.getAddress();
                	System.out.println("(v4)"+ u.getProtocol()+" "+u.getDefaultPort()+" "+b.toString());
                }
			} catch (MalformedURLException e) {
				System.out.println("URL nije validan");
				e.printStackTrace();
			}

		}
	}

	private static boolean adresa(String host) {
		if(host.startsWith("www."))
			return true;
		else
			return false;

	}















}


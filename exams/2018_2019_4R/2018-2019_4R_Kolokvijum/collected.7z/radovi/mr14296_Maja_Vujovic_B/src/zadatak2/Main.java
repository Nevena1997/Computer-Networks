package zadatak2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Uneti putanje do fajlova u kojima su vektori ciji skalarni proizvod treba izracunati:");



		sc.close();
	}//end main

}//end class

package zadatak1;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Zadatak1 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Uneti naziv fajla za kopiranje:");
		String fajl= sc.next();
		sc.close();

		Scanner in= null;
		BufferedWriter out= null;

		try {
			in = new Scanner(new BufferedInputStream(new FileInputStream(fajl)));
			out= new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));

			String tekst;
			while(in.hasNext()){
				tekst=in.next();
				System.out.println(tekst + " : " + isHexa(tekst));
				if(isHexa(tekst)){
					try {
						out.write(tekst);
						out.newLine();
					} catch (IOException e) {
						System.err.print("Pisanje u fajl daje izuzetak");
					}//end catch

				}//end if


			}//end while



		} catch (FileNotFoundException e) {
			System.err.print("Fajl nije pronadjen");
		} catch (UnsupportedEncodingException e) {
			System.err.print("Nije podrzano zeljeno kodiranje");
		} finally {
			try {
				if(in != null)
				in.close();
				if(out != null){
					out.flush();
					out.close();
					} //end if
				} catch (IOException e) {
					System.err.print("Zatvaranje resursa daje izuzetak");
				}//end catch
		}//end finally

	}//end main


	public static boolean isHexa(String s){
		if(s.charAt(0) != '0' || s.charAt(1) != 'x')
			return false;// ne pocinje na odgovarajuci nacin, odmah false
		System.out.println('.');
		for (int i=2;i<s.length();i++){
			System.out.println(':');
			if(!Character.isDigit(s.charAt(i)) && !((s.charAt(i) >= 'a') && (s.charAt(i) <= 'f')
					&& (s.charAt(i) <= 'F') && (s.charAt(i) >= 'A')) )
				return false;
		}//end for
		System.out.println(',');

		return true;

	}//kraj pomocne fje

}// end class

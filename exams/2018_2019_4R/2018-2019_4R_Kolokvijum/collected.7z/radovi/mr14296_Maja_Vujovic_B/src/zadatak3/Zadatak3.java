package zadatak3;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zadatak3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Uneti URL-ove (po jedan  u liniji):");
		String url;
		if((url=sc.nextLine()) != null){
			try {
				URL u=new URL(url);

			/*	if(hasIP(u)){
					URL u=new URL(url);
					System.out.printf("(v%d) %s %s %s [%s]",
					vrstaIP(url),
					u.getProtocol(),
					u.getPort(),
					u.getPath(),
					bajtovi(url);
				}//end if
				else {*/

					System.out.printf("%s %s %s %s",  u.getProtocol(), u.getDefaultPort(), u.getHost(), u.getPath());

			//	}//end else

			} catch (MalformedURLException e) {
				System.out.print("Uneti URL nije validan! ");
			}//end catch
			finally {
				sc.close();
			}
		}//end while



	}//end main

/*	private static byte[] bajtovi(String url) {
		byte[] b= url.getBytes();
		for (int i=0;i<b.length;i++)
			System.out.print(b);

		return null;
	}*/

	/*private static int vrstaIP(String url) {
	  	String adresa= "123.123.123.123";
		String []x=adresa.split(":");
		String []y=adresa.split("\\.");
			if(x.length == 16)
				return 6;
			if(y.length == 4)
				return 4;

	}*/

	 /*private static boolean hasIP(URL u) {
		String url=u.toString();
		String []x=url.split("\\");
		for (int i=0;i<x.length;i++)
			if(x[i].contains(":"))
				return true; //to je ipv6



	 }//end function
	*/

}//end class

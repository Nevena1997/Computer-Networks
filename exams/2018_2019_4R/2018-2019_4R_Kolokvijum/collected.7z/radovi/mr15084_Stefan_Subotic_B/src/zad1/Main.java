package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String filename = sc.next();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;

		try {
			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream("src/" + filename),"ASCII")));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/hex.txt"),"ASCII"));

			String word;
			while(in.hasNext()){
				word = in.next();
				if(isHex(word)){
					out.write(word);
					out.newLine();
				}
			}


		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try{
				if(in != null){
					in.close();
				}
				if(out != null){
					out.flush();
					out.close();
				}
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
	}

	private static boolean isHex(String word) {
		if(!word.startsWith("0x")){
			return false;
		}


		for(char c : word.toCharArray()){
			if(!(c!='a' || c!= 'b' || c!= 'c' || c!= 'd' || c!= 'e' || c!= 'f' || c!= 'A' ||
				 c!='B' || c!= 'C' || c!= 'D' || c!= 'E' || c!= 'F' || c!= '0' || c!= '1' ||
				 c!='2' || c!= '3' || c!= '4' || c!= '5' || c!= '6' || c!= '7' || c!= '8' || c!= '9')){
				return false;
			}
		}

		return true;
	}

}

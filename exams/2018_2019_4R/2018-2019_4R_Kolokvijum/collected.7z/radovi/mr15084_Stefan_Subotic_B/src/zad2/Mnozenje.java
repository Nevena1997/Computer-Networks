package zad2;

import java.util.concurrent.BlockingQueue;

public class Mnozenje implements Runnable {
	private Vector v;
	private static int sum = 0;

	public Mnozenje(Vector v){
		this.v = v;
	}

	@Override
	public void run() {
		boolean done = false;
		while(!done){
			try {
				int i1 = v.queue1.take();
				int i2 = v.queue2.take();

				if(i1 == Vector.DUMMY || i2 == Vector.DUMMY){
					done = true;
					v.queue1.put(Vector.DUMMY);
					v.queue2.put(Vector.DUMMY);
					break;
				}

				add(i1,i2);
				System.out.println("Thread: " + Thread.currentThread() + " added " + i1*i2 + " to sum. Current result is: " + sum);
				Thread.sleep(100);

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private synchronized void add(int i1, int i2) {
		sum += i1 * i2;
	}

}

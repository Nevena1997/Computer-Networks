package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;

public class Vector implements Runnable{
	public static final Integer DUMMY = -1;

	private Path file1;
	private Path file2;
	BlockingQueue<Integer> queue1;
	BlockingQueue<Integer> queue2;

	public Vector(Path f1, Path f2){
		this.file1 = f1;
		this.file2 = f2;
	}

	@Override
	public void run() {
		Scanner in1 = null;
		Scanner in2 = null;
		try{
			in1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file1.toString()))));
			in2 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file2.toString()))));

			Integer v1;
			Integer v2;
			while(in1.hasNext() && in2.hasNext()){
				v1 = in1.nextInt();
				v2 = in2.nextInt();

				this.queue1.put(v1);
				this.queue2.put(v2);
			}

			this.queue1.put(DUMMY);
			this.queue2.put(DUMMY);

		}  catch(FileNotFoundException e) {
			e.printStackTrace();
		}  catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			in1.close();
			in2.close();
		}
	}
}

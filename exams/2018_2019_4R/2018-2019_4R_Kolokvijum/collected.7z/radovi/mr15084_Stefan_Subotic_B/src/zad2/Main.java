package zad2;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String filepath = sc.nextLine();
		Path file1 = Paths.get(filepath);
		filepath = sc.nextLine();
		Path file2 = Paths.get(filepath);

		Vector v = new Vector(file1,file2);
		Thread vt = new Thread(v);
		vt.start();

		for(int i = 0; i < 10; i++){
			Mnozenje m = new Mnozenje(v);
			Thread mt = new Thread(m);
			mt.start();
		}

		sc.close();
	}

}

package zad3;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String u;
		while(sc.hasNext()){
			u = sc.next();
			try {
				URL url = new URL(u);
				System.out.println(url.getHost());
				if(url.getHost() != " "){
					System.out.println(url.getProtocol() + " " + url.getDefaultPort() + " " + url.getHost() + " " + url.getPath());
				}
				else {
					System.out.println(getVersion(url) + " " + url.getProtocol() + " " + url.getDefaultPort() + " ");
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}

		sc.close();

	}

	public static String getVersion(URL url){
		if(url.getAuthority().indexOf(':') < 10){
			return "(v6)";
		}
		else return "v4";
	}

}

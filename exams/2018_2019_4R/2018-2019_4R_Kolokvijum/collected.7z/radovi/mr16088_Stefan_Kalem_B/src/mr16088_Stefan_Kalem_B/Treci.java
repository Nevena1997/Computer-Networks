package mr16088_Stefan_Kalem_B;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;

public class Treci {
	static Pattern ip4Pattern = Pattern.compile("\\b([0-9]+\\.){3}[0-9]+\\b");
	static Pattern ip6Pattern = Pattern.compile("\\b([0-9a-eA-E]*\\:){7}[0-9a-eA-E]*\\:");
	static String convertBytes(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 4; i++) {
			if (bytes[i] < 0)
				sb.append(bytes[i] + 256);
			else
				sb.append(bytes[i]);
			sb.append(" ");
		}
		return sb.toString();
	}
	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in)) {
			String nextLine = null;
			while (scanner.hasNextLine()) {
				nextLine = scanner.nextLine();
				URL url = null;
				try {
					url = new URL(nextLine);
				} catch (MalformedURLException e) {
					System.out.println("error: malformed url");
					continue;
				}
				String authority = url.getAuthority();
				String host = url.getHost();
				String protocol = url.getProtocol();
				String filePath = url.getPath();
				int port = url.getPort();
				java.util.regex.Matcher matcher1 = ip4Pattern.matcher(host);
				java.util.regex.Matcher matcher2 = ip6Pattern.matcher(host);
				System.out.println(host);
				boolean isIp4 = matcher1.matches();
				boolean isIp6 = matcher2.matches();

				if (isIp4 || isIp6) {
					StringBuilder sb = new StringBuilder("v");
					if (isIp4)
						sb.append(4 + " ");
					else
						sb.append(6 + " ");
					sb.append(protocol + " " );
					if (port != -1)
						sb.append(port+ " ");
					sb.append(filePath + " ");
					if (isIp4) {
						InetAddress address = InetAddress.getByName(host);
						byte[] bytes = address.getAddress();
						sb.append("[ " + convertBytes(bytes) + "]");
					}
					System.out.println(sb.toString());
					continue;
				}
				StringBuilder sb = new StringBuilder();
				sb.append(protocol + " ").append(url.getDefaultPort() + " ")
					.append(host + " ").append(filePath + " ");
				System.out.println(sb.toString());
			}
		} catch (UnknownHostException e) {
			System.out.print(e);
		}
	}
}

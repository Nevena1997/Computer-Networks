package mr16088_Stefan_Kalem_B;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Drugi {

	public static void main(String[] args)
		throws IOException, VectorMultiplicationException {

		String filePath1 = "C:\\Users\\nalog\\Desktop\\mr16088_Stefan_Kalem_B\\src\\mr16088_Stefan_Kalem_B\\drugi-test1.txt";
		String filePath2 = "C:\\Users\\nalog\\Desktop\\mr16088_Stefan_Kalem_B\\src\\mr16088_Stefan_Kalem_B\\drugi-test2.txt";

		int dimension1;
		int[] cordinates1 = null;
		try (Scanner scanner = new Scanner(
				new FileInputStream(filePath1))) {
			dimension1 = scanner.nextInt();
			cordinates1 = new int[dimension1];
			for (int i = 0; i < dimension1; i++)
				cordinates1[i] = scanner.nextInt();
		}


		int dimension2;
		int[] cordinates2 = null;
		try (Scanner scanner = new Scanner(
				new FileInputStream(filePath2))) {
			dimension2 = scanner.nextInt();
			cordinates2 = new int[dimension2];
			for (int i = 0; i < dimension2; i++)
				cordinates2[i] = scanner.nextInt();
		}

		if (dimension1 != dimension2)
			throw new VectorMultiplicationException();
		ScalarMul scalarMul = new ScalarMul(dimension1, cordinates1, cordinates2);
		System.out.print(scalarMul.multiply());

	}




}

class vector {
	int dimension;
	int[] cordinates;
	public vector(int dimension, int[] cordinates) {
		this.dimension = dimension;
		this.cordinates = cordinates;
	}
}

class ScalarMul implements Runnable {
	Integer result = 0;
	int dimension;
	Integer indexOfNextElement = 0;
	int[] cordinatesA, cordinatesB;
	public ScalarMul(int dimension, int[] cordinatesA, int[] cordinatesB) {
		this.dimension = dimension;
		this.cordinatesA = cordinatesA;
		this.cordinatesB = cordinatesB;
	}

	public int multiply() {
		Thread[] threads = new Thread[dimension];
		for (int i = 0; i < dimension; i++)
			threads[i] = new Thread(this);
		for (int i = 0; i < dimension; i++)
			threads[i].start();
		for (int i = 0; i < dimension; i++)
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				return 0;
			}
		return result;
	}
	public void run() {
		int index;
		synchronized(indexOfNextElement) {
			if (indexOfNextElement <= dimension) {
				index = indexOfNextElement;
				indexOfNextElement++; 				// ovo ne moze da se desi
			}
			else return;
		}
		int r = cordinatesA[index] * cordinatesB[index];
		//System.out.pr
		synchronized (result) {
			result += r;
		}
	}

}

class VectorMultiplicationException extends Throwable {
	public String toString() {
		return "error: vectors don't have same dimension";
	}
}
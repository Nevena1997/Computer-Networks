package mr16088_Stefan_Kalem_B;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Prvi {
	public static void main(String[] args) 
		throws IOException {
		String fileName = "C:\\Users\\nalog\\Desktop\\mr16088_Stefan_Kalem_B\\src\\mr16088_Stefan_Kalem_B\\prvi-test.txt";
		try (BufferedReader reader = new BufferedReader(
				new InputStreamReader( 
				new FileInputStream(fileName)));
			 BufferedWriter writer = new BufferedWriter( 
				new OutputStreamWriter( 
				new FileOutputStream("hex.txt")));) {
			String nextLine = null;
			System.out.println("debug: ");
			while ((nextLine = reader.readLine()) != null) {
				System.out.println("debug: ");

				Pattern pattern = Pattern.compile("\\b0x[0-9a-eA-E]+\\b");
				Matcher matcher = pattern.matcher(nextLine);
				while (matcher.find()) {
					//System.out.println(matcher.group(0));
					writer.write(matcher.group(0)+"\r\n");
				}
			}
			
		}
		
	}
}




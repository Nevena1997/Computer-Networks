package kolokvijum;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Zad3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		while(sc.hasNext()){
			try{
				URL url=new URL(sc.next());
				String protokol=url.getProtocol();
				int defPort=url.getDefaultPort();
				String hostname=url.getHost();
				String putanja=url.getPath();
				if(!hostname.equals(""))
					System.out.println(protokol+" "+hostname+" "+defPort+" "+putanja);
				else{
					String s[]=putanja.split(":");
					String ip=s[0].substring(1);
					String verzija=ip_adresa(ip);
					String port=s[1].substring(0,2);
					String putanja1=s[1].substring(2);

					if(verzija.equals("v4"))
						System.out.println("("+verzija+") "+protokol+" "+port+" "+putanja1+" ["+ip+"]");
					else
						System.out.println("("+verzija+") "+protokol+" "+port+" "+putanja1);
				}
			}catch(MalformedURLException e){
				System.err.println("Greska sa URL adresom");
			}
		}
		sc.close();
	}

	private static String ip_adresa(String ip) {
		if(ip.contains(":"))
			return "v6";
		if(ip.contains("."))
			return "v4";
		else
			return null;
	}
}

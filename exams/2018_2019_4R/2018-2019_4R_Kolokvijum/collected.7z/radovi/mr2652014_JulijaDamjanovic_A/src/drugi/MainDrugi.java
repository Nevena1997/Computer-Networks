package drugi;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.UnsupportedEncodingException;

@SuppressWarnings("unused")
public class MainDrugi {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		String putanja1 = sc.nextLine().trim();
		String putanja2 = sc.nextLine().trim();
		sc.close();

		try{
		InputStreamReader p1 = new InputStreamReader(new FileInputStream(putanja1),"UTF-8");
		InputStreamReader p2 = new InputStreamReader(new FileInputStream(putanja2),"UTF-8");
		int b;
		while((b = p1.read())!=-1){

			System.out.println(b);
		}
		int k;
		while((k = p2.read())!=-1){
			System.out.println(k);
		}
		p1.close();
		p2.close();
		}catch(FileNotFoundException e){
			System.out.println("Fajl ne postoji");
		}

		catch(InterruptedIOException e){
			e.printStackTrace();
		}


	}

}

package prvi;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.UnsupportedEncodingException;




public class MainPrvi {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String file = sc.next().trim();
		//System.out.println(file);
		sc.close();
		Scanner in = null;
		String bla = " ";
		try{

		in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8")));
		@SuppressWarnings("resource")
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("names.txt"),"UTF-8"));
		while(in.hasNextLine()){
			bla = in.nextLine().trim();
			//System.out.println(bla);
			if(IspravnaNiska(bla))
				out.write(bla + "\r\n");
		}


		}
		catch(InterruptedIOException e){
			e.printStackTrace();
		}
		catch(FileNotFoundException ex){
			System.err.println("File"+ file +"ne postoji ! \n");
		}
		catch(UnsupportedEncodingException ex){
			System.err.println("Ovo ne bi trebalo da se desi, greska!");
		} catch (IOException e) {

			e.printStackTrace();
		}finally{

				if(in!=null)
					in.close();
				//if(out!=null)
			//		out.close();

		}



	}

	private static boolean IspravnaNiska(String word){
		if(word.length() < 1)
			return false;
		//if(!(word.toUpperCase().charAt(0)))
		//	return false;
		else
			return true;
	}



}

package P01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		String file = sc.next();
		InputStreamReader in;
		OutputStreamWriter out;
		try{
			 in = new InputStreamReader(new FileInputStream(file));
			 out = new OutputStreamWriter(new FileOutputStream("names.txt"));
			int c;
			while((c = in.read()) != -1)
				out.write((char)c);

			in.close();
			out.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.println("NE postojeci fajl");
		} catch (IOException e) {
			System.out.println("Ne mogu da zatvorim fajl");
		}finally{
		}

		try {
			in = new InputStreamReader(new FileInputStream(file));
			out = new OutputStreamWriter(new FileOutputStream("names1.txt"));


			int c;
			StringBuilder str = new StringBuilder("");
			String pom = null;
			while((c = in.read()) != -1)
			{
				if((char)c == ' ' || (char)c == '\n')
				{
					if(onlyFirstCharUpper(str.toString()))
					{
						if(pom == null)
						{
							pom = str.toString();
							str = new StringBuilder("");
						}
						else
						{
							out.write(pom);
							out.write(' ');
							out.write(str.toString());
							pom = null;
							str = new StringBuilder("");
							out.close();
						}
					}
					else{
						pom = null;
						str = new StringBuilder("");
					}
				}
				else{
					str.append((char)c);
				}
			}
			in.close();
			out.close();

		} catch (FileNotFoundException e) {
			System.out.println("NE postojeci fajl");
		} catch (IOException e) {
			System.out.println("Nisam uspeo da procitam liniju");
		}
		finally{
		}

		sc.close();

		try {
			in = new InputStreamReader(new FileInputStream(file), "UTF-8");
			out = new OutputStreamWriter(new FileOutputStream("names2.txt"), "UTF-8");
			BufferedReader bin = new BufferedReader(in);
			BufferedWriter bout = new BufferedWriter(out);
			sc = new Scanner(bin);
			while(sc.hasNext())
			{	bout.write(sc.next());
				bout.newLine();
			}

			bin.close();
			bout.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}








	}

	private static boolean onlyFirstCharUpper(String s)
	{
		if(s.length() == 0 || !Character.isUpperCase(s.charAt(0)))
		{
			return false;
		}
		for(int i = 1; i < s.length(); i++)
			if(!Character.isLowerCase(s.charAt(i)))
				return false;
		return true;
	}
}
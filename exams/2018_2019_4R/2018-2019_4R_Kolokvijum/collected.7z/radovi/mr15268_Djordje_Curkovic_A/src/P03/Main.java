package P03;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		String surl;
		int count = 0;
		URL url;
		while(sc.hasNext()){
			surl = sc.nextLine();
			if(surl.equals("kraj"))break;
			try {
				url = new URL(surl);
				System.out.println(url.getProtocol() + " " + url.getAuthority() + " " + url.getFile());
				String host = url.getHost();

				InetAddress addr = InetAddress.getByName(host);

				byte[] b = addr.getAddress();

				if(b.length == 4)
					System.out.print("(v4) ");
				else if (b.length == 16)
					System.out.print("(v6) ");
				else
					continue;
				System.out.print(url.getProtocol() + " " + url.getFile() + " [ ");
				for(int i = 0; i < b.length; i++)
					System.out.print(b[i] < 0 ? b[i] + 256 : b[i] + " ");
				System.out.println("]");

			} catch (MalformedURLException e) {
				System.out.println(surl + " nije ispravan");
			} catch (UnknownHostException e) {
				System.out.println("nepoznati host");
			}finally{
			}
			sc.close();
		}
	}
}

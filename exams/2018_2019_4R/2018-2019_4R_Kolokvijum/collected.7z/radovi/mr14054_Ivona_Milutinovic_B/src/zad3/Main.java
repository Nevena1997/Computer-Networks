package zad3;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		while(sc.hasNextLine()){

			String s = sc.nextLine();
			try {
				URL url = new URL(s);
				if(!url.getHost().toString().equals("")){
					System.out.print(url.getProtocol() + " ");
					System.out.print(url.getDefaultPort() + " ");
					System.out.print(url.getHost() + " ");
					System.out.println(url.getPath());
				}else{//data nam je IP adresa
					String[] parts = s.split(":");

					if(parts.length > 3){ // u pitanju je v6 adresa
						System.out.print("(v6) ");
						System.out.print(url.getProtocol() + " ");

						if(parts.length == 10){//parts je duzine 10 ako imamo port
							System.out.print("port");
						}

						//path -- nije dobro
						System.out.println(s.substring(s.lastIndexOf(':')+1));
					}
					else{ // u pitanju je ipv4 adresa
						System.out.print("(v4) ");
						System.out.print(url.getProtocol() + " ");

						//trazimo port
						//ako je dat port, onda parts ima 3 elementa
						//ako port nije dat, parts ima 2 elementa
						if(parts.length == 3){
							System.out.print(s.substring(0,s.indexOf('/')));//port
							System.out.print(s.substring(s.indexOf('/')));//path

							//addr
							System.out.print("[");
							String addr_pom = s.substring(s.indexOf(':') + 4,s.lastIndexOf(':'));

							try {
								InetAddress addr = InetAddress.getByName(addr_pom);

								byte[] address = addr.getAddress();
								for(int i=0; i<4; i++){
									System.out.print((address[i] < 0 ? address[i] + 256 : address[i]) + " ");
								}
								System.out.println("]");
							} catch (UnknownHostException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
						else{// u slucaju da nemamo port

							// path -- nije dobro jer izdvaja i port
							System.out.println(s.substring(s.lastIndexOf(':')+1));

							//nedostaje addresa po bajtovima
						}

					}
				}


			} catch (MalformedURLException e) {
				System.out.println(s + " is not valid URL");
			}
		}

		sc.close();
	}
}
/*
http://www.matf.bg.ac.rs:3030/dir1/dir2/test.txt
http:///123.123.123.123:80/dir1/dir2/test.txt
sftp://2001:0db8:85a3:::8a2e:0370:7334/dir1/dir2/test.txt
 */
package zad2;

import java.util.concurrent.locks.Lock;

public class Niti implements Runnable {

	private int[] vector1;
	private int[] vector2;
	private int result;
	private int n;
	private int indeks;
	private Lock lock;

	public static int norm;



	public Niti(int[] vector1, int[] vector2, int result, int n, int indeks, Lock lock) {
		this.vector1 = new int[n];
		this.vector2 = new int[n];
		this.result = result;
		this.n = n;
		this.indeks = indeks;
		this.lock = lock;

		for(int i = 0; i < n; i++){
			this.vector1[i] = vector1[i];
			this.vector2[i] = vector2[i];
		}
	}

	@Override
	public void run() {

		lock.lock();
		Main.result += vector1[indeks] * vector2[indeks];


		norm += Main.result;
		lock.unlock();


	}


}

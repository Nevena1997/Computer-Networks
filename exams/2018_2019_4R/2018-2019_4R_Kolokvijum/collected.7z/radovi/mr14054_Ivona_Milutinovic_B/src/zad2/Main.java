package zad2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

// pretpostavka: u fajlovima su dati samo vektori bez njihovih dimenzija
public class Main {

	public static int result = 0;

	public static void main(String[] args) throws VectorMultiplicationException, InterruptedException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String file1 = sc.nextLine();
		String file2 = sc.nextLine();
		sc.close();

		//List<int> vector1 = new ArrayList<int>(100);
		int[] vector1 = new int[100];
		int[] vector2 = new int[100];


		Lock lock = new ReentrantLock();

		Scanner in1 = null;
		Scanner in2 = null;

		try {
			in1 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file1))));
			in2 = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file2))));

			int n1 = 0;
			int n2 = 0;

			while(in1.hasNextInt()){
				int number = in1.nextInt();
				vector1[n1] = number;
				n1++;
			}

			n1++;

			while(in2.hasNextInt()){
				int number = in2.nextInt();
				vector2[n2] = number;
				n2++;
			}

			n2++;

			System.out.println("vector1: ");
			for(int i = 0; i < n1; i++)
				System.out.print(vector1[i]+ " ");

			System.out.println();

			System.out.println("vector2: ");
			for(int i = 0; i < n2; i++)
				System.out.print(vector2[i]+ " ");

			System.out.println();

			if(n1 != n2)
				throw new VectorMultiplicationException();

			Niti.norm = 0;

			Thread[] niti = new Thread[n1];
			for(int i = 0; i < n1; i++){
				niti[i] = new Thread(new Niti(vector1, vector2, result, n1, i, lock));
				niti[i].start();
			}

			for (Thread t : niti)
				t.join();

			System.out.println("Scalar product: " + result);
			System.out.println("L1 norm: " + Niti.norm);


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			in1.close();
			in2.close();
		}

	}


}
/* Pokretanje:
vektor1.txt
vektor2.txt
 * */

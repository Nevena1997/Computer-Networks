package zad2;

public class VectorMultiplicationException extends Exception {

}

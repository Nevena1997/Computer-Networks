package zad1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		sc.close();

		Scanner in = null;
		BufferedWriter out = null;


		try {

			in = new Scanner(new BufferedReader(new InputStreamReader(new FileInputStream(file))));
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"),"ASCII"));

			while(in.hasNext()){

				String s = in.next();
				if(isHex(s)){

					out.write(s);
					out.newLine();
				}

			}

		} catch (UnsupportedEncodingException  e) {
			System.err.println("Encoding is not supported");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("Failed to open " + file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Failed to write in output file ");
		}finally {

			try{
				if(in!=null)
					 in.close();
				if(out!=null){
					out.flush();
					out.close();

				}
			}catch(IOException e){
				 System.err.println("Failed to close streams");
			}

		}//kraj za finally
	}//kraj za main method

	public static boolean isHex(String s){

		if(!s.startsWith("0x"))
			return false;

		if(!s.substring(2).matches("[A-Fa-f0-9]+"))
			return false;

		return true;
	}

}//kraj za Main


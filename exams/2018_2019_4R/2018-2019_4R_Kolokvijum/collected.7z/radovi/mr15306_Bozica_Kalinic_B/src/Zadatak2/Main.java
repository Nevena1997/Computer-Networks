package Zadatak2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.Scanner;


public class Main {

	public static int[] vect3;
	public static int L1=0;
	public static int L2=0;


	public static void main(String[] args) throws VectorMultiplicationException, IOException {

		Scanner sc = new Scanner(System.in);

		System.out.println("Unesite ime prvog fajla: ");
		String fajl1 = sc.next();


		System.out.println("Unesite ime drugog fajla: ");
		String fajl2 = sc.next();

		Scanner sc1 = null;
		Scanner sc2 = null;
		try {
			 sc1 = new Scanner(new FileInputStream(fajl1));
			 sc2 = new Scanner(new FileInputStream(fajl2));
			int dim1 = sc1.nextInt();
			int dim2 = sc2.nextInt();

			if(dim1!=dim2)
				throw new VectorMultiplicationException();


			int[] vect1 = new int[dim1];
			int[] vect2 = new int[dim1];
			vect3 = new int[dim1];
			Niz resenje = new Niz(dim1);

			int i;

			for(i=0;i<dim1;i++){
				vect1[i] = sc1.nextInt();
			}


			for(i=0;i<dim2;i++){
				vect2[i] = sc2.nextInt();
			}

			for(i=0;i<dim2;i++){
				System.out.print(vect1[i]+ " ");
			}
			System.out.println();

			for(i=0;i<dim2;i++){
				System.out.print(vect2[i]+ " ");
			}
			System.out.println();

			int n = dim1;
			for(i=0;i<n;i++){
				Scalar s1= new Scalar(vect1, vect2, resenje, dim1, i);
				Thread t = new Thread(s1);
				t.start();

			}

			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			for(i=0;i<dim2;i++){
				System.out.print(vect3[i] + " ");
			}

			System.out.println();
			System.out.println(L1);
			System.out.println(L2);

			System.out.println(resenje.toString());
			System.out.println(resenje.getL1());
			System.out.println(resenje.getL2());


		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(sc1!=null)
				sc1.close();


			if(sc2!=null)
				sc2.close();
		}


	}




}

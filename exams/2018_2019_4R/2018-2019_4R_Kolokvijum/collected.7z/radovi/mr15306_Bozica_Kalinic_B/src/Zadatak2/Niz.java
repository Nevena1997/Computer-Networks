package Zadatak2;

public class Niz {

	private int[] vector;
	private int L1=0;
	private int L2=0;
	private int dim;

	public Niz(int dim){
		this.vector = new int[dim];
		int i;
		for(i=0;i<dim;i++)
			vector[i] = 0;
	}

	public void set(int i, int value){
		vector[i] = value;
	}

	public void addL1(int i){
		L1+=i;
	}

	public void addL2(int i){
		L2+=i;
	}

	@Override
	public String toString() {
		String s = "";
		int i;
		for(i=0;i<dim;i++)
			s +=vector[i];
		return s;
	}

	public int getL1() {
		return L1;
	}

	public int getL2() {
		return L2;
	}
}

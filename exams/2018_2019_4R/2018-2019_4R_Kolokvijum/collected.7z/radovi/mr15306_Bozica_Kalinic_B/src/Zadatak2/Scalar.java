package Zadatak2;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Scalar implements Runnable{

	private int[] vect1;
	private int[] vect2;
	public int[] obradjeni;
	private int dim;
	private int i;
	private Niz resenje;
	Lock lock;

	Scalar(int[] a, int[] b, Niz resenje, int dim, int i){
		vect1 = a;
		vect2 = b;
		this.i =i;
		this.dim = dim;
		this.resenje = resenje;

		obradjeni = new int[dim];

		int j;
		for(j=0;j<dim;j++){
			obradjeni[i] = -1;
		}

		lock = new ReentrantLock();
	}

	@Override
	public void run() {
		Random rand = new Random();
		int i;
		while(true){
			i = rand.nextInt(dim);
			if(obradjeni[i]!=-1)
					break;
		}

		lock.lock();
		if(obradjeni[i]==i)
			return;

		obradjeni[i] = i;
		int v =  vect1[i]*vect2[i];
		Main.vect3[i] = v;
		resenje.set(i, v);
		Main.L1+=vect1[i];
		Main.L2+=vect2[i];
		resenje.addL1(v);
		resenje.addL2(v);

		lock.unlock();
	}

}

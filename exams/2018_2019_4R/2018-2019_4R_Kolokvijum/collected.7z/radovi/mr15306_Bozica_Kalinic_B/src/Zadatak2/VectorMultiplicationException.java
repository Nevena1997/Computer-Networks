package Zadatak2;

public class VectorMultiplicationException extends Throwable{

}

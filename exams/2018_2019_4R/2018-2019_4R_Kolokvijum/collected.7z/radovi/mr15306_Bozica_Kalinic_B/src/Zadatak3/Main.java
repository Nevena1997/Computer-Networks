package Zadatak3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String s;
		try {
			while(sc.hasNextLine()){
					s= sc.nextLine();
					InetAddress address = InetAddress.getByName(s);
					if(address.isAnyLocalAddress()){
						URL url = new URL(s);
						if(address.getAddress().length == 4)
							System.out.println("(v4) " + url.getProtocol() + " "+ url.getDefaultPort() + " "+ url.getHost() + " " + url.getPath()+ " ["+ Arrays.toString(address.getAddress()) + "]");
						else if(address.getAddress().length == 16)
							System.out.println("(v6) " + url.getProtocol() + " "+ url.getDefaultPort() + " "+ url.getHost() + " " + url.getPath()+ " ["+ address.getAddress().toString()+ "]");
					}else{
						URL url = new URL(s);
						URLConnection uc = url.openConnection();
						System.out.println(url.getProtocol() + " "+ url.getDefaultPort() + " "+ url.getHost() + " " + url.getPath());

					}

			}


		} catch ( IOException e) {
				e.printStackTrace();
		}finally{
			sc.close();
		}


	}

}

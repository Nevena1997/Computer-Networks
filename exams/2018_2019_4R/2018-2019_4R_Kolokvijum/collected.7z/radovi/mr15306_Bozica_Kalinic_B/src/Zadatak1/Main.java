package Zadatak1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite naziv fajla: ");
		String ulaz = sc.next();
		sc.close();

		BufferedReader br = null;
		BufferedWriter bw = null;
		try{
			 br = new BufferedReader(new InputStreamReader(new FileInputStream(ulaz)));
			 bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("hex.txt"), "ASCII"));


			//char[] buf = new char[256];
			//int n;

			Pattern pattern = Pattern.compile("Ox[0-9a-fA-F]+");


			//while((n = br.read(buf, 0, 256))!=-1)
				//bw.write(buf, 0, n);
			String s;
			String ss;
			while((s = br.readLine())!=null){
				Matcher matcher = pattern.matcher(s);
				while(matcher.find()){
					ss = matcher.group();
					bw.write(ss);
					bw.newLine();

				}
			}
		}catch(FileNotFoundException e){
			System.err.println("Fajl "+ ulaz + " nije pronadjen!");
			e.printStackTrace();
		}catch(IOException e){
			System.err.println("IOException :(");
			e.printStackTrace();
		}finally{

			if(br!=null)
				br.close();

			if(bw!=null){
				bw.flush();
				bw.close();
			}
		}

	}

}
